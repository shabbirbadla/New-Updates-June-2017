using System;
using System.Collections.Generic;
using System.Text;
using Charts.DAL;
using Charts.DAL.Interfaces;
using System.Data;

namespace Charts.BAL
{
    public class DBOperations : IDBOperations
    {
        #region Memebre Veriables

        private string mReportID = string.Empty;
        private string mConnString = string.Empty;
        private DataSet mOperationsDS = new DataSet();
        private string mDBError = string.Empty;
        private DAL.DBOperations objDBOperations = new Charts.DAL.DBOperations();
        private string mChartsQuarry = string.Empty;
        private string mstringArguments = null;
        private string mnumaricArguments = null;
        private string mdatetimeArguments = null;

        #endregion
        #region IDBOperations Members

        /// <summary>
        /// Get or Set Report ID 
        /// </summary>
        public string ReportID
        {
            get { return mReportID; }
            set { mReportID = value; }
        }
        /// <summary>
        /// Get or Set Connection String Of The Reports 
        /// </summary>
        public string ConnString
        {
            get { return mConnString; }
            set { mConnString = value; }
        }
        /// <summary>
        /// get or set string arguments to pass the quarry
        /// </summary>
        public string stringArguments
        {
            get
            {
                return mstringArguments;
            }
            set
            {
                mstringArguments = value;
            }
        }
        /// <summary>
        /// get or set numaric arguments to pass the quarry
        /// </summary>
        public string numaricArguments
        {
            get
            {
                return mnumaricArguments;
            }
            set
            {
                mnumaricArguments = value;
            }
        }
        /// <summary>
        /// get or set datetime arguments to pass the quarry
        /// </summary>
        public string datetimeArguments
        {
            get
            {
                return mdatetimeArguments;
            }
            set
            {
                mdatetimeArguments = value;
            }
        }
        /// <summary>
        /// Get or Set DataSet
        /// </summary>
        public DataSet OperationsDS
        {
            get { return mOperationsDS; }
            set { mOperationsDS = value; }
        }
        /// <summary>
        /// Get the DB Error
        /// </summary>
        public string DBError
        {
            get { return mDBError; }
        }
        /// <summary>
        /// To Get or Set Charts Quarry
        /// </summary>
        public string ChartsQuarry
        {
            get
            {
                return mChartsQuarry;
            }
            set
            {
                mChartsQuarry = value;
            }
        }

        #endregion
        #region Public Methods
        public DataSet GetChartQuarry()
        {
            OperationsDS = new DataSet();
            try
            {
                objDBOperations.ReportID = ReportID;
                objDBOperations.ConnString = ConnString;
                OperationsDS = objDBOperations.GetChartQuarry(this);

                if (OperationsDS.Tables.Count > 0)
                {
                    if (OperationsDS.Tables["ReportDetails"].Rows.Count > 0)
                    {
                        return OperationsDS;
                    }
                    else
                    {
                        mDBError = "Error To Retrive The Data";
                        return OperationsDS = new DataSet();
                    }
                }
                else
                {
                    mDBError = "Error To Retrive The Data";
                    return OperationsDS = new DataSet();
                }
            }
            catch (Exception ex)
            {
                mDBError = ex.Message;
            }

            return OperationsDS;
        }
        public DataSet GetChartReportData()
        {
            OperationsDS = new DataSet();
            try
            {
                objDBOperations.ReportID = ReportID;
                objDBOperations.ConnString = ConnString;
                objDBOperations.ChartsQuarry = ChartsQuarry;
                objDBOperations.datetimeArguments = datetimeArguments;
                objDBOperations.numaricArguments = numaricArguments;
                objDBOperations.stringArguments = stringArguments;
                OperationsDS = objDBOperations.GetChartReportData(this);
                if (OperationsDS.Tables.Count > 0)
                {
                    if (OperationsDS.Tables["ChartsData"].Rows.Count > 0)
                    {
                        return OperationsDS;
                    }
                    else
                    {
                        mDBError = "Error To Retrive The Data";
                        return OperationsDS = new DataSet();
                    }
                }
                else
                {
                    mDBError = "Error To Retrive The Data";
                    return OperationsDS = new DataSet();
                }
            }
            catch (Exception ex)
            {
                mDBError = ex.Message;
            }

            return OperationsDS;
        }
        #endregion
        #region Private Methods

        #endregion


    }
}
