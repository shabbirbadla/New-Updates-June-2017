using System;
using System.Collections.Generic;
using System.Text;
using DevExpress.XtraEditors.Controls;
using DevExpress.LookAndFeel;
using DevExpress.Skins;
using DevExpress.XtraEditors;
using DevExpress.XtraNavBar;
using System.Windows.Forms;
using DevExpress.XtraGrid.Views.Grid;

namespace Charts.BAL
{
    public class Common
    {
        public Common()
        {

        }
        public int IndexOf(ListBoxItemCollection itemsCollection, string s)
        {
            for (int i = 0; i < itemsCollection.Count; i++)
                if (itemsCollection[i].ToString() == s) return i;
            return -1;
        }
        public ComboBoxEdit InitSkinNames(UserLookAndFeel lookAndFeel, ComboBoxEdit comboBoxEdit)
        {
            foreach (SkinContainer cnt in SkinManager.Default.Skins)
                comboBoxEdit.Properties.Items.Add(cnt.SkinName);
            comboBoxEdit.EditValue = lookAndFeel.SkinName;

            return comboBoxEdit;
        }

        public ListBoxControl bindListBox(ListBoxControl listBoxTheme, NavBarControl navBarControl)
        {
            listBoxTheme.Items.AddRange(navBarControl.AvailableNavBarViews.ToArray(typeof(object)) as object[]);
            listBoxTheme.SelectedIndex = IndexOf(listBoxTheme.Items, navBarControl.View.ToString());

            return listBoxTheme;
        }

        #region Spliting the Query Arguments
        /// <summary>
        /// spiting the arguments([,],=,|)
        /// </summary>
        /// <author>Jayakumar Budha</author>
        /// <param name="Value">string</param>
        /// <returns>array of string</returns>
        public string[] spiltArguments(string Value)
        {
            Value = Value.Replace("][", "|");
            Value = Value.Replace("[", "");
            Value = Value.Replace("]", "");
            Value = Value.Replace("=", "|");


            return Value.Split(new char[] { '|' });

        }
        #endregion
    }
}
