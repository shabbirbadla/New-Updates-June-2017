//************************************
// Created By:  S.Arockia Romulus   
// Date:        08/01/2010
// Purpose:     For Udyog Productes
// Discription: For Showing the Chart Reports of the Udyog Products. 
//************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DadosCharts;
using DevExpress.XtraBars;
using Charts.BAL;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;
using DevExpress.XtraCharts;
using DevExpress.XtraPrinting;
using DevExpress.XtraGrid.Views.Grid;
using DataAccess_Net;//Added by Archana K. on 11/10/13 for Bug-21126
using System.Diagnostics;//Added by Archana K. on 11/10/13 for Bug-21126

namespace DadosCharts
{
    public partial class ChartsMain : DevExpress.XtraEditors.XtraForm
    {
        #region Constractor
        /// <summary>
        /// Required designer variable.
        /// </summary>
        public ChartsMain(string[] args)
        {
            System.Threading.Thread.Sleep(5000);
            // Required for Windows Form Designer support
            InitializeComponent();

            // TODO: Add any constructor code after InitializeComponent call
            string[] argument = null; //new string[args.Length];
            //Commented by Archana K. on 23/01/14 for Bug-21126 start
            //if (args.Length == 1)
            //{
            //    argument = args[0].Split(new char[] { '|' });
                
            //}
            //Commented by Archana K. on 23/01/14 for Bug-21126 start
            argument = args[0].Split('|');//Added by Archana K. on 23/01/14 for Bug-21126 
            ChartsID = argument[0].ToString();
            ChartsLoginUser = argument[1].ToString();
            StringValues = argument[2].ToString();
            NumaricValues = argument[3].ToString();
            DateTimeValues = argument[4].ToString();
            ChartsCon = argument[5].ToString();
            //Added by Archana K. on 23/01/14 for Bug-21126 start
            this.pCompId = Convert.ToInt16(args[1]);
            this.pComDbnm = args[2].Replace("<*#*>", " ");
            this.pServerName = args[3].Replace("<*#*>", " ");
            this.pUserId = args[4].Replace("<*#*>", " ");
            this.pPassword = args[5].Replace("<*#*>", " ");
            this.pPApplText = args[9].Replace("<*#*>", " ");
            this.pPApplName = args[10].Replace("<*#*>", " ");
            this.pPApplPID1 = Convert.ToDouble(args[11]); 
            this.pPApplCode = args[12].Replace("<*#*>", " ");
            //Added by Archana K. on 23/01/14 for Bug-21126 end
         }
        #endregion
        #region Public Properties
        private string ChartsLoginUser = string.Empty;
        public string ChartsLoginUserName
        {
            get { return ChartsLoginUser; }
            set { ChartsLoginUser = value; }
        }
        private string StringValues = string.Empty;
        public string ChartsStringValues
        {
            get { return StringValues; }
            set { StringValues = value; }
        }
        private string NumaricValues = string.Empty;
        public string ChartsNumaricValues
        {
            get { return NumaricValues; }
            set { NumaricValues = value; }
        }
        private string DateTimeValues = string.Empty;
        public string ChartsDateTimeValues
        {
            get { return DateTimeValues; }
            set { DateTimeValues = value; }
        }
        private string ChartsCon;

        public string ChartsConnectionString
        {
            get { return ChartsCon; }
            set { ChartsCon = value; }
        }
        //Added by Archana K. on 23/01/14 for Bug-21126 start
        private Int16 _pCompId;
        public Int16 pCompId
        {
            get { return _pCompId; }
            set { _pCompId = value; }
        }
        private string _pComDbnm;
        public string pComDbnm
        {
            get { return _pComDbnm; }
            set { _pComDbnm = value; }
        }
        private string _pServerName;
        public string pServerName
        {
            get { return _pServerName; }
            set { _pServerName = value; }
        }
        private string _pUserId;
        public string pUserId
        {
            get { return _pUserId; }
            set { _pUserId = value; }
        }
        private string _pPassword;
        public string pPassword
        {
            get { return _pPassword; }
            set { _pPassword = value; }
        }
        //Added by Archana K. on 23/01/14 for Bug-21126 End
        #endregion
        #region Member Veriables
        string ChartsConString = string.Empty;
        string ChartsID = string.Empty;
        string ChartsQuary = null;
        string ChartsQuaryID = null;
        string ChartsDisplayType = null;
        string ChartsDispalyName = null;
        string ChartsLevelTypeID = null;
        string attachfilename = string.Empty;
        Charts.BAL.Common controlsLogic = new Charts.BAL.Common();
        string con = ConfigurationManager.ConnectionStrings["Experment.Properties.Settings.ChartsConnectionString"].ConnectionString.ToString();
        //SqlConnection connection = null;
        //SqlCommand command = null;
        //SqlDataAdapter dataAdapter = null;
        CommonInfo commonInfo = new CommonInfo();
        Common common = new Common();
        Charts.BAL.DBOperations objDBOperations = new DBOperations();
        string ReportName = string.Empty;
        string User = string.Empty;
        string Domain = string.Empty;
        string[] LoginUserName = null;
        //Added by Archana K. on 11/10/13 for Bug-21126 start
        DataAccess_Net.clsDataAccess oDataAccess;
        const int Timeout = 5000;
        private String cAppPId, cAppName, pPApplCode, pPApplName, pPApplText;
        private double pPApplPID1;
        //Added by Archana K. on 11/10/13 for Bug-21126 start
        #endregion
        #region Form Events
        #region Form Load Event
        /// <summary>
        /// Form Load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChartsMain_Load(object sender, EventArgs e)
        {
            // this.TopMost = true; //because need to come the form in the front view when runing the application.           

            try
            {
                #region Filling the deta of the Chart Type Dropdown
                string[] _cTypes = null;
                _cTypes = Enum.GetNames(typeof(DevExpress.XtraCharts.ViewType));
                foreach (string type in _cTypes)
                {
                    comboBox_ChartType.Items.Add(type);
                }
                comboBox_ChartType.Text = dadosChartControl_Chart.ChartType;
                #endregion
                #region Filling the deta of the Ledgend Type Dropdown
                string[] _lTypes = null;
                _lTypes = dadosChartControl_Chart.GetAppearanceNames();
                foreach (string type in _lTypes)
                {
                    comboBox_LegendColor.Items.Add(type);
                }
                comboBox_LegendColor.Text = dadosChartControl_Chart.AppearenceName;
                #endregion
                #region DifiningChart Dock Panel Size
                DockAdjesments();
                #endregion
                #region Valideting Chart Legend is Showing Or Hide
                if (dadosChartControl_Chart.LegendVisiblity)
                {
                    barCheckItem_ShowLedgend.Checked = true;
                }
                else
                {
                    barCheckItem_ShowLedgend.Checked = false;
                }
                #endregion
                #region To Close the Splash
                Loading.CloseSplash(); //Closing the splace screen.
                #endregion
                #region Bring to Front the form
                // Make this form the active form and make it TopMost
                this.Show();
                this.Focus();
                this.BringToFront();
                this.TopMost = false;
                #endregion
                #region Need to Change the code
                #region Commented Code
                //connection = new SqlConnection(con);
                //command = new SqlCommand();
                //command.Connection = connection;
                //command.CommandType = CommandType.Text;
                //command.CommandText = " select TOP 10 item as [ITEM SOLD] ,SUM(GRO_AMT)/1000 AS [GROSS AMOUNT]  ,sum(qty)*10 as QTY from stitem inner join it_mast on (it_mast.it_code=stitem.it_code) group by item order by SUM(GRO_AMT) desc";
                ////command.CommandText = "select TOP 10 item as [ITEM SOLD] ,SUM(GRO_AMT)/100000 AS [GROSS AMOUNT],sum(qty)as QTY,(SUM(GRO_AMT)/SUM(QTY))/10 AS [AVERAGE RATE]   from stitem   inner join it_mast on (it_mast.it_code=stitem.it_code)    inner join ac_mast on (ac_mast.ac_id=stitem.ac_id)    WHERE (stitem.date BETWEEN '04/01/2007' AND '03/31/2008')     and (ac_mast.ac_name BETWEEN 'a' AND 'z')   group by item order by SUM(GRO_AMT) desc";
                ////command.CommandText = "select datename(mm,M.date)+'-'+ltrim(str(year(M.date))) as [Month] ,sum(net_amt) as [Net Amt]from stmain m  WHERE (M.date BETWEEN '04/01/2007' AND '03/31/2009')  group by (datename(mm,M.date)+'-'+ltrim(str(year(M.date))))";
                //dataAdapter = new SqlDataAdapter(command);
                #endregion
                objDBOperations.ConnString = ChartsCon;
                objDBOperations.ReportID = ChartsID;

                #endregion
                #region Assign dataset values to user control of the Dados Charts
                DataSet DS = new DataSet();
                //dataAdapter.Fill(dadosChartControl_Chart.DataValues);
                DS = objDBOperations.GetChartQuarry();
                #endregion
                #region Calling the show Chart method of the user Control
                if (DS.Tables.Count > 0)
                {
                    if (DS.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow row in DS.Tables[0].Rows)
                        {
                            ChartsID = row["ReportID"].ToString();
                            ChartsQuary = row["ReportQurry"].ToString();
                            ChartsQuaryID = row["QurryID"].ToString();
                            ChartsDisplayType = row["ReportLevelType"].ToString();
                            ChartsDispalyName = row["ReportName"].ToString();
                            ChartsLevelTypeID = row["ReportLevelTypeID"].ToString();
                            ReportName = ChartsDispalyName;
                        }

                        if (ChartsQuary != string.Empty)
                        {

                            objDBOperations.ChartsQuarry = ChartsQuary;

                            if (ChartsLoginUserName != "" && ChartsLoginUserName != " ")
                            {
                                LoginUserName = commonInfo.spiltArguments(ChartsLoginUserName);
                                for (int i = 0; i < LoginUserName.Length; )
                                {
                                    User = LoginUserName[i + 1].ToString();
                                    Domain = LoginUserName[i + 3].ToString();//LoginUserName[i + 2].ToString() + ":" +
                                    break;
                                }

                            }
                            objDBOperations.stringArguments = ChartsStringValues;
                            objDBOperations.numaricArguments = ChartsNumaricValues;
                            objDBOperations.datetimeArguments = ChartsDateTimeValues;

                            DataSet dsChartReportData = new DataSet();
                            dsChartReportData = objDBOperations.GetChartReportData();
                            if (dsChartReportData.Tables.Count > 0)
                            {
                                if (dsChartReportData.Tables[0].Rows.Count > 0)
                                {
                                    dadosChartControl_Chart.DataValues = dsChartReportData;
                                    if (DS.Tables.Count > 0)
                                    {
                                        if (DS.Tables[0].Rows.Count > 0)
                                        {
                                            dadosChartControl_Chart.ChartTitle = ChartsDispalyName;
                                            dadosChartControl_Chart.ChartType = ChartsDisplayType;
                                            dadosChartControl_Chart.showChart();
                                            //LoginUserName = common.spiltArguments(ChartsLoginUserName);
                                            //for (int i = 0; i < LoginUserName.Length; )
                                            //{
                                            //    User = LoginUserName[i + 1].ToString();
                                            //    Domain = LoginUserName[i + 3].ToString();//LoginUserName[i + 2].ToString() + ":" +
                                            //    break;
                                            //}
                                        }
                                        else
                                        {
                                            if (objDBOperations.DBError != string.Empty)
                                            {
                                                MessageBox.Show(objDBOperations.DBError, "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                                            }
                                            else
                                            {
                                                MessageBox.Show("Please Verify Report Query and try once again", "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (objDBOperations.DBError != string.Empty)
                                        {
                                            MessageBox.Show(objDBOperations.DBError, "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                                        }
                                        else
                                        {
                                            MessageBox.Show("Please Verify Report Query and try once again", "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                                        }
                                    }//
                                }
                                else
                                {
                                    MessageBox.Show("The Data Values Are Null, To View Chart Need To Pass At Least One Numaric Value.", "Dados Charts - Information", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                                    Application.Exit();
                                }

                            }
                            else
                            {
                                MessageBox.Show("The Data Values Are Null, To View Chart Need To Pass At Least One Numaric Value.", "Dados Charts - Information", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                                Application.Exit();
                            }

                        }

                    }
                    else
                    {
                        if (objDBOperations.DBError != string.Empty)
                        {
                            MessageBox.Show(objDBOperations.DBError, "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        }
                        else
                        {
                            MessageBox.Show("Please Verify Report Query and try once again", "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                        }

                    }
                }

                #endregion
                #region To Display Gridview in the Chart Data Dock panel
                if (dadosChartControl_Chart.DataValues.Tables.Count > 0)
                {
                    if (dadosChartControl_Chart.DataValues.Tables[0].Rows.Count > 0)
                    {
                        gridControl_ChartData.DataSource = dadosChartControl_Chart.DataValues.Tables[0];
                        gridControl_ChartData.ForceInitialize();
                        gridViewChartData.PopulateColumns();
                        gridViewChartData.BestFitColumns();
                    }
                }

                #endregion
                #region binding thems in list box and combo box
                listBoxTheme = controlsLogic.bindListBox(listBoxTheme, navBarControl_ChartOptions);//binding the list box with availble themes but it will not appear in the screen
                comboBoxEdit2 = controlsLogic.InitSkinNames(gridControl_ChartData.LookAndFeel, comboBoxEdit2);// binding the dropdown box with default theams but it will not appear in the screen
                #endregion
                #region to display user id in status bar and display the report name as title
                StatusBar_barStaticItem.Caption = "User Name : " + User;

                this.Text = ReportName + "-" + Domain;
                #endregion
                //Added by Archana K. on 23/01/14 for Bug-21126 start
                DataAccess_Net.clsDataAccess._databaseName = this.pComDbnm;
                DataAccess_Net.clsDataAccess._serverName = this.pServerName;
                DataAccess_Net.clsDataAccess._userID = this.pUserId;
                DataAccess_Net.clsDataAccess._password = this.pPassword;
                oDataAccess = new DataAccess_Net.clsDataAccess();

                this.mInsertProcessIdRecord();
                //Added by Archana K. on 23/01/14 for Bug-21126 end
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }
        #endregion
        #region File Menu Items Functionality
        #region Print the Chart
        /// <summary>
        /// Print Menu Item Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Print_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            dadosChartControl_Chart.Print();
        }
        /// <summary>
        /// to Print the Both Chart and Data Grid in form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_printBoth_ItemClick(object sender, ItemClickEventArgs e)
        {
            DevExpress.XtraPrintingLinks.CompositeLink compositeLink = new DevExpress.XtraPrintingLinks.CompositeLink();
            compositeLink = dadosChartControl_Chart.PrintOrPrintPreviewChart();
            PrintingSystem ps = new PrintingSystem();
            compositeLink.PrintingSystem = ps;

            PrintableComponentLink link = new PrintableComponentLink();
            link.Component = gridControl_ChartData;
            compositeLink.Links.Add(link);

            compositeLink.CreateDocument();
            compositeLink.Print(string.Empty);


        }
        /// <summary>
        /// to Print the Chart in form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_printChart_ItemClick(object sender, ItemClickEventArgs e)
        {
            dadosChartControl_Chart.Print();
        }
        /// <summary>
        /// to Print the Data Grid in form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_printGridData_ItemClick(object sender, ItemClickEventArgs e)
        {
            gridControl_ChartData.Print();
        }
        #endregion
        #region Exit Application
        /// <summary>
        /// Exit Menu Item Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (MessageBox.Show(this, "Do You Really Want To Exit ?", "Dados Reports", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                Application.Exit();
            }
        }
        #endregion
        #region Print Preview of the Chart
        /// <summary>
        /// Print preview Menu Item Event 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_PrintPreview_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            dadosChartControl_Chart.PrintPreview();
        }
        /// <summary>
        /// Print preview Menu Item Event for both data grid and Chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_PrintPreviewBoth_ItemClick(object sender, ItemClickEventArgs e)
        {
            DevExpress.XtraPrintingLinks.CompositeLink compositeLink = new DevExpress.XtraPrintingLinks.CompositeLink();
            compositeLink = dadosChartControl_Chart.PrintOrPrintPreviewChart();
            PrintingSystem ps = new PrintingSystem();
            compositeLink.PrintingSystem = ps;

            PrintableComponentLink link = new PrintableComponentLink();
            link.Component = gridControl_ChartData;
            compositeLink.Links.Add(link);

            compositeLink.CreateDocument();
            compositeLink.ShowPreview();
        }
        /// <summary>
        /// Print preview Menu Item Event for Chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_PrintPreviewChart_ItemClick(object sender, ItemClickEventArgs e)
        {
            dadosChartControl_Chart.PrintPreview();
        }
        /// <summary>
        /// Print preview Menu Item Event for grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_PrintPreviewGridData_ItemClick(object sender, ItemClickEventArgs e)
        {
            gridControl_ChartData.ShowPrintPreview();
        }
        #endregion
        #endregion
        #region View Menu Item Functionality
        #region Show or Hide The Chart Legend
        /// <summary>
        /// Show or Hide The Chart Legend
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_ShowLedgend_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (barCheckItem_ShowLedgend.Checked)
            {
                dadosChartControl_Chart.ShowHideLegend();
                barCheckItem_ShowLedgend.Caption = "Show Legend";
            }
            else
            {
                dadosChartControl_Chart.ShowHideLegend();
                barCheckItem_ShowLedgend.Caption = "Hide Legend";
            }
        }
        #endregion

        #region Show Or Hide The Chart 3D Effects
        /// <summary>
        /// Show Or Hide The Chart 3D Effects
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_Show3DEffects_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Show or Hide Scrollbar of the Chart
        /// <summary>
        /// Show or Hide Scrollbar of the Chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_ShowScrollBar_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide or Show Titles
        /// <summary>
        /// To  Hide or Show Titles
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_ShowTitle_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide or Show X Axis
        /// <summary>
        /// To Hide or Show X Axis
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_ShowXAxis_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide or show Y Axis
        /// <summary>
        /// To Hide or show Y Axis
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_ShowYAxis_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide or Show Tool Tip
        /// <summary>
        /// To Hide or Show Tool Tip
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_ShowToolTip_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide or Show Cross Hair
        /// <summary>
        /// To Hide or Show Cross Hair
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_EnableCrossHair_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Swap or not Swap the Row and Column
        /// <summary>
        /// To Swap or not Swap the Row and Column
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_SwapRowAndColumn_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide or Show Chart Options
        /// <summary>
        /// To Hide or Show Chart Options
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_HideChartOptions_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide or Show Chart
        /// <summary>
        /// To Hide or Show Chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_HideChart_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion

        #region Hide Or Show Chart Data
        /// <summary>
        /// To Hide Or Show Chart Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barCheckItem_HideChartData_CheckedChanged(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #endregion
        #region Options Menu Item Functionality
        #region Email With PDF Functionality
        /// <summary>
        /// For Email With PDF Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_PDF_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            string fileName = ShowSaveFileDialog("PDF Document", "PDF|*.PDF");
            if (fileName != "")
            {
                dadosChartControl_Chart.SavePDF(fileName);
                DialogResult DR = MessageBox.Show("You Want To Send A Mail ??", "Information - Send Exel File", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                if (DR == DialogResult.Yes)
                {
                    try
                    {
                        SendMail sendmail = new SendMail(fileName, attachfilename, this.Text, ChartsLoginUserName, string.Empty);
                        sendmail.ShowDialog();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Mail Sending Files, please send once again \r\n the Error Is: " + ex.Message, "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    }
                }
                else
                {
                    FileInfo fi = new FileInfo(fileName);
                    if (fi.Exists)
                    {
                        fi.Delete();
                    }
                }
            }
        }
        #endregion

        #region Export with Html Functionality
        /// <summary>
        /// For Export with Html Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ExportToHtml_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            dadosChartControl_Chart.ExportToHtml();
        }
        #endregion

        #region Export with PDF Functionality
        /// <summary>
        /// For Export with PDF Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ExportToPDF_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            dadosChartControl_Chart.ExportToPdf();
        }
        #endregion

        #region Export to Image Functionality
        #region Export to BMP Image Functionality
        /// <summary>
        /// Export to BMP Image Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Bmp_ItemClick(object sender, ItemClickEventArgs e)
        {
            dadosChartControl_Chart.ExportToImage("bmp");
        }
        #endregion
        #region Export to Jpeg Image Functionality
        /// <summary>
        /// Export to Jpeg Image Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Jpeg_ItemClick(object sender, ItemClickEventArgs e)
        {
            dadosChartControl_Chart.ExportToImage("jpeg");
        }
        #endregion
        #region Export to Gif Image Functionality
        /// <summary>
        /// Export to Gif Image Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Gif_ItemClick(object sender, ItemClickEventArgs e)
        {
            dadosChartControl_Chart.ExportToImage("gif");
        }
        #endregion
        #region Export to Icon Image Functionality
        /// <summary>
        /// Export to Icon Image Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Icon_ItemClick(object sender, ItemClickEventArgs e)
        {
            dadosChartControl_Chart.ExportToImage("icon");
        }
        #endregion
        #endregion

        #endregion
        #region Customize Menu Items Functionality
        #region Create Drill Down Chart Report
        /// <summary>
        /// To Create Drill Down Chart Report
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_CreateDrillDown_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #region Create Calculated Fields in Chart Report
        /// <summary>
        /// To Create Calculated Fields in Chart Report
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>        
        private void barButtonItem_CreateCalculatedFields_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #region Set Chart's Top or Bottom Values
        /// <summary>
        /// To Set Chart's Top or Bottom Values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_TopOrBottomValue_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #region Conditional RunTime Fields
        /// <summary>
        /// For Conditional RunTime Fields
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ConditionalRunTimeFields_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #region Data Field of the Chart
        /// <summary>
        /// For Data Field of the Chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_DataField_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #region Change Main Field in Chart
        /// <summary>
        /// To Change Main Field in Chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ChangeMainField_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion


        #endregion
        #region Toggle Menu Items Functionality
        #region For Toggle to Cute
        /// <summary>
        /// For Toggle to Cute
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ToggleToCute_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #region To View the Toggle
        /// <summary>
        /// To View the Toggle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ToggleToView_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #region For Advance view of the toggle
        /// <summary>
        /// For Advance view of the toggle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ToggleToAdvanceView_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }
        #endregion
        #endregion
        #region Skin Menu Item Functionality
        #region Skin Format1 functioality
        /// <summary>
        /// For Skin Format1 functioality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Format1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //this is the default them for the window.
            DevExpress.LookAndFeel.UserLookAndFeel.Default.SetSkinStyle("Caramel");
            int intTheme = 0;
            for (int i = 0; i < listBoxTheme.Items.Count; i++)
            {
                if (listBoxTheme.Items[i].ToString() == "Skin:Caramel")
                    intTheme = i;
            }
            listBoxTheme.SelectedIndex = intTheme;
            navBarControl_ChartOptions.View = listBoxTheme.SelectedItem as DevExpress.XtraNavBar.ViewInfo.BaseViewInfoRegistrator;
            navBarControl_ChartOptions.ResetStyles();
            barManager_DadosReports.GetController().PaintStyleName = "Skin";

            int gridtheme = 0;
            for (int j = 0; j < comboBoxEdit2.Properties.Items.Count; j++)
            {
                if (comboBoxEdit2.Properties.Items[j].ToString() == "Caramel")
                    gridtheme = j;

            }
            System.EventArgs e1 = new EventArgs();
            comboBoxEdit2.SelectedIndex = gridtheme;
            comboBoxEdit1_SelectedIndexChanged(comboBoxEdit2, e1);
        }
        #endregion
        #region Skin Format2 Functionality
        /// <summary>
        /// For Skin Format2 Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Format2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DevExpress.LookAndFeel.UserLookAndFeel.Default.SetSkinStyle("Blue");
            //gridControl_ChartData.LookAndFeel.SetStyle(DevExpress.LookAndFeel.LookAndFeelStyle.Skin, false, false, "Blue");
            int intTheme = 0;
            for (int i = 0; i < listBoxTheme.Items.Count; i++)
            {
                if (listBoxTheme.Items[i].ToString() == "Skin:Blue")
                    intTheme = i;
            }
            listBoxTheme.SelectedIndex = intTheme;
            navBarControl_ChartOptions.View = listBoxTheme.SelectedItem as DevExpress.XtraNavBar.ViewInfo.BaseViewInfoRegistrator;
            navBarControl_ChartOptions.ResetStyles();
            barManager_DadosReports.GetController().PaintStyleName = "Skin";

            int gridtheme = 0;
            for (int j = 0; j < comboBoxEdit2.Properties.Items.Count; j++)
            {
                if (comboBoxEdit2.Properties.Items[j].ToString() == "Blue")
                    gridtheme = j;

            }
            System.EventArgs e1 = new EventArgs();
            comboBoxEdit2.SelectedIndex = gridtheme;
            comboBoxEdit1_SelectedIndexChanged(comboBoxEdit2, e1);
        }
        #endregion
        #region Skin Format3 Funactionality
        /// <summary>
        /// For Skin Format3 Funactionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Format3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DevExpress.LookAndFeel.UserLookAndFeel.Default.SetSkinStyle("Lilian");
            navBarControl_ChartOptions.LookAndFeel.SetStyle(DevExpress.LookAndFeel.LookAndFeelStyle.Skin, false, false, "Lilian");
            int intTheme = 0;
            for (int i = 0; i < listBoxTheme.Items.Count; i++)
            {
                if (listBoxTheme.Items[i].ToString() == "Skin:Lilian")
                    intTheme = i;
            }
            listBoxTheme.SelectedIndex = intTheme;
            navBarControl_ChartOptions.View = listBoxTheme.SelectedItem as DevExpress.XtraNavBar.ViewInfo.BaseViewInfoRegistrator;
            navBarControl_ChartOptions.ResetStyles();
            barManager_DadosReports.GetController().PaintStyleName = "Skin";

            int gridtheme = 0;
            for (int j = 0; j < comboBoxEdit2.Properties.Items.Count; j++)
            {
                if (comboBoxEdit2.Properties.Items[j].ToString() == "Lilian")
                    gridtheme = j;

            }
            System.EventArgs e1 = new EventArgs();
            comboBoxEdit2.SelectedIndex = gridtheme;
            comboBoxEdit1_SelectedIndexChanged(comboBoxEdit2, e1);
        }
        #endregion
        #region Skin Format4 Functionality
        /// <summary>
        /// For Skin Format4 Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Format4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DevExpress.LookAndFeel.UserLookAndFeel.Default.SetSkinStyle("Black");
            navBarControl_ChartOptions.LookAndFeel.SetStyle(DevExpress.LookAndFeel.LookAndFeelStyle.Skin, false, false, "Black");
            int intTheme = 0;
            for (int i = 0; i < listBoxTheme.Items.Count; i++)
            {
                if (listBoxTheme.Items[i].ToString() == "Skin:Black")
                    intTheme = i;
            }
            listBoxTheme.SelectedIndex = intTheme;
            navBarControl_ChartOptions.View = listBoxTheme.SelectedItem as DevExpress.XtraNavBar.ViewInfo.BaseViewInfoRegistrator;
            navBarControl_ChartOptions.ResetStyles();
            barManager_DadosReports.GetController().PaintStyleName = "Skin";

            int gridtheme = 0;
            for (int j = 0; j < comboBoxEdit2.Properties.Items.Count; j++)
            {
                if (comboBoxEdit2.Properties.Items[j].ToString() == "Black")
                    gridtheme = j;

            }
            System.EventArgs e1 = new EventArgs();
            comboBoxEdit2.SelectedIndex = gridtheme;
            comboBoxEdit1_SelectedIndexChanged(comboBoxEdit2, e1);
        }
        #endregion


        #endregion
        #region Image Menu Item Functionality
        #region ChartOptions in Image Menu Item
        /// <summary>
        /// To Hide Or Show ChartOptions in Image Menu Item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ChartOptions_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (dockPanel_ChartOptions.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                dockPanel_ChartOptions.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            }
            else
            {
                dockPanel_ChartOptions.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Visible;
            }
        }
        #endregion
        #region Chart Data in Image Menu Item
        /// <summary>
        /// To Hide and Show Chart Data in Image Menu Item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ChartData_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (dockPanel_ChartData.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                dockPanel_ChartData.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            }
            else
            {
                dockPanel_ChartData.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Visible;
            }

            DockAdjesments();
        }
        #endregion
        #region Summary in Image Menu Item
        /// <summary>
        /// To Hide or Show Summary in Image Menu Item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Summary_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (dockPanel_Summary.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                dockPanel_Summary.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            }
            else
            {
                dockPanel_Summary.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Visible;
            }

        }
        #endregion
        #region Comments in Image Menu Item
        /// <summary>
        /// To Hide or Show Comments in Image Menu Item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_Comments_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (dockPanel_Comments.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                dockPanel_Comments.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            }
            else
            {
                dockPanel_Comments.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Visible;
            }

        }
        #endregion
        #region View Chart in Image Menu Item
        /// <summary>
        /// To Hide Or View the Chart
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem_ViewChart_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (dockPanel_ChartType.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                dockPanel_ChartType.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            }
            else
            {
                dockPanel_ChartType.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Visible;
            }
        }
        #endregion
        #endregion
        #region Chart Option Functionality
        #region Chart Type Apply Button Functionality
        /// <summary>
        /// Chart Type Apply Button Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnApply_ChartType_Click(object sender, EventArgs e)
        {
            dadosChartControl_Chart.changeViewType(comboBox_ChartType.Text);
        }
        #endregion
        #region Legend Color Apply Button Functionality
        /// <summary>
        /// Legend Color Apply Button Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnApply_LegendColor_Click(object sender, EventArgs e)
        {
            dadosChartControl_Chart.SetAppreanceNameToChart(comboBox_LegendColor.Text);
        }
        #endregion
        #region to display font dilog in the form
        /// <summary>
        /// to display font dilog in the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textEdit1_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog(this);
        }
        #endregion
        #region Change Title Apply Button Functionality
        /// <summary>
        /// Change Title Apply Button Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void simpleButton_ChangeTitle_Click(object sender, EventArgs e)
        {
            dadosChartControl_Chart.ChartTitle = txtChartTitle.Text;
            Color color = new Color();
            color = (Color)colorEdit1.EditValue;
            Font font = new Font(fontDialog1.Font, fontDialog1.Font.Style);
            dadosChartControl_Chart.ChangeChartTitle(font, color);
        }
        #endregion
        #endregion
        #region Dockpanel Chart Data Visibility Changed Functionality
        /// <summary>
        /// Dockpanel Chart Data Visibility Changed Functionality
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dockPanel_ChartData_VisibilityChanged(object sender, DevExpress.XtraBars.Docking.VisibilityChangedEventArgs e)
        {
            int BolowDockHight;
            int totalHight;
            Size s = new Size();
            if (e.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                s = new Size();
                s.Height = 196;
                s.Width = dockPanel_ChartData.Size.Width;
                dockPanel_ChartData.Size = s;
                BolowDockHight = dockPanel_ChartData.Size.Height;
                totalHight = this.Height - 100;
                s = new Size();
                s.Height = totalHight - BolowDockHight;
                dockPanel_ChartType.Size = s;
            }
            else if (e.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Hidden)
            {
                totalHight = dockPanel_ChartType.Size.Height;
                s = new Size();
                BolowDockHight = dockPanel_ChartData.Size.Height;
                s.Height = totalHight + BolowDockHight;
                dockPanel_ChartType.Size = s;
            }
            else if (e.Visibility == DevExpress.XtraBars.Docking.DockVisibility.AutoHide)
            {
                s = new Size();
                totalHight = this.Height - 122;
                s = new Size();
                s.Height = totalHight;
                dockPanel_ChartType.Size = s;
            }
        }
        #endregion
        #region Binding the Skins availbabe in dev express controls
        /// <summary>
        /// Binding the Skins availbabe in dev express controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBoxEdit1_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            ComboBoxEdit cb = sender as ComboBoxEdit;
            gridControl_ChartData.LookAndFeel.SkinName = cb.EditValue.ToString();
        }
        #endregion
        #endregion
        #region Public Methods

        #endregion
        #region Private Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="title"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        private string ShowSaveFileDialog(string title, string filter)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            string name = this.Text;// Application.ProductName;
            int n = name.LastIndexOf(".") + 1;
            if (n > 0) name = name.Substring(n, name.Length - n);
            dlg.Title = "Export To " + title;
            dlg.FileName = name;
            dlg.Filter = filter;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                FileInfo fi = new FileInfo(dlg.FileName);
                string strOldFileName = fi.Name;
                string strNewFileName = string.Empty;
                strNewFileName = commonInfo.replaceSpecialChars(strOldFileName, strNewFileName);
                if (strNewFileName != string.Empty)
                    dlg.FileName = dlg.FileName.Replace(strOldFileName, strNewFileName);
                else
                    dlg.FileName = dlg.FileName;

                fi = new FileInfo(dlg.FileName);
                attachfilename = fi.Name;
                return dlg.FileName;
            }
            return "";
        }
        /// <summary>
        /// First Time Form Load adjesments of the all deck panels in the form.
        /// </summary>
        private void DockAdjesments()
        {
            int BolowDockHight;
            int totalHight;
            Size s = new Size();
            if (dockPanel_ChartData.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Visible)
            {
                s = new Size();
                s.Height = 196;
                s.Width = dockPanel_ChartData.Size.Width;
                dockPanel_ChartData.Size = s;
                BolowDockHight = dockPanel_ChartData.Size.Height;
                totalHight = this.Height - 103;
                s = new Size();
                s.Height = totalHight - BolowDockHight;
                dockPanel_ChartType.Size = s;
            }
            else if (dockPanel_ChartData.Visibility == DevExpress.XtraBars.Docking.DockVisibility.Hidden)
            {
                totalHight = this.Height - 122;
                s = new Size();
                s.Height = totalHight;
                dockPanel_ChartType.Size = s;
            }
            else if (dockPanel_ChartData.Visibility == DevExpress.XtraBars.Docking.DockVisibility.AutoHide)
            {
                s = new Size();
                totalHight = this.Height - 122;
                s.Height = totalHight;
                dockPanel_ChartType.Size = s;
            }
        }
        #endregion

        private void ChartsMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            mDeleteProcessIdRecord();//Added by Archana K. on 23/01/14 for Bug-21126 
        }
        ////Added by Archana K. on 23/01/14 for Bug-21126 start
        private void mInsertProcessIdRecord()
        {
            DataSet dsData = new DataSet();
            string sqlstr;
            int pi;
            pi = Process.GetCurrentProcess().Id;
            cAppName = "DadosCharts.exe";
            cAppPId = Convert.ToString(Process.GetCurrentProcess().Id);
            sqlstr = " insert into vudyog..ExtApplLog (pApplCode,CallDate,pApplNm,pApplId,pApplDesc,cApplNm,cApplId,cApplDesc) Values('" + this.pPApplCode + "',Convert(SmallDateTime,GetDate()),'" + this.pPApplName + "'," + this.pPApplPID1 + ",'" + this.pPApplText + "','" + cAppName + "'," + cAppPId + ",'" + this.Text.Trim() + " Dados Report')";
            oDataAccess.ExecuteSQLStatement(sqlstr, null, 20, true);
        }
        private void mDeleteProcessIdRecord()
        {
            if (string.IsNullOrEmpty(this.pPApplName) || this.pPApplPID1 == 0 || string.IsNullOrEmpty(this.cAppName) || string.IsNullOrEmpty(this.cAppPId))
            {
                return;
            }
            DataSet dsData = new DataSet();
            string sqlstr;
            sqlstr = " Delete from vudyog..ExtApplLog where pApplNm='" + this.pPApplName + "' and pApplId=" + this.pPApplPID1 + " and cApplNm= '" + cAppName + "' and cApplId= " + cAppPId;
            oDataAccess.ExecuteSQLStatement(sqlstr, null, 20, true);
        }

        ////Added by Archana K. on 23/01/14 for Bug-21126 end
    }
}
#region Commented Code

#endregion