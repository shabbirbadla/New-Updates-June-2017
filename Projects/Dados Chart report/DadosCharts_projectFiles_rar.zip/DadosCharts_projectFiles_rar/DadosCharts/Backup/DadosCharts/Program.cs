using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DadosCharts
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length != 0)
            {
                try
                {
                    Loading.ShowSplashScreen();
                    Application.Run(new ChartsMain(args));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }
            else
            {
                MessageBox.Show("Directly Run Application Is Not Supports!", "Dados Charts - Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                Application.Exit();
            }

        }
    }
}