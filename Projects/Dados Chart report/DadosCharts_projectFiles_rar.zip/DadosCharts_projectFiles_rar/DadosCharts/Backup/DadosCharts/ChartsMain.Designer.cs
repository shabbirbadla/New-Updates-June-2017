namespace DadosCharts
{
    partial class ChartsMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChartsMain));
            this.barManager_DadosReports = new DevExpress.XtraBars.BarManager(this.components);
            this.bar1 = new DevExpress.XtraBars.Bar();
            this.barButtonItem_ChartOptions = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ChartData = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Summary = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Comments = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ViewChart = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Exit = new DevExpress.XtraBars.BarButtonItem();
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.barSubItem1_File = new DevExpress.XtraBars.BarSubItem();
            this.barSubItem_print = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_printChart = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_printGridData = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_printBoth = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem_PrintPreview = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_PrintPreviewChart = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_PrintPreviewGridData = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_PrintPreviewBoth = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Print = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_PrintPreview = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem_Export = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_ExportToHtml = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ExportToPDF = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem_Image = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_Bmp = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Jpeg = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Gif = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Icon = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem2_View = new DevExpress.XtraBars.BarSubItem();
            this.barCheckItem_ShowLedgend = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_Show3DEffects = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_ShowScrollBar = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_ShowTitle = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_ShowXAxis = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_ShowYAxis = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_ShowToolTip = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_EnableCrossHair = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_SwapRowAndColumn = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_HideChartOptions = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_HideChart = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem_HideChartData = new DevExpress.XtraBars.BarCheckItem();
            this.barSubItem3_Options = new DevExpress.XtraBars.BarSubItem();
            this.barSubItem_Email = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_PDF = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem4_Customize = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_CreateDrillDown = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_CreateCalculatedFields = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_TopOrBottomValue = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ConditionalRunTimeFields = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_DataField = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ChangeMainField = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem5_Toggle = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_ToggleToCute = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ToggleToView = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ToggleToAdvanceView = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem6_Skin = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem_Format1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Format2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Format3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_Format4 = new DevExpress.XtraBars.BarButtonItem();
            this.bar3 = new DevExpress.XtraBars.Bar();
            this.StatusBar_barStaticItem = new DevExpress.XtraBars.BarStaticItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.dockManager_DadosReports = new DevExpress.XtraBars.Docking.DockManager();
            this.hideContainerLeft = new DevExpress.XtraBars.Docking.AutoHideContainer();
            this.dockPanel_ChartOptions = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.navBarControl_ChartOptions = new DevExpress.XtraNavBar.NavBarControl();
            this.navBarGroup_ChartType = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroupControlContainer1 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.comboBox_ChartType = new System.Windows.Forms.ComboBox();
            this.btnApply_ChartType = new DevExpress.XtraEditors.SimpleButton();
            this.navBarGroupControlContainer3 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.simpleButton_ChangeTitle = new DevExpress.XtraEditors.SimpleButton();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.colorEdit1 = new DevExpress.XtraEditors.ColorEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtChartTitle = new DevExpress.XtraEditors.TextEdit();
            this.navBarGroupControlContainer4 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer5 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer6 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer7 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer8 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer9 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer10 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer11 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer12 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer13 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer14 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.navBarGroupControlContainer2 = new DevExpress.XtraNavBar.NavBarGroupControlContainer();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.btnApply_LegendColor = new DevExpress.XtraEditors.SimpleButton();
            this.comboBox_LegendColor = new System.Windows.Forms.ComboBox();
            this.navBarGroup_Legend = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup_Titles = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup4 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup5 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup6 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup7 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup8 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup9 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup10 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup11 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup12 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup13 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarGroup14 = new DevExpress.XtraNavBar.NavBarGroup();
            this.largeImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            this.smallImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            this.hideContainerBottom = new DevExpress.XtraBars.Docking.AutoHideContainer();
            this.dockPanel_ChartData = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel3_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.gridControl_ChartData = new DevExpress.XtraGrid.GridControl();
            this.gridViewChartData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.dockPanel_Comments = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel4_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.listView_Comments = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.dockPanel_Summary = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel5_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.listView_Summary = new System.Windows.Forms.ListView();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.dockPanel_ChartType = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel2_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.dadosChartControl_Chart = new DadosChartControl.DadosChartControl();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.comboBoxEdit2 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.listBoxTheme = new DevExpress.XtraEditors.ListBoxControl();
            ((System.ComponentModel.ISupportInitialize)(this.barManager_DadosReports)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager_DadosReports)).BeginInit();
            this.hideContainerLeft.SuspendLayout();
            this.dockPanel_ChartOptions.SuspendLayout();
            this.dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl_ChartOptions)).BeginInit();
            this.navBarControl_ChartOptions.SuspendLayout();
            this.navBarGroupControlContainer1.SuspendLayout();
            this.navBarGroupControlContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChartTitle.Properties)).BeginInit();
            this.navBarGroupControlContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.largeImageCollection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smallImageCollection)).BeginInit();
            this.hideContainerBottom.SuspendLayout();
            this.dockPanel_ChartData.SuspendLayout();
            this.dockPanel3_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl_ChartData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewChartData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.dockPanel_Comments.SuspendLayout();
            this.dockPanel4_Container.SuspendLayout();
            this.dockPanel_Summary.SuspendLayout();
            this.dockPanel5_Container.SuspendLayout();
            this.dockPanel_ChartType.SuspendLayout();
            this.dockPanel2_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.listBoxTheme)).BeginInit();
            this.SuspendLayout();
            // 
            // barManager_DadosReports
            // 
            this.barManager_DadosReports.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar1,
            this.bar2,
            this.bar3});
            this.barManager_DadosReports.DockControls.Add(this.barDockControlTop);
            this.barManager_DadosReports.DockControls.Add(this.barDockControlBottom);
            this.barManager_DadosReports.DockControls.Add(this.barDockControlLeft);
            this.barManager_DadosReports.DockControls.Add(this.barDockControlRight);
            this.barManager_DadosReports.DockManager = this.dockManager_DadosReports;
            this.barManager_DadosReports.Form = this;
            this.barManager_DadosReports.Images = this.smallImageCollection;
            this.barManager_DadosReports.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barSubItem1_File,
            this.barSubItem2_View,
            this.barSubItem3_Options,
            this.barSubItem4_Customize,
            this.barSubItem5_Toggle,
            this.barSubItem6_Skin,
            this.barButtonItem_Print,
            this.barButtonItem_PrintPreview,
            this.barButtonItem_Exit,
            this.barCheckItem_ShowLedgend,
            this.barCheckItem_Show3DEffects,
            this.barCheckItem_ShowScrollBar,
            this.barCheckItem_ShowTitle,
            this.barCheckItem_ShowXAxis,
            this.barCheckItem_ShowYAxis,
            this.barCheckItem_ShowToolTip,
            this.barCheckItem_EnableCrossHair,
            this.barCheckItem_SwapRowAndColumn,
            this.barCheckItem_HideChartOptions,
            this.barCheckItem_HideChart,
            this.barCheckItem_HideChartData,
            this.barSubItem_Email,
            this.barSubItem_Export,
            this.barButtonItem_PDF,
            this.barButtonItem_ExportToHtml,
            this.barButtonItem_ExportToPDF,
            this.barButtonItem_CreateDrillDown,
            this.barButtonItem_CreateCalculatedFields,
            this.barButtonItem_TopOrBottomValue,
            this.barButtonItem_ConditionalRunTimeFields,
            this.barButtonItem_DataField,
            this.barButtonItem_ChangeMainField,
            this.barButtonItem_ToggleToCute,
            this.barButtonItem_ToggleToView,
            this.barButtonItem_ToggleToAdvanceView,
            this.barButtonItem_Format1,
            this.barButtonItem_Format2,
            this.barButtonItem_Format3,
            this.barButtonItem_Format4,
            this.barButtonItem_ChartOptions,
            this.barButtonItem_ChartData,
            this.barButtonItem_Summary,
            this.barButtonItem_Comments,
            this.barButtonItem_ViewChart,
            this.barSubItem_Image,
            this.barButtonItem_Bmp,
            this.barButtonItem_Jpeg,
            this.barButtonItem_Gif,
            this.barButtonItem_Icon,
            this.barSubItem_print,
            this.barButtonItem_printChart,
            this.barButtonItem_printGridData,
            this.barButtonItem_printBoth,
            this.barSubItem_PrintPreview,
            this.barButtonItem_PrintPreviewChart,
            this.barButtonItem_PrintPreviewGridData,
            this.barButtonItem_PrintPreviewBoth,
            this.StatusBar_barStaticItem,
            this.barStaticItem2});
            this.barManager_DadosReports.LargeImages = this.largeImageCollection;
            this.barManager_DadosReports.MainMenu = this.bar2;
            this.barManager_DadosReports.MaxItemId = 62;
            this.barManager_DadosReports.StatusBar = this.bar3;
            // 
            // bar1
            // 
            this.bar1.BarName = "Custom 2";
            this.bar1.DockCol = 0;
            this.bar1.DockRow = 1;
            this.bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_ChartOptions, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_ChartData, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_Summary, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_Comments, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_ViewChart, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_Exit, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar1.Text = "Custom 2";
            // 
            // barButtonItem_ChartOptions
            // 
            this.barButtonItem_ChartOptions.Caption = "Chart Options";
            this.barButtonItem_ChartOptions.Id = 40;
            this.barButtonItem_ChartOptions.ImageIndex = 14;
            this.barButtonItem_ChartOptions.Name = "barButtonItem_ChartOptions";
            this.barButtonItem_ChartOptions.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ChartOptions_ItemClick);
            // 
            // barButtonItem_ChartData
            // 
            this.barButtonItem_ChartData.Caption = "Chart Data";
            this.barButtonItem_ChartData.Id = 41;
            this.barButtonItem_ChartData.ImageIndex = 15;
            this.barButtonItem_ChartData.Name = "barButtonItem_ChartData";
            this.barButtonItem_ChartData.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ChartData_ItemClick);
            // 
            // barButtonItem_Summary
            // 
            this.barButtonItem_Summary.Caption = "Summary";
            this.barButtonItem_Summary.Id = 42;
            this.barButtonItem_Summary.ImageIndex = 17;
            this.barButtonItem_Summary.Name = "barButtonItem_Summary";
            this.barButtonItem_Summary.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem_Summary.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Summary_ItemClick);
            // 
            // barButtonItem_Comments
            // 
            this.barButtonItem_Comments.Caption = "Comments";
            this.barButtonItem_Comments.Id = 43;
            this.barButtonItem_Comments.ImageIndex = 16;
            this.barButtonItem_Comments.Name = "barButtonItem_Comments";
            this.barButtonItem_Comments.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem_Comments.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Comments_ItemClick);
            // 
            // barButtonItem_ViewChart
            // 
            this.barButtonItem_ViewChart.Caption = "View Chart";
            this.barButtonItem_ViewChart.Id = 44;
            this.barButtonItem_ViewChart.ImageIndex = 18;
            this.barButtonItem_ViewChart.Name = "barButtonItem_ViewChart";
            this.barButtonItem_ViewChart.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ViewChart_ItemClick);
            // 
            // barButtonItem_Exit
            // 
            this.barButtonItem_Exit.Caption = "Exit";
            this.barButtonItem_Exit.Id = 9;
            this.barButtonItem_Exit.ImageIndex = 11;
            this.barButtonItem_Exit.Name = "barButtonItem_Exit";
            this.barButtonItem_Exit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // bar2
            // 
            this.bar2.BarName = "Custom 3";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem1_File),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem2_View),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem3_Options),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem4_Customize),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem5_Toggle),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem6_Skin)});
            this.bar2.OptionsBar.MultiLine = true;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.Text = "Custom 3";
            // 
            // barSubItem1_File
            // 
            this.barSubItem1_File.Caption = "File";
            this.barSubItem1_File.Id = 1;
            this.barSubItem1_File.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem_print),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem_PrintPreview),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Print, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_PrintPreview),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barSubItem_Export, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Exit, true)});
            this.barSubItem1_File.Name = "barSubItem1_File";
            // 
            // barSubItem_print
            // 
            this.barSubItem_print.Caption = "Print";
            this.barSubItem_print.Id = 51;
            this.barSubItem_print.ImageIndex = 20;
            this.barSubItem_print.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_printChart),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_printGridData),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_printBoth)});
            this.barSubItem_print.Name = "barSubItem_print";
            // 
            // barButtonItem_printChart
            // 
            this.barButtonItem_printChart.Caption = "Chart";
            this.barButtonItem_printChart.Id = 52;
            this.barButtonItem_printChart.ImageIndex = 30;
            this.barButtonItem_printChart.Name = "barButtonItem_printChart";
            this.barButtonItem_printChart.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_printChart_ItemClick);
            // 
            // barButtonItem_printGridData
            // 
            this.barButtonItem_printGridData.Caption = "Grid Data";
            this.barButtonItem_printGridData.Id = 53;
            this.barButtonItem_printGridData.ImageIndex = 35;
            this.barButtonItem_printGridData.Name = "barButtonItem_printGridData";
            this.barButtonItem_printGridData.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_printGridData_ItemClick);
            // 
            // barButtonItem_printBoth
            // 
            this.barButtonItem_printBoth.Caption = "Both";
            this.barButtonItem_printBoth.Id = 54;
            this.barButtonItem_printBoth.ImageIndex = 33;
            this.barButtonItem_printBoth.Name = "barButtonItem_printBoth";
            this.barButtonItem_printBoth.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_printBoth_ItemClick);
            // 
            // barSubItem_PrintPreview
            // 
            this.barSubItem_PrintPreview.Caption = "Print Preview";
            this.barSubItem_PrintPreview.Id = 55;
            this.barSubItem_PrintPreview.ImageIndex = 12;
            this.barSubItem_PrintPreview.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_PrintPreviewChart),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_PrintPreviewGridData),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_PrintPreviewBoth)});
            this.barSubItem_PrintPreview.Name = "barSubItem_PrintPreview";
            // 
            // barButtonItem_PrintPreviewChart
            // 
            this.barButtonItem_PrintPreviewChart.Caption = "Chart";
            this.barButtonItem_PrintPreviewChart.Id = 56;
            this.barButtonItem_PrintPreviewChart.ImageIndex = 30;
            this.barButtonItem_PrintPreviewChart.Name = "barButtonItem_PrintPreviewChart";
            this.barButtonItem_PrintPreviewChart.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_PrintPreviewChart_ItemClick);
            // 
            // barButtonItem_PrintPreviewGridData
            // 
            this.barButtonItem_PrintPreviewGridData.Caption = "Grid Data";
            this.barButtonItem_PrintPreviewGridData.Id = 57;
            this.barButtonItem_PrintPreviewGridData.ImageIndex = 35;
            this.barButtonItem_PrintPreviewGridData.Name = "barButtonItem_PrintPreviewGridData";
            this.barButtonItem_PrintPreviewGridData.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_PrintPreviewGridData_ItemClick);
            // 
            // barButtonItem_PrintPreviewBoth
            // 
            this.barButtonItem_PrintPreviewBoth.Caption = "Both";
            this.barButtonItem_PrintPreviewBoth.Id = 58;
            this.barButtonItem_PrintPreviewBoth.ImageIndex = 33;
            this.barButtonItem_PrintPreviewBoth.Name = "barButtonItem_PrintPreviewBoth";
            this.barButtonItem_PrintPreviewBoth.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_PrintPreviewBoth_ItemClick);
            // 
            // barButtonItem_Print
            // 
            this.barButtonItem_Print.Caption = "Print";
            this.barButtonItem_Print.Id = 7;
            this.barButtonItem_Print.ImageIndex = 20;
            this.barButtonItem_Print.Name = "barButtonItem_Print";
            this.barButtonItem_Print.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem_Print.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Print_ItemClick);
            // 
            // barButtonItem_PrintPreview
            // 
            this.barButtonItem_PrintPreview.Caption = "Print Preview";
            this.barButtonItem_PrintPreview.Id = 8;
            this.barButtonItem_PrintPreview.ImageIndex = 12;
            this.barButtonItem_PrintPreview.Name = "barButtonItem_PrintPreview";
            this.barButtonItem_PrintPreview.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem_PrintPreview.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_PrintPreview_ItemClick);
            // 
            // barSubItem_Export
            // 
            this.barSubItem_Export.Caption = "Export";
            this.barSubItem_Export.Id = 23;
            this.barSubItem_Export.ImageIndex = 21;
            this.barSubItem_Export.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_ExportToHtml, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_ExportToPDF, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem_Image, true)});
            this.barSubItem_Export.Name = "barSubItem_Export";
            // 
            // barButtonItem_ExportToHtml
            // 
            this.barButtonItem_ExportToHtml.Caption = "Export to Html";
            this.barButtonItem_ExportToHtml.Id = 25;
            this.barButtonItem_ExportToHtml.ImageIndex = 19;
            this.barButtonItem_ExportToHtml.Name = "barButtonItem_ExportToHtml";
            this.barButtonItem_ExportToHtml.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.Caption;
            this.barButtonItem_ExportToHtml.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ExportToHtml_ItemClick);
            // 
            // barButtonItem_ExportToPDF
            // 
            this.barButtonItem_ExportToPDF.Caption = "Export to PDF";
            this.barButtonItem_ExportToPDF.Id = 26;
            this.barButtonItem_ExportToPDF.ImageIndex = 22;
            this.barButtonItem_ExportToPDF.Name = "barButtonItem_ExportToPDF";
            this.barButtonItem_ExportToPDF.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ExportToPDF_ItemClick);
            // 
            // barSubItem_Image
            // 
            this.barSubItem_Image.Caption = "Image";
            this.barSubItem_Image.Id = 46;
            this.barSubItem_Image.ImageIndex = 24;
            this.barSubItem_Image.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Bmp),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Jpeg),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Gif),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Icon)});
            this.barSubItem_Image.Name = "barSubItem_Image";
            // 
            // barButtonItem_Bmp
            // 
            this.barButtonItem_Bmp.Caption = "BMP Format";
            this.barButtonItem_Bmp.Id = 47;
            this.barButtonItem_Bmp.ImageIndex = 27;
            this.barButtonItem_Bmp.Name = "barButtonItem_Bmp";
            this.barButtonItem_Bmp.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Bmp_ItemClick);
            // 
            // barButtonItem_Jpeg
            // 
            this.barButtonItem_Jpeg.Caption = "Jpeg Format";
            this.barButtonItem_Jpeg.Id = 48;
            this.barButtonItem_Jpeg.ImageIndex = 26;
            this.barButtonItem_Jpeg.Name = "barButtonItem_Jpeg";
            this.barButtonItem_Jpeg.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Jpeg_ItemClick);
            // 
            // barButtonItem_Gif
            // 
            this.barButtonItem_Gif.Caption = "Gif Format";
            this.barButtonItem_Gif.Id = 49;
            this.barButtonItem_Gif.ImageIndex = 25;
            this.barButtonItem_Gif.Name = "barButtonItem_Gif";
            this.barButtonItem_Gif.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Gif_ItemClick);
            // 
            // barButtonItem_Icon
            // 
            this.barButtonItem_Icon.Caption = "Icon Format";
            this.barButtonItem_Icon.Id = 50;
            this.barButtonItem_Icon.ImageIndex = 28;
            this.barButtonItem_Icon.Name = "barButtonItem_Icon";
            this.barButtonItem_Icon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Icon_ItemClick);
            // 
            // barSubItem2_View
            // 
            this.barSubItem2_View.Caption = "View";
            this.barSubItem2_View.Id = 2;
            this.barSubItem2_View.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_ShowLedgend),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_Show3DEffects),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_ShowScrollBar),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_ShowTitle, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_ShowXAxis, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_ShowYAxis),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_ShowToolTip),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_EnableCrossHair, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_SwapRowAndColumn, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_HideChartOptions, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_HideChart),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem_HideChartData)});
            this.barSubItem2_View.Name = "barSubItem2_View";
            this.barSubItem2_View.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // barCheckItem_ShowLedgend
            // 
            this.barCheckItem_ShowLedgend.Caption = "Show Ledgend";
            this.barCheckItem_ShowLedgend.Id = 10;
            this.barCheckItem_ShowLedgend.Name = "barCheckItem_ShowLedgend";
            this.barCheckItem_ShowLedgend.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_ShowLedgend_CheckedChanged);
            // 
            // barCheckItem_Show3DEffects
            // 
            this.barCheckItem_Show3DEffects.Caption = "Show 3D Effects";
            this.barCheckItem_Show3DEffects.Id = 11;
            this.barCheckItem_Show3DEffects.Name = "barCheckItem_Show3DEffects";
            this.barCheckItem_Show3DEffects.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_Show3DEffects_CheckedChanged);
            // 
            // barCheckItem_ShowScrollBar
            // 
            this.barCheckItem_ShowScrollBar.Caption = "Show Scroll Bar";
            this.barCheckItem_ShowScrollBar.Id = 12;
            this.barCheckItem_ShowScrollBar.Name = "barCheckItem_ShowScrollBar";
            this.barCheckItem_ShowScrollBar.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barCheckItem_ShowScrollBar.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_ShowScrollBar_CheckedChanged);
            // 
            // barCheckItem_ShowTitle
            // 
            this.barCheckItem_ShowTitle.Caption = "Show Title";
            this.barCheckItem_ShowTitle.Id = 13;
            this.barCheckItem_ShowTitle.Name = "barCheckItem_ShowTitle";
            this.barCheckItem_ShowTitle.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_ShowTitle_CheckedChanged);
            // 
            // barCheckItem_ShowXAxis
            // 
            this.barCheckItem_ShowXAxis.Caption = "Show X Axis";
            this.barCheckItem_ShowXAxis.Id = 14;
            this.barCheckItem_ShowXAxis.Name = "barCheckItem_ShowXAxis";
            this.barCheckItem_ShowXAxis.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_ShowXAxis_CheckedChanged);
            // 
            // barCheckItem_ShowYAxis
            // 
            this.barCheckItem_ShowYAxis.Caption = "Show Y Axis";
            this.barCheckItem_ShowYAxis.Id = 15;
            this.barCheckItem_ShowYAxis.Name = "barCheckItem_ShowYAxis";
            this.barCheckItem_ShowYAxis.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_ShowYAxis_CheckedChanged);
            // 
            // barCheckItem_ShowToolTip
            // 
            this.barCheckItem_ShowToolTip.Caption = "Show Tool Tip";
            this.barCheckItem_ShowToolTip.Id = 16;
            this.barCheckItem_ShowToolTip.Name = "barCheckItem_ShowToolTip";
            this.barCheckItem_ShowToolTip.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_ShowToolTip_CheckedChanged);
            // 
            // barCheckItem_EnableCrossHair
            // 
            this.barCheckItem_EnableCrossHair.Caption = "Enable CrossHair";
            this.barCheckItem_EnableCrossHair.Id = 17;
            this.barCheckItem_EnableCrossHair.Name = "barCheckItem_EnableCrossHair";
            this.barCheckItem_EnableCrossHair.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_EnableCrossHair_CheckedChanged);
            // 
            // barCheckItem_SwapRowAndColumn
            // 
            this.barCheckItem_SwapRowAndColumn.Caption = "Swap Row and Column";
            this.barCheckItem_SwapRowAndColumn.Id = 18;
            this.barCheckItem_SwapRowAndColumn.Name = "barCheckItem_SwapRowAndColumn";
            this.barCheckItem_SwapRowAndColumn.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_SwapRowAndColumn_CheckedChanged);
            // 
            // barCheckItem_HideChartOptions
            // 
            this.barCheckItem_HideChartOptions.Caption = "Hide Chart Options";
            this.barCheckItem_HideChartOptions.Id = 19;
            this.barCheckItem_HideChartOptions.Name = "barCheckItem_HideChartOptions";
            this.barCheckItem_HideChartOptions.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_HideChartOptions_CheckedChanged);
            // 
            // barCheckItem_HideChart
            // 
            this.barCheckItem_HideChart.Caption = "Hide Chart";
            this.barCheckItem_HideChart.Id = 20;
            this.barCheckItem_HideChart.Name = "barCheckItem_HideChart";
            this.barCheckItem_HideChart.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_HideChart_CheckedChanged);
            // 
            // barCheckItem_HideChartData
            // 
            this.barCheckItem_HideChartData.Caption = "Hide Chart Data";
            this.barCheckItem_HideChartData.Id = 21;
            this.barCheckItem_HideChartData.Name = "barCheckItem_HideChartData";
            this.barCheckItem_HideChartData.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem_HideChartData_CheckedChanged);
            // 
            // barSubItem3_Options
            // 
            this.barSubItem3_Options.Caption = "Options";
            this.barSubItem3_Options.Id = 3;
            this.barSubItem3_Options.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barSubItem_Email, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.barSubItem3_Options.Name = "barSubItem3_Options";
            // 
            // barSubItem_Email
            // 
            this.barSubItem_Email.Caption = "Email";
            this.barSubItem_Email.Id = 22;
            this.barSubItem_Email.ImageIndex = 19;
            this.barSubItem_Email.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem_PDF, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.barSubItem_Email.Name = "barSubItem_Email";
            // 
            // barButtonItem_PDF
            // 
            this.barButtonItem_PDF.Caption = "PDF";
            this.barButtonItem_PDF.Id = 24;
            this.barButtonItem_PDF.ImageIndex = 22;
            this.barButtonItem_PDF.Name = "barButtonItem_PDF";
            this.barButtonItem_PDF.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_PDF_ItemClick);
            // 
            // barSubItem4_Customize
            // 
            this.barSubItem4_Customize.Caption = "Customize";
            this.barSubItem4_Customize.Id = 4;
            this.barSubItem4_Customize.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_CreateDrillDown),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_CreateCalculatedFields),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_TopOrBottomValue),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_ConditionalRunTimeFields, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_DataField),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_ChangeMainField, true)});
            this.barSubItem4_Customize.Name = "barSubItem4_Customize";
            this.barSubItem4_Customize.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // barButtonItem_CreateDrillDown
            // 
            this.barButtonItem_CreateDrillDown.Caption = "Create Drill Down";
            this.barButtonItem_CreateDrillDown.Id = 27;
            this.barButtonItem_CreateDrillDown.Name = "barButtonItem_CreateDrillDown";
            this.barButtonItem_CreateDrillDown.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_CreateDrillDown_ItemClick);
            // 
            // barButtonItem_CreateCalculatedFields
            // 
            this.barButtonItem_CreateCalculatedFields.Caption = "Create Calculated Fields";
            this.barButtonItem_CreateCalculatedFields.Id = 28;
            this.barButtonItem_CreateCalculatedFields.Name = "barButtonItem_CreateCalculatedFields";
            this.barButtonItem_CreateCalculatedFields.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_CreateCalculatedFields_ItemClick);
            // 
            // barButtonItem_TopOrBottomValue
            // 
            this.barButtonItem_TopOrBottomValue.Caption = "Top or Bottom Value";
            this.barButtonItem_TopOrBottomValue.Id = 29;
            this.barButtonItem_TopOrBottomValue.Name = "barButtonItem_TopOrBottomValue";
            this.barButtonItem_TopOrBottomValue.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_TopOrBottomValue_ItemClick);
            // 
            // barButtonItem_ConditionalRunTimeFields
            // 
            this.barButtonItem_ConditionalRunTimeFields.Caption = "Conditional Run Time Fields";
            this.barButtonItem_ConditionalRunTimeFields.Id = 30;
            this.barButtonItem_ConditionalRunTimeFields.Name = "barButtonItem_ConditionalRunTimeFields";
            this.barButtonItem_ConditionalRunTimeFields.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ConditionalRunTimeFields_ItemClick);
            // 
            // barButtonItem_DataField
            // 
            this.barButtonItem_DataField.Caption = "Data Field";
            this.barButtonItem_DataField.Id = 31;
            this.barButtonItem_DataField.Name = "barButtonItem_DataField";
            this.barButtonItem_DataField.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_DataField_ItemClick);
            // 
            // barButtonItem_ChangeMainField
            // 
            this.barButtonItem_ChangeMainField.Caption = "Change Main Field";
            this.barButtonItem_ChangeMainField.Id = 32;
            this.barButtonItem_ChangeMainField.Name = "barButtonItem_ChangeMainField";
            this.barButtonItem_ChangeMainField.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ChangeMainField_ItemClick);
            // 
            // barSubItem5_Toggle
            // 
            this.barSubItem5_Toggle.Caption = "Toggle";
            this.barSubItem5_Toggle.Id = 5;
            this.barSubItem5_Toggle.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_ToggleToCute),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_ToggleToView),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_ToggleToAdvanceView)});
            this.barSubItem5_Toggle.Name = "barSubItem5_Toggle";
            this.barSubItem5_Toggle.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // barButtonItem_ToggleToCute
            // 
            this.barButtonItem_ToggleToCute.Caption = "Toggle ToCute";
            this.barButtonItem_ToggleToCute.Id = 33;
            this.barButtonItem_ToggleToCute.Name = "barButtonItem_ToggleToCute";
            this.barButtonItem_ToggleToCute.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ToggleToCute_ItemClick);
            // 
            // barButtonItem_ToggleToView
            // 
            this.barButtonItem_ToggleToView.Caption = "Toggle ToView";
            this.barButtonItem_ToggleToView.Id = 34;
            this.barButtonItem_ToggleToView.Name = "barButtonItem_ToggleToView";
            this.barButtonItem_ToggleToView.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ToggleToView_ItemClick);
            // 
            // barButtonItem_ToggleToAdvanceView
            // 
            this.barButtonItem_ToggleToAdvanceView.Caption = "Toggle ToAdvanceView";
            this.barButtonItem_ToggleToAdvanceView.Id = 35;
            this.barButtonItem_ToggleToAdvanceView.Name = "barButtonItem_ToggleToAdvanceView";
            this.barButtonItem_ToggleToAdvanceView.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_ToggleToAdvanceView_ItemClick);
            // 
            // barSubItem6_Skin
            // 
            this.barSubItem6_Skin.Caption = "Skin";
            this.barSubItem6_Skin.Id = 6;
            this.barSubItem6_Skin.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Format1),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Format2),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Format3),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem_Format4)});
            this.barSubItem6_Skin.Name = "barSubItem6_Skin";
            // 
            // barButtonItem_Format1
            // 
            this.barButtonItem_Format1.Caption = "Format1";
            this.barButtonItem_Format1.Id = 36;
            this.barButtonItem_Format1.Name = "barButtonItem_Format1";
            this.barButtonItem_Format1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Format1_ItemClick);
            // 
            // barButtonItem_Format2
            // 
            this.barButtonItem_Format2.Caption = "Format2";
            this.barButtonItem_Format2.Id = 37;
            this.barButtonItem_Format2.Name = "barButtonItem_Format2";
            this.barButtonItem_Format2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Format2_ItemClick);
            // 
            // barButtonItem_Format3
            // 
            this.barButtonItem_Format3.Caption = "Format3";
            this.barButtonItem_Format3.Id = 38;
            this.barButtonItem_Format3.Name = "barButtonItem_Format3";
            this.barButtonItem_Format3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Format3_ItemClick);
            // 
            // barButtonItem_Format4
            // 
            this.barButtonItem_Format4.Caption = "Format4";
            this.barButtonItem_Format4.Id = 39;
            this.barButtonItem_Format4.Name = "barButtonItem_Format4";
            this.barButtonItem_Format4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_Format4_ItemClick);
            // 
            // bar3
            // 
            this.bar3.BarName = "Custom 4";
            this.bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.bar3.DockCol = 0;
            this.bar3.DockRow = 0;
            this.bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.bar3.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.StatusBar_barStaticItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.barStaticItem2)});
            this.bar3.OptionsBar.AllowQuickCustomization = false;
            this.bar3.OptionsBar.DrawDragBorder = false;
            this.bar3.OptionsBar.UseWholeRow = true;
            this.bar3.Text = "Custom 4";
            // 
            // StatusBar_barStaticItem
            // 
            this.StatusBar_barStaticItem.Caption = "Ready";
            this.StatusBar_barStaticItem.Id = 60;
            this.StatusBar_barStaticItem.Name = "StatusBar_barStaticItem";
            this.StatusBar_barStaticItem.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.AutoSize = DevExpress.XtraBars.BarStaticItemSize.Spring;
            this.barStaticItem2.Id = 61;
            this.barStaticItem2.Name = "barStaticItem2";
            this.barStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            this.barStaticItem2.Width = 32;
            // 
            // dockManager_DadosReports
            // 
            this.dockManager_DadosReports.AutoHideContainers.AddRange(new DevExpress.XtraBars.Docking.AutoHideContainer[] {
            this.hideContainerLeft,
            this.hideContainerBottom});
            this.dockManager_DadosReports.Form = this;
            this.dockManager_DadosReports.HiddenPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.dockPanel_Comments,
            this.dockPanel_Summary});
            this.dockManager_DadosReports.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.dockPanel_ChartType});
            this.dockManager_DadosReports.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl"});
            // 
            // hideContainerLeft
            // 
            this.hideContainerLeft.Controls.Add(this.dockPanel_ChartOptions);
            this.hideContainerLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.hideContainerLeft.Location = new System.Drawing.Point(0, 51);
            this.hideContainerLeft.Name = "hideContainerLeft";
            this.hideContainerLeft.Size = new System.Drawing.Size(19, 429);
            // 
            // dockPanel_ChartOptions
            // 
            this.dockPanel_ChartOptions.Controls.Add(this.dockPanel1_Container);
            this.dockPanel_ChartOptions.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.dockPanel_ChartOptions.FloatVertical = true;
            this.dockPanel_ChartOptions.ID = new System.Guid("72b1d136-70b8-428b-a2b9-9513500b0c30");
            this.dockPanel_ChartOptions.Location = new System.Drawing.Point(0, 0);
            this.dockPanel_ChartOptions.Name = "dockPanel_ChartOptions";
            this.dockPanel_ChartOptions.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.dockPanel_ChartOptions.SavedIndex = 0;
            this.dockPanel_ChartOptions.Size = new System.Drawing.Size(220, 413);
            this.dockPanel_ChartOptions.Text = "Chart Options";
            this.dockPanel_ChartOptions.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            // 
            // dockPanel1_Container
            // 
            this.dockPanel1_Container.Controls.Add(this.navBarControl_ChartOptions);
            this.dockPanel1_Container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.dockPanel1_Container.Name = "dockPanel1_Container";
            this.dockPanel1_Container.Size = new System.Drawing.Size(220, 413);
            this.dockPanel1_Container.TabIndex = 0;
            // 
            // navBarControl_ChartOptions
            // 
            this.navBarControl_ChartOptions.ActiveGroup = this.navBarGroup_ChartType;
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer1);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer3);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer4);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer5);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer6);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer7);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer8);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer9);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer10);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer11);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer12);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer13);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer14);
            this.navBarControl_ChartOptions.Controls.Add(this.navBarGroupControlContainer2);
            this.navBarControl_ChartOptions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navBarControl_ChartOptions.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.navBarGroup_ChartType,
            this.navBarGroup_Legend,
            this.navBarGroup_Titles,
            this.navBarGroup4,
            this.navBarGroup5,
            this.navBarGroup6,
            this.navBarGroup7,
            this.navBarGroup8,
            this.navBarGroup9,
            this.navBarGroup10,
            this.navBarGroup11,
            this.navBarGroup12,
            this.navBarGroup13,
            this.navBarGroup14});
            this.navBarControl_ChartOptions.LargeImages = this.largeImageCollection;
            this.navBarControl_ChartOptions.Location = new System.Drawing.Point(0, 0);
            this.navBarControl_ChartOptions.Name = "navBarControl_ChartOptions";
            this.navBarControl_ChartOptions.Size = new System.Drawing.Size(220, 413);
            this.navBarControl_ChartOptions.SmallImages = this.smallImageCollection;
            this.navBarControl_ChartOptions.TabIndex = 4;
            this.navBarControl_ChartOptions.Text = "navBarControl1";
            // 
            // navBarGroup_ChartType
            // 
            this.navBarGroup_ChartType.Caption = "Chart Type";
            this.navBarGroup_ChartType.ControlContainer = this.navBarGroupControlContainer1;
            this.navBarGroup_ChartType.GroupClientHeight = 102;
            this.navBarGroup_ChartType.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup_ChartType.Name = "navBarGroup_ChartType";
            this.navBarGroup_ChartType.SmallImageIndex = 7;
            // 
            // navBarGroupControlContainer1
            // 
            this.navBarGroupControlContainer1.Controls.Add(this.labelControl3);
            this.navBarGroupControlContainer1.Controls.Add(this.comboBox_ChartType);
            this.navBarGroupControlContainer1.Controls.Add(this.btnApply_ChartType);
            this.navBarGroupControlContainer1.Name = "navBarGroupControlContainer1";
            this.navBarGroupControlContainer1.Size = new System.Drawing.Size(211, 98);
            this.navBarGroupControlContainer1.TabIndex = 0;
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Location = new System.Drawing.Point(69, 10);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(116, 16);
            this.labelControl3.TabIndex = 4;
            this.labelControl3.Text = "Select Chart TYpe";
            // 
            // comboBox_ChartType
            // 
            this.comboBox_ChartType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChartType.FormattingEnabled = true;
            this.comboBox_ChartType.Location = new System.Drawing.Point(37, 38);
            this.comboBox_ChartType.Name = "comboBox_ChartType";
            this.comboBox_ChartType.Size = new System.Drawing.Size(148, 21);
            this.comboBox_ChartType.TabIndex = 3;
            // 
            // btnApply_ChartType
            // 
            this.btnApply_ChartType.Location = new System.Drawing.Point(110, 71);
            this.btnApply_ChartType.Name = "btnApply_ChartType";
            this.btnApply_ChartType.Size = new System.Drawing.Size(75, 23);
            this.btnApply_ChartType.TabIndex = 2;
            this.btnApply_ChartType.Text = "Apply";
            this.btnApply_ChartType.Click += new System.EventHandler(this.btnApply_ChartType_Click);
            // 
            // navBarGroupControlContainer3
            // 
            this.navBarGroupControlContainer3.Controls.Add(this.simpleButton_ChangeTitle);
            this.navBarGroupControlContainer3.Controls.Add(this.textEdit1);
            this.navBarGroupControlContainer3.Controls.Add(this.labelControl2);
            this.navBarGroupControlContainer3.Controls.Add(this.colorEdit1);
            this.navBarGroupControlContainer3.Controls.Add(this.labelControl1);
            this.navBarGroupControlContainer3.Controls.Add(this.txtChartTitle);
            this.navBarGroupControlContainer3.Name = "navBarGroupControlContainer3";
            this.navBarGroupControlContainer3.Size = new System.Drawing.Size(211, 209);
            this.navBarGroupControlContainer3.TabIndex = 2;
            // 
            // simpleButton_ChangeTitle
            // 
            this.simpleButton_ChangeTitle.Location = new System.Drawing.Point(67, 164);
            this.simpleButton_ChangeTitle.Name = "simpleButton_ChangeTitle";
            this.simpleButton_ChangeTitle.Size = new System.Drawing.Size(75, 23);
            this.simpleButton_ChangeTitle.TabIndex = 38;
            this.simpleButton_ChangeTitle.Text = "Change Title";
            this.simpleButton_ChangeTitle.Click += new System.EventHandler(this.simpleButton_ChangeTitle_Click);
            // 
            // textEdit1
            // 
            this.textEdit1.EditValue = "Title Font Name";
            this.textEdit1.Location = new System.Drawing.Point(4, 117);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Properties.Appearance.BackColor = System.Drawing.Color.LightCoral;
            this.textEdit1.Properties.Appearance.Options.UseBackColor = true;
            this.textEdit1.Properties.Appearance.Options.UseTextOptions = true;
            this.textEdit1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEdit1.Properties.AutoHeight = false;
            this.textEdit1.Properties.ReadOnly = true;
            this.textEdit1.Size = new System.Drawing.Size(204, 40);
            this.textEdit1.TabIndex = 4;
            this.textEdit1.Click += new System.EventHandler(this.textEdit1_Click);
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(4, 83);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(57, 13);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Font Color :";
            // 
            // colorEdit1
            // 
            this.colorEdit1.EditValue = System.Drawing.Color.Empty;
            this.colorEdit1.Location = new System.Drawing.Point(67, 80);
            this.colorEdit1.Name = "colorEdit1";
            this.colorEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.colorEdit1.Size = new System.Drawing.Size(141, 20);
            this.colorEdit1.TabIndex = 2;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Location = new System.Drawing.Point(49, 11);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(148, 16);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Top Title Of The Chart :";
            // 
            // txtChartTitle
            // 
            this.txtChartTitle.Location = new System.Drawing.Point(4, 39);
            this.txtChartTitle.Name = "txtChartTitle";
            this.txtChartTitle.Size = new System.Drawing.Size(204, 20);
            this.txtChartTitle.TabIndex = 0;
            // 
            // navBarGroupControlContainer4
            // 
            this.navBarGroupControlContainer4.Name = "navBarGroupControlContainer4";
            this.navBarGroupControlContainer4.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer4.TabIndex = 3;
            // 
            // navBarGroupControlContainer5
            // 
            this.navBarGroupControlContainer5.Name = "navBarGroupControlContainer5";
            this.navBarGroupControlContainer5.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer5.TabIndex = 4;
            // 
            // navBarGroupControlContainer6
            // 
            this.navBarGroupControlContainer6.Name = "navBarGroupControlContainer6";
            this.navBarGroupControlContainer6.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer6.TabIndex = 5;
            // 
            // navBarGroupControlContainer7
            // 
            this.navBarGroupControlContainer7.Name = "navBarGroupControlContainer7";
            this.navBarGroupControlContainer7.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer7.TabIndex = 6;
            // 
            // navBarGroupControlContainer8
            // 
            this.navBarGroupControlContainer8.Name = "navBarGroupControlContainer8";
            this.navBarGroupControlContainer8.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer8.TabIndex = 7;
            // 
            // navBarGroupControlContainer9
            // 
            this.navBarGroupControlContainer9.Name = "navBarGroupControlContainer9";
            this.navBarGroupControlContainer9.Size = new System.Drawing.Size(252, 76);
            this.navBarGroupControlContainer9.TabIndex = 8;
            // 
            // navBarGroupControlContainer10
            // 
            this.navBarGroupControlContainer10.Name = "navBarGroupControlContainer10";
            this.navBarGroupControlContainer10.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer10.TabIndex = 9;
            // 
            // navBarGroupControlContainer11
            // 
            this.navBarGroupControlContainer11.Name = "navBarGroupControlContainer11";
            this.navBarGroupControlContainer11.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer11.TabIndex = 10;
            // 
            // navBarGroupControlContainer12
            // 
            this.navBarGroupControlContainer12.Name = "navBarGroupControlContainer12";
            this.navBarGroupControlContainer12.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer12.TabIndex = 11;
            // 
            // navBarGroupControlContainer13
            // 
            this.navBarGroupControlContainer13.Name = "navBarGroupControlContainer13";
            this.navBarGroupControlContainer13.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer13.TabIndex = 12;
            // 
            // navBarGroupControlContainer14
            // 
            this.navBarGroupControlContainer14.Name = "navBarGroupControlContainer14";
            this.navBarGroupControlContainer14.Size = new System.Drawing.Size(227, 76);
            this.navBarGroupControlContainer14.TabIndex = 13;
            // 
            // navBarGroupControlContainer2
            // 
            this.navBarGroupControlContainer2.Controls.Add(this.labelControl4);
            this.navBarGroupControlContainer2.Controls.Add(this.btnApply_LegendColor);
            this.navBarGroupControlContainer2.Controls.Add(this.comboBox_LegendColor);
            this.navBarGroupControlContainer2.Name = "navBarGroupControlContainer2";
            this.navBarGroupControlContainer2.Size = new System.Drawing.Size(211, 100);
            this.navBarGroupControlContainer2.TabIndex = 14;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Location = new System.Drawing.Point(69, 12);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(128, 16);
            this.labelControl4.TabIndex = 5;
            this.labelControl4.Text = "Select Legend Color";
            // 
            // btnApply_LegendColor
            // 
            this.btnApply_LegendColor.Location = new System.Drawing.Point(110, 70);
            this.btnApply_LegendColor.Name = "btnApply_LegendColor";
            this.btnApply_LegendColor.Size = new System.Drawing.Size(75, 23);
            this.btnApply_LegendColor.TabIndex = 4;
            this.btnApply_LegendColor.Text = "Apply";
            this.btnApply_LegendColor.Click += new System.EventHandler(this.btnApply_LegendColor_Click);
            // 
            // comboBox_LegendColor
            // 
            this.comboBox_LegendColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_LegendColor.FormattingEnabled = true;
            this.comboBox_LegendColor.Location = new System.Drawing.Point(37, 37);
            this.comboBox_LegendColor.Name = "comboBox_LegendColor";
            this.comboBox_LegendColor.Size = new System.Drawing.Size(148, 21);
            this.comboBox_LegendColor.TabIndex = 4;
            // 
            // navBarGroup_Legend
            // 
            this.navBarGroup_Legend.Caption = "Legend";
            this.navBarGroup_Legend.ControlContainer = this.navBarGroupControlContainer2;
            this.navBarGroup_Legend.GroupClientHeight = 104;
            this.navBarGroup_Legend.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup_Legend.Name = "navBarGroup_Legend";
            this.navBarGroup_Legend.SmallImageIndex = 8;
            // 
            // navBarGroup_Titles
            // 
            this.navBarGroup_Titles.Caption = "Titles";
            this.navBarGroup_Titles.ControlContainer = this.navBarGroupControlContainer3;
            this.navBarGroup_Titles.GroupClientHeight = 213;
            this.navBarGroup_Titles.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup_Titles.Name = "navBarGroup_Titles";
            this.navBarGroup_Titles.SmallImageIndex = 9;
            // 
            // navBarGroup4
            // 
            this.navBarGroup4.Caption = "Axis";
            this.navBarGroup4.ControlContainer = this.navBarGroupControlContainer4;
            this.navBarGroup4.GroupClientHeight = 80;
            this.navBarGroup4.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup4.Name = "navBarGroup4";
            this.navBarGroup4.Visible = false;
            // 
            // navBarGroup5
            // 
            this.navBarGroup5.Caption = "Tool Tips";
            this.navBarGroup5.ControlContainer = this.navBarGroupControlContainer5;
            this.navBarGroup5.GroupClientHeight = 80;
            this.navBarGroup5.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup5.Name = "navBarGroup5";
            this.navBarGroup5.Visible = false;
            // 
            // navBarGroup6
            // 
            this.navBarGroup6.Caption = "Standard Effects";
            this.navBarGroup6.ControlContainer = this.navBarGroupControlContainer6;
            this.navBarGroup6.GroupClientHeight = 80;
            this.navBarGroup6.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup6.Name = "navBarGroup6";
            this.navBarGroup6.Visible = false;
            // 
            // navBarGroup7
            // 
            this.navBarGroup7.Caption = "Custonize";
            this.navBarGroup7.ControlContainer = this.navBarGroupControlContainer7;
            this.navBarGroup7.GroupClientHeight = 80;
            this.navBarGroup7.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup7.Name = "navBarGroup7";
            this.navBarGroup7.Visible = false;
            // 
            // navBarGroup8
            // 
            this.navBarGroup8.Caption = "Additional Labels";
            this.navBarGroup8.ControlContainer = this.navBarGroupControlContainer8;
            this.navBarGroup8.GroupClientHeight = 80;
            this.navBarGroup8.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup8.Name = "navBarGroup8";
            this.navBarGroup8.Visible = false;
            // 
            // navBarGroup9
            // 
            this.navBarGroup9.Caption = "Color Model";
            this.navBarGroup9.ControlContainer = this.navBarGroupControlContainer9;
            this.navBarGroup9.GroupClientHeight = 80;
            this.navBarGroup9.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup9.Name = "navBarGroup9";
            this.navBarGroup9.Visible = false;
            // 
            // navBarGroup10
            // 
            this.navBarGroup10.Caption = "Axis Settings";
            this.navBarGroup10.ControlContainer = this.navBarGroupControlContainer10;
            this.navBarGroup10.GroupClientHeight = 80;
            this.navBarGroup10.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup10.Name = "navBarGroup10";
            this.navBarGroup10.Visible = false;
            // 
            // navBarGroup11
            // 
            this.navBarGroup11.Caption = "Minimun/Maximun Axis Range";
            this.navBarGroup11.ControlContainer = this.navBarGroupControlContainer11;
            this.navBarGroup11.GroupClientHeight = 80;
            this.navBarGroup11.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup11.Name = "navBarGroup11";
            this.navBarGroup11.Visible = false;
            // 
            // navBarGroup12
            // 
            this.navBarGroup12.Caption = "Label Rotation";
            this.navBarGroup12.ControlContainer = this.navBarGroupControlContainer12;
            this.navBarGroup12.GroupClientHeight = 80;
            this.navBarGroup12.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup12.Name = "navBarGroup12";
            this.navBarGroup12.Visible = false;
            // 
            // navBarGroup13
            // 
            this.navBarGroup13.Caption = "Numeric Axis";
            this.navBarGroup13.ControlContainer = this.navBarGroupControlContainer13;
            this.navBarGroup13.GroupClientHeight = 80;
            this.navBarGroup13.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup13.Name = "navBarGroup13";
            this.navBarGroup13.Visible = false;
            // 
            // navBarGroup14
            // 
            this.navBarGroup14.Caption = "other Percentage";
            this.navBarGroup14.ControlContainer = this.navBarGroupControlContainer14;
            this.navBarGroup14.GroupClientHeight = 80;
            this.navBarGroup14.GroupStyle = DevExpress.XtraNavBar.NavBarGroupStyle.ControlContainer;
            this.navBarGroup14.Name = "navBarGroup14";
            this.navBarGroup14.Visible = false;
            // 
            // largeImageCollection
            // 
            this.largeImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("largeImageCollection.ImageStream")));
            // 
            // smallImageCollection
            // 
            this.smallImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("smallImageCollection.ImageStream")));
            // 
            // hideContainerBottom
            // 
            this.hideContainerBottom.Controls.Add(this.dockPanel_ChartData);
            this.hideContainerBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.hideContainerBottom.Location = new System.Drawing.Point(19, 461);
            this.hideContainerBottom.Name = "hideContainerBottom";
            this.hideContainerBottom.Size = new System.Drawing.Size(921, 19);
            // 
            // dockPanel_ChartData
            // 
            this.dockPanel_ChartData.Controls.Add(this.dockPanel3_Container);
            this.dockPanel_ChartData.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.dockPanel_ChartData.ID = new System.Guid("005a51fd-73f5-435e-89e5-1e5fce613ea5");
            this.dockPanel_ChartData.Location = new System.Drawing.Point(0, 0);
            this.dockPanel_ChartData.Name = "dockPanel_ChartData";
            this.dockPanel_ChartData.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.dockPanel_ChartData.SavedIndex = 0;
            this.dockPanel_ChartData.Size = new System.Drawing.Size(921, 196);
            this.dockPanel_ChartData.Text = "Chart Data";
            this.dockPanel_ChartData.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            this.dockPanel_ChartData.VisibilityChanged += new DevExpress.XtraBars.Docking.VisibilityChangedEventHandler(this.dockPanel_ChartData_VisibilityChanged);
            // 
            // dockPanel3_Container
            // 
            this.dockPanel3_Container.Controls.Add(this.gridControl_ChartData);
            this.dockPanel3_Container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanel3_Container.Location = new System.Drawing.Point(0, 0);
            this.dockPanel3_Container.Name = "dockPanel3_Container";
            this.dockPanel3_Container.Size = new System.Drawing.Size(921, 196);
            this.dockPanel3_Container.TabIndex = 0;
            // 
            // gridControl_ChartData
            // 
            this.gridControl_ChartData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl_ChartData.EmbeddedNavigator.Name = "";
            this.gridControl_ChartData.Location = new System.Drawing.Point(0, 0);
            this.gridControl_ChartData.MainView = this.gridViewChartData;
            this.gridControl_ChartData.Name = "gridControl_ChartData";
            this.gridControl_ChartData.Size = new System.Drawing.Size(921, 196);
            this.gridControl_ChartData.TabIndex = 0;
            this.gridControl_ChartData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewChartData,
            this.gridView2});
            // 
            // gridViewChartData
            // 
            this.gridViewChartData.GridControl = this.gridControl_ChartData;
            this.gridViewChartData.Name = "gridViewChartData";
            this.gridViewChartData.OptionsView.ShowGroupPanel = false;
            // 
            // gridView2
            // 
            this.gridView2.GridControl = this.gridControl_ChartData;
            this.gridView2.Name = "gridView2";
            // 
            // dockPanel_Comments
            // 
            this.dockPanel_Comments.Controls.Add(this.dockPanel4_Container);
            this.dockPanel_Comments.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel_Comments.FloatVertical = true;
            this.dockPanel_Comments.ID = new System.Guid("546490ee-4d7e-4936-b885-5a2b4694758d");
            this.dockPanel_Comments.Location = new System.Drawing.Point(3, 25);
            this.dockPanel_Comments.Name = "dockPanel_Comments";
            this.dockPanel_Comments.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel_Comments.SavedIndex = 1;
            this.dockPanel_Comments.SavedParent = this.dockPanel_ChartData;
            this.dockPanel_Comments.SavedTabbed = true;
            this.dockPanel_Comments.Size = new System.Drawing.Size(673, 147);
            this.dockPanel_Comments.Text = "Comments";
            this.dockPanel_Comments.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // dockPanel4_Container
            // 
            this.dockPanel4_Container.Controls.Add(this.listView_Comments);
            this.dockPanel4_Container.Location = new System.Drawing.Point(0, 0);
            this.dockPanel4_Container.Name = "dockPanel4_Container";
            this.dockPanel4_Container.Size = new System.Drawing.Size(673, 147);
            this.dockPanel4_Container.TabIndex = 0;
            // 
            // listView_Comments
            // 
            this.listView_Comments.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView_Comments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_Comments.GridLines = true;
            this.listView_Comments.Location = new System.Drawing.Point(0, 0);
            this.listView_Comments.Name = "listView_Comments";
            this.listView_Comments.Size = new System.Drawing.Size(673, 147);
            this.listView_Comments.TabIndex = 0;
            this.listView_Comments.UseCompatibleStateImageBehavior = false;
            this.listView_Comments.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Serial No";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Comments";
            this.columnHeader2.Width = 370;
            // 
            // dockPanel_Summary
            // 
            this.dockPanel_Summary.Controls.Add(this.dockPanel5_Container);
            this.dockPanel_Summary.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel_Summary.ID = new System.Guid("50cda021-bf07-48e1-88a7-9776227e73ba");
            this.dockPanel_Summary.Location = new System.Drawing.Point(3, 25);
            this.dockPanel_Summary.Name = "dockPanel_Summary";
            this.dockPanel_Summary.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.dockPanel_Summary.SavedIndex = 1;
            this.dockPanel_Summary.SavedParent = this.dockPanel_ChartData;
            this.dockPanel_Summary.SavedTabbed = true;
            this.dockPanel_Summary.Size = new System.Drawing.Size(673, 147);
            this.dockPanel_Summary.Text = "Summary";
            this.dockPanel_Summary.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // dockPanel5_Container
            // 
            this.dockPanel5_Container.Controls.Add(this.listView_Summary);
            this.dockPanel5_Container.Location = new System.Drawing.Point(0, 0);
            this.dockPanel5_Container.Name = "dockPanel5_Container";
            this.dockPanel5_Container.Size = new System.Drawing.Size(673, 147);
            this.dockPanel5_Container.TabIndex = 0;
            // 
            // listView_Summary
            // 
            this.listView_Summary.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.listView_Summary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_Summary.GridLines = true;
            this.listView_Summary.Location = new System.Drawing.Point(0, 0);
            this.listView_Summary.Name = "listView_Summary";
            this.listView_Summary.Size = new System.Drawing.Size(673, 147);
            this.listView_Summary.TabIndex = 7;
            this.listView_Summary.UseCompatibleStateImageBehavior = false;
            this.listView_Summary.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Serial No";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Summary";
            this.columnHeader4.Width = 365;
            // 
            // dockPanel_ChartType
            // 
            this.dockPanel_ChartType.Controls.Add(this.dockPanel2_Container);
            this.dockPanel_ChartType.Dock = DevExpress.XtraBars.Docking.DockingStyle.Top;
            this.dockPanel_ChartType.FloatVertical = true;
            this.dockPanel_ChartType.ID = new System.Guid("7397ac1e-5ce2-42a3-b80e-58e73ceb74d1");
            this.dockPanel_ChartType.Location = new System.Drawing.Point(19, 51);
            this.dockPanel_ChartType.Name = "dockPanel_ChartType";
            this.dockPanel_ChartType.Size = new System.Drawing.Size(921, 236);
            this.dockPanel_ChartType.Text = "Chart Type :: Bar";
            // 
            // dockPanel2_Container
            // 
            this.dockPanel2_Container.Controls.Add(this.dadosChartControl_Chart);
            this.dockPanel2_Container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanel2_Container.Location = new System.Drawing.Point(3, 25);
            this.dockPanel2_Container.Name = "dockPanel2_Container";
            this.dockPanel2_Container.Size = new System.Drawing.Size(915, 208);
            this.dockPanel2_Container.TabIndex = 0;
            // 
            // dadosChartControl_Chart
            // 
            this.dadosChartControl_Chart.AppearenceName = "Nature Colors";
            this.dadosChartControl_Chart.ChartAxisXStaggered = true;
            this.dadosChartControl_Chart.ChartAxisXThickness = 1;
            this.dadosChartControl_Chart.ChartAxisXTitle = "Axis of arguments";
            this.dadosChartControl_Chart.ChartAxisXVisiblity = true;
            this.dadosChartControl_Chart.ChartAxisYStaggered = false;
            this.dadosChartControl_Chart.ChartAxisYThickness = 1;
            this.dadosChartControl_Chart.ChartAxisYTitle = "Axis of values";
            this.dadosChartControl_Chart.ChartAxisYVisiblity = true;
            this.dadosChartControl_Chart.ChartTitle = "Chart Title";
            this.dadosChartControl_Chart.ChartTitleAlienment = "Center";
            this.dadosChartControl_Chart.ChartTitleLocation = "Top";
            this.dadosChartControl_Chart.ChartType = "Bar";
            this.dadosChartControl_Chart.DataValues = null;
            this.dadosChartControl_Chart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dadosChartControl_Chart.LegendHAlienment = "RightOutside";
            this.dadosChartControl_Chart.LegendVAlienment = "Top";
            this.dadosChartControl_Chart.LegendVisiblity = true;
            this.dadosChartControl_Chart.Location = new System.Drawing.Point(0, 0);
            this.dadosChartControl_Chart.Name = "dadosChartControl_Chart";
            this.dadosChartControl_Chart.Size = new System.Drawing.Size(915, 208);
            this.dadosChartControl_Chart.TabIndex = 1;
            // 
            // comboBoxEdit2
            // 
            this.comboBoxEdit2.Location = new System.Drawing.Point(731, 31);
            this.comboBoxEdit2.Name = "comboBoxEdit2";
            this.comboBoxEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit2.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.comboBoxEdit2.Size = new System.Drawing.Size(100, 20);
            this.comboBoxEdit2.TabIndex = 34;
            this.comboBoxEdit2.Visible = false;
            // 
            // listBoxTheme
            // 
            this.listBoxTheme.Location = new System.Drawing.Point(605, 31);
            this.listBoxTheme.Name = "listBoxTheme";
            this.listBoxTheme.Size = new System.Drawing.Size(120, 18);
            this.listBoxTheme.TabIndex = 33;
            this.listBoxTheme.Visible = false;
            // 
            // ChartsMain
            // 
            this.ClientSize = new System.Drawing.Size(940, 505);
            this.Controls.Add(this.comboBoxEdit2);
            this.Controls.Add(this.listBoxTheme);
            this.Controls.Add(this.dockPanel_ChartType);
            this.Controls.Add(this.hideContainerBottom);
            this.Controls.Add(this.hideContainerLeft);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChartsMain";
            this.Text = "ChartsMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ChartsMain_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChartsMain_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.barManager_DadosReports)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager_DadosReports)).EndInit();
            this.hideContainerLeft.ResumeLayout(false);
            this.dockPanel_ChartOptions.ResumeLayout(false);
            this.dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl_ChartOptions)).EndInit();
            this.navBarControl_ChartOptions.ResumeLayout(false);
            this.navBarGroupControlContainer1.ResumeLayout(false);
            this.navBarGroupControlContainer1.PerformLayout();
            this.navBarGroupControlContainer3.ResumeLayout(false);
            this.navBarGroupControlContainer3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChartTitle.Properties)).EndInit();
            this.navBarGroupControlContainer2.ResumeLayout(false);
            this.navBarGroupControlContainer2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.largeImageCollection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smallImageCollection)).EndInit();
            this.hideContainerBottom.ResumeLayout(false);
            this.dockPanel_ChartData.ResumeLayout(false);
            this.dockPanel3_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl_ChartData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewChartData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.dockPanel_Comments.ResumeLayout(false);
            this.dockPanel4_Container.ResumeLayout(false);
            this.dockPanel_Summary.ResumeLayout(false);
            this.dockPanel5_Container.ResumeLayout(false);
            this.dockPanel_ChartType.ResumeLayout(false);
            this.dockPanel2_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.listBoxTheme)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.BarManager barManager_DadosReports;
        private DevExpress.XtraBars.Bar bar1;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.Bar bar3;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.Docking.DockManager dockManager_DadosReports;
        private DevExpress.Utils.ImageCollection smallImageCollection;
        private DevExpress.Utils.ImageCollection largeImageCollection;
        private DevExpress.XtraBars.BarSubItem barSubItem1_File;
        private DevExpress.XtraBars.BarSubItem barSubItem2_View;
        private DevExpress.XtraBars.BarSubItem barSubItem3_Options;
        private DevExpress.XtraBars.BarSubItem barSubItem4_Customize;
        private DevExpress.XtraBars.BarSubItem barSubItem5_Toggle;
        private DevExpress.XtraBars.BarSubItem barSubItem6_Skin;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Print;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_PrintPreview;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Exit;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel_ChartOptions;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraNavBar.NavBarControl navBarControl_ChartOptions;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup_ChartType;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer1;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup_Legend;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup_Titles;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup4;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup5;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup6;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup7;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer3;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer4;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer5;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer6;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer7;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer8;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer9;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer10;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer11;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup8;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup9;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup10;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup11;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup12;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup13;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup14;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer12;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer13;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer14;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_ShowLedgend;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_Show3DEffects;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_ShowScrollBar;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_ShowXAxis;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_ShowYAxis;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_ShowToolTip;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_EnableCrossHair;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_SwapRowAndColumn;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_HideChartOptions;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_HideChart;
        private DevExpress.XtraBars.BarCheckItem barCheckItem_HideChartData;
        private DevExpress.XtraBars.BarSubItem barSubItem_Email;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_PDF;
        private DevExpress.XtraBars.BarSubItem barSubItem_Export;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ExportToHtml;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ExportToPDF;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_CreateDrillDown;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_CreateCalculatedFields;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_TopOrBottomValue;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ConditionalRunTimeFields;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_DataField;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ChangeMainField;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ToggleToCute;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ToggleToView;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ToggleToAdvanceView;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Format1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Format2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Format3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Format4;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel_ChartData;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel3_Container;
        private DevExpress.XtraEditors.SimpleButton btnApply_ChartType;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel_Summary;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel5_Container;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel_Comments;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel4_Container;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel_ChartType;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel2_Container;
        private System.Windows.Forms.ListView listView_Comments;
        private DevExpress.XtraGrid.GridControl gridControl_ChartData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewChartData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private System.Windows.Forms.ListView listView_Summary;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ChartOptions;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ChartData;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Summary;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Comments;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ViewChart;
        public DevExpress.XtraBars.BarCheckItem barCheckItem_ShowTitle;
        private DevExpress.XtraBars.BarSubItem barSubItem_Image;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Bmp;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Jpeg;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Gif;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_Icon;
        private System.Windows.Forms.ComboBox comboBox_ChartType;
        private DevExpress.XtraNavBar.NavBarGroupControlContainer navBarGroupControlContainer2;
        private DevExpress.XtraEditors.SimpleButton btnApply_LegendColor;
        private System.Windows.Forms.ComboBox comboBox_LegendColor;
        private DadosChartControl.DadosChartControl dadosChartControl_Chart;
        private DevExpress.XtraBars.BarSubItem barSubItem_print;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_printChart;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_printGridData;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_printBoth;
        private DevExpress.XtraBars.BarSubItem barSubItem_PrintPreview;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_PrintPreviewChart;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_PrintPreviewGridData;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_PrintPreviewBoth;
        private DevExpress.XtraEditors.ColorEdit colorEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtChartTitle;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private System.Windows.Forms.FontDialog fontDialog1;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit2;
        private DevExpress.XtraEditors.ListBoxControl listBoxTheme;
        private DevExpress.XtraEditors.SimpleButton simpleButton_ChangeTitle;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraBars.Docking.AutoHideContainer hideContainerLeft;
        private DevExpress.XtraBars.Docking.AutoHideContainer hideContainerBottom;
        private DevExpress.XtraBars.BarStaticItem StatusBar_barStaticItem;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;

    }
}