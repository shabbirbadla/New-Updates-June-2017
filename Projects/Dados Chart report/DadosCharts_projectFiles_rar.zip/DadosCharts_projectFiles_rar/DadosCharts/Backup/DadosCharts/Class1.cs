using System;
using System.Collections.Generic;
using System.Text;
using DevExpress.XtraCharts;

namespace DadosCharts
{
    public class Class1
    {   
       
    }
}
