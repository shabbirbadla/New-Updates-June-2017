using System;
using System.Collections.Generic;
using System.Text;
using Charts.DAL;
using Charts.DAL.Interfaces;




namespace Charts.DAL
{
    public class Common : ICommon
    {
       
    }
}
