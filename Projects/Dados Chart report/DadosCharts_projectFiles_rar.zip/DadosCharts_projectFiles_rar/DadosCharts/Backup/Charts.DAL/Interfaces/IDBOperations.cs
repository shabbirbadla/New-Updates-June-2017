﻿using System;
namespace Charts.DAL.Interfaces
{
    public interface IDBOperations
    {
        string ConnString { get; set; }
        string ReportID { get; set; }
        string ChartsQuarry { get;set;}
        string stringArguments { get;set; }
        string numaricArguments { get;set; }
        string datetimeArguments { get;set; }
    }
}
