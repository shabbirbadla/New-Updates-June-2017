using System;
using System.Collections.Generic;
using System.Text;
using System.Data;


namespace Charts.DAL
{
    public class DBOperations : Charts.DAL.Interfaces.IDBOperations//, Charts.DAL.IDBOperations
    {
        #region Member veriables

        DBConnections objConnection;
        private string mReportID = string.Empty;
        private string mConnString = string.Empty;
        private DataSet mOperationsDS = new DataSet();
        private string mDBError = string.Empty;
        private string mChartsQuarry = string.Empty;
        private string mstringArguments = null;
        private string mnumaricArguments = null;
        private string mdatetimeArguments = null;

        private string[] ChartstringArguments = null;
        private string[] ChartnumaricArguments = null;
        private string[] ChartdatetimeArguments = null;

        #endregion
        #region Constractor
        /// <summary>
        /// Constractor
        /// </summary>
        public DBOperations()
        {
            objConnection = new DBConnections();
        }
        #endregion
        #region Public Properties

        /// <summary>
        /// Get or Set Report ID 
        /// </summary>
        public string ReportID
        {
            get { return mReportID; }
            set { mReportID = value; }
        }
        /// <summary>
        /// Get or Set Connection String Of The Reports 
        /// </summary>
        public string ConnString
        {
            get { return mConnString; }
            set { mConnString = value; }
        }
        /// <summary>
        /// get or set string arguments to pass the quarry
        /// </summary>
        public string stringArguments
        {
            get
            {
                return mstringArguments;
            }
            set
            {
                mstringArguments = value;
            }
        }
        /// <summary>
        /// get or set numaric arguments to pass the quarry
        /// </summary>
        public string numaricArguments
        {
            get
            {
                return mnumaricArguments;
            }
            set
            {
                mnumaricArguments = value;
            }
        }
        /// <summary>
        /// get or set datetime arguments to pass the quarry
        /// </summary>
        public string datetimeArguments
        {
            get
            {
                return mdatetimeArguments;
            }
            set
            {
                mdatetimeArguments = value;
            }
        }
        /// <summary>
        /// Get or Set DataSet
        /// </summary>
        public DataSet OperationsDS
        {
            get { return mOperationsDS; }
            set { mOperationsDS = value; }
        }
        /// <summary>
        /// Get the DB Error
        /// </summary>
        public string DBError
        {
            get { return mDBError; }
        }
        /// <summary>
        /// To Get or Set Charts Quarry
        /// </summary>
        public string ChartsQuarry
        {
            get
            {
                return mChartsQuarry;
            }
            set
            {
                mChartsQuarry = value;
            }
        }

        #endregion
        #region Public Methods

        /// <summary>
        /// Get The Chart Qurry Based on the Report ID.
        /// </summary>
        /// <returns>DatSet</returns>
        public DataSet GetChartQuarry(DAL.Interfaces.IDBOperations ObjIDBOperations)
        {
            objConnection.AppConnectionString = ObjIDBOperations.ConnString;
            objConnection.CommandTypeToExecute = CommandType.Text;
            objConnection.CommandText = "Select Usrep.RepID as [ReportID],Usrep.Repnm as [ReportName],Usrep.repty as [ReportType],Usqry.QryID as [QurryID],Usqry.RepLvlID as [ReportLevelID],Usqry.RepQry as [ReportQurry], UsLty.Lvlty as [ReportLevelType], UsLty.lvltid as [ReportLevelTypeID] from Usrep Inner Join Usqry On (Usrep.Repid=Usqry.repid) Inner Join Usrlv on (Usrlv.QryId=Usqry.Qryid) Inner Join Uslty on (Uslty.lvltid=Usrlv.lvltyp)  Where Usrep.Repid='" + ReportID + "'";

            objConnection.ClearParameters();
            OperationsDS = new DataSet();
            try
            {
                OperationsDS = objConnection.GetDataSet("ReportDetails");
                if (OperationsDS.Tables.Count > 0)
                {
                    if (OperationsDS.Tables["ReportDetails"].Rows.Count > 0)
                    {
                        return OperationsDS;
                    }
                    else
                    {
                        mDBError = "Error To Retrive The Data";
                        return OperationsDS = new DataSet();
                    }
                }
                else
                {
                    mDBError = "Error To Retrive The Data";
                    return OperationsDS = new DataSet();
                }
            }
            catch (Exception ex)
            {
                mDBError = ex.Message;
            }

            return OperationsDS;
        }
        public DataSet GetChartReportData(DAL.Interfaces.IDBOperations ObjIDBOperations)
        {
            objConnection.AppConnectionString = ObjIDBOperations.ConnString;
            objConnection.CommandTypeToExecute = CommandType.Text;
            objConnection.ClearParameters();
            if (stringArguments != "" && stringArguments != " ")
            {
                ChartstringArguments = spiltArguments(stringArguments);
                for (int i = 0; i < (ChartstringArguments.Length); i++)
                {
                    objConnection.AddParameter("@" + ChartstringArguments[i].ToString(), ChartstringArguments[i + 1].ToString());
                    i = i + 1;
                }
            }
            if (numaricArguments != "" && numaricArguments != " ")
            {
                ChartnumaricArguments = spiltArguments(numaricArguments);
                for (int i = 0; i < (ChartnumaricArguments.Length); i++)
                {
                    objConnection.AddParameter("@" + ChartnumaricArguments[i].ToString(), ChartnumaricArguments[i + 1].ToString());
                    i = i + 1;
                }
            }
            if (datetimeArguments != "" && datetimeArguments != " ")
            {
                ChartdatetimeArguments = spiltArguments(datetimeArguments);
                for (int i = 0; i < (ChartdatetimeArguments.Length); i++)
                {
                    objConnection.AddParameter("@" + ChartdatetimeArguments[i].ToString(), ChartdatetimeArguments[i + 1].ToString());
                    i = i + 1;
                }
            }
            objConnection.CommandText = ObjIDBOperations.ChartsQuarry;           
            OperationsDS = new DataSet();
            try
            {
                OperationsDS = objConnection.GetDataSet("ChartsData");
                if (OperationsDS.Tables.Count > 0)
                {
                    if (OperationsDS.Tables["ChartsData"].Rows.Count > 0)
                    {
                        return OperationsDS;
                    }
                    else
                    {
                        mDBError = "Error To Retrive The Data";
                        return OperationsDS = new DataSet();
                    }
                }
                else
                {
                    mDBError = "Error To Retrive The Data";
                    return OperationsDS = new DataSet();
                }
            }
            catch (Exception ex)
            {
                mDBError = ex.Message;
            }

            return OperationsDS;
        }
        #endregion
        #region Private Methods
        #region Spliting the Query Arguments
        /// <summary>
        /// spiting the arguments([,],=,|)
        /// </summary>
        /// <author>Jayakumar Budha</author>
        /// <param name="Value">string</param>
        /// <returns>array of string</returns>
        private string[] spiltArguments(string Value)
        {
            Value = Value.Replace("][", "|");
            Value = Value.Replace("[", "");
            Value = Value.Replace("]", "");
            Value = Value.Replace("=", "|");


            return Value.Split(new char[] { '|' });

        }
        #endregion
        #endregion
    }
}
