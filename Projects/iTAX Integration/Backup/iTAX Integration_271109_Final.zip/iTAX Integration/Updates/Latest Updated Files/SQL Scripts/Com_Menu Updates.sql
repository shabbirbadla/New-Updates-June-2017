/*
Delete From Com_Menu Where Barname = 'ERPIntegration'
Delete From Com_Menu Where Padname = 'ERPIntegration'
*/

if not exists (select [range] from com_menu where barname = 'ERPIntegration')
begin
	insert into com_menu ([range],padname,padnum,barname,barnum,prompname,numitem,hotkey,progname,menutype,puser)
		values (90000,'_MSYSMENU',26,'ERPIntegration',0,'ERP Integration',5,'','','General','iTAX')
end
Go
if not exists (select [range] from com_menu where barname = 'Interface' And padname = 'ERPIntegration')
begin
	insert into com_menu ([range],padname,padnum,barname,barnum,prompname,numitem,hotkey,progname,menutype,puser)
		values (90001,'ERPIntegration',0,'Interface',1,'Interface',0,'','DO XMLINTERFACE.APP WITH "X", "^90001"','Transaction','iTAX')
end
Go
if not exists (select [range] from com_menu where barname = 'ERPUdyogiTaxMapping' And padname = 'ERPIntegration')
begin
	insert into com_menu ([range],padname,padnum,barname,barnum,prompname,numitem,hotkey,progname,menutype,puser)
		values (90002,'ERPIntegration',0,'ERPUdyogiTaxMapping',3,'ERP Udyog iTax Mapping',0,'','DO XMLINTERFACE.APP WITH "M", "^90002"','Transaction','iTAX')
end
Go
if not exists (select [range] from com_menu where barname = 'FileSettings' And padname = 'ERPIntegration')
begin
	insert into com_menu ([range],padname,padnum,barname,barnum,prompname,numitem,hotkey,progname,menutype,puser)
		values (90003,'ERPIntegration',0,'FileSettings',4,'File Settings',0,'','DO XMLINTERFACE WITH "S", "^90003"','Transaction','iTAX')
end
Go
if not exists (select [range] from com_menu where barname = 'CreateModifyFileStructure' And padname = 'ERPIntegration')
begin
	insert into com_menu ([range],padname,padnum,barname,barnum,prompname,numitem,hotkey,progname,menutype,puser)
		values (90004,'ERPIntegration',0,'CreateModifyFileStructure',2,'Middleware Structural Update',0,'','DO XMLINTERFACE WITH "C", "^90004"','Transaction','iTAX')
end

/*Go
if not exists (select [range] from com_menu where barname = 'Xmlsettings' And padname = 'ERPIntegration')
begin
	insert into com_menu ([range],padname,padnum,barname,barnum,prompname,numitem,hotkey,progname,menutype,puser)
		values (90005,'ERPIntegration',0,'Xmlsettings',4,'Xml Settings',0,'','DO Ui2_Sysmaster WITH "SYSTEM", "^90005"','Transaction','iTAX')
end
Go
*/