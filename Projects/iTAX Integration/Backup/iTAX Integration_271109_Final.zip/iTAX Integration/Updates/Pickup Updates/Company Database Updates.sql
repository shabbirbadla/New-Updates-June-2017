If Not Exists (Select [Name] From Syscolumns Where [Name] = 'isApproval' And id = Object_Id('Ui2_Settings'))
Begin 
	Alter Table Ui2_Settings Add isApproval Bit
End
Go 
Update Ui2_Settings Set isApproval = 0 Where isApproval Is Null
Go 
If Not Exists (Select [Name] From Syscolumns Where [Name] = 'is1stMap' And id = Object_Id('Ui2_Settings'))
Begin 
	Alter Table Ui2_Settings Add is1stMap Bit
End
Go 
Update Ui2_Settings Set is1stMap = 0 Where is1stMap Is Null
Go 
If Not Exists(Select [Name] From Sysobjects Where xType = 'U' AND [Name] = 'Ui2_Erp_iTAX_1stMap')
BEGIN
CREATE TABLE [Ui2_Erp_iTAX_1stMap](
	[XmlFilenm] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Erphdrtag] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Ui2_Hdrtag] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Erpfldtag] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Ui2_fldtag] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
END
Go
If Not Exists(Select [Name] From Syscolumns Where [Name] = 'Picktrans' And Object_Name(Id) = 'Ui2_Settings')
Begin
	Alter Table Ui2_Settings Add Picktrans Varchar(2)
End
Go 