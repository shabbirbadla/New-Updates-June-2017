﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Sdk;
using Microsoft.SqlServer.Server;

namespace ExportScript
{
    public partial class frmDataCompare : Form
    {
        string connStr;
        SqlConnection cn;
        SqlDataAdapter da;
        DataSet ds=new DataSet();
        private string _Uid;
        private string _Pwd;
        private string _Dbname;
        public frmDataCompare(string serverName,string user, string pass)
        {
            InitializeComponent();
            connStr = "Data Source="+serverName+";Initial Catalog=Master;Uid="+user+";Pwd="+pass;
            //connStr = "Data Source=Udyog9\\SQLEXPRESS;Initial Catalog=Master;Uid=sa;Pwd=sa1985";
            cn = new SqlConnection(connStr);
            _Uid = user;
            _Pwd = pass;
        }

       
        private void frmExportScript_Load(object sender, EventArgs e)
        {
            GetDatabases();
        }
        public void GetDatabases()
        {
            SqlCommand cmd;
            OpenConnection();
            cmd = new SqlCommand("Select [Name] as DB From SysDatabases Where [Name] Not In ('Master','TempDB','Model','MSDB') Order by [Name]", cn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cboDatabase.Items.Add(dr[0].ToString());
                cboStdDatabase.Items.Add(dr[0].ToString());
            }
            dr.Close();
            cn.Close();
        }
        public SqlConnection OpenConnection()
        {
            if (cn == null)
            {
                try
                {
                    cn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while opening connection :" + ex.Message);
                }
            }
            else
            {
                if (cn.State == ConnectionState.Closed)
                {
                    try
                    {
                        cn.Open();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while opening connection :" + ex.Message);
                    }
                }
            }
            return cn;
        }

        public void GenerateStructureScript(string SrcDb, string TargetDb, string tblNm)
        {
            string strText=string.Empty;
            da = new SqlDataAdapter("Use " + SrcDb + " Execute Usp_Ent_Gen_Script '" + SrcDb + "','" + TargetDb + "','" + tblNm + "'", cn);
            da.Fill(ds,tblNm+"_vw");
            for (int i = 0; i < ds.Tables[tblNm+"_vw"].Rows.Count; i++)
			{
			    strText=strText+ ds.Tables[tblNm+"_vw"].Rows[i]["Query"].ToString();
			}
            WriteScriptToFile("01_Struture_script",strText+ "| ");
        }
        public void GenerateRecordScript(string SrcDb, string TargetDb, string tblNm, string keyflds, string excludeflds)
        {
            DataTable srcTable, targetTable;
            string strText=string.Empty;
            string[] arrItem = keyflds.Split(',');
            bool exists;
            int counter;
            srcTable = GetDataTable(SrcDb, tblNm);
            targetTable = GetDataTable(TargetDb, tblNm);
            
            for (int i = 0; i < srcTable.Rows.Count; i++)
            {
                exists = false;
                for (int j = 0; j < targetTable.Rows.Count; j++)
                {
                    counter = 0;
                    foreach (string arr in arrItem)
                    {
                        if (srcTable.Rows[i][arr].ToString().ToUpper().Trim() == targetTable.Rows[j][arr].ToString().ToUpper().Trim() )
                        {
                            counter++;
                        }
                    }
                    if (counter==arrItem.Length)
                    {
                        exists = true;
                        strText = GetUpdateString(srcTable, targetTable, srcTable.Rows[i], targetTable.Rows[j], tblNm, keyflds, excludeflds);
                        WriteScriptToFile("01_Struture_script", (strText == "" ? "" : strText + "| "));
                        break;
                    }
                }
                if (exists==false)
                {
                    strText = GetInsertString(srcTable, srcTable.Rows[i], tblNm, keyflds)+"|";
                    WriteScriptToFile("01_Struture_script", (strText == "" ? "" : strText + "| "));
                }
            }
            
        }
        public string GetUpdateString(DataTable srcDt, DataTable targetDt, DataRow srcRow, DataRow targetRow, string tblNm, string keyflds,string excludeflds)
        {
            string retStr = string.Empty;
            string[] arrItem = keyflds.Split(',');
            string[] exclude=excludeflds.Split(',');
            bool exists=true;
            retStr = "Update " + tblNm + " Set ";
            for (int i = 0; i < srcDt.Columns.Count; i++)
            {
                try
                {
                    if (targetRow[srcDt.Columns[i].ColumnName] != null)
                {
                    if (!Inlist(srcDt.Columns[i].ColumnName, exclude))
                    {
                        if (srcRow[srcDt.Columns[i].ColumnName].ToString() != targetRow[srcDt.Columns[i].ColumnName].ToString())
                        {
                            exists = false;
                            switch (srcRow[srcDt.Columns[i].ColumnName].GetType().ToString())
                            {
                                case "System.Int16":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt16(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                    break;
                                case "System.Int32":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt32(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                    break;
                                case "System.Int64":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt64(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                    break;
                                case "System.Double":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDouble(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                    break;
                                case "System.Decimal":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDecimal(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                    break;
                                case "System.String":
                                case "System.DBNull":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToString(srcRow[i].ToString() == null ? "" : srcRow[i].ToString().Replace("'", "''")).ToString().Trim() + "',";
                                    break;
                                case "System.DateTime":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToDateTime(srcRow[i].ToString() == null ? "01/01/1900" : srcRow[i]).ToString().Trim() + "',";
                                    break;
                                case "System.Boolean":
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + (srcRow[i].ToString().Trim().ToUpper() == null ? 0 : (srcRow[i].ToString().Trim() == "True" ? 1 : 0)) + ",";
                                    break;
                                default:
                                    retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + srcRow[i].ToString().Trim() + "',";
                                    break;
                            }
                            //break;
                        }
                    }
                }
                }
                catch (Exception)
                {
                    exists = false;
                    //break;
                    switch (srcRow[srcDt.Columns[i].ColumnName].GetType().ToString())
                    {
                        case "System.Int16":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt16(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int32":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt32(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int64":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt64(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Double":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDouble(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Decimal":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDecimal(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.String":
                        case "System.DBNull":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToString(srcRow[i].ToString() == null ? "" : srcRow[i].ToString().Replace("'", "''")).ToString().Trim() + "',";
                            break;
                        case "System.DateTime":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToDateTime(srcRow[i].ToString() == null ? "01/01/1900" : srcRow[i]).ToString().Trim() + "',";
                            break;
                        case "System.Boolean":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + (srcRow[i].ToString().Trim().ToUpper() == null ? 0 : (srcRow[i].ToString().Trim() == "True" ? 1 : 0)) + ",";
                            break;
                        default:
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + srcRow[i].ToString().Trim() + "',";
                            break;
                    }
                }
                
                
                    
                
            }
            if (exists == false)
            {
        
                retStr = retStr.Substring(0, retStr.Length - 1)+" Where ";
                foreach (string arr in arrItem)
                {
                    retStr = retStr + " [" + arr.Trim() + "]= '" + srcRow[arr.Trim()].ToString().Trim() + "' And ";
                }
                retStr = retStr.Substring(0, retStr.Length - 4);
            }
            else
            {
                retStr = "";
            }
            return retStr;
        }
        public string GetInsertString(DataTable dt, DataRow row, string tblNm, string keyflds)
        {
            string retStr = string.Empty;
            string[] arrItem = keyflds.Split(',');
            retStr = "If Not Exists (Select [" + arrItem[0]+ "] From " + tblNm + " Where ";
            foreach (string arr in arrItem)
            {
                retStr = retStr +"["+ arr + "]='" + row[arr].ToString().Trim()+"' And ";
            }
            retStr = retStr.Substring(0, retStr.Length - 4) + ") Begin " + " Insert Into " + tblNm + " ("; 
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                retStr=retStr+"["+dt.Columns[i].ColumnName+"],";
            }
            retStr = retStr.Substring(0, retStr.Length - 1)+" ) Values (";
            
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                switch (dt.Columns[i].DataType.ToString())
                {
                    case "System.Int16":
                        retStr = retStr + Convert.ToInt16(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Int32":
                        retStr = retStr + Convert.ToInt32(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Int64":
                        retStr = retStr + Convert.ToInt64(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Double":
                        retStr = retStr + Convert.ToDouble(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Decimal":
                        retStr = retStr + Convert.ToDecimal(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.String":
                    case "System.DBNull":
                        retStr = retStr + "'" + Convert.ToString(row[i].GetType().ToString() == "System.DBNull" ? "" : row[i].ToString().Replace("'", "''").Trim()) + "',";
                        break;
                    case "System.DateTime":
                        retStr = retStr + "'" + Convert.ToDateTime(row[i].GetType().ToString() == "System.DBNull" ? "01/01/1900" : row[i]).ToString().Trim() + "',";
                        break;
                    case "System.Boolean":
                        retStr = retStr + (row[i].GetType().ToString().Trim().ToUpper() == "System.DBNull" ? 0 : (row[i].ToString().Trim() == "True" ? 1 : 0)) + ",";
                        break;
                    default:
                        retStr = retStr + "'" + row[i].ToString().Trim() + "',";
                        break;
                }
            }
            retStr = retStr.Substring(0, retStr.Length - 1)+") End ";
            return retStr;
        }
        public DataTable GetDataTable(string DatabaseNm, string tblName)
        {
            DataTable dt=new DataTable();
            da = new SqlDataAdapter("Select * From " + DatabaseNm + ".."+tblName, cn);
            da.Fill(dt);
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (dt.Columns[i].ColumnName.ToUpper()=="NEWRANGE" || dt.Columns[i].ColumnName.ToUpper()=="NEWGROUP")
                {
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        dt.Rows[j][i] = "";
                    }
                }
            }
            return dt;
        }
        public void WriteScriptToFile(string fileName, string strText)
        {
            string[] script;
            string filePath = string.Empty;
            script = strText.Split('|');
            foreach (string x in script)
            {
                try
                {
                    if (!string.IsNullOrEmpty(x))
                    {
                        filePath = (txtPath.Text == "" ? Application.StartupPath : txtPath.Text);
                        using (FileStream file = new FileStream(filePath + "\\" + fileName + ".Sql", FileMode.Append, FileAccess.Write))
                        {
                            StreamWriter streamWriter = new StreamWriter(file);
                            streamWriter.WriteLine(x + "\n");
                            streamWriter.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error in Write Script File Method: "+ex.Message);
                }
            }
           // MessageBox.Show("Script File generated Successfully...");

        }
        public bool Inlist(string str, string[] arrItems)
        {
            for (int i = 0; i < arrItems.Length; i++)
            {
                if (str.ToUpper()==arrItems[i].ToString().ToUpper())
                {
                    return true;
                }
            }
            return false;
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCreateScript_Click(object sender, EventArgs e)
        {
            string strText = string.Empty;
            _Dbname = cboDatabase.SelectedItem.ToString();
            DataTable Db=new DataTable();
            DataColumn col = new DataColumn("tblNm", typeof(System.String));
            Db.Columns.Add(col);
            col = new DataColumn("KeyFields", typeof(System.String));
            Db.Columns.Add(col);
            col = new DataColumn("ExcludeFlds", typeof(System.String));
            Db.Columns.Add(col);
            DataRow dr = Db.NewRow();
            dr["tblNm"] = "Com_menu";
            dr["KeyFields"] = "PadName,BarName";
            dr["ExcludeFlds"] = "Range,NewRange,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
            Db.Rows.Add(dr);
            dr = Db.NewRow();
            dr["tblNm"] = "R_status";
            dr["KeyFields"] = "Group,Desc,Rep_Nm";
            dr["ExcludeFlds"] = "NewGroup,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
            Db.Rows.Add(dr);
            dr = Db.NewRow();
            dr["tblNm"] = "Lother";
            dr["KeyFields"] = "E_Code,Fld_nm";
            dr["ExcludeFlds"] = "e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_,user_name,sysdate,passroute,";
            Db.Rows.Add(dr);
            dr = Db.NewRow();
            dr["tblNm"] = "Lcode";
            dr["KeyFields"] = "Entry_ty";
            dr["ExcludeFlds"] = "cd";
            Db.Rows.Add(dr);
            WriteScriptToFile("01_Struture_script", "--" + DateTime.Now.ToString() + " -- File has been auto generated...");
            for (int i = 0; i < Db.Rows.Count; i++)
            {
                toolStripLabel1.Text = "Generating Script for the table " + Db.Rows[i]["tblNm"].ToString();
                toolStrip1.Refresh();
                WriteScriptToFile("01_Struture_script", "--Generating Script of the table " + Db.Rows[i]["tblNm"].ToString() + " for the structure Script and Records \t \t --Start");
                GenerateStructureScript(cboDatabase.SelectedItem.ToString(), cboStdDatabase.SelectedItem.ToString(), Db.Rows[i]["tblNm"].ToString());
                GenerateRecordScript(cboDatabase.SelectedItem.ToString(), cboStdDatabase.SelectedItem.ToString(), Db.Rows[i]["tblNm"].ToString(), Db.Rows[i]["KeyFields"].ToString(), Db.Rows[i]["ExcludeFlds"].ToString());
                WriteScriptToFile("01_Struture_script", "--Generating Script of the table " + Db.Rows[i]["tblNm"].ToString() + " for the structure Script and Records \t \t --End");
            }
            CreateTableProcedureScript();
            toolStripLabel1.Text = "Ready";

            MessageBox.Show("Script File generated Successfully... \n Please check the files in the folder : " + (txtPath.Text == "" ? Application.StartupPath : txtPath.Text));
        }
        public void CreateTableProcedureScript()
        {
            string strText = string.Empty;
            bool exists = false;
            da = new SqlDataAdapter("Select [Name] as tblNm From "+cboDatabase.SelectedItem.ToString()+"..SysObjects Where [name] Not In (Select [Name] from "+cboStdDatabase.SelectedItem.ToString()+"..SysObjects where xType='U') and xType='U'", cn);
            da.Fill(ds, "tbl_Vw");

            ServerConnection conn = new ServerConnection();
            conn.LoginSecure = false;
            conn.Login = _Uid;
            conn.Password = _Pwd;
            Server server = new Server(conn);

            Database dbname = server.Databases[_Dbname];
            for (int i = 0; i < ds.Tables["tbl_Vw"].Rows.Count; i++)
            {
                Table tbl = dbname.Tables[ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString()];

                StringCollection script = tbl.Script();

                string[] scriptArray = new string[script.Count];
                script.CopyTo(scriptArray, 0);

                WriteScriptToFile("02_Table_script", "--Generating Script file for the table " + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString().ToUpper() + " \t --Start");
                strText = "If Not Exists (Select [Name] From SysObjects Where xType='U' and [Name]='" + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString().ToUpper() + "') Begin ";
                for (int j = 0; j < scriptArray.Length; j++)
                {
                    strText = strText + scriptArray[j].ToString()+"\t";
                }
                strText = strText + " End ";
                toolStripLabel1.Text = "Generating Script for the table " + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString();
                toolStrip1.Refresh();
                WriteScriptToFile("02_Table_script", strText + "| ");
                WriteScriptToFile("02_Table_script", "--Generating Script file for the table " + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString().ToUpper() + " \t --End");
            }

            da = new SqlDataAdapter("Select [Name] as srcProcNm From " + cboDatabase.SelectedItem.ToString() + "..SysObjects Where xType='P' Order by [Name]", cn);
            //da = new SqlDataAdapter("Select [Name] as procNm From " + cboDatabase.SelectedItem.ToString() + "..SysObjects Where [name] Not In (Select [Name] from " + cboStdDatabase.SelectedItem.ToString() + "..SysObjects where xType='P') and xType='P'", cn);

            da.Fill(ds, "srcProcedure_Vw");

            da = new SqlDataAdapter("Select [Name] as targetProcNm From " + cboStdDatabase.SelectedItem.ToString() + "..SysObjects Where xType='P' Order by [Name]", cn);
            da.Fill(ds, "targetProcedure_Vw");
            Database targetDbName = server.Databases[cboStdDatabase.SelectedItem.ToString()];
            for (int i = 0; i < ds.Tables["srcProcedure_Vw"].Rows.Count; i++)
            {
                exists = false;
                for (int j = 0; j < ds.Tables["targetProcedure_Vw"].Rows.Count; j++)
                {
                    if (ds.Tables["srcProcedure_Vw"].Rows[i]["srcProcNm"].ToString()==ds.Tables["targetProcedure_Vw"].Rows[j]["targetProcNm"].ToString())
                    {
                        exists = true;
                        StoredProcedure srcStoreProc = dbname.StoredProcedures[ds.Tables["srcProcedure_Vw"].Rows[i]["srcProcNm"].ToString()];
                        StoredProcedure targetStoreProc = targetDbName.StoredProcedures[ds.Tables["targetProcedure_Vw"].Rows[j]["targetProcNm"].ToString()];
                        DateTime srcTime = srcStoreProc.DateLastModified;
                        DateTime targetTime = targetStoreProc.DateLastModified;
                        if (DateTime.Compare(srcTime, targetTime) < 0)
                        {
                            Generate_Procedure_Script(srcStoreProc, 1);
                        }
                        else if (DateTime.Compare(srcTime, targetTime) == 0)
                        {
                        }
                        else
                        {
                            Generate_Procedure_Script(srcStoreProc, 2);
                        }
                        break;
                    }
                }
                if (exists==false)
                {
                    StoredProcedure srcStoreProc = dbname.StoredProcedures[ds.Tables["srcProcedure_Vw"].Rows[i]["srcProcNm"].ToString()];
                    Generate_Procedure_Script(srcStoreProc,3);
                }
                
            }
            
        }

        private void Generate_Procedure_Script(StoredProcedure storeProc, int type)
        {
            StringCollection cmdLines = storeProc.Script();
            string strText = string.Empty;

            string[] scriptLineArray = new string[cmdLines.Count];
            cmdLines.CopyTo(scriptLineArray, 0);

            WriteScriptToFile("03_Procedure_script", "--Generating Script for the procedure " + storeProc.Name.ToUpper() + " \t --Start");
            switch (type)
            {
                case 1:
                    WriteScriptToFile("03_Procedure_script", "--This procedure is Missed Match(i.e. this stored procedure is older ) ");
                    break;
                case 2:
                    WriteScriptToFile("03_Procedure_script", "--This procedure is Missed Match(i.e. This stored procedure is Newer )");
                    break;
                case 3:
                    WriteScriptToFile("03_Procedure_script", "--This procedure is Newly added");
                    break;
            }
            strText = "If Exists (Select [Name] From SysObjects Where xType='P' and [Name]='" + storeProc.Name.ToUpper() + "') Begin \n\t Drop Procedure " + storeProc.Name.ToUpper()+ " \n End \n \n";
            for (int j = 2; j < scriptLineArray.Length; j++)
            {
                strText = strText + scriptLineArray[j].ToString() + "\t";
            }
            toolStripLabel1.Text = "Generating Script for the procedure " + storeProc.Name.ToUpper();
            toolStrip1.Refresh();
            WriteScriptToFile("03_Procedure_script", strText + "| ");
            WriteScriptToFile("03_Procedure_script", "--Generating Script for the procedure " + storeProc.Name.ToUpper() + " \t --End");
        }
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog1.Description = "Select Path to Save Script Files ";
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtPath.Text = folderBrowserDialog1.SelectedPath.ToString();
            }
        }
    
    }
}

