﻿namespace ExportScript
{
    partial class frmFileCompare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSelectPath = new System.Windows.Forms.Button();
            this.txtSelectPath = new System.Windows.Forms.TextBox();
            this.btnSFoldPath = new System.Windows.Forms.Button();
            this.txtSFoldPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.dataGridComp = new System.Windows.Forms.DataGridView();
            this.select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.txtComp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chkClassFld = new System.Windows.Forms.CheckBox();
            this.chkBmpFld = new System.Windows.Forms.CheckBox();
            this.chkMainFld = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCompare = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.txtMsg = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridComp)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnSelectPath);
            this.panel1.Controls.Add(this.txtSelectPath);
            this.panel1.Controls.Add(this.btnSFoldPath);
            this.panel1.Controls.Add(this.txtSFoldPath);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 114);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 14);
            this.label3.TabIndex = 8;
            this.label3.Text = "Select location to Save files";
            // 
            // btnSelectPath
            // 
            this.btnSelectPath.Location = new System.Drawing.Point(282, 78);
            this.btnSelectPath.Name = "btnSelectPath";
            this.btnSelectPath.Size = new System.Drawing.Size(26, 22);
            this.btnSelectPath.TabIndex = 7;
            this.btnSelectPath.Text = "...";
            this.btnSelectPath.UseVisualStyleBackColor = true;
            this.btnSelectPath.Click += new System.EventHandler(this.btnSelectPath_Click);
            // 
            // txtSelectPath
            // 
            this.txtSelectPath.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSelectPath.Location = new System.Drawing.Point(4, 79);
            this.txtSelectPath.Name = "txtSelectPath";
            this.txtSelectPath.Size = new System.Drawing.Size(275, 20);
            this.txtSelectPath.TabIndex = 6;
            // 
            // btnSFoldPath
            // 
            this.btnSFoldPath.Location = new System.Drawing.Point(282, 21);
            this.btnSFoldPath.Name = "btnSFoldPath";
            this.btnSFoldPath.Size = new System.Drawing.Size(26, 22);
            this.btnSFoldPath.TabIndex = 4;
            this.btnSFoldPath.Text = "...";
            this.btnSFoldPath.UseVisualStyleBackColor = true;
            this.btnSFoldPath.Click += new System.EventHandler(this.btnSFoldPath_Click);
            // 
            // txtSFoldPath
            // 
            this.txtSFoldPath.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSFoldPath.Location = new System.Drawing.Point(4, 21);
            this.txtSFoldPath.Name = "txtSFoldPath";
            this.txtSFoldPath.Size = new System.Drawing.Size(275, 20);
            this.txtSFoldPath.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "Select Standard Main folder Path";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtMsg);
            this.panel2.Controls.Add(this.chkSelectAll);
            this.panel2.Controls.Add(this.dataGridComp);
            this.panel2.Controls.Add(this.chkClassFld);
            this.panel2.Controls.Add(this.chkBmpFld);
            this.panel2.Controls.Add(this.chkMainFld);
            this.panel2.Location = new System.Drawing.Point(3, 115);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(317, 337);
            this.panel2.TabIndex = 1;
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSelectAll.Location = new System.Drawing.Point(8, 75);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(127, 18);
            this.chkSelectAll.TabIndex = 4;
            this.chkSelectAll.Text = "Select All Companies";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.Click += new System.EventHandler(this.chkSelectAll_Click);
            // 
            // dataGridComp
            // 
            this.dataGridComp.AllowUserToAddRows = false;
            this.dataGridComp.AllowUserToDeleteRows = false;
            this.dataGridComp.AllowUserToResizeColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridComp.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridComp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridComp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.select,
            this.txtComp});
            this.dataGridComp.Location = new System.Drawing.Point(4, 95);
            this.dataGridComp.Name = "dataGridComp";
            this.dataGridComp.RowHeadersVisible = false;
            this.dataGridComp.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridComp.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridComp.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridComp.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridComp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridComp.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridComp.Size = new System.Drawing.Size(307, 236);
            this.dataGridComp.TabIndex = 3;
            // 
            // select
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.NullValue = false;
            this.select.DefaultCellStyle = dataGridViewCellStyle2;
            this.select.HeaderText = "";
            this.select.Name = "select";
            this.select.Width = 20;
            // 
            // txtComp
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComp.DefaultCellStyle = dataGridViewCellStyle3;
            this.txtComp.HeaderText = "Select Company";
            this.txtComp.Name = "txtComp";
            this.txtComp.Width = 284;
            // 
            // chkClassFld
            // 
            this.chkClassFld.AutoSize = true;
            this.chkClassFld.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkClassFld.Location = new System.Drawing.Point(8, 52);
            this.chkClassFld.Name = "chkClassFld";
            this.chkClassFld.Size = new System.Drawing.Size(86, 18);
            this.chkClassFld.TabIndex = 2;
            this.chkClassFld.Text = "Class Folder";
            this.chkClassFld.UseVisualStyleBackColor = true;
            // 
            // chkBmpFld
            // 
            this.chkBmpFld.AutoSize = true;
            this.chkBmpFld.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBmpFld.Location = new System.Drawing.Point(8, 29);
            this.chkBmpFld.Name = "chkBmpFld";
            this.chkBmpFld.Size = new System.Drawing.Size(80, 18);
            this.chkBmpFld.TabIndex = 1;
            this.chkBmpFld.Text = "BMP Folder";
            this.chkBmpFld.UseVisualStyleBackColor = true;
            // 
            // chkMainFld
            // 
            this.chkMainFld.AutoSize = true;
            this.chkMainFld.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMainFld.Location = new System.Drawing.Point(8, 6);
            this.chkMainFld.Name = "chkMainFld";
            this.chkMainFld.Size = new System.Drawing.Size(81, 18);
            this.chkMainFld.TabIndex = 0;
            this.chkMainFld.Text = "Main Folder";
            this.chkMainFld.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.btnClose);
            this.panel3.Controls.Add(this.btnCompare);
            this.panel3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(3, 451);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(317, 41);
            this.panel3.TabIndex = 2;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(232, 8);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCompare
            // 
            this.btnCompare.Location = new System.Drawing.Point(152, 8);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(75, 23);
            this.btnCompare.TabIndex = 0;
            this.btnCompare.Text = "C&ompare";
            this.btnCompare.UseVisualStyleBackColor = true;
            this.btnCompare.Click += new System.EventHandler(this.btnCompare_Click);
            // 
            // txtMsg
            // 
            this.txtMsg.BackColor = System.Drawing.Color.White;
            this.txtMsg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMsg.Enabled = false;
            this.txtMsg.Location = new System.Drawing.Point(4, 32);
            this.txtMsg.Multiline = true;
            this.txtMsg.Name = "txtMsg";
            this.txtMsg.ReadOnly = true;
            this.txtMsg.Size = new System.Drawing.Size(306, 60);
            this.txtMsg.TabIndex = 5;
            this.txtMsg.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "label2";
            this.label2.Visible = false;
            // 
            // frmFileCompare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 494);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frmFileCompare";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "File Compare";
            this.Load += new System.EventHandler(this.frmFileCompare_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridComp)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSFoldPath;
        private System.Windows.Forms.TextBox txtSFoldPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSelectPath;
        private System.Windows.Forms.TextBox txtSelectPath;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkClassFld;
        private System.Windows.Forms.CheckBox chkBmpFld;
        private System.Windows.Forms.CheckBox chkMainFld;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCompare;
        private System.Windows.Forms.DataGridView dataGridComp;
        private System.Windows.Forms.DataGridViewCheckBoxColumn select;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtComp;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.TextBox txtMsg;
        private System.Windows.Forms.Label label2;
    }
}