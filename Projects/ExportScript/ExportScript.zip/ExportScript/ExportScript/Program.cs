﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ExportScript
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] menuOption)
        {
            string _menuOption = string.Empty;
            if (menuOption.Length != 0)
            {
                _menuOption = menuOption[0];
            }
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainProg(_menuOption));
        }
       
    }
}
