﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExportScript
{
    public partial class MainProg : Form
    {
        public string _menuType=string.Empty;
        public MainProg()
        {
            InitializeComponent();
        }
        public MainProg(string menuType)
        {
            InitializeComponent();
            _menuType = menuType;
        }
        private string _server;
        private string _user;
        private string _pass;
        GetInfo.iniFile ini;
        GetInfo.EncDec x;

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void ImportDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //frmDataCompare f = new frmDataCompare(_server, x.Dec("myName", x.OnDecrypt("myName", _user)), x.Dec("myName", x.OnDecrypt("myName", _pass)));
            //f.MdiParent = this;
            //f.Show();
            OpenImportMenu(false);
        }

        private void ExportDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenExportMenu(false);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void MainProg_Load(object sender, EventArgs e)
        {
            Icon appIcon = new Icon(Application.StartupPath+ "\\BMP\\UEICON.ICO"); ;
            this.Icon = appIcon;
             ini= new GetInfo.iniFile(Application.StartupPath + "\\" + "Visudyog.ini");
            x = new GetInfo.EncDec();
            _server = ini.IniReadValue("DataServer", "Name");
            _user = ini.IniReadValue("DataServer", x.OnEncrypt("myName", x.Enc("myName", "User")));
            _pass = ini.IniReadValue("DataServer", x.OnEncrypt("myName", x.Enc("myName", "Pass")));
            //ConnStr = "Data Source=" + Server + ";Initial Catalog=Master;Uid=" + x.Dec("myName", x.OnDecrypt("myName", user)) + ";Pwd=" + x.Dec("myName", x.OnDecrypt("myName", pass));
            if (_menuType == "")
            {
            }
            else 
            {
                this.menuStrip.Visible = false;
                if (_menuType.Trim().ToUpper() == "IMPORT")
                {
                    this.ExportDataToolStripMenuItem.Visible = false;
                    OpenImportMenu(true);
                }
                else 
                {
                    this.ImportDataToolStripMenuItem.Visible = false;
                    OpenExportMenu(true);
                }
            }
        }
        public void OpenExportMenu(bool internalCall)
        {
            frmFileCompare g = new frmFileCompare(_server, x.Dec("myName", x.OnDecrypt("myName", _user)), x.Dec("myName", x.OnDecrypt("myName", _pass)), internalCall);
            //frmFileCompare g = new frmFileCompare("Shrikanth", "sa", "sa1985", true);
            g.MdiParent = this;
            g.Show();
        }
        public void OpenImportMenu(bool internalCall)
        {
            frmImportData f = new frmImportData(_server, x.Dec("myName", x.OnDecrypt("myName", _user)), x.Dec("myName", x.OnDecrypt("myName", _pass)), internalCall);
            f.MdiParent = this;
            f.Show();
        }
     
    }
}
