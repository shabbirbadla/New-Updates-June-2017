﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;


namespace ExportScript
{
    public partial class frmImportData : Form
    {
        #region Variables

        string connStr;
        SqlConnection cn;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        string importTime;
        string appPath = string.Empty;
        string luser = string.Empty;
        string lpass = string.Empty;
        string lserver = string.Empty;
        bool internalCall=false;
        #endregion

        #region Methods

        /// <summary>
        /// This method is used for Browsing the file
        /// </summary>
        private void OpenDialog()
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Zip|*.zip";
            dialog.InitialDirectory = Environment.SpecialFolder.MyComputer.ToString();
            dialog.Title = "Select the zip ";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                txtZipFilePath.Text = dialog.FileName.ToString();
            }
        }

        private SqlConnection OpenConnection()
        {
            if (cn == null)
            {
                try
                {
                    cn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while opening connection :" + ex.Message);
                }
            }
            else
            {
                if (cn.State == ConnectionState.Closed)
                {
                    try
                    {
                        cn.Open();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while opening connection :" + ex.Message);
                    }
                }
            }
            return cn;
        }
        private void LoadCompanies()
        {
            da = new SqlDataAdapter("Select Co_Name,DbName,CompId,Passroute=Convert(Varchar(100),Passroute),folderName from Vudyog..Co_Mast Where Enddir='' and com_type<>'M' Order By Co_Name ", cn);
            da.Fill(ds, "Co_mast_vw");
            cboCompany.DataSource = ds.Tables["Co_mast_vw"];
            cboCompany.DisplayMember = "Co_Name";
            cboCompany.ValueMember = "DbName";
            cn.Close();
            connStr = "Data Source=" + lserver + ";Initial Catalog=" + cboCompany.SelectedValue.ToString() + ";Uid=" + luser + ";Pwd=" + lpass;
            cn = new SqlConnection(connStr);
        }

        private bool CheckValidation()
        {
            if (txtZipFilePath.Text == string.Empty)
            {
                MessageBox.Show("Select the file to import", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnZipFilePath.Focus();
                return false;
            }
            return true;
        }
        /// <summary>
        /// This method is used for checking which is the last modified file
        /// </summary>
        /// <param name="srcParth">Client folder path</param>
        /// <param name="targetPath">Standard folder path</param>
        /// <param name="fileName">Name of the File</param>
        /// <returns></returns>
        public int CheckLastModified(string srcParth, string targetPath, string fileName)
        {
            string file = string.Empty;
            DateTime srcFileTime, targetFileTime;

            string srcFile = srcParth + "\\" + fileName;
            string targetFile = targetPath + "\\" + fileName;
            FileInfo srcFileInfo = new FileInfo(@srcFile);
            FileInfo targetFileInfo = new FileInfo(@targetFile);

            srcFileTime = Convert.ToDateTime(srcFileInfo.LastWriteTime.ToString(ReturnDateFormat()));
            targetFileTime = Convert.ToDateTime(targetFileInfo.LastWriteTime.ToString(ReturnDateFormat()));
            if (DateTime.Compare(srcFileTime, targetFileTime) < 0)
            {
                return 1;
            }
            else if (DateTime.Compare(srcFileTime, targetFileTime) == 0)
            {
                long srcFileLength = srcFileInfo.Length;
                long targetFileLength = targetFileInfo.Length;
                if (srcFileLength != targetFileLength && !Inlist(System.IO.Path.GetExtension(srcFile).ToUpper(), new string[] { ".SQL", ".DAT" }))
                {
                    return 2;
                }
                return 4;
            }
            else
            {
                return 3;
            }
        }
        /// <summary>
        /// This method is used for Checking the file existence 
        /// </summary>
        /// <param name="targetPath">Search file in this path</param>
        /// <param name="srcFile">FileName</param>
        /// <param name="excFiles">Exclude files for checking</param>
        /// <returns></returns>
        public bool CheckFileExistence(string targetPath, string srcFile, string[] excFiles)
        {
            string filename = "";
            foreach (string file in Directory.GetFiles(targetPath))
            {
                filename = System.IO.Path.GetFileName(file);
                if (!Inlist(filename, excFiles))
                {
                    if (filename.ToUpper() == srcFile.ToUpper())
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// This method is used for comparing folders and copy the missed match file to given path
        /// </summary>
        /// <param name="srcFolderPath">Client Main Folder(Respective folders like Class,Bmp etc)</param>
        /// <param name="targetFolderPath"> Standard Main Folder (Respective folders like Class,Bmp etc)</param>
        /// <param name="copyPath">Where to copy the missed matched (Respective folders like Class,Bmp etc)</param>
        /// <param name="folderName">folders like Class,Bmp etc</param>
        private void CompareFolders(string srcFolderPath, string targetFolderPath, string copyPath, string folderName)
        {
            string filename = "";
            string strText = string.Empty;
            string exMessage = string.Empty;
            bool exceptionExists = false;
            int logTotalFiles = 0, logNewFiles = 0, logNewerFiles = 0, logOlderFiles = 0, logFilesNotCopied = 0;


            DirectoryInfo d = new DirectoryInfo(srcFolderPath);
            string[] excFiles = { "Usquare.exe", "iTAX.exe", "VUdyogMfg.exe", "VUdyogTrd.exe" };
            logTotalFiles = d.GetFiles().Length;

            //progressBar1.Maximum = d.GetFiles().Length;
            //progressBar1.Value = 0;
            foreach (string file in Directory.GetFiles(srcFolderPath))
            {
                filename = System.IO.Path.GetFileName(file);

                if (System.IO.Path.GetExtension(file).ToUpper() == ".SQL")
                {
                    txtMsg.Text = "Executing Script File : " + file;
                    txtMsg.Refresh();

                    string script = "Use " + cboCompany.SelectedValue.ToString() + " \nGo\n ";
                    //string script = " ";
                    StreamReader sr = new StreamReader(file);
                    script = script + sr.ReadToEnd();
                    if (filename.ToUpper() == "04_co_mast_Update.Sql".ToUpper())
                    {
                        txtMsg.Text = "Updating Company details : " + file;
                        txtMsg.Refresh();
                        script = script + " Where dbname='" + cboCompany.SelectedValue.ToString().Trim() + "'";
                    }

                    sr.Close();
                    OpenConnection();

                    //SqlCommand cmd = new SqlCommand(script, cn);
                    try
                    {
                        //cmd.CommandTimeout = 2000;

                        Server server = new Server(new ServerConnection(cn));
                        server.ConnectionContext.ExecuteNonQuery(script);
                        server.ConnectionContext.Disconnect();
                        //cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while executing script file. '" + file + "' :" + ex.Message);
                    }

                }
                if (!Inlist(filename, excFiles))
                {
                    if (!CheckFileExistence(targetFolderPath, filename, excFiles))
                    {
                        exMessage = "";
                        exceptionExists = false;
                        try
                        {
                            if (!System.IO.Directory.Exists(copyPath))
                            {
                                System.IO.Directory.CreateDirectory(copyPath);
                            }
                            txtMsg.Text = "Copying File : " + file;
                            txtMsg.Refresh();
                            System.IO.File.Copy(file, copyPath + "\\" + filename, true);

                            //txtMsg.Text = "Copying file" + filename;
                            //txtMsg.Refresh();
                            logNewFiles = logNewFiles + 1;
                            strText = filename.PadRight(70, ' ') + "New".PadRight(20, ' ') + "File Copied Successfully";
                        }
                        catch (Exception ex)
                        {
                            logFilesNotCopied = logFilesNotCopied + 1;
                            strText = filename.PadRight(70, ' ') + "New".PadRight(20, ' ') + "File Not Copied. ";
                            exceptionExists = true;
                            exMessage = ex.Message;
                            //MessageBox.Show("Error in Compare folders method: "+ex.Message);
                        }
                        finally
                        {
                            WriteLogToFile(strText);
                            if (exceptionExists == true)
                            {
                                WriteLogToFile(" ".PadRight(55, ' ') + "C01".PadRight(15, ' ') + exMessage);
                            }
                        }

                    }
                    else
                    {
                        bool copy = false;
                        exMessage = "";
                        exceptionExists = false;

                        switch (CheckLastModified(srcFolderPath, targetFolderPath, filename))
                        {
                            case 1:
                                copy = false;
                                strText = filename.PadRight(70, ' ') + " ".PadRight(20, ' ') + "File Not Copied";
                                logFilesNotCopied = logFilesNotCopied + 1;
                                break;
                            case 2:
                                copy = true;
                                strText = filename.PadRight(70, ' ') + "New".PadRight(20, ' ') + "File Copied Successfully";
                                logNewFiles = logNewFiles + 1;
                                break;
                            case 3:
                                copy = true;
                                strText = filename.PadRight(70, ' ') + "Newer".PadRight(20, ' ') + "File Copied Successfully";
                                logNewerFiles = logNewerFiles + 1;
                                break;
                            case 4:
                                copy = false;
                                strText = filename.PadRight(70, ' ') + " ".PadRight(20, ' ') + "File Not Copied";
                                logFilesNotCopied = logFilesNotCopied + 1;
                                break;
                        }
                        if (copy == true)
                        {
                            try
                            {
                                //txtMsg.Text = "Copying file" + filename;
                                //txtMsg.Refresh();
                                if (!System.IO.Directory.Exists(copyPath + "\\" + folderName))
                                {
                                    System.IO.Directory.CreateDirectory(copyPath);
                                }
                                txtMsg.Text = "Copying File : " + file;
                                txtMsg.Refresh();
                                System.IO.File.Copy(file, copyPath + "\\" + filename, true);

                            }
                            catch (Exception ex)
                            {
                                exceptionExists = true;
                                exMessage = ex.Message;
                                logFilesNotCopied = logFilesNotCopied + 1;
                                //MessageBox.Show("Error in Compare folders method: " + ex.Message);
                            }
                        }
                        WriteLogToFile(strText);
                        if (exceptionExists == true)
                        {
                            WriteLogToFile(" ".PadRight(55, ' ') + "C01".PadRight(15, ' ') + exMessage);
                        }
                    }
                }
                //                progressBar1.Value = progressBar1.Value + 1;
            }
            WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
            WriteLogToFile("Total No. of Files :" + logTotalFiles.ToString());
            WriteLogToFile("No. of New Files (Not Existing):" + logNewFiles.ToString());
            WriteLogToFile("No. of Newer Files (Existing):" + logNewerFiles.ToString());
            WriteLogToFile("No. of Older Files (Existing):" + logOlderFiles.ToString());
            WriteLogToFile("No. of Files Not Copied :" + logFilesNotCopied.ToString());
            WriteLogToFile("Files Copied to the Path  :" + copyPath);
            WriteLogToFile(" ");
            WriteLogToFile(" ");
            DeleteFile(srcFolderPath);
        }
        /// <summary>
        /// This method is used for getting the character of the value
        /// </summary>
        /// <param name="intByte"></param>
        /// <returns></returns>
        private string Chr(int intByte)
        {
            byte[] bytBuffer = new byte[] { (byte)intByte };
            return Encoding.GetEncoding(1252).GetString(bytBuffer);
        }
        /// <summary>
        /// This method is used for getting the ascii value of the character
        /// </summary>
        /// <param name="strChar"></param>
        /// <returns></returns>
        private int Asc(string strChar)
        {
            char[] chrBuffer = { Convert.ToChar(strChar) };
            byte[] bytBuffer = Encoding.GetEncoding(1252).GetBytes(chrBuffer);
            return (int)bytBuffer[0];
        }
        /// <summary>
        /// This method is used for checking the value is in given list or not
        /// </summary>
        /// <param name="str">string to check</param>
        /// <param name="arrItems">array Items</param>
        /// <returns></returns>
        public bool Inlist(string str, string[] arrItems)   //shrikant
        {
            for (int i = 0; i < arrItems.Length; i++)
            {
                if (str.ToUpper() == arrItems[i].ToString().ToUpper())
                {
                    return true;
                }
            }
            return false;
        }
        private void DeleteFile(string scrPath)
        {
            try
            {
                if (System.IO.Directory.Exists(scrPath))
                {
                    foreach (string fil in System.IO.Directory.GetFiles(scrPath))
                    {
                        if (File.Exists(fil))
                        {
                            txtMsg.Text = "Deleting File : " + fil;
                            txtMsg.Refresh();
                            File.Delete(fil);

                        }
                    }
                    foreach (string dir in System.IO.Directory.GetDirectories(scrPath))
                    {
                        DeleteFile(dir);
                    }
                    txtMsg.Text = "Deleting directory : " + scrPath;
                    txtMsg.Refresh();
                    Directory.Delete(scrPath);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in file Deleting method. :" + ex.Message, "File Compare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        public void WriteLogToFile(string strText)
        {
            string[] script;
            string filePath = string.Empty;
            script = strText.Split('|');
            foreach (string x in script)
            {
                try
                {
                    if (!string.IsNullOrEmpty(x))
                    {
                        if (!System.IO.Directory.Exists(appPath + "\\"))
                        {
                            System.IO.Directory.CreateDirectory(appPath + "\\");
                        }
                        filePath = appPath + "\\";
                        using (FileStream file = new FileStream(filePath + "\\" + "File_Import_Log_" + importTime + ".txt", FileMode.Append, FileAccess.Write))
                        {
                            StreamWriter streamWriter = new StreamWriter(file);
                            streamWriter.WriteLine(x + "\n");
                            streamWriter.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error in Write Log File Method: " + ex.Message);
                }
            }
            //MessageBox.Show("Script File generated Successfully...");

        }

        private void ExtractZip(string srcFile, string targetPath)
        {
            try
            {
                UdyogZipUnzip.UdyoyZipUnZipUtility zipFile = new UdyogZipUnzip.UdyoyZipUnZipUtility();
                zipFile.UdyogUnzip(srcFile, targetPath, "");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static string ReturnDateFormat()
        {
            DateTime dt = Convert.ToDateTime("01/07/2010");

            if (dt.Day.ToString() == "7")
            {
                // dd/Mm/yyyy
                return "MM/dd/yyyy hh:mm";
            }
            else
            {
                // MM/dd/yyyy
                return "dd/MM/yyyy hh:mm";
            }
        }

        #endregion

        public frmImportData(string serverName, string user, string pass, bool internalCal)
        {
            InitializeComponent();
            connStr = "Data Source=" + serverName + ";Initial Catalog=Master;Uid=" + user + ";Pwd=" + pass;
            cn = new SqlConnection(connStr);
            luser = user;
            lpass = pass;
            lserver = serverName;
            internalCall = internalCal;
            appPath = Application.StartupPath;
            //appPath = "C:\\installed\\usquare";
            //appPath = "d:\\tmp\\Usquare";
        }

        private void btnZipFilePath_Click(object sender, EventArgs e)
        {
            OpenDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            if (internalCall == true)
                Application.Exit();
        }
        
        private void frmImportData_Load(object sender, EventArgs e)
        {
            Icon appIcon=new Icon(appPath+"\\BMP\\UEICON.ICO");;
            this.Icon = appIcon;
            LoadCompanies();
        }

        
        private void btnImport_Click(object sender, EventArgs e)
        {
            string targetPath = string.Empty;
            
            label3.Text = "Please wait...";
            label3.Refresh();
            if (CheckValidation()==true)
            {
                importTime = DateTime.Now.ToString("ddMMyyyy hh:mm:ss").Replace(':','_');
                string srcPath = txtZipFilePath.Text.Substring(0, txtZipFilePath.Text.LastIndexOf(".zip"));
                txtMsg.Visible = true;
                txtMsg.Text = "Extracting zip file " + txtZipFilePath.Text;
                txtMsg.Refresh();
                ExtractZip(txtZipFilePath.Text, srcPath);

                DataView dv = ds.Tables["Co_Mast_vw"].DefaultView;
                dv.Sort = "Co_Name";
                dv.RowFilter = "DbName='" + cboCompany.SelectedValue.ToString() + "'";
                string folderName = dv[0]["folderName"].ToString().Trim();
                targetPath = appPath+ "\\" + folderName;
                //targetPath = Application.StartupPath + "\\" + path;


                WriteLogToFile("Comparison status for  Company: " + cboCompany.Text.Trim() + " -- as on " + importTime.Replace('_',':'));
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                WriteLogToFile("Filename".PadRight(55, ' ') + "Error No.".PadRight(15, ' ') + "Status".PadRight(20, ' ') + "Message");
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                CompareFolders(srcPath, targetPath, targetPath, folderName);
                MessageBox.Show("Data Imported Successfully...","",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            label3.Text = "";
            label3.Refresh();
            txtMsg.Visible = false;
            txtMsg.Refresh();
        }
        
    }
}
