﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Compression;
using System.Threading;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
//using Microsoft.SqlServer.Management.Sdk;
using Microsoft.SqlServer.Server;
using UdyogZipUnzip;
namespace ExportScript
{
    public partial class frmFileCompare : Form
    {
        #region Variables

        string connStr;
        SqlConnection cn;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        private string _Uid;
        private string _Pwd;
        private string _Dbname;
        private string _serverName;
        bool internalCall=false;
        string logTime = string.Empty;
        string appPath = string.Empty;
        #endregion

        #region Methods

        /// <summary>
        ///  This method is used to browse the directory
        /// </summary>
        /// <returns></returns>
        private string GetFolderPath()
        {
            string path = string.Empty;
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog1.Description = "Select Path to Save Script Files ";
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                path = folderBrowserDialog1.SelectedPath.ToString();
            }
            return path;
        }
        /// <summary>
        /// This method is used for binding the companies to datagrid
        /// </summary>
        private void LoadCompanies()
        {
            da = new SqlDataAdapter("Select Sel=Convert(Bit,1), Co_Name,CompId,Dbname,Passroute=Convert(Varchar(100),Passroute),folderName from Vudyog..Co_Mast Where Enddir='' and com_type<>'M' Order By Co_Name ", cn); //Modified for Varchar to Varbinary
            da.Fill(ds, "Co_mast_vw");
            dataGridComp.DataSource = ds.Tables["Co_mast_vw"];
            for (int i = 0; i < dataGridComp.Columns.Count; i++)
            {
                switch (i)
                {
                    case 0:
                        dataGridComp.Columns[i].DataPropertyName = "Sel";
                        break;
                    case 1:
                        dataGridComp.Columns[i].DataPropertyName = "Co_Name";
                        dataGridComp.Columns[i].ReadOnly = true;
                        break;
                    default:
                        dataGridComp.Columns[i].Visible = false;
                        break;
                }
            }

        }
        /// <summary>
        /// This method is used for Comparision of the folders as well as database
        /// </summary>
        private void Compare()
        {
            string srcPath = appPath;
            string targetPath = txtSFoldPath.Text;

            string copyPath = txtSelectPath.Text;
            if (chkMainFld.Checked == true)
            {
                WriteLogToFile("Comparison status for Main Folder");
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                WriteLogToFile("Filenamme".PadRight(55, ' ') + "Error No.".PadRight(15, ' ') + "Status".PadRight(20, ' ') + "Message");
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                CompareFolders(srcPath, targetPath, copyPath, "MainAppFolder");
                txtMsg.Text = "Comparing MainAppFolder ";
                txtMsg.Refresh();
            }
            if (chkBmpFld.Checked == true)
            {
                WriteLogToFile("Comparison status for Bmp Folder");
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                WriteLogToFile("Filenamme".PadRight(55, ' ') + "Error No.".PadRight(15, ' ') + "Status".PadRight(20, ' ') + "Message");
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                CompareFolders(srcPath + "\\Bmp", targetPath + "\\Bmp", copyPath + "\\MainAppFolder", "Bmp");
                txtMsg.Text = "Comparing Bmp Folder ";
                txtMsg.Refresh();
            }
            if (chkClassFld.Checked == true)
            {
                WriteLogToFile("Comparison status for Class Folder");
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                WriteLogToFile("Filenamme".PadRight(55, ' ') + "Error No.".PadRight(15, ' ') + "Status".PadRight(20, ' ') + "Message");
                WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                CompareFolders(srcPath + "\\Class", targetPath + "\\Class", copyPath + "\\MainAppFolder", "Class");
                txtMsg.Text = "Comparing Class Folder ";
                txtMsg.Refresh();
            }
            if (dataGridComp.Rows.Count > 0)
            {
                ExtractZipFile(targetPath);
            }
            for (int i = 0; i < dataGridComp.Rows.Count; i++)
            {
                if (dataGridComp.Rows[i].Cells["Sel"].Value.ToString() == "True")
                {
                    string mprod = string.Empty;
                    mprod = dataGridComp.Rows[i].Cells["Passroute"].Value.ToString();
                    dataGridComp.Rows[i].Selected = true;
                    dataGridComp.Refresh();
                    WriteLogToFile("Comparison status for  Company: " + dataGridComp.Rows[i].Cells["Co_Name"].Value.ToString().Trim() + "(" + dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim() + ")" + " Folder");
                    WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                    WriteLogToFile("Filenamme".PadRight(55, ' ') + "Error No.".PadRight(15, ' ') + "Status".PadRight(20, ' ') + "Message");
                    WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
                    if (mprod.IndexOf("vutex") >= 0)
                    {
                        CompareFolders(srcPath + "\\" + dataGridComp.Rows[i].Cells["foldername"].Value.ToString(), targetPath + "\\Database\\" + "NXIO", copyPath + "\\MainAppFolder", dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim() + "_NXIO");
                        CreateScript(dataGridComp.Rows[i].Cells["Dbname"].Value.ToString().Trim(), "Nxio", copyPath + "\\MainAppFolder\\" + dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim() + "_NXIO");
                        GenerateCoMastScript(dataGridComp.Rows[i].Cells["CompId"].Value.ToString(), copyPath + "\\MainAppFolder\\" + dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim() + "_NXIO");
                    }
                    else
                    {
                        CompareFolders(srcPath + "\\" + dataGridComp.Rows[i].Cells["foldername"].Value.ToString(), targetPath + "\\Database\\" + "NEIO", copyPath + "\\MainAppFolder", dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim() + "_NEIO");
                        CreateScript(dataGridComp.Rows[i].Cells["Dbname"].Value.ToString().Trim(), "Neio", copyPath + "\\MainAppFolder\\" + dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim() + "_NEIO");
                        GenerateCoMastScript(dataGridComp.Rows[i].Cells["CompId"].Value.ToString(), copyPath + "\\MainAppFolder\\" + dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim() + "_NEIO");
                    }

                    txtMsg.Text = "Comparing Company Folder " + dataGridComp.Rows[i].Cells["foldername"].Value.ToString().Trim();
                    txtMsg.Refresh();
                }
            }
        }
        private void GenerateCoMastScript(string compId, string copyPath)
        {
            DataTable srcTable;

            srcTable = GetDataTable("Vudyog", "Co_Mast", " Where compId=" + compId.ToString());
            txtMsg.Text = "Generating Company Master Script";
            txtMsg.Refresh();
            WriteScriptToFile("04_co_mast_Update", "--Generating Company Master Script.", copyPath);
            for (int i = 0; i < srcTable.Rows.Count; i++)
            {
                string strText = GenerateUpdateCoMast(srcTable, srcTable.Rows[i]);
                WriteScriptToFile("04_co_mast_Update", (strText == "" ? "" : strText + "| "), copyPath);
            }

        }
        private string GenerateUpdateCoMast(DataTable dt, DataRow row)
        {
            string retStr = string.Empty;
            retStr = "Update Vudyog..co_mast Set ";
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (!Inlist(dt.Columns[i].ColumnName.ToUpper().Trim(), new string[] { "COMPID", "CO_NAME", "DIR_NM", "LOGO", "ENDDIR", "PRODCODE", "COFORMDT", "DBNAME", "FOLDERNAME" }))
                {
                    switch (row[dt.Columns[i].ColumnName].GetType().ToString())
                    {
                        case "System.Int16":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + Convert.ToInt16(row[i].ToString() == null ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int32":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + Convert.ToInt32(row[i].ToString() == null ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int64":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + Convert.ToInt64(row[i].ToString() == null ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Double":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + Convert.ToDouble(row[i].ToString() == null ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Decimal":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + Convert.ToDecimal(row[i].ToString() == null ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.String":
                        case "System.DBNull":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + "'" + Convert.ToString(row[i].ToString() == null ? "" : row[i].ToString().Replace("'", "''")).ToString().Trim() + "',";
                            break;
                        case "System.DateTime":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + "'" + Convert.ToDateTime(row[i].ToString() == null ? "01/01/1900" : row[i]).ToString("MM/dd/yyyy hh:mm:ss").Trim() + "',";
                            break;
                        case "System.Boolean":
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + (row[i].ToString().Trim().ToUpper() == null ? 0 : (row[i].ToString().Trim() == "True" ? 1 : 0)) + ",";
                            break;
                        default:
                            retStr = retStr + "[" + dt.Columns[i].ColumnName + "]=" + "'" + row[i].ToString().Trim() + "',";
                            break;
                    }
                }
            }
            retStr = retStr.Substring(0, retStr.Length - 1);
            return retStr;

        }
        /// <summary>
        /// This method is used for Extracting Standard Zip files (NEIO,NXIO)
        /// </summary>
        /// <param name="zipFilePath"></param>
        private void ExtractZipFile(string zipFilePath)
        {
            try
            {
                string strText = string.Empty;
                txtMsg.Text = "Extracting standard Zip Files";
                txtMsg.Refresh();
                UdyogZipUnzip.UdyoyZipUnZipUtility file = new UdyogZipUnzip.UdyoyZipUnZipUtility();
                file.UdyogUnzip(zipFilePath + "\\Database\\" + "Nxio.zip", zipFilePath + "\\Database\\Nxio", "");
                file.UdyogUnzip(zipFilePath + "\\Database\\" + "Neio.zip", zipFilePath + "\\Database\\Neio", "");

                txtMsg.Text = "Restoring Neio Database";
                txtMsg.Refresh();
                strText = "If Not Exists( Select [Name] From Master..SysDatabases Where [Name]='NEIO') Begin Create Database NEIO collate SQL_Latin1_General_CP1_CI_AS ";
                strText = strText + " Restore Database NEIO From Disk=N'" + zipFilePath + "\\Database\\Neio\\Neio.Dat" + "' With Move 'Neio' To '" + appPath + "\\Database\\Neio.mdf" + "', Move 'Neio_Log' To '" + appPath + "\\Database\\Neio.ldf" + "',replace  End";
                //strText = "If Exists( Select [Name] From Master..SysDatabases Where [Name]='NEIO') Begin Drop Database NEIO End  Create Database NEIO  ";
                OpenConnection();
                SqlCommand cmd = new SqlCommand(strText, cn);
                cmd.CommandTimeout = 1500;
                cmd.ExecuteNonQuery();

                txtMsg.Text = "Restoring Nxio Database";
                txtMsg.Refresh();
                strText = "If Not Exists( Select [Name] From Master..SysDatabases Where [Name]='NXIO') Begin Create Database NXIO collate SQL_Latin1_General_CP1_CI_AS";
                strText = strText + " Restore Database NXIO From Disk=N'" + zipFilePath + "\\Database\\Nxio\\Nxio.Dat" + "' With Move 'Nxio' To '" + appPath + "\\Database\\Nxio.mdf" + "', Move 'Nxio_Log' To '" + appPath + "\\Database\\Nxio.ldf" + "',replace End";
                OpenConnection();
                cmd = new SqlCommand(strText, cn);
                cmd.CommandTimeout = 1500;
                cmd.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                MessageBox.Show("Error in Extract zip file method: " + e.Message);
            }
        }

        /// <summary>
        ///  This method is used for Validations of the controls
        /// </summary>
        /// <returns></returns>
        public bool CheckValidation()
        {
            int cnt = 0;
            if (txtSFoldPath.Text == "")
            {
                MessageBox.Show("Standard Main Folder Path required to compare...!!!", "Compare File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                btnSFoldPath.Focus();
                return false;
            }
            if (txtSelectPath.Text == "")
            {
                MessageBox.Show("Select the Location to save Files ...!!!", "Compare File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                btnSelectPath.Focus();
                return false;
            }
            if (txtSFoldPath.Text != "")
            {
                if (!System.IO.Directory.Exists(txtSFoldPath.Text))
                {
                    MessageBox.Show("Standard Main folder path does not Exist!", "Compare File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    btnSFoldPath.Focus();
                    return false;
                }

            }
            if (txtSelectPath.Text == "")
            {
                if (!System.IO.Directory.Exists(txtSelectPath.Text))
                {
                    MessageBox.Show("Location to save files does not Exist!", "Compare File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    btnSelectPath.Focus();
                    return false;
                }
            }
            if (chkMainFld.Checked == true)
            {
                cnt = cnt + 1;
            }
            if (chkBmpFld.Checked == true)
            {
                cnt = cnt + 1;
            }
            if (chkClassFld.Checked == true)
            {
                cnt = cnt + 1;
            }
            for (int i = 0; i < dataGridComp.Rows.Count; i++)
            {
                if (dataGridComp.Rows[i].Cells["Sel"].Value.ToString() == "True")
                {
                    cnt = cnt + 1;
                }
            }
            if (cnt == 0)
            {
                MessageBox.Show("Select atleast one criteria for comparison ...!!!", "Compare File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            return true;
        }

        public SqlConnection OpenConnection()
        {
            if (cn == null)
            {
                try
                {
                    cn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while opening connection :" + ex.Message);
                }
            }
            else
            {
                if (cn.State == ConnectionState.Closed)
                {
                    try
                    {
                        cn.Open();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while opening connection :" + ex.Message);
                    }
                }
            }
            return cn;
        }
        /// <summary>
        /// This method is used for comparing folders and copy the missed match file to given path
        /// </summary>
        /// <param name="srcFolderPath">Client Main Folder(Respective folders like Class,Bmp etc)</param>
        /// <param name="targetFolderPath"> Standard Main Folder (Respective folders like Class,Bmp etc)</param>
        /// <param name="copyPath">Where to copy the missed matched (Respective folders like Class,Bmp etc)</param>
        /// <param name="folderName">folders like Class,Bmp etc</param>
        private void CompareFolders(string srcFolderPath, string targetFolderPath, string copyPath, string folderName)
        {
            string filename = "";
            string strText = string.Empty;
            string tmpfilName = string.Empty;
            string exMessage = string.Empty;
            bool exceptionExists = false;
            int logTotalFiles = 0, logNewFiles = 0, logNewerFiles = 0, logOlderFiles = 0, logFilesNotCopied = 0;


            DirectoryInfo d = new DirectoryInfo(srcFolderPath);
            //string[] excFiles = { "USquare.exe", "iTAX.exe", "VUdyogMfg.exe", "VUdyogTrd.exe", "Neio.Dat", "Nxio.Dat", "Vudyog.Dat", "Visudyog.ini", "Vudyog.Mem","USquare.msi","iTAX.msi","VuydogSDK.msi","VudyogSTD.msi","VudyogPro.msi","VudyogEnt.msi" };
            string[] excFiles = { "Neio.Dat", "Nxio.Dat", "Vudyog.Dat", "Visudyog.ini", "Vudyog.Mem", "USquare.msi", "iTAX.msi", "Visual Udyog SDK.msi", "Visual Udyog STD.msi", "Visual Udyog PRO.msi", "Visual Udyog ENT.msi", "VudyogMFG.msi", "VudyogTRD.msi" }; //10/05/2011 Changed by Shrikant S.
            logTotalFiles = d.GetFiles().Length;

            //progressBar1.Maximum = d.GetFiles().Length;
            //progressBar1.Value = 0;
            foreach (string file in Directory.GetFiles(srcFolderPath))
            {
                filename = System.IO.Path.GetFileName(file);
                if (!Inlist(filename, excFiles))
                {
                    if (!CheckFileExistence(targetFolderPath, filename, excFiles))
                    {
                        exMessage = "";
                        exceptionExists = false;
                        try
                        {
                            if (!System.IO.Directory.Exists(copyPath + "\\" + folderName))
                            {
                                System.IO.Directory.CreateDirectory(copyPath + "\\" + folderName);
                            }
                            //System.IO.File.Copy(file, copyPath + "\\" + folderName + "\\" + filename, true);      //Commented by Shrikant S. on 29/09/2011

                            //Added by Shrikant S. on 29/09/2011        //Start
                            tmpfilName = copyPath + "\\" + folderName + "\\" + filename;
                            System.IO.File.Copy(file, tmpfilName, true);
                            File.SetAttributes(tmpfilName, FileAttributes.Normal);
                            File.SetLastWriteTime(tmpfilName, File.GetLastWriteTime(file));
                            File.SetCreationTime(tmpfilName, File.GetCreationTime(file));
                            //Added by Shrikant S. on 29/09/2011        //End

                            txtMsg.Text = "Copying file " + filename;
                            txtMsg.Refresh();
                            logNewFiles = logNewFiles + 1;
                            strText = filename.PadRight(70, ' ') + "New".PadRight(20, ' ') + "File Copied Successfully";
                        }
                        catch (Exception ex)
                        {
                            logFilesNotCopied = logFilesNotCopied + 1;
                            strText = filename.PadRight(70, ' ') + "New".PadRight(20, ' ') + "File Not Copied. ";
                            exceptionExists = true;
                            exMessage = ex.Message;
                            //MessageBox.Show("Error in Compare folders method: "+ex.Message);
                        }
                        finally
                        {
                            WriteLogToFile(strText);
                            if (exceptionExists == true)
                            {
                                WriteLogToFile(" ".PadRight(55, ' ') + "C01".PadRight(15, ' ') + exMessage);
                            }
                        }

                    }
                    else
                    {
                        bool copy = false;
                        exMessage = "";
                        exceptionExists = false;

                        switch (CheckLastModified(srcFolderPath, targetFolderPath, filename))
                        {
                            case 1:
                                //copy = true;
                                ////strText = filename + " file from the Location " + srcFolderPath.Trim() + " is Older than the file from the location " + targetFolderPath.Trim()+"\\"+filename + " |";
                                //strText = filename.PadRight(70, ' ') + "Older".PadRight(20,' ') + "File Copied Successfully";
                                //logOlderFiles = logOlderFiles + 1;
                                copy = false;
                                strText = filename.PadRight(70, ' ') + " ".PadRight(20, ' ') + "File Not Copied, since File is Older.";
                                logFilesNotCopied = logFilesNotCopied + 1;
                                break;
                            case 2:
                                copy = true;
                                //strText = filename + " file size from the Location " + srcFolderPath.Trim() + " is mismatched with the file from the location " + targetFolderPath.Trim() + "\\" + filename + " |";
                                strText = filename.PadRight(70, ' ') + "New".PadRight(20, ' ') + "File Copied Successfully";
                                logNewFiles = logNewFiles + 1;
                                break;
                            case 3:
                                copy = true;
                                //strText = filename + " file from the Location " + srcFolderPath.Trim() + " is Newer than the file from the location " + targetFolderPath.Trim() + "\\" + filename + " |";
                                strText = filename.PadRight(70, ' ') + "Newer".PadRight(20, ' ') + "File Copied Successfully";
                                logNewerFiles = logNewerFiles + 1;
                                break;
                            case 4:
                                copy = false;
                                strText = filename.PadRight(70, ' ') + " ".PadRight(20, ' ') + "File Not Copied, since File is Matching.";
                                logFilesNotCopied = logFilesNotCopied + 1;
                                break;
                        }
                        if (copy == true)
                        {
                            try
                            {
                                txtMsg.Text = "Copying file " + filename;
                                txtMsg.Refresh();
                                if (!System.IO.Directory.Exists(copyPath + "\\" + folderName))
                                {
                                    System.IO.Directory.CreateDirectory(copyPath + "\\" + folderName);
                                }
                                //System.IO.File.Copy(file, copyPath + "\\" + folderName + "\\" + filename, true);

                                //Added by Shrikant S. on 29/09/2011        //Start
                                tmpfilName = copyPath + "\\" + folderName + "\\" + filename;
                                System.IO.File.Copy(file, tmpfilName, true);
                                File.SetAttributes(tmpfilName, FileAttributes.Normal);
                                File.SetLastWriteTime(tmpfilName, File.GetLastWriteTime(file));
                                File.SetCreationTime(tmpfilName, File.GetCreationTime(file));
                                //Added by Shrikant S. on 29/09/2011        //End


                            }
                            catch (Exception ex)
                            {
                                exceptionExists = true;
                                exMessage = ex.Message;
                                logFilesNotCopied = logFilesNotCopied + 1;
                                //MessageBox.Show("Error in Compare folders method: " + ex.Message);
                            }
                        }
                        WriteLogToFile(strText);
                        if (exceptionExists == true)
                        {
                            WriteLogToFile(" ".PadRight(55, ' ') + "C01".PadRight(15, ' ') + exMessage);
                        }
                    }
                }
                //                progressBar1.Value = progressBar1.Value + 1;
            }
            WriteLogToFile(Convert.ToString('~').PadRight(125, '~'));
            WriteLogToFile("Total No. of Files :" + logTotalFiles.ToString());
            WriteLogToFile("No. of New Files (Not Existing):" + logNewFiles.ToString());
            WriteLogToFile("No. of Newer Files (Existing):" + logNewerFiles.ToString());
            WriteLogToFile("No. of Older Files (Existing):" + logOlderFiles.ToString());
            WriteLogToFile("No. of Files Not Copied :" + logFilesNotCopied.ToString());
            WriteLogToFile("Files Copied to the Path  :" + copyPath + "\\" + folderName);
            WriteLogToFile(" ");
            WriteLogToFile(" ");
        }
        /// <summary>
        /// This method is used for checking which is the last modified file
        /// </summary>
        /// <param name="srcParth">Client folder path</param>
        /// <param name="targetPath">Standard folder path</param>
        /// <param name="fileName">Name of the File</param>
        /// <returns></returns>
        public int CheckLastModified(string srcParth, string targetPath, string fileName)
        {
            string file = string.Empty;
            DateTime srcFileTime, targetFileTime;

            string srcFile = srcParth + "\\" + fileName;
            string targetFile = targetPath + "\\" + fileName;
            FileInfo srcFileInfo = new FileInfo(@srcFile);
            FileInfo targetFileInfo = new FileInfo(@targetFile);


            srcFileTime = Convert.ToDateTime(srcFileInfo.LastWriteTime.ToString(ReturnDateFormat()));
            targetFileTime = Convert.ToDateTime(targetFileInfo.LastWriteTime.ToString(ReturnDateFormat()));
            if (DateTime.Compare(srcFileTime, targetFileTime) < 0)
            {
                return 1;
            }
            else if (DateTime.Compare(srcFileTime, targetFileTime) == 0)
            {
                long srcFileLength = srcFileInfo.Length;
                long targetFileLength = targetFileInfo.Length;
                if (srcFileLength != targetFileLength && !Inlist(System.IO.Path.GetExtension(srcFile).ToUpper(), new string[] { ".SQL", ".DAT" }))
                {
                    return 2;
                }
                return 4;
            }
            else
            {
                return 3;
            }
        }
        /// <summary>
        /// This method is used for Checking the file existence 
        /// </summary>
        /// <param name="targetPath">Search file in this path</param>
        /// <param name="srcFile">FileName</param>
        /// <param name="excFiles">Exclude files for checking</param>
        /// <returns></returns>
        public bool CheckFileExistence(string targetPath, string srcFile, string[] excFiles)
        {
            string filename = "";
            foreach (string file in Directory.GetFiles(targetPath))
            {
                filename = System.IO.Path.GetFileName(file);
                if (!Inlist(filename, excFiles))
                {
                    if (filename.ToUpper() == srcFile.ToUpper())
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// This method is used for checking the value is in given list or not
        /// </summary>
        /// <param name="str">string to check</param>
        /// <param name="arrItems">array Items</param>
        /// <returns></returns>
        public bool Inlist(string str, string[] arrItems)   //shrikant
        {
            for (int i = 0; i < arrItems.Length; i++)
            {
                if (str.ToUpper() == arrItems[i].ToString().ToUpper())
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// This method is used for writing log to txt File
        /// </summary>
        /// <param name="strText">string to write to file</param>
        public void WriteLogToFile(string strText)
        {
            string[] script;
            string filePath = string.Empty;
            script = strText.Split('|');
            foreach (string x in script)
            {
                try
                {
                    //if (!string.IsNullOrEmpty(x))
                    //{
                    if (!System.IO.Directory.Exists(txtSelectPath.Text + "\\MainAppFolder"))
                    {
                        System.IO.Directory.CreateDirectory(txtSelectPath.Text + "\\MainAppFolder");
                    }
                    filePath = txtSelectPath.Text + "\\MainAppFolder";
                    using (FileStream file = new FileStream(filePath + "\\" + "File_Compare_Log.txt", FileMode.Append, FileAccess.Write))
                    {
                        StreamWriter streamWriter = new StreamWriter(file);
                        streamWriter.WriteLine(x + "\n");
                        streamWriter.Close();
                    }
                    //}
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error in Write Log File Method: " + ex.Message);
                }
            }
            // MessageBox.Show("Script File generated Successfully...");

        }

        /// <summary>
        /// This method is used for Making the zip 
        /// </summary>
        /// <param name="scrPath">Path of the folder with folder Name</param>
        /// <param name="targetPath">path of the zip with filename</param>
        private void MakeZip(string scrPath)
        //private void MakeZip(string scrPath,string targetPath)
        {
            try
            {
                //txtMsg.Text = "Making Zip file " + targetPath;
                //txtMsg.Refresh();
                string targetPath = string.Empty;
                string tmpfilName = string.Empty;
                UdyogZipUnzip.UdyoyZipUnZipUtility file = new UdyogZipUnzip.UdyoyZipUnZipUtility();
                foreach (string dir in System.IO.Directory.GetDirectories(scrPath))
                {
                    targetPath = dir + ".zip";
                    file.UdyogZip(dir, targetPath, "");
                }
                foreach (string fil in System.IO.Directory.GetFiles(scrPath))
                {
                    if (fil.IndexOf(".zip") < 0)
                    {
                        if (System.IO.Path.GetFileNameWithoutExtension(fil) != "File_Compare_Log")
                        {
                            targetPath = "Common.zip";
                            if (!System.IO.Directory.Exists(scrPath + "\\" + "Common"))
                            {
                                System.IO.Directory.CreateDirectory(scrPath + "\\" + "Common");
                            }
                            //System.IO.File.Move(fil, scrPath + "\\" + "Common\\" + System.IO.Path.GetFileName(fil).ToString());   //Commented by Shrikant S. on 29/09/2011
                            //Added by Shrikant S. on 29/09/2011        //Start
                            tmpfilName = scrPath + "\\" + "Common\\" + System.IO.Path.GetFileName(fil).ToString();
                            System.IO.File.Move(fil, tmpfilName);
                            File.SetAttributes(tmpfilName, FileAttributes.Normal);
                            File.SetLastWriteTime(tmpfilName, File.GetLastWriteTime(fil));
                            File.SetCreationTime(tmpfilName, File.GetCreationTime(fil));
                            //Added by Shrikant S. on 29/09/2011        //End
                        }

                    }
                }
                if (System.IO.Directory.Exists(scrPath + "\\" + "Common"))
                {
                    file.UdyogZip(scrPath + "\\" + "Common", scrPath + "\\" + targetPath, "");
                }
                DeleteFile(scrPath);
            }
            catch (Exception e)
            {
                MessageBox.Show("Error in Making Zip file method: " + e.Message, "File Compare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// This method is used for deleting the files from the folder.
        /// </summary>
        /// <param name="scrPath">Path of the folder with folder name to delete files</param>
        private void DeleteFile(string scrPath)
        {
            try
            {
                if (System.IO.Directory.Exists(scrPath))
                {
                    foreach (string fil in System.IO.Directory.GetFiles(scrPath))
                    {
                        if (fil.IndexOf(".zip") < 0)
                        {
                            if (File.Exists(fil))
                            {
                                if (System.IO.Path.GetFileName(fil) != "File_Compare_Log.txt")
                                {
                                    File.Delete(fil);
                                    txtMsg.Text = "Deleting file " + fil;
                                    txtMsg.Refresh();
                                }
                            }
                        }
                    }
                    foreach (string dir in System.IO.Directory.GetDirectories(scrPath))
                    {
                        DeleteFile(dir);
                        txtMsg.Text = "Deleting Directory " + dir;
                        txtMsg.Refresh();
                    }
                    string[] filecount = System.IO.Directory.GetFiles(scrPath);
                    if (filecount.Length == 0)
                    {
                        Directory.Delete(scrPath);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in file Deleting method. :" + ex.Message, "File Compare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// This method is used for creating the script files 
        /// </summary>
        /// <param name="SrcDatabase">Client Database Name</param>
        /// <param name="targetDatabase">Standard Database Name (Neio,Nxio)</param>
        /// <param name="scriptFilePath">Path to store script files(i.e. Company folder path of the zip)</param>
        private void CreateScript(string SrcDatabase, string targetDatabase, string scriptFilePath)
        {
            string strText = string.Empty;
            _Dbname = SrcDatabase;
            DataTable Db = new DataTable();
            //DataColumn col = new DataColumn("tblNm", typeof(System.String));
            //Db.Columns.Add(col);
            //col = new DataColumn("KeyFields", typeof(System.String));
            //Db.Columns.Add(col);
            //col = new DataColumn("ExcludeFlds", typeof(System.String));
            //Db.Columns.Add(col);
            //DataRow dr = Db.NewRow();
            //dr["tblNm"] = "Com_menu";
            //dr["KeyFields"] = "PadName,BarName";
            //dr["ExcludeFlds"] = "Range,NewRange,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
            //Db.Rows.Add(dr);
            //dr = Db.NewRow();
            //dr["tblNm"] = "R_status";
            //dr["KeyFields"] = "Group,Desc,Rep_Nm";
            //dr["ExcludeFlds"] = "NewGroup,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
            //Db.Rows.Add(dr);
            //dr = Db.NewRow();
            //dr["tblNm"] = "Lother";
            //dr["KeyFields"] = "E_Code,Fld_nm";
            //dr["ExcludeFlds"] = "e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_,user_name,sysdate,passroute,";
            //Db.Rows.Add(dr);
            //dr = Db.NewRow();
            //dr["tblNm"] = "Lcode";
            //dr["KeyFields"] = "Entry_ty";
            //dr["ExcludeFlds"] = "cd";
            //Db.Rows.Add(dr);

            OpenConnection();
            //da = new SqlDataAdapter("Select tblNm=Upper([Name]),KeyFields=space(4000),ExcludeFlds=space(4000) From " + SrcDatabase + "..SysObjects Where xType='U' and [Name]='Com_menu' Order By [Name]", cn);
            da = new SqlDataAdapter("Select tblNm=Upper([Name]),KeyFields=space(4000),ExcludeFlds=space(4000) From " + SrcDatabase + "..SysObjects Where xType='U' Order By [Name]", cn); 
            da.Fill(ds, "tbllist");

            ds.ReadXml("XMLTable.xml", XmlReadMode.Auto);
            for (int i = 0; i < ds.Tables["tbllist"].Rows.Count; i++)
            {
                for (int j = 0; j < ds.Tables["TableList"].Rows.Count; j++)
                {
                    if (ds.Tables["tbllist"].Rows[i]["tblNm"].ToString().ToUpper() == ds.Tables["TableList"].Rows[j]["tblNm"].ToString().ToUpper())
                    {
                        ds.Tables["tbllist"].Rows[i]["KeyFields"] = ds.Tables["TableList"].Rows[j]["KeyFields"];
                        ds.Tables["tbllist"].Rows[i]["ExcludeFlds"] = ds.Tables["TableList"].Rows[j]["ExcludeFlds"];
                    }
                }
                //switch (ds.Tables["tbllist"].Rows[i]["tblNm"].ToString())
                //{
                //    case "COM_MENU":
                //        ds.Tables["tbllist"].Rows[i]["KeyFields"] = "PadName,BarName";
                //        ds.Tables["tbllist"].Rows[i]["ExcludeFlds"] = "Range,NewRange,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
                //        break;
                //    case "R_STATUS":
                //        ds.Tables["tbllist"].Rows[i]["KeyFields"] = "Group,Desc,Rep_Nm";
                //        ds.Tables["tbllist"].Rows[i]["ExcludeFlds"] = "Range,NewRange,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
                //        break;
                //    case "LOTHER":
                //        ds.Tables["tbllist"].Rows[i]["KeyFields"] = "E_Code,Fld_nm";
                //        ds.Tables["tbllist"].Rows[i]["ExcludeFlds"] = "e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_,user_name,sysdate,passroute,";
                //        break;
                //    case "LCODE":
                //        ds.Tables["tbllist"].Rows[i]["KeyFields"] = "Entry_ty";
                //        ds.Tables["tbllist"].Rows[i]["ExcludeFlds"] = "cd,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
                //        break;
                //    case "DCMAST":
                //        ds.Tables["tbllist"].Rows[i]["KeyFields"] = "Entry_ty,Fld_Nm";
                //        ds.Tables["tbllist"].Rows[i]["ExcludeFlds"] = "corder,e_,n_,r_,t_,i_,o_,b_,x_,xtvs_,dsni_,mcur_,tds_";
                //        break;
                //    default:
                //        break;
                //}
            }
            Db = ds.Tables["tbllist"];

            WriteScriptToFile("01_Struture_script", "--" + DateTime.Now.ToString() + " -- File has been auto generated...", scriptFilePath);
            for (int i = 0; i < Db.Rows.Count; i++)
            {
                WriteScriptToFile("01_Struture_script", "--Generating Script of the table " + Db.Rows[i]["tblNm"].ToString() + " for the structure Script and Records \t \t --Start", scriptFilePath);
                GenerateStructureScript(SrcDatabase, targetDatabase, Db.Rows[i]["tblNm"].ToString(), scriptFilePath);
                for (int j = 0; j < ds.Tables["TableList"].Rows.Count; j++)
                {
                    if (Db.Rows[i]["tblNm"].ToString().ToUpper() == ds.Tables["TableList"].Rows[j]["tblNm"].ToString().ToUpper())
                    {
                        GenerateRecordScript(SrcDatabase, targetDatabase, Db.Rows[i]["tblNm"].ToString(), Db.Rows[i]["KeyFields"].ToString(), Db.Rows[i]["ExcludeFlds"].ToString(), scriptFilePath);
                    }
                }

                WriteScriptToFile("01_Struture_script", "--Generating Script of the table " + Db.Rows[i]["tblNm"].ToString() + " for the structure Script and Records \t \t --End", scriptFilePath);
            }
            CreateTableProcedureScript(SrcDatabase, targetDatabase, scriptFilePath);
        }
        /// <summary>
        /// This method is used for generating structure script of the existing table for Com_menu, R_status, Lcode, Lother
        /// </summary>
        /// <param name="SrcDb">Client Database Name</param>
        /// <param name="TargetDb">Standard Database Name </param>
        /// <param name="tblNm">Table Name for scripting</param>
        /// <param name="scriptFilePath">Path to store script files(i.e. Company folder path of the zip)</param>
        public void GenerateStructureScript(string SrcDb, string TargetDb, string tblNm, string scriptFilePath)
        {
            string strText = string.Empty;
            txtMsg.Text = "Genearating Structure of the table " + tblNm;
            txtMsg.Refresh();
            //SqlCommand cmd = new SqlCommand("Select [Name] From " + SrcDb + "..SysObjects Where xType='P' and [Name]='Usp_Ent_Gen_Script'", cn);
            //ans = cmd.ExecuteScalar();
            da = new SqlDataAdapter("Use " + SrcDb + " Execute Usp_Ent_Gen_Script '" + SrcDb + "','" + TargetDb + "','" + tblNm + "'", cn);
            da.Fill(ds, tblNm + "_vw");
            for (int i = 0; i < ds.Tables[tblNm + "_vw"].Rows.Count; i++)
            {
                strText = strText + ds.Tables[tblNm + "_vw"].Rows[i]["Query"].ToString() + "\n";
            }
            WriteScriptToFile("01_Struture_script", strText + "|", scriptFilePath);
        }
        /// <summary>
        /// This method is used for Generating the script for Record Update/Insert
        /// </summary>
        /// <param name="SrcDb">Client Database Name</param>
        /// <param name="TargetDb">Standard Database Name</param>
        /// <param name="tblNm">Table name</param>
        /// <param name="keyflds">Key fields of the table</param>
        /// <param name="excludeflds">Exclude the fields from checking</param>
        /// <param name="scriptFilePath">Script file path </param>
        public void GenerateRecordScript(string SrcDb, string TargetDb, string tblNm, string keyflds, string excludeflds, string scriptFilePath)
        {
            DataTable srcTable, targetTable;
            string strText = string.Empty;
            string[] arrItem = keyflds.Split(',');
            bool exists;
            int counter;
            srcTable = GetDataTable(SrcDb, tblNm, "");
            targetTable = GetDataTable(TargetDb, tblNm, "");
            txtMsg.Text = "Genearating Record script of the table " + tblNm;
            txtMsg.Refresh();
            WriteScriptToFile("02_Insert_Update_script", "-- Generating Record script of the table " + tblNm + " |", scriptFilePath);
            for (int i = 0; i < srcTable.Rows.Count; i++)
            {
                exists = false;
                if (targetTable != null)
                {
                    for (int j = 0; j < targetTable.Rows.Count; j++)
                    {
                        counter = 0;
                        foreach (string arr in arrItem)
                        {
                            if (srcTable.Rows[i][arr].ToString().ToUpper().Trim() == targetTable.Rows[j][arr].ToString().ToUpper().Trim())
                            {
                                counter++;
                            }
                        }
                        if (counter == arrItem.Length)
                        {
                            exists = true;
                            // Added code for remove update string of following tables as per requirement. //12/05/2011
                            string[] arr = { "R_STATUS", "LCODE", "DCMAST", "STAX_MAS" };   
                            bool has=Array.IndexOf(arr,tblNm.ToUpper())>=0;
                            // Added code for remove update string of following tables as per requirement. //12/05/2011
                            if(has==false)
                            {
                                strText = GetUpdateString(srcTable, targetTable, srcTable.Rows[i], targetTable.Rows[j], tblNm, keyflds, excludeflds);
                                //strText = strText.Replace("'", "''");
                                WriteScriptToFile("02_Insert_Update_script", (strText == "" ? "" : strText.Trim() + "\n"), scriptFilePath);
                            }
                            break;
                        }
                    }
                }
                if (exists == false)
                {
                    strText = GetInsertString(srcTable, srcTable.Rows[i], tblNm, keyflds) + "|";
                    WriteScriptToFile("02_Insert_Update_script", (strText == "" ? "" : strText.Trim() + "\n"), scriptFilePath);
                }
            }

        }

        /// <summary>
        /// This method is used for getting the Datatable 
        /// </summary>
        /// <param name="DatabaseNm"></param>
        /// <param name="tblName"></param>
        /// <returns></returns>
        public DataTable GetDataTable(string DatabaseNm, string tblName, string cond)
        {
            DataTable dt = new DataTable();
            try
            {
                da = new SqlDataAdapter("Select * From " + DatabaseNm + ".." + tblName + " " + cond, cn);
                da.Fill(dt);
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (dt.Columns[i].ColumnName.ToUpper() == "NEWRANGE" || dt.Columns[i].ColumnName.ToUpper() == "NEWGROUP" || dt.Columns[i].ColumnName.ToUpper() == "CD")
                    {
                        for (int j = 0; j < dt.Rows.Count; j++)
                        {
                            if (dt.Rows[j][i].GetType().ToString()!="System.Byte[]")
                            {
                               dt.Rows[j][i] = "";    
                            }
                            else
                            {
                                dt.Rows[j][i] = null;
                            }
                        }
                    }
                }

            }
            catch (Exception)
            {
                dt = null;
            }
            return dt;
        }
        /// <summary>
        /// This Method is used for generating the Update string for Record
        /// </summary>
        /// <param name="srcDt">Client Database data table(source)</param>
        /// <param name="targetDt">Standard Database data Table(Target)</param>
        /// <param name="srcRow">Source Datarow</param>
        /// <param name="targetRow">Target Datarow</param>
        /// <param name="tblNm">Table Name</param>
        /// <param name="keyflds">Key fields for condition </param>
        /// <param name="excludeflds">Exclude the list of fields from validation</param>
        /// <returns></returns>
        public string GetUpdateString(DataTable srcDt, DataTable targetDt, DataRow srcRow, DataRow targetRow, string tblNm, string keyflds, string excludeflds)
        {
            string retStr = string.Empty;
            string[] arrItem = keyflds.Split(',');
            string[] exclude = excludeflds.Split(',');
            bool exists = true;
            retStr = "Update " + tblNm + " Set ";
            for (int i = 0; i < srcDt.Columns.Count; i++)
            {
                try
                {
                    if (targetRow[srcDt.Columns[i].ColumnName] != null)
                    {
                        if (!Inlist(srcDt.Columns[i].ColumnName, exclude))
                        {
                            if (srcRow[srcDt.Columns[i].ColumnName].ToString() != targetRow[srcDt.Columns[i].ColumnName].ToString())
                            {
                                exists = false;
                                switch (srcRow[srcDt.Columns[i].ColumnName].GetType().ToString())
                                {
                                    case "System.Int16":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt16(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                        break;
                                    case "System.Int32":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt32(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                        break;
                                    case "System.Int64":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt64(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                        break;
                                    case "System.Double":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDouble(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                        break;
                                    case "System.Decimal":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDecimal(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                                        break;
                                    case "System.String":
                                    case "System.DBNull":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToString(srcRow[i].ToString() == null ? "" : srcRow[i].ToString().Replace("'", "''")).ToString().Trim() + "',";
                                        break;
                                    case "System.DateTime":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToDateTime(srcRow[i].ToString() == null ? "01/01/1900" : srcRow[i]).ToString("MM/dd/yyyy hh:mm:ss").Trim() + "',";
                                        break;
                                    case "System.Boolean":
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + (srcRow[i].ToString().Trim().ToUpper() == null ? 0 : (srcRow[i].ToString().Trim() == "True" ? 1 : 0)) + ",";
                                        break;
                                    default:
                                        retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + srcRow[i].ToString().Trim() + "',";
                                        break;
                                }
                                //break;
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    exists = false;
                    //break;
                    switch (srcRow[srcDt.Columns[i].ColumnName].GetType().ToString())
                    {
                        case "System.Int16":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt16(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int32":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt32(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int64":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToInt64(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Double":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDouble(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.Decimal":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + Convert.ToDecimal(srcRow[i].ToString() == null ? 0 : srcRow[i]).ToString().Trim() + ",";
                            break;
                        case "System.String":
                        case "System.DBNull":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToString(srcRow[i].ToString() == null ? "" : srcRow[i].ToString().Replace("'", "''")).ToString().Trim() + "',";
                            break;
                        case "System.DateTime":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + Convert.ToDateTime(srcRow[i].ToString() == null ? "01/01/1900" : srcRow[i]).ToString("MM/dd/yyyy hh:mm:ss").Trim() + "',";
                            break;
                        case "System.Boolean":
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + (srcRow[i].ToString().Trim().ToUpper() == null ? 0 : (srcRow[i].ToString().Trim() == "True" ? 1 : 0)) + ",";
                            break;
                        default:
                            retStr = retStr + "[" + srcDt.Columns[i].ColumnName + "]=" + "'" + srcRow[i].ToString().Trim() + "',";
                            break;
                    }
                }




            }
            if (exists == false)
            {

                retStr = retStr.Substring(0, retStr.Length - 1) + " Where ";
                foreach (string arr in arrItem)
                {
                    retStr = retStr + " [" + arr.Trim() + "]= '" + srcRow[arr.Trim()].ToString().Trim() + "' And ";
                }
                retStr = retStr.Substring(0, retStr.Length - 4);
            }
            else
            {
                retStr = "";
            }
            return retStr;
        }
        /// <summary>
        /// This method is used for generating the Insert String of Record
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="row"></param>
        /// <param name="tblNm"></param>
        /// <param name="keyflds"></param>
        /// <returns></returns>
        public string GetInsertString(DataTable dt, DataRow row, string tblNm, string keyflds)
        {
            string retStr = string.Empty;
            string[] arrItem = keyflds.Split(',');
            retStr = "If Not Exists (Select [" + arrItem[0] + "] From " + tblNm + " Where ";
            foreach (string arr in arrItem)
            {
                retStr = retStr + "[" + arr + "]='" + row[arr].ToString().Trim() + "' And ";
            }
            retStr = retStr.Substring(0, retStr.Length - 4) + ") Begin " + " Insert Into " + tblNm + " (";
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                retStr = retStr + "[" + dt.Columns[i].ColumnName + "],";
            }
            retStr = retStr.Substring(0, retStr.Length - 1) + " ) Values (";

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                string x = dt.Columns[i].ColumnName;
                switch (dt.Columns[i].DataType.ToString())
                {
                    case "System.Int16":
                        retStr = retStr + Convert.ToInt16(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Int32":
                        retStr = retStr + Convert.ToInt32(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Int64":
                        retStr = retStr + Convert.ToInt64(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Double":
                        retStr = retStr + Convert.ToDouble(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.Decimal":
                        retStr = retStr + Convert.ToDecimal(row[i].GetType().ToString() == "System.DBNull" ? 0 : row[i]).ToString().Trim() + ",";
                        break;
                    case "System.String":
                    case "System.DBNull":
                        retStr = retStr + "'" + Convert.ToString(row[i].GetType().ToString() == "System.DBNull" ? "" : row[i].ToString().Replace("'", "''").Trim()) + "',";
                        break;
                    case "System.DateTime":
                        //retStr = retStr + "'" + Convert.ToDateTime(row[i].GetType().ToString() == "System.DBNull" ? "01/01/1900" : row[i]).ToString().Trim() + "',";
                        retStr = retStr + "'" + Convert.ToDateTime(row[i].GetType().ToString() == "System.DBNull" ? "01/01/1900" : row[i]).ToString("MM/dd/yyyy HH:mm:ss").Trim() + "',";   //Changed By Shrikant S. on 09/05/2011
                        break;
                    case "System.Boolean":
                        retStr = retStr + (row[i].GetType().ToString().Trim().ToUpper() == "System.DBNull" ? 0 : (row[i].ToString().Trim() == "True" ? 1 : 0)) + ",";
                        break;
                    case "System.Byte[]":
                        retStr = retStr + ("null")+ ",";
                        break;
                    default:
                        retStr = retStr + "'" + row[i].ToString().Trim() + "',";
                        break;
                }
            }
            retStr = retStr.Substring(0, retStr.Length - 1) + ") End ";
            return retStr;
        }
        /// <summary>
        /// This method is used for Writing script to the file
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="strText"></param>
        /// <param name="scriptFilePath"></param>
        public void WriteScriptToFile(string fileName, string strText, string scriptFilePath)
        {
            string[] script;
            string filePath = string.Empty;
            script = strText.Split('|');
            if (!System.IO.Directory.Exists(scriptFilePath))        // Added By Shrikant S. on 31/03/2012 for Bug-3228
            {
                System.IO.Directory.CreateDirectory(scriptFilePath);
            }
            foreach (string x in script)
            {
                try
                {
                    if (!string.IsNullOrEmpty(x))
                    {
                        using (FileStream file = new FileStream(scriptFilePath + "\\" + fileName + ".Sql", FileMode.Append, FileAccess.Write))
                        {
                            StreamWriter streamWriter = new StreamWriter(file);
                            streamWriter.WriteLine(x + "\n");
                            streamWriter.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error in Write Script File Method: " + ex.Message);
                }
            }
            // MessageBox.Show("Script File generated Successfully...");

        }
        /// <summary>
        /// This Method is used for creating script of New table and calling another method for script of procedure
        /// </summary>
        /// <param name="SrcDatabase"></param>
        /// <param name="targetDatabase"></param>
        /// <param name="scriptFilePath"></param>
        public void CreateTableProcedureScript(string SrcDatabase, string targetDatabase, string scriptFilePath)
        {
            string strText = string.Empty;
            bool exists = false;

            da = new SqlDataAdapter("Select [Name] as tblNm From " + SrcDatabase + "..SysObjects Where [name] Not In (Select [Name] from " + targetDatabase + "..SysObjects where xType='U') and xType='U'", cn);
            if (ds.Tables["tbl_Vw"] != null)
            {
                ds.Tables.Remove(ds.Tables["tbl_Vw"]);
            }
            da.Fill(ds, "tbl_Vw");
            ServerConnection conn = new ServerConnection(_serverName, _Uid, _Pwd);
            Server server = new Server(conn);
            Database dbname = server.Databases[_Dbname];
            for (int i = 0; i < ds.Tables["tbl_Vw"].Rows.Count; i++)
            {
                Table tbl = dbname.Tables[ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString()];

                StringCollection script = tbl.Script();

                string[] scriptArray = new string[script.Count];
                script.CopyTo(scriptArray, 0);
                txtMsg.Text = "Genearating Script of the new table " + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString().ToUpper().Trim();
                txtMsg.Refresh();
                WriteScriptToFile("09_Table_script", "--Generating Script file for the table " + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString().ToUpper() + " \t --Start", scriptFilePath);
                strText = "If Not Exists (Select [Name] From SysObjects Where xType='U' and [Name]='" + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString().ToUpper() + "') Begin ";
                for (int j = 0; j < scriptArray.Length; j++)
                {
                    strText = strText + scriptArray[j].ToString() + "\t";
                }
                strText = strText + " End ";
                //toolStripLabel1.Text = "Generating Script for the table " + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString();
                //toolStrip1.Refresh();
                WriteScriptToFile("09_Table_script", strText + "| ", scriptFilePath);
                WriteScriptToFile("09_Table_script", "--Generating Script file fr the table " + ds.Tables["tbl_Vw"].Rows[i]["tblNm"].ToString().ToUpper() + " \t --End", scriptFilePath);
            }

            da = new SqlDataAdapter("Select [Name] as srcNm,xType as fType From " + SrcDatabase + "..SysObjects Where xType In ('P','V') Order by xType,[Name]", cn);
            //da = new SqlDataAdapter("Select [Name] as procNm From " + cboDatabase.SelectedItem.ToString() + "..SysObjects Where [name] Not In (Select [Name] from " + cboStdDatabase.SelectedItem.ToString() + "..SysObjects where xType='P') and xType='P'", cn);
            if (ds.Tables["src_Vw"] != null)
            {
                ds.Tables.Remove(ds.Tables["src_Vw"]);
            }
            da.Fill(ds, "src_Vw");

            da = new SqlDataAdapter("Select [Name] as targetNm,xType as fType From " + targetDatabase + "..SysObjects Where xType in ('P','V') Order by xType,[Name]", cn);
            if (ds.Tables["target_Vw"] != null)
            {
                ds.Tables.Remove(ds.Tables["target_Vw"]);
            }
            da.Fill(ds, "target_Vw");
            Database targetDbName = server.Databases[targetDatabase];
            for (int i = 0; i < ds.Tables["src_Vw"].Rows.Count; i++)
            {
                exists = false;
                for (int j = 0; j < ds.Tables["target_Vw"].Rows.Count; j++)
                {
                    if (ds.Tables["src_Vw"].Rows[i]["srcNm"].ToString() == ds.Tables["target_Vw"].Rows[j]["targetNm"].ToString())
                    {
                        exists = true;
                        if (ds.Tables["src_Vw"].Rows[i]["fType"].ToString().Trim() == "P")
                        {
                            StoredProcedure srcStoreProc = dbname.StoredProcedures[ds.Tables["src_Vw"].Rows[i]["srcNm"].ToString()];
                            StoredProcedure targetStoreProc = targetDbName.StoredProcedures[ds.Tables["target_Vw"].Rows[j]["targetNm"].ToString()];
                            DateTime srcTime = Convert.ToDateTime(srcStoreProc.DateLastModified.ToString(ReturnDateFormat()));
                            DateTime targetTime = Convert.ToDateTime(targetStoreProc.DateLastModified.ToString(ReturnDateFormat()));
                            //DateTime srcTime = Convert.ToDateTime(srcStoreProc.DateLastModified.ToString("MM/dd/yyyy hh:mm"));
                            //DateTime targetTime = Convert.ToDateTime(targetStoreProc.DateLastModified.ToString("MM/dd/yyyy hh:mm"));
                            if (DateTime.Compare(srcTime, targetTime) < 0)
                            {
                                //Generate_Procedure_View_Script(srcStoreProc,"P", 1, scriptFilePath); 
                            }
                            else if (DateTime.Compare(srcTime, targetTime) == 0)
                            {
                            }
                            else
                            {
                                Generate_Procedure_View_Script(srcStoreProc, "P", 2, scriptFilePath);
                            }
                        }
                        if (ds.Tables["src_Vw"].Rows[i]["fType"].ToString().Trim() == "V")
                        {
                            Microsoft.SqlServer.Management.Smo.View srcView = dbname.Views[ds.Tables["src_Vw"].Rows[i]["srcNm"].ToString()];
                            Microsoft.SqlServer.Management.Smo.View targetView = targetDbName.Views[ds.Tables["target_Vw"].Rows[j]["targetNm"].ToString()];
                            DateTime srcTime = Convert.ToDateTime(srcView.DateLastModified.ToString(ReturnDateFormat()));
                            DateTime targetTime = Convert.ToDateTime(targetView.DateLastModified.ToString(ReturnDateFormat()));
                            if (DateTime.Compare(srcTime, targetTime) < 0)
                            {
                                //Generate_Procedure_View_Script(srcView, "V", 1, scriptFilePath); 
                            }
                            else if (DateTime.Compare(srcTime, targetTime) == 0)
                            {
                            }
                            else
                            {
                                Generate_Procedure_View_Script(srcView, "V", 2, scriptFilePath);
                            }
                        }
                        break;
                    }
                }
                if (exists == false)
                {

                    switch (ds.Tables["src_Vw"].Rows[i]["fType"].ToString().Trim())
                    {
                        case "P":
                            StoredProcedure srcStoreProc = dbname.StoredProcedures[ds.Tables["src_Vw"].Rows[i]["srcNm"].ToString()];
                            Generate_Procedure_View_Script(srcStoreProc, "P", 3, scriptFilePath);
                            break;
                        case "V":
                            Microsoft.SqlServer.Management.Smo.View srcView = dbname.Views[ds.Tables["src_Vw"].Rows[i]["srcNm"].ToString()];
                            Generate_Procedure_View_Script(srcView, "V", 3, scriptFilePath);
                            break;
                    }


                }

            }
            conn.Disconnect();
            server.ConnectionContext.Disconnect();
        }

        /// <summary>
        /// This method is used for generating the script of the procedure.
        /// </summary>
        /// <param name="storeProc"></param>
        /// <param name="type"></param>
        /// <param name="scriptFilePath"></param>
        private void Generate_Procedure_View_Script(Object scriptFile, string fileType, int type, string scriptFilePath)
        {
            StringCollection cmdLines;
            string fileName = string.Empty;
            string strText = string.Empty;
            string[] scriptLineArray;

            switch (fileType)
            {
                case "P":
                    cmdLines = ((StoredProcedure)scriptFile).Script();
                    fileName = ((StoredProcedure)scriptFile).Name.ToUpper();
                    scriptLineArray = new string[cmdLines.Count];
                    cmdLines.CopyTo(scriptLineArray, 0);

                    txtMsg.Text = "Genearating Script of the file " + fileName;
                    txtMsg.Refresh();

                    WriteScriptToFile("08_Procedure_script", "--Generating Script for the procedure " + fileName + " \t --Start", scriptFilePath);
                    switch (type)
                    {
                        case 1:
                            WriteScriptToFile("08_Procedure_script", "--This procedure is Missed Match(i.e. this stored procedure is older ) ", scriptFilePath);
                            break;
                        case 2:
                            WriteScriptToFile("08_Procedure_script", "--This procedure is Missed Match(i.e. This stored procedure is Newer )", scriptFilePath);
                            break;
                        case 3:
                            WriteScriptToFile("08_Procedure_script", "--This procedure is Newly added", scriptFilePath);
                            break;
                    }
                    strText = "If Exists (Select [Name] From SysObjects Where xType='P' and [Name]='" + fileName + "') \nBegin \n\t Drop Procedure " + fileName + " \n End \nGo\n \n";
                    for (int j = 2; j < scriptLineArray.Length; j++)
                    {
                        strText = strText + scriptLineArray[j].ToString() + "\t";
                    }
                    WriteScriptToFile("08_Procedure_script", strText.Trim() + "\nGO|", scriptFilePath);
                    WriteScriptToFile("08_Procedure_script", "--Generating Script for the procedure " + fileName + " \t --End", scriptFilePath);

                    break;
                case "V":
                    cmdLines = ((Microsoft.SqlServer.Management.Smo.View)scriptFile).Script();
                    fileName = ((Microsoft.SqlServer.Management.Smo.View)scriptFile).Name.ToUpper();
                    scriptLineArray = new string[cmdLines.Count];
                    cmdLines.CopyTo(scriptLineArray, 0);

                    txtMsg.Text = "Genearating Script of the file " + fileName;
                    txtMsg.Refresh();

                    //

                    strText = "If Exists (Select [Name] From SysObjects Where xType='V' and [Name]='" + fileName + "') \nBegin \n\t Drop View " + fileName + " \nEnd \nGo\n \n";
                    for (int j = 2; j < scriptLineArray.Length; j++)
                    {
                        strText = strText + scriptLineArray[j].ToString() + "\t";
                    }
                    switch (type)
                    {
                        case 1:
                            WriteScriptToFile("05_Older_View_script", "--Generating Script for the View " + fileName + " \t --Start", scriptFilePath);
                            WriteScriptToFile("05_Older_View_script", "--This View is Missed Match(i.e. this stored View is older ) ", scriptFilePath);
                            WriteScriptToFile("05_Older_View_script", strText.Trim() + "\nGO|", scriptFilePath);
                            WriteScriptToFile("05_Older_View_script", "--Generating Script for the View " + fileName + " \t --End", scriptFilePath);
                            break;
                        case 2:
                            WriteScriptToFile("06_Newer_View_script", "--Generating Script for the View " + fileName + " \t --Start", scriptFilePath);
                            WriteScriptToFile("06_Newer_View_script", "--This View is Missed Match(i.e. This stored View is Newer )", scriptFilePath);
                            WriteScriptToFile("06_Newer_View_script", strText.Trim() + "\nGO|", scriptFilePath);
                            WriteScriptToFile("06_Newer_View_script", "--Generating Script for the View " + fileName + " \t --End", scriptFilePath);
                            break;
                        case 3:
                            WriteScriptToFile("07_New_View_script", "--Generating Script for the View " + fileName + " \t --Start", scriptFilePath);
                            WriteScriptToFile("07_New_View_script", "--This View is Newly added", scriptFilePath);
                            WriteScriptToFile("07_New_View_script", strText.Trim() + "\nGO|", scriptFilePath);
                            WriteScriptToFile("07_New_View_script", "--Generating Script for the View " + fileName + " \t --End", scriptFilePath);
                            break;
                    }
                    break;
            }
        }
        public static string ReturnDateFormat()
        {
            DateTime dt = Convert.ToDateTime("01/07/2010");

            if (dt.Day.ToString() == "7")
            {
                // dd/Mm/yyyy
                return "MM/dd/yyyy hh:mm";
            }
            else
            {
                // MM/dd/yyyy
                return "dd/MM/yyyy hh:mm";
            }
        }

        #endregion
        public frmFileCompare(string serverName, string user, string pass,bool internalCal)
        {
            InitializeComponent();
            //connStr = "Data Source=Udyog3;Initial Catalog=Master;Uid=sa;Pwd=sa@1985";
            connStr = "Data Source=" + serverName + ";Initial Catalog=Master;Uid=" + user + ";Pwd=" + pass;
            cn = new SqlConnection(connStr);
            _Uid = user;
            _Pwd = pass;
            _serverName=serverName;
            internalCall = internalCal;
            //appPath = "E:\\U2\\VudyogSDK";
            appPath = Application.StartupPath;
        }

      
        private void btnSFoldPath_Click(object sender, EventArgs e)
        {
            txtSFoldPath.Text= GetFolderPath();
        }

        private void btnSelectPath_Click(object sender, EventArgs e)
        {
            txtSelectPath.Text= GetFolderPath();
        }
        
        
        /// <summary>
        /// This method is used for getting product code from Company Master
        /// </summary>
        /// <param name="code">String to decrypt</param>
        /// <returns></returns>
        private string GetProductCode(string code)
        {
            string decryptedStr = string.Empty;
            for (int i = 0; i < code.Length; i++)
            {
                decryptedStr = decryptedStr + Chr(Asc(code[i].ToString()) / 2);
            }
            return decryptedStr;
        }
        /// <summary>
        /// This method is used for getting the character of the value
        /// </summary>
        /// <param name="intByte"></param>
        /// <returns></returns>
        private string Chr(int intByte)
        {
            byte[] bytBuffer = new byte[] { (byte)intByte };
            return Encoding.GetEncoding(1252).GetString(bytBuffer);
        }
        /// <summary>
        /// This method is used for getting the ascii value of the character
        /// </summary>
        /// <param name="strChar"></param>
        /// <returns></returns>
        private int Asc(string strChar)
        {
            char[] chrBuffer = { Convert.ToChar(strChar) };
            byte[] bytBuffer = Encoding.GetEncoding(1252).GetBytes(chrBuffer);
            return (int)bytBuffer[0];
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            if (internalCall==true)
                Application.Exit();
        }

        private void frmFileCompare_Load(object sender, EventArgs e)
        {
            Icon appIcon = new Icon(appPath + "\\BMP\\UEICON.ICO"); ;
            this.Icon = appIcon;
            chkMainFld.Checked = true;
            chkBmpFld.Checked = true;
            chkClassFld.Checked = true;
            chkSelectAll.Checked = true;
            LoadCompanies();
            for (int i = 0; i < dataGridComp.Rows.Count; i++)
            {
                dataGridComp.Rows[i].Cells["Passroute"].Value = GetProductCode(dataGridComp.Rows[i].Cells["Passroute"].Value.ToString());
            }

        }

        private void btnCompare_Click(object sender, EventArgs e)
        {
            if (CheckValidation() == true)
            {
                txtMsg.Visible = true;
                txtMsg.Refresh();
                label2.Visible = true;
                label2.Text = "Please wait...";
                label2.Refresh();
                logTime = DateTime.Now.ToString("ddMMyyyy hh:mm:ss").Replace(':','_');
                WriteLogToFile("\t\t\t\t\t\tFile Comparison Log on " + logTime.Replace('_', ':'));
                WriteLogToFile(Convert.ToString('*').PadRight(125, '*'));
                Compare();
                //MakeZip(txtSelectPath.Text + "\\MainAppFolder", txtSelectPath.Text + "\\MainAppFolder.zip");
                MakeZip(txtSelectPath.Text + "\\MainAppFolder");  //031011
                txtMsg.Visible = false;
                txtMsg.Refresh();
                label2.Visible = false;
                label2.Refresh();
                MessageBox.Show("File Comparison completed successfully... \nPlease check the Log file File_Compare_Log.txt located in " + txtSelectPath.Text + "\\MainAppFolder" + " for more information. ", "File Compare", MessageBoxButtons.OK, MessageBoxIcon.Question);
//                progressBar1.Value = 0;
            }
        }
        
        private void chkSelectAll_Click(object sender, EventArgs e)
        {
            
                for (int i = 0; i < dataGridComp.Rows.Count; i++)
                {
                    dataGridComp.Rows[i].Cells["Sel"].Value = chkSelectAll.Checked;
                }
        }
    }
}


