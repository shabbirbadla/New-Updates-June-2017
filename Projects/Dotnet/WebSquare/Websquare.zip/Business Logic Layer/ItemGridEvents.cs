using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Data.Acess.Layer;     

namespace Business.Logic.Layer
{
    public class ItemGridEvents
    {
        public ItemGridEvents()
        {
        }

        public DataRow addItemCharges(DataTable dcmast_vw,
                DataRow itemRow,
                DataTable main_vw,
                DataTable lother_vw,
                string vChkProd,
                string pcvType,
                string beHave,
                bool isSetLother)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            stringFunction strFunction = new stringFunction();
            string fldn = "";
            decimal fldv = 0;
            bool Mu_sinfo = false;
            if (main_vw.Columns.Contains("U_sinfo") == true)
                Mu_sinfo = bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]);

            foreach (DataRow dcMastRow in dcmast_vw.Select("att_file = 0"))
            {
                if (Convert.ToString(dcMastRow["pert_name"]).Trim() != "")
                {
                    if (numFunction.toDecimal(dcMastRow["def_pert"]) > 0)
                    {
                        fldn = Convert.ToString(dcMastRow["pert_name"]).Trim();
                        fldv = numFunction.toDecimal(dcMastRow["def_pert"]);
                    }
                }
                else
                {
                    if (numFunction.toDecimal(dcMastRow["def_amt"]) !=0)
                    {
                        fldn = Convert.ToString(dcMastRow["fld_nm"]).Trim();
                        fldv = numFunction.toDecimal(dcMastRow["def_amt"]);
                    }
                }
                    
                if (fldn != "")
                {
                    if (itemRow.Table.Columns.Contains(fldn) == true)
                    {
                        if (vChkProd.Trim().IndexOf("vuexc") >= 0 &&
                            Convert.ToString(dcMastRow["code"]).Trim().IndexOf("E") >= 0 &&
                            Convert.ToString(main_vw.Rows[0]["rule"]).Trim() != "MODAVATABLE")
                        {
                            itemRow[fldn.Trim()] = 0;
                        }
                        else
                        {
                            if (vChkProd.Trim().IndexOf("vutex") >= 0 &&
                                Convert.ToString(dcMastRow["code"]).Trim().IndexOf("E") >= 0 &&
                                Convert.ToString(main_vw.Rows[0]["rule"]).Trim() != "EXCISE" &&
                                (strFunction.InList(pcvType.Trim(), new string[] { "AR", "GT" }) == true ||
                                 strFunction.InList(beHave.Trim(), new string[] { "AR", "GT" }) == true) &&
                                 Mu_sinfo == false)
                            {
                                itemRow[fldn.Trim()] = 0;
                            }
                            else
                            {
                                itemRow[fldn.Trim()] = fldv; 
                            }
                        }
                        
                    }
                }

            } // end for each loop

            if (isSetLother == true)
            {
                foreach (DataRow lotherRow in lother_vw.Select("att_file = 0 and ingrid = 1"))
                {
                    if (Convert.ToString(lotherRow["defa_val"]).Trim() != "")
                    {
                        if (Convert.ToString(lotherRow["fld_nm"]).Trim() != "")
                        {
                            itemRow[Convert.ToString(lotherRow["fld_nm"]).Trim()] =
                                Convert.ToString(lotherRow["defa_val"]).Trim();
                        }
                    }
                }
            }
            itemRow.AcceptChanges();

            return itemRow; 
        }
    }
}
