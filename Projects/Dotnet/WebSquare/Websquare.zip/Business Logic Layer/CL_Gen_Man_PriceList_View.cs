using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class CL_Gen_Man_PriceList_View
    {

    }
}
