using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class numericFunction
    {
        public numericFunction()
        {
        }


        public decimal toDecimal(string val)
        {
            decimal retVal = 0;

            if (val == "")
                val = "0";

            if (!DBNull.Value.Equals(val))
            {
                retVal = Convert.ToDecimal(val); 
            }
            else
            {
                retVal = Convert.ToDecimal(0);
            }
            return retVal;
        }

        public decimal toDecimal(object val)
        {
            if (!DBNull.Value.Equals(val))
            {
                val = Convert.ToDecimal(val);  
            }
            else
            {
                val = Convert.ToDecimal(0);
            }
            return (Decimal) val;
        }

        public decimal toDecimal(object val,int decimalSize)
        {
            if (!DBNull.Value.Equals(val))
            {
                val = Convert.ToDecimal(val);  
            }
            else
            {
                val = Convert.ToDecimal(0);
            }

            string DecimalStr = "";
            string Format = "{00:0." + DecimalStr.PadLeft(decimalSize,'0') + "}";

            return toDecimal(string.Format(Format, val));
        }

        public Int32 toInt32(object val)
        {
            
            if (!DBNull.Value.Equals(val))
            {
                if (val.GetType().ToString().Trim().ToUpper() == "SYSTEM.STRING")
                    if (val.ToString().Trim() == "")
                        val = "0";

                val = Convert.ToInt32(val);
            }
            else
            {
                val = Convert.ToInt32(0);
            }
            return (Int32) val;
        }

    }
}
