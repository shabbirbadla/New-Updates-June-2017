using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;  
using Data.Acess.Layer;   
 

namespace Business.Logic.Layer
{
    public class getServerDate
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;
        public getServerDate()
        {
        }

        public DateTime ServerDate()
        {
            DateTime serverDate = new DateTime();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            getDateFormat DateFormat = new getDateFormat();

            object ss = null; 
            ss = DataAcess.ExecuteScalar("select getDate()",ref connHandle);
            DataAcess.Connclose(connHandle);
            serverDate = DateFormat.TodateTime(ss);   
            return serverDate; 
        }
    }
}
