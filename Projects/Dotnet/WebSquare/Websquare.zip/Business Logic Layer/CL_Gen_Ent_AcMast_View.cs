using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class CL_Gen_Ent_AcMast_View
    {
        private int ac_Id;

        public int Ac_Id
        {
            get { return ac_Id; }
            set { ac_Id = value; }
        }
    }
}
