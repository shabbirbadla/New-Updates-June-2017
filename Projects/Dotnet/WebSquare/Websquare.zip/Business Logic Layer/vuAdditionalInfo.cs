using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Controls;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Data; 
using AjaxControlToolkit;
//using Customised.Trigger.Layer;





namespace Business.Logic.Layer
{
    public class vuAdditionalInfo 
    {

        //private static DataTier dataAcess = new DataTier();
        private numericFunction numFunction = new numericFunction();
        private getDateFormat DateFormat = new getDateFormat();
        private boolFunction bitFunction = new boolFunction();
        private SqlConnection connHandle;

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        
        
        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }


        public void genControls(DataView xtra_vw,DataRow data_vw,HtmlTable tblAddInfo)
        {
             
            try
            {

                HtmlTableRow r1 = new HtmlTableRow();
                tblAddInfo.Rows.Clear();
                tblAddInfo.Dispose();
                int cnt = 0;
                int viewRCount = 1;
                foreach (DataRowView xtraRow in xtra_vw)
                {
                    if (bitFunction.toBoolean(xtraRow["inGrid"]) == false ||
                        bitFunction.toBoolean(xtraRow["inter_Use"]) == false)
                    {
                        if (cnt == 0)
                        {
                            r1 = new HtmlTableRow(); // Create New Row
                            r1.VAlign = "Top";
                        }

                        cellGen("LABEL", r1, xtraRow, data_vw); // generate cell and insert control  
                        cellGen(Convert.ToString(xtraRow["data_ty"]).Trim().ToUpper(), r1, xtraRow, data_vw);

                        cnt = cnt + 1;
                        viewRCount = viewRCount + 1;
                        if (cnt == 2 || viewRCount > xtra_vw.Count)
                        {
                            tblAddInfo.Rows.Add(r1);
                            cnt = 0;
                        }
                    }

                    //if (cnt != 0)
                    //{
                    //    tblAddInfo.Rows.Add(r1);
                    //}
                }

                r1 = new HtmlTableRow();
                HtmlTableCell cellD = new HtmlTableCell();
                r1.Controls.Add(cellD);
                cellD = new HtmlTableCell();
                //Sample.Web.UI.Compatibility.ValidationSummary valAddinfoSummary = new Sample.Web.UI.Compatibility.ValidationSummary();
                //valAddinfoSummary.ShowMessageBox = true;
                //valAddinfoSummary.ShowSummary = false;
                //valAddinfoSummary.ValidationGroup = "valGrpAddInfo";
                //valAddinfoSummary.DisplayMode = ValidationSummaryDisplayMode.BulletList;
                //valAddinfoSummary.EnableClientScript = true;
                //cellD.Controls.Add(valAddinfoSummary);

                Button btnAddInfo = new Button();
                btnAddInfo.ID = "btnAddInfo";
                btnAddInfo.Style.Add("display","none");
                btnAddInfo.ValidationGroup = "valGrpAddInfo";
                cellD.Controls.Add(btnAddInfo);

                r1.Controls.Add(cellD);
                tblAddInfo.Rows.Add(r1);
            }
            catch (Exception Ex)
            {
                throw new Exception(Ex.Message);
            }
        }

        public void cellGen(string cntType, 
                            HtmlTableRow htmlRow, 
                            DataRowView xtraRow, 
                            DataRow data_vw)
                           
        {

            HtmlTableCell cellD = new HtmlTableCell();
            cellD.Align = "Left";
            cellD.VAlign = "Top";
            switch (cntType.Trim())
            {
                case "LABEL":
                    //if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    //{
                    //    Label lblMan = new Label();
                    //    lblMan.ID = "man" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    //    lblMan.Text = "*";
                    //    lblMan.Style.Add("font-weight", "bold");
                    //    lblMan.Style.Add("font-size", "9pt");
                    //    lblMan.Style.Add("color", "red");
                    //    cellD.Controls.Add(lblMan);
                    //    cellD.Controls.Add(new LiteralControl("&nbsp"));
                    //}
                    Label lblS = new Label();
                    lblS.ID = "lbl_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    lblS.Text = Convert.ToString(xtraRow["head_nm"]).Trim();
                    lblS.CssClass = "forms_ItemLeft5";
                    cellD.Controls.Add(lblS);
                    cellD.Align = "Right";
                    break;
                case "BIT":
                    GraphicalCheckBox chkBox = new GraphicalCheckBox();
                    chkBox.ID = "chk_" + Convert.ToString(xtraRow["fld_nm"]).Trim(); ;
                    chkBox.CheckedImg = "checked.png";
                    chkBox.CheckedOverImg = "checked-over.png";
                    chkBox.CheckedDisImg = "checked.png";
                    chkBox.UncheckedDisImg = "unchecked.png";
                    chkBox.UncheckedImg = "unchecked.png";
                    chkBox.UncheckedOverImg = "unchecked-over.png";
                    chkBox.Style.Add("z-index", "100");
                    SetValue<bool> chkGetDefaValue = new SetValue<bool>();
                    try
                    {
                        chkBox.Checked = chkGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message); 
                    }
                    cellD.Controls.Add(chkBox);
                    break;
                case "DECIMAL":
                case "NUMERIC":
                    NumericTextBox numTxtBox = new NumericTextBox();
                    numTxtBox.ID = "num_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    numTxtBox.AlignStyle = "RIGHT";
                    numTxtBox.AllowMinusValue = true;
                    numTxtBox.SelectOnEntry = true;
                    numTxtBox.Format = "0.00";
                    numTxtBox.Text = "0.00";
                    numTxtBox.CssClass = "form_textfield3";
                    numTxtBox.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                    SetValue<decimal> numGetDefaValue = new SetValue<decimal>();
                    try
                    {
                        numTxtBox.Text = Convert.ToString(numGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw));
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }

                    cellD.Controls.Add(numTxtBox);

                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("num_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), "0.00"));
                    }

                    break;
                case "TEXT":

                    // Uday This

                    Panel panel1 = new Panel();
                    panel1.ID = "Pan1_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    panel1.Width = 140;
                    panel1.CssClass = "CollapsePanelHeader";
                    panel1.ToolTip = "Click for Expand..";
                    //panel1.CssClass = "events"; 
                    Label label = new Label();
                    label.ID = "lblPan1_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    label.Text = "+ Show Memo Details";
                    panel1.Controls.Add(label);
                    panel1.Controls.Add(new LiteralControl("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;"));
                   
                    ////ImageButton imgButton = new ImageButton();
                    ////imgButton.ID = "imgPan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    ////imgButton.ImageUrl = "~/images/expand_blue.jpg";
                    ////imgButton.CausesValidation = false; 
                    ////panel1.Controls.Add(imgButton);

                    // Uday This

                    Panel panel2 = new Panel();
                    panel2.ID = "Pan2_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    panel2.Width = 140;
                    panel2.Height = 50;
                    TextBox txtText = new TextBox();
                    txtText.ID = "mut_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    txtText.TextMode = TextBoxMode.MultiLine;
                    txtText.Height = 100;
                    txtText.Width = 140;
                    txtText.CssClass = "form_textfield3";
                    SetValue<string> textGetDefaValue = new SetValue<string>();
                    try
                    {
                        txtText.Text = textGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                    panel2.Controls.Add(txtText);

                    cellD.Controls.Add(panel1);
                    cellD.Controls.Add(panel2);

                    // Uday This

                    //CollapsiblePanelExtender collExtender = new CollapsiblePanelExtender();
                    //collExtender.ID = "coll_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    //collExtender.TargetControlID = "Pan2_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    //collExtender.SuppressPostBack = true;
                    //collExtender.CollapsedImage = "~/images/expand_blue.jpg";
                    //collExtender.ExpandedImage = "~/images/collapse_blue.jpg";
                    //collExtender.CollapsedText = "+ Show Memo Details";
                    //collExtender.ExpandedText = "- Hide Memo Details";
                    ////collExtender.ImageControlID = "Image1";
                    //collExtender.TextLabelID = "lblPan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    //collExtender.Collapsed = true;
                    //collExtender.CollapseControlID = "Pan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    //collExtender.ExpandControlID = "Pan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    //cellD.Controls.Add(collExtender);

                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("mum_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), ""));

                    }
                    break;
                case "VARCHAR":
                    if (Convert.ToString(xtraRow["filtcond"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Substring(0, 4) != "SELE")
                        {
                            CustDropDownList cboList = new CustDropDownList();
                            cboList.ID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cboList.CssClass = "forms_drop";
                            cboList.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                            string[] cboValue;
                            cboValue = Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Split(',');
                            for (int i = 0; i < cboValue.Length; i++)
                            {
                                cboList.Items.Insert(i, cboValue[i].ToString().Trim());
                            }
                            cboList.Items.Insert(0, "--Select--");
                            SetValue<string> varGetDefaValue = new SetValue<string>();
                            try
                            {
                                cboList.SelectedValue = varGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                            }
                            catch (Exception Ex)
                            {
                                throw new Exception(Ex.Message);
                            }

                            cellD.Controls.Add(cboList);

                            if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                            {
                                cellD.Controls.Add(genValidator("cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), "--Select--"));
                            }

                            // Uday This

                            //ListSearchExtender lstExtender = new ListSearchExtender();
                            //lstExtender.ID = "lstExt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            //lstExtender.PromptPosition = ListSearchPromptPosition.Top;
                            //lstExtender.PromptText = "Type to search..";
                            //lstExtender.PromptCssClass = "ListSearchExtenderPrompt";
                            //lstExtender.TargetControlID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            //cellD.Controls.Add(lstExtender);
                        }
                        else
                        {
                            CustDropDownList cboList = new CustDropDownList();
                            cboList.ID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cboList.CssClass = "forms_drop";
                            cboList.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]); 
                            string dataFldName = Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Substring(6, Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().IndexOf("FROM") - 6);
                            DataTable dtDrop = null;
                            DataTier dataAcess = new DataTier();
                            dataAcess.DataBaseName = SessionProxy.DbName;

                            if (Convert.ToString(xtraRow["filtcond"]).Trim().IndexOf("{") >= 0)
                            {
                                dtDrop = dataAcess.ExecuteDataTable(Convert.ToString(xtraRow["filtcond"]).Trim().Substring(0, Convert.ToString(xtraRow["filtcond"]).Trim().IndexOf("{")),
                                                           "tblQuery", connHandle);
                            }
                            else
                            {
                                dtDrop = dataAcess.ExecuteDataTable(Convert.ToString(xtraRow["filtcond"]).Trim(), "tblQuery", connHandle);
                            }
                            dataAcess.Connclose(connHandle);
 
                            cboList.DataSource = dtDrop;
                            cboList.DataTextField = dataFldName.Trim();
                            cboList.DataValueField = dataFldName.Trim();
                            cboList.DataBind();
                            cboList.Items.Insert(0, "--Select--");
                            if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == true)
                            {
                                cboList.AutoPostBack = true;
                                //Udyog.E.Billingevents = new Udyog.E.Billing.itDetails();
                                    
                              
                                //DropDelegatesAndEvents DropEvent = new DropDelegatesAndEvents(new DropDelegate(), "");
                                //cboList.SelectedIndexChanged += new System.EventHandler(DropEvent.SelectedIndexChanged);
                                if (cboList.ID.Trim().ToUpper() == "CBOITEM" &&
                                    Convert.ToInt32(xtraRow["fld_nm"]) == 999)
                                {
                                    HiddenField hidBalQty = new HiddenField();
                                    HiddenField hidDropItemTag = new HiddenField();
                                    cellD.Controls.Add(hidBalQty);
                                    cellD.Controls.Add(hidDropItemTag);
                                    cboList.Attributes.Add("onfocusout", "javascript:ItemFocus();");

                                    GridView grdStock = new GridView();
                                    BoundField bndField = new BoundField();
                                    bndField.DataField = "it_code";
                                    bndField.HeaderText = "Item code";
                                    bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                                    bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right; 
                                    grdStock.Columns.Add(bndField);

                                    bndField = new BoundField();
                                    bndField.DataField = "it_name";
                                    bndField.HeaderText = "Item Name";
                                    bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                                    bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                                    grdStock.Columns.Add(bndField);

                                    bndField = new BoundField();
                                    bndField.DataField = "stockBal";
                                    bndField.HeaderText = "Phy. Stock";
                                    bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                                    bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                                    grdStock.Columns.Add(bndField);

                                    bndField = new BoundField();
                                    bndField.DataField = "stockPoBal";
                                    bndField.HeaderText = "Open PO.";
                                    bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                                    bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                                    grdStock.Columns.Add(bndField);

                                    bndField = new BoundField();
                                    bndField.DataField = "stockSOBal";
                                    bndField.HeaderText = "Open SO(-)";
                                    bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                                    bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                                    grdStock.Columns.Add(bndField);

                                    bndField = new BoundField();
                                    bndField.DataField = "logicalstk";
                                    bndField.HeaderText = "Logical Stock";
                                    bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                                    bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                                    grdStock.Columns.Add(bndField);
                                    grdStock.Font.Size = 6;  
                                    cellD.Controls.Add(grdStock);


                                }

                                //IEBilling ie = (IEBilling)(Test);  // Interface Casting
                                //cboList.SelectedIndexChanged += new System.EventHandler(SelectedIndexChanged);     

                            }
 
                            SetValue<string> cboGetDefaValue = new SetValue<string>();
                            try
                            {
                                cboList.SelectedValue = cboGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                            }
                            catch (Exception Ex)
                            {
                                throw new Exception(Ex.Message);
                            }

                            cellD.Controls.Add(cboList);
                            if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                            {
                                cellD.Controls.Add(genValidator("cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), "--Select--"));
                            }

                            // if postback is true then SearchExtender is not created
                            if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == false)
                            {
                                // Uday This

                                ListSearchExtender lstExtender = new ListSearchExtender();
                                lstExtender.ID = "lstExt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                                lstExtender.PromptPosition = ListSearchPromptPosition.Top;
                                lstExtender.PromptText = "Type to search..";
                                lstExtender.PromptCssClass = "ListSearchExtenderPrompt";
                                lstExtender.TargetControlID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                                cellD.Controls.Add(lstExtender);
                            }
                        }
                    }
                    else
                    {
                        TextBox txtBox = new TextBox();
                        txtBox.ID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                        txtBox.MaxLength = Convert.ToInt32(xtraRow["fld_wid"]);
                        txtBox.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                        txtBox.CssClass = "form_textfield3";
                        SetValue<string> txtGetDefaValue = new SetValue<string>();
                        try
                        {
                            txtBox.Text = txtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                        }
                        catch (Exception Ex)
                        {
                            throw new Exception(Ex.Message);
                        }

                        cellD.Controls.Add(txtBox);

                        if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                        {
                            cellD.Controls.Add(genValidator("txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                         "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), ""));

                        }

                    }
                    break;
                case "DATETIME":
                    TextBox txtDate = new TextBox();
                    txtDate.ID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    txtDate.CssClass = "form_textfield3";
                    txtDate.Width = 80;

                    getDateFormat DateFormat = new getDateFormat();
                    SetValue<DateTime> dtGetDefaValue = new SetValue<DateTime>();
                    DateTime retDate = DateTime.MinValue; 
                    try
                    {
                        retDate = dtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }


                    if (retDate == DateTime.MinValue || retDate == DateTime.MaxValue)
                    {
                        txtDate.Text = "";
                    }
                    else
                    {
                        txtDate.Text = DateFormat.dateformatBR(Convert.ToString(retDate).Trim());
                    }

                    cellD.Controls.Add(txtDate);
                    cellD.Controls.Add(new LiteralControl("&nbsp;"));

                    ImageButton imgBtnCal = new ImageButton();
                    imgBtnCal.ID = "imgBtn_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    imgBtnCal.ImageUrl = "~/images/Calendar_scheduleHS.png";
                    imgBtnCal.CausesValidation = false;
                    cellD.Controls.Add(imgBtnCal);

                    // Uday this 

                    CalendarExtender calExtender = new CalendarExtender();
                    calExtender.ID = "calExt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.PopupButtonID = "imgBtn_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.TargetControlID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.Format = "dd/MM/yyyy";
                    calExtender.PopupPosition = CalendarPosition.TopLeft;
                    //calExtender.CssClass = "CalendarExtender";
                    cellD.Controls.Add(calExtender);


                    MaskedEditExtender maskEditExtender = new MaskedEditExtender();
                    maskEditExtender.ID = "maskExtT_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    maskEditExtender.TargetControlID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    maskEditExtender.Mask = "99/99/9999";
                    maskEditExtender.MessageValidatorTip = true;
                    maskEditExtender.OnFocusCssClass = "MaskedEditFocus";
                    maskEditExtender.OnInvalidCssClass = "MaskedEditError";
                    maskEditExtender.MaskType = MaskedEditType.Date;
                    maskEditExtender.DisplayMoney = MaskedEditShowSymbol.Left;
                    maskEditExtender.AcceptNegative = MaskedEditShowSymbol.Left;
                    maskEditExtender.ErrorTooltipEnabled = true;
                    maskEditExtender.UserDateFormat = MaskedEditUserDateFormat.DayMonthYear;
                    cellD.Controls.Add(maskEditExtender);

                    RegularExpressionValidator ReqFldValid = new RegularExpressionValidator();
                    ReqFldValid.ControlToValidate = "txt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    ReqFldValid.ValidationExpression = "(0[1-9]|(1[0-9])|(2[0-9])|(3[0-1]))/(0[1-9]|(1[0-2]))/(200[5678910]$)";
                    ReqFldValid.SetFocusOnError = true;
                    ReqFldValid.ToolTip = "Invalid Date Format";
                    ReqFldValid.Display = ValidatorDisplay.None;
                    ReqFldValid.ErrorMessage = "Invalid Date";
                    cellD.Controls.Add(ReqFldValid);

                    // Uday This

                    //Sample.Web.UI.Compatibility.RegularExpressionValidator ReqFldValid = new Sample.Web.UI.Compatibility.RegularExpressionValidator();
                    ReqFldValid.ControlToValidate = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    //ReqFldValid.ValidationExpression = "(0[1-9]|(1[0-9])|(2[0-9])|(3[0-1]))/(0[1-9]|(1[0-2]))/(200[5678910]$)";
                    ReqFldValid.ValidationExpression = "(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\\d\\d";
                    ReqFldValid.SetFocusOnError = true;
                    ReqFldValid.ToolTip = "Invalid Date Format";
                    ReqFldValid.Display = ValidatorDisplay.Static;
                    ReqFldValid.ErrorMessage = "Invalid Date";
                    ReqFldValid.EnableViewState = true;
                    ReqFldValid.EnableClientScript = true;
                    //ReqFldValid.ValidationGroup = "valGrpAddInfo";
                    cellD.Controls.Add(ReqFldValid);

                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), ""));

                    }

                    break;

            }
            htmlRow.Cells.Add(cellD);

        }

        protected RequiredFieldValidator genValidator(string cntValidate, string errMess, string Id, string initValue)
        {
            // Uday This

            Sample.Web.UI.Compatibility.RequiredFieldValidator reqFldValidator = new Sample.Web.UI.Compatibility.RequiredFieldValidator();
            reqFldValidator.ID = Id.Trim();
            reqFldValidator.ControlToValidate = cntValidate;
            reqFldValidator.Display = ValidatorDisplay.Static;
            //reqFldValidator.ValidationGroup = "valGrpAddInfo";
            reqFldValidator.ErrorMessage = errMess.Trim();
            reqFldValidator.SetFocusOnError = true;
            reqFldValidator.InitialValue = initValue.Trim();
            reqFldValidator.Enabled = true;
            reqFldValidator.EnableViewState = true;
            reqFldValidator.EnableClientScript = true;
            reqFldValidator.Visible = true;
            reqFldValidator.Text = "*";
            return reqFldValidator;

            //RequiredFieldValidator reqFldValidator = new RequiredFieldValidator();
            //reqFldValidator.ID = Id.Trim();
            //reqFldValidator.ControlToValidate = cntValidate;
            //reqFldValidator.Display = ValidatorDisplay.None;
            //reqFldValidator.ErrorMessage = errMess.Trim();
            //reqFldValidator.SetFocusOnError = true;
            //reqFldValidator.InitialValue = initValue.Trim();

            //return reqFldValidator;
        }

        public void btnClick(HtmlTable tblAddInfo,DataRow data_vw,string toDO,string[] xclude)
        {
            string cntId = "";
            for (int tb = 0; tb < tblAddInfo.Controls.Count; tb++)
            {
                for (int tbRw = 0; tbRw < tblAddInfo.Controls[tb].Controls.Count; tbRw++)
                {
                    for (int tbCell = 0; tbCell < tblAddInfo.Controls[tb].Controls[tbRw].Controls.Count; tbCell++)
                    {
                        cntId = Convert.ToString(tblAddInfo.Controls[tb].Controls[tbRw].Controls[tbCell].ID);

                        if (cntId != null)
                        {
                            string fName = cntId.Trim().Substring(4, cntId.Length - 4);

                            if (xclude != null)
                            {
                                bool isFound = false;
                                foreach (string str in xclude)
                                {
                                    if (str != null)
                                    {
                                        if (fName.ToString().Trim() == str.ToString().Trim())
                                        {
                                            isFound = true;
                                            break;
                                        }
                                    }
                                }

                                if (isFound == true)
                                    continue;
                            }

                            object contObj = tblAddInfo.Controls[tb].Controls[tbRw].Controls[tbCell];
                            switch (cntId.ToString().ToUpper().Substring(0, 3))
                            {
                                case "TXT":
                                    if (toDO.ToUpper() == "BOXING")
                                        objBoxing(contObj, fName, "TEXTBOX",data_vw);
                                    else
                                        objUnBoxing(contObj, fName, "TEXTBOX", data_vw);
                                    break;
                                case "CHK":
                                    if (toDO.ToUpper() == "BOXING")
                                        objBoxing(contObj, fName, "CHECKBOX", data_vw);
                                    else
                                        objUnBoxing(contObj, fName, "CHECKBOX", data_vw);
                                    break;
                                case "CBO":
                                    if (toDO.ToUpper() == "BOXING")
                                        objBoxing(contObj, fName, "DROPDOWNLIST", data_vw);
                                    else
                                        objUnBoxing(contObj, fName, "DROPDOWNLIST", data_vw);
                                    break;
                                case "NUM":
                                    if (toDO.ToUpper() == "BOXING")
                                        objBoxing(contObj, fName, "NUMERICTEXTBOX", data_vw);
                                    else
                                        objUnBoxing(contObj, fName, "NUMERICTEXTBOX", data_vw);
                                    break;
                                case "PAN":
                                    if (cntId.Trim().Substring(0, 4) == "PAN2")
                                    {
                                        string panCntId = "";
                                        for (int panCont = 0; panCont < tblAddInfo.Controls[tb].Controls[tbRw].Controls[tbCell].Controls.Count; panCont++)
                                        {

                                            panCntId = Convert.ToString(tblAddInfo.Controls[tb].Controls[tbRw].Controls[tbCell].Controls[panCont].ID);

                                            if (panCntId.ToString().Trim().Substring(0, 3).ToUpper() == "MUT")
                                            {
                                                contObj = tblAddInfo.Controls[tb].Controls[tbRw].Controls[tbCell].Controls[panCont];
                                                fName = panCntId.Trim().Substring(4, panCntId.Length - 4);
                                                if (toDO.ToUpper() == "BOXING")
                                                    objBoxing(contObj, fName, "TEXTBOX", data_vw);
                                                else
                                                    objUnBoxing(contObj, fName, "TEXTBOX", data_vw);
                                                break; 
                                            }
                                        }
                                    }
                                    break;
                            }
                        }
                    }

                }
            }
        }

        protected void objUnBoxing(object contObj, string fName, string objType, DataRow data_vw)
        {
            switch (objType.Trim().ToUpper())
            {
                case "TEXTBOX":
                case "NUMERICTEXTBOX":
                    switch (data_vw[fName.Trim()].GetType().Name.ToUpper().Trim())
                    {
                        case "STRING":
                            ((TextBox)contObj).Text = Convert.ToString(data_vw[fName.Trim()]);
                            break;
                        case "DATETIME":
                            (((TextBox)contObj).Text) = DateFormat.dateformat(Convert.ToDateTime(data_vw[fName.Trim()]));
                            break;
                        case "DECIMAL":
                            NumericTextBox num = ((NumericTextBox)contObj);
                            num.ID = "num_" + fName.Trim();
                            num.Format = "0.00";
                            num.Text = Convert.ToString(numFunction.toDecimal(data_vw[fName.Trim()]));
                            break;
                        case "INT":
                        case "INT16":
                        case "INT32":
                        case "INT64":
                            ((NumericTextBox)contObj).Text = Convert.ToString(numFunction.toInt32(data_vw[fName.Trim()]));
                            break;
                    }
                    break;
                case "DROPDOWNLIST":
                    switch (data_vw[fName.Trim()].GetType().Name.ToUpper().Trim())
                    {
                        case "STRING":
                            // if datatype is STRING then data store from SelectedItem Property
                            // of dropdownlist
                            if (((CustDropDownList)contObj).DbDataValueField != "")
                            {
                                ((CustDropDownList)contObj).SelectedValue = Convert.ToString(data_vw[((CustDropDownList)contObj).DbDataValueField.Trim()]);

                            }
                            else
                            {
                                ((CustDropDownList)contObj).SelectedValue = Convert.ToString(data_vw[fName.Trim()]);
                            }
                            break;
                        case "DATETIME":
                            ((CustDropDownList)contObj).SelectedValue = DateFormat.dateformat(Convert.ToDateTime(data_vw[fName.Trim()]));
                            break;
                        case "DECIMAL":
                            ((CustDropDownList)contObj).SelectedValue = Convert.ToString(numFunction.toDecimal(data_vw[fName.Trim()]));
                            break;
                        case "INT":
                        case "INT16":
                        case "INT32":
                        case "INT64":
                            ((CustDropDownList)contObj).SelectedValue = Convert.ToString(numFunction.toInt32(data_vw[fName.Trim()]));
                            break;
                    }
                    break;
                case "CHECKBOX":
                    switch (data_vw[fName.Trim()].GetType().Name.ToUpper().Trim())
                    {
                        case "BOOLEAN":
                            ((GraphicalCheckBox)contObj).Checked = bitFunction.toBoolean(data_vw[fName.Trim()]);
                            break;
                    }
                    break;

            }
        }

        protected void objBoxing(object contObj, string fName, string objType,DataRow data_vw)
        {
            switch (objType.Trim().ToUpper())
            {
                case "TEXTBOX":
                case "NUMERICTEXTBOX":
                    switch (data_vw[fName.Trim()].GetType().Name.ToUpper().Trim())
                    {
                        case "STRING":
                            data_vw[fName.Trim()] = ((TextBox)contObj).Text;
                            break;
                        case "DATETIME":
                            data_vw[fName.Trim()] = DateFormat.TodateTime(((TextBox)contObj).Text);
                            break;
                        case "DECIMAL":
                            //numFunction.toDecimal((((NumericTextBox)contObj).Text));
                            NumericTextBox num = ((NumericTextBox)contObj);
                            num.ID = "num_" + fName.Trim();
                            num.Format = "0.00";
                            data_vw[fName.Trim()] = numFunction.toDecimal(num.Text);
                            break;
                        case "INT":
                        case "INT16":
                        case "INT32":
                        case "INT64":
                            data_vw[fName.Trim()] = Convert.ToInt32((((NumericTextBox)contObj).Text));
                            break;
                    }
                    break;
                case "DROPDOWNLIST":
                    switch (data_vw[fName.Trim()].GetType().Name.ToUpper().Trim())
                    {
                        case "STRING":
                            // if datatype is STRING then data store from SelectedItem Property
                            // of dropdownlist
                            data_vw[fName.Trim()] = ((CustDropDownList)contObj).SelectedIndex != 0 ? ((CustDropDownList)contObj).SelectedItem.Text : "";
                            if (((CustDropDownList)contObj).DbDataValueField != "")
                            {
                                if (((CustDropDownList)contObj).SelectedIndex != 0)
                                    data_vw[((CustDropDownList)contObj).DbDataValueField.Trim()] = ((CustDropDownList)contObj).SelectedValue;
                            }
                            break;
                        case "DATETIME":
                            data_vw[fName.Trim()] = DateFormat.TodateTime(((CustDropDownList)contObj).SelectedValue);
                            break;
                        case "DECIMAL":
                            data_vw[fName.Trim()] = numFunction.toDecimal((((CustDropDownList)contObj).SelectedValue));
                            break;
                        case "INT":
                        case "INT16":
                        case "INT32":
                        case "INT64":
                            data_vw[fName.Trim()] = Convert.ToInt32((((CustDropDownList)contObj).SelectedValue));
                            break;
                    }
                    break;
                case "CHECKBOX":
                    switch (data_vw[fName.Trim()].GetType().Name.ToUpper().Trim())
                    {
                        case "BOOLEAN":
                            data_vw[fName.Trim()] = ((GraphicalCheckBox)contObj).Checked;
                            break;
                    }
                    break;
                    
            }
        }

        public void SelectedIndexChanged(object sender, EventArgs e)
        {
            string ttt = "DDD";
        }

        public class SetValue<myType>
        {
           

            public myType SetDefaultValue(DataRowView xtraRow, string fldName,DataRow data_vw)
            {
                myType defaValue;
                if (Convert.ToString(xtraRow["defa_val"]).Trim() != "")
                {
                    try
                    {
                        defaValue = ((myType)xtraRow["defa_val"]);
                    }
                    catch (InvalidCastException Ex)
                    {
                        throw new InvalidCastException(fldName.Trim() + " default value is not proper," + Ex.Message.Trim());
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                }
                else
                {
                    try
                    {
                        //myType nullObj = (myType)"0";
                        object nullObj = null;
                        if (Convert.DBNull.Equals(data_vw[fldName.Trim()]) == false &&
                            Convert.ToString(data_vw[fldName.Trim()]) != "")
                            defaValue = ((myType)data_vw[fldName.Trim()]);
                        else
                            defaValue = default(myType); 
                    }
                    catch (InvalidCastException Ex)
                    {
                        throw new InvalidCastException(fldName.Trim() + " default value is not proper," + Ex.Message.Trim());
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }

                }
                return defaValue;
                
            }

          
        }



    }

  

    //delegate void DropDelegate(object sender, DropEventArgs e);
    //class DropEventArgs : System.EventArgs
    //{
    //    public string astring;
    //    public DropEventArgs(string a)
    //    {
    //        astring = a;
    //    }
    //} 

    
    //class DropDelegatesAndEvents
    //{
    //    private DropDelegate youDoIt;
    //    private string param;

    //    public DropDelegatesAndEvents(DropDelegate d, string p)
    //    {
    //        youDoIt = d;
    //        param = p;
    //    }

    //    public void SelectedIndexChanged(object sender, EventArgs e)
    //    {
    //        youDoIt(sender, new DropEventArgs(param));  
    //    }


     
    //}
}
