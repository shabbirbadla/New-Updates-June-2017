using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class CL_Gen_Ent_PriceList_Grid_Columns
    {
        #region DataTable field Structure
        //private int prlistcd;
        private bool chkselect;
        public bool Chkselect
        {
            get { return chkselect; }
            set { chkselect = value; }
        }


        #endregion
    }

    public class CL_Gen_Ent_PriceList_View
    {
    }
}
