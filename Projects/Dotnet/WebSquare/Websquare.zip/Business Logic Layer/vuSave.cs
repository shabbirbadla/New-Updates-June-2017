using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;  
using System.Web.UI.WebControls;
using System.Web.UI;
using Data.Acess.Layer;
using AjaxControlToolkit;  

namespace Business.Logic.Layer
{
    public class vuSave : BaseClass 
    {
        public vuSave()
        {
        }

        private string errorMessage;

        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

        //private PageCustomProperties DBPropsSession;
        private stringFunction strFunction = new stringFunction();
        private numericFunction numFunction = new numericFunction();
        private getDateFormat DateFormat = new getDateFormat();
        //private static DataTier DataAcess = new DataTier();
        //private static vuAllocation checkTable = new vuAllocation();
        private boolFunction bitFunction = new boolFunction();
        private SqlDataReader DR;

        private string SqlStr = "";
        private string filterExp = "";
        private bool isSuccess = true;

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();
        private SqlConnection connHandle;
       

        public bool Saveit(TextBox txtDate,
            TextBox txtPartyName,
            TextBox txtAccount,
            DropDownList dropSeries,
            DropDownList dropCategory,
            DropDownList dropDepartment,
            DropDownList dropRule,
            TextBox txtInvoiceNo,
            TextBox txtNetAmount,
            DataSet MainDataSet,
            System.Web.UI.Page thisPage,
            HiddenField hidretValue,
            TextBox txtBillNo,
            TextBox txtBillDate,
            TextBox txtNarration,
            TextBox txtNarrationB,
            TextBox txtChequeNoB,
            TextBox txtDrawnOnB)

        {

            //string strScript = "<script language='JavaScript'>";
            //strScript += "if(confirm(' test y/n')){}else{return false}" +
            //             "</" +
            //             "script>";


            //ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "key", strScript, true);

            bool IsSave = false;

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
   
            try
            {

                EmptyValidation(txtDate,
                    txtPartyName,
                    txtInvoiceNo,
                    txtAccount,
                    dropSeries,
                    dropCategory,
                    dropDepartment,
                    dropRule,
                    txtBillNo,
                    txtBillDate,
                    txtChequeNoB,
                    txtNarration,
                    txtNarrationB,
                    txtDrawnOnB, 
                    MainDataSet.Tables["main_vw"]);



                MadatoryValidation(MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["item_vw"],
                        MainDataSet.Tables["company"],
                        MainDataSet.Tables["acdet_vw"],
                        txtPartyName,
                        txtNetAmount);


                if (DBPropsSession.AccountPage == true)
                {
                    if (DBPropsSession.PcvType == "OB" ||
                        DBPropsSession.Behave == "OB" &&
                        DBPropsSession.AddMode == true)
                    {
                        SqlStr = "select ac_name from " + DBPropsSession.Entry_Tbl.Trim() + "acdet" +
                                 " where ac_id = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["ac_id"]) +
                                 " and date = '" + DateFormat.dateformat(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"])) + "' and " +
                                 " entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]) + "'";

                        DR = DataAcess.ExecuteDataReader(SqlStr,ref connHandle);

                        if (DR.HasRows == true)
                        {
                            DR.Close(); 
                            ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "narrMess", "narrMess(Opening Balance entry already created for this account \\n Add new entry ?);", true);
                        }
                        DR.Close();
                        DR.Dispose();
                        DataAcess.Connclose(connHandle);  

                        if (hidretValue.Value == "0")
                        {
                            hidretValue.Value = "";
                            return false;
                        }

                        if (bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["ac_bchk"]) == true)
                        {
                            string ProceedM = "";
                            int ProceedI = 0;
                            bool Proceed = true;
                            bool Proceeda = true;

                            decimal Ans = 1;
                            bool Ansl = false;
                            string Anst = "";

                            DataView acdetview = new DataView();
                            acdetview = MainDataSet.Tables["acdet_vw"].DefaultView;
                            acdetview.Sort = "ac_name";

                            foreach (DataRowView acDetviewRow in acdetview)
                            {
                                ProceedM = Convert.ToString(acDetviewRow["ac_name"]);
                                ProceedI = Convert.ToInt32(acDetviewRow["ac_id"]);
                                decimal bal = 0;

                                foreach (DataRow acdetRow in acdetview.Table.Select("ac_name = '" + ProceedM.Trim() + "'"))
                                {
                                    bal = bal + Convert.ToString(acdetRow["amt_ty"]).Trim() == "DR" ?
                                       numFunction.toDecimal(acdetRow["amount"]) :
                                        (-numFunction.toDecimal(acdetRow["amount"]));
                                }

                                if (bal < 0)
                                {
                                    SqlStr = "select Typ,cramount,crallow from " +
                                             " Ac_mast where Ac_name = '" + ProceedM.Trim() + "'";

                                    //DR = new SqlDataReader();
                                    DR = DataAcess.ExecuteDataReader(SqlStr,ref connHandle);

                                    Ans = 1;
                                    Ansl = false;
                                    Anst = "";

                                    if (DR.HasRows == true)
                                    {
                                        while (DR.Read())
                                        {
                                            Ans = numFunction.toDecimal(DR["crAmount"]);
                                            Ansl = bitFunction.toBoolean(DR["crAllow"]);
                                            Anst = Convert.ToString(DR["typ"]).Trim();
                                        }
                                    }
                                    DR.Close();
                                    DR.Dispose();
                                    DataAcess.Connclose(connHandle);

                                    if (Ans != 0 ||
                                        (Anst.Trim() == "PETTY EXP." &&
                                         (DBPropsSession.PcvType == "PC" || DBPropsSession.Behave == "PC")))
                                    {
                                        vuAccountBalance getAccBal = new vuAccountBalance();
                                        decimal balamt = getAccBal.getAccountBalance(ProceedI,
                                                ProceedM, 
                                                Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]),
                                                DBPropsSession.AddMode,
                                                DBPropsSession.Entry_Tbl);
                                        bal = bal + balamt;

                                        if (Ans > bal)
                                        {
                                            if (Ansl == false)
                                            {
                                                Proceed = false;
                                                return false;
                                            }

                                            if (Ansl == true)
                                            {
                                                Proceeda = false;
                                                return false;
                                            }
                                        }
                                    }
                                }
                            } // end foreach loop

                            if (Anst == "PETTY EXP.")
                            {
                                if (Proceed == false)
                                {
                                    ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", "alert('Exceeding The Petty Cash Balance. Couldn't Save');", true);
                                }
                            }
                            else
                            {
                                if (Proceeda == false)
                                {
                                    ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "narrMess", "narrMess('" + ProceedM.Trim() + " has crossed the credit amount limit, Proceed ? ');", true);
                                    if (hidretValue.Value == "0")
                                    {
                                        hidretValue.Value = "";
                                        return false;
                                    }
                                }

                                if (Proceed == false)
                                {
                                    ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", "alert('" + ProceedM.Trim() + " has crossed the credit amount limit, cannot Proceed..!!!');", true);
                                    return false;
                                }
                            }
                        } // end company accBchk
                    }
                } // End accountPage

                if (DBPropsSession.ItemPage == true)
                {
                    foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                    {
                        itemRow["or_sr"] = "";
                    }
                    MainDataSet.Tables["item_vw"].AcceptChanges();

                    if (DBPropsSession.EditMode == true)
                    {
                        SqlStr = "Select Entry_ty,Date,Doc_no," +
                                 " Itserial,It_code,Qty,Or_sr,Re_qty From " + DBPropsSession.Entry_Tbl + "item " +
                                 " where Tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);

                        bool Ansl = true;
                        DataTable tmpItemvw = DataAcess.ExecuteDataTable(SqlStr, "tmpItem", connHandle);
                        DataAcess.Connclose(connHandle);

                        foreach (DataRow tmpItemRow in tmpItemvw.Rows)
                        {
                            if (numFunction.toDecimal(tmpItemRow["re_qty"]) != 0)
                            {

                                filterExp = "entry_ty = '" + Convert.ToString(tmpItemRow["entry_ty"]).Trim() + "'" +
                                            " and " +
                                            " date = '" + DateFormat.TodateTime(tmpItemRow["date"]) + "'" +
                                            " and " +
                                            " doc_no ='" + Convert.ToString(tmpItemRow["doc_no"]).Trim() + "'" +
                                            " and " +
                                            " it_serial ='" + Convert.ToString(tmpItemRow["it_serial"]).Trim() + "'";

                                // Search row in item_vw
                                try
                                {
                                    DataRow SearchItRow = MainDataSet.Tables["item_vw"].Select(filterExp)[0];
                                    bool Ansla = false;

                                    if (Convert.ToInt32(SearchItRow["it_code"]) == Convert.ToInt32(tmpItemRow["it_code"]) &&
                                        Ansla == false)
                                    {
                                        SearchItRow["or_sr"] = Convert.ToString(tmpItemRow["or_sr"]).Trim();
                                        SearchItRow["re_qty"] = numFunction.toDecimal(tmpItemRow["re_qty"]);
                                        SearchItRow.AcceptChanges();
                                        MainDataSet.Tables["item_vw"].AcceptChanges();
                                    }
                                    else
                                    {
                                        Ansl = false;
                                    }

                                }
                                catch
                                {
                                    Ansl = false;
                                }
                            }
                        } // end foreach loop

                        if (Ansl == false)
                        {
                            ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", "alert('Item pickup not done properly..!!!');", true);
                            return false;
                        }
                    } // end editmode
                } // end ItemPage


                if (bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["neg_itbal"]) == false)
                {
                    if (Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["inv_stk"]) == "-")
                    {
                        bool qtyflag = true;

                        if (MainDataSet.Tables["main_vw"].Columns.Contains("u_choice") == true)
                        {
                            if (bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_choice"]) == true)
                                qtyflag = false;
                        }

                        string ItemName = "";
                        bool negCheck = false;

                        if (qtyflag == true)
                        {
                            string sortExp = "Item ASC,Ware_nm ASC,date ASC";
                            string Ware_nm = "";
                            int ItemCode = 0;
                            decimal ItemQty = 0;
                            DataView itemView = new DataView(MainDataSet.Tables["item_vw"], "", sortExp, DataViewRowState.CurrentRows);
                            foreach (DataRowView itemRowView in itemView)
                            {
                                ItemName = Convert.ToString(itemRowView["item"]).Trim();
                                ItemCode = Convert.ToInt32(itemRowView["it_code"]);
                                Ware_nm = Convert.ToString(itemRowView["ware_nm"]).Trim();
                                ItemQty = 0;
                                sortExp = "item = '" + ItemName.Trim() + "'" +
                                          " and ware_nm = '" + Ware_nm.Trim() + "'" +
                                          " and dc_no = ''";
                                ItemQty = ((decimal)MainDataSet.Tables["item_vw"].Compute("sum(qty)", sortExp));

                                if (ItemQty != 0)
                                {
                                    decimal BalQty = 0;
                                    bool negBalQty = false;
                                    if (MainDataSet.Tables["company"].Columns.Contains("mneg_itbal") == true)
                                    {
                                        negBalQty = bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["mneg_itbal"]);
                                    }

                                    vuStockCheck StockCheck = new vuStockCheck();
                                    if (negBalQty == false)
                                    {
                                        BalQty = StockCheck.StockItBalW(DBPropsSession.AddMode,
                                                    ItemCode,
                                                    Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]),
                                                    Ware_nm.Trim(),
                                                    DateTime.MinValue,
                                                    DBPropsSession.Entry_Tbl,
                                                    MainDataSet.Tables["lcode_vw"]);

                                    }
                                    else
                                    {
                                        BalQty = StockCheck.StockItBal(DBPropsSession.AddMode,
                                                 ItemCode,
                                                 Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]),
                                                 MainDataSet.Tables["lcode_vw"],
                                                 DBPropsSession.Entry_Tbl);

                                    }

                                    BalQty = BalQty - ItemQty;

                                    if (BalQty < 0)
                                        negCheck = true;


                                } // End ItemQty !=0
                            }    // End for each loop
                        } // end (qtyflag == true)

                        if (negCheck == true)
                        {
                            ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", "alert('Item " + ItemName.Trim() + " Out of Stock..!!!');", true);
                            return false;
                        }
                    } // End lcode_vw = "-"
                } // End Company Neg_check

                //next

                if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                    MainDataSet.Tables["item_vw"].Columns.Contains("sr_sr") == true &&
                    (strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(),
                                       new string[] { "EXCISE", "NON-EXCISE" }) == true &&
                    (strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "DC", "IR", "II", "GT", "SS" }) == true ||
                    strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "DC", "IR", "II", "GT", "SS" }) == true)))
                {
                 
                    foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                    {
                        if (((DBPropsSession.PcvType == "AR" || DBPropsSession.Behave == "AR") ||
                            (DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                            bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["U_sinfo"]) == false) &&
                            Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                        {
                            try
                            {
                                string filterExp = "entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                                   " and tran_cd =" + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                                   " and itserial='" + Convert.ToString(itemRow["itserial"]).Trim() + "'";

                                DataRow ManuDetRow = MainDataSet.Tables["manu_det_vw"].Select(filterExp)[0];

                            }
                            catch (Exception Ex)
                            {
                                throw new Exception("Manufacturer details not found for " + Convert.ToString(itemRow["item"]).Trim());
                            }
                        }

                        if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS", "IR" }) == true ||
                             strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS", "IR" }) == true) ||
                             ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                               bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true))
                        {
                            decimal qty =0;
                            string filterExp = "entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                               " and tran_cd =" + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                               " and itserial ='" + Convert.ToString(itemRow["itserial"]).Trim() +"'";
                            foreach (DataRow litemallRow in MainDataSet.Tables["litemall_vw"].Select(filterExp))
                            {
                                qty = qty + numFunction.toDecimal(litemallRow["qty"]);
                            }

                            if (qty != numFunction.toDecimal(itemRow["qty"]))
                            {
                                throw new Exception(Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["code_nm"]).Trim() +
                                                    " Qty. does not match with allocated Qty." +
                                                    " for " + Convert.ToString(itemRow["item"]).Trim() +
                                                    " please delete this entry and re-enter again");

                            }
                        } // End DC SS IR

                        if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR" }) == true ||
                            strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR" }) == true) &&
                            ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                              bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false))
                        {
                            try
                            {
                                SqlCommand cmdRg = new SqlCommand();
                                GenerateRGPage RgPage = new GenerateRGPage();
                                RgPage.RgPageValidation("CHECK",
                                            itemRow,
                                            MainDataSet.Tables["main_vw"].Rows[0],
                                            MainDataSet.Tables["manufact"].Rows[0],
                                            MainDataSet.Tables["company"].Rows[0],  
                                            DBPropsSession.AddMode,
                                            DBPropsSession.EditMode,
                                            cmdRg,ref connHandle);
                            }
                            catch (Exception Ex)
                            {
                                throw Ex;
                            }


                        }

                        if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                             strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
                        {
                            if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "GT" }) == true ||
                                strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "GT" }) == true) &&
                                bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false)
                            {
                                if (numFunction.toDecimal(itemRow["qty"]) != numFunction.toDecimal(itemRow["Balqty"]))
                                {
                                    throw new Exception("Quantity changed, Excise duty not updated..");
                                }
                            }
                        }

                    } // end foreach

                    if (DBPropsSession.PcvType == "IR" || DBPropsSession.Behave == "IR")
                    {
                        // pending generate II entry()

                        foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                        {
                            itemRow["balqty"] = numFunction.toDecimal(itemRow["qty"]);
                            itemRow.AcceptChanges(); 
                        }
                        MainDataSet.Tables["item_vw"].AcceptChanges();
  
                        // pending
                    }


                }

                // for charges details

                if (DBPropsSession.ItemPage == true &&
                    DBPropsSession.ChargesPage == true)
                {
                    try   // Search in dcmast
                    {
                        DataRow dcMastRow = MainDataSet.Tables["dcmast_vw"].Select("fld_nm = 'EXAMT' and att_file = 1")[0];
                        string DutyN = Convert.ToString(dcMastRow["pert_name"]).Trim() != "" ?
                                       Convert.ToString(dcMastRow["pert_name"]).Trim() : "";
                        decimal DutyV = DutyN.Trim() != "" ?
                            numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0][DutyN]) :
                            numFunction.toDecimal(dcMastRow["def_pert"]);

                        decimal DutyT = numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0]["examt"]);
                        decimal DutyI = 0;
                        int rowSkip = 0;
                        int rowCnt = MainDataSet.Tables["item_vw"].Rows.Count;

                        foreach (DataRow ItemRow in MainDataSet.Tables["item_vw"].Rows)
                        {
                            rowSkip = rowSkip + 1;

                            if (ItemRow.Table.Columns.Contains("u_asseamt") == true)
                            {
                                DutyI = ((numFunction.toDecimal(ItemRow["u_asseamt"]) *
                                         DutyV) / 100);
                            }
                            else
                            {
                                DutyI = (((numFunction.toDecimal(ItemRow["qty"]) *
                                        numFunction.toDecimal(ItemRow["rate"])) *
                                        DutyV) / 100);
                            }

                            if (ItemRow.Table.Columns.Contains(DutyN) == true)
                            {
                                ItemRow[DutyN] = DutyV;
                            }

                            if ((DutyT - DutyI) <= 0)
                            {
                                ItemRow["examt"] = DutyT;
                            }
                            else
                            {
                                ItemRow["examt"] = DutyI;
                                DutyT = DutyT - DutyI;

                                if (rowCnt == rowSkip)
                                {
                                    ItemRow["examt"] = numFunction.toDecimal(ItemRow["examt"]) +
                                                       DutyT;
                                }
                            }
                            ItemRow.AcceptChanges();
                        }
                        MainDataSet.Tables["item_vw"].AcceptChanges();
                    }
                    catch
                    {
                    }  // end search

                    try   // Search in dcmast for other than EXAMT
                    {
                        foreach (DataRow dcMastRow in MainDataSet.Tables["dcmast_vw"].Select("fld_nm != 'EXAMT' and att_file = 1"))
                        {
                            string fldNm = Convert.ToString(dcMastRow["fld_nm"]).Trim();

                            if (MainDataSet.Tables["item_vw"].Columns.Contains("fldNm") == true)
                            {
                                if (MainDataSet.Tables["item_vw"].Columns[fldNm].DataType.ToString().Trim().ToUpper() == "SYSTEM.DECIMAL")
                                {
                                    string DutyN = Convert.ToString(dcMastRow["pert_name"]).Trim() != "" ?
                                                    Convert.ToString(dcMastRow["pert_name"]).Trim() :
                                                    "";
                                    decimal DutyV = DutyN.Trim() != "" ?
                                        numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0][DutyN]) :
                                        numFunction.toDecimal(dcMastRow["def_pert"]);
                                    decimal DutyT = numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0][fldNm]);
                                    decimal DutyI = 0;
                                    int rowSkip = 0;
                                    int rowCnt = MainDataSet.Tables["item_vw"].Rows.Count;
                                    foreach (DataRow ItemRow in MainDataSet.Tables["item_vw"].Rows)
                                    {
                                        DutyI = (numFunction.toDecimal(ItemRow["gro_amt"]) *
                                                 numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0][fldNm])) /
                                                 numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"]);

                                        if (ItemRow.Table.Columns.Contains(DutyN) == true)
                                        {
                                            if (ItemRow.Table.Columns[fldNm].DataType.ToString().Trim().ToUpper() == "SYSTEM.DECIMAL")
                                            {
                                                ItemRow[DutyN] = DutyV;
                                            }
                                        }

                                        if ((DutyT - DutyI) <= 0)
                                        {
                                            ItemRow[fldNm] = DutyT;
                                        }
                                        else
                                        {
                                            ItemRow[fldNm] = DutyI;
                                            DutyT = DutyT - DutyI;

                                            if (rowCnt == rowSkip)
                                            {
                                                ItemRow[fldNm] = numFunction.toDecimal(ItemRow[fldNm]) +
                                                                   DutyT;
                                            }
                                        }
                                        ItemRow.AcceptChanges();
                                    }  // item_vw loop
                                    MainDataSet.Tables["item_vw"].AcceptChanges();
                                }
                            }
                        } // dcmast_vw loop
                    }
                    catch
                    {
                    }
                } // end ItemPage and ChargesPage

                // for Allocation Details
                if (DBPropsSession.AllocationPage == true)
                {
                    // replace all with 0
                    foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                    {
                        acdetRow["ref_no"] = "";
                        acdetRow["re_all"] = 0;
                        acdetRow["tds"] = 0;
                        acdetRow["disc"] = 0;
                        acdetRow.AcceptChanges();
                    }
                    MainDataSet.Tables["acdet_vw"].AcceptChanges();

                    if (MainDataSet.Tables["mall_vw"] != null)
                    {
                        string sortExp = "ac_id ASC";
                        DataView mallView = new DataView(MainDataSet.Tables["mall_vw"], "", sortExp, DataViewRowState.CurrentRows);
                        foreach (DataRowView mallRowView in mallView)
                        {
                            string ProceedM = Convert.ToString(mallRowView["Party_nm"]).Trim();
                            int ProceedI = Convert.ToInt32(mallRowView["ac_id"]);
                            string mRefNo = "";
                            string mEntryTy = "";
                            decimal mreAll = 0;
                            decimal mTds = 0;
                            decimal mDisc = 0;
                            decimal mTds1 = 0;
                            decimal mDisc1 = 0;

                            foreach (DataRow MallRow in MainDataSet.Tables["mall_vw"].Select("ac_id = " + ProceedI))
                            {
                                mreAll = mreAll +
                                         numFunction.toDecimal(MallRow["new_all"]) +
                                         numFunction.toDecimal(MallRow["Tds"]) +
                                         numFunction.toDecimal(MallRow["Disc"]);

                                mTds = mTds + Convert.ToString(MallRow["entry_ty"]).Trim() ==
                                              Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]) &&
                                              DateFormat.TodateTime(MallRow["date"]) ==
                                              DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["Date"]) &&
                                              Convert.ToString(MallRow["doc_no"]).Trim() ==
                                              Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]) ?
                                              numFunction.toDecimal(MallRow["tds"]) : 0;

                                mDisc = mDisc + Convert.ToString(MallRow["entry_ty"]).Trim() ==
                                              Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]) &&
                                              DateFormat.TodateTime(MallRow["date"]) ==
                                              DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["Date"]) &&
                                              Convert.ToString(MallRow["doc_no"]).Trim() ==
                                              Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]) ?
                                              numFunction.toDecimal(MallRow["Disc"]) : 0;

                                mTds1 = mTds1 + mTds;
                                mDisc1 = mDisc1 + mDisc;

                                mEntryTy = Convert.ToString(MallRow["entry_ty"]).Trim() ==
                                              Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]) &&
                                              DateFormat.TodateTime(MallRow["date"]) ==
                                              DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["Date"]) &&
                                              Convert.ToString(MallRow["doc_no"]).Trim() ==
                                              Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]) ?
                                              Convert.ToString(MallRow["entry_all"]) :
                                              Convert.ToString(MallRow["entry_ty"]);

                                mRefNo = mRefNo.Trim() + ((mRefNo.Trim().IndexOf(mEntryTy) >= 0 ||
                                         mEntryTy.Trim() == "") ?
                                         "" :
                                         mEntryTy.Trim() + "/");
                            } // end mall_vw loop

                            try // Seach row in acdet_vw
                            {
                                DataRow acdetRow = MainDataSet.Tables["acdet_vw"].Select("ac_name = '" + ProceedM.Trim() + "'")[0];

                                if (numFunction.toDecimal(acdetRow["amount"]) < numFunction.toDecimal(acdetRow["re_all"]))
                                {
                                    ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", DisplayMessage("Allocated Amount can't be more than Amount for " + ProceedM.Trim()), true);
                                    return false;
                                }
                                else
                                {
                                    acdetRow["ref_no"] = mRefNo.Trim();
                                    acdetRow["re_all"] = mreAll;
                                    acdetRow["tds"] = mTds;
                                    acdetRow["disc"] = mDisc;
                                    acdetRow.AcceptChanges();
                                }
                            }
                            catch // row not found
                            {
                                if (mTds1 != 0 && mDisc1 != 0)
                                {
                                    string Message = (mTds1 != 0 ?
                                        "TDS has been Deducted in this entry //n " :
                                        "") +
                                        (mDisc1 != 0 ?
                                        "Discount has been given in this entry //n " :
                                        "") +
                                        "//n //n  " + ProceedM.Trim() + " not found in Account Posting";

                                    ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", DisplayMessage(Message), true);
                                    return false;
                                }


                                foreach (DataRow MallRow in MainDataSet.Tables["mall_vw"].Select("ac_id = " + ProceedI))
                                {
                                    MallRow["new_all"] = 0;
                                    MallRow.AcceptChanges();
                                }
                            }

                            MainDataSet.Tables["acdet_vw"].AcceptChanges();
                            MainDataSet.Tables["mall_vw"].AcceptChanges();
                        } // loop of Dataview mallView
                    }
                } // end (DBPropsSession.AllocationPage == true)

                 
                SqlCommand cmd = new SqlCommand(); // Sqlcommand Object define for Update 
                AllUpdate(MainDataSet);
                IsSave = true;
                return IsSave; 
                //ScriptManager.RegisterStartupScript(thisPage.Page, thisPage.GetType(), "alert()", "AddRecAgain('Saved Succesfully, Add More Records ? \\n Click OK or Cancel to Continue','" + btnAddAgain.ClientID + "','" + btnDiscardTop.ClientID + "');", true);
            }
            catch (Exception Ex)
            {
                //DataAcess.RollBackTransaction();
                //DataAcess.Connclose();
                throw new Exception(Ex.Message); 
                //ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", "alert('" + Ex.Message + "');", true);
                //ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "ErroMess", "alert('Exceeding The Petty Cash Balance. Could not Save');", true);
                //return false;
            }

        }

        public void AllUpdate(DataSet MainDataSet)
                              
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            if (DBPropsSession.AddMode == true)
            {
                GenereateDocNo DocumentNo = new GenereateDocNo();
                //DocumentNo.DBPropsSession = DBPropsSession;  
                string DocNo = "";
                try
                {
                    DocNo = DocumentNo.GenDocNo(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim(),
                                                     DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]),
                                                     Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim().Length,
                                                     null,
                                                     false,ref connHandle);
                    DataAcess.Connclose(connHandle);
                }
                catch (Exception Ex)
                {
                    throw new Exception("ERROR found while Generating Document No.|" +
                                        Ex.Message.Trim());
                }

                if (DocNo.Trim() == "")
                {
                    throw new Exception ("Blank document no., not allowed ..!!!");
                }

                // Document no update for all item releated DataTables
                if (DBPropsSession.ItemPage == true)
                {
                    // Check itref_vw exist in DataSet
                    if (MainDataSet.Tables.Contains("itref_vw") == true)
                    {
                        filterExp = "entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                    " and date = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                    " and doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                        foreach (DataRow itRefRow in MainDataSet.Tables["itref_vw"].Select(filterExp))
                        {
                            itRefRow["doc_no"] = DocNo.Trim();
                            itRefRow.AcceptChanges();
                        }
                        MainDataSet.Tables["itref_vw"].AcceptChanges();
                    }

                    // Check Rmdet_vw exist in DataSet
                    if (MainDataSet.Tables.Contains("Rmdet_vw") == true)
                    {
                        filterExp = "entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                    " and date = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                    " and doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                        foreach (DataRow RmdetRow in MainDataSet.Tables["Rmdet_vw"].Select(filterExp))
                        {
                            RmdetRow["doc_no"] = DocNo.Trim();
                            RmdetRow.AcceptChanges();
                        }
                        MainDataSet.Tables["Rmdet_vw"].AcceptChanges();
                    }

                    filterExp = "entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                " and date = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                " and doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                    foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Select(filterExp))
                    {
                        itemRow["doc_no"] = DocNo.Trim();
                        itemRow.AcceptChanges();
                    }
                    MainDataSet.Tables["item_vw"].AcceptChanges();
                }

                if (DBPropsSession.AccountPage == true)
                {
                    filterExp = "entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                " and date = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                " and doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                    foreach (DataRow acDetRow in MainDataSet.Tables["acdet_vw"].Select(filterExp))
                    {
                        acDetRow["doc_no"] = DocNo.Trim();
                        acDetRow.AcceptChanges();
                    }
                    MainDataSet.Tables["acdet_vw"].AcceptChanges();
                }

                // update Document No. in mall_vw
                if (DBPropsSession.AllocationPage == true)
                {
                    if (MainDataSet.Tables.Contains("mall_vw") == true)
                    {
                        filterExp = "entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                    " and date = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                    " and doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                        foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Select(filterExp))
                        {
                            mallRow["doc_no"] = DocNo.Trim();
                            mallRow.AcceptChanges();
                        }

                        filterExp = "entry_all = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                    " and date_all = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                    " and doc_all = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                        foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Select(filterExp))
                        {
                            mallRow["doc_all"] = DocNo.Trim();
                            mallRow.AcceptChanges();
                        }

                        MainDataSet.Tables["mall_vw"].AcceptChanges();

                    }
                }

                MainDataSet.Tables["main_vw"].Rows[0]["doc_no"] = DocNo.Trim();
                MainDataSet.Tables["main_vw"].AcceptChanges();
            } // end AddMode


            string InvoiceNo = "";
            SqlCommand cmd = new SqlCommand();  // Cmd use for open transaction
            if (bitFunction.toBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["auto_inv"]) == true)
            {
                GenerateInvoiceNo genInvoiceNo = new GenerateInvoiceNo();
                //genInvoiceNo.DBPropsSession = DBPropsSession;
                genInvoiceNo.Cmd = cmd;

                InvoiceNo = genInvoiceNo.GenInvNo(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim(),
                                      Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim(),
                                      Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim(),
                                      DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]),
                                      DBPropsSession.EditSeries,
                                      DBPropsSession.EditInvoice,
                                      Convert.ToInt32(MainDataSet.Tables["lcode_vw"].Rows[0]["invno_size"]),
                                      MainDataSet.Tables["main_vw"],
                                      MainDataSet.Tables["company"],ref connHandle);
                                      
                if (InvoiceNo.Trim() == "")
                {
                    throw new Exception("Blank Invoice No.");
                }
                cmd = genInvoiceNo.Cmd;  
                MainDataSet.Tables["main_vw"].Rows[0]["inv_no"] = InvoiceNo.Trim();

            }
            else
            {
                bool InvoiceNoFlg = false;
                InvoiceNo = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();

                if (DBPropsSession.PcvType == "PT" ||
                    DBPropsSession.Behave == "PT")
                {
                    SqlStr = "Select top 2 Entry_ty,Date,Doc_no From " +
                             DBPropsSession.Entry_Tbl.Trim() + "main where " +
                             "entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                             " and inv_sr ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim() + "'" +
                             " and inv_no ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim() + "'" +
                             " and l_yn ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["l_yn"]).Trim() + "'" +
                             " and ac_id ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["ac_id"]).Trim() + "'";
                }
                else
                {
                    SqlStr = "Select top 2 Entry_ty,Date,Doc_no From " +
                             DBPropsSession.Entry_Tbl.Trim() + "main where " +
                             "entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                             " and inv_sr ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim() + "'" +
                             " and inv_no ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim() + "'" +
                             " and l_yn ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["l_yn"]).Trim() + "'";
                }

                DataTable tmpTblVw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connHandle);

                if (tmpTblVw != null)
                {
                    try
                    {
                        filterExp = "entry_ty !='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                    " and Date !='" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]) + "'" +
                                    " and doc_no !='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]) + "'";
                        DataRow mainRow = tmpTblVw.Select(filterExp)[0];
                        InvoiceNoFlg = true;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    InvoiceNoFlg = true;
                }

                if (InvoiceNoFlg == true)
                {
                    throw new Exception("Invoice already exist, Please reenter..!!!");
                }

            }  // end auto_inv = true

            if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim() +
                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim() !=
                DBPropsSession.JustSeries + DBPropsSession.JustInvoice)
            {
                DBPropsSession.JustSeries = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                DBPropsSession.JustInvoice = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            }

            string SysDate = "";

            SqlStr = "select getdate()  as curdate";
            DR = DataAcess.ExecuteDataReader(SqlStr,cmd,ref connHandle);
            if (DR.HasRows == true)
            {
                while(DR.Read())
                {
                    SysDate = Convert.ToDateTime(DR["curDate"]).Year.ToString().Trim() + "/" +
                              Convert.ToDateTime(DR["curDate"]).Month.ToString().Trim() + "/" +
                              Convert.ToDateTime(DR["curDate"]).Day.ToString().Trim();
                }
            }
            DR.Close();
            DR.Dispose();

            // lcode general approval 
            
            if (bitFunction.toBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["apgenps"]) == false)
            {
                MainDataSet.Tables["main_vw"].Rows[0]["Apgen"] = "YES";
                MainDataSet.Tables["main_vw"].Rows[0]["Apgenby"] = "Username";
                MainDataSet.Tables["main_vw"].Rows[0]["Apgentime"] = SysDate;
            }
            else
            {
                MainDataSet.Tables["main_vw"].Rows[0]["Apgen"] = "PENDING";
                MainDataSet.Tables["main_vw"].Rows[0]["Apgenby"] = "";
                MainDataSet.Tables["main_vw"].Rows[0]["Apgentime"] = "";
            }

            // lcode posting approval 
            if (bitFunction.toBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["apledps"]) == false)
            {
                MainDataSet.Tables["main_vw"].Rows[0]["Apled"] = "YES";
                MainDataSet.Tables["main_vw"].Rows[0]["Apledby"] = "Username";
                MainDataSet.Tables["main_vw"].Rows[0]["Apledtime"] = SysDate;
            }
            else
            {
                MainDataSet.Tables["main_vw"].Rows[0]["Apled"] = "PENDING";
                MainDataSet.Tables["main_vw"].Rows[0]["Apledby"] = "";
                MainDataSet.Tables["main_vw"].Rows[0]["Apledtime"] = "";
            }

            MainDataSet.Tables["main_vw"].Rows[0]["user_name"] = "username";
            MainDataSet.Tables["main_vw"].Rows[0]["sysdate"] = SysDate;
            MainDataSet.Tables["main_vw"].Rows[0]["compid"] = Convert.ToInt32(MainDataSet.Tables["company"].Rows[0]["compid"]);

            // Checked Cancelled Party

            if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).IndexOf("CANCELLED") >= 0)
            {
                MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"] = 0;
                MainDataSet.Tables["main_vw"].Rows[0]["net_amt"] = 0;
                MainDataSet.Tables["main_vw"].Rows[0]["form_nm"] = "";
            }
            else
            {
                if (numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"]) <= 0)
                {
                    MainDataSet.Tables["main_vw"].Rows[0]["Gro_amt"] =
                        numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0]["net_amt"]);
                }

                if (numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0]["net_amt"]) <= 0)
                {
                    MainDataSet.Tables["main_vw"].Rows[0]["net_amt"] =
                        numFunction.toDecimal(MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"]);
                }

                if (DBPropsSession.ItemPage == true)
                {
                    foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                    {
                        itemRow["dept"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim();
                        itemRow["cate"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim();
                        itemRow["compid"] = Convert.ToInt32(MainDataSet.Tables["company"].Rows[0]["compId"]);
                        itemRow["ac_id"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["ac_id"]);
                        itemRow["Party_nm"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim();
                        itemRow["inv_sr"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                        itemRow["inv_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                        itemRow["l_yn"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["l_yn"]).Trim();
                        itemRow["pmkey"] = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["inv_stk"]).Trim();
                        itemRow["sr_sr"] = "";
                        itemRow.AcceptChanges();  
                    }
                }

                // Account Page

                if (DBPropsSession.AccountPage == true)
                {
                    try
                    {
                        foreach (DataRow LotherRow in MainDataSet.Tables["lother_vw"].Select("att_file = 1"))
                        {
                            string tblName = "";
                            string fldName = Convert.ToString(LotherRow["fld_nm"]).Trim();
                            tblName = (Convert.ToString(LotherRow["tbl_nm"]).Trim() == "" ?
                                "MAIN" :
                                Convert.ToString(LotherRow["tbl_nm"]).Trim()) + "_vw";
                            tblName = tblName.Replace(DBPropsSession.Entry_Tbl.Trim(), "  ").Trim();  

                            if (MainDataSet.Tables["acdet_vw"].Columns.Contains(fldName) == true &&
                                MainDataSet.Tables[tblName].Columns.Contains(fldName) == true)
                            {
                                foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                                {
                                    acdetRow[fldName] = MainDataSet.Tables[tblName].Rows[0][fldName];
                                }
                            }
                        }
                    }
                    catch (NullReferenceException Ex)
                    {
                        throw new NullReferenceException("Table name is not proper define " +
                                                            "in lother according Transaction type |" +
                                                            Ex.Message.Trim()); 
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message.Trim()); 
                    }


                    if (MainDataSet.Tables["acdet_Vw"].Columns.Contains("postord") == true)
                    {
                        DataView AcPost = MainDataSet.Tables["acdet_vw"].Clone().DefaultView;
                        AcPost.Sort = "Ac_name ASC,Amt_ty ASC";

                        try
                        {
                            filterExp = "ac_name ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim() + "'";
                            DataRow acdetvwRow = MainDataSet.Tables["acdet_vw"].Select(filterExp)[0];

                            DataRowView GatherRowView = AcPost.AddNew();
                            for (int i = 0; i < acdetvwRow.Table.Columns.Count; i++)
                            {
                                GatherRowView[i] = acdetvwRow[i];
                                GatherRowView["postOrd"] = "A";
                            }
                            GatherRowView.EndEdit();  

                        }
                        catch
                        {
                        }

                        string ldebitAccount = "";
                        string lcreditAccount = "";
                        vuAccountPosting AccountPosting = new vuAccountPosting();
                        AccountPosting.CmdTran = cmd; 
                        if (Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["defa_db"]).Trim() != "")
                        {
                            ldebitAccount = AccountPosting.findAccountName(Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["defa_db"]).Trim(),
                                            MainDataSet.Tables["main_vw"],
                                            MainDataSet.Tables["item_vw"],ref connHandle);
                                            
                                                            
                        }

                        if (Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["defa_cr"]).Trim() != "")
                        {
                            lcreditAccount = AccountPosting.findAccountName(Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["defa_cr"]).Trim(),
                                            MainDataSet.Tables["main_vw"],
                                            MainDataSet.Tables["item_vw"],ref connHandle);
                        }

                        cmd = AccountPosting.CmdTran;
                        ldebitAccount = ldebitAccount.Trim().PadRight(Convert.ToString(MainDataSet.Tables["acdet_vw"].Rows[0]["ac_name"]).Trim().Length,' ');
                        lcreditAccount = lcreditAccount.Trim().PadRight(Convert.ToString(MainDataSet.Tables["acdet_vw"].Rows[0]["ac_name"]).Trim().Length,' ');

                        // for debit account
                        if (ldebitAccount.Trim() != "" &&
                            ldebitAccount != Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim())
                        {
                            try
                            {
                                filterExp = "ac_name ='" + ldebitAccount.Trim() + "'";
                                DataRow acdetvwRow = MainDataSet.Tables["acdet_vw"].Select(filterExp)[0];
                                try
                                {
                                    foreach (DataRowView Drv in AcPost)
                                    {
                                        if (Convert.ToString(Drv["ac_name"]).Trim() != ldebitAccount.Trim())
                                        {
                                            DataRowView GatherRowView = AcPost.AddNew();
                                            for (int i = 0; i < acdetvwRow.Table.Columns.Count; i++)
                                            {
                                                GatherRowView[i] = acdetvwRow[i];
                                                GatherRowView["postOrd"] = "B";
                                            }
                                            GatherRowView.EndEdit();
                                        }
                                    }

                                }
                                catch
                                {

                                }

                            }
                            catch
                            {
                            }   
                        }

                        // for credit account
                        if (lcreditAccount.Trim() !="" &&
                            lcreditAccount.Trim() != Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Party_nm"]).Trim())
                        {
                            try
                            {
                                filterExp = "ac_name ='" + lcreditAccount.Trim() + "'";
                                DataRow acdetvwRow = MainDataSet.Tables["acdet_vw"].Select(filterExp)[0];
                                try
                                {
                                    foreach (DataRowView Drv in AcPost)
                                    {
                                        if (Convert.ToString(Drv["ac_name"]).Trim() != lcreditAccount.Trim())
                                        {
                                            DataRowView GatherRowView = AcPost.AddNew();
                                            for (int i = 0; i < acdetvwRow.Table.Columns.Count; i++)
                                            {
                                                GatherRowView[i] = acdetvwRow[i];
                                                GatherRowView["postOrd"] = "B";
                                            }
                                            GatherRowView.EndEdit();
                                        }
                                    }

                                }
                                catch
                                {

                                }

                            }
                            catch
                            {
                            }   
                        }
                    }

                    // Item wise Accounting Pending
                    //if (DBPropsSession.ItemPage == true &&
                    //    ((strFunction.InList(DBPropsSession.PcvType, new string[]{"PT","PR"}) == true ||
                    //     strFunction.InList(DBPropsSession.Behave, new string[]{"PT","PR"}) == true)
                    //    && Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["p_item"]) == true)
                    //    ||
                    //    ((strFunction.InList(DBPropsSession.PcvType, new string[]{"ST","SR"}) == true ||
                    //     strFunction.InList(DBPropsSession.Behave, new string[]{"ST","SR"}) == true)
                    //    && Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["s_item"]) == true))
                    //{
                    //    //foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)  
                    //    //{

                    //    //}
                    //}
                    //

                    int acdetRows = MainDataSet.Tables["acdet_vw"].Rows.Count;   
                    string[] oacArr = new string[acdetRows];
                    int oacR = 0;
                    foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                    {
                        //oacArr[oacR] = Convert.ToString(acdetRow["ac_name"]).Trim() +
                        //               (string.Empty.PadLeft(Convert.ToString(acdetRow["ac_name"]).Length -
                        //               Convert.ToString(acdetRow["ac_name"]).Trim().Length, ' ')) +
                        //               numFunction.toDecimal(acdetRow["amount"]).ToString().Trim() +
                        //               Convert.ToString(acdetRow["amt_ty"]).Trim();

                        oacArr[oacR] = Convert.ToString(acdetRow["ac_name"]).Trim() + "|" +
                                        numFunction.toDecimal(acdetRow["amount"]).ToString().Trim() +
                                        Convert.ToString(acdetRow["amt_ty"]).Trim();
                        oacR = oacR + 1;
                    }


                    foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                    {
                        acdetRow["oac_name"] = "";
                        int fstName = 1;

                        for (int i=0;i<=oacR-1;i++)
                        {
                            if ((oacArr[i].Substring(0,oacArr[i].IndexOf('|'))).Trim() 
                                != Convert.ToString(acdetRow["ac_name"]).Trim())
                            {
                                acdetRow["oac_name"] = (fstName == 1 ? 
                                    "":
                                    Convert.ToString(acdetRow["oac_name"]) + "\r\n")+
                                    oacArr[i].Substring(0, oacArr[i].IndexOf('|')).Trim()+oacArr[i].Substring(oacArr[i].IndexOf('|')+1, oacArr[i].Length - oacArr[i].IndexOf('|')-1).Trim(); 
                                fstName = fstName + 1;
                                acdetRow.AcceptChanges();  
                            }

                        }
                    }

                    //Convert.ToDateTime(DateFormat.GetDateSTR(MainDataSet.Tables["main_vw"].Rows[0]["date"])).ToString() 

                    filterExp = "entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                " and date = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                " and doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                    foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Select(filterExp))
                    {
                        acdetRow["dept"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim();
                        acdetRow["cate"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim();
                        acdetRow["compid"] = Convert.ToInt32(MainDataSet.Tables["company"].Rows[0]["compId"]);
                        acdetRow["inv_sr"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                        acdetRow["inv_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                        acdetRow["l_yn"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["l_yn"]).Trim();
                        acdetRow.AcceptChanges();  
                    }
                }  // End AccountPage

                // Allocation Page
                if (DBPropsSession.AllocationPage == true &&
                    MainDataSet.Tables.Contains("mall_vw") == true)
                {
                    if (MainDataSet.Tables["mall_vw"].Columns.Contains("inv_sr") == true)
                    {
                        filterExp = "entry_all = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                    " and date_all = '" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "'" +
                                    " and doc_all = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                        foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Select(filterExp))
                        {
                            mallRow["inv_sr"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                            mallRow["inv_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                            mallRow["l_yn"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["l_yn"]).Trim();
                            mallRow.AcceptChanges();  
                        }
                    }
                } // End Allocation Page
            } // End not cancelled

            int tranCd = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
            SqlStr = "";

            if (DBPropsSession.AddMode == true)
            {
                tranCd =0;
                SqlStr = DataAcess.GenInsertString(MainDataSet.Tables["main_vw"],
                                    DBPropsSession.Entry_Tbl+"main",
                                    new string[] {"tran_cd"},
                                    null);
            }
            else
            {
                string cond = " tran_cd = " + tranCd;
                SqlStr = "select top 1 tran_cd from " + DBPropsSession.Entry_Tbl+"main" + 
                         " where " + cond.Trim();
                         
                DR = DataAcess.ExecuteDataReader(SqlStr,cmd,ref connHandle); 
                SqlStr = "";
                if (DR.HasRows == true)
                {
                    SqlStr = DataAcess.GenUpdateString(MainDataSet.Tables["main_vw"],
                                                DBPropsSession.Entry_Tbl+"main",
                                                new string[]{"tran_cd"},
                                                null,
                                                cond.Trim(),
                                                null);
                }
                DR.Close();
                DR.Dispose(); 
            }

            try
            {
                // Start Transaction
                //SqlCommand cmd = new SqlCommand();
                bool tranSucess = true;
                if (SqlStr.Trim() != "")
                {
                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true, ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        tranSucess = true;
                    }
                    catch (Exception Ex)
                    {
                        tranSucess = false;
                        DataAcess.RollBackTransaction(cmd.Transaction);
                        DataAcess.Connclose(connHandle);
                        throw Ex;
                    }
                }

                if (tranSucess == true && tranCd <= 0)
                {
                    SqlStr = "Select top 1 Tran_cd From " + DBPropsSession.Entry_Tbl + "main" +
                             " where entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                             " and date ='" + DateFormat.dateformat(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"])) + "'" +
                             " and doc_no ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "'";

                    DR = DataAcess.ExecuteDataReader(SqlStr, cmd, ref connHandle);
                    if (DR.HasRows == true)
                    {
                        while (DR.Read())
                        {
                            tranCd = Convert.ToInt32(DR["tran_cd"]);
                        }
                    }
                    DR.Close();
                    DR.Dispose();
                }

                MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"] = tranCd;
                MainDataSet.Tables["main_vw"].AcceptChanges();
                MainDataSet.Tables["item_vw"].AcceptChanges();
                MainDataSet.Tables["acdet_vw"].AcceptChanges();
                if (MainDataSet.Tables.Contains("mall_vw") == true)
                    MainDataSet.Tables["mall_vw"].AcceptChanges();

                if (DBPropsSession.AddMode == true)
                {
                    AddUpdate(MainDataSet, cmd, ref connHandle);

                }
                else
                {
                    EditUpdate(MainDataSet, cmd, ref connHandle);
                }

                DataAcess.CommitTransaction(cmd.Transaction);
            }
            catch (Exception Ex)
            {
                DataAcess.RollBackTransaction(cmd.Transaction);
                throw Ex;
            }
            finally
            {
                DataAcess.Connclose(connHandle);
            }
        }

        # region For Add Rows
        public void AddUpdate(DataSet MainDataSet,
                    SqlCommand cmd, ref SqlConnection connTran)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            vuAllocation checkTable = new vuAllocation();

            if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).IndexOf("CANCELLED") < 0)
            {
                if (DBPropsSession.ItemPage == true)
                {
                    foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                    {
                        itemRow["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                        itemRow.AcceptChanges(); 
                    }

                    if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex")  >=0 &&
                        (strFunction.InList(DBPropsSession.PcvType, new string[] {"DC","AR","SS","IR","GT"}) == true ||
                        strFunction.InList(DBPropsSession.Behave , new string[] {"DC","AR","SS","IR","GT"}) == true ))
                    {
                        if ((strFunction.InList(DBPropsSession.PcvType, new string[] {"DC","IR","SS"}) == true ||
                            strFunction.InList(DBPropsSession.Behave , new string[] {"DC","IR","SS"}) == true) ||
                            ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                            bitFunction.toBoolean( MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true) &&
                            strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(),new string[]{"EXCISE","NON-EXCISE"}) == true)
                        {
                            foreach (DataRow litemallRow in MainDataSet.Tables["litemall_vw"].Rows)
                            {
                                litemallRow["tran_cd"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                                litemallRow["compid"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["compid"]);
                                litemallRow.AcceptChanges();
                            }

                            string _chkTbl = "";
                            string mentry_ty = "#";
                            string _mentry_ty = "#";

                            foreach (DataRow litemallRow in MainDataSet.Tables["litemall_vw"].Rows)
                            {
                                SqlStr = "";
                                _mentry_ty = Convert.ToString(litemallRow["pentry_ty"]).Trim();

                                if ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") ||
                                    bitFunction.toBoolean( MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true)
                                    _mentry_ty = Convert.ToString(litemallRow["rentry_ty"]).Trim();

                                _chkTbl = mentry_ty != _mentry_ty ?
                                        checkTable.chkTable(_mentry_ty,cmd,ref connTran) :
                                        _chkTbl;
                                mentry_ty = _mentry_ty;

                                SqlStr = "update " + _chkTbl.Trim()+"item" + " set balqty = (balqty-" + numFunction.toDecimal(litemallRow["qty"]) +")";
                                if ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") ||
                                    bitFunction.toBoolean( MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true)
                                {
                                    SqlStr = " update " + _chkTbl.Trim()+"item" + " set balqty=(balqty+" + numFunction.toDecimal(litemallRow["qty"]) +")";
                                }
                                int mtex_exs = 1;
                                while (mtex_exs < DBPropsSession.Tex_exe)
                                {
                                    SqlStr = SqlStr + "," + SessionProxy.Tex_ExAr[mtex_exs, 2] + "=(" + SessionProxy.Tex_ExAr[mtex_exs, 2] +
                                        ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                                        (bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true) ? "+" : "-") +
                                        litemallRow[SessionProxy.Tex_ExAr[mtex_exs, 1].Trim()] + ")";
                                    mtex_exs = mtex_exs + 1;
                                }

                                if ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") ||
                                    bitFunction.toBoolean( MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true)
                                {
                                    SqlStr = SqlStr + " where entry_ty ='" + Convert.ToString(litemallRow["rentry_ty"]).Trim() + "' and " +
                                             " date ='" + DateFormat.dateformat(Convert.ToString(litemallRow["rdate"]).Trim()) + "' and " +
                                             " doc_no='" + Convert.ToString(litemallRow["rdoc_no"]).Trim() +"' and it_serial =" + 
                                             Convert.ToString(litemallRow["ritserial"]).Trim() + "'";
                                }
                                else
                                {
                                    SqlStr = SqlStr + " where entry_ty='" + Convert.ToString(litemallRow["pentry_ty"]).Trim() +"' and " +
                                             " tran_cd = "+ numFunction.toInt32(litemallRow["ptran_cd"]) + " and itserial ='" + 
                                             Convert.ToString(litemallRow["pitserial"]).Trim() + "'";
                                }

                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    throw ex;
                                }
                                 
                                SqlStr = "";
                                SqlStr = DataAcess.GenInsertString(litemallRow,"litemall",null,null);
                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    throw ex;
                                }
    
                            }
                        } // end

                        if ((strFunction.InList(DBPropsSession.PcvType,new string[] {"AR","IR"}) == true ||
                            strFunction.InList(DBPropsSession.Behave ,new string[] {"AR","IR"}) == true) ||
                            ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                            bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false) &&
                            strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim(), new string[]{"EXCISE","NON-EXCISE"}) == true)
                        {
                            foreach (DataRow manuDetRow in MainDataSet.Tables["manu_det_vw"].Rows)
                            {
                                manuDetRow["tran_cd"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                                manuDetRow["compid"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["compid"]);
                                manuDetRow.AcceptChanges();
                            }

                            SqlStr = "";
                            SqlStr = DataAcess.GenInsertString(MainDataSet.Tables["manu_det_vw"],"manu_det",null,null);

                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                throw ex;
                            }

                        }

                        // pending IR
                        if (DBPropsSession.PcvType == "IR" || DBPropsSession.Behave == "IR")
                        {
                            string _chktbl = checkTable.chkTable("II",cmd,ref connTran);
                            string mentry_ty = "";
                            string iimaintable = _chktbl.Trim();
                        }


 
                    
                    }
                    foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                    {
                        string fldQty = DBPropsSession.Entry_Tbl + "qty";
                        decimal iQty = Convert.ToString(itemRow["dc_no"]).Trim() == "" ?
                            numFunction.toDecimal(itemRow["qty"]) :
                            0;
                        SqlStr = "Select top 1 It_code,It_name from it_bal " +
                                 " where it_code = " + 
                                  Convert.ToInt32(MainDataSet.Tables["item_vw"].Rows[0]["it_code"]);
                        DataTable itBalTmpvw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);

                        if (itBalTmpvw.Rows.Count <= 0)
                        {
                            DataRow itBalTmpvwRow = itBalTmpvw.NewRow();
                            itBalTmpvwRow["it_name"] = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[0]["item"]);
                            itBalTmpvwRow["it_code"] = Convert.ToInt32(MainDataSet.Tables["item_vw"].Rows[0]["it_code"]);
                            itBalTmpvw.Rows.Add(itBalTmpvwRow);
                            itBalTmpvwRow.AcceptChanges();
  
                            SqlStr = "";
                            SqlStr = DataAcess.GenInsertString(itBalTmpvw, "it_bal", null, null);
                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                throw ex;
                            }
                        }

                        SqlStr = "update it_bal set " + fldQty + "= isnull(" + fldQty + ",0) + " + iQty +
                                 " where it_code = " +
                                 Convert.ToInt32(MainDataSet.Tables["item_vw"].Rows[0]["it_code"]);
                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();
                            isSuccess = true;
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            throw ex;
                        }

                        SqlStr = "Select top 1 It_code,Ware_nm,Entry_ty,Date " +
                            " From It_balw where It_code = " +
                            Convert.ToInt32(MainDataSet.Tables["item_vw"].Rows[0]["it_code"]) +
                            " and ware_nm ='" + Convert.ToString(MainDataSet.Tables["item_vw"].Rows[0]["ware_nm"]).Trim() + "'" +
                            " and entry_ty ='" + Convert.ToString(MainDataSet.Tables["item_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                            " and date ='" + DateFormat.dateformat(Convert.ToDateTime(MainDataSet.Tables["item_vw"].Rows[0]["date"])) + "'";

                        itBalTmpvw = new DataTable();

                        itBalTmpvw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connTran);

                        if (itBalTmpvw.Rows.Count <= 0)
                        {
                            DataRow itBalTmpvwRow = itBalTmpvw.NewRow();
                            itBalTmpvwRow["it_code"] = Convert.ToInt32(MainDataSet.Tables["item_vw"].Rows[0]["it_code"]);
                            itBalTmpvwRow["ware_nm"] = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[0]["ware_nm"]);
                            itBalTmpvwRow["entry_ty"] = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[0]["entry_ty"]);
                            itBalTmpvwRow["date"] = DateFormat.TodateTime(MainDataSet.Tables["item_vw"].Rows[0]["date"]); 
                            itBalTmpvw.Rows.Add(itBalTmpvwRow);
                            itBalTmpvwRow.AcceptChanges();

                            SqlStr = DataAcess.GenInsertString(itBalTmpvw,
                                                "it_balw",
                                                null,
                                                null);
                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                                isSuccess = true;
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                isSuccess = false;
                                throw ex;
                            }
                        }

                        
                        SqlStr = "Update It_balw Set qty= isnull(qty,0) + " + iQty +
                                 " where It_code = " + 
                                 Convert.ToInt32(MainDataSet.Tables["item_vw"].Rows[0]["it_code"]) +
                                 " and ware_nm ='" + Convert.ToString(MainDataSet.Tables["item_vw"].Rows[0]["ware_nm"]) + "'" +
                                 " and entry_ty ='" + Convert.ToString(MainDataSet.Tables["item_vw"].Rows[0]["entry_ty"]) + "'" +
                                 " and date ='" + DateFormat.dateformat(Convert.ToDateTime(MainDataSet.Tables["item_vw"].Rows[0]["date"])) + "'";

                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery(); 
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            isSuccess = false;
                            throw ex;
                        }

                        if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >=0 && 
                            ((strFunction.InList(DBPropsSession.PcvType,new string[] {"AR","IR"}) == true ||
                             strFunction.InList(DBPropsSession.Behave,new string[] {"AR","IR"}) == true) ||
                             ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                             bitFunction.toBoolean (MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false)))
                        {
                                try
                                {
                                    GenerateRGPage RgPage = new GenerateRGPage();
                                    RgPage.RgPageValidation("INSERT",
                                                itemRow,
                                                MainDataSet.Tables["main_vw"].Rows[0],
                                                MainDataSet.Tables["manufact"].Rows[0],
                                                MainDataSet.Tables["company"].Rows[0],  
                                                DBPropsSession.AddMode,
                                                DBPropsSession.EditMode,
                                                cmd,ref connTran);
                                }
                                catch (Exception Ex)
                                {
                                    throw Ex;
                                }
                        }
                        SqlStr = "";
                        //changed by uday
                        SqlStr = DataAcess.GenInsertString(itemRow,
                                            DBPropsSession.Entry_Tbl + "item",
                                            null,
                                            null);

                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            throw ex;
                            
                        }
                                                
                    }  // End iteration of item_vw
                } // end ItemPage

                // AccountPage
                if (DBPropsSession.AccountPage == true)
                {
                    foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                    {
                        acdetRow["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                        acdetRow.AcceptChanges();  
                    }

                    if (MainDataSet.Tables.Contains("mall_vw") == true)
                    {
                        SqlStr = "select * from " + DBPropsSession.Entry_Tbl + "mall" +
                                 " where 1=0";

                        DataTable tmpMall_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);

                        //update tran_cd of mall_vw
                        foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Select("tran_cd=0"))
                        {
                            mallRow["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                            mallRow.AcceptChanges();
                        }

                        //update main_tran of mall_vw
                        foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Select("tran_cd=0"))
                        {
                            mallRow["main_tran"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                            mallRow.AcceptChanges();
                        }

                        string chkTbl = "";
                        string entryTy = "#";
                        string tmpTbl = "";
                        string entryAll = "";
                        string sqlCond = "";
                        string sqlAcdet = "";
                        foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Rows)
                        {
                            if (numFunction.toDecimal(mallRow["new_all"]) > 0)
                            {
                                if (Convert.ToString(mallRow["entry_ty"]).Trim() ==
                                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim()
                                    &&
                                    Convert.ToInt32(mallRow["tran_cd"]) ==
                                    Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]))
                                {
                                    chkTbl = entryTy != Convert.ToString(mallRow["entry_all"]).Trim() ?
                                        checkTable.chkTable(Convert.ToString(mallRow["entry_all"]).Trim(),cmd,ref connTran) :
                                        chkTbl;
                                    tmpTbl = DBPropsSession.Entry_Tbl;
                                    entryTy = Convert.ToString(mallRow["entry_all"]).Trim();
                                    entryAll = Convert.ToString(mallRow["entry_ty"]).Trim();
                                    sqlCond = "entry_ty ='" + Convert.ToString(mallRow["entry_all"]).Trim() + "'" +
                                              " and tran_cd = " + Convert.ToInt32(mallRow["main_tran"]) +
                                              " and ac_id = " + Convert.ToInt32(mallRow["ac_id"]);
                                    sqlAcdet = chkTbl + "acdet";
                                }
                                else
                                {
                                    chkTbl = entryTy != Convert.ToString(mallRow["entry_all"]).Trim() ?
                                        checkTable.chkTable(Convert.ToString(mallRow["entry_all"]).Trim(),cmd,ref connTran) :
                                        chkTbl;
                                    tmpTbl = chkTbl;
                                    entryTy = Convert.ToString(mallRow["entry_ty"]).Trim();
                                    entryAll = Convert.ToString(mallRow["entry_all"]).Trim();
                                    sqlCond = "entry_ty ='" + Convert.ToString(mallRow["entry_all"]).Trim() + "'" +
                                              " tran_cd = " + Convert.ToInt32(mallRow["main_tran"]) +
                                              " ac_id = " + Convert.ToInt32(mallRow["ac_id"]);
                                    sqlAcdet = chkTbl + "acdet";
                                }

                                SqlStr = "Select top 1 Ref_no,Re_all From " +
                                         sqlAcdet.Trim() + " where " + sqlCond.Trim();

                                DataTable tmptblVw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connTran);
                                if (tmptblVw.Rows.Count > 0)
                                {
                                    tmptblVw.Rows[0]["ref_no"] = !DBNull.Value.Equals(tmptblVw.Rows[0]["ref_no"]) ?
                                                                    "" :
                                                                    Convert.ToString(tmptblVw.Rows[0]["ref_no"]);
                                    tmptblVw.Rows[0]["re_all"] = (numFunction.toDecimal(tmptblVw.Rows[0]["re_all"]) +
                                                        numFunction.toDecimal(mallRow["new_all"]) +
                                                        numFunction.toDecimal(mallRow["disc"]) +
                                                        numFunction.toDecimal(mallRow["tds"]));

                                    tmptblVw.Rows[0]["ref_no"] = Convert.ToString(tmptblVw.Rows[0]["ref_no"]).IndexOf(entryAll) >= 0 ?
                                        Convert.ToString(tmptblVw.Rows[0]["ref_no"]) :
                                        (Convert.ToString(tmptblVw.Rows[0]["ref_no"]).Trim() +
                                         entryAll + "/");
                                    tmptblVw.AcceptChanges();
                                    SqlStr = "";
                                    SqlStr = DataAcess.GenUpdateString(tmptblVw,
                                                    sqlAcdet,
                                                    null,
                                                    new string[] { "ref_no", "ref_all" },
                                                    sqlCond,
                                                    null);
                                    if (SqlStr.Trim() != "")
                                    {
                                        try
                                        {
                                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                            cmd.ExecuteNonQuery();
                                        }
                                        catch (Exception ex)
                                        {
                                            DataAcess.RollBackTransaction(cmd.Transaction);
                                            DataAcess.Connclose(connTran);
                                            throw ex;
                                        }
                                    }
                                }
                                else
                                {
                                    isSuccess = false;
                                }


                                 if (isSuccess == true && mallRow.Table.Columns.Contains("u_serbamt") == true)
                                     
                                 {
                                     if (Convert.ToString(mallRow["entry_ty"]).Trim() == Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() &&
                                         Convert.ToInt32(mallRow["tran_cd"]) == Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]))
                                     {
                                         sqlCond = " entry_all ='" + Convert.ToString(mallRow["entry_all"]).Trim() + "' and " +
                                                   " tran_cd = " + Convert.ToInt32(mallRow["main_tran"]);
                                     }
                                     else
                                     {
                                         sqlCond = " entry_all ='" + Convert.ToString(mallRow["entry_all"]).Trim() + "' and " +
                                                   " tran_cd = " + Convert.ToInt32(mallRow["tran_cd"]);

                                     }

                                     SqlStr = " select * from acdetalloc where " + sqlCond.Trim();

                                     tmptblVw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);
                                     if (tmptblVw.Rows.Count > 0)
                                     {
                                         if (tmptblVw.Rows.Count > 0)
                                         {
                                             foreach (DataRow tmpRows in tmptblVw.Rows)
                                             {
                                                 tmpRows["re_all"] = numFunction.toDecimal(tmpRows["re_all"]) +
                                                                      numFunction.toDecimal(mallRow[Convert.ToString(tmpRows["fld_nm"])]);

                                                 SqlStr = "";
                                                 SqlStr = DataAcess.GenUpdateString(tmptblVw,
                                                                                    sqlAcdet,
                                                                                    null,
                                                                                    new string[] { "re_all" },
                                                                                    sqlCond,
                                                                                    null);
                                                 if (SqlStr.Trim()  != "")
                                                 {
                                                     try
                                                     {
                                                         cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                                         cmd.ExecuteNonQuery();
                                                     }
                                                     catch (Exception ex)
                                                     {
                                                         DataAcess.RollBackTransaction(cmd.Transaction);
                                                         DataAcess.Connclose(connTran);
                                                         throw ex;
                                                     }
                                                 }
                                             }
                                         }
                                         else
                                         {
                                             isSuccess = false;
                                         }
                                     }
                                     else
                                     {
                                         isSuccess = false;
                                     }
                                 }

                                 if (isSuccess == true)
                                 {
                                     DataRow tmpMallRow = tmpMall_vw.NewRow();
                                     for (int j = 0; j < tmpMall_vw.Columns.Count ; j++)
                                     {
                                         for (int i = 0; i < mallRow.Table.Columns.Count; i++)
                                         {
                                             if (tmpMallRow.Table.Columns[j].ColumnName == mallRow.Table.Columns[i].ColumnName)
                                             {

                                                 switch (tmpMallRow.Table.Columns[i].DataType.ToString().Trim().ToUpper())
                                                 {
                                                     case "SYSTEM.STRING":
                                                         tmpMallRow[j] = Convert.ToString(mallRow[i]);
                                                         break;
                                                     case "SYSTEM.DECIMAL":
                                                         tmpMallRow[j] = DBNull.Value.Equals(mallRow[i]) ?
                                                             0 :
                                                             Convert.ToDecimal(mallRow[i]);

                                                         break;
                                                     case "SYSTEM.INT16":
                                                         tmpMallRow[j] = DBNull.Value.Equals(mallRow[i]) ?
                                                             0.0 :
                                                             Convert.ToInt16(mallRow[i]);
                                                         break;
                                                     case "SYSTEM.INT32":
                                                         tmpMallRow[j] = DBNull.Value.Equals(mallRow[i]) ?
                                                             0 :
                                                             Convert.ToInt32(mallRow[i]);
                                                         break;
                                                     case "SYSTEM.INT64":
                                                         tmpMallRow[j] = DBNull.Value.Equals(mallRow[i]) ?
                                                             0 :
                                                             Convert.ToInt64(mallRow[i]);
                                                         break;
                                                     case "SYSTEM.DATETIME":
                                                         tmpMallRow[j] = DBNull.Value.Equals(mallRow[i]) ?
                                                             Convert.ToDateTime("01/01/1900") :
                                                             DateFormat.TodateTime(mallRow[i]);
                                                         break;
                                                     case "SYSTEM.BOOLEAN":
                                                         tmpMallRow[j] = DBNull.Value.Equals(mallRow[i]) ?
                                                             false :
                                                             Convert.ToBoolean(mallRow[i]);
                                                         break;
                                                     default:
                                                         tmpMallRow[j] = mallRow[i];
                                                         break;
                                                 }
                                                 break; 
                                             }
                                         }
                                     }
                                     tmpMall_vw.Rows.Add(tmpMallRow);
                                     tmpMall_vw.AcceptChanges();
  
                                     SqlStr = "";
                                     SqlStr = DataAcess.GenInsertString(tmpMall_vw,
                                                        tmpTbl.Trim() + "mall",
                                                        null,
                                                        null);
                                     try
                                     {
                                         cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                         cmd.ExecuteNonQuery();
                                     }
                                     catch (Exception ex)
                                     {
                                         DataAcess.RollBackTransaction(cmd.Transaction);
                                         DataAcess.Connclose(connTran);
                                         throw ex;
                                     }
                                 }

                             }  // End mallRow["new_all"]
                        } // End Foreach Loop mall_vw

                    } // End MainDataSet.Tables.Contains("mall_vw") == true

                    foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                    {
                        string fld = Convert.ToString(acdetRow["amt_ty"]).Trim();
                        SqlStr = "Select top 1 Ac_name,Ac_id," + fld.Trim() +
                                 " from ac_bal where ac_id = " +
                                 Convert.ToInt32(acdetRow["ac_id"]);

                        DataTable tmpTblvw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);
                        if (tmpTblvw.Rows.Count > 0)
                        {
                            tmpTblvw.Rows[0][fld] = DBNull.Value.Equals(tmpTblvw.Rows[0][fld]) ?
                                0 : numFunction.toDecimal(tmpTblvw.Rows[0][fld]);
                            tmpTblvw.Rows[0][fld] = numFunction.toDecimal(tmpTblvw.Rows[0][fld]) +
                                                    numFunction.toDecimal(acdetRow["amount"]);
                            tmpTblvw.AcceptChanges(); 
                            string mcond = "ac_id = " + Convert.ToInt32(acdetRow["ac_id"]);
                            SqlStr = DataAcess.GenUpdateString(tmpTblvw,
                                                    "ac_bal",
                                                    null,
                                                    new string[] { fld },
                                                    mcond,
                                                    null);
                        }
                        else
                        {
                            DataRow tmpTblvwRow = tmpTblvw.NewRow();
                            tmpTblvwRow["ac_name"] = Convert.ToString(acdetRow["ac_name"]);
                            tmpTblvwRow["ac_id"] = Convert.ToInt32(acdetRow["ac_id"]);
                            tmpTblvwRow[fld] = numFunction.toDecimal(acdetRow["amount"]);
                            tmpTblvw.Rows.Add(tmpTblvwRow);
                            tmpTblvwRow.AcceptChanges();
  
                            SqlStr = DataAcess.GenInsertString(tmpTblvw, "ac_bal", null, null);  
                        }

                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true, ref connTran);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            throw ex;
                        }

                        MainDataSet.Tables["acdet_vw"].AcceptChanges();
                        SqlStr = DataAcess.GenInsertString(acdetRow,
                                                           DBPropsSession.Entry_Tbl + "acdet",
                                                           null, null);
                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            throw ex;
                        }


                    }
                }

            }
        }
        # endregion

        # region This method for Update
        public void EditUpdate(DataSet MainDataSet,
                            SqlCommand cmd, ref SqlConnection connTran)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            vuAllocation checkTable = new vuAllocation();

            if (DBPropsSession.ItemPage == true)
            {
                foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                {
                    itemRow["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                    itemRow.AcceptChanges();
                }

                if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                    ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                      strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true)))
                {
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS" }) == true) ||
                        ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                      bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true) &&
                      strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim(), new string[] { "EXCISE", "NON-EXCISE" }) == true)
                    {
                        foreach (DataRow litemallRow in MainDataSet.Tables["litemall_vw"].Rows)
                        {
                            litemallRow["tran_cd"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                            litemallRow.AcceptChanges();
                        }
                        MainDataSet.Tables["litemall_vw"].AcceptChanges();

                        SqlStr = DataAcess.GenDeleteString("litemall", "tran_cd = " + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]));
                        if (SqlStr != "")
                        {
                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                throw ex;
                            }
                        }

                        if (!(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().ToUpper().IndexOf("CANCELLED") >= 0))
                        {
                            SqlStr = DataAcess.GenInsertString(MainDataSet.Tables["litemall_vw"], "litemall", null, null);

                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                throw ex;
                            }

                        }
                    } // end DC 

                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR", "GT" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR", "GT" }) == true) &&
                        strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]), new string[] { "EXCISE", "NON-EXCISE" }) == true)
                    {
                        foreach (DataRow manuDetRow in MainDataSet.Tables["manu_det_vw"].Rows)
                        {
                            manuDetRow["tran_cd"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                            manuDetRow.AcceptChanges();
                        }
                        MainDataSet.Tables["manu_det_vw"].AcceptChanges();

                        SqlStr = DataAcess.GenDeleteString("manu_det", "tran_cd =" + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]));

                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            throw ex;
                        }

                        if (!(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().ToUpper().IndexOf("CANCELLED") >= 0))
                        {
                            SqlStr = DataAcess.GenInsertString(MainDataSet.Tables["manu_det_vw"], "manu_det", null, null);

                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                throw ex;
                            }

                        }

                        SqlStr = DataAcess.GenDeleteString("gen_srno", "tran_cd = " + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                                                      " and ctype ='RGPAGE' and entry_ty='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'");
                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            throw ex;
                        }


                        foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                        {
                            try
                            {
                                GenerateRGPage RgPage = new GenerateRGPage();
                                RgPage.RgPageValidation("INSERT",
                                                            itemRow,
                                                            MainDataSet.Tables["main_vw"].Rows[0],
                                                            MainDataSet.Tables["manu_det_vw"].Rows[0],
                                                            MainDataSet.Tables["Company"].Rows[0],
                                                            DBPropsSession.AddMode,
                                                            DBPropsSession.EditMode,
                                                            cmd,ref connTran);
                            }
                            catch (Exception Ex)
                            {
                                throw Ex;
                            }
                        }

                        // Pending excise trading ii entry
                    }
                } // End Vutex

                SqlStr = "select entry_ty,date,doc_no,itserial from item where 1=0";
                DataTable updVw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connTran);

                DataView updDataview = updVw.DefaultView;
                updDataview.Sort = "entry_ty ASC,Date ASC,doc_no ASC,itserial ASC";

                SqlStr = "select * from " + DBPropsSession.Entry_Tbl + "item" +
                         " where tran_cd = " +
                         Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);

                DataTable tmpTblVw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connTran);

                foreach (DataRow tmpTblRow in tmpTblVw.Rows)
                {
                    filterExp = "entry_ty ='" + Convert.ToString(tmpTblRow["entry_ty"]).Trim() + "'" +
                                " and date ='" + DateFormat.TodateTime(tmpTblRow["date"]) + "'" +
                                " and doc_no ='" + Convert.ToString(tmpTblRow["doc_no"]) + "'" +
                                " and itserial ='" + Convert.ToString(tmpTblRow["itserial"]) + "'" +
                                " and it_code =" + Convert.ToInt32(tmpTblRow["it_code"]);

                    bool rowFound = false;
                    DataRow itemRow = null;
                    try  // search Row
                    {
                        itemRow = MainDataSet.Tables["item_vw"].Select(filterExp)[0];
                        if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().IndexOf("CANCELLED") < 0)
                        {
                            rowFound = true;
                        }
                        else
                        {
                            rowFound = false;
                        }

                    }
                    catch
                    {
                        rowFound = false;
                    }

                    if (rowFound == true)
                    {
                        DataRowView updvwViewRow = updDataview.AddNew();
                        updvwViewRow["entry_ty"] = Convert.ToString(tmpTblRow["entry_ty"]).Trim();
                        updvwViewRow["date"] = DateFormat.TodateTime(tmpTblRow["date"]);
                        updvwViewRow["doc_no"] = Convert.ToString(tmpTblRow["doc_no"]).Trim();
                        updvwViewRow["itserial"] = Convert.ToString(tmpTblRow["itserial"]).Trim();
                        updvwViewRow.EndEdit();

                        decimal iqty = (Convert.ToString(tmpTblRow["dc_no"]).Trim() == "" ?
                            numFunction.toDecimal(tmpTblRow["qty"]) : 0) -
                            (Convert.ToString(itemRow["dc_no"]).Trim() == "" ?
                            numFunction.toDecimal(itemRow["qty"]) : 0);

                        if (iqty < 0)
                        {
                            string fld = DBPropsSession.Entry_Tbl + "qty";
                            SqlStr = "update it_bal set " + fld.Trim() + "=" + fld.Trim() + "-" + iqty +
                                     " where it_code = " + Convert.ToInt32(itemRow["it_code"]);

                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                                
                                SqlStr = "update it_balw set qty = isnull(qty,0) -" + iqty +
                                         " where it_code =" + Convert.ToInt32(itemRow["it_code"]) +
                                         " and ware_nm ='" + Convert.ToString(itemRow["ware_nm"]).Trim() + "'" +
                                         " and entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                         " and date ='" + DateFormat.dateformat(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"])) + "'";

                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                                isSuccess = true;
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                isSuccess = false;
                                throw ex;
                            }
                        }

                        if (isSuccess == true)
                        {
                            //SqlStr = DataAcess.GenUpdateString(tmpTblVw,
                            //                    MainDataSet.Tables["item_vw"],
                            //                    DBPropsSession.Entry_Tbl+"item",
                            //                    " tran_cd = " +
                            //                    Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                            //                    " and itserial = '" + Convert.ToString(itemRow["itserial"]).Trim() + "'");

                            DataRow UpItemRow = MainDataSet.Tables["item_vw"].Select("itserial ='" + Convert.ToString(tmpTblRow["itserial"]) + "'")[0];  
                            SqlStr = DataAcess.GenUpdateString(UpItemRow,
                                               tmpTblRow,
                                               DBPropsSession.Entry_Tbl + "item",
                                               " tran_cd = " +
                                               Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                               " and itserial = '" + Convert.ToString(itemRow["itserial"]).Trim() + "'");

                            if (SqlStr.Trim() != "")
                            {
                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                    isSuccess = true;
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    isSuccess = false;
                                    throw ex;

                                }
                            }
                        }

                    } // End (rowFound == true)
                    else
                    {
                        decimal iQty = Convert.ToString(tmpTblRow["dc_no"]).Trim() == "" ?
                            numFunction.toDecimal(tmpTblRow["qty"]) : 0;
                        string fld = DBPropsSession.Entry_Tbl + "qty";
                        
                        SqlStr = "update it_bal set " + fld.Trim() + "=" + fld.Trim() +
                                 " - " + iQty + " where it_code = " +
                                 Convert.ToInt32(tmpTblRow["it_code"]);

                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();

                            SqlStr = "update it_balw set qty = isnull(qty,0) - " + iQty +
                                     " where it_code = " + Convert.ToInt32(tmpTblRow["it_code"]) +
                                     " and ware_nm = '" + Convert.ToString(tmpTblRow["ware_nm"]).Trim() + "'" +
                                     " and entry_ty ='" + Convert.ToString(tmpTblRow["entry_ty"]).Trim() + "'" +
                                     " and date='" + DateFormat.dateformat(Convert.ToDateTime(tmpTblRow["date"])) + "'";

                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            isSuccess = false;
                            throw ex;
                        }

                        if (isSuccess == true)
                        {
                            SqlStr = DataAcess.GenDeleteString(DBPropsSession.Entry_Tbl + "item",
                                                "tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                                " and itserial ='" + Convert.ToString(tmpTblRow["itserial"]).Trim() + "'");

                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                                isSuccess = true;
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                isSuccess = false;
                                throw ex;
                            }
                        }
                    }
                } // for each loop 
                
                if (isSuccess == true)
                {
                    foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                    {
                        bool rowFound = false;
                        try
                        {
                            filterExp = "entry_ty ='" + Convert.ToString(itemRow["entry_ty"]).Trim() + "'" +
                                " and date ='" + DateFormat.TodateTime(itemRow["date"]) + "'" +
                                " and doc_no ='" + Convert.ToString(itemRow["doc_no"]).Trim() + "'" +
                                " and itserial ='" + Convert.ToString(itemRow["itserial"]).Trim() + "'";

                            DataRow updvwRow = updVw.Select(filterExp)[0];
                            if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().ToUpper().IndexOf("CANCELLED") < 0)
                            {
                                rowFound = true;
                            }
                            else
                            {
                                rowFound = false;
                            }
                        }
                        catch
                        {
                            rowFound = false;
                        }

                        if (rowFound == false)
                        {
                            string fld = DBPropsSession.Entry_Tbl + "qty";
                            SqlStr = "Select top 1 It_name,It_code," + fld.Trim() +
                                     " from it_bal where it_code = " +
                                     Convert.ToInt32(itemRow["it_code"]);
                            
                            tmpTblVw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connTran);

                            if (tmpTblVw.Rows.Count > 0)
                            {
                                tmpTblVw.Rows[0][fld] = numFunction.toDecimal(tmpTblVw.Rows[0][fld]) +
                                            Convert.ToString(itemRow["dc_no"]).Trim() == "" ?
                                            numFunction.toDecimal(itemRow["qty"]) : 0;

                                tmpTblVw.AcceptChanges();

                                SqlStr = DataAcess.GenUpdateString(tmpTblVw,
                                                        "it_bal",
                                                        null,
                                                        null,
                                                        "it_code = " + Convert.ToInt32(itemRow["it_code"]),
                                                        null);
                            }
                            else
                            {
                                DataRow tmpTblRow = tmpTblVw.NewRow();
                                tmpTblRow["it_name"] = Convert.ToString(itemRow["it_name"]).Trim();
                                tmpTblRow["it_code"] = Convert.ToInt32(itemRow["it_code"]);
                                tmpTblRow[fld] = Convert.ToString(itemRow["dc_no"]).Trim() == "" ?
                                                numFunction.toDecimal(itemRow["qty"]) : 0;
                                tmpTblVw.Rows.Add(tmpTblRow);
                                tmpTblVw.AcceptChanges();
   
                                SqlStr = DataAcess.GenInsertString(tmpTblVw,
                                                                   "it_bal",
                                                                   null, null);
                            }

                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery(); 
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                isSuccess = false;
                                throw ex; 
                            }

                            SqlStr = "Select top 1 It_code,Ware_nm,Entry_ty,Date " +
                                     " From It_balw where It_code = " + Convert.ToInt32(itemRow["it_code"]) +
                                     " and ware_nm ='" + Convert.ToString(itemRow["ware_nm"]).Trim() + "'" +
                                     " and entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                     " and date ='" + DateFormat.dateformat(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"])) + "'";

                            tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);

                            if (tmpTblVw.Rows.Count <= 0)
                            {
                                DataRow tmpTblRow = tmpTblVw.NewRow();
                                tmpTblRow["it_code"] = Convert.ToInt32(itemRow["it_code"]);
                                tmpTblRow["ware_nm"] = Convert.ToString(itemRow["ware_nm"]).Trim();
                                tmpTblRow["entry_ty"] = Convert.ToString(itemRow["entry_ty"]).Trim();
                                tmpTblRow["date"] = DateFormat.TodateTime(itemRow["date"]);
                                tmpTblVw.Rows.Add(tmpTblRow);
                                tmpTblVw.AcceptChanges();

                                SqlStr = DataAcess.GenInsertString(tmpTblVw, "it_balw", null, null);

                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    isSuccess = false;
                                    throw ex;
                                }
                            }

                            decimal iQty = Convert.ToString(itemRow["dc_no"]).Trim() == "" ?
                            numFunction.toDecimal(itemRow["qty"]) : 0;

                            SqlStr = "update it_balw set qty = isnull(0,qty) + " + iQty +
                                     " where it_code = " + Convert.ToInt32(itemRow["it_code"]) +
                                     " and ware_nm ='" + Convert.ToString(itemRow["ware_nm"]).Trim() + "'" +
                                     " and entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                     " and date ='" + DateFormat.dateformat(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"])) + "'";
                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                isSuccess = false;
                                return;
                            }

                            if (isSuccess == true)
                            {
                                SqlStr = DataAcess.GenInsertString(itemRow,
                                                                DBPropsSession.Entry_Tbl + "item",
                                                                null, null);

                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    isSuccess = false;
                                    throw ex;
                                }
                            }
                        }  // End (rowFound == false)
                    } // End foreach Loop Item_vw
                }
            }  // end ItemPage

            // Account Page
            string meref_no = "";  // consider this variable for Account Page & Mall_Vw
            if (DBPropsSession.AccountPage == true)
            {
                foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                {
                    acdetRow["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                    acdetRow.AcceptChanges();
                }

                SqlStr = "select * from " + DBPropsSession.Entry_Tbl + "acdet" +
                         " where tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                         " order by acserial ";

                DataTable tmpTblVw1 = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);
               
                foreach (DataRow tmpTblRow1 in tmpTblVw1.Rows)
                {
                    if (numFunction.toDecimal(tmpTblRow1["re_all"]) > 0)
                    {
                        string mref_no = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() +
                                         "/" + (DBNull.Value.Equals(tmpTblRow1["ref_no"]) ?
                                         "" : Convert.ToString(tmpTblRow1["ref_no"]).Trim());

                        while (mref_no.Trim() != "")
                        {
                            string entryTy = strFunction.Left(mref_no, 2);
                            mref_no = mref_no.Trim().Substring(3);

                            if (meref_no.Trim().IndexOf(entryTy) < 0)
                            {
                                meref_no = meref_no + entryTy + "/";
                            }

                            if (mref_no.Trim() != "")
                            {
                                break;
                            }
                        }
                    }
                }  // End foreach loop for tmpTblVw

                // Update Mall_vw
                if (MainDataSet.Tables.Contains("mall_vw") == true)
                {
                    SqlStr = "select * from " + DBPropsSession.Entry_Tbl + "mall" +
                             " where 1=0";

                    DataTable tmpMall_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);

                    //update tran_cd of mall_vw
                    foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Select("tran_cd=0"))
                    {
                        mallRow["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                        mallRow.AcceptChanges();
                    }

                    //update main_tran of mall_vw
                    foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Select("tran_cd=0"))
                    {
                        mallRow["main_tran"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                        mallRow.AcceptChanges();
                    }

                    SqlStr = "select entry_ty,tran_cd,entry_all,main_tran,party_nm from mall where 1=0";
                    
                    DataTable updVw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);

                    DataView updDataview = new DataView();
                    updDataview = updVw.DefaultView;
                    updDataview.Sort = "entry_ty ASC,tran_cd ASC,entry_all ASC,main_tran ASC,Party_nm ASC";

                    string tmpTbl = "";
                    string chkTbl = "";
                    string chkEntry = "#";
                    string sqlCond = "";
                    string sqlMall = "";
                    string sqlAcdet = "";
                    string sqlStrs = "";
                    string entryTy = "";
                    string entryAll = "";

                    while (meref_no.Trim() != "")
                    {
                        entryTy = strFunction.Left(meref_no, 2);
                        meref_no = meref_no.Trim().Substring(3);
                        sqlCond = "";
                        sqlMall = "";
                        sqlAcdet = "";
                        sqlStrs = "";

                        if (entryTy.Trim() == Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]))
                        {
                            sqlMall = DBPropsSession.Entry_Tbl+"mall";
                            sqlCond = " entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]) + "'" +
                                      " and tran_cd =" + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_Cd"]);
                        }
                        else
                        {
                            chkTbl = entryTy.Trim() != chkEntry.Trim() ?
                                checkTable.chkTable(entryTy.Trim(),cmd,ref connTran) :
                                chkTbl;
                            sqlMall = chkTbl+"mall";  
                            chkEntry = entryTy.Trim();
                            sqlCond = " entry_all = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]) + "'" +
                                      " and main_tran =" + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_Cd"]);
                        }

                        SqlStr = "Select * from " + sqlMall.Trim() + " where " + sqlCond.Trim();
                        DataTable tmpTblVw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connTran);
                        bool isRowfound = false;
                        foreach(DataRow tmpVwRow in tmpTblVw.Rows)
                        {
                            DataRow mallRow = null;
                            try
                            {
                                filterExp = " entry_ty= '" + Convert.ToString(tmpVwRow["entry_ty"]).Trim() + "'" +
                                            " and tran_cd = " + Convert.ToInt32(tmpVwRow["tran_cd"]) +
                                            " and entry_all = " + Convert.ToString(tmpVwRow["entry_all"]).Trim() + "'" +
                                            " and main_tran = " + Convert.ToInt32(tmpVwRow["main_tran"]) +
                                            " and party_nm ='" + Convert.ToString(tmpVwRow["party_nm"]).Trim() + "'";

                                mallRow = MainDataSet.Tables["mall_vw"].Select(filterExp)[0];
                                if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().ToUpper().IndexOf("CANCELLED") <0
                                    && numFunction.toDecimal(mallRow) > 0)
                                    isRowfound = true;
                                else
                                    isRowfound = false;
                            }
                            catch (Exception EX)
                            {
                                isRowfound = false;
                            }

                            decimal mamt = 0;
                            decimal mamtt = 0;
                            decimal mamtd = 0;

                            if (isRowfound == true)
                            {
                                DataRowView updDataViewRow = updDataview.AddNew();
                                updDataViewRow["entry_ty"] = Convert.ToString(tmpVwRow["entry_ty"]);
                                updDataViewRow["tran_cd"] = Convert.ToInt32(tmpVwRow["tran_cd"]);
                                updDataViewRow["entry_all"] = Convert.ToString(tmpVwRow["entry_all"]);
                                updDataViewRow["main_tran"] = Convert.ToString(tmpVwRow["main_tran"]);
                                updDataViewRow["party_nm"] = Convert.ToString(tmpVwRow["party_nm"]);
                                updDataViewRow.EndEdit();

                                mamt = numFunction.toDecimal(tmpVwRow["new_all"]) - numFunction.toDecimal(mallRow["new_all"]);
                                mamtt = numFunction.toDecimal(tmpVwRow["tds"]) - numFunction.toDecimal(mallRow["tds"]);
                                mamtd = numFunction.toDecimal(tmpVwRow["disc"]) - numFunction.toDecimal(mallRow["disc"]);

                                if (Convert.ToString(tmpVwRow["entry_ty"]).Trim() ==
                                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() &&
                                    Convert.ToInt32(tmpVwRow["tran_cd"]) ==
                                    Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]))
                                {
                                    chkTbl = Convert.ToString(tmpVwRow["entry_all"]).Trim() != chkEntry.Trim() ?
                                             checkTable.chkTable(Convert.ToString(tmpVwRow["entry_all"]).Trim(),cmd,ref connTran) :
                                             chkTbl;

                                    tmpTbl = DBPropsSession.Entry_Tbl.Trim();
                                    chkEntry = Convert.ToString(tmpVwRow["entry_all"]).Trim();
                                    sqlAcdet = chkTbl.Trim() + "acdet";
                                    sqlCond = " entry_ty ='" + Convert.ToString(tmpVwRow["entry_all"]).Trim() + "'" +
                                              " and tran_cd =" + Convert.ToInt32(tmpVwRow["main_tran"]) +
                                              " and ac_id =" + Convert.ToInt32(tmpVwRow["ac_id"]);
                                    sqlStrs = " re_all = re_all - (" + mamt + mamtt + mamtd + ")";
                                }
                                else
                                {
                                    chkTbl = Convert.ToString(tmpVwRow["entry_ty"]).Trim() != chkEntry.Trim() ?
                                             checkTable.chkTable(Convert.ToString(tmpVwRow["entry_ty"]).Trim(),cmd,ref connTran) :
                                             chkTbl;
                                    tmpTbl = chkTbl.Trim();
                                    chkEntry = Convert.ToString(tmpVwRow["entry_ty"]).Trim();
                                    sqlAcdet = chkTbl.Trim() + "acdet";
                                    sqlCond = " entry_ty ='" + Convert.ToString(tmpVwRow["entry_ty"]).Trim() + "'" +
                                              " and tran_cd =" + Convert.ToInt32(tmpVwRow["tran_cd"]) +
                                              " and ac_id =" + Convert.ToInt32(tmpVwRow["ac_id"]);
                                    sqlStrs = " re_all = re_all - (" + mamt + mamtt + mamtd + ")," +
                                              " tds - " + mamtt + ",disc = disc - " + mamtd;
                                }

                                if (mamt != 0 || mamtt != 0 || mamtd != 0)
                                {
                                    SqlStr = " update " + sqlAcdet.Trim() + " set " +
                                             sqlStrs.Trim() + " where " + sqlCond.Trim();
                                    try
                                    {
                                        cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                        cmd.ExecuteNonQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        DataAcess.RollBackTransaction(cmd.Transaction);
                                        DataAcess.Connclose(connTran);
                                        isSuccess = false;
                                        throw ex;
                                    }
                                }

                                if (isSuccess == true)
                                {
                                    SqlStr = DataAcess.GenUpdateString(MainDataSet.Tables["mall_vw"],
                                                    tmpTblVw,
                                                    tmpTbl.Trim() + "mall",
                                                    (" entry_ty ='" + Convert.ToString(mallRow["entry_ty"]).Trim() + "'" +
                                                    " and tran_cd = " + Convert.ToInt32(mallRow["tran_cd"]) +
                                                    " and entry_all ='" + Convert.ToString(mallRow["entry_all"]).Trim() + "'" +
                                                    " and main_tran =" + Convert.ToInt32(mallRow["main_tran"]) +
                                                    " and ac_id = " + Convert.ToInt32(mallRow["ac_id"])));

                                    if (SqlStr.Trim() != "")
                                    {
                                        try
                                        {
                                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                            cmd.ExecuteNonQuery();
                                        }
                                        catch (Exception ex)
                                        {
                                            DataAcess.RollBackTransaction(cmd.Transaction);
                                            DataAcess.Connclose(connTran);
                                            isSuccess = false;
                                            throw ex;
                                        }
                                    }

                                } // End (isSuccess == true)

                            } // End (isRowfound == true)
                            else
                            {
                                mamt = numFunction.toDecimal(tmpVwRow["new_all"]);
                                mamtt = numFunction.toDecimal(tmpVwRow["tds"]);
                                mamtd = numFunction.toDecimal(tmpVwRow["disc"]);

                                if (Convert.ToString(tmpVwRow["entry_ty"]).Trim() ==
                                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() &&
                                    Convert.ToInt32(tmpVwRow["tran_cd"]) ==
                                    Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]))
                                {

                                    chkTbl = Convert.ToString(tmpVwRow["entry_all"]).Trim() != chkEntry.Trim() ?
                                             checkTable.chkTable(Convert.ToString(tmpVwRow["entry_all"]).Trim(),cmd,ref connTran) :
                                             chkTbl;

                                    tmpTbl = DBPropsSession.Entry_Tbl.Trim();
                                    chkEntry = Convert.ToString(tmpVwRow["entry_all"]).Trim();
                                    sqlAcdet = chkTbl.Trim() + "acdet";
                                    sqlCond = " entry_ty ='" + Convert.ToString(tmpVwRow["entry_all"]).Trim() + "'" +
                                              " and tran_cd =" + Convert.ToInt32(tmpVwRow["main_tran"]) +
                                              " and ac_id =" + Convert.ToInt32(tmpVwRow["ac_id"]);
                                    sqlStrs = " re_all = re_all - (" + mamt + mamtt + mamtd + ")";
                                }
                                else
                                {
                                    chkTbl = Convert.ToString(tmpVwRow["entry_ty"]).Trim() != chkEntry.Trim() ?
                                            checkTable.chkTable(Convert.ToString(tmpVwRow["entry_ty"]).Trim(),cmd,ref connTran) :
                                            chkTbl;
                                    tmpTbl = chkTbl.Trim();
                                    chkEntry = Convert.ToString(tmpVwRow["entry_ty"]).Trim();
                                    sqlAcdet = chkTbl.Trim() + "acdet";
                                    sqlCond = " entry_ty ='" + Convert.ToString(tmpVwRow["entry_ty"]).Trim() + "'" +
                                              " and tran_cd =" + Convert.ToInt32(tmpVwRow["tran_cd"]) +
                                              " and ac_id =" + Convert.ToInt32(tmpVwRow["ac_id"]);
                                    sqlStrs = " re_all = re_all - (" + mamt + mamtt + mamtd + ")," +
                                              " tds - " + mamtt + ",disc = disc - " + mamtd;
                                }

                                SqlStr = " update " + sqlAcdet.Trim() + " set " +
                                          sqlStrs.Trim() + " where " + sqlCond.Trim();
                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    isSuccess = false;
                                    throw ex;
                                }


                                if (isSuccess == true)
                                {
                                    SqlStr = DataAcess.GenDeleteString(tmpTbl.Trim() + "mall",
                                                   (" entry_ty ='" + Convert.ToString(tmpVwRow["entry_ty"]).Trim() + "'" +
                                                    " and tran_cd = " + Convert.ToInt32(tmpVwRow["tran_cd"]) +
                                                    " and entry_all ='" + Convert.ToString(tmpVwRow["entry_all"]).Trim() + "'" +
                                                    " and main_tran =" + Convert.ToInt32(tmpVwRow["main_tran"]) +
                                                    " and ac_id = " + Convert.ToInt32(tmpVwRow["ac_id"])));

                                    try
                                    {
                                        cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                        cmd.ExecuteNonQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        DataAcess.RollBackTransaction(cmd.Transaction);
                                        DataAcess.Connclose(connTran);
                                        isSuccess = false;
                                        throw ex;
                                    }

                                } // End (isSuccess == true)

                            }  // End (isRowfound == true) else Part
                        } // End foreach loop tmpTblVw

                        if (meref_no.Trim() == "")
                        {
                            break;
                        }

                    }  // End while

                    // Adding new records in Mall View

                    if (isSuccess == true)
                    {
                        foreach (DataRow mallRow in MainDataSet.Tables["mall_vw"].Rows)
                        {
                            // Index On entry_ty+str(tran_cd)+Entry_all+str(Main_tran)+party_nm Tag Eddp_all		&&atlas_remove
                            bool isRowFound = false;
                            if ((updDataview.Find(new object[]{Convert.ToString(mallRow["entry_ty"]),
                                                    Convert.ToInt32(mallRow["tran_cd"]),
                                                    Convert.ToString(mallRow["entry_all"]),
                                                    Convert.ToInt32(mallRow["main_tran"]),
                                                    Convert.ToString(mallRow["party_nm"])}) <= 0) &&
                                                    numFunction.toDecimal(mallRow["new_all"]) > 0 &&
                                                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().ToUpper().IndexOf("CANCELLED") <0)
                            {
                                if (Convert.ToString(mallRow["entry_ty"]).Trim() ==
                                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() &&
                                    Convert.ToInt32(mallRow["tran_cd"]) ==
                                    Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]))
                                {

                                    chkTbl = Convert.ToString(mallRow["entry_all"]).Trim() != chkEntry.Trim() ?
                                             checkTable.chkTable(Convert.ToString(mallRow["entry_all"]).Trim(),cmd,ref connTran) :
                                             chkTbl;

                                    tmpTbl = DBPropsSession.Entry_Tbl.Trim();
                                    chkEntry = Convert.ToString(mallRow["entry_all"]).Trim();
                                    sqlAcdet = chkTbl.Trim() + "acdet";
                                    entryAll = Convert.ToString(mallRow["entry_ty"]).Trim();    
                                    sqlCond = " entry_ty ='" + Convert.ToString(mallRow["entry_all"]).Trim() + "'" +
                                              " and tran_cd =" + Convert.ToInt32(mallRow["main_tran"]) +
                                              " and ac_id =" + Convert.ToInt32(mallRow["ac_id"]);
                                }
                                else
                                {
                                    chkTbl = Convert.ToString(mallRow["entry_ty"]).Trim() != chkEntry.Trim() ?
                                            checkTable.chkTable(Convert.ToString(mallRow["entry_ty"]).Trim(),cmd,ref connTran) :
                                            chkTbl;
                                    tmpTbl = chkTbl.Trim();
                                    chkEntry = Convert.ToString(mallRow["entry_ty"]).Trim();
                                    sqlAcdet = chkTbl.Trim() + "acdet";
                                    entryAll = Convert.ToString(mallRow["entry_all"]).Trim();    
                                    sqlCond = " entry_ty ='" + Convert.ToString(mallRow["entry_ty"]).Trim() + "'" +
                                              " and tran_cd =" + Convert.ToInt32(mallRow["tran_cd"]) +
                                              " and ac_id =" + Convert.ToInt32(mallRow["ac_id"]);
                                }

                                SqlStr = "select top 1 ref_no,re_all from " + sqlAcdet.Trim() +
                                         " where " + sqlCond.Trim();

                                DataTable tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);

                                if (tmpTblVw.Rows.Count > 0)
                                {
                                    tmpTblVw.Rows[0]["ref_no"] = DBNull.Value.Equals(tmpTblVw.Rows[0]["ref_no"]) ?
                                        "" : Convert.ToString(tmpTblVw.Rows[0]["ref_no"]).Trim();
                                    tmpTblVw.Rows[0]["re_all"] = numFunction.toDecimal(tmpTblVw.Rows[0]["re_all"]) +
                                        numFunction.toDecimal(mallRow["new_all"]) +
                                        numFunction.toDecimal(mallRow["tds"]) +
                                        numFunction.toDecimal(mallRow["disc"]);
                                    tmpTblVw.Rows[0]["ref_no"] = Convert.ToString(tmpTblVw.Rows[0]["ref_no"]).Trim().IndexOf(entryAll) >= 0 ?
                                                                 Convert.ToString(tmpTblVw.Rows[0]["ref_no"]).Trim() :
                                                                 Convert.ToString(tmpTblVw.Rows[0]["ref_no"]).Trim() + entryAll + "/";
                                    tmpTblVw.AcceptChanges();

                                    SqlStr = DataAcess.GenUpdateString(tmpTblVw, sqlAcdet, null,
                                                                       new string[] { "ref_no", "re_all" },
                                                                       sqlCond.Trim(),
                                                                       null);
                                    if (SqlStr.Trim() != "")
                                    {
                                        try
                                        {
                                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                            cmd.ExecuteNonQuery();
                                        }
                                        catch (Exception ex)
                                        {
                                            DataAcess.RollBackTransaction(cmd.Transaction);
                                            DataAcess.Connclose(connTran);
                                            isSuccess = false;
                                            throw ex;
                                        }
                                    }
                                }
                                else
                                {
                                    isSuccess = false;
                                }
                                
     
                            }  // end find
                        }
                    }
                }
                
                SqlStr = "select entry_ty,date,doc_no,ac_name,acserial from acdet where 1=0";
                
                DataView updDataView = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran).DefaultView;
                updDataView.Sort = "ac_name ASC,acserial ASC,entry_ty ASC,date ASC,doc_no ASC";  

                if (tmpTblVw1 != null)
                {
                    decimal mamt = 0;
                    foreach (DataRow tmpVwRow1 in tmpTblVw1.Rows)
                    {
                        bool isRowFound = false;
                        DataRow acDetRow = null;
                        try
                        {
                            //		Index On ac_name+amt_ty+entry_ty+DToS(date)+doc_no Tag aaedd		&&03/01/2008		
                            filterExp = "ac_name ='" + Convert.ToString(tmpVwRow1["ac_name"]).Trim() + "'" +
                                        " and amt_ty='" + Convert.ToString(tmpVwRow1["amt_ty"]).Trim() + "'" +
                                        " and entry_ty ='" + Convert.ToString(tmpVwRow1["entry_ty"]).Trim() + "'" +
                                        " and date ='" + DateFormat.TodateTime(tmpVwRow1["date"]) + "'" +
                                        " and doc_no='" + Convert.ToString(tmpVwRow1["doc_no"]).Trim() + "'";

                            acDetRow = MainDataSet.Tables["acdet_vw"].Select(filterExp)[0];
                            if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().ToUpper().IndexOf("CANCELLED") < 0)
                            {
                                isRowFound = true;
                            }
                            else
                            {
                                isRowFound = false;
                            }
                        }
                        catch
                        {
                            isRowFound = false;
                        }

                        if (isRowFound == true)
                        {
                            DataRowView updDataViewRow = updDataView.AddNew();

                            updDataViewRow["entry_ty"] = Convert.ToString(tmpVwRow1["entry_ty"]);
                            updDataViewRow["date"] = DateFormat.TodateTime(tmpVwRow1["date"]);
                            updDataViewRow["doc_no"] = Convert.ToString(tmpVwRow1["doc_no"]);
                            updDataViewRow["ac_name"] = Convert.ToString(tmpVwRow1["ac_name"]);
                            updDataViewRow["acserial"] = Convert.ToString(tmpVwRow1["acserial"]);
                            updDataViewRow.EndEdit();

                            mamt = numFunction.toDecimal(tmpVwRow1["amount"]) - numFunction.toDecimal(acDetRow["amount"]);

                            // uday
                            if (mamt != 0)
                            {
                                string fld = Convert.ToString(tmpVwRow1["amt_ty"]).Trim();
                                SqlStr = "update ac_bal set " + fld + " = " + fld + " - " + mamt +
                                         " where ac_id = " + Convert.ToInt32(acDetRow["ac_id"]);

                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    isSuccess = false;
                                    throw ex;
                                }
                            }

                            if (isSuccess == true)
                            {
                                DataRow upAcDetRow = MainDataSet.Tables["acdet_vw"].Select("acserial ='" + Convert.ToString(tmpVwRow1["acserial"]).Trim() + "'")[0];
                                SqlStr = DataAcess.GenUpdateString(upAcDetRow, 
                                                    tmpVwRow1,
                                                    DBPropsSession.Entry_Tbl + "acdet",
                                                    (" tran_cd =" + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                                     " and ac_id = " + Convert.ToInt32(acDetRow["ac_id"]) +
                                                     " and amt_ty='" + Convert.ToString(acDetRow["amt_ty"]).Trim() + "'"));
                                if (SqlStr.Trim() != "")
                                {
                                    try
                                    {
                                        cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                        cmd.ExecuteNonQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        DataAcess.RollBackTransaction(cmd.Transaction);
                                        DataAcess.Connclose(connTran);
                                        isSuccess = false;
                                        throw ex;
                                    }
                                }

                            }
                        }   // End isRowFound == true
                        else
                        {
                            mamt = numFunction.toDecimal(tmpVwRow1["amount"]);
                            string fld = Convert.ToString(tmpVwRow1["amt_ty"]).Trim();

                            SqlStr = "update ac_bal set " + fld.Trim() + " = " + fld.Trim() +
                                     " - " + mamt + " where ac_id = " + Convert.ToInt32(tmpVwRow1["ac_id"]);

                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                isSuccess = false;
                                throw ex;
                            }

                            if (isSuccess == true)
                            {
                                SqlStr = DataAcess.GenDeleteString(DBPropsSession.Entry_Tbl + "acdet",
                                                    (" tran_cd =" + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                                     " and ac_id = " + Convert.ToInt32(tmpVwRow1["ac_id"]) +
                                                     " and amt_ty='" + Convert.ToString(tmpVwRow1["amt_ty"]).Trim() + "'"));

                                try
                                {
                                    cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception ex)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connTran);
                                    isSuccess = false;
                                    throw ex;
                                }
                            }


                        } // End isRowFound == false
                    }  // End foreach Loop for tmpTblVw1
                } // End  if (tmpTblVw1 != null)

                foreach (DataRow acdetRow in MainDataSet.Tables["acdet_vw"].Rows)
                {
                    // new changed by uday

                    string filterExp = " ac_name ='" + Convert.ToString(acdetRow["ac_name"]).Trim() + "' and " +
                                       " acserial ='" + Convert.ToString(acdetRow["acserial"]).Trim() + "' and " +
                                       " entry_ty ='" + Convert.ToString(acdetRow["entry_ty"]).Trim() + "' and " +
                                       " date = '" + DateFormat.TodateTime(acdetRow["date"]) + "' and " +
                                       " doc_no ='" + Convert.ToString(acdetRow["doc_no"]).Trim() + "'";
                    DataRow updRow = null;
                    try
                    {
                        updRow = updDataView.ToTable().Select(filterExp)[0];
                    }
                    catch
                    {
                        if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).IndexOf("CANCELLED") >= 0)
                        {
                            continue;
                        }

                        string fld = Convert.ToString(acdetRow["amt_ty"]).Trim();

                        SqlStr = "select top 1 ac_name,ac_id," + fld + " from ac_bal " +
                                 " where ac_id = " + Convert.ToInt32(acdetRow["ac_id"]);

                        DataTable tmpTblvw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);

                        SqlStr = "";
                        if (tmpTblvw.Rows.Count > 0)
                        {
                            tmpTblvw.Rows[0][fld] = DBNull.Value.Equals(tmpTblvw.Rows[0][fld]) ? 0 :
                                                    numFunction.toDecimal(tmpTblvw.Rows[0][fld]);
                            tmpTblvw.Rows[0][fld] = numFunction.toDecimal(tmpTblvw.Rows[0][fld]) +
                                                    numFunction.toDecimal(acdetRow["amount"]);
                            tmpTblvw.AcceptChanges();
                            SqlStr = DataAcess.GenUpdateString(tmpTblvw, "ac_bal", null, new string[] { fld },
                                                               " ac_id = " + Convert.ToInt32(acdetRow["ac_id"]), null);
                        }
                        else
                        {
                            DataRow tmpTblRow = tmpTblvw.NewRow();
                            tmpTblRow["ac_name"] = Convert.ToString(acdetRow["ac_name"]).Trim();
                            tmpTblRow["ac_id"] = Convert.ToInt32(acdetRow["ac_id"]);
                            tmpTblRow[fld] = numFunction.toDecimal(acdetRow["Amount"]);

                            // new changes from uday
                            tmpTblvw.Rows.Add(tmpTblRow);

                            tmpTblvw.AcceptChanges();

                            SqlStr = DataAcess.GenInsertString(tmpTblvw, "ac_bal", null, null);
                        }

                        // new changes from uday
                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connTran);
                            isSuccess = false;
                            throw ex;
                        }

                        SqlStr = string.Empty;
                        SqlStr = DataAcess.GenInsertString(acdetRow, DBPropsSession.Entry_Tbl.Trim() + "acdet", null, null);
                        if (SqlStr != string.Empty)
                        {
                            try
                            {
                                cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connTran);
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connTran);
                                isSuccess = false;
                                throw ex;
                            }
                        }
                    }
                    //if ((updDataView.Find(new object[]{Convert.ToString(acdetRow["ac_name"]),
                    //                        Convert.ToString(acdetRow["acserial"]),
                    //                        Convert.ToString(acdetRow["entry_ty"]),
                    //                        DateFormat.TodateTime(acdetRow["date"]),
                    //                        Convert.ToString(acdetRow["doc_no"])}) <= 0) &&
                    //                        Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim().ToUpper().IndexOf("CANCELLED") <= 0)
                    //{
                    //    string fld = Convert.ToString(acdetRow["amt_ty"]).Trim();

                    //    SqlStr = "select top 1 ac_name,ac_id," + fld + " from ac_bal " +
                    //             " where ac_id = " + Convert.ToInt32(acdetRow["ac_id"]);

                    //    DataTable tmpTblvw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction);

                    //    SqlStr = "";
                    //    if (tmpTblvw.Rows.Count > 0)
                    //    {
                    //        tmpTblvw.Rows[0][fld] = DBNull.Value.Equals(tmpTblvw.Rows[0][fld]) ? 0 :
                    //                                numFunction.toDecimal(tmpTblvw.Rows[0][fld]);
                    //        tmpTblvw.Rows[0][fld] = numFunction.toDecimal(tmpTblvw.Rows[0][fld]) +
                    //                                numFunction.toDecimal(acdetRow["amount"]);
                    //        tmpTblvw.AcceptChanges();
                    //        SqlStr = DataAcess.GenUpdateString(tmpTblvw, "ac_bal", null, new string[] { fld },
                    //                                           " ac_id = " + Convert.ToInt32(acdetRow["ac_id"]), null);
                    //    }
                    //    else
                    //    {

                    //        DataRow tmpTblRow = tmpTblvw.NewRow();
                    //        tmpTblRow["ac_name"] = Convert.ToString(acdetRow["ac_name"]).Trim();
                    //        tmpTblRow["ac_id"] = Convert.ToInt32(acdetRow["ac_id"]);
                    //        tmpTblRow[fld] = numFunction.toDecimal(acdetRow["Amount"]);

                    //        // new changes from uday
                    //        tmpTblvw.Rows.Add(tmpTblRow);

                    //        tmpTblvw.AcceptChanges();

                    //        SqlStr = DataAcess.GenInsertString(tmpTblvw, "ac_bal", null, null);
                    //    }

                    //    // new changes from uday
                    //    try
                    //    {
                    //        cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true);
                    //        cmd.ExecuteNonQuery();
                    //    }
                    //    catch (Exception ex)
                    //    {
                    //        DataAcess.RollBackTransaction();
                    //        DataAcess.Connclose();
                    //        isSuccess = false;
                    //        throw ex;
                    //    }

                    //    SqlStr = string.Empty;
                    //    SqlStr = DataAcess.GenInsertString(acdetRow, DBPropsSession.Entry_Tbl.Trim() + "acdet", null, null);
                    //    if (SqlStr != string.Empty)
                    //    {
                    //        try
                    //        {
                    //            cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true);
                    //            cmd.ExecuteNonQuery();
                    //        }
                    //        catch (Exception ex)
                    //        {
                    //            DataAcess.RollBackTransaction();
                    //            DataAcess.Connclose();
                    //            isSuccess = false;
                    //            throw ex;
                    //        }
                    //    }
                    //} // End Find
                } // End foreach loop for acdet_vw
            } // End (DBPropsSession.AccountPage == true)

        }
        #endregion
        public void EmptyValidation(TextBox txtDate,
            TextBox txtPartyName,
            TextBox txtInvoiceNo,
            TextBox txtAccount,
            DropDownList dropSeries,
            DropDownList dropCategory,
            DropDownList dropDepartment,
            DropDownList dropRule,
            TextBox txtBillNo,
            TextBox txtBillDate,
            TextBox txtChequeNoB,
            TextBox txtNarration,
            TextBox txtNarrationB,
            TextBox txtDrawnOnB, 
            DataTable main_vw)
        {
            if (txtDate.Text == "")
            {
                txtDate.Focus();
                throw new Exception("Date cannot be empty..!!!");
            }

            if (txtPartyName.Text.ToString().Trim() == "")
            {
                txtPartyName.Focus();
                throw new Exception("Party name cannot be empty..!!!");
            }

            if (txtInvoiceNo.Visible == true &&
                txtInvoiceNo.Enabled == true)
            {
                if (txtInvoiceNo.Text == "")
                {
                    txtInvoiceNo.Focus();
                    throw new Exception("Invoice no. cannot be empty..!!!");
                }
            }

            if (Convert.ToString(main_vw.Rows[0]["party_nm"]) != "CANCELLED.")
            {
                if (txtAccount != null)
                {
                    if (txtAccount.Enabled == true &&
                        txtAccount.Visible == true)
                    {
                        if (txtAccount.Text == "")
                        {
                            txtAccount.Focus();
                            throw new Exception("Account cannot be empty..!!!");
                        }
                    }
                }

                if (dropSeries.Enabled == true &&
                    dropSeries.Visible == true)
                {
                    if (dropSeries.SelectedIndex == 0)
                    {
                        dropSeries.Focus();
                        throw new Exception("Series cannot be empty..!!!");
                    }
                    else
                    {
                        main_vw.Rows[0]["inv_sr"] = dropSeries.SelectedItem.ToString().Trim();    
                    }
                }

                if (dropCategory.Enabled == true &&
                    dropCategory.Visible == true)
                {
                    if (dropCategory.SelectedIndex == 0)
                    {
                        dropCategory.Focus();
                        throw new Exception("Category cannot be empty..!!!");
                    }
                    else
                    {
                        main_vw.Rows[0]["cate"] = dropCategory.SelectedItem.ToString().Trim();  
                    }
                }

                if (dropDepartment.Enabled == true &&
                    dropDepartment.Visible == true)
                {
                    if (dropDepartment.SelectedIndex == 0)
                    {
                        dropDepartment.Focus();
                        throw new Exception("Department cannot be empty..!!!");
                    }
                    else
                    {
                        main_vw.Rows[0]["dept"] = dropDepartment.SelectedItem.ToString().Trim();  
                    }
                }

                if (dropRule != null)
                {
                    if (dropRule.Enabled == true &&
                        dropRule.Visible == true)
                    {
                        if (dropRule.SelectedIndex == 0)
                        {
                            dropRule.Focus();
                            throw new Exception("Rule cannot be empty..!!!");
                        }
                        else
                        {
                            main_vw.Rows[0]["rule"] = dropRule.SelectedItem.ToString().Trim();  
                        }
                    }
                }

                if (txtBillNo.Visible == true && txtBillNo.Enabled == true)
                {
                    if (txtBillNo.Text == "")
                    {
                        txtBillNo.Focus();
                        throw new Exception("Bill no. cannot be empty..!!!");
                    }
                    else
                    {
                        main_vw.Rows[0]["u_pinvno"] = txtBillNo.Text.ToString().Trim();
                        if (txtBillDate.Text.Trim() != "" && txtBillDate.Text.Trim() != "__/__/____")
                            main_vw.Rows[0]["u_pinvdt"] = DateFormat.TodateTime(txtBillDate.Text);
                    }
                }

                // Binding Textbox
                if (txtChequeNoB.Visible == true && txtChequeNoB.Enabled == true)
                {
                    if (txtChequeNoB.Text != "")
                        main_vw.Rows[0]["Cheq_No"] = txtChequeNoB.Text.ToString().Trim();  
                }

                if (txtNarration.Visible == true && txtNarration.Enabled == true)
                {
                    if (txtNarration.Text != "")
                        main_vw.Rows[0]["Narr"] = txtNarration.Text.ToString().Trim();  
                }

                if (txtNarrationB.Visible == true && txtNarrationB.Enabled == true)
                {
                    if (txtNarrationB.Text != "")
                        main_vw.Rows[0]["Narr"] = txtNarrationB.Text.ToString().Trim();  
                }

                if (txtDrawnOnB.Visible == true && txtDrawnOnB.Enabled == true)
                {
                    if (txtDrawnOnB.Text != "")
                        main_vw.Rows[0]["Drawn_on"] = txtDrawnOnB.Text.ToString().Trim();  
                }

                main_vw.AcceptChanges();
            }
        }

        public void MadatoryValidation(DataTable main_vw,
                DataTable item_vw,
                DataTable company,
                DataTable acdet_vw,
                TextBox txtPartyName,
                TextBox txtNetAmount)
        {
            if (DBPropsSession.AddMode == true)
            {
                if (DBPropsSession.PBackDate > DateFormat.TodateTime(main_vw.Rows[0]["date"]))
                {
                    throw new Exception("Date cannot be less than last entry date..!!!");
                }
            }

            if (strFunction.InList(DBPropsSession.PcvType, new string[] {"BR", "BP", "CR", "CP" }) == true ||
                strFunction.InList(DBPropsSession.Behave, new string[] {"BR", "BP", "CR", "CP" }) == true)
            {
                if (Convert.ToString(main_vw.Rows[0]["party_nm"]) == Convert.ToString(main_vw.Rows[0]["bank_nm"]))
                {
                    throw new Exception("Party name cannot be same as Bank name..!!!");
                }
            }

            if (Convert.ToString(main_vw.Rows[0]["party_nm"]) == "CANCELLED.")
            {
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "SO", "ST", "DC", "CR", "CP", "BR", "BP", "JV", "DN", "CN", "PC", "SQ", "PI", "PL" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "SO", "ST", "DC", "CR", "CP", "BR", "BP", "JV", "DN", "CN", "PC", "SQ", "PI", "PL" }) == true)
                {
                    txtPartyName.Focus();  
                    throw new Exception("This transaction cannot be Cancelled..");
                }
            }

            if (DBPropsSession.AccountPage == true &&
                numFunction.toDecimal(main_vw.Rows[0]["net_amt"]) <= 0)
            {
                bool mAnsl = true;

                if (Convert.ToString(main_vw.Rows[0]["Party_nm"]) == "CANCELLED.")
                {
                    mAnsl = false;
                }
                else
                {
                    if ((DBPropsSession.PcvType == "ST" &&
                        Convert.ToString(main_vw.Rows[0]["rule"]) == "CAPTIVE USE")
                        ||
                        (DBPropsSession.Behave == "ST" &&
                        Convert.ToString(main_vw.Rows[0]["rule"]) == "CAPTIVE USE"))
                    {
                        if (DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0)
                        {
                            mAnsl = false;
                        }
                    }
                }

                if (mAnsl == true)
                {
                    if (txtNetAmount.Visible == true &&
                        txtNetAmount.Enabled == true)
                    {
                        txtNetAmount.Focus();
                    }

                    
                    switch (DBPropsSession.PcvType)
                    {
                        case "BR":
                        case "CR":
                        case "DN":
                        case "CN":
                            throw new Exception("Amount Received cannot be empty..!!!");
                        case "BP":
                        case "CP":
                        case "PC":
                            throw new Exception("Amount paid cannot be empty..!!!");
                        case "EP":
                            throw new Exception("Net Amount cannot be zero..!!!");
                        default:
                            throw new Exception("Transaction Amount cannot be zero..!!!");
                    }
                }
            }

            // For Item Details

            if (DBPropsSession.ItemPage == true)
            {
                // Delete empty item rows
                foreach (DataRow itemRow in item_vw.Select("item = ''"))
                {
                    itemRow.Delete();  
                }
                item_vw.AcceptChanges();

                string mitname = "";
                int mcnt = 0;
                int mrate = 0;
                int mgross = 0;
                int mit_cnt = 0;

                if (Convert.ToString(main_vw.Rows[0]["party_nm"]) == "CANCELLED.")
                {
                    mit_cnt = 1;
                }

                if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "ST", "SR", "SO", "SQ", "DC" }) == false ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "ST", "SR", "SO", "SQ", "DC" }) == false) &&
                    bitFunction.toBoolean(company.Rows[0]["sgro_op"]) == true)
                {
                    mit_cnt = 1;
                }

                if ((strFunction.InList(DBPropsSession.PcvType, new string[] {"PT", "PR", "PO", "AR"}) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "PT", "PR", "PO", "AR"}) == true) &&
                    bitFunction.toBoolean(company.Rows[0]["pgro_op"]) == true)
                {
                    mit_cnt = 1;
                }

                foreach (DataRow itemRow in item_vw.Rows)
                {
                    mitname = Convert.ToString(itemRow["item"]).Trim(); 

                    if (numFunction.toDecimal(itemRow["Qty"]) == 0)
                    {
                        throw new Exception(Convert.ToString(itemRow["item"]).Trim() + " item qty. cannot be empty..!!!");
                    }
                    else
                    {
                        if (Convert.ToString(itemRow["ware_nm"]) == "" && DBPropsSession.WareCol > 0)
                        {
                            throw new Exception("Warehouse name for " + Convert.ToString(itemRow["item"]).Trim() +
                                            " cannot be empty..!!");
                        }
                        else
                        {
                            if (numFunction.toDecimal(itemRow["rate"]) < 0)
                            {
                                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "ST", "PT", "SR", "PR", "BR", "BP", "CR", "CP", "JV", "DN", "CN", "EP" }) == true ||
                                    strFunction.InList(DBPropsSession.Behave, new string[] { "ST", "PT", "SR", "PR", "BR", "BP", "CR", "CP", "JV", "DN", "CN", "EP" }) == true)
                                {
                                    mrate = mrate + 1;
                                }
                            }
                            else
                            {
                                if (numFunction.toDecimal(itemRow["gro_amt"]) < 0)
                                {
                                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "ST", "PT", "SR", "PR", "BR", "BP", "CR", "CP", "JV", "DN", "CN", "EP" }) == true ||
                                        strFunction.InList(DBPropsSession.Behave, new string[] { "ST", "PT", "SR", "PR", "BR", "BP", "CR", "CP", "JV", "DN", "CN", "EP" }) == true)
                                    {
                                        mgross = mgross + 1;
                                    }
                                }
                            }
                        }
                    }

                } // end for each loop

                if (mit_cnt == 0 && mitname.Trim() == "")
                {
                    throw new Exception("cannot save without item(s)...");
                }

                if (DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0 &&
                    Convert.ToString(main_vw.Rows[0]["rule"]) == "CAPTIVE USE" &&
                    (DBPropsSession.PcvType == "ST" || DBPropsSession.Behave == "ST"))
                {
                }
                else
                {
                    if (mrate != 0)
                    {
                        if (mrate == mcnt)
                        {
                            throw new Exception("Item rate cannot be empty..!!!");
                        }
                    }

                    if (mgross != 0)
                    {
                        if (mgross == mcnt)
                        {
                            throw new Exception("Item Gross Amount cannot be empty..!!!");
                        }
                    }
                }
            } // End Item Page

            // Account Page Details

            if (DBPropsSession.AccountPage == true)
            {
                foreach (DataRow acdetRow in acdet_vw.Select("ac_name = ''"))
                {
                    acdetRow.Delete();  
                }
                acdet_vw.AcceptChanges();

                decimal dbAmt = 0;
                decimal crAmt = 0;
                bool drParty = false;
                bool crParty = false;

                if (Convert.ToString(main_vw.Rows[0]["party_nm"]) == "CANCELLED.")
                {
                    dbAmt = 1;
                    crAmt = 1;
                    drParty = true;
                    crParty = true;
                }

                if (main_vw.Columns.Contains("Bank_nm") == true)
                {
                    if (Convert.ToString(main_vw.Rows[0]["bank_nm"]) == "")
                    {
                        crParty = true;
                    }
                }
                else
                {
                    crParty = true;
                }

                foreach (DataRow acdetRow in acdet_vw.Rows)
                {
                    dbAmt = dbAmt + 
                            ((Convert.ToString(acdetRow["amt_ty"]).Trim().ToUpper() == "DR" && 
                            numFunction.toDecimal(acdetRow["amount"]) > 0 )? 
                            numFunction.toDecimal(acdetRow["amount"]) : 0);

                    crAmt = crAmt + 
                            ((Convert.ToString(acdetRow["amt_ty"]).Trim().ToUpper() == "CR" &&
                             numFunction.toDecimal(acdetRow["amount"]) > 0) ?
                             numFunction.toDecimal(acdetRow["amount"]) : 0);

                    if (Convert.ToString(acdetRow["ac_name"]).Trim() == Convert.ToString(main_vw.Rows[0]["party_nm"]).Trim())
                    {
                        drParty = true; 
                    }

                    if (main_vw.Columns.Contains("Bank_nm") == true)
                    {
                        if (Convert.ToString(acdetRow["ac_name"]).Trim() == Convert.ToString(main_vw.Rows[0]["party_nm"]).Trim())
                        {
                            crParty = true;
                        }
                    }

                }

                if (dbAmt == 0 &&
                    crAmt == 0 &&
                    (DateFormat.TodateTime(main_vw.Rows[0]["date"]) >= DateFormat.TodateTime(company.Rows[0]["sta_dt"]) &&
                     DateFormat.TodateTime(main_vw.Rows[0]["date"]) <= DateFormat.TodateTime(company.Rows[0]["end_dt"])))
                {                   
                    throw new Exception("Cannot save without accounting effects..!!!");
                }

                if (crParty == false)
                {
                    throw new Exception(Convert.ToString(main_vw.Rows[0]["Bank_Nm"]).Trim() +
                                " not found in Accounting Effect..!!!");
                }
                else
                {
                    if (drParty == false)
                    {
                        throw new Exception(Convert.ToString(main_vw.Rows[0]["Party_nm"]).Trim() +
                                " not found in Accounting Effect..!!!");
                    }
                    else
                    {
                        if (dbAmt != crAmt)
                        {
                            throw new Exception("Debit & Credit Amounts are not Balanced..!!!");
                        }
                    }
                }
             }
        }

        protected void OtherColBind(DataTable main_vw)
        {

        }
    }
}
