using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class CL_Gen_Ent_GLview_Grid_Columns
    {
        #region DataTable field Structure
        private string ac_name;
        private string acgroup;
        private bool select;
        private int ac_id;


        public bool Select
        {
            get { return select; }
            set { select = value; }
        }
        public string Ac_name
        {
            get { return ac_name; }
            set { ac_name = value; }
        }
        public int Ac_id
        {
            get { return ac_id; }
            set { ac_id = value; }
        }
        public string Acgroup
        {
            get { return acgroup; }
            set { acgroup = value; }
        }
        #endregion
    }

    public class CL_Gen_Ent_GLview : CL_Gen_Ent_GLview_Grid_Columns 
    {
        private int startIndex;
        private int pageSize;
        private string sortBy;
        private string trantype;
        private string searchtext;
        private int totalRec;
        private int groupId;

        public int GroupId
        {
            get { return groupId; }
            set { groupId = value; }
        }

        public int TotalRec
        {
            get { return totalRec; }
            set { totalRec = value; }
        }

        public int StartIndex
        {
            get { return startIndex; }
            set { startIndex = value; }
        }

        public int PageSize
        {
            get { return pageSize; }
            set { pageSize = value; }
        }

        public string SortBy
        {
            get { return sortBy; }
            set { sortBy = value; }
        }

        public string Trantype
        {
            get { return trantype; }
            set { trantype = value; }
        }

        public string Searchtext
        {
            get { return searchtext; }
            set { searchtext = value; }
        }

    }
}
