using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    class MyDelegate
    {
        public delegate void MyDelegates(Object sendingobj, EventArgs e);
        public void MyFunction(object sendingObj, EventArgs e)
        {
        }

    }
}
