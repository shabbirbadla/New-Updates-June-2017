using System;
using System.Collections.Generic;
using System.Text;
using System.Data; 

namespace Business.Logic.Layer
{
    public class CL_Gen_Ent_ItMast_View
    {
        private int it_Code;
        public int It_Code
        {
            get { return it_Code; }
            set { it_Code = value; }
        }

        private DataSet dsXml;
        public DataSet DsXml
        {
            get { return dsXml; }
            set { dsXml = value; }
        }

    }
}

