using System;
using System.Collections.Generic;
using System.Text;
using Data.Acess.Layer;
using System.Data;
using System.Data.SqlClient;  
using System.Web.UI.WebControls;
using Controls;
using System.Reflection;
using AjaxControlToolkit;
   



namespace Business.Logic.Layer
{
    public class vuAllocation 
    {
        //private static DataTier DataAcess = new DataTier();
        //private static DataSet ds = new DataSet();
        stringFunction strFunction = new stringFunction();
        numericFunction numFunction = new numericFunction();
        getDateFormat DateFormat = new getDateFormat(); 

        public vuAllocation()
        {
            
        }

        private decimal vAmt;
        public decimal VAmt
        {
            get { return vAmt; }
            set { vAmt = value; }
        }

        private decimal vchrAmt;
        public decimal VchrAmt
        {
            get { return vchrAmt; }
            set { vchrAmt = value; }
        }

        private decimal fromAcAmt;

        public decimal FromAcAmt
        {
            get { return fromAcAmt; }
            set { fromAcAmt = value; }
        }

        

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();
        private SqlConnection connHandle;

        public void  CreateMallVw(DataSet MainDataSet,string pcvType)
        {
            string sql_mall = pcvType.ToString().Trim() + "Mall";
            string sqlStr = "select *,new_all as re_all,tds as tds_all,disc as disc_all,new_all as balance from " +
                                    sql_mall.ToString().Trim() + " where 1=0 ";

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
      
            MainDataSet = DataAcess.ExecuteDataset(MainDataSet, sqlStr, "mall_vw",connHandle);
            DataAcess.Connclose(connHandle);
 
            DataTable Mall_vw = MainDataSet.Tables["mall_vw"]; 
            Mall_vw = AddColumnsInDataSet(Mall_vw, "v_inv_no", "System.String", 15);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "v_inv_dt", "System.DateTime",10);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "dept", "System.String", 50);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "cate", "System.String", 50);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "Inv_sr", "System.String", 50);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "Inv_no", "System.String", 15);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "l_yn", "System.String", 9);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "inv_date", "System.DateTime", 10);
            Mall_vw = AddColumnsInDataSet(Mall_vw, "id", "System.String", 8);
            Mall_vw.AcceptChanges();
            DataTable TmpMall_vw = Mall_vw.Clone();
            TmpMall_vw.TableName = "tmpMall_vw";  
            TmpMall_vw.AcceptChanges();
            MainDataSet.Tables.Add(TmpMall_vw);    
            MainDataSet.AcceptChanges();
        }


        private DataTable AddColumnsInDataSet(DataTable DTable, string ColumnName, string Coltype, int ColMaxLen)
        {
            if (DTable.Columns.Contains(ColumnName) == false)
            {
                DataColumn DbCol = new DataColumn();
                DbCol.ColumnName = ColumnName.ToString();
                DbCol.DataType = System.Type.GetType(Coltype);
                if (ColMaxLen == 0)
                {
                    DbCol.MaxLength = ColMaxLen;
                }
                DTable.Columns.Add(DbCol);
            }
            return DTable;
        }

        public void Allocate(bool addmode, bool editmode, DataTable tmpMall_vw, DataTable Mall_vw, string pcvType,                            
                             DataRow acDetRow,DataTable main_vw,DataTable Company)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            DataSet ds = new DataSet();

            string _al_type = "";
            if (Convert.ToString(acDetRow["amt_ty"].ToString().Trim())   == "DR")
            {
                _al_type = "CR";
            }
            else
            {
                _al_type = "DR";
            }

            string SqlStr = "";
            if (addmode == true || editmode == true)
            {
                SqlDataReader dr;
                SqlStr = "select top 1 entry_ty from lac_vw where ac_id = " + Convert.ToString(acDetRow["ac_id"]).Trim();
                dr = DataAcess.ExecuteDataReader(SqlStr,ref connHandle);  

                if (dr.HasRows == true)
                {
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);  
                    SqlStr = "Select A.Tran_cd,A.Entry_ty,A.Date,A.Inv_sr,A.Inv_no,A.L_yn, " +
                             "A.Dept,A.Cate,A.U_pinvno,A.U_pinvdt,B.Amount,B.Re_all,B.Disc,B.Tds,B.Amt_ty From Lac_vw B,Lmain_vw A where " +
                             "B.Entry_ty = A.Entry_ty And B.Tran_cd = A.Tran_cd And B.Ac_id = " + Convert.ToString(acDetRow["ac_id"]).Trim();
                    ds = DataAcess.ExecuteDataset(SqlStr, "_tmptbl_vw",connHandle);
                    DataAcess.Connclose(connHandle);

                    if (ds.Tables["_tmptbl_vw"].Rows.Count > 0)
                    {

                        foreach (DataRow dtRows in ds.Tables["_tmptbl_vw"].Select("amt_ty <> '" + _al_type.ToString() + "' OR re_all  >= amount"))
                        {
                            dtRows.Delete();
                            dtRows.AcceptChanges();  
                        }
                        
                        foreach (DataRow dtRows in ds.Tables["_tmptbl_vw"].Rows)
                        {
                            allUpdate(tmpMall_vw, dtRows, Convert.ToInt32(acDetRow["ac_id"]), Convert.ToString(acDetRow["ac_name"]).Trim());
                        }
                    }
                    ds.Clear();
                    ds.Dispose(); 
                }
                dr.Close();
                dr.Dispose();
                DataAcess.Connclose(connHandle);
            }

            string moref_no = "";
            string meref_no = "";
            if (editmode == true)    // Edit mode True
            {
                string Sql_acdet = pcvType.ToString().Trim() + "Acdet";
                SqlStr = " Select Top 1 Re_all,Ref_no From " + Sql_acdet.ToString() +
                " where Tran_cd = '" + Convert.ToString(main_vw.Rows[0]["tran_cd"]).Trim() + "' and ac_id = " + Convert.ToString(acDetRow["ac_id"]).Trim()  +
                " and amt_ty = '" + Convert.ToString(acDetRow["amt_ty"]).Trim() + "'";

                ds = DataAcess.ExecuteDataset(SqlStr,"_tmptbl_vw",connHandle);
                DataAcess.Connclose(connHandle);

                if (ds.Tables["_tmptbl_vw"].Rows.Count > 0 && numFunction.toDecimal(ds.Tables["_tmptbl_vw"].Rows[0]["re_all"]) > 0)
                {
                    meref_no = Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "/";

                    if (Convert.ToString(ds.Tables["_tmptbl_vw"].Rows[0]["ref_no"]) == null || Convert.ToString(ds.Tables["_tmptbl_vw"].Rows[0]["ref_no"]) == "")
                    {
                        meref_no += "";
                    }
                    else
                    {
                        meref_no += Convert.ToString(ds.Tables["_tmptbl_vw"].Rows[0]["ref_no"]).Trim();
                    }
                }
            }  // End


            if (addmode == false && editmode == false && numFunction.toDecimal(acDetRow["re_all"])  > 0)
            {
                meref_no = Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "/";

                if (Convert.ToString(acDetRow["ref_no"]) == null || Convert.ToString(acDetRow["ref_no"]) == "")
                {
                    meref_no += "";
                }
                else
                {
                    meref_no += Convert.ToString(acDetRow["ref_no"]).Trim();
                }
            }

            if (meref_no != "")
            {
                string _chktbl = "";
                string _chkentry = "";
                while (meref_no != "")
                {
                    string mentry_ty = strFunction.Left(meref_no, 2);
                    meref_no = meref_no.Trim().Substring(3);

                    if (moref_no.ToString().Trim() != "")
                    {
                        if (mentry_ty.IndexOf(moref_no.ToString().Trim()) <= 0)
                        {
                            continue;
                        }
                    }

                    moref_no = moref_no + '/' + mentry_ty.ToString().Trim();

                    string sql_mall = "";
                    string sql_cond = "";
                    
                    if (mentry_ty.ToString().Trim() == Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim())
                    {
                        sql_mall = pcvType.ToString().Trim() + "Mall";
                        sql_cond = " entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and tran_cd = " + Convert.ToString(main_vw.Rows[0]["tran_cd"]).Trim(); 
                    }
                    else
                    {
                        if (mentry_ty.ToString().Trim() != _chkentry.ToString().Trim())
                        {
                            _chktbl = chkTable(mentry_ty.ToString().Trim(),null,ref connHandle);
                        }

                        _chkentry = mentry_ty.ToString();
                        sql_mall = _chktbl.ToString() + "Mall";
                        sql_cond = " entry_all = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and main_tran = " + Convert.ToString(main_vw.Rows[0]["tran_cd"]).Trim();     
                    }

                    SqlStr = "Select Tran_cd,Entry_ty,Main_Tran,Entry_all,New_all,Tds,Disc From " +
			                 sql_mall.ToString().Trim() + " where " +sql_cond.ToString().Trim() + " And Ac_id = " + Convert.ToString(acDetRow["ac_id"]).Trim();

                    ds = DataAcess.ExecuteDataset(ds, SqlStr, "_tmptbl_vw1",connHandle);
                    DataAcess.Connclose(connHandle);
                    DataRow SearchRow = null;
                    foreach (DataRow tmpRows in ds.Tables["_tmptbl_vw1"].Rows)
                    {
                        bool mfound = false;
                        mentry_ty = "";
                        sql_cond = "";
                       
                        if (Convert.ToString(tmpRows["entry_ty"]).Trim() == Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() && 
                            Convert.ToString(tmpRows["tran_cd"]).Trim() == Convert.ToString(main_vw.Rows[0]["tran_cd"]).Trim())
                        {
                            foreach (DataRow DtRow in tmpMall_vw.Select("entry_all = '" + Convert.ToString(tmpRows["entry_all"]).Trim() + "' and main_tran = " + Convert.ToString(tmpRows["main_tran"])))
                            {
                                SearchRow = DtRow;
                                mfound = true;
                            }

                            if (mfound == false)
                            {
                                mentry_ty = Convert.ToString(tmpRows["entry_all"]).Trim();
                                sql_cond = "a.entry_ty = b.entry_ty and a.tran_cd = b.tran_cd and a.entry_ty = '" +
                                            Convert.ToString(tmpRows["entry_all"]).Trim() + "' and a.tran_cd = " + Convert.ToString(tmpRows["main_tran"]).Trim();
                            }
                        }
                        else
                        {
                            foreach (DataRow DtRow in tmpMall_vw.Select("entry_ty = '" + Convert.ToString(tmpRows["entry_all"]).Trim() + "' and main_tran = " + Convert.ToString(tmpRows["tran_cd"]).Trim()))
                            {
                                SearchRow = DtRow;
                                mfound = true;
                            }

                            if (mfound == false)
                            {
                                mentry_ty = Convert.ToString(tmpRows["entry_ty"]).Trim();
                                sql_cond = "a.entry_ty = b.entry_ty and a.tran_cd = b.tran_cd and a.entry_ty = '" +
                                            Convert.ToString(tmpRows["entry_ty"]).Trim() + "' and a.tran_cd = " + Convert.ToString(tmpRows["tran_cd"]).Trim();

                            }
                        }

                        if (mfound == false)
                        {
                            string sql_main = "";
                            string sql_acdet = "";
                            if (mentry_ty.ToString().Trim() == Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim())
                            {
                                sql_main = pcvType.ToString().Trim() + "Main";
                                sql_acdet = pcvType.ToString().Trim() + "Acdet";
                            }
                            else
                            {
                                if (mentry_ty.ToString().Trim() != _chkentry.ToString().Trim())
                                {
                                    _chktbl = chkTable(mentry_ty.ToString().Trim(),null,ref connHandle);
                                }
                                _chkentry = mentry_ty.ToString().Trim();
                                sql_main = _chktbl.ToString().Trim() + "Main";
                                sql_acdet = _chktbl.ToString().Trim() + "Acdet";
                            }

                            SqlStr = "Select Top 1 A.tran_cd,a.entry_ty,A.Date,A.Inv_sr,A.Inv_no,A.L_yn," +
                                     "A.Dept,A.Cate,A.U_pinvno,A.U_pinvdt," +
                                     "B.Amount,B.Re_all,B.Disc,B.Tds,B.Amt_ty From " + sql_acdet.ToString().Trim() + " B," + sql_main.ToString().Trim() + " A where " +
                                     "B.Ac_id = " + Convert.ToString(acDetRow["ac_id"]).Trim() + " And B.Amt_ty = " + _al_type.ToString().Trim() + " And " +
                                     sql_cond.ToString().Trim();

                            ds = DataAcess.ExecuteDataset(ds, SqlStr, "_tmptbl_vw",connHandle);
                            DataAcess.Connclose(connHandle);

                            if (ds.Tables["_tmptbl_vw"].Rows.Count > 0)
                            {
                                DataRow DtRow = ds.Tables["_tmptbl_vw"].Rows[0];
                                allUpdate(tmpMall_vw, DtRow, Convert.ToInt16(acDetRow["ac_id"]), Convert.ToString(acDetRow["ac_name"]).Trim());
                                mfound = true;
                            }

                        }

                        if (mfound == true)
                        {

                            SearchRow["re_all"] = numFunction.toDecimal(SearchRow["Re_all"]) -
                                                  (numFunction.toDecimal(tmpRows["new_all"]) + numFunction.toDecimal(tmpRows["tds"]) + numFunction.toDecimal(tmpRows["disc"]));

                            // Tds All
                            if (Convert.ToString(SearchRow["Entry_all"]).Trim() == Convert.ToString(tmpRows["entry_all"]).Trim()
                                && Convert.ToInt16(SearchRow["Main_Tran"]) == Convert.ToInt16(tmpRows["Main_Tran"]))
                            {
                                SearchRow["Tds_all"] = numFunction.toDecimal(SearchRow["Tds_all"]) - numFunction.toDecimal(tmpRows["Tds"]);
                            }
                            else
                            {
                                SearchRow["Tds_all"] = numFunction.toDecimal(SearchRow["Tds_all"]) - 0;
                            }

                            // Disc All
                            if (Convert.ToString(SearchRow["Entry_all"]).Trim() == Convert.ToString(tmpRows["entry_all"]).Trim()
                                && Convert.ToInt16(SearchRow["Main_Tran"]) == Convert.ToInt16(tmpRows["Main_Tran"]))
                            {
                                SearchRow["Disc_all"] = numFunction.toDecimal(SearchRow["Disc_all"]) - numFunction.toDecimal(tmpRows["Disc"]);
                            }
                            else
                            {
                                SearchRow["Disc_all"] = numFunction.toDecimal(SearchRow["Disc_all"]) - 0;
                            }

                            if (addmode == true || editmode == true)
                            {
                                SearchRow["New_all"] = 0;
                                SearchRow["Tds"] = 0;
                                SearchRow["Disc"] = 0;
                            }
                            else
                            {
                                SearchRow["New_all"] = numFunction.toDecimal(SearchRow["New_all"]) + numFunction.toDecimal(tmpRows["New_All"]);
                                if (Convert.ToString(SearchRow["Entry_all"]).Trim() == Convert.ToString(tmpRows["entry_all"]).Trim()
                                    && Convert.ToInt16(SearchRow["Main_Tran"]) == Convert.ToInt16(tmpRows["Main_Tran"]))
                                {
                                    SearchRow["Tds"] = numFunction.toDecimal(SearchRow["Tds"]) + numFunction.toDecimal(tmpRows["Tds"]);
                                }
                                else
                                {
                                    SearchRow["Tds"] = numFunction.toDecimal(SearchRow["Tds"]) + 0;
                                }

                                if (Convert.ToString(SearchRow["Entry_all"]).Trim() == Convert.ToString(tmpRows["entry_all"]).Trim()
                                    && Convert.ToInt16(SearchRow["Main_Tran"]) == Convert.ToInt16(tmpRows["Main_Tran"]))
                                {
                                    SearchRow["Disc"] = numFunction.toDecimal(SearchRow["Disc"]) + numFunction.toDecimal(tmpRows["Disc"]);
                                }
                                else
                                {
                                    SearchRow["Disc"] = numFunction.toDecimal(SearchRow["Disc"]) + 0;
                                }
                            }
                            SearchRow.AcceptChanges();
                            tmpMall_vw.AcceptChanges();  

                        }   // mfound end

                    }
 
                    if (meref_no == "")
                    {
                        break; 
                    }
                }  // End While
            } // meref_no not empty END

            if (addmode == true || editmode == true)
            {
                foreach (DataRow mallRow in Mall_vw.Select("ac_id = " + Convert.ToString(acDetRow["ac_id"]).Trim()))
                {
                    bool mfound = false;
                    DataRow SearchRow = null;
                    if (Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() == Convert.ToString(mallRow["Entry_ty"]).Trim()
                        && Convert.ToInt32(main_vw.Rows[0]["tran_cd"]) == Convert.ToInt32(mallRow["Tran_cd"]))
                    {
                        foreach (DataRow DtRow in tmpMall_vw.Select("entry_all = '" + Convert.ToString(mallRow["entry_all"]).Trim() + "' and main_tran = " + Convert.ToString(mallRow["main_tran"])
                                                              + " and ac_id = " + Convert.ToString(mallRow["Ac_id"]).Trim()))
                        {
                            SearchRow = DtRow; 
                            mfound = true;
                        }

                        if (mfound == false)
                        {
                            foreach (DataRow DtRow in tmpMall_vw.Select("entry_ty = '" + Convert.ToString(mallRow["entry_all"]).Trim() + "' and tran_cd = " + Convert.ToString(mallRow["main_tran"])
                                                                  + " and ac_id = " + Convert.ToString(mallRow["Ac_id"]).Trim()))
                            {
                                SearchRow = DtRow;
                                mfound = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (DataRow DtRow in tmpMall_vw.Select("entry_ty = '" + Convert.ToString(mallRow["entry_ty"]).Trim() + "' and tran_cd = " + Convert.ToString(mallRow["Tran_cd"]).Trim() 
                                      + " and ac_id = " + Convert.ToString(mallRow["Ac_id"]).Trim()))
                        {
                            SearchRow = DtRow;
                            mfound = true;
                        }

                        if (mfound == false)
                        {
                            foreach (DataRow DtRow in tmpMall_vw.Select("entry_all = '" + Convert.ToString(mallRow["entry_all"]).Trim() + "' and main_tran = " + Convert.ToString(mallRow["main_tran"]).Trim() 
                                                                   + " and ac_id = " + Convert.ToString(mallRow["Ac_id"]).Trim()))
                            {
                                SearchRow = DtRow;
                                mfound = true;
                            }
                        }
                    }

                    if (mfound == true)
                    {
                        SearchRow["New_All"] = numFunction.toDecimal(SearchRow["New_All"]) + numFunction.toDecimal(mallRow["New_all"]);
                        SearchRow["Tds"] = numFunction.toDecimal(SearchRow["Tds"]) + numFunction.toDecimal(mallRow["Tds"]);
                        SearchRow["Disc"] = numFunction.toDecimal(SearchRow["Disc"]) + numFunction.toDecimal(mallRow["Disc"]);
                        SearchRow.AcceptChanges();  
                    }
                    tmpMall_vw.AcceptChanges();  
                }
            }

            if (addmode == true || editmode == true)
            {
                bool found = false;
                SqlStr = "select top 1 ac_id from Lac_vw where ac_id = " + Convert.ToString(acDetRow["ac_id"]).Trim() +
                         " and date < '" + DateFormat.dateformat(DateFormat.TodateTime(Company.Rows[0]["sta_dt"])) + "'";
                  
                ds = DataAcess.ExecuteDataset(SqlStr, "tmptbl_vw",connHandle);
                DataAcess.Connclose(connHandle);
                if (ds.Tables["tmptbl_vw"].Rows.Count  > 0)
                {
                    found = true;
                }
                else
                {
                    found = false;
                }

                if (found == true)
                {
                    foreach (DataRow tmpRow in tmpMall_vw.Select("(entry_ty = 'OB' or entry_all = 'OB') and (new_all = 0 and tds = 0)"))
                    {
                        tmpRow.Delete();
                        tmpRow.AcceptChanges();
                    }
                }

                foreach (DataRow tmpRow in tmpMall_vw.Select("(Inv_Date > '" + Convert.ToString(acDetRow["date"]).Trim() + "' or Date > '"
                         + Convert.ToString(acDetRow["Date"]).Trim() + "') and (new_all = 0 and tds = 0)"))
                {
                    tmpRow.Delete();
                    tmpRow.AcceptChanges();  
                }
                
                // update all rows which entry_ty fields blank
                foreach (DataRow tmpRow in tmpMall_vw.Select("entry_ty = '' or entry_ty IS NULL "))
                {
                    tmpRow["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                    tmpRow["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                    tmpRow.AcceptChanges();  
                }
                tmpMall_vw.AcceptChanges();  
            }

            foreach (DataRow tmpRow in tmpMall_vw.Rows)
            {
                tmpRow["Balance"] = (numFunction.toDecimal(tmpRow["net_amt"]) -
                                     (numFunction.toDecimal(tmpRow["re_all"]) +
                                      numFunction.toDecimal(tmpRow["new_all"]) +
                                      numFunction.toDecimal(tmpRow["disc_all"]) +
                                      numFunction.toDecimal(tmpRow["tds_all"]) +
                                      numFunction.toDecimal(tmpRow["disc"]) +
                                      numFunction.toDecimal(tmpRow["tds"])));
                tmpRow.AcceptChanges();  
            }
            tmpMall_vw.AcceptChanges();
            ds.Dispose();
            DataAcess.Connclose(connHandle); 
        }

        private string editNarr;
        public string EditNarr
        {
            get { return editNarr; }
            set { editNarr = value; }
        }

        private string mNarration;
        public string MNarration
        {
            get { return mNarration; }
            set { mNarration = value; }
        }

        private string mNarration1;
        public string MNarration1
        {
            get { return mNarration1; }
            set { mNarration1 = value; }
        }

        public void autoAllocate(bool addmode, bool editmode, DataTable tmpMall_vw, DataTable Mall_vw, string pcvType,
                            DataRow acDetRow, DataTable main_vw, DataTable Company,DataTable lcode_vw,bool alloc)
        {
            try
            {
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                string defaNarr = Convert.ToString(lcode_vw.Rows[0]["defa_narr"]).Trim();
                string acName = Convert.ToString(acDetRow["ac_name"]).Trim();
                string mnarr = "";
                string narrcapt = "";
                EditNarr = EditNarr == null ? "" : EditNarr;

                if (alloc == false && defaNarr.ToString().Trim() != "")
                {
                    foreach (DataRow mallRow in Mall_vw.Select("party_nm = '" + acName.ToString().Trim() + "'"))
                    {
                        string muPinvNo, mnarrmain = "";
                        DateTime muPinvDt = DBPropsSession.AppDate;
                        if (Convert.ToString(mallRow["v_inv_no"]) != "")
                        {
                            muPinvNo = Convert.ToString(mallRow["v_inv_no"]);
                        }
                        else
                        {
                            muPinvNo = Convert.ToString(mallRow["inv_no"]);
                        }

                        if (DateFormat.TodateTime(mallRow["v_inv_dt"]) >= DBPropsSession.AppDate && DateFormat.TodateTime(mallRow["v_inv_dt"]) <= DateTime.MaxValue)
                        {
                            muPinvDt = DateFormat.TodateTime(mallRow["v_inv_dt"]);
                        }
                        else
                        {
                            muPinvDt = DateFormat.TodateTime(mallRow["inv_date"]);
                        }

                        switch (defaNarr.ToString().Trim())
                        {
                            case "FROM ALLOCATION WITH DATE AND AMOUNT":
                                mnarrmain = muPinvNo.Trim() + " Dt. " + DateFormat.TodateTime(muPinvDt) +
                                            " Amt. " + Convert.ToString(mallRow["net_amt"]).Trim();
                                break;
                            case "FROM ALLOCATION WITH DATE":
                                mnarrmain = muPinvNo.Trim() + " Dt. " + DateFormat.TodateTime(muPinvDt);
                                break;
                            case "FROM ALLOCATION":
                                mnarrmain = muPinvNo.Trim();
                                break;
                        }

                        if (Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() == Convert.ToString(mallRow["entry_ty"]).Trim() &&
                            Convert.ToInt32(main_vw.Rows[0]["tran_cd"]) == Convert.ToInt32(mallRow["tran_cd"]))
                        {
                            mnarr = mnarr + ", " + mnarrmain.Trim();
                        }
                        else
                        {
                            if (Convert.ToString(mallRow["entry_all"]).Trim() == narrcapt.Trim())
                            {
                                mnarr = mnarr + ", " + mnarrmain;
                            }
                            else
                            {
                                string codeNm = "";
                                string invCaption = "";
                                string SqlStr = "";
                                DataTable tmptbl_vw;
                                SqlStr = "select top 1 code_nm,InvCaption from lcode where cd = '" +
                                         Convert.ToString(mallRow["entry_all"]).Trim() + "'";
                                tmptbl_vw = DataAcess.ExecuteDataTable(SqlStr, "tmptbl_vw",connHandle);
                                DataAcess.Connclose(connHandle);

                                foreach (DataRow tmpRows in tmptbl_vw.Rows)
                                {
                                    codeNm = Convert.ToString(tmpRows["code_nm"]).Trim();
                                    invCaption = Convert.ToString(tmpRows["InvCaption"]).Trim();
                                }

                                if (invCaption.ToString().Trim() != "")
                                {
                                    mnarr = mnarr + ", " + codeNm.Trim().ToUpper() + " " +
                                            invCaption.Trim();
                                }
                                else
                                {
                                    if (strFunction.InList(Convert.ToString(mallRow["entry_all"]).Trim(), new string[4] { "ST", "PT", "SR", "PR" }) == true)
                                    {
                                        mnarr = mnarr + ", " + codeNm.Trim().ToUpper() + " " +
                                                " Invoice(s) " + mnarrmain.Trim();
                                    }
                                    else
                                    {
                                        mnarr = mnarr + ", " + codeNm.Trim().ToUpper() + " " +
                                                " No(s). " + mnarrmain.Trim();
                                    }
                                }
                                narrcapt = Convert.ToString(mallRow["entry_all"]).Trim();

                            }
                        }

                    }  // end DataTable filter 
                    if (mnarr.Trim() != "")
                    {
                        mnarr = "AGAINST " + mnarr;
                    }

                    EditNarr = mnarr;
                }

                if (alloc == true)
                {
                    foreach (DataRow mallRow in Mall_vw.Select("party_nm = '" + acName.ToString().Trim() + "'"))
                    {
                        acDetRow["re_all"] = numFunction.toDecimal(acDetRow["re_all"]) -
                                            (numFunction.toDecimal(mallRow["new_all"]) +
                                             numFunction.toDecimal(mallRow["tds"]) +
                                             numFunction.toDecimal(mallRow["disc"]));

                        if (Convert.ToString(mallRow["entry_ty"]).Trim() == Convert.ToString(acDetRow["entry_ty"]).Trim() &&
                            Convert.ToInt32(mallRow["tran_cd"]) == Convert.ToInt32(acDetRow["tran_cd"]))
                        {
                            acDetRow["tds"] = numFunction.toDecimal(mallRow["tds"]);
                            acDetRow["disc"] = numFunction.toDecimal(mallRow["disc"]);
                        }
                    }

                    foreach (DataRow mallRow in Mall_vw.Select("party_nm ='" + acName.Trim() + "'"))
                    {
                        mallRow.Delete();
                        mallRow.AcceptChanges();
                    }

                    foreach (DataRow tmpMallRow in tmpMall_vw.Select("new_all > 0", "Inv_Date"))
                    {
                        DataRow mallRow;
                        mallRow = Mall_vw.NewRow();

                        mallRow = DataAcess.ScatterGatherRow(tmpMallRow, mallRow);
                        Mall_vw.Rows.Add(mallRow);

                        //for (int i = 0; i < tmpMall_vw.Columns.Count; i++)
                        //{
                        //    mallRow[i] = tmpMallRow[i];
                        //}

                        if (defaNarr.Trim() != "")
                        {
                            string muPinvNo, mnarrmain = "";
                            DateTime muPinvDt = DBPropsSession.AppDate;
                            if (Convert.ToString(mallRow["v_inv_no"]) != "")
                            {
                                muPinvNo = Convert.ToString(mallRow["v_inv_no"]);
                            }
                            else
                            {
                                muPinvNo = Convert.ToString(mallRow["inv_no"]);
                            }

                            if (DateFormat.TodateTime(mallRow["v_inv_dt"]) >= DBPropsSession.AppDate && DateFormat.TodateTime(mallRow["v_inv_dt"]) <= DateTime.MaxValue)
                            {
                                muPinvDt = DateFormat.TodateTime(mallRow["v_inv_dt"]);
                            }
                            else
                            {
                                muPinvDt = DateFormat.TodateTime(mallRow["inv_date"]);
                            }

                            switch (defaNarr.ToString().Trim())
                            {
                                case "FROM ALLOCATION WITH DATE AND AMOUNT":
                                    mnarrmain = muPinvNo.Trim() + " Dt. " + DateFormat.TodateTime(muPinvDt) +
                                                " Amt. " + Convert.ToString(mallRow["net_amt"]).Trim();
                                    break;
                                case "FROM ALLOCATION WITH DATE":
                                    mnarrmain = muPinvNo.Trim() + " Dt. " + DateFormat.GetDateSTR(muPinvDt).Trim();
                                    break;
                                case "FROM ALLOCATION":
                                    mnarrmain = muPinvNo.Trim();
                                    break;
                            }

                            if (Convert.ToString(main_vw.Rows[0]["Entry_ty"]).Trim() == Convert.ToString(mallRow["Entry_ty"]).Trim() &&
                                Convert.ToInt32(main_vw.Rows[0]["tran_cd"]) == Convert.ToInt32(mallRow["tran_cd"]))
                            {
                                mnarr = mnarr + ", " + mnarrmain;
                            }
                            else
                            {
                                if (Convert.ToString(mallRow["Entry_all"]).Trim() == narrcapt.Trim())
                                {
                                    mnarr = mnarr + ", " + mnarrmain;
                                }
                                else
                                {
                                    string codeNm = "";
                                    string invCaption = "";
                                    string SqlStr = "";

                                    DataTable tmptbl_vw;
                                    SqlStr = "select top 1 code_nm,InvCaption from lcode where cd = '" +
                                             Convert.ToString(mallRow["entry_all"]).Trim() + "'";
                                    tmptbl_vw = DataAcess.ExecuteDataTable(SqlStr, "tmptbl_vw",connHandle);
                                    DataAcess.Connclose(connHandle);

                                    foreach (DataRow tmpRows in tmptbl_vw.Rows)
                                    {
                                        codeNm = Convert.ToString(tmpRows["code_nm"]).Trim();
                                        invCaption = Convert.ToString(tmpRows["InvCaption"]).Trim();
                                    }

                                    if (invCaption.ToString().Trim() != "")
                                    {
                                        mnarr = mnarr + ", " + codeNm.Trim().ToUpper() + " " +
                                                invCaption.Trim();
                                    }
                                    else
                                    {
                                        if (strFunction.InList(Convert.ToString(mallRow["entry_all"]).Trim(), new string[4] { "ST", "PT", "SR", "PR" }) == true)
                                        {
                                            mnarr = mnarr + ", " + codeNm.Trim().ToUpper() + " " +
                                                    " Invoice(s) " + mnarrmain.Trim();
                                        }
                                        else
                                        {
                                            mnarr = mnarr + ", " + codeNm.Trim().ToUpper() + " " +
                                                    " No(s). " + mnarrmain.Trim();
                                        }
                                    }
                                    narrcapt = Convert.ToString(mallRow["entry_all"]).Trim();
                                }
                            }

                            acDetRow["re_all"] = numFunction.toDecimal(acDetRow["re_all"]) +
                                                 (numFunction.toDecimal(tmpMallRow["new_all"]) +
                                                 numFunction.toDecimal(tmpMallRow["tds"]) +
                                                 numFunction.toDecimal(tmpMallRow["disc"]));


                            if (Convert.ToString(mallRow["entry_ty"]).Trim() == Convert.ToString(acDetRow["entry_ty"]).Trim() &&
                                Convert.ToInt32(mallRow["tran_cd"]) == Convert.ToInt32(acDetRow["tran_cd"]))
                            {
                                acDetRow["tds"] = numFunction.toDecimal(mallRow["tds"]);
                                acDetRow["disc"] = numFunction.toDecimal(mallRow["disc"]);
                            }

                        }


                        Mall_vw.AcceptChanges();  // update changes
                    }

                    if (mnarr.Trim() != "")
                    {
                        mnarr = " AGAINST " + mnarr.Trim();

                        if (EditNarr.Trim() == "" || Convert.ToBoolean(lcode_vw.Rows[0]["a_narr"]) == true)
                        {
                            acDetRow["narr"] = Convert.ToString(acDetRow["narr"]) + mnarr.Trim();
                        }
                        else
                        {
                            if (EditNarr.Trim() != "")
                            {
                                string mnarr1 = "";
                                if (EditNarr.IndexOf(Convert.ToString(acDetRow["narr"]).Trim()) >= 0)
                                {
                                    mnarr1 = Convert.ToString(acDetRow["Narr"]).Trim().Replace(editNarr.Trim(), mnarr);
                                }
                                else
                                {
                                    mnarr1 = mnarr;
                                }
                                MNarration = mnarr.Trim();
                                MNarration1 = mnarr1.Trim();
                            }
                        }
                    }
                }
                acDetRow.AcceptChanges();
                DataAcess.Connclose(connHandle); 
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in autoAllocate Method |" + DataEx.Message.Trim());  
            }
            catch (SqlException SqlEx)
            {
                throw new Exception("ERROR found in autoAllocate Method |" + SqlEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in autoAllocate Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException  IndEx)
            {
                throw new Exception("ERROR found in autoAllocate Method |" + IndEx.Message.Trim());
            }
            catch (Exception IndEx)
            {
                throw new Exception("ERROR found in autoAllocate Method |" + IndEx.Message.Trim());
            }

        }

        public void autoAllocAlert(DataRow acdetRow, bool found, string editNarr, string mNarr)
        {
            try
            {
                if (found == true)
                {
                    if (EditNarr.Trim().IndexOf(Convert.ToString(acdetRow["Narr"])) >= 0)
                    {
                        acdetRow["Narr"] = Convert.ToString(acdetRow["Narr"]).Trim().Replace(editNarr.Trim(), mNarr);
                    }
                    else
                    {
                        acdetRow["Narr"] = mNarr.Trim();
                    }

                    acdetRow.AcceptChanges();
                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in autoAllocAlert Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in autoAllocAlert Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in autoAllocAlert Method |" + IndEx.Message.Trim());
            }
            catch (Exception IndEx)
            {
                throw new Exception("ERROR found in autoAllocAlert Method |" + IndEx.Message.Trim());
            }
        }

        public string chkTable(string _chkentry1,SqlCommand cmd,ref SqlConnection connTran)
        {
            try
            {
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                string _chkentry2 = _chkentry1;
                string _chktbl = "";
                string SqlStr = "select Top 1 Entry_ty,Bcode_nm from Lcode Where Entry_ty = '" + _chkentry2.ToString().Trim() + "'";
                DataTable tmpLcode_vw = null;

                if (cmd != null)
                    tmpLcode_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);
                else
                    tmpLcode_vw = DataAcess.ExecuteDataTable(SqlStr, "tmpLcode",connTran);

                if (tmpLcode_vw.Rows.Count > 0)
                {
                    foreach (DataRow tmpLcodeRow in tmpLcode_vw.Rows)
                    {
                        string ment = Convert.ToString(tmpLcodeRow["entry_ty"]).Trim();
                        string mbeh = Convert.ToString(tmpLcodeRow["bcode_nm"]).Trim();

                        SqlStr = "select name from sysobjects where xtype='U' and name like '%MAIN%'";

                        DataTable chktbl_vw = null;
                        if (cmd != null)
                            chktbl_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connTran);
                        else
                            chktbl_vw = DataAcess.ExecuteDataTable(SqlStr, "_chk",connHandle);

                        if (chktbl_vw.Rows.Count > 0)
                        {
                            bool isFoundMent = false;
                            try
                            {
                                DataRow chkTblRow = chktbl_vw.Select("name = '" + ment.ToString().Trim() + "Main'")[0];
                                isFoundMent = true;
                            }
                            catch
                            {
                                isFoundMent = false;
                            }

                            if (isFoundMent == true)
                                _chktbl = ment.ToString().Trim();
                            else
                            {
                                bool isFoundMBeh = false;
                                try
                                {
                                    DataRow chkTblRow = chktbl_vw.Select("name = '" + mbeh.ToString().Trim() + "Main'")[0];
                                    isFoundMBeh = true;
                                }
                                catch
                                {
                                    isFoundMBeh = false;
                                }

                                if (isFoundMBeh == true)
                                    _chktbl = mbeh.ToString().Trim();
                            }
                        }
                    }

                }
                //DataAcess.Connclose();  
                return _chktbl;
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in chkTable Method |" + DataEx.Message.Trim());
            }
            catch (SqlException SqlEx)
            {
                throw new Exception("ERROR found in chkTable Method |" + SqlEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in chkTable Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in chkTable Method |" + IndEx.Message.Trim());
            }
            catch (Exception IndEx)
            {
                throw new Exception("ERROR found in chkTable Method |" + IndEx.Message.Trim());
            }

        }

        private void allUpdate(DataTable tmpMall_vw,DataRow tmptbl_vw,int ac_id,string acName)
        {
            try
            {
                string pInv_no = "";
                DateTime pInv_dt = DBPropsSession.AppDate;
                if (Convert.ToString(tmptbl_vw["u_pinvno"]).Trim() == "")
                {
                    pInv_no = Convert.ToString(tmptbl_vw["Inv_no"]).Trim();
                }
                else
                {
                    pInv_no = Convert.ToString(tmptbl_vw["U_pinvno"]).Trim();
                }

                if (pInv_dt >= DBPropsSession.AppDate && pInv_dt <= DateTime.MaxValue)
                {
                    pInv_dt = DateFormat.TodateTime(tmptbl_vw["Date"]);
                }
                else
                {
                    pInv_dt = DateFormat.TodateTime(tmptbl_vw["U_pinvdt"]);
                }
                vuGenerateNo GenerateUniqueNo = new vuGenerateNo();
                DataRow _row = tmpMall_vw.NewRow();
                _row["id"] = GenerateUniqueNo.GenerateNo(tmpMall_vw, "id", false, 8).PadLeft(8, '0');
                _row["ac_id"] = ac_id;
                _row["party_nm"] = acName.ToString();
                _row["main_tran"] = tmptbl_vw["tran_cd"].ToString();
                _row["entry_all"] = tmptbl_vw["entry_ty"].ToString();
                _row["inv_date"] = tmptbl_vw["date"];
                _row["inv_no"] = tmptbl_vw["inv_no"].ToString();
                _row["Inv_sr"] = tmptbl_vw["inv_sr"].ToString();
                _row["l_yn"] = tmptbl_vw["l_yn"].ToString();
                _row["v_inv_no"] = pInv_no;
                _row["v_inv_dt"] = pInv_dt;
                _row["re_all"] = numFunction.toDecimal(tmptbl_vw["re_all"]);
                _row["disc_all"] = numFunction.toDecimal(tmptbl_vw["disc"]);
                _row["tds_all"] = numFunction.toDecimal(tmptbl_vw["tds"]);
                _row["net_amt"] = numFunction.toDecimal(tmptbl_vw["Amount"]);
                _row["new_all"] = 0;
                _row["disc"] = 0;
                _row["tds"] = 0;
                _row["balance"] = 0;

                tmpMall_vw.Rows.Add(_row);
                tmpMall_vw.AcceptChanges();
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in allUpdate Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in allUpdate Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in allUpdate Method |" + IndEx.Message.Trim());
            }
            catch (Exception IndEx)
            {
                throw new Exception("ERROR found in allUpdate Method |" + IndEx.Message.Trim());
            }

        }

        public void vuAllocationInit(GridView gridforAllocation, 
                        DataTable tmpAll_vw, 
                        DataTable main_vw, 
                        CheckBox chkAllocExcess, 
                        string pcvType, 
                        bool addMode, 
                        bool editMode, 
                        decimal vAmt,
                        Label lblAmount,
                        Label lblTotAlloc,
                        Label lblBalance)
        {

            try
            {
                if (addMode == true || editMode == true)
                {
                    if (vAmt == 0)
                    {
                        chkAllocExcess.Checked = true;
                    }
                    else
                    {
                        chkAllocExcess.Checked = true;
                    }

                    decimal sumAmt1 = 0;
                    decimal sumAmt2 = 0;
                    decimal fromAcAmt = 0;
                    decimal vchrAmt = 0;
                    bool deptFound = false;
                    foreach (DataRow tmpRow in tmpAll_vw.Rows)
                    {
                        if (Convert.ToString(tmpRow["dept"]).Trim() != "")
                        {
                            deptFound = true;
                        }
                    }

                    foreach (DataRow tmpRow in tmpAll_vw.Rows)
                    {
                        if (Convert.ToString(tmpRow["entry_ty"]) != Convert.ToString(main_vw.Rows[0]["Entry_ty"]).Trim() &&
                            Convert.ToInt32(tmpRow["tran_cd"]) != Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                        {
                            sumAmt1 = sumAmt1 + (numFunction.toDecimal(tmpRow["new_all"]) + numFunction.toDecimal(tmpRow["tds"]) + numFunction.toDecimal(tmpRow["disc"]));
                        }

                        if (Convert.ToString(tmpRow["entry_ty"]) != Convert.ToString(main_vw.Rows[0]["Entry_ty"]).Trim() &&
                            Convert.ToInt32(tmpRow["tran_cd"]) != Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                        {
                            sumAmt2 = sumAmt2 + (numFunction.toDecimal(tmpRow["new_all"]) + numFunction.toDecimal(tmpRow["tds"]) + numFunction.toDecimal(tmpRow["disc"]));
                        }
                    }

                    fromAcAmt = vAmt - sumAmt2;

                    if (chkAllocExcess.Checked == true)
                    {
                        vchrAmt = sumAmt1;
                    }
                    else
                    {
                        vchrAmt = fromAcAmt;
                    }

                    VchrAmt = vchrAmt; // assign value to public variable

                    lblAmount.Text = Convert.ToString(vchrAmt).Trim();
                    lblTotAlloc.Text = Convert.ToString(sumAmt1).Trim();
                    lblBalance.Text = Convert.ToString(vchrAmt - sumAmt2).Trim();

                    // uday
                    DataTable gridColGen = new DataTable("StockDis");
                    DataColumn gridCol = new DataColumn();

                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Column";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Heading";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Tag";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Type";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.Int32");
                    gridCol.ColumnName = "Order";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "DataType";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.Int32");
                    gridCol.ColumnName = "Width";
                    gridColGen.Columns.Add(gridCol);

                    if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PT" }) == true)
                    {
                        AddRowInGridColGen(gridColGen, "new_all", "Allocate", "ALLOCATING", "TEMPLATE", 0, "DECIMAL", 100);  // 1
                        AddRowInGridColGen(gridColGen, "net_amt", "Inv.Amt.", "INVAMT", "BOUND", 1, "DECIMAL", 80);  // 2
                        AddRowInGridColGen(gridColGen, "re_all", "Allocated", "ALLOCATED", "BOUND", 2, "DECIMAL", 80); // 3
                        AddRowInGridColGen(gridColGen, "balance", "Balance", "BALANCE", "BOUND", 3, "DECIMAL", 80); // 4
                        AddRowInGridColGen(gridColGen, "", "Type", "INVTYPE", "BOUND", 6, "STRING", 0); //5
                        AddRowInGridColGen(gridColGen, "v_inv_no", "Bill.No.", "BILLNO", "BOUND", 4, "STRING", 80); // 6
                        if (deptFound == true)
                        {
                            AddRowInGridColGen(gridColGen, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 13, "DATE", 80); // 7
                            AddRowInGridColGen(gridColGen, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 12, "DECIMAL", 80); // 8
                            AddRowInGridColGen(gridColGen, "inv_no", "Inv.No.", "INVNO", "BOUND", 14, "STRING", 80); // 13
                            AddRowInGridColGen(gridColGen, "l_yn", "Year    ", "INVYEAR", "BOUND", 11, "STRING", 80); // 14
                        }
                        else
                        {
                            AddRowInGridColGen(gridColGen, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 12, "DATE", 80); // 7
                            AddRowInGridColGen(gridColGen, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 11, "DECIMAL", 80); // 8
                            AddRowInGridColGen(gridColGen, "inv_no", "Inv.No.", "INVNO", "BOUND", 13, "STRING", 80); // 13
                            AddRowInGridColGen(gridColGen, "l_yn", "Year    ", "INVYEAR", "BOUND", 10, "STRING", 80); // 14
                        }

                        AddRowInGridColGen(gridColGen, "tds_all", "TDS given", "TDSOLD", "BOUND", 7, "DECIMAL", 80); // 9
                        AddRowInGridColGen(gridColGen, "disc", "Discount", "DISCAMT", "BOUND", 8, "DECIMAL", 80); // 10
                        AddRowInGridColGen(gridColGen, "disc_all", "Discount given", "DISCOLD", "TEMPLATE", 10, "DECIMAL", 80); // 11
                        AddRowInGridColGen(gridColGen, "inv_sr", "Inv.Series", "INVSERIES", "BOUND", 09, "STRING", 100); // 12
                        AddRowInGridColGen(gridColGen, "dept", "Department", "DEPT", "BOUND", 5, "STRING", 100); // 15
                    }
                    else
                    {
                        AddRowInGridColGen(gridColGen, "new_all", "Allocate", "ALLOCATING", "TEMPLATE", 0, "DECIMAL", 200); // 1
                        AddRowInGridColGen(gridColGen, "net_amt", "Inv.Amt.", "INVAMT", "BOUND", 1, "DECIMAL", 80);  // 2
                        AddRowInGridColGen(gridColGen, "re_all", "Allocated", "ALLOCATED", "BOUND", 2, "DECIMAL", 80); // 3
                        AddRowInGridColGen(gridColGen, "balance", "Balance", "BALANCE", "BOUND", 3, "DECIMAL", 80); // 4
                        AddRowInGridColGen(gridColGen, "", "Type", "INVTYPE", "BOUND", 7, "STRING", 0); //5
                        AddRowInGridColGen(gridColGen, "v_inv_no", "Bill.No.", "BILLNO", "BOUND", 4, "STRING", 80); // 6
                        if (deptFound == true)
                        {
                            AddRowInGridColGen(gridColGen, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 09, "DATE", 80); // 7
                            AddRowInGridColGen(gridColGen, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 8, "DECIMAL", 80); // 8
                            AddRowInGridColGen(gridColGen, "tds_all", "TDS given", "TDSOLD", "BOUND", 11, "DECIMAL", 80); // 9
                            AddRowInGridColGen(gridColGen, "disc", "Discount", "DISCAMT", "TEMPLATE", 12, "DECIMAL", 80); // 10
                            AddRowInGridColGen(gridColGen, "disc_all", "Discount given", "DISCOLD", "TEMPLATE", 14, "DECIMAL", 80); // 11
                            AddRowInGridColGen(gridColGen, "inv_sr", "Inv.Series", "INVSERIES", "BOUND", 13, "STRING", 100); // 12
                            AddRowInGridColGen(gridColGen, "inv_no", "Inv.No.", "INVNO", "BOUND", 10, "STRING", 80); // 13
                            AddRowInGridColGen(gridColGen, "l_yn", "Year    ", "INVYEAR", "BOUND", 7, "STRING", 80); // 14
                        }
                        else
                        {
                            AddRowInGridColGen(gridColGen, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 8, "DATE", 80); // 7
                            AddRowInGridColGen(gridColGen, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 7, "DECIMAL", 80); // 8
                            AddRowInGridColGen(gridColGen, "tds_all", "TDS given", "TDSOLD", "BOUND", 10, "DECIMAL", 80); // 9
                            AddRowInGridColGen(gridColGen, "disc", "Discount", "DISCAMT", "TEMPLATE", 11, "DECIMAL", 80); // 10
                            AddRowInGridColGen(gridColGen, "disc_all", "Discount given", "DISCOLD", "BOUND", 13, "DECIMAL", 80); // 11
                            AddRowInGridColGen(gridColGen, "inv_sr", "Inv.Series", "INVSERIES", "BOUND", 12, "STRING", 100); // 12
                            AddRowInGridColGen(gridColGen, "inv_no", "Inv.No.", "INVNO", "BOUND", 09, "STRING", 80); // 13
                            AddRowInGridColGen(gridColGen, "l_yn", "Year    ", "INVYEAR", "BOUND", 6, "STRING", 80); // 14
                        }
                        AddRowInGridColGen(gridColGen, "dept", "Department", "DEPT", "BOUND", 5, "STRING", 100); // 15
                    }

                    DataView grdGenvw = gridColGen.DefaultView;
                    grdGenvw.Sort = "Order ASC";

                    foreach (DataRowView drv in grdGenvw)
                    {
                        //grdTemplateColumn(gridforAllocation,
                        //                  Convert.ToString(drv["Column"]).Trim(),
                        //                  Convert.ToString(drv["Heading"]).Trim(),
                        //                  Convert.ToString(drv["Tag"]).Trim(),
                        //                  Convert.ToString(drv["Type"]).Trim(),
                        //                  Convert.ToInt32(drv["Order"]),
                        //                  Convert.ToString(drv["datatype"]).Trim(),
                        //                  Convert.ToInt32(drv["width"]));

                        grdTemplateColumn(gridforAllocation,
                      Convert.ToString(drv["Column"]).Trim(),
                      Convert.ToString(drv["Heading"]).Trim(),
                      Convert.ToString(drv["Tag"]).Trim(),
                      Convert.ToString(drv["Type"]).Trim(),
                      Convert.ToInt32(drv["Order"]),
                      Convert.ToString(drv["datatype"]).Trim(),
                      10);

                    }
                    //int grdIndextotCol = gridforAllocation.Columns.Count - 1;
                    //for (int i = grdIndextotCol; 0 <= i; i--)
                    //{
                    //    if (gridforAllocation.Columns[i].AccessibleHeaderText.ToString().Trim().ToUpper() == "REMOVEONLY")
                    //    {
                    //        gridforAllocation.Columns.RemoveAt(i);
                    //    }
                    //}

                    //for (int i = 0; i < gridforAllocation.Rows[0].Cells.Count-1; i++)
                    //{
                    //    gridforAllocation.Rows[0].Cells[i].Width = Unit.Pixel(200);
                    //}


                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + IndEx.Message.Trim());
            }
            catch (Exception IndEx)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + IndEx.Message.Trim());
            }
        }

        private string errorMessage;

        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

      
        public void allocateTxtBox_TextChanged(bool addMode,bool editMode,DataTable tmpMall_vw,DataTable main_vw,Label lblAmount,Label lblTotAlloc,Label lblBalance,decimal thisValue, decimal vchrAmt, decimal oldAllocAmt,CheckBox chkAllocExcess, DataRow tmpMallRows)
        {
            try
            {
                if (thisValue < 0)
                {
                    ErrorMessage = "Allocated amount can not be less than zero..!!!";
                    return;
                }
                decimal vchrBal1 = 0;

                // sum amount
                foreach (DataRow tmpRows in tmpMall_vw.Rows)
                {
                    if (Convert.ToString(tmpRows["entry_ty"]) == Convert.ToString(main_vw.Rows[0]["entry_ty"]) &&
                        Convert.ToInt32(tmpRows["tran_cd"]) == Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                    {
                        vchrBal1 = vchrBal1 + numFunction.toDecimal(tmpRows["new_all"]);
                    }
                    else
                    {
                        vchrBal1 = vchrBal1 + numFunction.toDecimal(tmpRows["new_all"]) + numFunction.toDecimal(tmpRows["tds"]) + numFunction.toDecimal(tmpRows["disc"]);
                    }
                }

                if (vchrAmt < vchrBal1 && thisValue == 0 && chkAllocExcess.Checked == false)
                {
                    ErrorMessage = "Can not allocate more than Transaction Amount..!!!";
                    return;
                }

                if (thisValue > (numFunction.toDecimal(tmpMallRows["balance"]) + oldAllocAmt) &&
                    thisValue != 0)
                {
                    ErrorMessage = "Balance can not be negative \\n The Balance amount is " +
                                   Convert.ToString(numFunction.toDecimal(tmpMallRows["balance"]) + oldAllocAmt).Trim();
                    return;
                }

                tmpMallRows["balance"] = (numFunction.toDecimal(tmpMallRows["net_amt"]) -
                                         (numFunction.toDecimal(tmpMallRows["re_all"]) +
                                          numFunction.toDecimal(tmpMallRows["new_all"]) +
                                          numFunction.toDecimal(tmpMallRows["disc_all"]) +
                                          numFunction.toDecimal(tmpMallRows["tds_all"]) +
                                          numFunction.toDecimal(tmpMallRows["disc"]) +
                                          numFunction.toDecimal(tmpMallRows["tds"])));

                tmpMallRows.AcceptChanges();
                tmpMall_vw.AcceptChanges();

                if (chkAllocExcess.Checked == true)
                {
                    vchrAmt = vchrBal1;
                    VchrAmt = vchrBal1; // Assign value to public variable
                }

                lblAmount.Text = Convert.ToString(vchrAmt);
                lblTotAlloc.Text = Convert.ToString(vchrBal1);
                lblBalance.Text = Convert.ToString(vchrAmt - vchrBal1);
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + IndEx.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in vuAllocationInit Method |" + Ex.Message.Trim());
            }

        }

        public void allocateTxtBox_KeyPress(bool addMode, bool editMode, DataTable tmpMall_vw, DataTable main_vw, Label lblAmount, Label lblTotAlloc, Label lblBalance, decimal thisValue, decimal vchrAmt, CheckBox chkAllocExcess, DataRow tmpMallRows)
        {
            try
            {
                if (addMode == true || editMode == true)
                {
                    decimal vchrBal1 = 0;

                    foreach (DataRow tmpRows in tmpMall_vw.Rows)
                    {
                        tmpRows["new_all"] = 0;
                        tmpRows.AcceptChanges();
                    }

                    tmpMall_vw.AcceptChanges();

                    // sum amount
                    foreach (DataRow tmpRows in tmpMall_vw.Rows)
                    {
                        if (Convert.ToString(tmpRows["entry_ty"]) == Convert.ToString(main_vw.Rows[0]["entry_ty"]) &&
                            Convert.ToInt32(tmpRows["tran_cd"]) == Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                        {
                            vchrBal1 = vchrBal1 + numFunction.toDecimal(tmpRows["new_all"]);
                        }
                        else
                        {
                            vchrBal1 = vchrBal1 + numFunction.toDecimal(tmpRows["new_all"]) + numFunction.toDecimal(tmpRows["tds"]) + numFunction.toDecimal(tmpRows["disc"]);
                        }
                    }

                    if (vchrAmt > vchrBal1 || chkAllocExcess.Checked == true)
                    {
                        decimal amt = 0;
                        amt = numFunction.toDecimal(tmpMallRows["re_all"]) +
                              numFunction.toDecimal(tmpMallRows["disc_all"]) +
                              numFunction.toDecimal(tmpMallRows["tds_all"]) +
                              numFunction.toDecimal(tmpMallRows["disc"]) +
                              numFunction.toDecimal(tmpMallRows["tds"]);

                        if (chkAllocExcess.Checked == true)
                        {
                            tmpMallRows["new_all"] = numFunction.toDecimal(tmpMallRows["net_amt"]) - amt;
                        }
                        else
                        {
                            if ((vchrAmt - vchrBal1) > (numFunction.toDecimal(tmpMallRows["net_amt"]) - amt))
                            {
                                tmpMallRows["new_all"] = numFunction.toDecimal(tmpMallRows["net_amt"]) - amt;
                            }
                            else
                            {
                                tmpMallRows["new_all"] = vchrAmt - vchrBal1;
                            }
                        }

                        tmpMallRows.AcceptChanges();
                        tmpMall_vw.AcceptChanges();

                        // sum amount
                        foreach (DataRow tmpRows in tmpMall_vw.Rows)
                        {
                            if (Convert.ToString(tmpRows["entry_ty"]) == Convert.ToString(main_vw.Rows[0]["entry_ty"]) &&
                                Convert.ToInt32(tmpRows["tran_cd"]) == Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                            {
                                vchrBal1 = vchrBal1 + numFunction.toDecimal(tmpRows["new_all"]);
                            }
                            else
                            {
                                vchrBal1 = numFunction.toDecimal(tmpRows["new_all"]) + numFunction.toDecimal(tmpRows["tds"]) + numFunction.toDecimal(tmpRows["disc"]);
                            }
                        }

                        if (chkAllocExcess.Checked == true)
                        {
                            vchrAmt = vchrBal1;
                            VchrAmt = vchrBal1;
                        }

                        lblAmount.Text = Convert.ToString(vchrAmt);
                        lblTotAlloc.Text = Convert.ToString(vchrBal1);
                        lblBalance.Text = Convert.ToString(vchrAmt - vchrBal1);
                    }
                    else
                    {
                        ErrorMessage = "Balance avaliable for Allocation is 0.00";
                    }
                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in allocateTxtBox_KeyPress Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in allocateTxtBox_KeyPress Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in allocateTxtBox_KeyPress Method |" + IndEx.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in allocateTxtBox_KeyPress Method |" + Ex.Message.Trim());
            }

        }

        public void tdsamtTxtBox_TextChanged(bool addMode, bool editMode, DataTable tmpMall_vw, DataTable main_vw, decimal thisValue, decimal oldTDSAmt,decimal vchrAmt, DataRow tmpMallRows)
        {
            try
            {
                if (addMode == true || editMode == true)
                {
                    if (thisValue < 0)
                    {
                        ErrorMessage = "TDS amount can not be less than zero";
                        return;
                    }

                    if (thisValue > (numFunction.toDecimal(tmpMallRows["balance"]) + oldTDSAmt) &&
                        thisValue != 0)
                    {
                        ErrorMessage = "Balance can not be negative \\n The Balance amount is " +
                                Convert.ToString(numFunction.toDecimal(tmpMallRows["balance"]) + oldTDSAmt).Trim();
                        return;
                    }

                    if (Convert.ToString(tmpMallRows["entry_ty"]).Trim() == Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() &&
                        Convert.ToInt32(tmpMallRows["tran_cd"]) == Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                    {
                        tmpMallRows["balance"] = numFunction.toDecimal(tmpMallRows["net_amt"]) - (numFunction.toDecimal(tmpMallRows["re_all"]) +
                                                                                              numFunction.toDecimal(tmpMallRows["new_all"])) -
                                                                                              (numFunction.toDecimal(tmpMallRows["disc"]) +
                                                                                               numFunction.toDecimal(tmpMallRows["tds"]) +
                                                                                               numFunction.toDecimal(tmpMallRows["disc_all"]) +
                                                                                               numFunction.toDecimal(tmpMallRows["tds_all"]));
                    }
                    else
                    {
                        tmpMallRows["balance"] = numFunction.toDecimal(tmpMallRows["net_amt"]) - (numFunction.toDecimal(tmpMallRows["re_all"]) +
                                                                                              numFunction.toDecimal(tmpMallRows["new_all"]));
                    }
                    tmpMallRows.AcceptChanges();
                    tmpMall_vw.AcceptChanges();
                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in tdsamtTxtBox_TextChanged Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in tdsamtTxtBox_TextChanged Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in tdsamtTxtBox_TextChanged Method |" + IndEx.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in tdsamtTxtBox_TextChanged Method |" + Ex.Message.Trim());
            }

        }


        public void discountTxtBox_TextChanged(bool addMode, bool editMode, DataTable tmpMall_vw, DataTable main_vw, decimal thisValue, decimal oldDiscount, decimal vchrAmt, DataRow tmpMallRows)
        {
            try
            {
                if (addMode == true || editMode == true)
                {
                    if (thisValue > (numFunction.toDecimal(tmpMallRows["balance"]) + oldDiscount) &&
                        thisValue != 0)
                    {
                        ErrorMessage = "Balance can not be negative \\n The Balance amount is " +
                                Convert.ToString(numFunction.toDecimal(tmpMallRows["balance"]) + oldDiscount).Trim();
                        return;
                    }

                    if (Convert.ToString(tmpMallRows["entry_ty"]).Trim() == Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() &&
                        Convert.ToInt32(tmpMallRows["tran_cd"]) == Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                    {
                        tmpMallRows["balance"] = numFunction.toDecimal(tmpMallRows["net_amt"]) - (numFunction.toDecimal(tmpMallRows["re_all"]) +
                                                                                              numFunction.toDecimal(tmpMallRows["new_all"])) -
                                                                                              (numFunction.toDecimal(tmpMallRows["disc"]) +
                                                                                               numFunction.toDecimal(tmpMallRows["tds"]) +
                                                                                               numFunction.toDecimal(tmpMallRows["disc_all"]) +
                                                                                               numFunction.toDecimal(tmpMallRows["tds_all"]));
                    }
                    else
                    {
                        tmpMallRows["balance"] = numFunction.toDecimal(tmpMallRows["net_amt"]) - (numFunction.toDecimal(tmpMallRows["re_all"]) +
                                                                                              numFunction.toDecimal(tmpMallRows["new_all"]));
                    }
                    tmpMallRows.AcceptChanges();
                    tmpMall_vw.AcceptChanges();
                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in discountTxtBox_TextChanged Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in discountTxtBox_TextChanged Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in discountTxtBox_TextChanged Method |" + IndEx.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in discountTxtBox_TextChanged Method |" + Ex.Message.Trim());
            }
        }

        //public GridView grdTemplateColumn(GridView gridforAllocation, string fldName,string headName,string tagName,string colType,int colOrder,string dataType,int colWidth)
        //{
        //    getGridColumn _getGridColumn = new getGridColumn();
        //    TemplateField templateField = new TemplateField();
        //    DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
        //    DynamicTemplate dynamictemplateEdit = new DynamicTemplate(ListItemType.EditItem);

        //    if (colType == "TEMPLATE")
        //    {
        //        //NumericTextBox txtBox = new NumericTextBox();
        //        //txtBox.ID = "txt" + fldName.Trim();
        //        //txtBox.CssClass = "form_textfield3";
        //        //txtBox.Visible = true;
        //        //txtBox.AlignStyle = "RIGHT";
        //        //txtBox.Format = "0.00";
        //        //txtBox.Width = 80;
        //        //txtBox.SelectOnEntry = true;

        //        TextBox txtBox = new TextBox();
        //        txtBox.ID = "txt" + fldName.Trim();
        //        txtBox.CssClass = "form_textfield3";
        //        txtBox.Visible = true;
        //        //txtBox.AlignStyle = "RIGHT";
        //        //txtBox.Format = "0.00";
        //        txtBox.Width = 80;
        //        //txtBox.SelectOnEntry = true;
                
        //        //MethodInfo method = typeof(A).GetMethod("num_TextChanged", BindingFlags.NonPublic | BindingFlags.Instance);
        //        //Type type = typeof(EventHandler);
        //        //Delegate handler = Delegate.CreateDelegate(type, this, method);
        //        //EventInfo evt = txtBox.GetType().GetEvent("TextChanged");
        //        //evt.AddEventHandler(txtBox, handler);
        //           //txtBox.TextChanged += new System.EventHandler(this.numText_Changed);    

        //        //Type type = GetType(myPage);
        //        //MethodInfo method = type.GetMethod("num_TextChanged", BindingFlags.NonPublic | BindingFlags.Instance);
        //        //Delegate handler = Delegate.CreateDelegate(type, this, method);
        //        //EventInfo evt = txtBox.GetType().GetEvent("TextChanged");
        //        //evt.AddEventHandler(txtBox, handler);

        //        dynamictemplateItem.AddControl(txtBox, "Text", fldName);
        //        templateField.ItemTemplate = dynamictemplateItem;
        //        templateField.HeaderText = headName.Trim();
        //        templateField.AccessibleHeaderText = tagName.Trim().ToUpper();
        //        templateField.ItemStyle.BackColor = System.Drawing.Color.WhiteSmoke; 
        //        gridforAllocation.Columns.Insert(colOrder, templateField);
        //    }
        //    else
        //    {
        //        Label lblText = new Label();
        //        lblText.ID = "lbl" + fldName.Trim();
        //        lblText.Visible = true;
        //        lblText.Width = colWidth; 
        //        dynamictemplateItem.AddControl(lblText, "Text", fldName);
        //        templateField.ItemTemplate = dynamictemplateItem;
        //        templateField.HeaderText = headName.Trim();
        //        templateField.AccessibleHeaderText = tagName.Trim().ToUpper();
        //        switch (dataType.Trim().ToUpper())
        //        {
        //            case "STRING":
        //            case "DATE":
        //                templateField.ItemStyle.HorizontalAlign = HorizontalAlign.Left;
        //                break;
        //            case "DECIMAL":
        //                templateField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
        //                break;
        //        }
        //        gridforAllocation.Columns.Insert(colOrder, templateField);
        //        //bndField = new BoundField();
        //        //bndField = _getGridColumn.grdBoundField(bndField, fldName ,headName);
        //        //bndField.AccessibleHeaderText = tagName.Trim().ToUpper();
        //        //switch (dataType.Trim().ToUpper())
        //        //{
        //        //    case "DECIMAL":
        //        //        bndField.HtmlEncode = false;  
        //        //        bndField.DataFormatString = "{0:F2}";
        //        //        bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
        //        //        break;
        //        //    case "DATE":
        //        //        bndField.HtmlEncode = false;  
        //        //        bndField.DataFormatString = "{0:dd-M-yyyy}";
        //        //        break;
        //        //    default :
        //        //        bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Left;
        //        //        break; 
        //        //}
        //        //bndField.HtmlEncode = true;
        //        //bndField.ItemStyle.Width = Unit.Pixel(200);
        //        //bndField.HeaderStyle.Width = Unit.Pixel(200);
        //        //gridforAllocation.Columns.Insert(colOrder, bndField);
        //        //grdItem.Columns[0].ItemStyle.Width = 10;

        //    }

       
            
        //    return gridforAllocation; 

        //}

        //public event EventHandler TextChanged;
        public void grdTemplateColumn(GridView grdAllocation, string fldName, string headName, string tagName, string colType, int colOrder, string dataType, int colWidth)
        {
            try
            {
                TemplateField templateField = new TemplateField();
                DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);

                if (colType == "TEMPLATE")
                {
                    NumericTextBox txtBox = new NumericTextBox();
                    txtBox.ID = "txt" + fldName.Trim();
                    txtBox.CssClass = "form_textAllocation";
                    txtBox.Visible = true;
                    txtBox.AlignStyle = "RIGHT";
                    txtBox.Format = "0.00";
                    txtBox.Width = 80;
                    txtBox.SelectOnEntry = false;
                    dynamictemplateItem.AddControl(txtBox, "Text", fldName);
                    templateField.ItemTemplate = dynamictemplateItem;
                    templateField.HeaderText = headName.Trim();
                    templateField.AccessibleHeaderText = tagName.Trim().ToUpper();
                    templateField.ItemStyle.BackColor = System.Drawing.Color.WhiteSmoke;

                    grdAllocation.Columns.Add(templateField);

                    //grdAllocation.Columns.Insert(colOrder, templateField);
                }
                else
                {
                    Label lblText = new Label();
                    lblText.ID = "lbl" + fldName.Trim();
                    lblText.Visible = true;
                    lblText.Width = colWidth;
                    lblText.Font.Size = 7;
                    dynamictemplateItem.AddControl(lblText, "Text", fldName);
                    templateField.ItemTemplate = dynamictemplateItem;
                    templateField.HeaderText = headName.Trim();
                    templateField.AccessibleHeaderText = tagName.Trim().ToUpper();

                    switch (dataType.Trim().ToUpper())
                    {
                        case "STRING":
                        case "DATE":
                            templateField.ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                            break;
                        case "DECIMAL":
                            templateField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            break;
                    }
                    //grdAllocation.Columns.Insert(colOrder, templateField);
                    grdAllocation.Columns.Add(templateField);
                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in grdTemplateColumn Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in grdTemplateColumn Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in grdTemplateColumn Method |" + IndEx.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in grdTemplateColumn Method |" + Ex.Message.Trim());
            }
        }
        public void AfterCloseAllocationWindow(bool addMode, 
                        bool editMode, 
                        string pcvType, 
                        DataTable main_vw, 
                        DataTable item_vw, 
                        DataTable lcode_vw, 
                        DataTable acdet_vw, 
                        DataTable tmpMall_vw, 
                        DataTable mall_vw, 
                        decimal vchrBal, 
                        decimal oTds, 
                        decimal oDisc, 
                        DataRow acDetRow, 
                        DataTable Company)
        {
            try
            {
                vuAccountPosting accountPosting = new vuAccountPosting();
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                if (vchrBal != 0)
                {
                    main_vw.Rows[0]["net_amt"] = vchrBal;
                    main_vw.AcceptChanges();
                    accountPosting.defaacposting(main_vw, lcode_vw, item_vw, acdet_vw,null,ref connHandle);
                }

                // Call Auto allocate Method

                autoAllocate(addMode, editMode, tmpMall_vw, mall_vw, pcvType, acDetRow, main_vw, Company, lcode_vw, true);

                decimal new_tot = 0;
                decimal tds_tot = 0;
                decimal disc_tot = 0;

                new_tot = (decimal)tmpMall_vw.Compute("SUM(new_all)", "entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                                                    " tran_cd = " + Convert.ToString(main_vw.Rows[0]["tran_cd"]).Trim());
                tds_tot = (decimal)tmpMall_vw.Compute("SUM(tds)", "entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                                                    " tran_cd = " + Convert.ToString(main_vw.Rows[0]["tran_cd"]).Trim());
                disc_tot = (decimal)tmpMall_vw.Compute("SUM(disc)", "entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                                                    " tran_cd = " + Convert.ToString(main_vw.Rows[0]["tran_cd"]).Trim());

                tds_tot = new_tot <= 0 ? 0 : tds_tot;
                disc_tot = disc_tot <= 0 ? 0 : disc_tot;

                if (oTds != 0 || oDisc != 0 || tds_tot != 0 || disc_tot != 0)
                {
                    string lcnamePay = "TAX DEDUCTED AT SOURCE (PAYABLE)";
                    string lcnameRec = "TAX DEDUCTED AT SOURCE (RECEIVABLE)";
                    string lcName1 = "";
                    string lcName2 = "";
                    int lcName1i = 0;
                    int lcName2i = 0;

                    if (oTds != 0 || tds_tot != 0) // for TDS
                    {
                        string sqlStr = " select top 1 tds_accoun from ac_mast where ac_name = '" + Convert.ToString(acDetRow["ac_name"]).Trim() + "'";
                        DataTable tmpTbl_vw = DataAcess.ExecuteDataTable(sqlStr, "tmpTbl_vw",connHandle);
                        DataAcess.Connclose(connHandle);

                        if (Convert.ToString(tmpTbl_vw.Rows[0]["tds_accoun"]).Trim() != "")
                        {
                            lcName1 = accountPosting.findAccountName(Convert.ToString(tmpTbl_vw.Rows[0]["tds_accoun"]).Trim(), main_vw, item_vw,ref connHandle);
                        }

                        if (Convert.ToString(acDetRow["amt_ty"]).Trim() == "DR")
                        {
                            lcName1 = lcName1.Trim() != "" ? lcName1 : lcnamePay;
                        }
                        else
                        {
                            lcName1 = lcName1.Trim() != "" ? lcName1 : lcnameRec;
                        }

                        lcName1 = lcName1.PadLeft(Convert.ToString(acDetRow["ac_name"]).Length, ' ');

                        sqlStr = " select top 1 ac_id,ac_name from ac_mast where ac_name = '" + lcName1.Trim() + "'";
                        tmpTbl_vw = DataAcess.ExecuteDataTable(sqlStr, "tmpTbl_vw",connHandle);
                        DataAcess.Connclose(connHandle);

                        if (tmpTbl_vw.Rows.Count > 0)
                        {
                            lcName1i = Convert.ToInt32(tmpTbl_vw.Rows[0]["ac_id"]);
                        }

                        if (lcName1i == 0)
                        {
                            ErrorMessage = " " + lcName1.Trim() + " A/c not found..!!!";
                        }
                    }

                    if (oDisc != 0 || disc_tot != 0) // for Discount
                    {
                        string sqlStr = " select top 1 disc_ac from ac_mast where ac_name = '" + Convert.ToString(acDetRow["ac_name"]).Trim() + "'";
                        DataTable tmpTbl_vw = DataAcess.ExecuteDataTable(sqlStr, "tmpTbl_vw",connHandle);
                        DataAcess.Connclose(connHandle);
                        if (Convert.ToString(tmpTbl_vw.Rows[0]["disc_ac"]).Trim() != "")
                        {
                            lcName2 = accountPosting.findAccountName(Convert.ToString(tmpTbl_vw.Rows[0]["disc_ac"]).Trim(), main_vw, item_vw,ref connHandle);
                        }

                        lcName2 = lcName2.Trim() != "" ? lcName2 : "DISCOUNT (BILLS)";
                        lcName2 = lcName2.PadLeft(Convert.ToString(acDetRow["ac_name"]).Length, ' ');

                        sqlStr = " select top 1 ac_id,ac_name from ac_mast where ac_name = '" + lcName2.Trim() + "'";

                        tmpTbl_vw = DataAcess.ExecuteDataTable(sqlStr, "tmpTbl_vw",connHandle);
                        DataAcess.Connclose(connHandle);

                        if (tmpTbl_vw.Rows.Count > 0)
                        {
                            lcName2i = Convert.ToInt32(tmpTbl_vw.Rows[0]["ac_id"]);
                        }

                        if (lcName2i == 0)
                        {
                            ErrorMessage = " " + lcName2.Trim() + " A/c not found..!!!";
                        }
                    }

                    if ((oTds != 0 || tds_tot != 0) || (oDisc != 0 || disc_tot != 0))
                    {
                        acDetRow["Amount"] = numFunction.toDecimal(acDetRow["Amount"]) +
                                             tds_tot + disc_tot - (oTds + oDisc);
                        string lc_effect = Convert.ToString(acDetRow["amt_ty"]);

                        if (numFunction.toDecimal(acDetRow["Amount"]) < 0)
                        {
                            acDetRow["Amount"] = Math.Abs(numFunction.toDecimal(acDetRow["Amount"]));
                            acDetRow["Amt_ty"] = Convert.ToString(acDetRow["Amt_ty"]).Trim() == "DR" ? "CR" : "DR";
                        }

                        //for TDS
                        if ((oTds != 0 || tds_tot != 0) && lcName1.Trim() != "" && lcName1i != 0)
                        {
                            decimal lnSum = tds_tot - oTds;
                            try
                            {
                                DataRow SearchRow = acdet_vw.Select("Ac_name = '" + lcName1.Trim() + "'")[0];
                                SearchRow["Amount"] = numFunction.toDecimal(SearchRow["Amount"]) +
                                    Convert.ToString(SearchRow["Amt_Ty"]).Trim() != lc_effect.Trim() ? lnSum : -lnSum;

                                if (numFunction.toDecimal(SearchRow["Amount"]) < 0)
                                {
                                    SearchRow["Amount"] = Math.Abs(numFunction.toDecimal(SearchRow["Amount"]));
                                    SearchRow["Amt_Ty"] = Convert.ToString(SearchRow["Amt_ty"]) == "DR" ? "CR" : "DR";
                                }

                                SearchRow.AcceptChanges();
                            }
                            catch
                            {
                                accountPosting.addtoEffect(acdet_vw, main_vw, lnSum, lnSum > 0 && lc_effect == "DR" ? "CR" : "DR", lcName1, lcName1i);
                            }
                        }

                        //for Discount
                        if ((oDisc != 0 || disc_tot != 0) && lcName2.Trim() != "" && lcName2i != 0)
                        {
                            decimal lnSum = disc_tot - oDisc;
                            try
                            {
                                DataRow SearchRow = acdet_vw.Select("Ac_name = '" + lcName2.Trim() + "'")[0];
                                SearchRow["Amount"] = numFunction.toDecimal(SearchRow["Amount"]) +
                                    Convert.ToString(SearchRow["Amt_Ty"]).Trim() != lc_effect.Trim() ? lnSum : -lnSum;

                                if (numFunction.toDecimal(SearchRow["Amount"]) < 0)
                                {
                                    SearchRow["Amount"] = Math.Abs(numFunction.toDecimal(SearchRow["Amount"]));
                                    SearchRow["Amt_Ty"] = Convert.ToString(SearchRow["Amt_ty"]) == "DR" ? "CR" : "DR";
                                }

                                SearchRow.AcceptChanges();
                            }
                            catch
                            {
                                accountPosting.addtoEffect(acdet_vw, main_vw, lnSum, lnSum > 0 && lc_effect == "DR" ? "CR" : "DR", lcName2, lcName2i);
                            }
                        }

                        vuCheckDbCrBalance CheckDbCrBalance = new vuCheckDbCrBalance();
                        string WarningMess = CheckDbCrBalance.DbCrBalanceCheck(acdet_vw, true);
                        if (WarningMess != "")
                             throw new Exception(WarningMess);

                        acDetRow.AcceptChanges();
                        acdet_vw.AcceptChanges();

                        DataAcess.Connclose(connHandle);
                    }
                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in AfterCloseAllocationWindow Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in AfterCloseAllocationWindow Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in AfterCloseAllocationWindow Method |" + IndEx.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in AfterCloseAllocationWindow Method |" + Ex.Message.Trim());
            }
        }


        #region allocation grid
        public void GenerateBoundColumns(GridView gridforAllocation)
        {
            gridforAllocation.Columns.Clear();
            for (int i = 0; i < 28; i++)
            {
                BoundField bndField = new BoundField();
                bndField.AccessibleHeaderText = "RemoveOnly";
                gridforAllocation.Columns.Add(bndField);
            }
        }

        public void vuAllocationGridInit(GridView gridforAllocation, 
                                    DataTable tmpAll_vw, 
                                    DataTable main_vw, 
                                    CheckBox chkAllocExcess, 
                                    string pcvType, 
                                    bool addMode, 
                                    bool editMode, 
                                    bool ChargesPage,
                                    decimal vAmt, 
                                    Label lblAmount, 
                                    Label lblTotAlloc, 
                                    Label lblBalance,
                                    bool isDeleteColumn)
        {
            try
            {
                if (addMode == true || editMode == true)
                {
                    if (vAmt == 0)
                    {
                        chkAllocExcess.Checked = true;
                    }
                    else
                    {
                        chkAllocExcess.Checked = true;
                    }

                    decimal sumAmt1 = 0;
                    decimal sumAmt2 = 0;
                    decimal fromAcAmt = 0;
                    //decimal vchrAmt = 0;
                    bool deptFound = false;
                    foreach (DataRow tmpRow in tmpAll_vw.Rows)
                    {
                        if (Convert.ToString(tmpRow["dept"]).Trim() != "")
                        {
                            deptFound = true;
                        }
                    }

                    foreach (DataRow tmpRow in tmpAll_vw.Rows)
                    {
                        if (Convert.ToString(tmpRow["entry_ty"]) != Convert.ToString(main_vw.Rows[0]["Entry_ty"]).Trim() &&
                            Convert.ToInt32(tmpRow["tran_cd"]) != Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                        {
                            sumAmt1 = sumAmt1 + (numFunction.toDecimal(tmpRow["new_all"]) + numFunction.toDecimal(tmpRow["tds"]) + numFunction.toDecimal(tmpRow["disc"]));
                        }

                        if (Convert.ToString(tmpRow["entry_ty"]) != Convert.ToString(main_vw.Rows[0]["Entry_ty"]).Trim() &&
                            Convert.ToInt32(tmpRow["tran_cd"]) != Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                        {
                            sumAmt2 = sumAmt2 + (numFunction.toDecimal(tmpRow["new_all"]) + numFunction.toDecimal(tmpRow["tds"]) + numFunction.toDecimal(tmpRow["disc"]));
                        }
                    }

                    FromAcAmt = vAmt - sumAmt2;

                    if (chkAllocExcess.Checked == true)
                    {
                        VchrAmt = sumAmt1;

                    }
                    else
                    {
                        VchrAmt = FromAcAmt;
                    }

                    lblAmount.Text = Convert.ToString(vchrAmt).Trim();
                    lblTotAlloc.Text = Convert.ToString(sumAmt1).Trim();
                    lblBalance.Text = Convert.ToString(vchrAmt - sumAmt2).Trim();

                    // uday
                    DataTable gridColGen = new DataTable("grdGen");
                    DataColumn gridCol = new DataColumn();

                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Column";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Heading";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Tag";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "Type";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.Int32");
                    gridCol.ColumnName = "Order";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.String");
                    gridCol.ColumnName = "DataType";
                    gridColGen.Columns.Add(gridCol);

                    gridCol = new DataColumn();
                    gridCol.DataType = Type.GetType("System.Int32");
                    gridCol.ColumnName = "Width";
                    gridColGen.Columns.Add(gridCol);

                    AddRowInGridColGen(gridColGen, "new_all", "Allocate", "ALLOCATING", "TEMPLATE", 1, "DECIMAL", 100);  // 1
                    AddRowInGridColGen(gridColGen, "", "Type", "INVTYPE", "BOUND", 2, "STRING", 0); //5
                    AddRowInGridColGen(gridColGen, "v_inv_no", "Bill.No.", "BILLNO", "BOUND", 3, "STRING", 80); // 6
                    AddRowInGridColGen(gridColGen, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 4, "DATE", 80); // 7
                    AddRowInGridColGen(gridColGen, "net_amt", "Inv.Amt.", "INVAMT", "BOUND", 5, "DECIMAL", 80);  // 2
                    AddRowInGridColGen(gridColGen, "re_all", "Allocated", "ALLOCATED", "BOUND", 6, "DECIMAL", 80); // 3
                    AddRowInGridColGen(gridColGen, "balance", "Balance", "BALANCE", "BOUND", 7, "DECIMAL", 80); // 4
                    if (deptFound == true)
                    {
                        AddRowInGridColGen(gridColGen, "dept", "Department", "DEPT", "BOUND", 8, "STRING", 100); // 15                        
                    }

                    if (ChargesPage == true)
                    {
                        AddRowInGridColGen(gridColGen, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 9, "DECIMAL", 80); // 8
                        AddRowInGridColGen(gridColGen, "tds_all", "TDS given", "TDSOLD", "BOUND", 10, "DECIMAL", 80); // 9
                        AddRowInGridColGen(gridColGen, "disc", "Discount", "DISCAMT", "TEMPLATE", 11, "DECIMAL", 80); // 10
                        AddRowInGridColGen(gridColGen, "disc_all", "Disc.given", "DISCOLD", "BOUND", 12, "DECIMAL", 80); // 11
                    }
                    AddRowInGridColGen(gridColGen, "l_yn", "Year    ", "INVYEAR", "BOUND", 13, "STRING", 80); // 14
                    AddRowInGridColGen(gridColGen, "inv_sr", "Inv.Series", "INVSERIES", "BOUND", 14, "STRING", 100); // 12
                    AddRowInGridColGen(gridColGen, "inv_no", "Inv.No.", "INVNO", "BOUND", 15, "STRING", 80); // 13

                    DataView grdGenvw = gridColGen.DefaultView;
                    grdGenvw.Sort = "Order ASC";

                    if (isDeleteColumn == true)
                    {
                        gridforAllocation.Columns.Clear();
                    }

                    foreach (DataRowView drv in grdGenvw)
                    {
                        grdTemplateColumn(gridforAllocation,
                                          Convert.ToString(drv["Column"]).Trim(),
                                          Convert.ToString(drv["Heading"]).Trim(),
                                          Convert.ToString(drv["Tag"]).Trim(),
                                          Convert.ToString(drv["Type"]).Trim(),
                                          Convert.ToInt32(drv["Order"]),
                                          Convert.ToString(drv["datatype"]).Trim(),
                                          Convert.ToInt32(drv["width"]));
                    }

                    TemplateField templateField = new TemplateField();
                    DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
                    Button btnforAllocate = new Button();
                    btnforAllocate.ID = "btnAlloc";
                    btnforAllocate.Width = 50;
                    btnforAllocate.Height = 18;
                    btnforAllocate.Visible = true;
                    btnforAllocate.Text = "Allocate";
                    //btnforAllocate.CssClass = "AllocButton";
                    btnforAllocate.CommandName = "SELECT";
                    dynamictemplateItem.AddControl(btnforAllocate, "Text", "");
                    templateField.ItemTemplate = dynamictemplateItem;
                    gridforAllocation.Columns.Insert(0, templateField);

                    VAmt = vAmt; // pass value to parent class 
                }
            }
            catch (DataException DataEx)
            {
                throw new Exception("ERROR found in vuAllocationGridInit Method |" + DataEx.Message.Trim());
            }
            catch (NullReferenceException NullEx)
            {
                throw new Exception("ERROR found in vuAllocationGridInit Method |" + NullEx.Message.Trim());
            }
            catch (IndexOutOfRangeException IndEx)
            {
                throw new Exception("ERROR found in vuAllocationGridInit Method |" + IndEx.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in vuAllocationGridInit Method |" + Ex.Message.Trim());
            }

        }


        protected DataTable AddRowInGridColGen(DataTable table,
                                          string fldName,
                                          string headName,
                                          string tagName,
                                          string colType,
                                          int colOrder, 
                                          string dataType, 
                                          int colWidth)
        {
            try
            {
                DataRow row = table.NewRow();
                row["column"] = fldName.Trim();
                row["heading"] = headName.Trim();
                row["tag"] = tagName.Trim();
                row["type"] = colType.Trim();
                row["order"] = colOrder;
                row["dataType"] = dataType.Trim();
                row["width"] = colWidth;
                table.Rows.Add(row);

                return table;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }                                          
        #endregion

    }
}
