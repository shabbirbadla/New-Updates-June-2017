using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data; 
using System.Web.UI.WebControls;
using Data.Acess.Layer;


namespace Business.Logic.Layer
{
    public class vouFillDropdownList
    {
        public vouFillDropdownList()
        {
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        public DropDownList fillDropDownList(DropDownList cboList,string caption,string SqlStr,string tblName,string DataValueField,string DataTextField)
        {
            DataSet DS = new DataSet();
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

 
            DS = _datatier.ExecuteDataset(SqlStr, tblName,connHandle);
            _datatier.Connclose(connHandle);
            cboList.DataSource = DS.Tables[tblName];
            cboList.DataTextField = DataTextField.ToString();
            cboList.DataValueField = DataValueField.ToString();
            cboList.DataBind();

            if (caption.ToString().Trim() != "")
            {
                cboList.Items.Insert(0, caption.ToString().Trim());
            }
            else
            {
                cboList.Items.Insert(0, "--Select--");
            }

            DS.Clear();
            DS.Dispose();
            return cboList; 
        }

        public DropDownList fillDropDownList(DropDownList cboList,string caption, string DataValueField, string DataTextField, string tblName,string fldName,string Cond)
        {
            DataSet DS = new DataSet();
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            string SqlStr = "";
            if (Cond.ToString() != "")
            {
                SqlStr = "select ltrim(rtrim(" + fldName.ToString().Trim() + ")) as " + fldName.ToString().Trim() + " from " + tblName.ToString().Trim() + 
                                " where " + Cond.ToString().Trim() + " order by " + fldName.ToString().Trim(); 
            }
            else
            {
                SqlStr = "select ltrim(rtrim(" + fldName.ToString().Trim() + ")) as " + fldName.ToString().Trim() + " from " + tblName.ToString().Trim() + 
                                " order by " + fldName.ToString().Trim();
            }


            DS = _datatier.ExecuteDataset(SqlStr, tblName,connHandle);
            _datatier.Connclose(connHandle);
            cboList.DataSource = DS.Tables[tblName];
            cboList.DataTextField = DataTextField.ToString();
            cboList.DataValueField = DataValueField.ToString();
            cboList.DataBind();
            DS.Dispose();

            if (caption.ToString().Trim() != "")
            {
                cboList.Items.Insert(0, caption.ToString().Trim());
            }
            else
            {
                cboList.Items.Insert(0, "--Select--");
            }

            return cboList; 
        }


        public DropDownList fillDropDownList(DropDownList cboList, string caption, string DataValueField, string DataTextField, string fillType, string pcvType, string beHave, DataTable lcode_vw, string fldName, int mainvw_acid, string Vchkprod)
        {
            DataSet DS = new DataSet();
            DS = listinit(fillType, pcvType, beHave, lcode_vw, fldName, mainvw_acid,Vchkprod);
            cboList.DataSource = DS.Tables["_qrytbl"];
            cboList.DataTextField = DataTextField.ToString();
            cboList.DataValueField = DataValueField.ToString();
            cboList.DataBind();

            if (caption.ToString().Trim() != "")
            {
                cboList.Items.Insert(0, caption.ToString().Trim());
            }
            else
            {
                cboList.Items.Insert(0, "--Select--");
            }

            return cboList; 
        }


        private DataSet listinit(string fillType, 
                    string pcvType, 
                    string beHave, 
                    DataTable lcode_vw, 
                    string fldName, 
                    int mainvw_acid, 
                    string Vchkprod)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
            DataSet DS = new DataSet();
            stringFunction StrFunction = new stringFunction();
            string SqlStr = "";
            switch (fillType.ToString().Trim())
            {
                case "ACCOUNT":
                    SqlStr = "select ac_name,ac_id from ac_mast where rtrim(ltrim(upper([Group]))) != '' " +
                             "order by ac_name ";
                    DS = _datatier.ExecuteDataset(SqlStr, "_qrytbl",connHandle);
                    _datatier.Connclose(connHandle);
                    DataRow getNewRow;
                    getNewRow = DS.Tables["_qrytbl"].NewRow();
                    getNewRow["ac_name"] = "";
                    DS.Tables["_qrytbl"].Rows.Add(getNewRow);
                    DS.Tables["_qrytbl"].AcceptChanges();  
                    break;
                case "PARTY" :
                    SqlStr = "EXECUTE USP_ENT_GET_ACGROUP '" + Convert.ToString(lcode_vw.Rows[0]["defa_group"]) + "'";
                    SqlDataReader dr = _datatier.ExecuteDataReader(SqlStr,ref connHandle);
                    string grpId = "";
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            grpId += grpId + "," + Convert.ToString(dr["ac_group_id"]).Trim(); 
                        }
                    }
                    dr.Close();
                    dr.Dispose();
                    _datatier.Connclose(connHandle);
                    grpId = grpId.Substring(1);

                    string SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) != '' Or Ac_name Like '%CANCELLED%')";
                     
                    if (Vchkprod.IndexOf("vutex") >=0 && 
                        (StrFunction.InList(pcvType.Trim(),new string[] {"DC","AR","SS","IR","SR"}) == true ||
                         StrFunction.InList(beHave.Trim(),new string[] {"DC","AR","SS","IR","SR"}) == true))
                    {
                        if (grpId.Length <= 1)
                        {
                            SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";
                        }
                        else
                        {
                            if (StrFunction.InList(pcvType.Trim(), new string[] { "DC", "SS", "IR", "SR" }) == true ||
                                StrFunction.InList(beHave.Trim(), new string[] { "DC", "SS", "IR", "SR" }) == true)
                                SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'SUNDRY DEBTORS')";
                            else
                                if (StrFunction.InList(pcvType.Trim(), new string[] { "AR" }) == true ||
                                    StrFunction.InList(beHave.Trim(), new string[] { "AR" }) == true)
                                    SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'SUNDRY CREDITORS')";
                        }
                    }
                    else
                    {
                        if (grpId.Length <=1)
                        {
                          if (StrFunction.InList(pcvType.Trim(), new string[] { "CR", "CP" }) == true ||
                                StrFunction.InList(beHave.Trim(), new string[] { "CR", "CP" }) == true)
                                SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                            else
                                if (StrFunction.InList(pcvType.Trim(), new string[] { "BR","BP","BI","RR","FP","FR","DP","DR"}) == true ||
                                    StrFunction.InList(beHave.Trim(), new string[] { "BR","BP","BI","RR","FP","FR","DP","DR" }) == true)
                                    SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'BANK')";
                                else
                                    if (StrFunction.InList(pcvType.Trim(), new string[] { "RP"}) == true ||
                                        StrFunction.InList(beHave.Trim(), new string[] { "RP"}) == true)
                                        SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'CASH & BANK BALANCES' Or " +
						                          " RTRIM(LTRIM(UPPER(Typ))) = 'BANK' Or " +
						                          " RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                        }
                        else
                        {
                          if (StrFunction.InList(pcvType.Trim(), new string[] { "CR", "CP" }) == true ||
                                StrFunction.InList(beHave.Trim(), new string[] { "CR", "CP" }) == true)
                                SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                            else
                            {
                                if (StrFunction.InList(pcvType.Trim(), new string[] { "BR","BP","BI","RR","FP","FR","DP","DR"}) == true ||
                                    StrFunction.InList(beHave.Trim(), new string[] { "BR","BP","BI","RR","FP","FR","DP","DR" }) == true)
                                    SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'BANK')";
                                else
                                    if (StrFunction.InList(pcvType.Trim(), new string[] { "RP"}) == true ||
                                        StrFunction.InList(beHave.Trim(), new string[] { "RP"}) == true)
                                        SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'CASH & BANK BALANCES' Or " +
						                          " RTRIM(LTRIM(UPPER(Typ))) = 'BANK' Or " +
						                          " RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                                    else
                                        if (StrFunction.InList(pcvType.Trim(), new string[] { "ST","PT","DC","AC","II","IR","ES","SS","IP","OP","JV","SQ","SO","PO","SR","PR","SB"}) == true ||
                                            StrFunction.InList(beHave.Trim(), new string[] { "ST","PT","DC","AC","II","IR","ES","SS","IP","OP","JV","SQ","SO","PO","SR","PR","SB" }) == true)
                                            SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";
                                        else
                                            if (StrFunction.InList(pcvType.Trim(), new string[] { "BR","BP","CR","CP","BI","RP","RR","FP","FR","DP","DR","GI","GR","HI","HR","LI","IL","LR","RL"}) == true ||
                                                StrFunction.InList(beHave.Trim(), new string[] { "BR","BP","CR","CP","BI","RP","RR","FP","FR","DP","DR","GI","GR","HI","HR","LI","IL","LR","RL" }) == true)
                                                SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";
                                            else
                                                if (StrFunction.InList(pcvType.Trim(), new string[] { "PC", "DN","CN","EP" }) == true ||
                                                    StrFunction.InList(beHave.Trim(), new string[] { "PC", "DN","CN","EP" }) == true)
                                                    SqlCond = "(ac_group_id in (" + grpId + "))";
                                                else
                                                    if (StrFunction.InList(pcvType.Trim(), new string[] { "OB", "OS"}) == true ||
                                                        StrFunction.InList(beHave.Trim(), new string[] { "OB", "OS" }) == true)
                                                        SqlCond = "(ac_group_id in (" + grpId + ") And Ac_name Not Like '%CANCELLED%')";
                                                    else
                                                        SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";

                                }
                            }
                        }
                        //+ " And (ldeactive = 0 Or (ldeactive = 1 And deactfrom > '" + dateFormat.TodateTime(mainvw_date) + "'))";
                        SqlStr = "select " + fldName.ToString().Trim() + " from ac_mast where " +
                                 SqlCond + " order by ac_name ";
                        DS = _datatier.ExecuteDataset(SqlStr, "_qrytbl",connHandle);
                        _datatier.Connclose(connHandle);
                        break;
                case "ITEM":
                    #region "Retrive data for Item"
                    string sql_tbl, sql_cond, sql_var,sql_var1 = "";
                    int mRate_Level = 0;
                    sql_cond = "";
                    sql_tbl = "it_mast";
                    sql_var = System.Convert.ToString(lcode_vw.Rows[0]["item_type"]).ToUpper().Trim();
                    if (sql_var.ToString().Trim() != "")
                    {
                        sql_var = "#" + sql_var.Replace(",", "#,#") + "#";
                    }

                    if (System.Convert.DBNull.Equals(lcode_vw.Rows[0]["it_rate"]) == false)
                    {
                        if (System.Convert.ToBoolean(lcode_vw.Rows[0]["it_rate"]) == true)
                        {
                            SqlDataReader DR;
                            SqlStr = "select top 1 rate_level from ac_mast where ac_id = " + mainvw_acid.ToString();
                            DR =_datatier.ExecuteDataReader(SqlStr,ref connHandle);
                            if (DR.HasRows == true)
                            {
                                mRate_Level = System.Convert.ToInt32(DR["rate_level"]);
                            }

                            if (mRate_Level != 0)
                            {
                                sql_cond = sql_cond + " and it_mast.it_code = it_rate.it_code and it_rate.rlevel = " + mRate_Level.ToString();
                            }
                            else
                            {
                                sql_cond = sql_cond + " and it_mast.it_code = it_rate.it_code and it_rate.ac_id = " + mainvw_acid.ToString();
                            }
                            DR.Close();
                            DR.Dispose();
                            _datatier.Connclose(connHandle); 
                        }
                     
                    }

                    if (sql_var.IndexOf("#") >= 0)
                    {
                        if (sql_cond.Trim() == "")
                        {
                            sql_cond = " ('" + sql_var.ToString().Trim() + "' Like '%#'+RTRIM(LTRIM(UPPER(It_mast.[Type])))+'#%')";
                        }
                        else
                        {
                            sql_cond = sql_cond + " and ('" + sql_var.ToString().Trim() + "' Like '%#'+RTRIM(LTRIM(UPPER(It_mast.[Type])))+'#%')";
                        }

                    }

                    sql_var1 = System.Convert.ToString(lcode_vw.Rows[0]["item_group"]).ToUpper().Trim();

                    if (sql_var1.ToString().Trim() != "")
                    {
                        sql_var1 = "#" + sql_var1.Replace(",", "#,#") + "#";
                    }

                    if (sql_var1.IndexOf("#") >= 0)
                    {
                        if (sql_cond.Trim() == "")
                        {
                            sql_cond = " ('" + sql_var1.ToString().Trim() + "' like '%#'+rtrim(ltrim(upper(it_mast.[Group])))+'#%'";
                        }
                        else
                        {
                            sql_cond = sql_cond + " and ('" + sql_var1.ToString().Trim() + "' like '%#'+rtrim(ltrim(upper(it_mast.[Group])))+'#%'";
                        }
                    }

                    if (sql_cond.Trim() != "")
                    {
                        SqlStr = "select " + fldName.ToString().Trim() + " from " + sql_tbl.ToString().Trim() +
                                 " where " + sql_cond.ToString().Trim() + " order by it_mast.it_name ";
                    }
                    else
                        SqlStr = "select " + fldName.ToString().Trim() + " from " + sql_tbl.ToString().Trim() +
                                 " order by it_mast.it_name ";


                    DS = _datatier.ExecuteDataset(SqlStr, "_qrytbl",connHandle);
                    _datatier.Connclose(connHandle);
                    break; 
                    #endregion


            }
            return DS;
  
        }

        // Below method using for GetPOP

        public DataView listinit(string fillType,
            string pcvType,
            string beHave,
            DataTable lcode_vw,
            string[,] fldName,
            int mainvw_acid,
            string Vchkprod)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
            DataView retView = new DataView();
            stringFunction StrFunction = new stringFunction();
            string SqlStr = "";
            string fldList = "";
            switch (fillType.ToString().Trim())
            {
                case "ACCOUNT":
                    SqlStr = "select ac_name,ac_id from ac_mast where rtrim(ltrim(upper([Group]))) != '' " +
                             "order by ac_name ";
                    retView = _datatier.ExecuteDataTable(SqlStr, "_qrytbl",connHandle).DefaultView;
                    _datatier.Connclose(connHandle);
                    //DataRowView getNewRow;
                    //getNewRow = retView.AddNew(); 
                    //getNewRow["ac_name"] = "";
                    //retView.Table.Rows.Add(getNewRow);
                    //retView.Table.AcceptChanges();  
                    break;
                case "PARTY":
                    SqlStr = "EXECUTE USP_ENT_GET_ACGROUP '" + Convert.ToString(lcode_vw.Rows[0]["defa_group"]) + "'";
                    SqlDataReader dr = _datatier.ExecuteDataReader(SqlStr, ref connHandle);
                    string grpId = "";
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            grpId += grpId + "," + Convert.ToString(dr["ac_group_id"]).Trim();
                        }
                    }
                    dr.Close();
                    dr.Dispose();
                    grpId = grpId.Substring(1);

                    string SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) != '' Or Ac_name Like '%CANCELLED%')";

                    if (Vchkprod.IndexOf("vutex") >= 0 &&
                        (StrFunction.InList(pcvType.Trim(), new string[] { "DC", "AR", "SS", "IR", "SR" }) == true ||
                         StrFunction.InList(beHave.Trim(), new string[] { "DC", "AR", "SS", "IR", "SR" }) == true))
                    {
                        if (grpId.Length <= 1)
                        {
                            SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";
                        }
                        else
                        {
                            if (StrFunction.InList(pcvType.Trim(), new string[] { "DC", "SS", "IR", "SR" }) == true ||
                                StrFunction.InList(beHave.Trim(), new string[] { "DC", "SS", "IR", "SR" }) == true)
                                SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'SUNDRY DEBTORS')";
                            else
                                if (StrFunction.InList(pcvType.Trim(), new string[] { "AR" }) == true ||
                                    StrFunction.InList(beHave.Trim(), new string[] { "AR" }) == true)
                                    SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'SUNDRY CREDITORS')";
                        }
                    }
                    else
                    {
                        if (grpId.Length <= 1)
                        {
                            if (StrFunction.InList(pcvType.Trim(), new string[] { "CR", "CP" }) == true ||
                                  StrFunction.InList(beHave.Trim(), new string[] { "CR", "CP" }) == true)
                                SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                            else
                                if (StrFunction.InList(pcvType.Trim(), new string[] { "BR", "BP", "BI", "RR", "FP", "FR", "DP", "DR" }) == true ||
                                    StrFunction.InList(beHave.Trim(), new string[] { "BR", "BP", "BI", "RR", "FP", "FR", "DP", "DR" }) == true)
                                    SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'BANK')";
                                else
                                    if (StrFunction.InList(pcvType.Trim(), new string[] { "RP" }) == true ||
                                        StrFunction.InList(beHave.Trim(), new string[] { "RP" }) == true)
                                        SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'CASH & BANK BALANCES' Or " +
                                                  " RTRIM(LTRIM(UPPER(Typ))) = 'BANK' Or " +
                                                  " RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                        }
                        else
                        {
                            if (StrFunction.InList(pcvType.Trim(), new string[] { "CR", "CP" }) == true ||
                                  StrFunction.InList(beHave.Trim(), new string[] { "CR", "CP" }) == true)
                                SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                            else
                            {
                                if (StrFunction.InList(pcvType.Trim(), new string[] { "BR", "BP", "BI", "RR", "FP", "FR", "DP", "DR" }) == true ||
                                    StrFunction.InList(beHave.Trim(), new string[] { "BR", "BP", "BI", "RR", "FP", "FR", "DP", "DR" }) == true)
                                    SqlCond = "(RTRIM(LTRIM(UPPER(Typ))) = 'BANK')";
                                else
                                    if (StrFunction.InList(pcvType.Trim(), new string[] { "RP" }) == true ||
                                        StrFunction.InList(beHave.Trim(), new string[] { "RP" }) == true)
                                        SqlCond = "(RTRIM(LTRIM(UPPER([Group]))) = 'CASH & BANK BALANCES' Or " +
                                                  " RTRIM(LTRIM(UPPER(Typ))) = 'BANK' Or " +
                                                  " RTRIM(LTRIM(UPPER(Typ))) = 'CASH')";
                                    else
                                        if (StrFunction.InList(pcvType.Trim(), new string[] { "ST", "PT", "DC", "AC", "II", "IR", "ES", "SS", "IP", "OP", "JV", "SQ", "SO", "PO", "SR", "PR", "SB" }) == true ||
                                            StrFunction.InList(beHave.Trim(), new string[] { "ST", "PT", "DC", "AC", "II", "IR", "ES", "SS", "IP", "OP", "JV", "SQ", "SO", "PO", "SR", "PR", "SB" }) == true)
                                            SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";
                                        else
                                            if (StrFunction.InList(pcvType.Trim(), new string[] { "BR", "BP", "CR", "CP", "BI", "RP", "RR", "FP", "FR", "DP", "DR", "GI", "GR", "HI", "HR", "LI", "IL", "LR", "RL" }) == true ||
                                                StrFunction.InList(beHave.Trim(), new string[] { "BR", "BP", "CR", "CP", "BI", "RP", "RR", "FP", "FR", "DP", "DR", "GI", "GR", "HI", "HR", "LI", "IL", "LR", "RL" }) == true)
                                                SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";
                                            else
                                                if (StrFunction.InList(pcvType.Trim(), new string[] { "PC", "DN", "CN", "EP" }) == true ||
                                                    StrFunction.InList(beHave.Trim(), new string[] { "PC", "DN", "CN", "EP" }) == true)
                                                    SqlCond = "(ac_group_id in (" + grpId + "))";
                                                else
                                                    if (StrFunction.InList(pcvType.Trim(), new string[] { "OB", "OS" }) == true ||
                                                        StrFunction.InList(beHave.Trim(), new string[] { "OB", "OS" }) == true)
                                                        SqlCond = "(ac_group_id in (" + grpId + ") And Ac_name Not Like '%CANCELLED%')";
                                                    else
                                                        SqlCond = "(ac_group_id in (" + grpId + ") Or Ac_name Like '%CANCELLED%')";

                            }
                        }
                    }
                    //+ " And (ldeactive = 0 Or (ldeactive = 1 And deactfrom > '" + dateFormat.TodateTime(mainvw_date) + "'))";

                    fldList = "";
                    for (int i = 0; i < fldName.GetLength(0)  ; i++)
                    {
                        fldList = fldList.Trim() + (fldList.Trim() == "" ? 
                            "" : ",") + fldName[i, 0].Trim(); 
                    }

                    SqlStr = "select " + fldList.ToString().Trim() + " from ac_mast where " +
                             SqlCond + " order by ac_name ";

                    retView = _datatier.ExecuteDataTable(SqlStr, "_qrytbl",connHandle).DefaultView;
                    _datatier.Connclose(connHandle);
                    break;
                case "ITEM":
                    #region "Retrive data for Item"
                    string sql_tbl, sql_cond, sql_var, sql_var1 = "";
                    int mRate_Level = 0;
                    sql_cond = "";
                    sql_tbl = "it_mast";
                    sql_var = System.Convert.ToString(lcode_vw.Rows[0]["item_type"]).ToUpper().Trim();
                    if (sql_var.ToString().Trim() != "")
                    {
                        sql_var = "#" + sql_var.Replace(",", "#,#") + "#";
                    }

                    if (System.Convert.DBNull.Equals(lcode_vw.Rows[0]["it_rate"]) == false)
                    {
                        if (System.Convert.ToBoolean(lcode_vw.Rows[0]["it_rate"]) == true)
                        {
                            SqlDataReader DR;
                            SqlStr = "select top 1 rate_level from ac_mast where ac_id = " + mainvw_acid.ToString();
                            DR = _datatier.ExecuteDataReader(SqlStr,ref connHandle);
                            if (DR.HasRows == true)
                            {
                                mRate_Level = System.Convert.ToInt32(DR["rate_level"]);
                            }

                            if (mRate_Level != 0)
                            {
                                sql_cond = sql_cond + " and it_mast.it_code = it_rate.it_code and it_rate.rlevel = " + mRate_Level.ToString();
                            }
                            else
                            {
                                sql_cond = sql_cond + " and it_mast.it_code = it_rate.it_code and it_rate.ac_id = " + mainvw_acid.ToString();
                            }
                            DR.Close();
                            DR.Dispose();
                            _datatier.Connclose(connHandle);
                        }

                    }

                    if (sql_var.IndexOf("#") >= 0)
                    {
                        if (sql_cond.Trim() == "")
                        {
                            sql_cond = " ('" + sql_var.ToString().Trim() + "' Like '%#'+RTRIM(LTRIM(UPPER(It_mast.[Type])))+'#%')";
                        }
                        else
                        {
                            sql_cond = sql_cond + " and ('" + sql_var.ToString().Trim() + "' Like '%#'+RTRIM(LTRIM(UPPER(It_mast.[Type])))+'#%')";
                        }

                    }

                    sql_var1 = System.Convert.ToString(lcode_vw.Rows[0]["item_group"]).ToUpper().Trim();

                    if (sql_var1.ToString().Trim() != "")
                    {
                        sql_var1 = "#" + sql_var1.Replace(",", "#,#") + "#";
                    }

                    if (sql_var1.IndexOf("#") >= 0)
                    {
                        if (sql_cond.Trim() == "")
                        {
                            sql_cond = " ('" + sql_var1.ToString().Trim() + "' like '%#'+rtrim(ltrim(upper(it_mast.[Group])))+'#%'";
                        }
                        else
                        {
                            sql_cond = sql_cond + " and ('" + sql_var1.ToString().Trim() + "' like '%#'+rtrim(ltrim(upper(it_mast.[Group])))+'#%'";
                        }
                    }

                    fldList = "";
                    for (int i = 0; i < fldName.Length; i++)
                    {
                        fldList = fldList.Trim() + (fldList.Trim() == "" ?
                            "" : ",") + fldName[i, 0].Trim();
                    }

                    if (sql_cond.Trim() != "")
                    {
                        SqlStr = "select " + fldList.ToString().Trim() + " from " + sql_tbl.ToString().Trim() +
                                 " where " + sql_cond.ToString().Trim() + " order by it_mast.it_name ";
                    }
                    else
                        SqlStr = "select " + fldList.ToString().Trim() + " from " + sql_tbl.ToString().Trim() +
                                 " order by it_mast.it_name ";


                    retView = _datatier.ExecuteDataTable(SqlStr, "_qrytbl",connHandle).DefaultView;
                    _datatier.Connclose(connHandle);
                    break;
                    #endregion


            }
            
            return retView; 

        }

    }
}
