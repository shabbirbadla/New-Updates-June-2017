using System;
using System.Collections.Generic;
using System.Text;
using Data.Acess.Layer;
using Controls;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Data;
using AjaxControlToolkit;


namespace Business.Logic.Layer
{
    public class VuchkTransaction
    {
        DataTier dataAcess = new DataTier();
        boolFunction bitFunction = new boolFunction();

        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }
        public void genChkControls(DataView xtra_vw, DataRow data_vw, HtmlTable tblLcode)
        {
            try
            {
                HtmlTableRow r = new HtmlTableRow();
                tblLcode.Rows.Clear();
                tblLcode.Dispose();
                int cnt = 0;
                int viewRCount = 1;
                foreach (DataRowView xtraRow in xtra_vw)
                {
                    if (cnt == 0)
                    {
                        r = new HtmlTableRow(); // Create New Row
                        r.VAlign = "Top";
                    }
                    cellGen("LABEL", r, xtraRow, data_vw); // generate cell and insert control  
                    cellGen("BIT",r, xtraRow, data_vw);
                    cnt = cnt + 1;
                    viewRCount = viewRCount + 1;
                    if (cnt == 2 || viewRCount > xtra_vw.Count)
                    {
                        tblLcode.Rows.Add(r);
                        cnt = 0;
                    } 
                }
                r = new HtmlTableRow();
                HtmlTableCell cellD = new HtmlTableCell();
                r.Controls.Add(cellD);
                cellD = new HtmlTableCell();
                r.Controls.Add(cellD);
                tblLcode.Rows.Add(r);
            }
            catch (Exception Ex)
            {
                throw new Exception(Ex.Message);
            }
        }

        public void cellGen(string cntType,HtmlTableRow htmlRow,DataRowView xtraRow,
                            DataRow data_vw)
        {
            HtmlTableCell cellD = new HtmlTableCell();
            cellD.Align = "Left";
            cellD.VAlign = "Top";
            switch (cntType.Trim())
            {
                case "LABEL":
                    Label lblS = new Label();
                    lblS.ID = "lbl" + Convert.ToString(xtraRow["cd"]).Trim();
                    lblS.Text = Convert.ToString(xtraRow["code_nm"]).Trim();
                    lblS.CssClass = "forms_ItemLeft5";
                    cellD.Controls.Add(lblS);
                    cellD.Align = "Right";
                    break;
                case "BIT":
                    CheckBox chkBox = new CheckBox();
                    chkBox.ID = "chk" + Convert.ToString(xtraRow["cd"]).Trim();
                    cellD.Controls.Add(chkBox);
                    cellD.Align = "Left";
                    break;
            }
            htmlRow.Cells.Add(cellD);
        }
        protected void objUnBoxing(object contObj, string fName, string objType, string chkvalue)
        {
            //switch (objType.Trim().ToUpper())
            //{
            //    case "CHECKBOX":
            //    switch (data_vw[fName.Trim()].GetType().Name.ToUpper().Trim())
            //    {
            //        case "BOOLEAN":
            //            ((CheckBox)contObj).Checked = bitFunction.toBoolean(data_vw[fName.Trim()]);
                        
            //            break;                    
            //    }
            //        break;
            //}
        }

        protected void objBoxing(object contObj, string fName, string objType,string chkvalue)
        {
            string [] arrchk = chkvalue.Split(' ');
            foreach (string arrval in arrchk)
            {
                 ((CheckBox)contObj).ID = "chk"+fName;
            }
           
        }

        public string btnClick(HtmlTable tblLcode, string[] xclude, string chkStr, string text)
        {
            string cntId = "";
            string nm = "";
            string[] arrChk;

            for (int tb = 0; tb < tblLcode.Controls.Count; tb++)
            {
                for (int tbRw = 0; tbRw < tblLcode.Controls[tb].Controls.Count; tbRw++)
                {
                    for (int tbCell = 0; tbCell < tblLcode.Controls[tb].Controls[tbRw].Controls.Count; tbCell++)
                    {
                        cntId = Convert.ToString(tblLcode.Controls[tb].Controls[tbRw].Controls[tbCell].ID);

                        if (cntId != null)
                        {
                            string fName = cntId.Trim().Substring(3, cntId.Length - 3);

                            if (xclude != null)
                            {
                                bool isFound = false;
                                foreach (string str in xclude)
                                {
                                    if (str != null)
                                    {
                                        if (fName.ToString().Trim() == str.ToString().Trim())
                                        {
                                            isFound = true;
                                            break;
                                        }
                                    }
                                }

                                if (isFound == true)
                                    continue;
                            }

                            object contObj = tblLcode.Controls[tb].Controls[tbRw].Controls[tbCell];
                            //((CheckBox)contObj).Checked = 
                            switch (cntId.ToString().ToUpper().Substring(0, 3))
                            {
                                case "CHK":
                                    if (chkStr.ToUpper() == "" && text.ToString() == "")
                                    {
                                        if (((CheckBox)contObj).Checked == true)
                                        {
                                            nm = nm + " " + fName;
                                        }
                                        else
                                        {
                                            if (((CheckBox)contObj).Checked == false)
                                            {
                                                break;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (chkStr.ToUpper() == "UNBOXING" && text.ToString()!= "")
                                        {
                                            string [] arrchk = text.Split(' ');
                                            foreach (string arrval in arrchk)
                                            {
                                                if (((CheckBox)contObj).ID.ToUpper() == "CHK" + arrval.Trim().ToUpper())
                                                {
                                                    ((CheckBox)contObj).Checked = true;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (chkStr.ToUpper() == "Cancel" && text.ToString() != "")
                                            {
                                                string[] arrchk = text.Split(' ');
                                                foreach (string arrval in arrchk)
                                                {
                                                    if (((CheckBox)contObj).ID.ToUpper() == "CHK" + arrval.Trim().ToUpper())
                                                    {
                                                        ((CheckBox)contObj).Checked = false;
                                                    }
                                                }
                                            }
                                            else
                                            {                                               
                                                    
                                                        if (((CheckBox)contObj).ID.ToUpper() == "CHK" + fName.Trim().ToUpper())
                                                        {
                                                            ((CheckBox)contObj).Checked = false;
                                                        }
                                                    
                                                
                                            }
                                        }
                                        
                                      
                                    } 
                                    
                                    
                                 break;
                            }
                        }
                    }
                }
                
            }
            return nm;
        }

        public class SetValue<myType>
        {
            public myType SetDefaultValue(DataRowView xtraRow, string fldName, DataRow data_vw)
            {
                myType defaValue;
                if (Convert.ToString(xtraRow["code_nm"]).Trim() != "")
                {
                    try
                    {
                        defaValue = ((myType)xtraRow["code_nm"]);
                    }
                    catch (InvalidCastException Ex)
                    {
                        throw new InvalidCastException(fldName.Trim() + " default value is not proper," + Ex.Message.Trim());
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                }
                else
                {
                    try
                    {
                        //myType nullObj = (myType)"0";
                        object nullObj = null;
                        if (Convert.DBNull.Equals(data_vw[fldName.Trim()]) == false)
                            defaValue = ((myType)data_vw[fldName.Trim()]);
                        else
                            defaValue = default(myType);
                    }
                    catch (InvalidCastException Ex)
                    {
                        throw new InvalidCastException(fldName.Trim() + " default value is not proper," + Ex.Message.Trim());
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }

                }
                return defaValue;

            }


        }
    }
}
