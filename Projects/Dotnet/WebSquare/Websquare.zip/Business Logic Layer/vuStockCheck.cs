using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls; 
using Data.Acess.Layer;     

namespace Business.Logic.Layer
{
    public class vuStockCheck
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        public vuStockCheck()
        {
        }

        public decimal[] StockChecking(string ItemName,
                int itCd,
                string wareName,
                bool addMode,
                string entry_tbl,
                DataTable lcode_vw,
                DataTable Company,
                DataTable main_vw,
                string vChkprod,
                Button btnItAdd,
                HiddenField hidInvStk,
                HiddenField hidNegItBal,
                HiddenField hidNonStk)
        {   
            decimal[] Stock = new decimal[4];
            decimal StockBal, StockBalW, StockPoBal, StockSoBal = 0;
            int tranCd = 0;
            DateTime tranDt;
            getDateFormat DateFormat = new getDateFormat();
            tranCd = System.Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
            tranDt = DateFormat.TodateTime(main_vw.Rows[0]["date"]);  
            StockBalW = 0;
            StockPoBal = 0;
            StockSoBal = 0; 
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
  
            SqlDataReader Dr;
            string SqlStr,NonStk = "";
            SqlStr = "select top 1 it_code,s_unit,NonStk from it_mast where it_code = " + itCd.ToString(); 

            Dr = _datatier.ExecuteDataReader(SqlStr,ref connHandle);   
            while (Dr.Read())
            {
                NonStk = System.Convert.ToString(Dr["NonStk"]);
            }
            Dr.Close(); 
            Dr.Dispose();
            _datatier.Connclose(connHandle);

            StockBal = StockItBal(addMode, itCd, tranCd, lcode_vw, entry_tbl);    

            if (System.Convert.ToString(lcode_vw.Rows[0]["inv_stk"]).Trim() == "-" &&
                System.Convert.ToBoolean(Company.Rows[0]["neg_itBal"]) == false && 
                NonStk.ToString().ToUpper().Trim() == "STOCKABLE" )
            {
                StockBalW = StockItBalW(addMode, itCd, tranCd, wareName, tranDt, entry_tbl, lcode_vw);   
            }

            if (vChkprod.IndexOf("vuord") >= 0)  // Product Order Processing
            {
                if (!System.Convert.IsDBNull(lcode_vw.Rows[0]["Logi_Stk"]))
                {
                    if (System.Convert.ToBoolean(lcode_vw.Rows[0]["Logi_Stk"]) == true)
                    {
                        StockPoBal = StockOrdBal(itCd, tranCd, main_vw, addMode, "PO");
                        StockSoBal = StockOrdBal(itCd, tranCd, main_vw, addMode, "SO");
                    }
                }
            }

            
            if (System.Convert.ToString(lcode_vw.Rows[0]["Inv_Stk"]).Trim() == "-" &&
                System.Convert.ToBoolean(Company.Rows[0]["Neg_ItBal"]) == false &&
                NonStk.ToString().ToUpper().Trim() == "STOCKABLE" && (StockBal <= 0 || StockBalW <= 0))
            {
                //if (btnItAdd.Attributes.Keys.ToString().Trim().ToUpper() != "ONCLICK")
                //{
                //    btnItAdd.Attributes.Add("onclick", "javascript: return StockValidation()");
                //}
                throw new Exception ("Item " + ItemName.ToString().Trim() + "is out of Stock!!!");
            }


            Stock[0] = StockBal;
            Stock[1] = StockBalW;
            Stock[2] = StockPoBal;
            Stock[3] = StockSoBal;
            hidInvStk.Value  = System.Convert.ToString(lcode_vw.Rows[0]["Inv_Stk"]).Trim();
            hidNegItBal.Value = System.Convert.ToString(Company.Rows[0]["Neg_ItBal"]);
            hidNonStk.Value = NonStk.ToString().ToUpper().Trim();

            return Stock;
        }

        public decimal StockItBalW(bool addMode, int itId, int tranId, string wareName, DateTime tranDt,string entry_tbl,DataTable lcode_vw)
        {
            decimal StockBal = 0;
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            getDateFormat DateFormat = new getDateFormat(); 
            DataSet ds = new DataSet();
            string SqlStr = "";
            SqlStr = "a.it_code = " + itId.ToString();
            if (wareName.ToString().Trim() != "")
            {
                SqlStr += " and a.ware_nm = '" + wareName.ToString().Trim() + "'";
            }

            if (tranId != 0)
            {
                SqlStr += (tranDt > DateTime.MinValue && tranDt < DateTime.MaxValue) ?
                    " and a.date <= '" + DateFormat.dateformat(tranDt) + "'" :
                    "";
            }

            SqlStr += " And A.Entry_ty = B.Entry_Ty And B.inv_stk != ' ' ";

            ds = _datatier.ExecuteDataset("Select A.*,B.inv_stk From It_balw A,Lcode B where " + SqlStr, "_itbalw",connHandle);

            if (ds.Tables["_itbalw"].Rows.Count > 0)
            {
                SqlStr = " Select A.*,B.inv_stk into #tmpitBalW From It_balw A,Lcode B where " + SqlStr;
                _datatier.ExecuteScalar(SqlStr, ref connHandle);

                SqlStr = "select " +
                         " sum (case when inv_stk = '+' and qty is not null " +
                         "  then qty " +
                         "else" +
                         "	case when inv_stk = '-' and qty is not null" +
                         "      then -qty " +
                         "  end " +
                         "end) as qty" +
                         " from #tmpItBalW";
                ds = _datatier.ExecuteDataset(ds, SqlStr, "_itBalWs",ref connHandle);

                _datatier.ExecuteScalar("drop table #tmpitBalW ", ref connHandle);  // Remove temp table
                if (ds.Tables["_itBalWs"].Rows.Count > 0)
                {
                    if (!System.Convert.IsDBNull(ds.Tables["_itBalWs"].Rows[0]["Qty"])) 
                    {
                        StockBal = StockBal + System.Convert.ToDecimal(ds.Tables["_itBalws"].Rows[0]["Qty"]);  
                    }

                    if (addMode == true) // Editing entry check stock
                    {
                        if (wareName.ToString().Trim() != "")
                        {
                            SqlStr = " Select dc_no,qty from " + entry_tbl.ToString().Trim() + "item" +
                                     " where tran_cd =" + tranId.ToString() + " and it_code = " + itId.ToString();
                        }
                        else
                        {
                            SqlStr = " Select dc_no,qty from " + entry_tbl.ToString().Trim() + "item" +
                                     " where tran_cd =" + tranId.ToString() + " and it_code = " + itId.ToString() +
                                     " and ware_nm = '" + wareName.ToString().Trim() + "'";

                        }
                        ds = _datatier.ExecuteDataset(ds, SqlStr, "_itBalWstmp", ref connHandle);
                        if (ds.Tables["_itBalWstmp"].Rows.Count > 0)
                        {
                            foreach (DataRow Row in ds.Tables["_itBalWstmp"].Rows)
                            {
                                if (System.Convert.ToString(Row["dc_no"]) == "")
                                {
                                    if (System.Convert.ToString(lcode_vw.Rows[0]["Inv_Stk"]) == "+")
                                    {
                                        StockBal = StockBal + (-System.Convert.ToDecimal(Row["Qty"]));
                                    }
                                    else
                                    {
                                        if (System.Convert.ToString(lcode_vw.Rows[0]["Inv_Stk"]) == "-")
                                        {
                                            StockBal = StockBal + System.Convert.ToDecimal(Row["Qty"]);
                                        }
                                    }

                                }
                            }
                        }
                    }
                    
                } // End
            }
            ds.Clear(); 
            ds.Dispose();
            _datatier.Connclose(connHandle);  
            return StockBal; 
  
        }

        public decimal StockItBal(bool addMode, int itId,int tranId, DataTable lcode_vw,string entry_Tbl)
        {
            decimal stockBal = 0;
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            DataSet ds = new DataSet();
            string SqlStr = "";
            SqlStr = "select * From It_bal where it_code = " + itId.ToString();

            ds = _datatier.ExecuteDataset(SqlStr, "_itBal", connHandle);   
            if (ds.Tables["_itBal"].Rows.Count > 0)
            {
                SqlStr = "Select Entry_ty,Bcode_nm,Inv_stk From Lcode where Inv_stk = '+' Or Inv_stk = '-'";
                ds = _datatier.ExecuteDataset(ds, SqlStr, "_lcode", ref connHandle);
                if (ds.Tables["_lcode"].Rows.Count > 0)
                {
                    SqlStr = " Select Entry_ty,Bcode_nm,Inv_stk into #tmpLcode From Lcode where Inv_stk = '+' Or Inv_stk = '-'";
                    _datatier.ExecuteScalar(SqlStr, ref connHandle);  

                    SqlStr = "select entry_ty,bcode_nm,inv_stk from #tmpLcode where ";
                    SqlStr = SqlStr + "(ltrim(rtrim(bcode_nm)) = '') ";
                    SqlStr = SqlStr + "or bcode_nm not in (select entry_ty from #tmpLcode)";
                    ds = _datatier.ExecuteDataset(ds, SqlStr, "_tmplcode",ref connHandle);

                    _datatier.ExecuteScalar("drop table #tmpLcode ",ref connHandle); // Remove temp table  

                    string fld = "";
                    string entry_ty,bcode_nm = "";
                    if (ds.Tables["_tmplcode"].Rows.Count > 0)
                    {
                        foreach (DataRow Row in ds.Tables["_tmplcode"].Rows)
                        {
                            entry_ty = System.Convert.ToString(Row["entry_ty"]).Trim();
                            bcode_nm = System.Convert.ToString(Row["bcode_nm"]).Trim();
                            entry_ty = entry_ty + "qty";
                            bcode_nm = bcode_nm + "qty";

                            try
                            {
                                if (ds.Tables["_itBal"].Rows[0].Table.Columns.Contains(entry_ty) == true)
                                {
                                    fld = System.Convert.ToString(Row["entry_ty"]).Trim() + "qty";
                                }
                                else
                                {
                                    if (System.Convert.ToString(Row["bcode_nm"]).Trim() != "")
                                    {
                                        if (ds.Tables["_itBal"].Rows[0].Table.Columns.Contains(bcode_nm) == true)
                                        {
                                            fld = System.Convert.ToString(Row["bcode_nm"]).Trim() + "qty";
                                        }
                                        else
                                            fld = "";
                                    }
                                    else
                                        fld = "";
                                }
                            }
                            catch 
                            {
                                try
                                {
                                    if (System.Convert.ToString(Row["bcode_nm"]).Trim() != "")
                                    {
                                        if (ds.Tables["_itBal"].Rows[0].Table.Columns.Contains(bcode_nm) == true)
                                        {
                                            fld = System.Convert.ToString(Row["bcode_nm"]).Trim() + "qty";
                                        }
                                        else
                                            fld = "";
                                    }
                                    else
                                        fld = "";
                                }
                                catch (Exception SS)
                                {
                                    throw new Exception(SS.Message.ToString().Trim());   
                                }
                            }

                            if (fld != "")
                            {
                                if (!System.Convert.IsDBNull(ds.Tables["_itBal"].Rows[0][fld]))
                                {
                                    if (System.Convert.ToString(Row["inv_stk"]).Trim() == "+")
                                    {
                                        if (System.Convert.ToDecimal(ds.Tables["_itBal"].Rows[0][fld]) > 0)
                                        {
                                            stockBal = stockBal + (System.Convert.ToDecimal(ds.Tables["_itBal"].Rows[0][fld]));
                                        }
                                    }
                                    else
                                    {
                                        if (System.Convert.ToString(Row["inv_stk"]).Trim() == "-")
                                        {
                                            if (System.Convert.ToDecimal(ds.Tables["_itBal"].Rows[0][fld]) > 0)
                                            {
                                                stockBal = stockBal + ( - System.Convert.ToDecimal(ds.Tables["_itBal"].Rows[0][fld]));
                                            }
                                        }
                                    }
                                }
                            }

                        }


                        if (addMode  == false) // While editing Entry to Check existing Stock
                        {
                            SqlStr = "select dc_no,qty from " + entry_Tbl.ToString().Trim() + 
                                     "item where tran_cd = " + tranId.ToString().Trim() + 
                                     " and it_code = " + itId.ToString().Trim();
                            ds = _datatier.ExecuteDataset(ds, SqlStr, "_item_vw",ref connHandle);
                            if (ds.Tables["_item_vw"].Rows.Count > 0)
                            {
                                foreach (DataRow Row in ds.Tables["_item_vw"].Rows)
                                {
                                    if (System.Convert.ToString(Row["dc_no"]).Trim() == "")
                                    {
                                        if (System.Convert.ToString(lcode_vw.Rows[0]["inv_stk"]).Trim() == "+")
                                        {
                                            stockBal = stockBal + ( - System.Convert.ToDecimal(ds.Tables["_item_vw"].Rows[0]["qty"]));
                                        }
                                        else
                                        {
                                            if (System.Convert.ToString(lcode_vw.Rows[0]["inv_stk"]).Trim() == "-")
                                            {
                                                stockBal = stockBal + (System.Convert.ToDecimal(ds.Tables["_item_vw"].Rows[0]["qty"]));
                                            }
                                        }
                                    }
                                }
                            }

                        } // End
                    }
                }
            }
            ds.Clear();
            ds.Dispose();
            _datatier.Connclose(connHandle); 
            return stockBal; 
        }

        public decimal StockOrdBal(int itId, int tranId,DataTable main_vw,bool addMode,string OrderType)
        {
            decimal StockOrdQty = 0;
            string SqlStr,OrdHeaderTbl,OrdDetailTbl = "";
            OrdHeaderTbl = OrderType.ToString().Trim() + "main";
            OrdDetailTbl = OrderType.ToString().Trim() + "item"; 
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            SqlDataReader Dr;
            SqlCommand cmd = new SqlCommand();
            SqlStr = " a.tran_cd = b.tran_cd and a.entry_ty = b.entry_ty and a.it_code = " + tranId.ToString();
            if (System.Convert.ToString(main_vw.Rows[0]["entry_ty"]) == OrderType.ToString().Trim()  && addMode == false)
            {
                SqlStr += " and a.tran_id != " + tranId.ToString();
            }

            int ret = 0;
            SqlStr = " select a.dc_no,a.qty,a.re_qty,b.apgen into #tmpTblVw from " + OrdDetailTbl.ToString().Trim() + " a," +
                      OrdHeaderTbl.ToString().Trim() + " b where "  + SqlStr;

            ret = _datatier.ExecuteNonQuery(SqlStr,"TX",ref connHandle);  
            
            if (ret > 0)
            {
                SqlStr = "select sum(qty-re_qty) as qty from #tmpTblVw where ltrim(rtrim(dc_no)) <> ''" +
                         " and apgen = 'YES' ";
                Dr = _datatier.ExecuteDataReader(SqlStr,ref connHandle);
                //_datatier.ExecuteScalar("drop table #tmpTblVw "); // Remove temp table    

                while (Dr.Read())
                {
                    if (!System.Convert.IsDBNull(Dr["qty"]))
                    {
                        StockOrdQty = StockOrdQty + System.Convert.ToDecimal(Dr["Qty"]);  
                    }
                }
                Dr.Close();
                Dr.Dispose();
            }
            _datatier.ExecuteScalar("drop table #tmpTblVw ",ref connHandle); // Remove temp table  
            return StockOrdQty;
        }

        public DataTable GenSRStock(int ItemName,
                   DataTable main_vw,
                   DataTable coAdditional,
                   DataTable lcode_vw,
                   DataTable litemall_vw,
                   DataRow itemRow,
                   string varETGoDown,
                   int Tex_exe,
                   string[,] Tex_ExAr)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            getDateFormat DateFormat = new getDateFormat();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlDataReader dr;

            int rowsEffected = 0;
            string GodownName, mentry_tydc, mentry_tygt = "";
            mentry_tydc = "";
            mentry_tygt = "";
            string sqlstr = "";
            bool etFlag = false;
            int _Mdays = 0;

            _Mdays = numFunction.toInt32(coAdditional.Rows[0]["sr_days"]);
 
            GodownName = varETGoDown;
            etFlag = Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
               bitFunction.toBoolean(coAdditional.Rows[0]["et_flag"]) :
               bitFunction.toBoolean(coAdditional.Rows[0]["net_flag"]);

            string mFieldlist = Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() != "" ?
               Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() : "it_mast.it_name";

            string fldName, fldName1, fldnewName = "";
            fldName = mFieldlist;

            while (fldName.Trim() != "")
            {
                fldName1 = fldName.Trim().IndexOf(",") >= 0 ?
                    fldName.Trim().Substring(0, fldName.Trim().IndexOf(',')) : fldName.Trim();
                fldnewName = fldnewName + (fldnewName.Trim() != "" ? "," : "") +
                            (fldName1.Trim().IndexOf(':') >= 0 ?
                            fldName1.Trim().Substring(0, fldName1.IndexOf(':')) : fldName1.Trim());
                fldName = fldName.Trim().IndexOf(',') > 0 ?
                    fldName.Trim().Substring(fldName.Trim().IndexOf(',') + 1) : "";
            }
            fldName = fldnewName.Trim().ToUpper().Replace("IT_MAST.", "B.");

            SqlParameter[] spParam = new SqlParameter[15];

            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@date";
            spParam[0].SqlDbType = SqlDbType.DateTime;
            spParam[0].Value = DateFormat.TodateTime(DateFormat.TodateTime(main_vw.Rows[0]["date"]));

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@rule";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(main_vw.Rows[0]["rule"]).Trim();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@sconsid";
            spParam[2].SqlDbType = SqlDbType.Int;
            spParam[2].Value = numFunction.toInt32(main_vw.Rows[0]["scons_id"]);

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@consid";
            spParam[3].SqlDbType = SqlDbType.Int;
            spParam[3].Value = numFunction.toInt32(main_vw.Rows[0]["cons_id"]);

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@pentryty";
            spParam[4].SqlDbType = SqlDbType.VarChar; 
            spParam[4].Value = (litemall_vw.Rows.Count !=0 ? Convert.ToString(litemall_vw.Rows[0]["pentry_ty"]).Trim() : "") ;

            spParam[5] = new SqlParameter();
            spParam[5].ParameterName = "@ptrancd";
            spParam[5].SqlDbType = SqlDbType.Int;
            spParam[5].Value = (litemall_vw.Rows.Count != 0 ? numFunction.toInt32(litemall_vw.Rows[0]["ptran_cd"]) : 0);

            spParam[6] = new SqlParameter();
            spParam[6].ParameterName = "@itcode";
            spParam[6].SqlDbType = SqlDbType.Int;
            spParam[6].Value = ItemName;

            spParam[7] = new SqlParameter();
            spParam[7].ParameterName = "@godown";
            spParam[7].SqlDbType = SqlDbType.VarChar;
            spParam[7].Value = GodownName;

            StringBuilder texEx = new StringBuilder();
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                texEx.Append("," + "A." + Tex_ExAr[tex_exs, 1]);
            }

            spParam[8] = new SqlParameter();
            spParam[8].ParameterName = "@AtexExAr";
            spParam[8].SqlDbType = SqlDbType.NVarChar;
            spParam[8].Value = texEx.ToString().Trim();

            texEx = new StringBuilder();
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                texEx.Append("," + "B." + Tex_ExAr[tex_exs, 1]);
            }

            spParam[9] = new SqlParameter();
            spParam[9].ParameterName = "@BtexExAr";
            spParam[9].SqlDbType = SqlDbType.NVarChar; 
            spParam[9].Value = texEx.ToString().Trim();

            fldName = fldnewName.Trim().ToUpper().Replace("IT_MAST.", "B.");

            spParam[10] = new SqlParameter();
            spParam[10].ParameterName = "@fldname";
            spParam[10].SqlDbType = SqlDbType.VarChar;
            spParam[10].Value = fldName;

            spParam[11] = new SqlParameter();
            spParam[11].ParameterName = "@uoSale";
            spParam[11].SqlDbType = SqlDbType.Bit;
            spParam[11].Value = bitFunction.toBoolean(main_vw.Rows[0]["u_osale"]);

            spParam[12] = new SqlParameter();
            spParam[12].ParameterName = "@srdays";
            spParam[12].SqlDbType = SqlDbType.Int;
            spParam[12].Value = _Mdays;

            spParam[13] = new SqlParameter();
            spParam[13].ParameterName = "@ucominv";
            spParam[13].SqlDbType = SqlDbType.VarChar;
            spParam[13].Value = Convert.ToString(main_vw.Rows[0]["u_cominvno"]).Trim();

            string sumStr = "";
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                sumStr = sumStr + "," + "Sum(A." + Tex_ExAr[tex_exs, 1].Trim() + ") as " +
                    Tex_ExAr[tex_exs, 1].Trim();
            }

            spParam[14] = new SqlParameter();
            spParam[14].ParameterName = "@sumstr";
            spParam[14].SqlDbType = SqlDbType.NVarChar;
            spParam[14].Value = sumStr;


            DataTable trdtbl_vw = DataAcess.ExecuteDataTable("sp_ent_web_genSRstock", spParam, connHandle);
            DataAcess.Connclose(connHandle);
            foreach (DataRow litemAllRow in litemall_vw.Rows)
            {
                try
                {
                    string filterExp = "(Entry_ty ='" + Convert.ToString(litemAllRow["pentry_ty"]).Trim() + "' and " +
                             " tran_cd = " + numFunction.toInt32(litemAllRow["ptran_cd"]) +
                             " and itserial ='" + Convert.ToString(litemAllRow["pitserial"]).Trim() + "') and " +
                             " is null date";

                    DataRow findRow = trdtbl_vw.Select(filterExp)[0];
                    findRow["qty"] = numFunction.toDecimal(findRow["qty"]) -
                                        numFunction.toDecimal(litemAllRow["qty"]);
                    findRow["u_lqty"] = numFunction.toDecimal(findRow["u_lqty"]) -
                                        numFunction.toDecimal(litemAllRow["u_lqty"]);
                    findRow["examt"] = numFunction.toDecimal(findRow["examt"]) -
                                        numFunction.toDecimal(litemAllRow["examt"]);

                    for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                    {
                        findRow[Tex_ExAr[tex_exs, 1]]
                                = numFunction.toDecimal(findRow[Tex_ExAr[tex_exs, 1]]) -
                                numFunction.toDecimal(litemAllRow[Tex_ExAr[tex_exs, 1]]);
                    }

                    if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim() == "EXCISE")
                    {
                        if (!(numFunction.toDecimal(findRow["qty"]) > 0 &&
                            (numFunction.toDecimal(findRow["examt"]) > 0 ||
                             numFunction.toDecimal(findRow["u_cessamt"]) > 0)))
                        {
                            findRow.Delete();
                        }
                    }
                    else
                    {
                        if (!(numFunction.toDecimal(findRow["qty"]) > 0))
                        {
                            findRow.Delete();
                        }
                    }
                    findRow.AcceptChanges();
                }
                catch
                {
                    if (itemRow != null)
                    {
                        if (Convert.ToString(litemAllRow["itserial"]).Trim() ==
                            Convert.ToString(itemRow["itserial"]))
                        {
                            litemAllRow["Qty"] = 0;
                            litemAllRow.AcceptChanges();
                        }
                    }
                }
            }

            trdtbl_vw.AcceptChanges();
            return trdtbl_vw;

            //sqlstr = " select entry_ty,bcode_nm from lcode where entry_ty " +
            //         " in ('DC','GT') or bcode_nm in ('DC','GT') ";

            //dr = DataAcess.ExecuteDataReader(sqlstr);
            //if (dr.HasRows == true)
            //{
            //    while (dr.Read())
            //    {
            //        if (Convert.ToString(dr["entry_ty"]).Trim() == "GT" ||
            //            Convert.ToString(dr["bcode_nm"]).Trim() == "GT")
            //        {
            //            mentry_tygt = mentry_tygt + (mentry_tygt.Trim() != "" ?
            //                "," : "") + "'" + Convert.ToString(dr["entry_ty"]).Trim() + "'";
            //        }
            //        else
            //        {
            //            mentry_tydc = mentry_tydc + (mentry_tydc.Trim() != "" ?
            //                "," : "") + "'" + Convert.ToString(dr["entry_ty"]).Trim() + "'";
            //        }
            //    }
            //}
            //else
            //{
            //    dr.Close();
            //    DataAcess.Connclose();
            //    throw new Exception("ERROR!!! Lcode table not found OR Records not found in Lcode");
            //}
            //dr.Close();
            //dr.Dispose();

            //string mcond = "";
            //mcond = " ((A.Entry_ty In (" + mentry_tydc + ")) ";
            //mcond = mcond + ( bitFunction.toBoolean(main_vw.Rows[0]["u_osale"]) == false ?
            //    " And a.date between (" + 
            //    DateFormat.dateformat(DateFormat.TodateTime(main_vw.Rows[0]["date"])) + "-" +
            //    _Mdays + ") and " + DateFormat.dateformat(DateFormat.TodateTime(main_vw.Rows[0]["date"])) :
            //     " And A.Date <='" + DateFormat.dateformat(DateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'");
            //mcond = mcond + " And A.[Rule] ='" + Convert.ToString(main_vw.Rows[0]["rule"]).Trim() + "'";
            //mcond = mcond + " And a.scond_id = " + numFunction.toInt32(main_vw.Rows[0]["scons_id"]) +
            //        " And a.cons_id = " + numFunction.toInt32(main_vw.Rows[0]["cons_id"]);
            //mcond = mcond + (Convert.ToString(main_vw.Rows[0]["u_cominvno"]).Trim() != "" ?
            //    " And A.entry_ty ='" + Convert.ToString(litemall_vw.Rows[0]["pentry_ty"]).Trim() + "' and " +
            //    " a.tran_cd =" + numFunction.toInt32(litemall_vw.Rows[0]["ptran_cd"]) : "");


            //sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Date,A.Inv_no,C.Ac_name As Cons_Name," +
            //         " A.Scons_id,C.Ac_name,A.Cons_id into #tmptbl_vwv From TradeMain A " +
            //         " Inner Join Ac_mast C On A.Cons_id = C.Ac_id " +
            //         " Left Join Shipto B on A.Cons_id = B.Ac_id And A.Scons_id = B.Shipto_id " +
            //         " where " + mcond;

            //try
            //{
            //    rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}

            //mcond = " (A.Entry_ty in (" + mentry_tydc + "))";
            //mcond = mcond + (ItemName != 0 ? " And a.it_code = " + ItemName : "");
            //mcond = mcond + (Convert.ToString(main_vw.Rows[0]["u_cominvno"]).Trim() != "" ?
            //    " And a.ware_nm ='" + GodownName.Trim() + "'" : "");
            //sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Itserial,A.It_code,A.Ware_nm,A.Rgpage,A.Qty,A.U_lqty";

            //for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            //{
            //    sqlstr = sqlstr + "," + "A." + Tex_ExAr[tex_exs, 1];
            //}

            //sqlstr = sqlstr + "," + fldName +
            //    " into #tmptbl_vwi " +
            //    " From TradeItem A,It_mast B Where A.It_Code = B.It_code And " + mcond;

            //try
            //{
            //    rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}

            //mcond = " (A.PEntry_ty in (" + mentry_tydc + ")) ";
            //sqlstr = "  Select A.Ptran_cd,A.Pentry_ty,A.Pitserial,SUM(A.Qty) As Qty,SUM(A.U_lqty) As U_lqty ";

            //for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            //{
            //    sqlstr = sqlstr + "," + "Sum(A." + Tex_ExAr[tex_exs, 1].Trim() + ") as " +
            //        Tex_ExAr[tex_exs,1].Trim();
            //}

            //sqlstr = sqlstr + " into #tmptbl_vwl from litemall a where " + mcond +
            //        " group by  A.Ptran_cd,A.Pentry_ty,A.Pitserial ";

            //try
            //{
            //    rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}

            //sqlstr = " A.Tran_cd,A.Entry_ty,A.Date,A.Inv_no,A.Ac_Name,A.Cons_id,A.Cons_Name,A.Scons_id," +
            //    " B.Itserial,B.It_code,B.Ware_nm,B.Rgpage," +
            //    " B.Qty-IIF(A.Tran_cd = C.Ptran_cd,C.Qty,0) as Qty," +
            //    " B.U_lqty-IIF(A.Tran_cd = C.Ptran_cd,C.U_lqty,0) as U_lqty";

            //for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            //{
            //    sqlstr = sqlstr + "," + "B." + Tex_ExAr[tex_exs, 1].Trim() +
            //        "-IIF(A.Tran_cd = C.Ptran_cd,C." +
            //        Tex_ExAr[tex_exs, 1].Trim() + ",0) as " + Tex_ExAr[tex_exs, 1].Trim();
            //}

            //sqlstr = sqlstr + "," + fldName;

            //sqlstr = " select " + sqlstr + " From #tmptbl_vwv A," +
            //         " inner join #tmptbl_vwi B " +
            //         " on a.entry_ty = b.entry_ty and a.tran_cd = b.tran_cd " +
            //         " left join #tmptbl_vwl C on b.entry_ty = c.pentry_ty " +
            //         " and b.tran_cd = c.ptran_cd and b.itserial = c.pitserial ";

            //DataTable trdtbl_vw = new DataTable();
            //try
            //{
            //    trdtbl_vw = DataAcess.ExecuteDataTable(sqlstr, "_trdtbl_vw");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}

            //sqlstr = " drop table #tmptbl_vwv " +
            //         " drop table #tmptbl_vwi " +
            //         " drop table #tmptbl_vwl ";

            //DataAcess.ExecuteNonQuery(sqlstr, "TX");

            //foreach (DataRow litemAllRow in litemall_vw.Rows)
            //{
            //    try
            //    {
            //        string filterExp = "(Entry_ty ='" + Convert.ToString(litemAllRow["pentry_ty"]).Trim() + "' and " +
            //                 " tran_cd = " + numFunction.toInt32(litemAllRow["ptran_cd"]) +
            //                 " and itserial ='" + Convert.ToString(litemAllRow["pitserial"]).Trim() + "') and " +
            //                 " is null date";

            //        DataRow findRow = trdtbl_vw.Select(filterExp)[0];
            //        findRow["qty"] = numFunction.toDecimal(findRow["qty"]) -
            //                            numFunction.toDecimal(litemAllRow["qty"]);
            //        findRow["u_lqty"] = numFunction.toDecimal(findRow["u_lqty"]) -
            //                            numFunction.toDecimal(litemAllRow["u_lqty"]);
            //        findRow["examt"] = numFunction.toDecimal(findRow["examt"]) -
            //                            numFunction.toDecimal(litemAllRow["examt"]);

            //        for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            //        {
            //            findRow[Tex_ExAr[tex_exs, 1]]
            //                    = numFunction.toDecimal(findRow[Tex_ExAr[tex_exs, 1]]) -
            //                    numFunction.toDecimal(litemAllRow[Tex_ExAr[tex_exs, 1]]);
            //        }

            //        if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim() == "EXCISE")
            //        {
            //            if (!(numFunction.toDecimal(findRow["qty"]) > 0 &&
            //                (numFunction.toDecimal(findRow["examt"]) > 0 ||
            //                 numFunction.toDecimal(findRow["u_cessamt"]) > 0)))
            //            {
            //                findRow.Delete();
            //            }
            //        }
            //        else
            //        {
            //            if (!(numFunction.toDecimal(findRow["qty"]) > 0))
            //            {
            //                findRow.Delete();
            //            }
            //        }
            //        findRow.AcceptChanges();
            //    }
            //    catch
            //    {
            //        if (itemRow != null)
            //        {
            //            if (Convert.ToString(litemAllRow["itserial"]).Trim() ==
            //                Convert.ToString(itemRow["itserial"]))
            //            {
            //                litemAllRow["Qty"] = 0;
            //                litemAllRow.AcceptChanges();
            //            }
            //        }
            //    }
            //}

            //trdtbl_vw.AcceptChanges();
            //DataAcess.Connclose(); 
            //return trdtbl_vw;
        }

        public DataTable GenStock(int ItemName,
                    DataTable main_vw,
                    DataTable coAdditional,
                    DataTable lcode_vw,
                    DataTable litemall_vw,
                    DataRow itemRow,
                    string varETGoDown,
                    int Tex_exe,
                    string[,] Tex_ExAr)
                    
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            getDateFormat DateFormat = new getDateFormat();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlDataReader dr;
            int rowsEffected = 0;
            string GodownName, mentry_tyar, mentry_tygt = "";
            mentry_tyar = "";
            mentry_tygt = "";
            string sqlstr = "";
            bool etFlag = false;
            int pParty, pPartyS, manuName, manuNameS = 0;

            pParty = numFunction.toInt32(main_vw.Rows[0]["suppac_id"]);
            pPartyS = numFunction.toInt32(main_vw.Rows[0]["suppsac_id"]);
            manuName = numFunction.toInt32(main_vw.Rows[0]["manuac_id"]);
            manuNameS = numFunction.toInt32(main_vw.Rows[0]["manusac_id"]);

            GodownName = varETGoDown;
            etFlag = Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
                bitFunction.toBoolean(coAdditional.Rows[0]["et_flag"]) :
                bitFunction.toBoolean(coAdditional.Rows[0]["net_flag"]);

            string mFieldlist = Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() != "" ?
                Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() : "it_mast.it_name";

            string fldName, fldName1, fldnewName = "";
            fldName = mFieldlist;

            while (fldName.Trim() != "")
            {
                fldName1 = fldName.Trim().IndexOf(",") >= 0 ?
                    fldName.Trim().Substring(0, fldName.Trim().IndexOf(',')) : fldName.Trim();
                fldnewName = fldnewName + (fldnewName.Trim() != "" ? "," : "") +
                            (fldName1.Trim().IndexOf(':') >= 0 ?
                            fldName1.Trim().Substring(0, fldName1.IndexOf(':')) : fldName1.Trim());
                fldName = fldName.Trim().IndexOf(',') > 0 ?
                    fldName.Trim().Substring(fldName.Trim().IndexOf(',') + 1) : "";
            }

            SqlParameter[] spParam = new SqlParameter[12];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@date";
            spParam[0].SqlDbType = SqlDbType.DateTime;
            spParam[0].Value = DateFormat.TodateTime(DateFormat.TodateTime(main_vw.Rows[0]["date"]));

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@rule";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(main_vw.Rows[0]["rule"]).Trim();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@pPartyId";
            spParam[2].SqlDbType = SqlDbType.Int;
            spParam[2].Value = pParty;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@sPartyId";
            spParam[3].SqlDbType = SqlDbType.Int;
            spParam[3].Value = pPartyS;

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@etflag";
            spParam[4].SqlDbType = SqlDbType.Bit;
            spParam[4].Value = etFlag;

            spParam[5] = new SqlParameter();
            spParam[5].ParameterName = "@itcode";
            spParam[5].SqlDbType = SqlDbType.Int;
            spParam[5].Value = ItemName;

            spParam[6] = new SqlParameter();
            spParam[6].ParameterName = "@godown";
            spParam[6].SqlDbType = SqlDbType.VarChar;
            spParam[6].Value = GodownName;

            StringBuilder texEx = new StringBuilder();
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                texEx.Append("," + "A." + Tex_ExAr[tex_exs, 2]);
            }

            spParam[7] = new SqlParameter();
            spParam[7].ParameterName = "@AtexExAr";
            spParam[7].SqlDbType = SqlDbType.VarChar;
            spParam[7].Value = texEx.ToString().Trim();

            texEx = new StringBuilder();
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                texEx.Append("," + "B." + Tex_ExAr[tex_exs, 2]);
            }

            spParam[8] = new SqlParameter();
            spParam[8].ParameterName = "@BtexExAr";
            spParam[8].SqlDbType = SqlDbType.VarChar;
            spParam[8].Value = texEx.ToString().Trim();

            fldName = fldnewName.Trim().ToUpper().Replace("IT_MAST.", "B.");

            spParam[9] = new SqlParameter();
            spParam[9].ParameterName = "@fldname";
            spParam[9].SqlDbType = SqlDbType.VarChar;
            spParam[9].Value = fldName;

            spParam[10] = new SqlParameter();
            spParam[10].ParameterName = "@ManuId";
            spParam[10].SqlDbType = SqlDbType.Int;
            spParam[10].Value = manuName;

            spParam[11] = new SqlParameter();
            spParam[11].ParameterName = "@ManuSId";
            spParam[11].SqlDbType = SqlDbType.Int;
            spParam[11].Value = manuNameS;

            DataTable trdtbl_vw = DataAcess.ExecuteDataTable("sp_ent_web_genstock", spParam,connHandle);

            foreach (DataRow litemAllRow in litemall_vw.Rows)
            {
                try
                {
                    string filterExp = "(Entry_ty ='" + Convert.ToString(litemAllRow["pentry_ty"]).Trim() + "' and " +
                           " tran_cd = " + numFunction.toInt32(litemAllRow["ptran_cd"]) +
                           " and itserial ='" + Convert.ToString(litemAllRow["pitserial"]).Trim() + "') and " +
                           " is null date";

                    DataRow findRow = trdtbl_vw.Select(filterExp)[0];
                    findRow["balqty"] = numFunction.toDecimal(findRow["balqty"]) -
                                        numFunction.toDecimal(litemAllRow["qty"]);
                    findRow["balqty1"] = numFunction.toDecimal(findRow["balqty1"]) -
                                        numFunction.toDecimal(litemAllRow["u_lqty"]);

                    for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                    {
                        findRow[Tex_ExAr[tex_exs, 2]]
                                = numFunction.toDecimal(findRow[Tex_ExAr[tex_exs, 2]]) -
                                numFunction.toDecimal(litemAllRow[Tex_ExAr[tex_exs, 1]]);
                    }

                    if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim() == "EXCISE")
                    {
                        if (!(numFunction.toDecimal(findRow["Balqty"]) > 0 &&
                            (numFunction.toDecimal(findRow["excbal"]) > 0 ||
                             numFunction.toDecimal(findRow["u_cessbal"]) > 0)))
                        {
                            findRow.Delete();
                        }
                    }
                    else
                    {
                        if (!(numFunction.toDecimal(findRow["balqty"]) > 0))
                        {
                            findRow.Delete();
                        }
                    }
                    findRow.AcceptChanges();
                }
                catch
                {
                    if (itemRow != null)
                    {
                        if (Convert.ToString(litemAllRow["itserial"]).Trim() ==
                            Convert.ToString(itemRow["itserial"]))
                        {
                            litemAllRow["Qty"] = 0;
                            litemAllRow.AcceptChanges();
                        }
                    }

                }
            }
            trdtbl_vw.AcceptChanges();
            DataAcess.Connclose(connHandle);
            return trdtbl_vw;
        }
    }
}
