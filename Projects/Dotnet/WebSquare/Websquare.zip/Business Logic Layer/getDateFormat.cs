using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlTypes;  

namespace Business.Logic.Layer
{
    public class getDateFormat
    {
        public SqlDateTime GetdateDT(string _strdate)
        {
            SqlDateTime _retdate = SqlDateTime.MinValue;
            if (_strdate != "")
            {
                _retdate = (SqlDateTime)System.Convert.ToDateTime(dateformat(_strdate));
            }
            return _retdate;
        }

        public string GetDateSTR(SqlDateTime sqlDate)
        {
            string _retdate = "";
            if (sqlDate > SqlDateTime.MinValue && sqlDate < SqlDateTime.MaxValue)
            {
                _retdate = dateformat(System.Convert.ToString(sqlDate));
            }

            return _retdate;
        }

        public string GetDateSTR(DateTime NetDate)
        {
            string _retdate = "";
            if (NetDate > DateTime.MinValue && NetDate < DateTime.MaxValue)
            {
                _retdate = dateformat(System.Convert.ToString(NetDate));
            }

            return _retdate;
        }

        public DateTime TodateTime(object objDate)
        {
            DateTime Date = Convert.ToDateTime("01/01/1900"); 
            switch (objDate.GetType().ToString().Trim().ToUpper())
            {
                case "SYSTEM.DATETIME":
                    Date = ((DateTime)objDate);
                    break;
                case "SYSTEM.STRING":
                    string dateTime = (String)objDate;
                    if (dateTime == "")
                        dateTime = "01/01/1900";
                    Date = Convert.ToDateTime(dateTime);
                    break;
            }

            if (Date.Year < 1900)
            {
                Date = Convert.ToDateTime("01/01/1900"); 
            }

            if (Date != null && (Date.Year > 1900))
            {
                string _retdate = "";
                string[] datearray = new string[3];
                string _date = Convert.ToString(Date).Trim();  
                datearray = _date.Split('/');
                _retdate = datearray[0];
                _retdate += "/" + datearray[1];
                if (datearray[2].Length > 4)
                {
                    _retdate += "/" + datearray[2].Substring(0, 4);
                }
                else
                {
                    _retdate += "/" + datearray[2];
                }

                Date = Convert.ToDateTime(_retdate);   
            }
            return Date; 
        }

        public string GetDateSTR(object objDate)
        {
            DateTime netDate = ((DateTime)objDate);

            string _retdate = "";
            if ((netDate > DateTime.MinValue && netDate < DateTime.MaxValue) &&
                 netDate.Year > 1900)
            {
                _retdate = dateformat(System.Convert.ToString(netDate));
            }
            else
            {
                _retdate = "";
            }
            return _retdate;
        }

        public string dateformat(DateTime date)
        {
            string _retdate = "";
            string strDate = "";
            if (date != null)
            {
                strDate = Convert.ToString(date);
                string[] datearray = new string[3];
                datearray = strDate.Split('/');
                _retdate = datearray[1];
                _retdate += "/" + datearray[0];
                if (datearray[2].Length > 4)
                {
                    _retdate += "/" + datearray[2].Substring(0, 4);
                }
                else
                {
                    _retdate += "/" + datearray[2];
                }
            }
            return _retdate;  
        }

        public string DtoStr(DateTime date)
        {
            string _retdate = "";
            string strDate = "";
            if (date != null)
            {
                strDate = Convert.ToString(date);
                string[] datearray = new string[3];
                datearray = strDate.Split('/');
                _retdate = datearray[0];
                _retdate += "/" + datearray[1];
                if (datearray[2].Length > 4)
                {
                    _retdate += "/" + datearray[2].Substring(0, 4);
                }
                else
                {
                    _retdate += "/" + datearray[2];
                }
            }
            return _retdate;
        }

        public string dateformat(string _date)
        {
            string _retdate = "";
         
            if (_date != "" && _date != null)
            {
                string[] datearray = new string[3];
                datearray = _date.Split('/');
                _retdate = datearray[1];
                _retdate += "/" + datearray[0];
                if (datearray[2].Length > 4)
                {
                    _retdate += "/" + datearray[2].Substring(0, 4);
                }
                else
                {
                    _retdate += "/" + datearray[2];
                }
            }

            //if ((Convert.ToDateTime(_retdate) > DateTime.MinValue &&
            //    Convert.ToDateTime(_retdate) < DateTime.MaxValue) ||
            //    Convert.ToDateTime(_retdate).Year != 1900)
            //{
            //    return _retdate;
            //}
            //else
            //{
            //    return "";
            //}
            return _retdate;  
        }

        public string dateformatBR(string _date)
        {
            string _retdate = "";
            if (_date != "" && _date != null)
            {
                string[] datearray = new string[3];
                datearray = _date.Split('/');
                _retdate = datearray[0];
                _retdate += "/" + datearray[1];
                if (datearray[2].Length > 4)
                {
                    _retdate += "/" + datearray[2].Substring(0, 4);
                }
                else
                {
                    _retdate += "/" + datearray[2];
                }

                DateTime netDate = Convert.ToDateTime(_retdate);
                if (!((netDate > DateTime.MinValue && netDate < DateTime.MaxValue) &&
                     netDate.Year > 1900))
                    _retdate = "";

                return _retdate;
            }

            return _retdate; 

            //try
            //{
            //    if ((Convert.ToDateTime(_retdate) > DateTime.MinValue &&
            //         Convert.ToDateTime(_retdate) < DateTime.MaxValue)&&
            //         Convert.ToDateTime(_retdate).Year != 1900)
            //    {
            //        return _retdate;
            //    }
            //    else
            //    {
            //        return "";
            //    }
            //}
            //catch
            //{
            //    string[] datearray = new string[3];
            //    datearray = _retdate.Split('/');
            //    _retdate = datearray[1];
            //    _retdate += "/" + datearray[0];
            //    if (datearray[2].Length >= 4)
            //    {
            //        _retdate += "/" + datearray[2].Substring(0, 4);
            //    }
            //    else
            //    {
            //        _retdate += "/" + datearray[2];
            //    }

            //    if ((Convert.ToDateTime(_retdate) > DateTime.MinValue &&
            //         Convert.ToDateTime(_retdate) < DateTime.MaxValue) ||
            //         Convert.ToDateTime(_retdate).Year != 1900)
            //    {
            //        return _retdate;
            //    }
            //    else
            //    {
            //        return "";
            //    }
            //}

        }
    }
}
