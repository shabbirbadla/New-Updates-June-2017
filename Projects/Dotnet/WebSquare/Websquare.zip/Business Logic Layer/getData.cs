using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Data.Acess.Layer;   

namespace Business.Logic.Layer
{
    public class getData
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        public getData()
        {
        }

        public DataSet getDataSet(DataSet DS, string SqlStr,string tblName)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
  
            DS = _datatier.ExecuteDataset(DS, SqlStr, tblName,connHandle);
            _datatier.Connclose(connHandle);
            return DS;
        }
    }
}
