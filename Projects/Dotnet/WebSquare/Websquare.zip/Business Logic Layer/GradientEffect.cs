using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using Controls;

namespace Business.Logic.Layer
{
    public class GradientEffect
    {
        public GradientEffect()
        {
        }

        public void SetBackGroundEffect(string startColorEff,string finishColorEff,int length,HtmlControl objHtml)
        {
            Color startColor = ColorTranslator.FromHtml(startColorEff.ToString().Trim());
            Color finishColor = ColorTranslator.FromHtml(finishColorEff.ToString().Trim());
          
            string backgroundUrl = GradientHandler.GetUrl(Orientation.Vertical, length, startColor, finishColor);
            string backgroundCss = string.Format("{0} url({1}) repeat-x", finishColor, backgroundUrl);
            objHtml.Style.Add("background", backgroundCss);  
        }
    }
}
