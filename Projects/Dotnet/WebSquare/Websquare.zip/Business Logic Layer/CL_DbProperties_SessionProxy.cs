using System;
using System.Collections.Generic;
using System.Text;


namespace Business.Logic.Layer
{
    public class CL_DbProperties_SessionProxy
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        public CL_DbProperties_SessionProxy()
        {
        }

        private const string ITEMPAGE = "ItemPage";
        private const string ACCOUNTPAGE = "AccountPage";
        private const string CHARGESPAGE = "ChargesPage";
        private const string ICHARGESPAGE =  "IchargesPage";
        private const string ALLOCATIONPAGE =  "AllocationPage";
        private const string AINFOPAGE =  "AinfoPage";
        private const string TDSPAGE = "TdsPage";
        private const string SERVICETAXPAGE =  "ServiceTaxPage";
        private const string PCVTYPE =  "PcvType";
        private const string BEHAVE =  "Behave";
        private const string ENTRY_TBL = "Entry_Tbl";
        private const string ADDMODE =  "AddMode";
        private const string EDITMODE =  "EditMode";
        private const string VCHKPROD =  "Vchkprod";
        private const string LTODATSDATE = "LTodaySDate";
        private const string PBACKDATE =  "PBackDate";
        private const string SALESTAXITEM =  "SalesTaxItem";
        private const string HOWCALCULATEEXAMT = "HowtoCalculateExAmt";
        private const string JUSTSERIES =  "JustSeries";
        private const string JUSTINVOICE =  "JustInvoice";
        private const string EDITSERIES =  "EditSeries";
        private const string EDITINVOICE =  "EditInvoice";
        private const string WARECOL =  "WareCol";
        private const string APPDATE =  "AppDate";
        private const string VARETGODOWNTO =   "VarETGodownTo";
        private const string VARETGODOWN = "VarETGodown";
        private const string TEX_EXE =  "Tex_exe";
        private const string VAMT =  "VAmt";
        private const string VCHRAMT =  "VchrAmt";
        private const string FROMACAMT =  "FromAcAmt";
        private const string ALLOCROWINDEX =  "AllocRowIndex";
        private const string ISOPENGRIDFORALLOCATION =  "IsOpenGridForAllocation";
        private const string INITSTARTWITHTRANCD =  "InitStartWithTranCd";
        private const string COLDEPT=   "ColDept";
        private const string COLCATE = "ColCate";
        private const string COLSERIES =  "ColSeries";
        private const string COLRULE =  "ColRule";
        private const string COLBANKNM =  "ColBankNm";
        private const string COLUINVNODT = "ColUInvnodt";
        private const string ITRATE =  "ItRate";
        private const string LBACKDATED = "LbackDated";

        // Item Page
        public bool ItemPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ITEMPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][ITEMPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][ITEMPAGE] = value;
            }
        }

        // Item Page
        public bool AccountPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ACCOUNTPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][ACCOUNTPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][ACCOUNTPAGE] = value;
            }
        }


        // Charges Page
        public bool ChargesPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][CHARGESPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][CHARGESPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][CHARGESPAGE] = value;
            }
        }

        // Charges Page
        public bool IchargesPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ICHARGESPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][ICHARGESPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][ICHARGESPAGE] = value;
            }
        }

        // Allocation Page
        public bool AllocationPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ALLOCATIONPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][ALLOCATIONPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][ALLOCATIONPAGE] = value;
            }
        }

        // Additional Info Page
        public bool AinfoPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][AINFOPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][AINFOPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][AINFOPAGE] = value;
            }
        }

        // Tds Page
        public bool TdsPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][TDSPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][TDSPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][TDSPAGE] = value;
            }
        }

        // Service Tax Page
        public bool ServiceTaxPage
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][SERVICETAXPAGE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][SERVICETAXPAGE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][SERVICETAXPAGE] = value;
            }
        }

        // Add Mode
        public bool AddMode
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ADDMODE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][ADDMODE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][ADDMODE] = value;
            }
        }

        // Today's Date
        public bool LTodaySDate
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][LTODATSDATE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][LTODATSDATE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][LTODATSDATE] = value;
            }
        }

        // Edit Mode
        public bool EditMode
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][EDITMODE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][EDITMODE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][EDITMODE] = value;
            }
        }

        // Sales Tax Item
        public bool SalesTaxItem
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][SALESTAXITEM]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][SALESTAXITEM];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][SALESTAXITEM] = value;
            }
        }

        // Grid For Allocation
        public bool IsOpenGridForAllocation
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ISOPENGRIDFORALLOCATION]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][ISOPENGRIDFORALLOCATION];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][ISOPENGRIDFORALLOCATION] = value;
            }
        }

        // Department
        public bool ColDept
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][COLDEPT]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][COLDEPT];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][COLDEPT] = value;
            }
        }

        // Category
        public bool ColCate
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][COLCATE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][COLCATE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][COLCATE] = value;
            }
        }

        // Series
        public bool ColSeries
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][COLSERIES]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][COLSERIES];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][COLSERIES] = value;
            }
        }

        // Rule
        public bool ColRule
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][COLRULE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][COLRULE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][COLRULE] = value;
            }
        }

        // Rule
        public bool ColBankNm
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][COLBANKNM]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][COLBANKNM];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][COLBANKNM] = value;
            }
        }

        // Invoice No. Date
        public bool ColUInvnodt
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][COLUINVNODT]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][COLUINVNODT];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][COLUINVNODT] = value;
            }
        }

        // Item Rate
        public bool ItRate
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ITRATE]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][ITRATE];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][ITRATE] = value;
            }
        }

        // Back Dated
        public bool LbackDated
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][LBACKDATED]))
                {
                    return false;
                }
                else
                {
                    return (bool)SessionProxy.DbProperties.Rows[0][LBACKDATED];
                }
            }
            set
            {
                if (value == true)
                    SessionProxy.DbProperties.Rows[0][LBACKDATED] = value;
            }
        }


        // Pcv Type
        public string PcvType
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][PCVTYPE]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][PCVTYPE];
                }
            }
            set
            {
                    SessionProxy.DbProperties.Rows[0][PCVTYPE] = value;
            }
        }

        // Behave
        public string Behave
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][BEHAVE]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][BEHAVE];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][BEHAVE] = value;
            }
        }

        // Entry_Tbl
        public string Entry_Tbl
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ENTRY_TBL]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][ENTRY_TBL];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][ENTRY_TBL] = value;
            }
        }


        // VchkProd
        public string Vchkprod
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][VCHKPROD]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][VCHKPROD];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][VCHKPROD] = value;
            }
        }

        // HowtoCalculateExAmt
        public string HowtoCalculateExAmt
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][HOWCALCULATEEXAMT]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][HOWCALCULATEEXAMT];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][HOWCALCULATEEXAMT] = value;
            }
        }

        // Just Series
        public string JustSeries
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][JUSTSERIES]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][JUSTSERIES];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][JUSTSERIES] = value;
            }
        }

        // Just Invoice
        public string JustInvoice
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][JUSTINVOICE]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][JUSTINVOICE];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][JUSTINVOICE] = value;
            }
        }

        // Edit Series
        public string EditSeries
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][EDITSERIES]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][EDITSERIES];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][EDITSERIES] = value;
            }
        }

        // Edit Invoice
        public string EditInvoice
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][EDITINVOICE]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][EDITINVOICE];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][EDITINVOICE] = value;
            }
        }


        // Warehouse
        public string VarETGodownTo
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][VARETGODOWNTO]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][VARETGODOWNTO];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][VARETGODOWNTO] = value;
            }
        }

        // Warehouse
        public string VarETGoDown
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][VARETGODOWN]))
                {
                    return string.Empty;
                }
                else
                {
                    return (string)SessionProxy.DbProperties.Rows[0][VARETGODOWN];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][VARETGODOWN] = value;
            }
        }

        // Application Date
        public DateTime AppDate
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][APPDATE]))
                {
                    return Convert.ToDateTime("01/01/1900");
                }
                else
                {
                    return (DateTime)SessionProxy.DbProperties.Rows[0][APPDATE];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][APPDATE] = value;
            }
        }

        // Application Date
        public DateTime PBackDate
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][PBACKDATE]))
                {
                    return Convert.ToDateTime("01/01/1900");
                }
                else
                {
                    return (DateTime)SessionProxy.DbProperties.Rows[0][PBACKDATE];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][PBACKDATE] = value;
            }
        }

        // Tax
        public Int32 Tex_exe
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][TEX_EXE]))
                {
                    return 0;
                }
                else
                {
                    return (Int32)SessionProxy.DbProperties.Rows[0][TEX_EXE];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][TEX_EXE] = value;
            }
        }

        // Allocation Row Index
        public Int32 AllocRowIndex
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][ALLOCROWINDEX]))
                {
                    return 0;
                }
                else
                {
                    return (Int32)SessionProxy.DbProperties.Rows[0][ALLOCROWINDEX];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][ALLOCROWINDEX] = value;
            }
        }

        // Allocation Row Index
        public Int32 InitStartWithTranCd
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][INITSTARTWITHTRANCD]))
                {
                    return 0;
                }
                else
                {
                    return (Int32)SessionProxy.DbProperties.Rows[0][INITSTARTWITHTRANCD];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][INITSTARTWITHTRANCD] = value;
            }
        }

        // Warehouse
        public Int32 WareCol
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][WARECOL]))
                {
                    return 0;
                }
                else
                {
                    return (Int32)SessionProxy.DbProperties.Rows[0][WARECOL];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][WARECOL] = value;
            }
        }


        // VAmt
        public Decimal VAmt
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][VAMT]))
                {
                    return 0;
                }
                else
                {
                    return (Decimal)SessionProxy.DbProperties.Rows[0][VAMT];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][VAMT] = value;
            }
        }

        // VchrAmt
        public Decimal VchrAmt
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][VCHRAMT]))
                {
                    return 0;
                }
                else
                {
                    return (Decimal)SessionProxy.DbProperties.Rows[0][VCHRAMT];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][VCHRAMT] = value;
            }
        }

        // From A/c amt.
        public Decimal FromAcAmt
        {
            get
            {
                if (DBNull.Value.Equals(SessionProxy.DbProperties.Rows[0][FROMACAMT]))
                {
                    return 0;
                }
                else
                {
                    return (Decimal)SessionProxy.DbProperties.Rows[0][FROMACAMT];
                }
            }
            set
            {
                SessionProxy.DbProperties.Rows[0][FROMACAMT] = value;
            }
        }

    }
}
