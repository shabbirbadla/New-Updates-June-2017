using System;
using System.Collections.Generic;
using System.Text;
using System.Data; 

namespace Business.Logic.Layer
{
    public class xtraSetValue<myType>
    {
        public myType SetDefaultValue(DataRowView xtraRow, string fldName, DataRow data_vw)
        {
            myType defaValue;
            try
            {   
                defaValue = ((myType)(Convert.DBNull.Equals(data_vw[fldName.Trim()]) ? DateTime.MinValue : data_vw[fldName.Trim()]));
            }
            catch (InvalidCastException Ex)
            {
                throw new InvalidCastException(fldName.Trim() + " default value is not proper," + Ex.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception(Ex.Message);
            }
            return defaValue;
        }

        public myType SetDefaultValue(DataRowView xtraRow, string fldName)
        {
            myType defaValue;
            try
            {
                defaValue = ((myType)xtraRow["defa_val"]);
            }
            catch (InvalidCastException Ex)
            {
                throw new InvalidCastException(fldName.Trim() + " default value is not proper," + Ex.Message.Trim());
            }
            catch (Exception Ex)
            {
                throw new Exception(Ex.Message);
            }
            return defaValue;
        }
    }
}
