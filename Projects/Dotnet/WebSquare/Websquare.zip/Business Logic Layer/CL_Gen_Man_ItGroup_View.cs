using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using Data.Acess.Layer;  

namespace Business.Logic.Layer
{
    public class CL_Gen_Man_ItGroup_View:CL_Gen_Ent_ItGroup_view,ICommonBLL  
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        #region enum Declaration
        public enum ItGroup_RowNameSelect : int
        {
            select = 0,
            it_group_name,
            itgroup,
            itgrid,
            type
        }
        #endregion

        #region ICommonBLL Events Members
        public void Select()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Insert()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Update()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Delete()
        {
            DataTier m_Obj_Dal = new DataTier();
            SqlCommand m_Obj_Cmd = new SqlCommand();
            try
            {
                m_Obj_Cmd = m_Obj_Dal.ExecuteNonQuery(m_Obj_Cmd, "sp_ent_web_AcGroup_Delete", "SP", true, ref connHandle);
                m_Obj_Cmd.Parameters.AddWithValue("@ac_group_id", Itgroup);
                m_Obj_Cmd.ExecuteNonQuery();
                m_Obj_Dal.CommitTransaction(m_Obj_Cmd.Transaction);
            }
            catch (SqlException Ex)
            {
                throw m_Obj_Dal.SqlExceptionErrorsTraping(Ex);
            }
            catch (Exception Ex)
            {
                m_Obj_Dal.RollBackTransaction(m_Obj_Cmd.Transaction);
                m_Obj_Dal.Connclose(connHandle);
                throw Ex;
            }
            finally
            {
                m_Obj_Cmd.Dispose();
                m_Obj_Dal.Connclose(connHandle);
                m_Obj_Dal = null;
            }
        }
        #endregion

        #region Public Events
        public List<CL_Gen_Ent_ItGroup_Grid_Columns> GetAllRows()
        {
            List<CL_Gen_Ent_ItGroup_Grid_Columns> m_Lst_ItGroup_view;
            SqlParameter[] spParam = new SqlParameter[5];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@startIndex";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = StartIndex;

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@pageSize";
            spParam[1].SqlDbType = SqlDbType.Int;
            spParam[1].Value = PageSize;

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@sortBy";
            spParam[2].SqlDbType = SqlDbType.NVarChar;
            spParam[2].Value = SortBy;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@searchtext";
            spParam[3].SqlDbType = SqlDbType.NVarChar;
            spParam[3].Value = Searchtext;

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@totRecOUT";
            spParam[4].SqlDbType = SqlDbType.Int;
            spParam[4].Value = 0;
            spParam[4].Direction = ParameterDirection.Output;

            DataSet m_ds_ItGroup_view = new DataSet();
            DataTier m_obj_DAL = new DataTier();
            m_obj_DAL.DataBaseName = SessionProxy.DbName;

            m_ds_ItGroup_view = m_obj_DAL.ExecuteDataset(m_ds_ItGroup_view,
                                    "sp_ent_web_ItGroup_view",
                                    spParam, null,connHandle);
            m_obj_DAL.Connclose(connHandle);
 
            TotalRec = Convert.ToInt32(spParam[4].Value);

            m_Lst_ItGroup_view = ConvertorTransactionList(m_ds_ItGroup_view);
            return m_Lst_ItGroup_view;
        }
        #endregion

        #region Private Events
        private List<CL_Gen_Ent_ItGroup_Grid_Columns> ConvertorTransactionList(DataSet m_ds_ItGroup_view)
        {
            getDateFormat DateFormat = new getDateFormat();
            if (m_ds_ItGroup_view == null || m_ds_ItGroup_view.Tables.Count == 0)
                throw new ArgumentException("DataSet is null or empty.", "General Leder Master");

            List<CL_Gen_Ent_ItGroup_Grid_Columns> m_List = new List<CL_Gen_Ent_ItGroup_Grid_Columns>();

            try
            {
                foreach (DataRow TranRow in m_ds_ItGroup_view.Tables[0].Rows)
                {
                    ArrayList arr = new ArrayList();
                    CL_Gen_Ent_ItGroup_Grid_Columns m_Grd_col = new CL_Gen_Ent_ItGroup_Grid_Columns();
                    m_Grd_col.ChkSelect = Convert.ToBoolean(TranRow[(int)ItGroup_RowNameSelect.select]);
                    m_Grd_col.It_group_name = Convert.ToString(TranRow[(int)ItGroup_RowNameSelect.it_group_name]);
                    m_Grd_col.Itgrid = TranRow[(int)ItGroup_RowNameSelect.itgrid] == null ? 0 : Convert.ToInt32(TranRow[(int)ItGroup_RowNameSelect.itgrid]);
                    m_Grd_col.Itgroup = Convert.ToString(TranRow[(int)ItGroup_RowNameSelect.itgroup]);
                    m_Grd_col.Type = Convert.ToString(TranRow[(int)ItGroup_RowNameSelect.type]);
                    m_List.Add(m_Grd_col);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Error occur while parsing dataset into Transaction List. Error Detail: {0} {1} ", Environment.NewLine, ex.Message));
            }
            return m_List;
        }
        #endregion

    }
}
