using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using Data.Acess.Layer;    

namespace Business.Logic.Layer
{    
    public class vuAccountPosting
    {
        stringFunction strFunction = new stringFunction();
        vuGenerateNo GenerateSeialItNo = new vuGenerateNo();
        getDateFormat DateFormat = new getDateFormat();
        SqlConnection connHandle;

        //private static DataTier DataAcess = new DataTier();
        //private static getTables addRecord = new getTables();
        private string SqlStr = "";

        private string errorMessage;
        public string ErrorMessage
        {
          get { return errorMessage; }
          set { errorMessage = value; }
        }

        private Int32 account_id;
        public Int32 Account_id
        {
            get { return account_id; }
            set { account_id = value; }
        }

        private string account_name;
        public string Account_name
        {
            get { return account_name; }
            set { account_name = value; }
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        public vuAccountPosting()
        {
        }

        public void AccountPosting(DataSet MainDataSet, 
                    TextBox txtItemTotal, 
                    TextBox txtNetAmount, 
                    TextBox txtAccNetAmount,
                    bool itemPage, 
                    bool ChargesPage,
                    bool accountPage,
                    string vchkProd, 
                    string pcvType, 
                    string beHave, 
                    string howtoCalculateExAmt, 
                    bool SalesTaxItem,
                    ref SqlConnection connTran)
        {
            try
            {
                DataTable lcode_vw = MainDataSet.Tables["lcode_vw"];
                DataTable main_vw = MainDataSet.Tables["main_vw"];
                DataTable item_vw = MainDataSet.Tables["item_vw"];
                DataTable acdet_vw = MainDataSet.Tables["acdet_vw"];
                DataTable coadditional = MainDataSet.Tables["manufact"];
                DataTable company = MainDataSet.Tables["company"];
                DataTable tax_vw = MainDataSet.Tables["tax_vw"];

                string debitAccount = "";
                string creditAccount = "";

                if (Convert.ToString(lcode_vw.Rows[0]["defa_db"]).Trim() != "")
                {
                    debitAccount = findAccountName(Convert.ToString(lcode_vw.Rows[0]["defa_db"]).Trim(), main_vw, item_vw,ref connTran);
                }

                if (Convert.ToString(lcode_vw.Rows[0]["defa_cr"]).Trim() != "")
                {
                    creditAccount = findAccountName(Convert.ToString(lcode_vw.Rows[0]["defa_cr"]).Trim(), main_vw, item_vw,ref connTran);
                }

                if (debitAccount.Trim() == "" && creditAccount.Trim() == "")
                {
                    return;
                }

                decimal GrossAmount = 0;
                if (itemPage == true)
                {
                    GrossAmount = Convert.ToDecimal(txtItemTotal.Text);
                }
                else
                {
                    GrossAmount = Convert.ToDecimal(main_vw.Rows[0]["gro_amt"]);
                }

                if (vchkProd.Trim().IndexOf("vuexc") >= 0 && Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "MODVATABLE")
                {
                    if (pcvType.ToString().Trim() == "ST" || beHave.ToString().Trim() == "ST")
                    {
                        if (Convert.ToString(coadditional.Rows[0]["paydays"]).Trim().ToUpper() == "DAILY")
                        {
                            GrossAmount = GrossAmount - Convert.ToDecimal(main_vw.Rows[0]["Tot_Examt"]);
                        }
                    }
                }

                // call method for posting
                defaultPosting(GrossAmount, debitAccount.Trim(), creditAccount.Trim(), acdet_vw, main_vw, item_vw,ref connTran);
                bool PostItem = false;

                if (itemPage == true)
                {
                    if ((strFunction.InList(pcvType.Trim(), new string[2] { "ST", "SR" }) == true ||
                        strFunction.InList(beHave.Trim(), new string[2] { "ST", "SR" }) == true) &&
                        Convert.ToBoolean(company.Rows[0]["s_item"]) == true)
                    {
                        PostItem = true;
                    }

                    if ((strFunction.InList(pcvType.Trim(), new string[2] { "PT", "PR" }) == true ||
                        strFunction.InList(beHave.Trim(), new string[2] { "PT", "PR" }) == true) &&
                        Convert.ToBoolean(company.Rows[0]["p_item"]) == true)
                    {
                        PostItem = true;
                    }
                }

                if (PostItem == true)
                {
                    // Method is not available 
                    throw new Exception("Itemwise Account posting Under construction");

                }
                else
                {
                    // Call Charges Method
                    Charges(debitAccount.Trim(), creditAccount.Trim(), MainDataSet, pcvType, beHave,
                                          vchkProd, howtoCalculateExAmt, SalesTaxItem,ref connTran);
                }

                if (ChargesPage == true)
                {
                    // Call Fcharges Method
                    Fcharges(tax_vw, acdet_vw, main_vw, item_vw, pcvType.Trim(), beHave.Trim(),
                             creditAccount.Trim(), debitAccount.Trim(),ref connTran);
                }

                // Called below method for Roundig off
                if ((strFunction.InList(pcvType.Trim(), new string[2] { "ST", "SR" }) == true ||
                    strFunction.InList(beHave.Trim(), new string[2] { "ST", "SR" }) == true) &&
                    Convert.ToBoolean(company.Rows[0]["snet_op"]) == true &&
                    Convert.ToString(company.Rows[0]["sac_round"]).Trim() != "")
                {
                    string roundingAccount = findAccountName(Convert.ToString(company.Rows[0]["sac_round"]), main_vw, item_vw,ref connTran);
                    Rounding(roundingAccount.Trim(), debitAccount.Trim(), creditAccount.Trim(), main_vw, acdet_vw, item_vw, pcvType.Trim(),
                             beHave.Trim(), txtNetAmount, txtAccNetAmount, itemPage, accountPage);
                }

                if ((strFunction.InList(pcvType.Trim(), new string[2] { "PT", "PR" }) == true ||
                    strFunction.InList(beHave.Trim(), new string[2] { "PT", "PR" }) == true) &&
                    Convert.ToBoolean(company.Rows[0]["pnet_op"]) == true &&
                    Convert.ToString(company.Rows[0]["pac_round"]).Trim() != "")
                {
                    string roundingAccount = findAccountName(Convert.ToString(company.Rows[0]["pac_round"]), main_vw, item_vw,ref connTran);
                    Rounding(roundingAccount.Trim(), debitAccount.Trim(), creditAccount.Trim(), main_vw, acdet_vw, item_vw, pcvType.Trim(),
                             beHave.Trim(), txtNetAmount, txtAccNetAmount, itemPage, accountPage);
                }

                // End

                // Check Amount difference
                
                vuCheckDbCrBalance CheckdbcrBalance = new vuCheckDbCrBalance();
                try
                {
                    CheckdbcrBalance.DbCrBalanceCheck(acdet_vw, true);
                }
                catch (SqlException Ex)
                {
                    throw Ex;
                }
            }
            catch (Exception Ex)
            {
                connTran.Close();
                connTran.Dispose();
                throw new Exception(" ERROR found in AccountPosting void Method |" + Ex.Message.Trim()); 
            }
        }

        public void Rounding(string roundingAccount, 
                             string debitAccount, 
                             string creditAccount, 
                             DataTable main_vw, 
                             DataTable acdet_vw, 
                             DataTable item_vw, 
                             string pcvType, 
                             string beHave, 
                             TextBox txtNetAmount, 
                             TextBox txtAccNetAmount, 
                             bool itemPage,
                             bool accountPage)
        {
            try
            {
                if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                    strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                {
                    // Call Rounding Sub method for Debit account
                    Rounding_Sub(roundingAccount.Trim(), debitAccount.Trim(), creditAccount.Trim(), debitAccount.Trim(), main_vw, item_vw,
                                 acdet_vw, pcvType.Trim(), beHave.Trim(), txtNetAmount, txtAccNetAmount, itemPage, accountPage);
                }
                else
                {
                    // Call Rounding Sub method for Credit account
                    Rounding_Sub(roundingAccount.Trim(), debitAccount.Trim(), creditAccount.Trim(), creditAccount.Trim(), main_vw, item_vw,
                                 acdet_vw, pcvType.Trim(), beHave.Trim(), txtNetAmount, txtAccNetAmount, itemPage, accountPage);
                } // End pcvType = "ST","PR"
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in Rounding method |" + Ex.Message.Trim());
            }
        }

        //<Summary>//
        // This Below method call from Rounding Method//
        protected void Rounding_Sub(string roundingAccount, string debitAccount, string creditAccount, string SubAccount, DataTable main_vw, DataTable item_vw, DataTable acdet_vw, string pcvType, string beHave, TextBox txtNetAmount, TextBox txtAccNetAmount,bool itemPage,bool accountPage)
        {
            try
            {
                DataRow Acdetvw_Row_Round = acdet_vw.Select("ac_name = '" + SubAccount.Trim() + "'")[0];
                decimal mAmount = Convert.ToDecimal(Acdetvw_Row_Round["Amount"]);
                decimal roundAmount = Math.Round(mAmount, 0);
                decimal roundoffDiff = roundAmount - mAmount;
                string acType = "";
                if (roundoffDiff > 0)
                {
                    if (roundoffDiff < 0)
                    {
                        if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                            strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                        {
                            acType = "DR";
                        }
                        else
                        {
                            acType = "CR";
                        }
                    }
                    else
                    {
                        if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                            strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                        {
                            acType = "CR";
                        }
                        else
                        {
                            acType = "Dr";
                        }
                    } // End roundoffDiff < 0

                    try
                    {
                        DataRow Acdetvw_Row = acdet_vw.Select("ac_name ='" + roundingAccount.Trim() + "'")[0];
                        if (Convert.ToDecimal(Acdetvw_Row["Amount"]) == 0)
                        {
                            Acdetvw_Row["Amount"] = Math.Abs(roundoffDiff);
                            Acdetvw_Row["amt_ty"] = acType.Trim();
                            Acdetvw_Row["Memo_OP"] = false;
                        }
                        else
                        {
                            Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) + Math.Abs(roundoffDiff);
                            Acdetvw_Row["Memo_OP"] = false;

                        } // End Acdetvw_Row["Amount"] = 0

                        // minus amount
                        if (Convert.ToDecimal(Acdetvw_Row["Amount"]) < 0)
                        {
                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                            if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                            {
                                Acdetvw_Row["amt_ty"] = "CR";
                            }
                            else
                            {
                                Acdetvw_Row["amt_ty"] = "DR";
                            }
                        }
                        Acdetvw_Row.AcceptChanges();
                    }
                    catch
                    {
                        // if not find row in ac_det the add new record

                        if (roundingAccount.ToString().Trim() != Account_name.ToString().Trim())
                        {
                            findAccountName('"' + roundingAccount.Trim() + '"', main_vw, item_vw,ref connHandle);

                        }

                        string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acserial", false, 0).Trim().PadLeft(5,'0');
                        DataRow Acdetvw_Row;
                        Acdetvw_Row = acdet_vw.NewRow();
                        Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                        Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                        Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                        Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                        //Acdetvw_Row["amount"] = Convert.ToDecimal(mAmount);
                        Acdetvw_Row["amount"] = Math.Abs(roundoffDiff);
                        Acdetvw_Row["amt_ty"] = acType.Trim();
                        Acdetvw_Row["ac_name"] = Account_name.Trim();
                        Acdetvw_Row["ac_id"] = Account_id;
                        Acdetvw_Row["memo_op"] = false;
                        Acdetvw_Row["acSerial"] = acSerial; 
                        
                        // Check field exist or not in ac_det table
                        if (Acdetvw_Row.Table.Columns.Contains("PostOrd") == true)     
                        {
                            Acdetvw_Row["PostOrd"] = "Z";
                        }  // end

                        // minus amount
                        if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                        {
                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                            if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                            {
                                Acdetvw_Row["amt_ty"] = "CR";
                            }
                            else
                            {
                                Acdetvw_Row["amt_ty"] = "DR";
                            }
                        }
                        acdet_vw.Rows.Add(Acdetvw_Row);
                        acdet_vw.AcceptChanges();
                    } // End TRY

                    if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                        strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                    {
                        try // Search record in acdet_vw
                        {
                            DataRow Acdetvw_Row = acdet_vw.Select("ac_name = '" + debitAccount.Trim() + "'")[0];
                            Acdetvw_Row["Amount"] = roundAmount;
                            Acdetvw_Row["Memo_op"] = false;

                            if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                            {
                                Acdetvw_Row["Amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["Amount"]));
                                if (Convert.ToString(Acdetvw_Row["Amt_Ty"]) == "DR")
                                {
                                    Acdetvw_Row["Amt_Ty"] = "DR";
                                }
                                else
                                {
                                    Acdetvw_Row["Amt_Ty"] = "CR";
                                }
                            }

                            Acdetvw_Row.AcceptChanges();  
                        }
                        catch
                        {
                        } // End Try

                    }
                    else
                    {
                        try // Search record in acdet_vw
                        {
                            DataRow Acdetvw_Row = acdet_vw.Select("ac_name = '" + creditAccount.Trim() + "'")[0];
                            Acdetvw_Row["Amount"] = roundAmount;
                            Acdetvw_Row["Memo_op"] = false;

                            if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                            {
                                Acdetvw_Row["Amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["Amount"]));
                                if (Convert.ToString(Acdetvw_Row["Amt_Ty"]) == "DR")
                                {
                                    Acdetvw_Row["Amt_Ty"] = "DR";
                                }
                                else
                                {
                                    Acdetvw_Row["Amt_Ty"] = "CR";
                                }
                            }
                            Acdetvw_Row.AcceptChanges();  
                        }
                        catch
                        {
                        } // End Try
                    }

                } // End roundoffDiff > 0

                try  // check round off field exist in main_vw
                {
                    main_vw.Rows[0]["roundoff"] = roundoffDiff;
                }
                catch
                {
                }
                main_vw.Rows[0]["net_amt"] = roundAmount;
                main_vw.AcceptChanges(); // update changes in main_vw  
                acdet_vw.AcceptChanges();  // update all changes in acdet_vw table  
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in Rounding_Sub method |" + Ex.Message.Trim());
            }  // End main try

            // update TextBox of Net Amount
            if (itemPage == true)
            {
                txtNetAmount.Text = Convert.ToString(main_vw.Rows[0]["net_amt"]);
            }

            if (accountPage == true)
            {
                txtAccNetAmount.Text = Convert.ToString(main_vw.Rows[0]["net_amt"]);
            }

        }

        public void Fcharges(DataTable tax_vw, 
                DataTable acdet_vw, 
                DataTable main_vw, 
                DataTable item_vw,
                string pcvType, 
                string beHave,
                string creditAccount,
                string debitAccount,
                ref SqlConnection connTran)
        {
            try
            {
                foreach (DataRow Taxvw_Row in tax_vw.Rows)
                {
                    string fieldName = Convert.ToString(Taxvw_Row["fld_nm"]).Trim();
                    string mA_s = Convert.ToString(Taxvw_Row["a_s"]).Trim();
                    if (fieldName.Trim() != "" || Convert.ToBoolean(Taxvw_Row["att_file"]) == false)
                    {
                        string acType = "";
                        if (strFunction.InList(Convert.ToString(Taxvw_Row["Code"]), new string[2] { "D", "F" }) == true)
                        {
                            if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                                strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                            {
                                acType = mA_s =="+" ? "CR" :"DR";
                            }
                            else
                            {
                                acType = mA_s =="+" ? "DR" :"CR";
                            }
                        }  // End Tax_vw code = {"D","F"}
                        else
                        {
                            if (strFunction.InList(pcvType.Trim(), new string[4] {"ST", "PR","SB","SD" }) == true ||
                               strFunction.InList(beHave.Trim(), new string[4] {"ST", "PR", "SB", "SD" }) == true)
                            {
                                acType = mA_s == "-" ? "DR" : "CR";
                            }
                            else
                            {
                                acType = mA_s == "-" ? "CR" : "DR";
                            }
                        } // End Tax_vw code = {"D","F"}


                        decimal mAmount = 0;
                        mAmount = Convert.ToDecimal(main_vw.Rows[0][fieldName.Trim()]);
                        string mExclNet = "";
                        DataRow Acdetvw_Row = null;

                        if (mAmount > 0)
                        {
                            string AccountNm = findAccountName(Convert.ToString(Taxvw_Row["dac_name"]).Trim(), main_vw, item_vw,ref connTran);
                            if (AccountNm.Trim() != "")
                            {
                                try
                                {
                                    Acdetvw_Row = acdet_vw.Select("ac_name ='" + AccountNm.Trim() + "'")[0];
                                    if (acType.Trim() != Convert.ToString(Acdetvw_Row["Amt_ty"]).Trim())
                                    {
                                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["Memo_Op"] = false;
                                    }
                                    else
                                    {
                                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["Memo_Op"] = false;
                                    }
                                }
                                catch
                                {
                                    // if not find row in ac_det the add new record

                                    if (AccountNm.ToString().Trim() != Account_name.ToString().Trim())
                                    {
                                        findAccountName('"' + AccountNm.Trim() + '"', main_vw, item_vw,ref connTran);

                                    }
                                    string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acserial", false, 0).Trim().PadLeft(5, '0');
                                    Acdetvw_Row = acdet_vw.NewRow();
                                    Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                                    Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                                    Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                                    Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                                    Acdetvw_Row["amount"] = Convert.ToDecimal(mAmount);
                                    Acdetvw_Row["amt_ty"] = acType.Trim();
                                    Acdetvw_Row["ac_name"] = Account_name.Trim();
                                    Acdetvw_Row["ac_id"] = Account_id;
                                    Acdetvw_Row["memo_op"] = false;
                                    Acdetvw_Row["acserial"] = acSerial;

                                    // Check field exist or not in ac_det table
                                    if (Acdetvw_Row.Table.Columns.Contains("PostOrd") == true)
                                    {
                                        Acdetvw_Row["PostOrd"] = "C";
                                    }

                                    acdet_vw.Rows.Add(Acdetvw_Row);
                                } // End TRY

                                // minus amount
                                if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                                {
                                    Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                                    if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                                    {
                                        Acdetvw_Row["amt_ty"] = "CR";
                                    }
                                    else
                                    {
                                        Acdetvw_Row["amt_ty"] = "DR";
                                    }
                                }
                                acdet_vw.AcceptChanges();
                            } // End AccountNm.Trim() != ""

                            AccountNm = "";
                            if (tax_vw.Columns.Contains("cac_name") == true)
                            {
                                AccountNm = findAccountName(Convert.ToString(Taxvw_Row["cac_name"]).Trim(), main_vw, item_vw,ref connTran);
                            }

                            if (AccountNm == "")
                            {
                                if (strFunction.InList(pcvType.Trim(), new string[4] {"ST", "PR", "SB", "SD" }) == true ||
                                strFunction.InList(beHave.Trim(), new string[4] {"ST", "PR", "SB", "SD" }) == true)
                                    AccountNm = debitAccount;
                                else
                                    AccountNm = creditAccount; 
                            }


                            //////////////////////////

                            Acdetvw_Row = null;
                            if (AccountNm.Trim() != "")
                            {
                                try
                                {
                                    Acdetvw_Row = acdet_vw.Select("ac_name ='" + AccountNm.Trim() + "'")[0];
                                }
                                catch
                                {
                                    // if not find row in ac_det the add new record
                                    if (AccountNm.ToString().Trim() != Account_name.ToString().Trim())
                                    {
                                        findAccountName('"' + AccountNm.Trim() + '"', main_vw, item_vw,ref connTran);
                                    }
                                    string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acserial", false, 0).Trim().PadLeft(5, '0');
                                    Acdetvw_Row = acdet_vw.NewRow();
                                    Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                                    Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                                    Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                                    Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                                    Acdetvw_Row["amount"] = Convert.ToDecimal(mAmount);
                                    Acdetvw_Row["amt_ty"] = acType.Trim();
                                    Acdetvw_Row["ac_name"] = Account_name.Trim();
                                    Acdetvw_Row["ac_id"] = Account_id;
                                    Acdetvw_Row["memo_op"] = false;
                                    Acdetvw_Row["acserial"] = acSerial;
                                    // Check field exist or not in ac_det table
                                    if (Acdetvw_Row.Table.Columns.Contains("PostOrd") == true)
                                    {
                                        Acdetvw_Row["PostOrd"] = "C";
                                    }
                                    acdet_vw.Rows.Add(Acdetvw_Row);
                                } // End TRY

                                if (mExclNet.Trim() == "")
                                {
                                    if (acType.Trim() == Convert.ToString(Acdetvw_Row["Amt_ty"]).Trim())
                                    {
                                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["Memo_Op"] = false;
                                    }
                                    else
                                    {
                                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["Memo_Op"] = false;
                                    }
                                }
                                else
                                {
                                    if (acType.Trim() == Convert.ToString(Acdetvw_Row["Amt_ty"]).Trim())
                                    {
                                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["Memo_Op"] = false;
                                    }
                                    else
                                    {
                                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["Memo_Op"] = false;
                                    }

                                } // End mExclNet = ""
                                // minus amount
                                if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                                {
                                    Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                                    if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                                    {
                                        Acdetvw_Row["amt_ty"] = "CR";
                                    }
                                    else
                                    {
                                        Acdetvw_Row["amt_ty"] = "DR";
                                    }
                                }
                                acdet_vw.AcceptChanges();
                            } // End AccountNm.Trim() != ""
                            ///////////////////////////
                        } // End (mAmount > 0)
                    }
                    acdet_vw.AcceptChanges(); // update all changes in acdet_vw table  
                } // End foreach of tax_vw
            }
            catch (Exception Ex)
            {
                connTran.Close();
                connTran.Dispose();
                throw new Exception("ERROR found in Fcharges method |" + Ex.Message.Trim());
            }

        }

        public void Charges(string debitAccount, 
                    string creditAccount, 
                    DataSet MainDataSet, 
                    string pcvType, 
                    string beHave, 
                    string vchkProd, 
                    string howtoCalculateExAmt, 
                    bool SalesTaxItem,
                    ref SqlConnection connTran)
        {
            try
            {
                DataTable main_vw = MainDataSet.Tables["main_vw"];
                DataTable item_vw = MainDataSet.Tables["item_vw"];
                DataTable acdet_vw = MainDataSet.Tables["acdet_vw"];
                DataTable dcmast_vw = MainDataSet.Tables["dcmast_vw"];
                DataTable company = MainDataSet.Tables["company"];
                DataTable coadditional = MainDataSet.Tables["manufact"];
                DataTable stax_vw = MainDataSet.Tables["stax_vw"];

                foreach (DataRow dcmast_Row in dcmast_vw.Select("att_file = 0"))
                {
                    string FieldName = Convert.ToString(dcmast_Row["fld_nm"]);
                    string mA_s = Convert.ToString(dcmast_Row["a_s"]);

                    if (FieldName.Trim() != "")
                    {
                        if ((vchkProd.Trim().IndexOf("vuexc") <= -1 &&
                            Convert.ToString(main_vw.Rows[0]["Rule"]) != "MODVATABLE") &&
                            Convert.ToString(dcmast_Row["code"]).Trim() != "E" &&
                            (pcvType.Trim() != "ST" || beHave.Trim() != "ST") &&
                            (Convert.ToString(coadditional.Rows[0]["Daily"]).Trim().ToUpper() != "DAILY") &&
                            howtoCalculateExAmt.Trim() != "I")
                        {

                            string acType = "";
                            if (strFunction.InList(Convert.ToString(dcmast_Row["Code"]).Trim(), new string[2] { "D", "F" }) == true)
                            {
                                // for Plus Sign
                                if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                                    strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                                {
                                    if (mA_s.Trim() == "+") // if "DR"
                                    {
                                        acType = "CR";
                                    }
                                    else
                                    {
                                        acType = "DR";
                                    }
                                }
                                else
                                {
                                    if (mA_s.Trim() == "+") // if "CR"
                                    {
                                        acType = "DR";
                                    }
                                    else
                                    {
                                        acType = "CR";
                                    }

                                } // END check pcvtype = {"ST","PR"}
                            }
                            else
                            {
                                // for Minus Sign
                                if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                                    strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                                {
                                    if (mA_s.Trim() == "-") // if "DR"
                                    {
                                        acType = "DR";
                                    }
                                    else
                                    {
                                        acType = "CR";
                                    }
                                }
                                else
                                {
                                    if (mA_s.Trim() == "-") // if "CR"
                                    {
                                        acType = "CR";
                                    }
                                    else
                                    {
                                        acType = "DR";
                                    }

                                } // END check pcvtype = {"ST","PR"}

                            } // End check dcmast code {"D","F"}

                            decimal mAmount = 0;
                            string mExcl_Gross = "";

                            // check field in dc_mast
                            if (dcmast_Row.Table.Columns.Contains("Excl_Gross") == true)
                            {
                                if (Convert.ToString(dcmast_Row["Excl_Gross"]).Trim() != "")
                                {
                                    mExcl_Gross = Convert.ToString(dcmast_Row["Excl_Gross"]).Trim();
                                }
                            }  // end field check

                            if (vchkProd.Trim().IndexOf("vuexc") >= 0 &&
                                Convert.ToString(dcmast_Row["code"]).Trim() == "E" &&
                                (pcvType.Trim() == "ST" || beHave.Trim() == "ST"))
                            {
                                if (Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().ToUpper() == "DEALER")
                                {
                                    mExcl_Gross = "G";
                                }
                            }

                            mAmount = (decimal)item_vw.Compute("SUM(" + FieldName.Trim() + ")", "");

                            if (mAmount > 0)
                            {
                                string AccountNm = "";
                                AccountNm = findAccountName(Convert.ToString(dcmast_Row["dac_name"]).Trim(), main_vw, item_vw,ref connTran);
                                if (AccountNm.Trim() != "")
                                {
                                    try
                                    {
                                        // find row in ac_det
                                        DataRow Acdetvw_Row = acdet_vw.Select("ac_name = '" + AccountNm.ToString().Trim() + "'")[0];

                                        if (acType.Trim() != Convert.ToString(Acdetvw_Row["Amt_ty"]).Trim())
                                        {
                                            Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                            Acdetvw_Row["Memo_Op"] = false;
                                        }
                                        else
                                        {
                                            Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                            Acdetvw_Row["Memo_Op"] = false;
                                        }

                                        // minus amount
                                        if (Convert.ToDecimal(Acdetvw_Row["Amount"]) < 0)
                                        {
                                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                                            if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                                            {
                                                Acdetvw_Row["amt_ty"] = "CR";
                                            }
                                            else
                                            {
                                                Acdetvw_Row["amt_ty"] = "DR";
                                            }
                                        }
                                        Acdetvw_Row.AcceptChanges();
                                    }
                                    catch
                                    {
                                        // if not find row in ac_det the add new record

                                        if (AccountNm.ToString().Trim() != Account_name.ToString().Trim())
                                        {
                                            findAccountName('"' + AccountNm + '"', main_vw, item_vw,ref connTran);

                                        }

                                        string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acserial", false, 0).Trim().PadLeft(5, '0');

                                        DataRow Acdetvw_Row;
                                        Acdetvw_Row = acdet_vw.NewRow();
                                        Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                                        Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                                        Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                                        Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                                        Acdetvw_Row["amount"] = Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["amt_ty"] = acType.Trim();
                                        Acdetvw_Row["ac_name"] = Account_name.Trim();
                                        Acdetvw_Row["ac_id"] = Account_id;
                                        Acdetvw_Row["memo_op"] = false;
                                        Acdetvw_Row["acserial"] = acSerial;

                                        // Check field exist or not in ac_det table
                                        if (Acdetvw_Row.Table.Columns.Contains("PostOrd") == true)
                                        {
                                            Acdetvw_Row["PostOrd"] = "B";
                                        }

                                        // minus amount
                                        if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                                        {
                                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                                            if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                                            {
                                                Acdetvw_Row["amt_ty"] = "CR";
                                            }
                                            else
                                            {
                                                Acdetvw_Row["amt_ty"] = "DR";
                                            }
                                        }
                                        acdet_vw.Rows.Add(Acdetvw_Row);
                                        acdet_vw.AcceptChanges();
                                    } // End TRY

                                } // End AccountNm.Trim() !=""

                                if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true)
                                {
                                    try // find credit account name exist in acdet_vw table
                                    {
                                        DataRow Acdet_Row = acdet_vw.Select("ac_name = '" + creditAccount.Trim() + "'")[0];

                                        if (mExcl_Gross == "")
                                        {
                                            if (acType.Trim() != Convert.ToString(Acdet_Row["Amt_ty"]).Trim())
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }
                                            else
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }
                                        }
                                        else
                                        {
                                            if (acType.Trim() != Convert.ToString(Acdet_Row["Amt_ty"]).Trim())
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }
                                            else
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }

                                        } // End mExcl_Gross = ""

                                        if (Convert.ToDecimal(Acdet_Row["Amount"]) < 0)
                                        {
                                            Acdet_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdet_Row["amount"]));
                                            if (Convert.ToString(Acdet_Row["amt_ty"]) == "DR")
                                            {
                                                Acdet_Row["amt_ty"] = "CR";
                                            }
                                            else
                                            {
                                                Acdet_Row["amt_ty"] = "DR";
                                            }
                                        }
                                        Acdet_Row.AcceptChanges();
                                    }
                                    catch
                                    {

                                    }  // End find debit account name exist in acdet_vw table
                                }
                                else
                                {
                                    try // find debit account name exist in acdet_vw table
                                    {
                                        DataRow Acdet_Row = acdet_vw.Select("ac_name = '" + debitAccount.Trim() + "'")[0];
                                        if (mExcl_Gross == "")
                                        {
                                            if (acType.Trim() != Convert.ToString(Acdet_Row["Amt_ty"]).Trim())
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }
                                            else
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }
                                        }
                                        else
                                        {
                                            if (acType.Trim() != Convert.ToString(Acdet_Row["Amt_ty"]).Trim())
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) - Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }
                                            else
                                            {
                                                Acdet_Row["Amount"] = Convert.ToDecimal(Acdet_Row["Amount"]) + Convert.ToDecimal(mAmount);
                                                Acdet_Row["Memo_Op"] = false;
                                            }

                                        } // End mExcl_Gross = ""

                                        if (Convert.ToDecimal(Acdet_Row["Amount"]) < 0)
                                        {
                                            Acdet_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdet_Row["amount"]));
                                            if (Convert.ToString(Acdet_Row["amt_ty"]) == "DR")
                                            {
                                                Acdet_Row["amt_ty"] = "CR";
                                            }
                                            else
                                            {
                                                Acdet_Row["amt_ty"] = "DR";
                                            }
                                        }

                                        Acdet_Row.AcceptChanges();
                                    }
                                    catch
                                    {

                                    } // End find debit account name exist in acdet_vw table

                                }// End Pcvtype = "ST","PR"
                            } // End mAmount > 0

                        } // End Daily Checking
                    }
                    acdet_vw.AcceptChanges(); // update all changes in acdet_vw table  
                }  // End for each dcmast

                // Itemwise SaleTax
                if (SalesTaxItem == true)
                {
                    string acType = "";
                    if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "SR" }) == true ||
                        strFunction.InList(beHave.Trim(), new string[2] { "ST", "SR" }) == true)
                    {
                        acType = "CR";
                    }
                    else
                    {
                        acType = "DR";
                    }

                    // loop for item_vw
                    foreach (DataRow Item_Row in item_vw.Rows)
                    {
                        decimal mAmount = Convert.ToDecimal(Item_Row["taxAmt"]);
                        if (mAmount > 0)
                        {
                            try  // Search record in Stax_vw
                            {
                                string Account_Nm = "";
                                DataRow Stax_Row = stax_vw.Select("tax_name ='" + Convert.ToString(Item_Row["tax_name"]).Trim() + "'")[0];
                                if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "SR" }) == true ||
                                    strFunction.InList(beHave.Trim(), new string[2] { "ST", "SR" }) == true)
                                {
                                    Account_Nm = findAccountName(Convert.ToString(Stax_Row["ac_name1"]).Trim(), main_vw, item_vw,ref connTran);
                                }
                                else
                                {
                                    Account_Nm = findAccountName(Convert.ToString(Stax_Row["ac_name3"]).Trim(), main_vw, item_vw,ref connTran);
                                }

                                if (Account_Nm.Trim() != "")
                                {
                                    try // Search record in Acdet_vw
                                    {
                                        DataRow Acdetvw_Row = acdet_vw.Select("ac_name ='" + Account_Nm.Trim() + "'")[0];
                                        Acdetvw_Row["amount"] = Convert.ToDecimal(Acdetvw_Row["amount"]) + Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["memo_op"] = false;

                                        if (Convert.ToDecimal(Acdetvw_Row["Amount"]) < 0)
                                        {
                                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["Amount"]));

                                            if (Convert.ToString(Acdetvw_Row["Amt_Ty"]).Trim() == "DR")
                                            {
                                                Acdetvw_Row["amt_ty"] = "CR";
                                            }
                                            else
                                            {
                                                Acdetvw_Row["amt_ty"] = "DR";
                                            }
                                        }

                                        Acdetvw_Row.AcceptChanges();
                                    }
                                    catch
                                    {
                                        if (Account_Nm.ToString().Trim() != Account_name.ToString().Trim())
                                        {
                                            findAccountName('"' + Account_Nm.Trim() + '"', main_vw, item_vw,ref connTran);
                                        }
                                        string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acserial", false, 0).Trim().PadLeft(5, '0');
                                        DataRow Acdetvw_Row;
                                        Acdetvw_Row = acdet_vw.NewRow();
                                        Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                                        Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                                        Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                                        Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                                        Acdetvw_Row["amount"] = Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["amt_ty"] = acType.Trim();
                                        Acdetvw_Row["ac_name"] = Account_name.Trim();
                                        Acdetvw_Row["ac_id"] = Account_id;
                                        Acdetvw_Row["memo_op"] = false;
                                        Acdetvw_Row["acSerial"] = acSerial;

                                        // Check field exist or not in ac_det table
                                        if (Acdetvw_Row.Table.Columns.Contains("PostOrd") == true)
                                        {
                                            Acdetvw_Row["PostOrd"] = "B";
                                        }


                                        if (Convert.ToDecimal(Acdetvw_Row["Amount"]) < 0)
                                        {
                                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["Amount"]));

                                            if (Convert.ToString(Acdetvw_Row["Amt_Ty"]).Trim() == "DR")
                                            {
                                                Acdetvw_Row["amt_ty"] = "CR";
                                            }
                                            else
                                            {
                                                Acdetvw_Row["amt_ty"] = "DR";
                                            }
                                        }

                                        acdet_vw.Rows.Add(Acdetvw_Row);
                                        acdet_vw.AcceptChanges();
                                    }
                                } // End (Account_Nm.Trim() != ""

                                if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PR" }) == true ||
                                    strFunction.InList(beHave.Trim(), new string[2] { "ST", "PR" }) == true)
                                {
                                    try
                                    {
                                        DataRow Acdetvw_Row = acdet_vw.Select("ac_name ='" + creditAccount.Trim() + "'")[0];
                                        Acdetvw_Row["amount"] = Convert.ToDecimal(Acdetvw_Row["amount"]) - Convert.ToDecimal(mAmount);
                                        Acdetvw_Row["memo_op"] = false;

                                        if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                                        {
                                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["Amount"]));

                                            if (Convert.ToString(Acdetvw_Row["Amt_Ty"]).Trim() == "DR")
                                            {
                                                Acdetvw_Row["amt_ty"] = "CR";
                                            }
                                            else
                                            {
                                                Acdetvw_Row["amt_ty"] = "DR";
                                            }
                                        }
                                        Acdetvw_Row.AcceptChanges();
                                    }
                                    catch
                                    {
                                    }

                                } // End pcvtype or behave = {"ST","PR"}

                            }
                            catch
                            {
                            }// End // Search record in Stax_vw
                        }
                    }
                    acdet_vw.AcceptChanges(); // update all changes in acdet_vw table  
                }

            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in Charges method |" + Ex.Message.Trim()); 
            }
        }

        public void defaultPosting(decimal mAmount, 
                    string debitAccount, 
                    string creditAccount,
                    DataTable acdet_vw,
                    DataTable main_vw,
                    DataTable item_vw,
                    ref SqlConnection connTran)
        {
            try
            {
                if (mAmount == 0)
                {
                    acdet_vw.Clear();
                    acdet_vw.AcceptChanges();
                    return;
                }

                if (acdet_vw.Rows.Count > 0)
                {
                    foreach (DataRow acdetvw_Row in acdet_vw.Select("Memo_op = 0"))
                    {
                        acdetvw_Row["Amount"] = 0;
                    }
                    acdet_vw.AcceptChanges();
                }


                // for Debit account
                if (debitAccount.Trim() != "")
                {
                    try
                    {
                        // find row in ac_det
                        DataRow Acdetvw_Row = acdet_vw.Select("ac_name = '" + debitAccount.ToString().Trim() + "'")[0];

                        // convert boolean value if it is null
                        if (Convert.IsDBNull(Acdetvw_Row["memo_op"]))
                        {
                            Acdetvw_Row["memo_op"] = false;
                        }

                        if (Convert.ToBoolean(Acdetvw_Row["memo_op"]) == false)
                        {
                            Acdetvw_Row["amt_ty"] = "DR";
                        }
                        else
                        {
                            Acdetvw_Row["amt_ty"] = Convert.ToString(Acdetvw_Row["amt_ty"]);
                        }
                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) + Convert.ToDecimal(mAmount);
                        Acdetvw_Row["Memo_Op"] = false;

                        // minus amount
                        if (Convert.ToDecimal(Acdetvw_Row["Amount"]) < 0)
                        {
                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                            if (Convert.ToString(Acdetvw_Row["amt_ty"]).Trim() == "DR")
                            {
                                Acdetvw_Row["amt_ty"] = "CR";
                            }
                            else
                            {
                                Acdetvw_Row["amt_ty"] = "DR";
                            }
                        }

                        Acdetvw_Row.AcceptChanges();
                    }
                    catch
                    {
                        // if not find row in ac_det the add new record

                        if (debitAccount.ToString().Trim() != Account_name.ToString().Trim())
                        {
                            findAccountName('"' + debitAccount + '"', main_vw, item_vw,ref connTran);

                        }
                        string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acserial", false, 0).Trim().PadLeft(5, '0');

                        DataRow Acdetvw_Row;
                        Acdetvw_Row = acdet_vw.NewRow();
                        Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                        Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                        Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                        Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                        Acdetvw_Row["amount"] = Convert.ToDecimal(mAmount);
                        Acdetvw_Row["amt_ty"] = "DR";
                        Acdetvw_Row["ac_name"] = Account_name.Trim();
                        Acdetvw_Row["ac_id"] = Account_id;
                        Acdetvw_Row["memo_op"] = false;
                        Acdetvw_Row["acserial"] = acSerial;

                        // Check field exist or not in ac_det table
                        if (Acdetvw_Row.Table.Columns.Contains("PostOrd") == true)
                        {
                            if (Convert.ToString(main_vw.Rows[0]["party_nm"]) ==
                                Convert.ToString(Acdetvw_Row["ac_name"]))
                            {
                                Acdetvw_Row["PostOrd"] = "A";
                            }
                            else
                            {
                                Acdetvw_Row["PostOrd"] = "B";
                            }
                        } // end

                        // minus amount
                        if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                        {
                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                            if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                            {
                                Acdetvw_Row["amt_ty"] = "CR";
                            }
                            else
                            {
                                Acdetvw_Row["amt_ty"] = "DR";
                            }
                        }
                        acdet_vw.Rows.Add(Acdetvw_Row);
                        acdet_vw.AcceptChanges();
                    }
                } // End debitAccount.Trim() != ""

                // for credit account
                if (creditAccount.Trim() != "")
                {
                    try
                    {
                        // find row in ac_det
                        DataRow Acdetvw_Row = acdet_vw.Select("ac_name = '" + creditAccount.ToString().Trim() + "'")[0];

                        // convert boolean value if it is null
                        if (Convert.IsDBNull(Acdetvw_Row["memo_op"]))
                        {
                            Acdetvw_Row["memo_op"] = false;
                        }

                        if (Convert.ToBoolean(Acdetvw_Row["memo_op"]) == false)
                        {
                            Acdetvw_Row["amt_ty"] = "CR";
                        }
                        else
                        {
                            Acdetvw_Row["amt_ty"] = Convert.ToString(Acdetvw_Row["amt_ty"]);
                        }
                        Acdetvw_Row["Amount"] = Convert.ToDecimal(Acdetvw_Row["Amount"]) + Convert.ToDecimal(mAmount);
                        Acdetvw_Row["Memo_Op"] = false;

                        // minus amount
                        if (Convert.ToDecimal(Acdetvw_Row["Amount"]) < 0)
                        {
                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                            if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                            {
                                Acdetvw_Row["amt_ty"] = "CR";
                            }
                            else
                            {
                                Acdetvw_Row["amt_ty"] = "DR";
                            }
                        }

                        Acdetvw_Row.AcceptChanges();
                    }
                    catch
                    {
                        // if not find row in ac_det the add new record

                        if (creditAccount.ToString().Trim() != Account_name.ToString().Trim())
                        {
                            findAccountName('"' + creditAccount + '"', main_vw, item_vw,ref connTran);
                        }

                        string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acserial", false, 0).Trim().PadLeft(5, '0');

                        DataRow Acdetvw_Row;
                        Acdetvw_Row = acdet_vw.NewRow();
                        Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                        Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                        Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                        Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                        Acdetvw_Row["amount"] = Convert.ToDecimal(mAmount);
                        Acdetvw_Row["amt_ty"] = "CR";
                        Acdetvw_Row["ac_name"] = Account_name.Trim();
                        Acdetvw_Row["ac_id"] = Account_id;
                        Acdetvw_Row["memo_op"] = false;
                        Acdetvw_Row["acSerial"] = acSerial;

                        // Check field exist or not in ac_det table
                        if (Acdetvw_Row.Table.Columns.Contains("PostOrd") == true)
                        {
                            if (Convert.ToString(main_vw.Rows[0]["party_nm"]) ==
                                Convert.ToString(Acdetvw_Row["ac_name"]))
                            {
                                Acdetvw_Row["PostOrd"] = "A";
                            }
                            else
                            {
                                Acdetvw_Row["PostOrd"] = "B";
                            }
                        } // end

                        // minus amount
                        if (Convert.ToDecimal(Acdetvw_Row["amount"]) < 0)
                        {
                            Acdetvw_Row["amount"] = Math.Abs(Convert.ToDecimal(Acdetvw_Row["amount"]));
                            if (Convert.ToString(Acdetvw_Row["amt_ty"]) == "DR")
                            {
                                Acdetvw_Row["amt_ty"] = "CR";
                            }
                            else
                            {
                                Acdetvw_Row["amt_ty"] = "DR";
                            }
                        }
                        acdet_vw.Rows.Add(Acdetvw_Row);
                        acdet_vw.AcceptChanges();
                    }
                } // End creditAccount.Trim() != ""

                acdet_vw.AcceptChanges(); // update all changes in acdet_vw table
            }
            catch (Exception Ex)
            {
                throw new Exception(" ERROR found in defaultposting Method |" + Ex.Message.Trim());  
            }
        }

        private SqlCommand cmdTran;
        public SqlCommand CmdTran
        {
            get { return cmdTran; }
            set { cmdTran = value; }
        }

        public string findAccountName(string lcodedefaAc,
                        DataTable main_vw,
                        DataTable item_vw,
                        ref SqlConnection connTran)
        {
            try
            {
                if (lcodedefaAc.ToString().Trim() != "")
                {
                    string accountName = "";
                    accountName = lcodedefaAc.ToString().Trim();


                    if (accountName.Trim().IndexOf("'") >= 0 || accountName.Trim().IndexOf('"') >= 0)
                    {
                        if (accountName.Trim().IndexOf("'") >= 0)
                        {
                            accountName = accountName.Remove(accountName.IndexOf("'"), 1);
                            accountName = accountName.Remove(accountName.LastIndexOf("'"), 1);
                        }
                        else
                        {
                            if (accountName.Trim().IndexOf('"') >= 0)
                            {
                                accountName = accountName.Remove(accountName.IndexOf('"'), 1);
                                accountName = accountName.Remove(accountName.LastIndexOf('"'), 1);
                            }
                        }

                    }
                    else
                    {
                        try
                        {
                            if (accountName.Trim().IndexOf('.') >= 0)
                            {
                                string DataTableName, DataFieldName = "";
                                DataTableName = accountName.Trim().Substring(0, accountName.Trim().IndexOf("."));
                                DataFieldName = accountName.Trim().Substring(accountName.Trim().IndexOf(".") + 1, (accountName.Length - accountName.Trim().IndexOf(".")) - 1);

                                if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                                {
                                    accountName = Convert.ToString(main_vw.Rows[0][DataFieldName]).Trim();
                                }
                                else
                                {
                                    if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                    {
                                        accountName = Convert.ToString(item_vw.Rows[0][DataFieldName]).Trim();
                                    }
                                    else
                                    {
                                        //ErrorMessage = "Other than Main_vw or Item_vw table in lcode default debit or credit not allowed.";
                                        throw new Exception("Other than Main_vw or Item_vw table in lcode default debit or credit not allowed.");
                                    }
                                }
                            }
                            else
                            {
                                throw new Exception("Default Account Posting is not Proper defined in lcode");
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }

                    }

                    SqlDataReader dr;
                    accountName = accountName.PadRight(Convert.ToString(main_vw.Rows[0]["Party_nm"]).Length, ' ');
                    SqlStr = "select top 1 ac_id,ac_name from ac_mast where ac_name = '" + accountName.Trim() + "'";

                    DataTier DataAcess = new DataTier();
                    DataAcess.DataBaseName = SessionProxy.DbName;

                    dr = DataAcess.ExecuteDataReader(SqlStr, CmdTran, ref connTran);
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            Account_id = Convert.ToInt32(dr["ac_id"]);
                            Account_name = Convert.ToString(dr["ac_name"]);
                        }
                    }
                    else
                    {
                        Account_id = 0;
                        Account_name = "";
                    }
                    dr.Close();
                    dr.Dispose();

                    if (Account_name == null)
                    {
                        if (Account_name.Trim() == "")
                        {
                            throw new Exception("Account Name not found..!!!");
                        }
                    }

                }
                else
                {
                    Account_name = "";
                }
            }
            catch (Exception Ex)
            {
                throw new Exception(" ERROR found in findAccountName method |" + Ex.Message.Trim());
            }
            return Account_name;  
        }

        public void defaacposting(DataTable main_vw,
            DataTable lcode_vw,
            DataTable item_vw,
            DataTable acdet_vw,
            string isChoice,
            ref SqlConnection connTran)
        {
            string debitaccount = "";
            string creditaccount = "";

            if (Convert.ToString(lcode_vw.Rows[0]["defa_db"]).Trim() != "")
            {
                if (isChoice != null)
                {
                    // for Openning Balance Transaction
                    if (isChoice.Trim().ToUpper() == "TRUE")
                    {
                        debitaccount = findAccountName("MAIN_VW.PARTY_NM", main_vw, item_vw,ref connTran);
                    }
                    else
                    {
                        if (isChoice.Trim().ToUpper() == "FALSE")
                        {
                            debitaccount = findAccountName(Convert.ToString(lcode_vw.Rows[0]["defa_cr"]).Trim(), 
                                                main_vw, 
                                                item_vw,
                                                ref connTran);
                        }
                    }
                }
                else
                {
                    debitaccount = findAccountName(Convert.ToString(lcode_vw.Rows[0]["defa_db"]).Trim(), 
                                                    main_vw, 
                                                    item_vw,ref connTran);
                }
            }

            if (debitaccount.Trim() != "")
            {
                if (debitaccount.Trim() != Account_name.ToString().Trim())
                {
                    findAccountName(debitaccount.Trim(), main_vw, item_vw,ref connTran);                       
                }

                // call add effect method
                addtoEffect(acdet_vw, main_vw, Convert.ToDecimal(main_vw.Rows[0]["net_amt"]), "DR", Account_name.Trim(), Account_id);
                Account_id = 0;
                Account_name = "";
            }

            if (Convert.ToString(lcode_vw.Rows[0]["defa_cr"]).Trim() != "")
            {
                if (isChoice != null)
                {
                    if (isChoice.Trim().ToUpper() == "FALSE")
                    {
                        creditaccount = findAccountName("MAIN_VW.PARTY_NM", main_vw, item_vw,ref connTran);
                    }
                    else
                    {
                        if (isChoice.Trim().ToUpper() == "TRUE")
                        {
                            creditaccount = findAccountName(Convert.ToString(lcode_vw.Rows[0]["defa_cr"]).Trim(), main_vw, item_vw,ref connTran);
                        }
                    }
                }
                else
                {
                    creditaccount = findAccountName(Convert.ToString(lcode_vw.Rows[0]["defa_cr"]).Trim(), main_vw, item_vw,ref connTran);
                }
            }

            if (creditaccount.Trim() != "")
            {
                if (creditaccount.Trim() != Account_name.ToString().Trim())
                {
                    findAccountName(creditaccount.Trim(), main_vw, item_vw,ref connTran);                       
                }

                // call add effect method
                addtoEffect(acdet_vw, main_vw, Convert.ToDecimal(main_vw.Rows[0]["net_amt"]), "CR", Account_name.Trim(), Account_id);
                Account_id = 0;
                Account_name = "";
            }


            foreach (DataRow acDetRow in acdet_vw.Select("ac_name = '' or amount = 0"))
            {
                acDetRow.Delete();
                acDetRow.AcceptChanges();
            }

         
        }

        public void addtoEffect(DataTable acdet_vw,DataTable main_vw,decimal netAmt,string acType,string acName,int acId)
        {
            if (acName.Trim() != "")
            {
                try
                {
                    DataRow AcDetRow;
                    AcDetRow = acdet_vw.Select("ac_name = '" + acName.Trim() + "' and amt_ty = '" + acType.Trim() + "'")[0];
                    AcDetRow["ac_name"] = acName.Trim();
                    AcDetRow["ac_id"] = acId;
                    AcDetRow["amt_ty"] = acType.Trim();
                    AcDetRow["amount"] = netAmt;
                    AcDetRow["memo_op"] = false;
                    AcDetRow.AcceptChanges();
                }
                catch
                {
                    // Generate AcSerial No.
                    string acSerial = GenerateSeialItNo.GenerateNo(acdet_vw, "acSerial", false, 0).Trim().PadLeft(5,'0');

                    DataRow Acdetvw_Row;
                    Acdetvw_Row = acdet_vw.NewRow();
                    Acdetvw_Row["tran_cd"] = Convert.ToInt32(main_vw.Rows[0]["tran_cd"]);
                    Acdetvw_Row["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
                    Acdetvw_Row["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                    Acdetvw_Row["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                    Acdetvw_Row["amount"] = Convert.ToDecimal(netAmt);
                    Acdetvw_Row["amt_ty"] = acType.Trim();
                    Acdetvw_Row["ac_name"] = acName.Trim();
                    Acdetvw_Row["ac_id"] = acId;
                    Acdetvw_Row["acSerial"] = acSerial;

                    if (acdet_vw.Columns.Contains("postOrd") == true)
                    {
                        Acdetvw_Row["PostOrd"] = "X";
                    }
                    acdet_vw.Rows.Add(Acdetvw_Row);
                    acdet_vw.AcceptChanges(); 
                 }
                 acdet_vw.AcceptChanges();
            }
        }

        public decimal sumeffect(DataTable acdet_vw,DataTable company,string pcvType,string beHave)
        {
            decimal balAmt = 0;
            decimal dbAmt = 0;
            decimal crAmt = 0;
            try
            {

                numericFunction numFunction = new numericFunction();
                dbAmt = numFunction.toDecimal(acdet_vw.Compute("SUM(Amount)", "amt_ty = 'DR'"));
                crAmt = numFunction.toDecimal(acdet_vw.Compute("SUM(Amount)", "amt_ty = 'CR'"));
                balAmt = crAmt - dbAmt;

                if (balAmt < 1)
                {
                    if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "SR" }) == true)
                    {
                        if (Convert.ToBoolean(company.Rows[0]["snet_op"]) == true)
                        {
                            balAmt = Math.Round(crAmt, 0) - Math.Round(dbAmt, 0);
                        }
                    }

                    if (strFunction.InList(pcvType.Trim(), new string[2] { "PT", "PR" }) == true)
                    {
                        if (Convert.ToBoolean(company.Rows[0]["pnet_op"]) == true)
                        {
                            balAmt = Math.Round(crAmt, 0) - Math.Round(dbAmt, 0);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in Sumeffect method |" + Ex.Message.Trim());
            }

            return balAmt;
        }
    }
}
