using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Data.Acess.Layer; 

namespace Business.Logic.Layer
{
    public class getCompany
    {
        public getCompany()
        {
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        public DataSet Company(DataSet DS,string RequestCode,string Year)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
            DS = _datatier.ExecuteDataset(DS,"select * from servicetax..co_mast where requestcode = '" + RequestCode.ToString().Trim() + "' and [year] = '" + Year.ToString().Trim() + "'", "Company",connHandle);
            _datatier.Connclose(connHandle);
            return DS;

            
        }

        public DataTable Company(string RequestCode, string Year)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            string sqlStr = "select * from servicetax..co_mast where requestcode = '" + RequestCode.ToString().Trim() + "' and [year] = '" + Year.ToString().Trim() + "'";
            DataTable companyVw = _datatier.ExecuteDataTable(sqlStr, "Company",connHandle);
            _datatier.Connclose(connHandle); 
            return companyVw;
        }   
    }
}
