using System;
using System.Collections.Generic;
using System.Text;
using System.Data;


namespace Business.Logic.Layer
{
    public class vuCheckDbCrBalance
    {

        public vuCheckDbCrBalance()
        {
        }

        public string DbCrBalanceCheck(DataTable acdet_vw,bool RemoveBlankAmt)
        {
            string WarningMess = "";

            try
            {
                decimal mDebit = 0;
                decimal mCredit = 0;

                if (RemoveBlankAmt == true)
                {
                    try
                    {
                        DataRow removeRow;
                        removeRow = acdet_vw.Select("ac_name = '' or amount <= 0")[0];
                        removeRow.Delete();
                        removeRow.AcceptChanges();
                        acdet_vw.AcceptChanges();
                    }
                    catch
                    {
                    }
                }

                if (acdet_vw.Rows.Count > 0)
                {
                    numericFunction numFunction = new numericFunction();
                    mDebit = numFunction.toDecimal(acdet_vw.Compute("SUM(Amount)", "amt_ty = 'DR'"));
                    mCredit = numFunction.toDecimal((decimal)acdet_vw.Compute("SUM(Amount)", "amt_ty = 'CR'"));
                }
                else
                {
                    mDebit = 0;
                    mCredit = 0;
                }

                if (mDebit != mCredit)
                {
                    WarningMess = "Amount difference " + Convert.ToString(mDebit - mCredit).Trim();
                }
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in DbCrBalanceCheck " + Ex.Message.Trim()); 
            }

            return WarningMess; 
        }
    }
}
