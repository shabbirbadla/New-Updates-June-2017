using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;   
using Data.Acess.Layer;      

namespace Business.Logic.Layer
{
    public class vuInit 
    {
        public vuInit()
        {
            ErrorMessage = "";
        }

        private string SqlStr = "";
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private SqlConnection connHandle;
        
        public void AddNew(DataTable main_vw,
                    DataTable lcode_vw,
                    DataTable company,
                    string entry_Tbl,
                    string pcvType)
                    
        {
            getDateFormat DateFormat = new getDateFormat();
            // Check null value
            if (System.Convert.IsDBNull(lcode_vw.Rows[0]["web_bk_dated"]))
            {
                LbackDated = false;
            }
            else
            {
                LbackDated = !System.Convert.ToBoolean(Convert.ToInt32(lcode_vw.Rows[0]["web_bk_dated"])); // Store value in Public properties
            }

            if (System.Convert.IsDBNull(lcode_vw.Rows[0]["cur_date"]))
            {
                LTodaySDate = false;
            }
            else
            {
                LTodaySDate = System.Convert.ToBoolean(lcode_vw.Rows[0]["cur_date"]);// Store value in Public properties
            }

            SqlDataReader Dr;
            if (LbackDated == true)
            {
                SqlParameter[] spParam = new SqlParameter[2];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@pcvtype";
                spParam[0].SqlDbType = SqlDbType.VarChar;
                spParam[0].Value = pcvType.Trim(); 

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@entryTbl";
                spParam[1].SqlDbType = SqlDbType.VarChar;
                spParam[1].Value = entry_Tbl.Trim();
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                Dr = DataAcess.ExecuteDataReader("sp_ent_web_getback_InvDate",spParam, ref connHandle);
                while (Dr.Read())
                {
                    PBackDated = DateFormat.TodateTime(Dr["Date"]);
                }
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle);
            }

            stringFunction strFunc = new stringFunction();
            getTables AddRec = new getTables();
            getServerDate appServerDate = new getServerDate();
            getNullUpdate dataNullUpdate = new getNullUpdate();
            string tDocNo = "";
            tDocNo = strFunc.Right(UniqueID(),5);  // Generate Doc no from Unique ID

            //AddRec.AppendBlankRec(main_vw);   

            // add blank record in main_vw
            DataRow Mainvw_Row;
            Mainvw_Row = main_vw.NewRow();
            Mainvw_Row = dataNullUpdate.NullUpdate(Mainvw_Row);  // null update 

            Mainvw_Row["entry_ty"] = pcvType.ToString().Trim();

            if (LTodaySDate == true ||
                ((PBackDated >= DateTime.MinValue && PBackDated <= DateTime.MaxValue) ||
                 (PBackDated <= Convert.ToDateTime("01/01/1900"))))
            {
                Mainvw_Row["date"] = appServerDate.ServerDate();
            }
            else
            {
                Mainvw_Row["date"] = PBackDated;
            }

            Mainvw_Row["doc_no"] = tDocNo.ToString().Trim();
            main_vw.Rows.Add(Mainvw_Row); // add new row in main_vw    
            main_vw.AcceptChanges(); 
            UpdateFinYear(main_vw, company, main_vw); // Update financial year in l_yn according Transaction Date
        }

        public string UpdateFinYear(DataTable company, DataRow mainRow)
        {
            string ctrlYear = "";
            //string endDate, startDate = "";
            string[] endDate = new string[13];
            string[] startDate = new string[13];
            getDateFormat DateFormat = new getDateFormat();

            if (DateFormat.TodateTime(mainRow["date"]) >= DateFormat.TodateTime(company.Rows[0]["sta_dt"]) &&
                DateFormat.TodateTime(mainRow["date"]) <= DateFormat.TodateTime(company.Rows[0]["end_dt"]))
            {
                ctrlYear = DateFormat.TodateTime(company.Rows[0]["sta_dt"]).Year.ToString().Trim() +
                           "-" +
                           DateFormat.TodateTime(company.Rows[0]["end_dt"]).Year.ToString().Trim();

            }
            else
            {
                // end Date
                for (int i = 0; i <= DateFormat.TodateTime(company.Rows[0]["end_dt"]).Month; i++)
                {
                    endDate[i] = i.ToString().Trim();
                }

                // Start Date
                for (int i = DateFormat.TodateTime(company.Rows[0]["sta_dt"]).Month; i <= 12; i++)
                {
                    startDate[i] = i.ToString().Trim();
                }

                stringFunction strFunction = new stringFunction();
                if (strFunction.InList(DateFormat.TodateTime(mainRow["date"]).Month.ToString(), endDate))
                {
                    ctrlYear = System.Convert.ToString(DateFormat.TodateTime(mainRow["date"]).Year - 1).Trim() + "-" + DateFormat.TodateTime(mainRow["date"]).Year.ToString().Trim();
                }
                else
                {
                    if (strFunction.InList(DateFormat.TodateTime(mainRow["date"]).Month.ToString(), startDate))
                    {
                        ctrlYear = (DateFormat.TodateTime(mainRow["date"]).Year).ToString().Trim() + "-" + System.Convert.ToString(DateFormat.TodateTime(mainRow["date"]).Year + 1).Trim();
                    }
                }
            }

            return ctrlYear;
        }

        public DataTable UpdateFinYear(DataTable dtName,DataTable company,DataTable main_vw)
        {
            string ctrlYear = "";
            //string endDate, startDate = "";
            string[] endDate = new string[12];
            string[] startDate = new string[12];
            getDateFormat DateFormat = new getDateFormat();

            if (DateFormat.TodateTime(main_vw.Rows[0]["date"]) >= DateFormat.TodateTime(company.Rows[0]["sta_dt"]) &&
                DateFormat.TodateTime(main_vw.Rows[0]["date"]) <= DateFormat.TodateTime(company.Rows[0]["end_dt"]))
            {
                ctrlYear = DateFormat.TodateTime(company.Rows[0]["sta_dt"]).Year.ToString().Trim() +
                           "-" +
                           DateFormat.TodateTime(company.Rows[0]["end_dt"]).Year.ToString().Trim();

            }
            else
            {
                // end Date
                for (int i = 0; i <= DateFormat.TodateTime(company.Rows[0]["end_dt"]).Month; i++)
                {
                     endDate[i] = i.ToString().Trim();
                }

                // Start Date
                for (int i = DateFormat.TodateTime(company.Rows[0]["sta_dt"]).Month; i <= 12; i++)
                {
                    if (i !=0)
                        startDate[i-1] = i.ToString().Trim();
                    else
                        startDate[i] = i.ToString().Trim();
                }

                stringFunction strFunction = new stringFunction();
                if (strFunction.InList(DateFormat.TodateTime(main_vw.Rows[0]["date"]).Month.ToString(), endDate))
                {
                    ctrlYear = System.Convert.ToString(DateFormat.TodateTime(main_vw.Rows[0]["date"]).Year - 1).Trim() + "-" + DateFormat.TodateTime(main_vw.Rows[0]["date"]).Year.ToString().Trim();
                }
                else
                {
                    if (strFunction.InList(DateFormat.TodateTime(main_vw.Rows[0]["date"]).Month.ToString(), startDate))
                    {
                        ctrlYear = (DateFormat.TodateTime(main_vw.Rows[0]["date"]).Year).ToString().Trim() + "-" + System.Convert.ToString(DateFormat.TodateTime(main_vw.Rows[0]["date"]).Year + 1).Trim();
                    }
                }
            }

            dtName.Rows[0]["l_yn"] = ctrlYear.ToString().Trim();
            dtName.AcceptChanges();
            return dtName; 
        }

        public void txtInvoiceNo_GotFocus(bool addMode,
                bool editMode,
                string entry_Tbl,
                DataTable main_vw,
                DataTable lcode_vw,
                string cntWhat)
        {
            string lentry_ty = Convert.ToString(main_vw.Rows[0]["entry_ty"]);
            string linv_sr = Convert.ToString(main_vw.Rows[0]["inv_sr"]);
            int vNoSize = Convert.ToInt32(lcode_vw.Rows[0]["invno_size"]);
            string visType = "";
            string viPrefix = "";
            string viSuffix = "";
            string viMiddle = "";

            getDateFormat DateFormat = new getDateFormat();
            numericFunction numFunction = new numericFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlParameter[] spParam = new SqlParameter[7];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@invseries";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = Convert.ToString(main_vw.Rows[0]["inv_sr"]).Trim();

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@entry_ty";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@date";
            spParam[2].SqlDbType = SqlDbType.DateTime;
            spParam[2].Value = DateFormat.TodateTime(main_vw.Rows[0]["Date"]);

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@lyn";
            spParam[3].SqlDbType = SqlDbType.VarChar;
            spParam[3].Value = Convert.ToString(main_vw.Rows[0]["l_yn"]).Trim();

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@entryTbl";
            spParam[4].SqlDbType = SqlDbType.VarChar;
            spParam[4].Value =entry_Tbl;

            spParam[5] = new SqlParameter();
            spParam[5].ParameterName = "@mInvoiceNo";
            spParam[5].SqlDbType = SqlDbType.VarChar;
            spParam[5].Value = Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim();

            spParam[6] = new SqlParameter();
            spParam[6].ParameterName = "@autoInv";
            spParam[6].SqlDbType = SqlDbType.Bit;
            spParam[6].Value = Convert.ToBoolean(lcode_vw.Rows[0]["auto_inv"]);

            DataSet DS = new DataSet();
            ArrayList dbList = new ArrayList();
            dbList.Add("Series");
            dbList.Add("NewInv");
            DS = DataAcess.ExecuteDataset(DS,
                                "sp_ent_web_getInvoiceNo",
                                spParam,
                                dbList, connHandle);
            DataAcess.Connclose(connHandle); 
            DataTable tmpTbl_vw = DS.Tables["series"]; 
            if (tmpTbl_vw.Rows.Count > 0  && tmpTbl_vw.Columns.Contains("s_type") == true)
            {
                visType = Convert.ToString(tmpTbl_vw.Rows[0]["s_type"]).Trim();  
            
                if (Convert.ToString(tmpTbl_vw.Rows[0]["i_prefix"]).Trim() != "")
                {
                    viPrefix = Convert.ToString(tmpTbl_vw.Rows[0]["i_prefix"]).Trim();
                }

                if (Convert.ToString(tmpTbl_vw.Rows[0]["i_suffix"]).Trim() != "")
                {
                    viSuffix = Convert.ToString(tmpTbl_vw.Rows[0]["i_suffix"]).Trim();
                }

                switch (visType.Trim())
                {
                    case "DAYWISE":
                        viMiddle = Convert.ToString(DateFormat.TodateTime(main_vw.Rows[0]["Date"]).Day);
                        viMiddle += Convert.ToString(DateFormat.TodateTime(main_vw.Rows[0]["Date"]).Month);
                        viMiddle += Convert.ToString(DateFormat.TodateTime(main_vw.Rows[0]["Date"]).Year).Trim().Substring(2, 2);
                        break; 
                    case "MONTHWISE":
                        viMiddle += Convert.ToString(DateFormat.TodateTime(main_vw.Rows[0]["Date"]).Month);
                        viMiddle += Convert.ToString(DateFormat.TodateTime(main_vw.Rows[0]["Date"]).Year).Trim().Substring(2, 2);
                        break; 
                }
            }

            //if (oldVal != Convert.ToString(main_vw.Rows[0]["inv_sr"]) ||
            //    oldVal == null ||
            //    Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim() == "")
            //{
            if (Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim() == "")
            {
                if (Convert.ToBoolean(lcode_vw.Rows[0]["auto_inv"]) == true)
                {
                    int linv_no = 0;
                    int linvSize = vNoSize;
                    int newinv = 0;
                    linv_no = Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim() != "" ? Convert.ToInt32(main_vw.Rows[0]["inv_no"]) : 0;

                    //switch (visType.Trim())
                    //{
                    //    case "DAYWISE":
                    //        SqlStr = "select top 1 inv_no from gen_inv where entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                    //                 "inv_sr = '" + Convert.ToString(main_vw.Rows[0]["inv_sr"]).Trim() + "' and inv_dt = '" + DateFormat.dateformat(Convert.ToString(main_vw.Rows[0]["Date"])) + "'";

                    //        dr = DataAcess.ExecuteDataReader(SqlStr);
                    //        while (dr.Read())
                    //        {
                    //            newinv = Convert.ToInt32(dr["inv_no"]);
                    //        }
                    //        dr.Close();
                    //        dr.Dispose();
                    //        break;
                    //    case "MONTHWISE":
                    //        SqlStr = "select top 1 inv_no from gen_inv where entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                    //                 "inv_sr = '" + Convert.ToString(main_vw.Rows[0]["inv_sr"]).Trim() + "' and Month(inv_dt) = " + Convert.ToDateTime(main_vw.Rows[0]["Date"]).Month +
                    //                 "year(inv_dt) = " + Convert.ToDateTime(main_vw.Rows[0]["Date"]).Year;

                    //        dr = DataAcess.ExecuteDataReader(SqlStr);
                    //        while (dr.Read())
                    //        {
                    //            newinv = Convert.ToInt32(dr["inv_no"]);
                    //        }
                    //        dr.Close();
                    //        dr.Dispose();
                    //        break;
                    //    default:
                    //        SqlStr = "select top 1 inv_no from gen_inv where entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                    //                 "inv_sr = '" + Convert.ToString(main_vw.Rows[0]["inv_sr"]).Trim() + "' and l_yn = '" + Convert.ToString(main_vw.Rows[0]["l_yn"]) + "'";

                    //        dr = DataAcess.ExecuteDataReader(SqlStr);
                    //        while (dr.Read())
                    //        {
                    //            newinv = Convert.ToInt32(dr["inv_no"]);
                    //        }
                    //        dr.Close();
                    //        dr.Dispose(); 

                    //        string sqlMain = entry_Tbl + "Main";

                    //        SqlStr = "select top 1 inv_no from " + sqlMain.Trim() + " where entry_ty+inv_sr+l_yn  = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() +
                    //                 Convert.ToString(main_vw.Rows[0]["inv_sr"]).Trim() +
                    //                 Convert.ToString(main_vw.Rows[0]["l_yn"]).Trim() + "' order by entry_ty+inv_sr+inv_no+l_yn desc";

                    //        dr = DataAcess.ExecuteDataReader(SqlStr);

                    //        while (dr.Read())
                    //        {
                    //            int minvNo = 0;
                    //            try
                    //            {
                    //                minvNo = Convert.ToInt32(dr["inv_no"]);
                    //            }
                    //            catch
                    //            {

                    //            }

                    //            if (minvNo > newinv)
                    //            {
                    //                newinv = Convert.ToInt32(dr["inv_no"]);
                    //            }
                    //        }
                    //        dr.Close();
                    //        dr.Dispose(); 
                    //        break;
                    //}

                    linv_no = numFunction.toInt32(DS.Tables["NewInv"].Rows[0]["NewInvNo"]); 

                    if (cntWhat == "SERIES")
                    {
                        main_vw.Rows[0]["inv_no"] = Convert.ToString(linv_no + 1).Trim().PadLeft(linvSize, '0');
                    }
                    else
                    {
                        if (editMode == true)
                        {
                            main_vw.Rows[0]["inv_no"] = Convert.ToString(linv_no).Trim().PadLeft(linvSize, '0');
                        }
                        else
                        {
                            main_vw.Rows[0]["inv_no"] = Convert.ToString(linv_no + 1).Trim().PadLeft(linvSize, '0');
                        }
                    }
                    main_vw.AcceptChanges(); 
                }
            }
            else
            {
                if (Convert.ToBoolean(lcode_vw.Rows[0]["auto_inv"]) == true)
                {
                    string vInvoiceNo = Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim();
                    vInvoiceNo = vInvoiceNo.Substring(viSuffix.Length + viPrefix.Length + viSuffix.Length == 0 || viPrefix.Length == 0?0:1);
                    vInvoiceNo = vInvoiceNo.Substring(0,vInvoiceNo.Length-viSuffix.Length);
                    main_vw.Rows[0]["inv_no"] = vInvoiceNo;
                    main_vw.AcceptChanges(); 
                }
            }
            DS.Dispose();
        }

        private string errorMessage;

        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

        public string txtInvoiceNo_LostFocus(bool addMode, bool editMode, string pcvType,string beHave,string entry_Tbl,DataTable main_vw, DataTable lcode_vw, string oldVal,string thisValue,string lblCaption)
        {
                    
            if (Convert.ToBoolean(lcode_vw.Rows[0]["auto_inv"]) == true)
            {
                thisValue = thisValue.Replace(" ", "");  
            }

            if (Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim() == "")
            {
                ErrorMessage = lblCaption.Trim() + " cannot be Empty..!!!";
                return ""; 
            }

            if ((thisValue.Trim() == "" ? 0 : Convert.ToInt32(thisValue.Trim())) == 0 && Convert.ToBoolean(lcode_vw.Rows[0]["auto_inv"]) == true)
            {
                ErrorMessage = "ERROR, Invalid Entry...!!!";
                return ""; 
            }

            int vNoSize = Convert.ToInt32(lcode_vw.Rows[0]["invno_size"]);
            string visType = ""; 
            string viPrefix = "";
            string viSuffix = "";
            string viMiddle = "";

            SqlDataReader dr;
            DataTable tmpTbl_vw;
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlStr = "select top 1 * from series where inv_sr = '" + Convert.ToString(main_vw.Rows[0]["inv_sr"]) + "'";    
            
            tmpTbl_vw = DataAcess.ExecuteDataTable(SqlStr, "tmpTbm_vw",connHandle);
            DataAcess.Connclose(connHandle); 

            if (tmpTbl_vw.Rows.Count > 0 && tmpTbl_vw.Columns.Contains("s_type") == true)
            {
                visType = Convert.ToString(tmpTbl_vw.Rows[0]["s_type"]).Trim();  
            
                if (Convert.ToString(tmpTbl_vw.Rows[0]["i_prefix"]).Trim() != "")
                {
                    viPrefix = Convert.ToString(tmpTbl_vw.Rows[0]["i_prefix"]).Trim();
                }

                if (Convert.ToString(tmpTbl_vw.Rows[0]["i_suffix"]).Trim() != "")
                {
                    viSuffix = Convert.ToString(tmpTbl_vw.Rows[0]["i_suffix"]).Trim();
                }

                switch (visType.Trim())
                {
                    case "DAYWISE":
                        viMiddle = Convert.ToString(Convert.ToDateTime(main_vw.Rows[0]["Date"]).Day);
                        viMiddle += Convert.ToString(Convert.ToDateTime(main_vw.Rows[0]["Date"]).Month);
                        viMiddle += Convert.ToString(Convert.ToDateTime(main_vw.Rows[0]["Date"]).Year).Trim().Substring(2,2);
                        break; 
                    case "MONTHWISE":
                        viMiddle += Convert.ToString(Convert.ToDateTime(main_vw.Rows[0]["Date"]).Month);
                        viMiddle += Convert.ToString(Convert.ToDateTime(main_vw.Rows[0]["Date"]).Year).Trim().Substring(2, 2);
                        break; 
                }
            }

            if (Convert.ToBoolean(lcode_vw.Rows[0]["auto_inv"]) == true)
            {
                if (thisValue.Trim().Length <= vNoSize)
                {
                    thisValue = thisValue.Trim().PadLeft(vNoSize,'0');   
                }

                if (thisValue.Trim().Length > vNoSize)
                {
                    ErrorMessage = lblCaption.Trim() + " should be of " + Convert.ToString(vNoSize).Trim() + " Digits. Please re-enter..!!!";  
                    return ""; 
                }

                oldVal = oldVal == null?" ":oldVal;
  
                string mval = viPrefix.Trim() + viMiddle.Trim() + thisValue.Trim() + viSuffix.Trim();
                mval = mval.PadRight(Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim().Length,' ');     
                
                if (mval.Trim() != oldVal.Trim())
                {
                    string sqlMain = entry_Tbl.Trim() + "Main";
                    SqlStr = "Select top 1 inv_no from " + sqlMain.Trim() + " where entry_ty ='" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                             " and inv_sr ='" + Convert.ToString(main_vw.Rows[0]["inv_sr"]).Trim() + "'" +
                             " and inv_no ='" + mval.Trim() + "'" + 
                             " and l_yn   ='" + Convert.ToString(main_vw.Rows[0]["l_yn"]).Trim() + "'";

                    dr = DataAcess.ExecuteDataReader(SqlStr,ref connHandle);
   
                    if (dr.HasRows == true)
                    {
                        ErrorMessage = lblCaption.Trim() + " already exists, Please re-enter...!!!";
                        dr.Close();
                        dr.Dispose();
                        DataAcess.Connclose(connHandle);  
                        return ""; 
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);
                }
                thisValue = mval; 
            }
            else
            {
                if (thisValue.Trim().Length > vNoSize)
                {
                    ErrorMessage = lblCaption.Trim() + " should be of " + Convert.ToString(vNoSize).Trim() + " Digits. Please re-enter..!!!";    
                    return ""; 
                }

                oldVal = oldVal ==null?" ":oldVal;
  
                if (thisValue.Trim() != oldVal.Trim())
                {
                    if (pcvType.Trim() == "PT" || beHave.Trim() == "PT")
                    {
                        string sqlMain = entry_Tbl.Trim() + "Main";
                        SqlStr = "select top 1 inv_no from " + sqlMain + " where Entry_ty+Inv_sr+Inv_no+L_yn = '" +
                                  Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + 
                                  Convert.ToString(main_vw.Rows[0]["inv_sr"]).Trim() + 
                                  Convert.ToString(main_vw.Rows[0]["inv_no"]).Trim() + 
                                  Convert.ToString(main_vw.Rows[0]["l_yn"]).Trim() + "'";             

                        dr = DataAcess.ExecuteDataReader(SqlStr, ref connHandle);
                        if (dr.HasRows == true)
                        {
                            ErrorMessage = lblCaption.Trim() + " already exists. Please re-enter..!!!";
                            dr.Close();
                            dr.Dispose();
                            DataAcess.Connclose(connHandle);
                            return ""; 
                        }
                        dr.Close();
                        dr.Dispose();
                        DataAcess.Connclose(connHandle);
                    }
                }
            }

            return thisValue; 
        }

        public string UniqueID()
        {
            string retVal = "";
            SqlDataReader Dr;
            SqlStr = "SELECT substring(rtrim(ltrim(str(RAND( (DATEPART(mm, GETDATE()) * 100000 ) " +
		             " + (DATEPART(ss, GETDATE()) * 1000 )+ DATEPART(ms, GETDATE())) , 20,15))),3,20) as UID";
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            Dr = DataAcess.ExecuteDataReader(SqlStr, ref connHandle);

            while (Dr.Read())
            {
                retVal = System.Convert.ToString(Dr["UID"]); 
            }
            Dr.Close();
            Dr.Dispose();
            DataAcess.Connclose(connHandle);
            return retVal; 
        }

        private DateTime pBackDated;
        public DateTime PBackDated
        {
            get { return pBackDated; }
            set { pBackDated = value; }
        }

        private bool lbackDated;
        public bool LbackDated
        {
            get { return lbackDated; }
            set { lbackDated = value; }
        }
        
        private bool lTodaySDate;
        public bool LTodaySDate
        {
            get { return lTodaySDate; }
            set { lTodaySDate = value; }
        }
 
    }
}
