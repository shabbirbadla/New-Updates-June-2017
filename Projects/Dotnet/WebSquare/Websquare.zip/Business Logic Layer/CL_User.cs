using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class CL_User
    {
      private string _userId;
      private SessionCache _cache;

      public SessionCache Cache
      {
         get { return _cache; }
      }
      
      //used internally to re-create a user from the database
      public CL_User(string userId)
      {
         _userId = userId;
         _cache = new SessionCache(_userId.ToString());
      }
    }
}
