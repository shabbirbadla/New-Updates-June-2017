using System;
using System.Collections.Generic;
using System.Text;
using System.Data; 

namespace Business.Logic.Layer
{
    public class getNullUpdate
    {
        public getNullUpdate()
        {
        }

        public DataRow NullUpdate(DataRow Row)
        {

            for (int i = 0; i < Row.Table.Columns.Count; i++)
            {
                if (Row[i].GetType().Name.Trim().ToUpper() == "DBNULL")
                {
                    switch (Row.Table.Columns[i].DataType.ToString().ToUpper().Trim())
                    {
                        case "SYSTEM.STRING":
                            Row[i] = "";
                            break; 
                        case "SYSTEM.DECIMAL":
                        case "SYSTEM.INT":
                        case "SYSTEM.INT16":
                        case "SYSTEM.INT32":
                        case "SYSTEM.INT64":
                            Row[i] = 0;
                            break;
                        case "SYSTEM.BOOLEAN":
                            Row[i] = false;
                            break;
                        case "SYSTEM.DATETIME":
                            Row[i] = Convert.ToDateTime("1900/01/01"); 
                            break;
                    }
                }
            }
            return Row; 
        }
    }
}
