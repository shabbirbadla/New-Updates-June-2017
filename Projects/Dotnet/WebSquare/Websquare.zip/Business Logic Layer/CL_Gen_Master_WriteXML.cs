using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Data.Acess.Layer;   

namespace Business.Logic.Layer
{
    public class CL_Gen_Master_WriteXML
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private SqlConnection connHandle;

        #region Public Methods
        public DataSet writeXmlDS(string type)
        {
            SqlParameter[] param = { new SqlParameter("@pwhat", SqlDbType.VarChar) };

            param[0].Value = type;

            DataSet Ds = new DataSet();
            ArrayList dblist = new ArrayList();
            if (type == "IT")
                dblist.Add("ITXML");
            else
                if (type == "AC")
                    dblist.Add("ACXML");

            DataTier m_Obj_Dal = new DataTier();
            m_Obj_Dal.DataBaseName = SessionProxy.DbName;

            Ds = m_Obj_Dal.ExecuteDataset(Ds, "sp_ent_web_GenXML",
                                param,
                                dblist,connHandle);

            m_Obj_Dal.Connclose(connHandle);
            return Ds;
        }
        #endregion

    }
}
