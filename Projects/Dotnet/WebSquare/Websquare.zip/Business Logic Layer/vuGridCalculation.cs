using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using Data.Acess.Layer;    
 

namespace Business.Logic.Layer
{
    public class vuGridCalculation
    {
        private stringFunction strFunction = new stringFunction();
        private numericFunction numFunction = new numericFunction();
        private string SqlStr = "";
        private SqlConnection connHandle;

        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        public void gridItemCal(GridView grdItem, DataSet MainDataSet, DataRow item_Row, string pcvType, string beHave, string vchkProd, string howtoCalculateExAmt, bool itemPage, bool chargesPage, bool accountPage, TextBox txtItemTotal, TextBox txtTotalQty, TextBox txtNetAmount, TextBox txtAccNetAmount, bool salesTaxItem,bool addMode,bool editMode)
        {
            DataTable dcmast_vw = MainDataSet.Tables["dcmast_vw"];
            DataTable main_vw = MainDataSet.Tables["main_vw"];
            DataTable item_vw = MainDataSet.Tables["item_vw"];
            DataTable acdet_vw = MainDataSet.Tables["acdet_vw"];
            DataTable coadditional = MainDataSet.Tables["manufact"];
            DataTable company = MainDataSet.Tables["company"];
            DataTable stax_vw = MainDataSet.Tables["stax_vw"];
            DataTable tax_vw = MainDataSet.Tables["tax_vw"];
            DataTable tax_vw1 = MainDataSet.Tables["tax_vw1"];

          
            if (vchkProd.IndexOf("vutex") < 0 && (item_Row.Table.Columns.Contains("u_asseamt") == true) &&
                (strFunction.InList(pcvType.ToString().Trim(), new string[2] { "PT", "ST" }) == true ||
                 strFunction.InList(pcvType.ToString().Trim(), new string[2] { "PT", "ST" }) == true))
            {
                for (int i = 0; i < grdItem.Columns.Count; i++)
                {
                    if (grdItem.Columns[i].AccessibleHeaderText.Trim() == "ASS. VALUE")
                    {
                        if (numFunction.toDecimal(item_Row["Rate"]) == 0 &&
                            numFunction.toDecimal(item_Row["u_asseamt"]) != 0 &&
                            numFunction.toDecimal(item_Row["Qty"]) != 0)
                        {
                            item_Row["Rate"] = numFunction.toDecimal(item_Row["u_asseamt"]) / numFunction.toDecimal(item_Row["Qty"]);
                            item_Row.AcceptChanges();
                            MainDataSet.Tables["item_vw"].AcceptChanges();   
                            break; 

                        }
                    }
                }
            }

            decimal RatePer = 1;
            decimal lnAmount = 0;
            SqlStr = "select top 1 rateper,it_name from it_mast where it_code = " + System.Convert.ToInt32(item_Row["it_code"]);

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlDataReader dr  = DataAcess.ExecuteDataReader(SqlStr,ref connHandle);  
            while (dr.Read())
            {
                RatePer = numFunction.toDecimal(dr["rateper"]);
            }
            dr.Read();
            dr.Close();
            DataAcess.Connclose(connHandle);

            if (RatePer == 0)
                RatePer = 1;

            lnAmount =((numFunction.toDecimal(item_Row["Qty"]) * numFunction.toDecimal(item_Row["Rate"])) / RatePer);
            decimal GrossAmount = 0;
            GrossAmount = ItemWiseTotal(grdItem, item_Row, MainDataSet, vchkProd.Trim(), pcvType.Trim(), beHave.Trim(), lnAmount, howtoCalculateExAmt);
            item_Row["gro_amt"] = GrossAmount;
            if (numFunction.toDecimal(item_Row["gro_amt"]) <= 0)
            {
                item_Row["gro_amt"] = 0;
            }

            SumColumns(main_vw, item_vw, dcmast_vw,tax_vw,tax_vw1, "", "", "", itemPage, chargesPage, accountPage, txtItemTotal, txtTotalQty,
                       txtNetAmount, txtAccNetAmount, howtoCalculateExAmt, vchkProd.Trim(), pcvType.Trim(), beHave.Trim(),addMode,editMode);

            if (accountPage == true)
            {
                // Inherit accountPosting class 
                vuAccountPosting APosting = new vuAccountPosting();
                APosting.AccountPosting(MainDataSet, txtItemTotal, txtNetAmount, txtAccNetAmount,
                                        itemPage, chargesPage, accountPage, vchkProd.Trim(), pcvType.Trim(),
                                        beHave.Trim(), howtoCalculateExAmt, salesTaxItem,ref connHandle);
                DataAcess.Connclose(connHandle);
            }

            //update all datatable and dataset
            main_vw.AcceptChanges();
            item_vw.AcceptChanges();
            if (tax_vw !=null)
                tax_vw.AcceptChanges();
            if (tax_vw1 != null)
                tax_vw1.AcceptChanges();
            if (acdet_vw != null)
                acdet_vw.AcceptChanges();
            if (stax_vw != null) 
                stax_vw.AcceptChanges();
            MainDataSet.AcceptChanges();  
        }

        public decimal ItemWiseTotal(GridView grdItem, DataRow item_Row,DataSet MainDataSet, string vchkProd, string pcvType, string beHave, decimal mAmount, string howtoCalculateExAmt)
        {
            DataTable dcmast_vw = MainDataSet.Tables["dcmast_vw"];
            DataTable main_vw = MainDataSet.Tables["main_vw"];
            DataTable item_vw = MainDataSet.Tables["item_vw"];
            DataTable acdet_vw = MainDataSet.Tables["acdet_vw"];
            DataTable coadditional = MainDataSet.Tables["manufact"];
            DataTable company = MainDataSet.Tables["company"];
            DataTable stax_vw = MainDataSet.Tables["stax_vw"];
            DataTable tax_vw = MainDataSet.Tables["tax_vw"];  

            BoundField Datafld = new BoundField();
            string fldName, fld, mcode, Mexcl_gross = "";
            bool mCalDuty = true; 
            decimal mAvalue = 0;
            mAvalue = mAmount; 
            for (int i = 0; i < grdItem.Columns.Count; i++)  // Read Every Grid Column
            {
                // Next
                if (grdItem.Columns[i].AccessibleHeaderText != "")
                {
                    if (strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText, 2), new string[4] { "S#", "V#", "@#", "%#" }))
                    {
                        if (strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText, 2), new string[1] { "V#" }) == true)
                        {
                            Datafld = grdItem.Columns[i] as BoundField;
                            fld = Datafld.DataField;
                        }
                        else
                        {
                            Datafld = grdItem.Columns[i + 1] as BoundField;
                            fld = Datafld.DataField;
                        }

                        if (fld != "")
                        {
                            mcode = grdItem.Columns[i].AccessibleHeaderText.Trim().Substring(3, 1);
                            if (mcode.ToString().Trim() != "")
                            {
                                fldName = mcode.ToString().Trim().ToUpper() + fld.ToString().Trim().ToUpper() + "I";
                                Mexcl_gross = "";
                                try
                                {
                                    DataRow Row = dcmast_vw.Select("fld_nm = '" + fldName.ToString().Trim() + "'")[0];

                                    // Check Field in Dcmast Table
                                    try
                                    {
                                        if (Row.Table.Columns.Contains("Excl_Gross") == true)  
                                        {
                                            Mexcl_gross = System.Convert.ToString(Row["Excl_Gross"]).Trim();
                                        }
                                    }
                                    catch
                                    {
                                    }
                                    // End
                                    if (mcode.Trim() == "E")
                                    {
                                        if (vchkProd.Trim().IndexOf("vuexc") >= 0 &&
                                           (pcvType.ToString().Trim() == "PT" ||
                                            beHave.ToString().Trim() == "PT"))
                                        {
                                            if (System.Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().IndexOf("DEALER") >= 0)
                                            {
                                                Mexcl_gross = "G";
                                            }
                                        }
                                    }
                                    string mFld_nm, mA_s = "";
                                    mFld_nm = System.Convert.ToString(Row["fld_nm"]).Trim();
                                    if (System.Convert.ToString(Row["a_s"]).Trim() != "")
                                    {
                                        mA_s = System.Convert.ToString(Row["a_s"]).Trim();
                                    }
                                    else
                                    {
                                        if (strFunction.InList(System.Convert.ToString(Row["Code"]).Trim(), new string[2] { "D", "E" }) == true)
                                        {
                                            mA_s = "-";
                                        }
                                        else
                                        {
                                            mA_s = "+";
                                        }
                                    }

                                    if (strFunction.InList(strFunction.Left(grdItem.Columns[i - 1].AccessibleHeaderText, 2), new string[2] { "@#", "%#" }) == true ||
                                        strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText, 2), new string[2] { "@#", "%#" }) == true)
                                    {
                                        if (mCalDuty == true)
                                        {
                                            // Below variable define for evaulate item_vw Field
                                            string mPerName = System.Convert.ToString(Row["Pert_Name"]).Trim();
                                            decimal mPer, mCalAmt, mAmt = 0;
                                            mPer = 0;
                                            mCalAmt = 0;
                                            try  // Check Data Field In Item_vw
                                            {
                                                if (item_Row.Table.Columns.Contains(mPerName) == true) 
                                                {
                                                    mPer = numFunction.toDecimal(item_Row[mPerName]);
                                                }
                                            }
                                            catch
                                            {
                                            } // End

                                            if (mPer > 0)
                                            {
                                                if (System.Convert.ToString(Row["amtExpr"]).Trim() != "")
                                                {
                                                    try
                                                    {
                                                        string DataTableName, DataFieldName, AmountExpression = "";
                                                        AmountExpression = System.Convert.ToString(Row["amtExpr"]).Trim();
                                                        if (AmountExpression.IndexOf(".") >= 0)
                                                        {
                                                            DataTableName = AmountExpression.Trim().Substring(0, AmountExpression.Trim().IndexOf("."));
                                                            DataFieldName = AmountExpression.Trim().Substring(AmountExpression.Trim().IndexOf(".") + 1, (AmountExpression.Length - AmountExpression.Trim().IndexOf(".")) - 1);

                                                            if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                                                            {
                                                                mCalAmt = numFunction.toDecimal(main_vw.Rows[0][DataFieldName]);
                                                            }
                                                            else
                                                            {
                                                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                                                {
                                                                    mCalAmt = numFunction.toDecimal(item_Row[DataFieldName]);
                                                                }
                                                                else
                                                                {
                                                                    ErrorMessage = "Main_vw and Item_vw Datatable Amount Expression can Evaulate";
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            ErrorMessage = "Invalid syntax found of Datatable in AmtExpr field eg. Item_vw.Examt";
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        ErrorMessage = ex.Message.ToString().Trim();
                                                    }
                                                }  // Empty Amount Expression Check End

                                                // Check the Display sign in DcMast view
                                                if (System.Convert.ToString(Row["disp_sign"]).Trim() == "@")
                                                {
                                                    decimal mDef_Qty = numFunction.toDecimal(item_Row["Qty"]);
                                                    try // Check field in Dcmast
                                                    {
                                                        if (Row.Table.Columns.Contains("def_qty") == true)   
                                                        {
                                                            string defQty = System.Convert.ToString(Row["def_qty"]).Trim();
                                                            try // Check Field in Item_vw
                                                            {
                                                                if (item_Row.Table.Columns.Contains(defQty) == true)     
                                                                {
                                                                    mDef_Qty = numFunction.toDecimal(item_Row[defQty]);
                                                                }
                                                            }
                                                            catch 
                                                            {
                                                            }
                                                        }
                                                    }
                                                    catch
                                                    {
                                                    }  //end

                                                    mAmt = mDef_Qty * mPer;
                                                }
                                                else
                                                {
                                                    if (mCalAmt == 0)
                                                    {
                                                        mAmt = mAmount * (mPer / 100);
                                                    }
                                                    else
                                                    {
                                                        mAmt = mCalAmt * (mPer / 100);
                                                    }
                                                }

                                                // Round off
                                                if (System.Convert.ToBoolean(Row["Round_Off"]) == true)
                                                {

                                                    mAmt = System.Math.Round(mAmt, 0);
                                                }

                                                if (strFunction.InList(strFunction.Left(grdItem.Columns[i - 1].AccessibleHeaderText, 2), new string[2] { "@#", "%#" }) == true)
                                                {
                                                    if (numFunction.toDecimal(item_Row[mFld_nm]) != mAmt)
                                                    {
                                                        try // Check percentage field In Item_vw
                                                        {
                                                            if (item_Row.Table.Columns.Contains(mPerName) == true)     
                                                            {
                                                                item_Row[mPerName] = 0;
                                                                item_Row.AcceptChanges();
                                                            }
                                                        }
                                                        catch
                                                        {
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (item_Row.Table.Columns.Contains(mPerName) == true)    
                                                {
                                                    item_Row[mPerName] = 0;
                                                    item_Row.AcceptChanges();
                                                }
                                            }

                                            if (strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText, 2), new string[2] { "@#", "%#" }) == true)
                                            {
                                                item_Row[mFld_nm] = System.Math.Abs(mAmt);
                                                item_Row.AcceptChanges();
                                            }

                                        }
                                    }
                                    if (strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText, 2), new string[3] { "S#", "@#", "%#" }) == false)
                                    {
                                        if (numFunction.toDecimal(Row["Bef_Aft"]) == 1 && Mexcl_gross.ToString().Trim() == "")
                                        {
                                            switch (mA_s.Trim())
                                            {
                                                case "+":
                                                    mAvalue = mAvalue + (+numFunction.toDecimal(item_Row[mFld_nm]));
                                                    break;
                                                case "-":
                                                    mAvalue = mAvalue + (-numFunction.toDecimal(item_Row[mFld_nm]));
                                                    break;
                                            }
                                        }

                                        if (strFunction.InList(Mexcl_gross, new string[2] { "C", "A" }) == false)
                                        {
                                            switch (mA_s.Trim())
                                            {
                                                case "+":
                                                    mAmount = mAmount + (+numFunction.toDecimal(item_Row[mFld_nm]));
                                                    break;
                                                case "-":
                                                    mAmount = mAmount + (-numFunction.toDecimal(item_Row[mFld_nm]));
                                                    break;
                                            }

                                        }
                                    }
                                }
                                catch
                                {
                                    string mFld_nm = "";
                                    decimal mAmt = 0;
                                    mFld_nm = fld.ToString().Trim();
                                    if (strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText, 2), new string[1] { "S#" }) == true)
                                    {
                                        // find tax in Sale tax View
                                        foreach (DataRow Stax_Row in stax_vw.Select("tax_name = '" + System.Convert.ToString(item_Row["tax_name"]).Trim() + "'"))
                                        {
                                            mAmt = mAmount * (System.Convert.ToInt32(Stax_Row["level1"]) / 100);
                                            // Round off setting in company master 
                                            if (System.Convert.ToBoolean(company.Rows[0]["Ssamt_op"]) == true)
                                            {
                                                mAmt = System.Math.Round(mAmt, 0);
                                            }

                                        } // end

                                        item_Row[mFld_nm] = System.Math.Abs(mAmt);
                                        item_Row.AcceptChanges();
                                    }

                                    if (strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText, 2), new string[3] { "S#", "@#", "%#" }) == false)
                                    {
                                        mAmount = mAmount + numFunction.toDecimal(item_Row[mFld_nm]);
                                    }
                                }
                            }
                        }
                    }
                } // End grdItem.Columns[i].AccessibleHeaderText != ""
            } // End

            if ((strFunction.InList(pcvType.ToString().Trim(),new string[5]{"ST","SR","SO","SQ","DC"}) == true ||
                strFunction.InList(beHave.ToString().Trim(),new string[5]{"ST","SR","SO","SQ","DC"}) == true) &&
                System.Convert.ToBoolean(company.Rows[0]["Sinet_op"]) == true)
            {
                mAmount = System.Math.Round(mAmount, 0);   
            }

            if ((strFunction.InList(pcvType.ToString().Trim(), new string[5] { "PT", "PR", "PO", "EP", "AR" }) == true ||
                strFunction.InList(beHave.ToString().Trim(), new string[5] { "PT", "PR", "PO", "EP", "AR" }) == true) &&
                System.Convert.ToBoolean(company.Rows[0]["Pinet_op"]) == true)
            {
                mAmount = System.Math.Round(mAmount, 0);
            }

            try  // Check field is exist in item_vw to replace round off assesment amount
            {
                //if (item_Row["u_asseamt"].GetType().Name == "Decimal")
                if (item_Row.Table.Columns.Contains("u_asseamt") == true)
                {
                    if (!System.Convert.IsDBNull(coadditional.Rows[0]["rndavalue"]))
                    {
                        if (System.Convert.ToBoolean(coadditional.Rows[0]["rndavalue"]) == true )
                        {
                            mAvalue = System.Math.Round(mAvalue, 0);
                        }
                    }
                    item_Row["u_asseamt"] = mAvalue;
                    item_Row.AcceptChanges();
                }
            }
            catch
            {
            } // End

            if (howtoCalculateExAmt == "I")
            {
                main_vw.Rows[0]["tot_examt"] = 0;

                foreach (DataRow dcMastRow in dcmast_vw.Select("code = 'E' and att_file = 0"))
                {
                    string dcFldName = System.Convert.ToString(dcMastRow["fld_nm"]).Trim();
                    if (main_vw.Rows[0].Table.Columns.Contains(dcFldName) == true)
                    {
                        main_vw.Rows[0][dcFldName] = 0;

                        foreach (DataRow ItemTbl_Row in item_vw.Rows)
                        {
                            main_vw.Rows[0][dcFldName] = numFunction.toDecimal(main_vw.Rows[0][dcFldName]) + numFunction.toDecimal(ItemTbl_Row[dcFldName]);
                        }
                        main_vw.Rows[0]["tot_examt"] = numFunction.toDecimal(main_vw.Rows[0]["tot_examt"]) + numFunction.toDecimal(main_vw.Rows[0][dcFldName]);
                    }
                }

            }

            main_vw.AcceptChanges(); // update changes in main_vw datatable  
            item_vw.AcceptChanges(); // update changes in item_vw datatable   

            return mAmount; 
        }

        public void SumColumns(DataTable main_vw, DataTable item_vw, DataTable dcmast_vw, DataTable tax_vw, DataTable tax_vw1, string calType, string calFld, string calGro, bool itemPage, bool chargesPage, bool accountPage, TextBox txtItemTotal, TextBox txtTotalQty, TextBox txtNetAmount, TextBox txtAccNetAmount, string howtoCalculateExAmt, string vchkProd, string pcvType, string beHave,bool addMode,bool editMode)
        {
            decimal lnColumnSum = 0;
            decimal mTotExcl = 0;
            decimal mQty = 0;

            if (itemPage == true)  // if item tab is enable
            {
                if (item_vw.Rows.Count > 0)
                {
                    lnColumnSum = (decimal)item_vw.Compute("SUM(gro_amt)", "");
                    mQty = (decimal)item_vw.Compute("SUM(Qty)", "");
                }
                else
                {
                    lnColumnSum = 0;
                    mQty = 0;
                }

                  // Check field in dc_mast

                if (dcmast_vw.Columns.Contains("Excl_Gross") == true)     
                 {
                    foreach (DataRow dcMast_Row in dcmast_vw.Select("att_file = 0 and Excl_Gross In('G','C')"))
                    {
                        string dcCode = Convert.ToString(dcMast_Row["code"]).Trim().Substring(2, 1);
                        string dcMastfld = Convert.ToString(dcMast_Row["Fld_Nm"]).Trim();
                        string dcSign = "";

                        foreach (DataRow item_Row in item_vw.Rows)  // Loop Item_vw
                        {
                            switch (dcCode.ToString().Trim())
                            {
                                case "N":
                                case "A":
                                case "E":
                                case "T":
                                    dcSign = "+";
                                    break;
                                default:
                                    dcSign = "-";
                                    break;
                            }

                            if (dcSign.ToString().Trim() == "+")
                            {
                                mTotExcl = mTotExcl + (+numFunction.toDecimal(item_Row[dcMastfld]));
                            }
                            else
                            {
                                if (dcSign.ToString().Trim() == "-")
                                {
                                    mTotExcl = mTotExcl + (-numFunction.toDecimal(item_Row[dcMastfld]));
                                }
                            }


                        }  // End Loop Item_vw

                    } // End Filter Loop for Dc_mast
                }

                if (calGro.ToString().Trim() == "N" && txtItemTotal.Enabled == true)
                {
                    lnColumnSum = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]);
                }

                // Update textBox for Total Qty
                txtTotalQty.Text = Convert.ToString(mQty);
                txtItemTotal.Text = Convert.ToString(lnColumnSum);

                main_vw.Rows[0]["gro_amt"] = numFunction.toDecimal(lnColumnSum);
                main_vw.AcceptChanges(); // update changes in main_vw   

            } // End itemPage == true

            if (chargesPage == true)
            {
                // run autocalchg
                ChargesAutoCalculation(main_vw, item_vw, tax_vw, pcvType.Trim()
                       , beHave.Trim(), calType, calFld, howtoCalculateExAmt, vchkProd);

                vouGridFill pageTaxCharges = new vouGridFill();
                tax_vw1 = pageTaxCharges.pgTaxUpdate(tax_vw, tax_vw1, main_vw, item_vw, addMode,editMode);     
            }

            if (howtoCalculateExAmt == "I")
            {
                decimal mDealerAmount = 0;
                if (vchkProd.Trim().IndexOf("vuexc") >= 0 &&
                   (pcvType.ToString().Trim() == "PT" ||
                    beHave.ToString().Trim() == "PT"))
                {

                    if (System.Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().IndexOf("DEALER") >= 0)
                    {
                        mDealerAmount = numFunction.toDecimal(main_vw.Rows[0]["tot_examt"]);
                    }
                }  // End 

                lnColumnSum = numFunction.toDecimal(mTotExcl) +
                              numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["tot_tax"]) +
                              numFunction.toDecimal(mDealerAmount) +
                              numFunction.toDecimal(main_vw.Rows[0]["tot_add"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["taxamt"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["tot_nontax"]) -
                              numFunction.toDecimal(main_vw.Rows[0]["tot_fdisc"]);

            }
            else
            {
                lnColumnSum = numFunction.toDecimal(mTotExcl) +
                              numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["tot_tax"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["tot_examt"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["tot_add"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["taxamt"]) +
                              numFunction.toDecimal(main_vw.Rows[0]["tot_nontax"]) -
                              numFunction.toDecimal(main_vw.Rows[0]["tot_fdisc"]);
            }   // End howtoCalculateExAmt == "I"

            main_vw.Rows[0]["net_amt"] = numFunction.toDecimal(lnColumnSum);
            main_vw.AcceptChanges(); // update changes in main_vw datatable

            if (itemPage == true) // if enabled Item Page 
            {
                // Then update net amount textbox from Item Page
                //txtNetAmount.Text = String.Format("{0:F2}",lnColumnSum);
                txtNetAmount.Text = String.Format("{0:F2}", lnColumnSum);  
            }

            if (accountPage == true) // if enabled Account Page 
            {
                txtAccNetAmount.Text = String.Format("{0:F2}",lnColumnSum);  // Then update net amount textbox from account Page  
            }
            
        }

        public void ChargesAutoCalculation(DataTable main_vw, DataTable item_vw, DataTable tax_vw, string pcvType, string beHave, string calType, string calFld, string howtoCalculateExAmt,string vchkProd)
        {
            calType = calType.Trim().ToUpper();
            bool calValue = false;

            if (calType.Trim() == "")
            {
                calValue = true;
            }

            // update 0 value in below field

            main_vw.Rows[0]["Tot_deduc"] = 0;
            main_vw.Rows[0]["Tot_tax"] = 0;
            main_vw.Rows[0]["Tot_examt"] = 0;
            main_vw.Rows[0]["Tot_Add"] = 0;
            main_vw.Rows[0]["Tot_Nontax"] = 0;
            main_vw.Rows[0]["Tot_fdisc"] = 0;
            main_vw.AcceptChanges(); // update changes in main_vw datatable

            foreach (DataRow Taxvw_Row in tax_vw.Rows)
            {
                if (calType == "P" && Convert.ToString(Taxvw_Row["fld_nm"]).Trim() == calFld.Trim())
                {
                    calValue = true; 
                }

                string mainFldName = Convert.ToString(Taxvw_Row["fld_nm"]).Trim();

                if (strFunction.InList(Convert.ToString(Taxvw_Row["Excl_Net"]).Trim(), new string[2] { "D", "E" }) == false &&
                    calValue == true)
                {
                    string TaxPerFld_Name = Convert.ToString(Taxvw_Row["Pert_Name"]).Trim();
                    decimal TaxPerDef = numFunction.toDecimal(Taxvw_Row["Def_Pert"]);

                    // Check field in main_vw table 
                    if (main_vw.Rows[0].Table.Columns.Contains(TaxPerFld_Name) == true)
                    {
                        // Evaluate column value from main_vw table
                        TaxPerDef = numFunction.toDecimal(main_vw.Rows[0][TaxPerFld_Name]);
                    } // end Check field in main_vw table 

                    decimal mCalAmt = 0;
                    decimal mAmt = numFunction.toDecimal(Taxvw_Row["def_amt"]);

                    if (TaxPerDef > 0)
                    {
                        // Check amount expression empty or not
                        if (System.Convert.ToString(Taxvw_Row["amtExpr"]).Trim() != "")
                        {
                            try
                            {
                                string DataTableName, DataFieldName, AmountExpression = "";
                                AmountExpression = System.Convert.ToString(Taxvw_Row["amtExpr"]).Trim();
                                if (AmountExpression.IndexOf(".") >= 0)
                                {
                                    DataTableName = AmountExpression.Trim().Substring(0, AmountExpression.Trim().IndexOf("."));
                                    DataFieldName = AmountExpression.Trim().Substring(AmountExpression.Trim().IndexOf(".") + 1, (AmountExpression.Length - AmountExpression.Trim().IndexOf(".")) - 1);

                                    if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                                    {
                                        mCalAmt = numFunction.toDecimal(main_vw.Rows[0][DataFieldName]);
                                    }
                                    else
                                    {
                                        ErrorMessage = "Main_vw and Item_vw Datatable Amount Expression can Evaulate";
                                    }
                                }
                                else
                                {
                                    // Customisation for Amar Remedies
                                    if (AmountExpression.IndexOf("MRP") >= 0)
                                    {
                                        //try
                                        //{
                                        //    CL_User UserKeys = new CL_User(SessionProxy.ReqCode);
                                        //    DataSet xmlDS = (DataSet)UserKeys.Cache["ItMastView"];
                                        //    string filterExp = "";
                                        //    foreach (DataRow itRow in item_vw.Rows)
                                        //    {
                                        //        mCalAmt += numFunction.toDecimal(itRow["qty"]) *
                                        //                         numFunction.toDecimal(itRow["u_mrprate"]);  
                                        //    }
                                        //}
                                        //catch { }

                                    }
                                    else
                                        ErrorMessage = "Invalid syntax found of Datatable in AmtExpr field eg. Main_vw.Examt";
                                }
                            }
                            catch (Exception ex)
                            {
                                ErrorMessage = ex.Message.ToString().Trim();
                            }
                        }
                        else
                        {
                            decimal mExamt = 0;
                            if (howtoCalculateExAmt == "I")
                            {
                                if (vchkProd.Trim().IndexOf("vuexc") >= 0 &&
                                   (pcvType.ToString().Trim() == "PT" ||
                                    beHave.ToString().Trim() == "PT"))
                                {
                                    if (System.Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().IndexOf("DEALER") >= 0)
                                    {
                                        mExamt = numFunction.toDecimal(main_vw.Rows[0]["tot_examt"]);
                                    }
                                }
                                else
                                {
                                    mExamt = numFunction.toDecimal(main_vw.Rows[0]["tot_examt"]);
                                }  // End 
                            } // End howtoCalculateExAmt = "I"


                            // Check Tax Code for calculation
                            switch (Convert.ToString(Taxvw_Row["Code"]).Trim().ToUpper())
                            {
                                case "D":
                                    mCalAmt = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]);
                                    break;
                                case "T":
                                    mCalAmt = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]);
                                    break;
                                case "E":
                                    mCalAmt = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_tax"]);
                                    break;
                                case "A":
                                    mCalAmt = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_tax"]) +
                                              numFunction.toDecimal(mExamt);
                                    break;
                                case "S":
                                    mCalAmt = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_tax"]) +
                                              numFunction.toDecimal(mExamt) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_add"]);
                                    break;
                                case "N":
                                    mCalAmt = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_tax"]) +
                                              numFunction.toDecimal(mExamt) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_add"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["taxamt"]);
                                    break;
                                case "F":
                                    mCalAmt = numFunction.toDecimal(main_vw.Rows[0]["gro_amt"]) -
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_deduc"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_tax"]) +
                                              numFunction.toDecimal(mExamt) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_add"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["taxamt"]) +
                                              numFunction.toDecimal(main_vw.Rows[0]["tot_nontax"]);
                                    break;
                            } // End Check Tax Code for calculation
                        } // Empty Amount Expression Check End

                        switch (Convert.ToString(Taxvw_Row["disp_sign"]))
                        {
                            case "@":
                                string defQtyfld = "Qty";
                                if (Taxvw_Row.Table.Columns.Contains("def_Qty") == true)
                                {
                                    defQtyfld = Convert.ToString(Taxvw_Row["def_qty"]).Trim();
                                    if (item_vw.Rows[0].Table.Columns.Contains(defQtyfld) == true)
                                    {
                                        defQtyfld = defQtyfld.ToUpper().Trim();
                                    }
                                }

                                decimal itQtyValue = 0;
                                foreach (DataRow itemVw_Row in item_vw.Rows)
                                {
                                    itQtyValue = itQtyValue + numFunction.toDecimal(itemVw_Row[defQtyfld]);
                                }

                                mAmt = numFunction.toDecimal(itQtyValue) * numFunction.toDecimal(TaxPerDef);
                                break;
                            case "%":
                                mAmt = numFunction.toDecimal(mCalAmt) * (numFunction.toDecimal(TaxPerDef) / 100);
                                break;
                        }

                        // If round off is true the rounding amount
                        if (Convert.ToBoolean(Taxvw_Row["round_off"]) == true)
                        {
                            mAmt = Math.Round(mAmt, 0);
                        }

                        Taxvw_Row["def_amt"] = numFunction.toDecimal(mAmt);
                        main_vw.Rows[0][mainFldName] = numFunction.toDecimal(mAmt);

                    } // end TaxPerDef > 0
                } // end caltype = .t.

                if (Convert.ToString(Taxvw_Row["Excl_Net"]).Trim() != "D")
                {
                    string mA_s = "";
                    if (strFunction.InList(Convert.ToString(Taxvw_Row["Code"]), new string[2] { "D", "F" }) == true &&
                        Convert.ToString(Taxvw_Row["a_s"]).Trim() == "+")
                    {
                        mA_s = "-";
                    }
                    else
                    {
                        if (strFunction.InList(Convert.ToString(Taxvw_Row["Code"]), new string[2] { "D", "F" }) == true &&
                            Convert.ToString(Taxvw_Row["a_s"]).Trim() == "-")
                        {
                            mA_s = "+";
                        }
                        else
                        {
                            if (Convert.ToString(Taxvw_Row["a_s"]).Trim() != "")
                            {
                                mA_s = Convert.ToString(Taxvw_Row["a_s"]).Trim();
                            }
                            else
                            {
                                mA_s = "+";
                            } // END not empty a_s
                        }  // END code "D","F" and a_s = "-"
                    }  // END code "D","F" and a_s = "+"


                    // Check Tax code and do Calculation
                    switch (Convert.ToString(Taxvw_Row["Code"]).Trim())
                    {
                        case "D":
                            switch (mA_s.Trim())
                            {
                                case "+":
                                    main_vw.Rows[0]["Tot_deduc"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_deduc"]) +
                                                                   (+numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                                case "-":
                                    main_vw.Rows[0]["Tot_deduc"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_deduc"]) +
                                                                   (-numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                            }
                            break; 
                        case "T":
                            switch (mA_s.Trim())
                            {
                                case "+":
                                    main_vw.Rows[0]["Tot_Tax"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_Tax"]) +
                                                                   (+numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                                case "-":
                                    main_vw.Rows[0]["Tot_Tax"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_Tax"]) +
                                                                   (-numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                            }
                            break; 
                        case "E":
                            switch (mA_s.Trim())
                            {
                                case "+":
                                    main_vw.Rows[0]["Tot_Examt"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_Examt"]) +
                                                                   (+numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                                case "-":
                                    main_vw.Rows[0]["Tot_Examt"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_Examt"]) +
                                                                   (-numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                            }
                            break; 
                        case "A":
                            switch (mA_s.Trim())
                            {
                                case "+":
                                    main_vw.Rows[0]["Tot_Add"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_Add"]) +
                                                                   (+numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                                case "-":
                                    main_vw.Rows[0]["Tot_Add"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_Add"]) +
                                                                   (-numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                            }
                            break; 
                        case "N":
                            switch (mA_s.Trim())
                            {
                                case "+":
                                    main_vw.Rows[0]["Tot_NonTax"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_NonTax"]) +
                                                                   (+numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                                case "-":
                                    main_vw.Rows[0]["Tot_NonTax"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_NonTax"]) +
                                                                   (-numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                            }
                            break; 
                        case "F":
                            switch (mA_s.Trim())
                            {
                                case "+":
                                    main_vw.Rows[0]["Tot_fdisc"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_fdisc"]) +
                                                                   (+numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                                case "-":
                                    main_vw.Rows[0]["Tot_fdisc"] = numFunction.toDecimal(main_vw.Rows[0]["Tot_fdisc"]) +
                                                                   (-numFunction.toDecimal(main_vw.Rows[0][mainFldName]));
                                    break;
                            }
                            break;
                    } // End Check Tax code and do Calculation

                    if (calType.ToString().Trim() == "A" &&
                        Convert.ToString(Taxvw_Row["Fld_Nm"]).Trim() == calFld.ToString().Trim())
                    {
                        calValue = true;
                    }
                } // End Convert.ToString(Taxvw_Row["Excl_Net"]).Trim() != "D"
            }

            // update all datatable after made changes
            main_vw.AcceptChanges();
            item_vw.AcceptChanges();
            tax_vw.AcceptChanges();  
        }
    }
}


                //if (strFunction.InList(strFunction.Left(grdItem.Columns[i].AccessibleHeaderText,2),new string[1]{"V#"}))        
                //{
                //    Datafld = grdItem.Columns[i] as BoundField;
                //    fldName = Datafld.DataField;

                //    if (fldName != "")
                //    {
                //        mcode = grdItem.Columns[i].AccessibleHeaderText.Trim().Substring(3, 1);
                //        if (mcode != "")
                //        {
                //            fldName = mcode.ToString().Trim().ToUpper() + fldName.ToString().Trim().ToUpper() + "I";
                //            try
                //            {
                //                DataRow Row = dcmast_vw.Select("fld_nm = '" + fldName.ToString().Trim() + "'")[0];
                //                if (System.Convert.ToString(Row["Excl_Gross"]).GetType().Name.Trim().ToUpper()  == "VARCHAR")
                //                {
                //                    Mexcl_gross = System.Convert.ToString(Row["Excl_Gross"]);
                //                }

                //                if (mcode == "E")
                //                {
                //                    if (vchkProd.Trim().IndexOf("vuexc") >= 0 &&
                //                        (pcvType.ToString().Trim() == "PT" ||
                //                        beHave.ToString().Trim() == "PT"))
                //                    {
                //                        if (System.Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().IndexOf("DEALER") >= 0)
                //                        {
                //                            Mexcl_gross = "G";
                //                        }
                //                    }
                //                }

                //                string mFld_nm,mA_s = "";
                //                mFld_nm = System.Convert.ToString(Row["fld_nm"]).Trim();

                //                if (System.Convert.ToString(Row["a_s"]).Trim() != "")
                //                {
                //                    mA_s = System.Convert.ToString(Row["a_s"]).Trim();
                //                }
                //                else
                //                {
                //                    if (strFunction.InList(System.Convert.ToString(Row["Code"]).Trim(), new string[2] { "D", "E" }) == true)
                //                    {
                //                        mA_s = "-";
                //                    }
                //                    else
                //                    {
                //                        mA_s = "+";
                //                    }
                //                }

                //                if (System.Convert.ToDecimal(Row["Bef_Aft"]) == 1 &&
                //                    Mexcl_gross.ToString().Trim() != "")
                //                {
                //                    switch (mA_s.Trim())
                //                    {
                //                        case "+":
                //                            mAvalue = mAvalue + ( + System.Convert.ToDecimal(item_Row[mFld_nm]));
                //                            break;
                //                        case "-":
                //                            mAvalue = mAvalue + ( - System.Convert.ToDecimal(item_Row[mFld_nm]));
                //                            break; 
                //                    }
                                   
                //                }

                //                if (strFunction.InList(Mexcl_gross,new string[2]{"C","A"}))
                //                {
                //                    switch (mA_s.Trim())
                //                    {
                //                        case "+":
                //                            mAmount = mAmount + (+System.Convert.ToDecimal(item_Row[mFld_nm]));
                //                            break;
                //                        case "-":
                //                            mAmount = mAmount + (-System.Convert.ToDecimal(item_Row[mFld_nm]));
                //                            break; 
                //                    }
                //                }

                //            }
                //            catch 
                //            {
                //                string mFld_nm = fldName.ToString().Trim();
                //                mAmount = mAmount + System.Convert.ToDecimal(item_Row[mFld_nm]);   
                //            }
                            
                //        }
                //    }
                //}
