using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Data.Acess.Layer;


namespace Business.Logic.Layer
{
    public class GenerateInvoiceNo_Delete
    {
        numericFunction numFunction = new numericFunction();
        stringFunction strFunction = new stringFunction();
        getDateFormat DateFormat = new getDateFormat();
        string SqlStr = "";

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DbSessionProxy = new CL_DbProperties_SessionProxy();

        public GenerateInvoiceNo_Delete()
        {
        }

        private SqlCommand cmd;
        public SqlCommand Cmd
        {
            get { return cmd; }
            set { cmd = value; }
        }

        public bool GenInvNo_Delete(string entryType,
                    string InvoiceSeries,
                    string InvoiceNo,
                    DateTime entDate,
                    string entYear,
                    string oldInvoiceSeries,
                    string oldInvoiceNo,
                    ref SqlConnection connHandle)
        {


            bool minv_no = true;
            string v_i_s_type = "";
            string v_i_prefix = "";
            string v_i_suffix = "";
            string v_i_middle = "";
            string _vInvoiceSr = oldInvoiceSeries;
            string _vInvoiceNo = oldInvoiceNo;

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            SqlDataReader Dr;

            SqlStr = "Select Top 1 * from Series Where Inv_sr = '" + _vInvoiceSr + "'";
            Dr = DataAcess.ExecuteDataReader(SqlStr, Cmd, ref connHandle);

            if (Dr.HasRows == true)
            {
                while (Dr.Read())
                {
                    v_i_s_type = Convert.ToString(Dr["s_type"]);
                    if (Convert.ToString(Dr["i_prefix"]).Trim() != "")
                    {
                        v_i_prefix = Convert.ToString(Dr["i_prefix"]).Trim();
                    }

                    if (Convert.ToString(Dr["i_suffix"]).Trim() != "")
                    {
                        v_i_suffix = Convert.ToString(Dr["i_suffix"]).Trim();
                    }
                }
                switch (v_i_s_type.Trim().ToUpper())
                {
                    case "DAYWISE":
                        v_i_middle += Convert.ToString(Convert.ToDateTime(entDate).Day);
                        v_i_middle += Convert.ToString(Convert.ToDateTime(entDate).Month);
                        v_i_middle += Convert.ToString(Convert.ToDateTime(entDate).Year).Trim().Substring(2, 2);
                        break;
                    case "MONTHWISE":
                        v_i_middle += Convert.ToString(Convert.ToDateTime(entDate).Month);
                        v_i_middle += Convert.ToString(Convert.ToDateTime(entDate).Year).Trim().Substring(2, 2);
                        break;
                }
                _vInvoiceNo = _vInvoiceNo.Substring((v_i_prefix.Length + v_i_middle.Length) + 1);
                _vInvoiceNo = _vInvoiceNo.Substring(1, ((v_i_prefix.Length + v_i_middle.Length) + 1));
            }
            Dr.Close();
            Dr.Dispose();

            if (v_i_s_type == "MONTHWISE")
            {
                entDate = Convert.ToDateTime("01/" + entDate.Month.ToString() + "/" + entDate.Year.ToString().Trim());
            }

            int vInvNo = Convert.ToInt32(_vInvoiceNo);
            vInvNo = vInvNo == 0 ? 1 : vInvNo;
            _vInvoiceNo = Convert.ToString(vInvNo);
            string _vInvoiceEn = Convert.ToString(vInvNo <= 0 ? 0 : vInvNo - 1);

            SqlStr = "Select * from Gen_inv with (NOLOCK) where 1=0 ";
            DataTable genInv_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction, ref connHandle);
            SqlStr = "Select * from Gen_miss with (NOLOCK) where 1=0 ";
            DataTable genMiss_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connHandle);

            DataRow GenInvRow = genInv_vw.NewRow();
            GenInvRow["entry_ty"] = entryType.Trim();
            GenInvRow["inv_dt"] = entDate;
            GenInvRow["inv_sr"] = InvoiceSeries.Trim();
            GenInvRow["inv_no"] = InvoiceNo.Trim();
            GenInvRow["l_yn"] = entYear.Trim();
            genInv_vw.Rows.Add(GenInvRow);
            genInv_vw.AcceptChanges();

            DataRow GenMissRow = genMiss_vw.NewRow();
            GenMissRow["entry_ty"] = entryType.Trim();
            GenMissRow["inv_dt"] = entDate;
            GenMissRow["inv_sr"] = _vInvoiceSr.Trim();
            GenMissRow["inv_no"] = _vInvoiceNo.Trim();
            GenMissRow["l_yn"] = entYear.Trim();
            GenMissRow["flag"] = "N";
            genMiss_vw.Rows.Add(GenMissRow);
            genMiss_vw.AcceptChanges();

            DataTable tmpTbl_vw;
            bool exSucess = true;
            switch (v_i_s_type.Trim().ToUpper())
            {
                case "DAYWISE":
                    SqlStr = "Select Top 1 Inv_no from Gen_inv with (TABLOCKX) " +
                             " where Entry_ty = '" + Convert.ToString(genInv_vw.Rows[0]["Entry_ty"]).Trim() + "'" +
                             " And Inv_sr = '" + Convert.ToString(genInv_vw.Rows[0]["Inv_sr"]).Trim() + "'" +
                             " And Inv_dt = '" + DateFormat.dateformat(Convert.ToDateTime(genInv_vw.Rows[0]["Inv_dt"])) + "'";
                    tmpTbl_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connHandle);
                    break;
                case "MONTHWISE":
                    SqlStr = "Select Top 1 Inv_no from Gen_inv with (TABLOCKX) " +
                             " where Entry_ty = '" + Convert.ToString(genInv_vw.Rows[0]["Entry_ty"]).Trim() + "'" +
                             " And Inv_sr = '" + Convert.ToString(genInv_vw.Rows[0]["Inv_sr"]).Trim() + "'" +
                             " And Month(Inv_dt) = " + Convert.ToDateTime(genInv_vw.Rows[0]["Inv_dt"]).Month +
                             " And Year(Inv_dt) = " + Convert.ToDateTime(genInv_vw.Rows[0]["Inv_dt"]).Year;
                    tmpTbl_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connHandle);
                    break;
                default:
                    SqlStr = "Select Top 1 Inv_no from Gen_inv with (TABLOCKX) " +
                             " where Entry_ty = '" + Convert.ToString(genInv_vw.Rows[0]["Entry_ty"]).Trim() + "'" +
                             " And Inv_sr = '" + Convert.ToString(genInv_vw.Rows[0]["Inv_sr"]).Trim() + "'" +
                             " And L_yn = '" + Convert.ToString(genInv_vw.Rows[0]["l_yn"]).Trim() + "'";
                    tmpTbl_vw = DataAcess.ExecuteDataTable(SqlStr, cmd.Transaction,ref connHandle);
                    break;
            }

            SqlStr = "";
            if (tmpTbl_vw.Rows.Count <= 0)
            {
                SqlStr = DataAcess.GenInsertString(genInv_vw, "gen_inv", null, null);

            }
            else
            {
                _vInvoiceEn = Convert.ToString(tmpTbl_vw.Rows[0]["inv_no"]).Trim() == _vInvoiceNo ?
                _vInvoiceEn.Trim() : Convert.ToString(tmpTbl_vw.Rows[0]["Inv_no"]).Trim();

                genInv_vw.Rows[0]["Inv_no"] = _vInvoiceEn;
                genInv_vw.AcceptChanges();

                string[] cond = new string[3];
                switch (v_i_s_type.Trim().ToUpper())
                {
                    case "DAYWISE":
                        cond[0] = "Entry_ty";
                        cond[1] = "Inv_Sr";
                        cond[2] = "Inv_Dt";
                        break;
                    case "MONTHWISE":
                        SqlStr = "update gen_inv set inv_no = '" + Convert.ToString(genInv_vw.Rows[0]["inv_no"]).Trim() + "'" +
                                 " where entry_ty ='" + Convert.ToString(genInv_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                                 " and inv_sr ='" + Convert.ToString(genInv_vw.Rows[0]["inv_sr"]).Trim() + "'" +
                                 " and month(inv_dt) = " + Convert.ToDateTime(genInv_vw.Rows[0]["inv_dt"]).Month +
                                 " and year(inv_dt) = " + Convert.ToDateTime(genInv_vw.Rows[0]["inv_dt"]).Year;

                        break;
                    default:
                        cond[0] = "Entry_ty";
                        cond[1] = "Inv_Sr";
                        cond[2] = "l_yn";
                        break;
                }

                if (v_i_s_type.Trim().ToUpper() != "MONTHWISE")
                {
                    SqlStr = DataAcess.GenUpdateString(genInv_vw, "gen_inv", null, new string[] { "inv_no" }, "", cond);
                }
            }

            if (SqlStr.Trim() != "")
            {
                try
                {
                    Cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true,ref connHandle);
                    Cmd.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    exSucess = false;

                }
            }

            string vFoundInMiss = "Y";
            if (exSucess == true)
            {
                genInv_vw.Rows[0]["inv_no"] = _vInvoiceNo;
                genInv_vw.AcceptChanges();

                genMiss_vw.Rows[0]["inv_no"] = Convert.ToString(genInv_vw.Rows[0]["inv_no"]);
                genMiss_vw.AcceptChanges();

                tmpTbl_vw = new DataTable();
                switch (v_i_s_type.Trim().ToUpper())
                {
                    case "DAYWISE":
                        SqlStr = "Select Top 1 inv_no from Gen_miss where " +
                                 " entry_ty ='" + Convert.ToString(genMiss_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                                 " and inv_sr ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_sr"]).Trim() + "'" +
                                 " and inv_no ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_no"]).Trim() + "'" +
                                 " and inv_dt ='" + DateFormat.dateformat(Convert.ToDateTime(genMiss_vw.Rows[0]["inv_dt"])) + "'";
                        tmpTbl_vw = DataAcess.ExecuteDataTable(SqlStr, Cmd.Transaction, ref connHandle);
                        break;
                    case "MONTHWISE":
                        SqlStr = "Select Top 1 inv_no from Gen_miss where " +
                                 " entry_ty ='" + Convert.ToString(genMiss_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                                 " and inv_sr ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_sr"]).Trim() + "'" +
                                 " and inv_no ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_no"]).Trim() + "'" +
                                 " and Month(inv_dt) =" + Convert.ToDateTime(genMiss_vw.Rows[0]["Inv_dt"]).Month +
                                 " and Year(inv_dt) =" + Convert.ToDateTime(genMiss_vw.Rows[0]["Inv_dt"]).Year;
                        tmpTbl_vw = DataAcess.ExecuteDataTable(SqlStr, Cmd.Transaction , ref connHandle);
                        break;
                    default:
                        SqlStr = "Select Top 1 Inv_no from Gen_miss where " +
                                 " entry_ty ='" + Convert.ToString(genMiss_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                                 " and inv_sr ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_sr"]).Trim() + "'" +
                                 " and inv_no ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_no"]).Trim() + "'" +
                                 " and l_yn ='" + Convert.ToString(genMiss_vw.Rows[0]["l_yn"]).Trim() + "'";
                        tmpTbl_vw = DataAcess.ExecuteDataTable(SqlStr, Cmd.Transaction, ref connHandle);
                        break;
                }

                SqlStr = "";
                if (tmpTbl_vw.Rows.Count <= 0)
                {
                    vFoundInMiss = "N";
                    SqlStr = DataAcess.GenInsertString(genMiss_vw, "gen_miss", null, null);
                    Cmd = DataAcess.ExecuteNonQuery(Cmd, SqlStr, "TX", true, ref connHandle);
                    Cmd.ExecuteNonQuery();
                }
                else
                {
                    SqlStr = "";
                    string[] cond = new string[5];
                    switch (v_i_s_type.ToUpper().Trim())
                    {
                        case "DAYWISE":
                            cond[0] = "Entry_ty";
                            cond[1] = "Inv_Sr";
                            cond[2] = "Inv_no";
                            cond[3] = "Inv_dt";
                            break;
                        case "MONTHWISE":
                            SqlStr = "update gen_miss set inv_no ='" +
                                      Convert.ToString(genMiss_vw.Rows[0]["inv_no"]).Trim() + "'" +
                                      ",flag='" + Convert.ToString(genMiss_vw.Rows[0]["flag"]).Trim() + "'" +
                                      " where entry_ty ='" + Convert.ToString(genMiss_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                                      " and inv_sr ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_sr"]).Trim() + "'" +
                                      " and inv_no ='" + Convert.ToString(genMiss_vw.Rows[0]["inv_no"]).Trim() + "'" +
                                      " and Month(inv_dt) = " + Convert.ToDateTime(genMiss_vw.Rows[0]["inv_dt"]).Month +
                                      " and Year(inv_dt) = " + Convert.ToDateTime(genMiss_vw.Rows[0]["inv_dt"]).Year;
                            break;
                        default:
                            cond[0] = "Entry_ty";
                            cond[1] = "Inv_Sr";
                            cond[2] = "Inv_no";
                            cond[3] = "l_yn";
                            break;
                    }

                    if (v_i_s_type.Trim().ToUpper() != "MONTHWISE")
                    {
                        SqlStr = DataAcess.GenUpdateString(genInv_vw, "gen_inv", null, new string[] { "inv_no" }, "", cond);
                    }

                    if (SqlStr.Trim() != "")
                    {
                        try
                        {
                            Cmd = DataAcess.ExecuteNonQuery(cmd, SqlStr, "TX", true, ref connHandle);
                            Cmd.ExecuteNonQuery();
                        }
                        catch
                        {
                            exSucess = false;
                        }
                    }
                }
            }

            if (exSucess == true)
                DataAcess.CommitTransaction(Cmd.Transaction);
            else
            {
                DataAcess.RollBackTransaction(Cmd.Transaction);
                minv_no = false;
            }
            return minv_no;
        }


    }


}
