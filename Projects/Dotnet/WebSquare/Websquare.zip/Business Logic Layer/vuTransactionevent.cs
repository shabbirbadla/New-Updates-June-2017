using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;  
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data;
using Data.Acess.Layer;
using AjaxControlToolkit;
using System.Collections; 
using Controls;




namespace Business.Logic.Layer
{
    public class vuTransactionevent
    {
        //private static DataTier DataAcess = new DataTier();
        private getDateFormat DateFormat = new getDateFormat();
        private stringFunction strFunction = new stringFunction();
        private numericFunction numFunction = new numericFunction();
        private boolFunction bitFunction = new boolFunction();
        private SqlConnection connHandle;
        private string errorMessage ="";

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();

        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

        private HeaderFields fieldsofHeader;
        public HeaderFields FieldsofHeader
        {
            get { return fieldsofHeader; }
            set { fieldsofHeader = value; }
        }

        public vuTransactionevent()
        {
        }

        public void dropParty_SelectedIndexChanged(TextBox txtPartyName,
                    GridView GridAccount,
                    GridView grdAllocation, 
                    DataTable main_vw,
                    DataTable lcode_vw,
                    DataTable company,
                    DataTable acdet_vw,
                    TextBox txtdate,
                    TextBox txtDueDays, 
                    TextBox txtDueDate,
                    //Label lblBnkName,
                    Label lblAccBalAmt,
                    HiddenField hiddPartyName)
                   
                    
        {
            
            decimal crAmount = 0;
            bool crAllow = false;
            int crDays = 0;
            string vendType = "";
            string coGroup = "";
            int acId = 0;

            SqlParameter[] spParam = new SqlParameter[4];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@partyNM";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = txtPartyName.Text.Trim();
            spParam[0].Direction = ParameterDirection.Input;

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@prod";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = DBPropsSession.Vchkprod; 
            spParam[1].Direction = ParameterDirection.Input;

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@accPage";
            spParam[2].SqlDbType = SqlDbType.Bit; 
            spParam[2].Value = DBPropsSession.AccountPage;
            spParam[2].Direction = ParameterDirection.Input;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@hidPartynm";
            spParam[3].SqlDbType = SqlDbType.VarChar;
            spParam[3].Value = hiddPartyName.Value.Trim();  
            spParam[3].Direction = ParameterDirection.Input;


            DataSet Ds = new DataSet();
            ArrayList dblist = new ArrayList();
            dblist.Add("acMast");

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            if (DBPropsSession.AccountPage == true)
            {
                if (hiddPartyName.Value.Trim() != "")
                {
                    dblist.Add("PrevacId");
                }
            }

            Ds = DataAcess.ExecuteDataset(Ds,"sp_ent_web_tran_party_validation",
                                                 spParam, dblist,connHandle);

            DataAcess.Connclose(connHandle);
            if (Ds.Tables["acMast"].Rows.Count == 0)
                throw new Exception("Party name not found in master");

            foreach (DataRow acMastRow in Ds.Tables["acMast"].Rows)
            {
                acId = numFunction.toInt32(acMastRow["ac_id"]);
                crAmount = numFunction.toDecimal(acMastRow["cramount"]);
                crAllow = bitFunction.toBoolean(acMastRow["crAllow"]);
                crDays = Convert.ToInt32(acMastRow["cr_Days"]);
                coGroup = Convert.ToString(acMastRow["coGroup"]);
                if (DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0)
                {
                    vendType = Convert.ToString(acMastRow["vend_type"]).Trim();
                }
                else
                {
                    vendType = "";
                }

                if (bitFunction.toBoolean(lcode_vw.Rows[0]["it_rate"]) == true)
                {
                    if (acMastRow.Table.Columns.Contains("PRLSTNAME") == true)
                    {
                        SessionProxy.PrlistCode = Convert.ToString(acMastRow["Prlstname"]);
                    }
                }
            }

            if (DBPropsSession.AccountPage == true)
            {
                if (hiddPartyName.Value.Trim() != "")
                {
                    if (Ds.Tables["PrevacId"].Rows.Count == 0)
                        throw new Exception("Previous A/c code not found for Remove effects from Account Detail");

                    int prvID = numFunction.toInt32(Ds.Tables["prevAcid"].Rows[0]["ac_id"]);
                    foreach (DataRow acDetRow in acdet_vw.Select("ac_id = " + prvID))
                    {
                        acDetRow["ac_name"] = txtPartyName.Text.ToString().Trim();
                        acDetRow["ac_id"] = acId;
                        acDetRow["memo_op"] = 0;
                        acDetRow.AcceptChanges();
                    }
                    acdet_vw.AcceptChanges();
                }

                vouGridFill vouGridInit = new vouGridFill();
                GridAccount.DataSource = acdet_vw;
                string[] grdCols = vouGridInit.grdAccountColSHide(lcode_vw);
                vouGridInit.gridBind(GridAccount, grdCols);
                if (DBPropsSession.AllocationPage == true)
                {
                    grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdAllocation.DataSource = acdet_vw;
                    vouGridInit.gridBind(grdAllocation, grdCols);
                }

                if (bitFunction.toBoolean(company.Rows[0]["ac_bchk"]) == true)
                {
                    decimal accBalance = 0;
                    vuAccountBalance AccountBalance = new vuAccountBalance();

                    accBalance = AccountBalance.getAccountBalance(Convert.ToInt32(acId),
                                txtPartyName.Text.ToString().Trim(),
                                Convert.ToInt32(main_vw.Rows[0]["tran_cd"]),
                                 DBPropsSession.AddMode,
                                 DBPropsSession.Entry_Tbl);


                    lblAccBalAmt.Text = "<b>A/c Balance Details :</b> " +
                        Convert.ToString(accBalance).Trim() +
                                        (accBalance > 0 ? "<span style='color:red'> <b>DR</b></span>" : "<span style='color:red'> <b>CR</b></span>");


                    if (crAmount > 0 && (strFunction.InList(DBPropsSession.PcvType, new string[] { "ST", "BP", "CP", "PC", "SS", "II" }) == true || strFunction.InList(DBPropsSession.Behave, new string[] { "ST", "BP", "CP", "PC", "SS", "II" }) == true))
                    {
                        if (crAmount > accBalance)
                        {
                            if (!crAllow)
                            {
                                ErrorMessage = txtPartyName.Text.ToString().Trim() + " has crossed the Credit Amount Limit..!!'";
                                return;
                            }
                            else
                            {
                                ErrorMessage = txtPartyName.Text.ToString().Trim() + " has crossed the Credit Amount Limit..!!'";
                            }
                        }
                    }
                }
            }

            DataAcess.Connclose(connHandle);
            main_vw.Rows[0]["party_nm"] = txtPartyName.Text.ToString().Trim();
            main_vw.Rows[0]["ac_id"] = acId;

            if (Convert.ToString(main_vw.Rows[0]["due_dt"]) == "")
            {
                txtDueDays.Text = crDays.ToString().Trim();
                main_vw.Rows[0]["due_dt"] = DateFormat.TodateTime(txtdate.Text).AddDays(crDays);
                txtDueDate.Text = DateFormat.dateformatBR(Convert.ToString(main_vw.Rows[0]["due_dt"]));
            }

            if (DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0 && DBPropsSession.PcvType == "PT")
                main_vw.Rows[0]["ettype"] = vendType.Trim().ToUpper();
                                                             
            
            main_vw.AcceptChanges();
            DataAcess.Connclose(connHandle); 
        }

        public void grdCharges_RowEditing(GridView grdCharges,
            DataTable tax_vw1,
            DataTable Stax_vw,
            int NewEditIndex)
        {
            grdCharges.EditIndex = NewEditIndex;
            grdCharges.DataSource = tax_vw1;
            grdCharges.DataBind();

            string strStaxCode = "";
            bool SaleTaxYes = false;

            strStaxCode = ((Label)grdCharges.Rows[NewEditIndex].FindControl("lblCharges")).Text.ToString().Trim();

            foreach (DataRow TaxDataRows in tax_vw1.Select("code = 'S' and head_nm = '" + strStaxCode + "'"))
            {
                SaleTaxYes = true;
            }

            if (strStaxCode == "NO-TAX" || SaleTaxYes == true)
            {
                DropDownList dropSTax = new DropDownList();
                Label lblSTax = new Label();
                lblSTax = ((Label)grdCharges.Rows[grdCharges.EditIndex].FindControl("lblCharges"));
                dropSTax = ((DropDownList)grdCharges.Rows[grdCharges.EditIndex].FindControl("dropSaleTax"));
                lblSTax.Visible = false;
                dropSTax.Visible = true;
                dropSTax.AutoPostBack = true;
                foreach (DataRow TaxDataRows in Stax_vw.Rows)
                {
                    dropSTax.Items.Add(Convert.ToString(TaxDataRows["tax_name"]).Trim());
                }

                dropSTax.DataBind();
                dropSTax.Items.Add("NO-TAX");
                dropSTax.SelectedValue = lblSTax.Text.Trim();
            }
            else
            {
                DropDownList dropSTax = new DropDownList();
                Label lblSTax = new Label();
                lblSTax = ((Label)grdCharges.Rows[grdCharges.EditIndex].FindControl("lblCharges"));
                dropSTax = ((DropDownList)grdCharges.Rows[grdCharges.EditIndex].FindControl("dropSaleTax"));
                lblSTax.Visible = true;
                dropSTax.Visible = false;
            }

            DataRow TaxDataRow;
            TaxDataRow = tax_vw1.Select("head_nm = '" + strStaxCode + "'")[0];
            NumericTextBox txtChargesAmt = ((NumericTextBox)grdCharges.Rows[grdCharges.EditIndex].FindControl("txtChargesAmt"));
            NumericTextBox txtChargesPer = ((NumericTextBox)grdCharges.Rows[grdCharges.EditIndex].FindControl("txtChargesPer"));

            if (Convert.ToString(TaxDataRow["code"]) == "S" || (Convert.ToString(TaxDataRow["Excl_Net"]).Trim() == "D"
                || Convert.ToString(TaxDataRow["Excl_Net"]).Trim() == "E"))
                txtChargesPer.Enabled = false;
            else
                txtChargesPer.Enabled = true;

            if (Convert.ToString(TaxDataRow["Excl_Net"]).Trim() == "D" || Convert.ToString(TaxDataRow["Excl_Net"]).Trim() == "E")
                txtChargesAmt.Enabled = false;
            else
                txtChargesAmt.Enabled = true;

            txtChargesAmt.Text = ((Label)grdCharges.Rows[grdCharges.EditIndex].FindControl("lblChargesAmtHD")).Text;
            txtChargesPer.Text = ((Label)grdCharges.Rows[grdCharges.EditIndex].FindControl("lblChargePerHD")).Text;

            if (strStaxCode == "NO-TAX" || SaleTaxYes == true)
            {
                txtChargesAmt.Enabled = false;
            }
            else
            {
               txtChargesAmt.Attributes.Add("onfocusout", "javascript:disCharges_PerRemove('" + txtChargesPer.ClientID + "','" + txtChargesAmt.ClientID + "')");  
            }
        }

        public void grdCharges_RowUpdating(DataSet MainDataSet,GridView grdCharges,int RowIndex,
                                           GridView GridAccount,GridView grdAllocation,
                                            TextBox txtItemTotal,
                                            TextBox txtTotalQty,
                                            TextBox txtNetAmount, 
                                            TextBox txtAccNetAmount,
                                            TextBox txtGrossAmt,
                                            TextBox txtdedBefTax,
                                            TextBox txtTaxCharges,
                                            TextBox txtExAmt,
                                            TextBox txtAddCharges,
                                            TextBox txtTaxAmt,
                                            TextBox txtNonTax,
                                            TextBox txtfdisc,
                                            TextBox txtRoundoff,
                                            TextBox txtNetAmountTax)
        {
           DataTable main_vw, tax_vw1, item_vw, dcmast_vw, tax_vw, Company;
           vuGridCalculation taxCalculation = new vuGridCalculation();
           vuAccountPosting accPosting = new vuAccountPosting();
        
           main_vw = MainDataSet.Tables["Main_vw"];
           item_vw = MainDataSet.Tables["item_vw"];
           tax_vw1 = MainDataSet.Tables["tax_vw1"];
           tax_vw =  MainDataSet.Tables["tax_vw"];
           dcmast_vw = MainDataSet.Tables["dcmast_vw"];
           Company = MainDataSet.Tables["company"];

           main_vw.AcceptChanges();
           tax_vw1.AcceptChanges();
           tax_vw.AcceptChanges();

           string strSTaxCode = "";
           bool SaleTaxYes = false;
           strSTaxCode = ((Label)grdCharges.Rows[RowIndex].FindControl("lblCharges")).Text.ToString().Trim();
          
           foreach (DataRow TaxDataRow in MainDataSet.Tables["tax_vw1"].Select("code = 'S'"))
           {
             if (Convert.ToString(TaxDataRow["head_nm"]).Trim() != strSTaxCode)
             {
                 strSTaxCode = ((DropDownList)grdCharges.Rows[RowIndex].FindControl("dropSaleTax")).SelectedValue.ToString().Trim();
                if (Convert.ToString(TaxDataRow["head_nm"]).Trim() == strSTaxCode)
                    SaleTaxYes = true;
                else
                {
                    SaleTaxYes = false;
                    strSTaxCode = ((Label)grdCharges.Rows[RowIndex].FindControl("lblCharges")).Text.ToString().Trim();
                }

             }
             else
                SaleTaxYes = true;
           }

           //below code execute for Sale Tax Calculation
           if (SaleTaxYes == true ||
               strSTaxCode == "NO-TAX")
           {
               strSTaxCode = ((DropDownList)grdCharges.Rows[RowIndex].FindControl("dropSaleTax")).SelectedValue.ToString().Trim();

                DataRow taxRow;
                taxRow = tax_vw1.Select("code = 'S'")[0];
                taxRow["def_amt"] = ((NumericTextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesAmt")).Text.ToString();
                taxRow["def_pert"] = ((NumericTextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesPer")).Text.ToString();
                string fldName = taxRow["fld_nm"].ToString().Trim();

                DataRow staxVwRow = null;
                bool isRowFound = false;
                try
                {
                    staxVwRow = MainDataSet.Tables["Tax_vw"].Select("Code = 'S'")[0];
                    isRowFound = true;
                }
                catch
                {
                    isRowFound = false;
                }

                if (isRowFound == true)
                {
                    // if record is found then update row from tax_vw1 table
                    for (int i=0; i<=MainDataSet.Tables["tax_vw1"].Columns.Count - 1;i++)
                    {
                        staxVwRow[i] = taxRow[i];
                    }
                    staxVwRow.AcceptChanges();
                    MainDataSet.Tables["Tax_vw"].AcceptChanges();
                }
                else
                {
                    // record not found in tax_vw table then add new row from tax_vw1
                    staxVwRow = MainDataSet.Tables["Tax_vw"].NewRow();
                    for (int i=0;i<=MainDataSet.Tables["tax_vw1"].Columns.Count - 1;i++)
                    {
                        staxVwRow[i] = taxRow[i];
                    }
                    MainDataSet.Tables["Tax_vw"].Rows.Add(staxVwRow);
                    MainDataSet.Tables["Tax_vw"].AcceptChanges();
                }

                taxRow.AcceptChanges();
                tax_vw1.AcceptChanges();

               // call Sumcolumns
                taxCalculation.SumColumns(main_vw, item_vw, dcmast_vw, tax_vw, tax_vw1, "P", fldName,
                                          "N", DBPropsSession.ItemPage, DBPropsSession.ChargesPage,
                                          DBPropsSession.AccountPage,txtItemTotal,txtTotalQty,
                                          txtNetAmount, txtAccNetAmount, DBPropsSession.HowtoCalculateExAmt,
                                          DBPropsSession.Vchkprod, DBPropsSession.PcvType, DBPropsSession.Behave, 
                                          DBPropsSession.AddMode, DBPropsSession.EditMode);

                taxRow = tax_vw1.Select("head_nm = '" + strSTaxCode.Trim() + "'")[0];
               
                foreach (DataRow taxVw1Row in tax_vw1.Rows)
                {
                    // find row in  tax_vw table
                    DataRow taxvwRow = null;
                    isRowFound = false;
                    try
                    {
                       
                        taxvwRow = tax_vw.Select("fld_nm = '" + fldName.Trim() + "'")[0];
                        isRowFound = true;
                    }
                    catch
                    {
                        isRowFound = false;
                    }

                    if (isRowFound == true)
                        taxRow["def_amt"] = numFunction.toDecimal(taxvwRow["def_amt"]);
                }

                taxRow.AcceptChanges();
                tax_vw1.AcceptChanges();
                
                if (DBPropsSession.AccountPage == true)
                {
                    accPosting.AccountPosting(MainDataSet, txtItemTotal, txtNetAmount, txtAccNetAmount, 
                    DBPropsSession.ItemPage, DBPropsSession.ChargesPage, DBPropsSession.AccountPage, 
                    DBPropsSession.Vchkprod, DBPropsSession.PcvType, DBPropsSession.Behave, 
                    DBPropsSession.HowtoCalculateExAmt, DBPropsSession.SalesTaxItem,ref connHandle);

                    connHandle.Close();
                    connHandle.Dispose();

                    GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
                    GridAccount.DataBind();

                    grdAllocation.DataSource = MainDataSet.Tables["acdet_vw"];
                    grdAllocation.DataBind();
                }


                RefreshHeaderField(Company,
                                   main_vw,
                                   txtGrossAmt,
                                   txtdedBefTax,
                                   txtTaxCharges,
                                   txtExAmt,
                                   txtAddCharges,
                                   txtTaxAmt,
                                   txtNonTax,
                                   txtfdisc,
                                   txtRoundoff,
                                   txtNetAmountTax); // Refresh header fields 

                // Hide dropdownlist
                ((DropDownList)grdCharges.Rows[grdCharges.EditIndex].FindControl("dropSaleTax")).Visible = false;
           }
           else
           {
               //taxRow = tax_vw1.Select("code = 'S'")[0];
               //taxRow["def_amt"] = ((TextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesAmt")).Text.ToString();
               //taxRow["def_pert"] = ((TextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesPer")).Text.ToString();

                // Below code for other sale tax
                DataRow TaxVw1Row;
                string PerName, FldName = "";
                TaxVw1Row = tax_vw1.Select("head_nm = '" + strSTaxCode + "'")[0];
                PerName = Convert.ToString(TaxVw1Row["Pert_name"]);
                FldName = Convert.ToString(TaxVw1Row["fld_nm"]);

                decimal ChargesPer = Convert.ToDecimal(Convert.ToString(((TextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesPer")).Text).Trim() == "" ?
                    "0" : Convert.ToString(((TextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesPer")).Text).Trim());
                decimal ChargesAmt = Convert.ToDecimal(Convert.ToString(((TextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesAmt")).Text).Trim() == "" ?
                    "0" : Convert.ToString(((TextBox)grdCharges.Rows[RowIndex].FindControl("txtChargesAmt")).Text).Trim());


                TaxVw1Row["def_pert"] = ChargesPer;
                TaxVw1Row["def_amt"] = ChargesAmt;

                if (ChargesPer == 0 && ChargesAmt != 0)
                {
                    TaxVw1Row["def_pert"] = 0;
                    if (main_vw.Columns.Contains(PerName) == true)
                        main_vw.Rows[0][PerName] = 0;

                    if (main_vw.Columns.Contains(FldName) == true)
                        main_vw.Rows[0][FldName] = Convert.ToDecimal(TaxVw1Row["def_amt"]);
                }
                else
                {
                    if (main_vw.Columns.Contains(PerName) == true)
                        main_vw.Rows[0][PerName] = numFunction.toDecimal(TaxVw1Row["def_pert"]);

                    if (numFunction.toDecimal(TaxVw1Row["def_pert"]) <= 0)
                    {
                        if (main_vw.Columns.Contains(PerName) == true)
                            main_vw.Rows[0][FldName] = 0;
                    }
                }

                foreach (DataRow TaxVwRow in tax_vw.Select("fld_nm = '" + Convert.ToString(TaxVw1Row["fld_nm"]) + "'"))
                {
                    TaxVwRow["def_pert"] = numFunction.toDecimal(TaxVw1Row["def_pert"]);
                    TaxVwRow["def_amt"] = numFunction.toDecimal(main_vw.Rows[0][FldName]);
                    TaxVwRow.AcceptChanges();
                }
                tax_vw.AcceptChanges();

                taxCalculation.SumColumns(main_vw, item_vw, dcmast_vw, tax_vw, tax_vw1, 
                                          "P", FldName, "N", DBPropsSession.ItemPage, DBPropsSession.ChargesPage, 
                                          DBPropsSession.AccountPage, txtItemTotal, txtTotalQty, txtNetAmount, 
                                          txtAccNetAmount, DBPropsSession.HowtoCalculateExAmt, DBPropsSession.Vchkprod,
                                          DBPropsSession.PcvType, DBPropsSession.Behave, DBPropsSession.AddMode, DBPropsSession.EditMode);

                //TaxVw1Row = tax_vw1.Select("head_nm = '" + strSTaxCode.Trim() + "'")[0];
                foreach (DataRow TaxRow in tax_vw1.Select("head_nm = '" + strSTaxCode.Trim() + "'"))
                {
                    // find row in  tax_vw table
                    try
                    {
                        DataRow TaxVwRow;
                        TaxVwRow = tax_vw.Select("fld_nm = '" + Convert.ToString(TaxRow["fld_nm"]).Trim() + "'")[0];
                        TaxRow["def_amt"] = numFunction.toDecimal(TaxVwRow["def_amt"]);
                        TaxRow.AcceptChanges();
                        tax_vw1.AcceptChanges();
                    }
                    catch
                    {
                    }
                }

                if (DBPropsSession.AccountPage == true)
                {
                    accPosting.AccountPosting(MainDataSet, txtItemTotal, txtNetAmount,txtAccNetAmount,
                                              DBPropsSession.ItemPage, DBPropsSession.ChargesPage, 
                                              DBPropsSession.AccountPage,DBPropsSession.Vchkprod,
                                              DBPropsSession.PcvType, DBPropsSession.Behave,DBPropsSession.HowtoCalculateExAmt,
                                              DBPropsSession.SalesTaxItem,ref connHandle);

                    connHandle.Close();
                    connHandle.Dispose();

                    GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
                    GridAccount.DataBind();

                    grdAllocation.DataSource = MainDataSet.Tables["acdet_vw"];
                    grdAllocation.DataBind();
                }
                
           }

            grdCharges.EditIndex = -1;
            grdCharges.DataSource = MainDataSet.Tables["tax_vw1"];
            grdCharges.DataBind();

            RefreshHeaderField(Company,
                            main_vw,
                            txtGrossAmt,
                            txtdedBefTax,
                            txtTaxCharges,
                            txtExAmt,
                            txtAddCharges,
                            txtTaxAmt,
                            txtNonTax,
                            txtfdisc,
                            txtRoundoff,
                            txtNetAmountTax); // Refresh header fields 

        }

        public void RefreshHeaderField(DataTable Company,DataTable main_vw,
                                          TextBox txtGrossAmt,
                                          TextBox txtdedBefTax,
                                          TextBox txtTaxCharges,
                                          TextBox txtExAmt,
                                          TextBox txtAddCharges,
                                          TextBox txtTaxAmt,
                                          TextBox txtNonTax,
                                          TextBox txtfdisc,
                                          TextBox txtRoundoff,
                                          TextBox txtNetAmountTax)
        {
            //Int32 deci = Convert.ToInt32(Company.Rows[0]["ratedeci"]);
            //string FormatRate = "";
            //if (deci != 0)
            //{
            //    for (int i = 0; i <= deci; i++)
            //    {
            //        FormatRate += "0";
            //    }
            //    FormatRate = "{0:000." + FormatQty + ";Nothing}";

            //}
            //else
            //{
            //    FormatRate = "{0:000.00;Nothing}";
            //}


            //txtGrossAmt.Text = Convert.ToString(main_vw.Rows[0]["gro_amt"]);
            //txtdedBefTax.Text = Convert.ToString(main_vw.Rows[0]["Tot_deduc"]);
            //txtTaxCharges.Text = Convert.ToString(main_vw.Rows[0]["Tot_Tax"]);
            //txtExAmt.Text = Convert.ToString(main_vw.Rows[0]["Tot_examt"]);
            //txtAddCharges.Text = Convert.ToString(main_vw.Rows[0]["Tot_add"]);
            //txtTaxAmt.Text = Convert.ToString(main_vw.Rows[0]["TaxAmt"]);
            //txtNonTax.Text = Convert.ToString(main_vw.Rows[0]["Tot_nontax"]);
            //txtfdisc.Text = Convert.ToString(main_vw.Rows[0]["Tot_fdisc"]);

            string FormatRate = "{0:00.00;Nothing}";
            txtGrossAmt.Text = string.Format(FormatRate, main_vw.Rows[0]["gro_amt"]);
            txtdedBefTax.Text = string.Format(FormatRate,main_vw.Rows[0]["Tot_deduc"]);
            txtTaxCharges.Text = string.Format(FormatRate, main_vw.Rows[0]["Tot_Tax"]);
            txtExAmt.Text = string.Format(FormatRate, main_vw.Rows[0]["Tot_examt"]);
            txtAddCharges.Text = string.Format(FormatRate, main_vw.Rows[0]["Tot_add"]);
            txtTaxAmt.Text = string.Format(FormatRate, main_vw.Rows[0]["TaxAmt"]);
            txtNonTax.Text = string.Format(FormatRate, main_vw.Rows[0]["Tot_nontax"]);
            txtfdisc.Text = string.Format(FormatRate, main_vw.Rows[0]["Tot_fdisc"]);

            if (main_vw.Columns.Contains("roundoff") == true)
                                
                txtRoundoff.Text = numFunction.toDecimal(main_vw.Rows[0]["roundoff"]) > 0 ?
                    string.Format(FormatRate, main_vw.Rows[0]["roundoff"]) :
                    string.Format("{0:00.00}", main_vw.Rows[0]["roundoff"]);
                //txtRoundoff.Text = Convert.ToString( main_vw.Rows[0]["roundoff"]);

            txtNetAmountTax.Text = string.Format(FormatRate, main_vw.Rows[0]["net_amt"]);
            //txtNetAmountTax.Text = Convert.ToString(main_vw.Rows[0]["net_amt"]);

        }

        public void cboBankName_SelectedIndexChanged(TextBox txtBankName,
                                TextBox txtPartyNameB,
                                DataTable main_vw,
                                DataTable acdet_vw,
                                DataTable Company,
                                DataTable lcode_vw,
                                Label lblAccBalAmt,
                                GridView GridAccount,
                                GridView grdAllocation,
                                HiddenField hiddBankName)
                   
                                
        {
            if (txtBankName.Text == "")
            {
                return;
            }

            if (txtPartyNameB.Text.ToString().Trim() == txtBankName.ToString().Trim())
            {
                ErrorMessage = "Bank Name can not be Same as Party Name..!!!";
                return;
            }

            string sqlStr = "";
            int BkId = 0;

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            sqlStr = " select Top 1 Ac_id from ac_mast where ac_name ='" + txtBankName.Text.ToString().Trim() + "'";
            DataTable DtAc = DataAcess.ExecuteDataTable(sqlStr, "_qq", connHandle);
            if (DtAc.Rows.Count == 0)
            {
                DataAcess.Connclose(connHandle);
                DtAc.Dispose();
                throw new Exception("Bank name not found in master");
            }
            else
            {
                BkId = numFunction.toInt32(DtAc.Rows[0]["ac_id"]);
            }
            DtAc.Dispose();

            if (bitFunction.toBoolean(Company.Rows[0]["ac_bchk"]) == true &&
                DBPropsSession.AccountPage == true)
            {
                decimal accBalance = 0;
                decimal crAmount = 0;
                bool crAllow = false;
                vuAccountBalance AccountBalance = new vuAccountBalance();
                accBalance = AccountBalance.getAccountBalance(Convert.ToInt32(BkId),
                             txtPartyNameB.Text.ToString().Trim(),
                             Convert.ToInt32(main_vw.Rows[0]["tran_cd"]),
                             DBPropsSession.AddMode, DBPropsSession.Entry_Tbl);

                lblAccBalAmt.Text = "<b>Bank Balance Details :</b> " + 
                    Convert.ToString(accBalance).Trim() +
                                    (accBalance > 0 ? "<span style='color:red'> <b>DR</b></span>" : "<span style='color:red'> <b>CR</b></span>");

                SqlDataReader dr;
                dr = DataAcess.ExecuteDataReader("select ac_id,ac_name,isnull(cramount,0) as cramount,isnull(crallow,0) as crallow from ac_mast where ac_id = " + BkId, ref connHandle);
                while (dr.Read())
                {
                    crAmount = numFunction.toDecimal(dr["crAmount"]);
                    crAllow = bitFunction.toBoolean(dr["crAllow"]);
                }
                dr.Close();
                dr.Dispose();
                DataAcess.Connclose(connHandle);
                if (crAmount > 0 &&
                    (strFunction.InList(DBPropsSession.PcvType, new string[] { "ST", "BP", "CP", "PC", "SS", "II" }) == true ||
                     strFunction.InList(DBPropsSession.Behave, new string[] { "ST", "BP", "CP", "PC", "SS", "II" }) == true))
                {
                    if (crAmount > accBalance)
                    {
                        if (!crAllow)
                        {
                            ErrorMessage = txtBankName.Text.ToString().Trim() + " has crossed the Credit Amount Limit..!!";
                            //ScriptManager.RegisterStartupScript(Me, GetType(), "alert()", "alert('" + cboBankName.SelectedItem.ToString().Trim() + " has crossed the Credit Amount Limit..!!');", True)
                            return;
                        }
                        else
                        {
                            ErrorMessage = txtBankName.Text.ToString().Trim() + " has crossed the Credit Amount Limit..!!";
                            //ScriptManager.RegisterStartupScript(Me, GetType(), "alert()", "alert('" + cboBankName.SelectedItem.ToString().Trim() + " has crossed the Credit Amount Limit..!!');", True)
                        }
                    }
                }
            }
            else
            {
                lblAccBalAmt.Text = ""; 
            }
        
            if (DBPropsSession.AccountPage == true)
            {
                if (hiddBankName.Value.Trim() != "")
                {
                    SqlDataReader dr;
                    int prvID = 0;
                    sqlStr = " select Top 1 Ac_id from ac_mast where ac_name ='" + hiddBankName.Value.Trim() + "'";
                    dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
                    if (dr.HasRows == false)
                    {
                        dr.Close();
                        dr.Dispose();
                        throw new Exception("Bank name not found in master");
                    }

                    while (dr.Read())
                    {
                        prvID = numFunction.toInt32(dr["ac_id"]);
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle); 

                    foreach (DataRow acDetRow in acdet_vw.Select("ac_id = " + prvID))
                    {
                        acDetRow["ac_name"] = txtBankName.Text.ToString().Trim();
                        acDetRow["ac_id"] = BkId; 
                        acDetRow["memo_op"] = 0;
                        acDetRow.AcceptChanges();
                    }
                    acdet_vw.AcceptChanges();
                }

                vouGridFill vouGridInit = new vouGridFill();
                GridAccount.DataSource = acdet_vw;
                string[] grdCols = vouGridInit.grdAccountColSHide(lcode_vw);
                vouGridInit.gridBind(GridAccount, grdCols);
                if (DBPropsSession.AllocationPage)
                {
                    grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdAllocation.DataSource = acdet_vw;
                    vouGridInit.gridBind(grdAllocation, grdCols);
                }
            }
            main_vw.Rows[0]["bank_nm"] = txtBankName.Text.ToString().Trim();
            main_vw.Rows[0]["bk_id"] = BkId; 
            main_vw.AcceptChanges();  

        }
        
        public void txtAccNetAmount_TextChanged(DataTable main_vw,
                    DataTable acdet_vw,
                    DataTable item_vw,
                    DataTable lcode_vw,
                    GridView GridAccount,
                    GridView grdAllocation, 
                    LinkButton LinkAcAdd,
                    TextBox txtAccNetAmount,
                    string isChoice)
        {
            try
            {
                if (DBPropsSession.AccountPage == true)
                {
                    foreach (DataRow acDetRow in acdet_vw.Select("memo_op = 0 or memo_op is null"))
                    {
                        acDetRow["Amount"] = 0;
                        if (DBPropsSession.TdsPage == true)
                            acDetRow["Tds"] = 0;
                        acDetRow.AcceptChanges();
                    }

                    main_vw.Rows[0]["net_amt"] = (txtAccNetAmount.Text == "" ? 0 : numFunction.toDecimal(txtAccNetAmount.Text));
                    acdet_vw.AcceptChanges();
                    vuAccountPosting vuAccPosting = new vuAccountPosting();

                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "OB", "OS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "OB", "OS" }))
                    {
                        vuAccPosting.defaacposting(main_vw,
                                    lcode_vw,
                                    item_vw,
                                    acdet_vw,
                                    Convert.ToString(main_vw.Rows[0]["u_choice"]),
                                    ref connHandle);
                    }
                    else
                        vuAccPosting.defaacposting(main_vw, lcode_vw, item_vw, acdet_vw, null, ref connHandle);



                    vouGridFill vouGridInit = new vouGridFill();
                    GridAccount.DataSource = acdet_vw;
                    string[] grdCols = vouGridInit.grdAccountColSHide(lcode_vw);
                    vouGridInit.gridBind(GridAccount, grdCols);
                    if (DBPropsSession.AllocationPage == true)
                    {
                        grdCols = new string[2];
                        grdCols[0] = "0";
                        grdCols[1] = "";
                        grdAllocation.DataSource = acdet_vw;
                        vouGridInit.gridBind(grdAllocation, grdCols);
                    }

                    LinkAcAdd.Enabled = true;
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            //finally
            //{
            //    connHandle.Close();
            //    connHandle.Dispose();
            //}
        }

        public void cboPartyNameB_SelectedIndexChanged(TextBox txtPartyNameB,
                DataTable main_vw,
                DataTable acdet_vw,
                DataTable lcode_vw,
                DataTable Company,
                Label lblAccBalAmt,
                GridView grdAllocation,
                GridView GridAccount,
                HiddenField hiddBnkPartyName)
                
        {
            if (txtPartyNameB.Text == "")
            {
                return;
            }

            string sqlStr = "";
            sqlStr = "select top 1 isnull(cogroup,'') as cogroup,ac_id,isnull(cramount,0) as cramount,isnull(crallow,0) as crallow,isnull(cr_days,0) as cr_days ";
            
            if (DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0)
                sqlStr = sqlStr + ",isnull(vend_type,'')";

            SqlDataReader dr;
            int acId = 0;
            decimal crAmount = 0;
            bool crAllow = false;
            int crDays = 0;
            string vendType = "";
            string coGroup = "";

            sqlStr = " select Top 1 isnull(cogroup,'') as cogroup,ac_id,isnull(cramount,0) as cramount," +
                     " isnull(crallow,0) as crallow,isnull(cr_days,0) as cr_days " +
                     " from ac_mast where ac_name ='" + txtPartyNameB.Text.ToString().Trim() + "'";

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
            if (dr.HasRows == false)
            {
                dr.Close();
                dr.Dispose();
                DataAcess.Connclose(connHandle); 
                throw new Exception("Party name not found in master");
            }
            else
            {
                while (dr.Read())
                {
                    acId = numFunction.toInt32(dr["ac_id"]);
                    crAmount = numFunction.toDecimal(dr["cramount"]);
                    crAllow = bitFunction.toBoolean(dr["crAllow"]);
                    crDays = Convert.ToInt32(dr["cr_Days"]);
                    coGroup = Convert.ToString(dr["coGroup"]);
                    if (DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0)
                        vendType = Convert.ToString(dr["vend_type"]).Trim();
                    else
                        vendType = "";
                }
            }
            dr.Close();
            dr.Dispose();
            DataAcess.Connclose(connHandle);
  
            if (bitFunction.toBoolean(Company.Rows[0]["ac_bchk"]) == true &&
                DBPropsSession.AccountPage == true)
            {
                decimal accBalance = 0;
                vuAccountBalance AccountBalance = new vuAccountBalance();
                accBalance = AccountBalance.getAccountBalance(Convert.ToInt32(acId),
                        txtPartyNameB.ToString().Trim(),   
                        Convert.ToInt32(main_vw.Rows[0]["tran_cd"]),    
                        DBPropsSession.AddMode, 
                        DBPropsSession.Entry_Tbl);

                lblAccBalAmt.Text = "<b>A/c Balance Details :</b> " +
                    Convert.ToString(accBalance).Trim() +
                                    (accBalance > 0 ? "<span style='color:red'> <b>DR</b></span>" : "<span style='color:red'> <b>CR</b></span>");


                if (crAmount > 0 && (strFunction.InList(DBPropsSession.PcvType, new string[]{"ST", "BP", "CP", "PC", "SS", "II","DC"}) == true ||
                    strFunction.InList(DBPropsSession.Behave,new string[]{"ST", "BP", "CP", "PC", "SS", "II","DC"}) == true))
                {
                    if (crAmount > accBalance)
                    {
                        if (!crAllow)
                        {
                            ErrorMessage = txtPartyNameB.ToString().Trim() + " has crossed the Credit Amount Limit..!!";
                            return;
                        }
                        else
                            ErrorMessage = txtPartyNameB.ToString().Trim() + " has crossed the Credit Amount Limit..!!";

                    }
                }
            }

            main_vw.Rows[0]["party_nm"] = txtPartyNameB.Text.ToString().Trim();
            main_vw.Rows[0]["ac_id"] = acId; 

            if (DBPropsSession.AccountPage == true)
            {
                if (hiddBnkPartyName.Value.Trim() != "")
                {
                    int prvID = 0;
                    sqlStr = " select Top 1 Ac_id from ac_mast where ac_name ='" + hiddBnkPartyName.Value.Trim() + "'";
                    dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
                    if (dr.HasRows == false)
                    {
                        dr.Close();
                        dr.Dispose();
                        DataAcess.Connclose(connHandle);  
                        throw new Exception("Party name not found in master");
                    }

                    while (dr.Read())
                    {
                        prvID = numFunction.toInt32(dr["ac_id"]);
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);

                    foreach (DataRow acDetRow in acdet_vw.Select("ac_id = " + prvID))
                    {
                        acDetRow["ac_name"] = txtPartyNameB.Text.ToString().Trim();
                        acDetRow["ac_id"] = acId; 
                        acDetRow["memo_op"] = 0;
                        acDetRow.AcceptChanges();
                    }
                    acdet_vw.AcceptChanges();
                }

                vouGridFill vouGridInit = new vouGridFill();
                GridAccount.DataSource = acdet_vw;
                string[] grdCols = vouGridInit.grdAccountColSHide(lcode_vw);
                vouGridInit.gridBind(GridAccount, grdCols);
                if (DBPropsSession.AllocationPage == true)
                {
                    grdCols = new string[2]; 
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdAllocation.DataSource = acdet_vw;
                    vouGridInit.gridBind(grdAllocation, grdCols);
                }
            }

        }

        public void dropETAcName_SelectedIndexChanged(TextBox txtBPName,
                DropDownList DropAddDRCR,
                Label lblAccBalAmt,
                DataTable acdet_vw,
                DataTable company,
                DataTable main_vw)
                
        {
            try
            {
                if (txtBPName.Text == "")
                {
                    //tblAccStatus.Visible = false;
                    return;
                }

                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                if (bitFunction.toBoolean(company.Rows[0]["ac_bchk"]) == true &&
                    DBPropsSession.AccountPage == true)
                {
                    int acID = 0;
                    string sqlStr = " select Ac_id from ac_mast where ac_name ='" + txtBPName.Text + "'";
                    SqlDataReader dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
                    if (dr.HasRows == false)
                    {
                        dr.Close();
                        dr.Dispose();
                        DataAcess.Connclose(connHandle);
                        throw new Exception("Party name not found in master");
                    }

                    while (dr.Read())
                    {
                        acID = numFunction.toInt32(dr["ac_id"]);
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);

                    decimal accBalance = 0;
                    vuAccountBalance AccountBalance = new vuAccountBalance();
                    accBalance = AccountBalance.getAccountBalance(acID,
                            txtBPName.Text.Trim(),
                            Convert.ToInt32(main_vw.Rows[0]["tran_cd"]),
                            DBPropsSession.AddMode,
                            DBPropsSession.Entry_Tbl);

                    lblAccBalAmt.Text = "<b>A/c Balance Details :</b> " +
                                Convert.ToString(accBalance).Trim() +
                                (accBalance > 0 ? "<span style='color:red'> <b>DR</b></span>" : "<span style='color:red'> <b>CR</b></span>");

                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        public void dropBPName_SelectedIndexChanged(TextBox txtBPName,
                DropDownList DropAddDRCR,
                //Label lblBnkName,
                Label lblAccBalAmt,
                DataTable acdet_vw,
                DataTable company,
                DataTable main_vw,
                //HtmlTable tblAccStatus,
                NumericTextBox txtAddAmt)
        {
            try
            {
                if (txtBPName.Text == "")
                {
                    return;
                }

                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;


                if (bitFunction.toBoolean(company.Rows[0]["ac_bchk"]) == true &&
                    DBPropsSession.AccountPage == true)
                {
                    int acID = 0;
                    string sqlStr = " select Ac_id from ac_mast where ac_name ='" + txtBPName.Text + "'";
                    SqlDataReader dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
                    if (dr.HasRows == false)
                    {
                        dr.Close();
                        dr.Dispose();
                        DataAcess.Connclose(connHandle);
                        throw new Exception("Party name not found in master");
                    }

                    while (dr.Read())
                    {
                        acID = numFunction.toInt32(dr["ac_id"]);
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);
                    decimal accBalance = 0;
                    vuAccountBalance AccountBalance = new vuAccountBalance();
                    accBalance = AccountBalance.getAccountBalance(acID,
                            txtBPName.Text.Trim(),
                            Convert.ToInt32(main_vw.Rows[0]["tran_cd"]),
                            DBPropsSession.AddMode,
                            DBPropsSession.Entry_Tbl);

                    lblAccBalAmt.Text = "<b>A/c Balance Details :</b> " +
                                Convert.ToString(accBalance).Trim() +
                                (accBalance > 0 ? "<span style='color:red'> <b>DR</b></span>" : "<span style='color:red'> <b>CR</b></span>");

                }

                foreach (DataRow acDetRow in acdet_vw.Select("ac_name = '' or amount = 0"))
                {
                    acDetRow.Delete();
                    acDetRow.AcceptChanges();
                }

                acdet_vw.AcceptChanges();
                vuAccountPosting AccountPosting = new vuAccountPosting();
                decimal SumAmt = 0;
                SumAmt = AccountPosting.sumeffect(acdet_vw, company, DBPropsSession.PcvType, DBPropsSession.Behave);
                txtAddAmt.Text = Convert.ToString(Math.Abs(SumAmt));
                if (SumAmt > 0)
                    DropAddDRCR.SelectedValue = "DR";
                else
                    DropAddDRCR.SelectedValue = "CR";
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        // used only for grdAllocation SelectedIndexchanged method
            private string narration;
            public string Narration
            {
              get { return narration; }
              set { narration = value; }
            }

            private DataRow acdetRowVar;
            public DataRow AcdetRowVar
            {
                get { return acdetRowVar; }
                set { acdetRowVar = value; }
            }

            private string editNarration;
            public string EditNarration
            {
                get { return editNarration; }
                set { editNarration = value; }
            }

        // End

        public void grdAllocation_SelectedIndexChanged(GridView GridAccount,
                    DataSet MainDataSet,
                    object sender)
                     
        {
            
            GridViewRow row = ((GridView)sender).SelectedRow; // for searching row
            
            DataRow acDetRow;
            string key = GridAccount.DataKeys[row.RowIndex].Value.ToString();
            acDetRow = MainDataSet.Tables["acdet_vw"].Select("acSerial = '" + key + "'")[0];
            if (numFunction.toDecimal(acDetRow["tds"]) > 0 &&
                numFunction.toDecimal(acDetRow["re_all"]) > 0)
            {
                ErrorMessage = "Allocation can not be done, TDS amount allocated";
                return;
            }
            vuAllocation getAllocation = new vuAllocation();
            //getAllocation.PageCustProps = PageCustProps; 

            getDateFormat dateFormat = new getDateFormat();
            if (MainDataSet.Tables.Contains("mall_vw") == false)
                getAllocation.CreateMallVw(MainDataSet, DBPropsSession.PcvType);
            else
                MainDataSet.Tables["tmpMall_vw"].Rows.Clear();
        
            getAllocation.Allocate(DBPropsSession.AddMode, DBPropsSession.EditMode, 
            MainDataSet.Tables["tmpMall_vw"], MainDataSet.Tables["mall_vw"], DBPropsSession.PcvType,acDetRow,MainDataSet.Tables["main_vw"],
            MainDataSet.Tables["company"]);
            
            if (MainDataSet.Tables["tmpMall_vw"].Rows.Count == 0)
            {
                ErrorMessage = "No transaction found for Allocation";
                return;
            }
        
            string filterExpr = "";
            decimal oTds = 0;
            decimal oDisc = 0;
        
            filterExpr = "entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Entry_ty"]).Trim() + "' and ";
            filterExpr += " date ='" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "' and ";
            filterExpr += " doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "' ";

            try
            {
                oTds = ((Decimal)MainDataSet.Tables["tmpMall_vw"].Compute("Sum(tds)", filterExpr));
                oDisc = ((Decimal)MainDataSet.Tables["tmpMall_vw"].Compute("Sum(disc)", filterExpr));
            }
            catch 
            {
            }
        
            getAllocation.autoAllocate(DBPropsSession.AddMode, 
                                       DBPropsSession.EditMode, 
                                       MainDataSet.Tables["tmpMall_vw"], 
                                       MainDataSet.Tables["Mall_vw"], 
                                       DBPropsSession.PcvType, 
                                       acDetRow, 
                                       MainDataSet.Tables["main_vw"], 
                                       MainDataSet.Tables["company"], 
                                       MainDataSet.Tables["lcode_vw"], 
                                       false);

            AcdetRowVar = acDetRow;  
            Narration = getAllocation.MNarration1;
            EditNarration = getAllocation.EditNarr;  
        }

        //public void grdAllocation_SelectedChanged_Next(bool narr,bool hidValue)
        //{
        //    if (narr == true)
        //    {
        //        string alertMess = "";
        //        alertMess = "Existing Narration     : \n " + Convert.ToString(acDetRow("narr")).Trim() + "\n\n ";
        //        alertMess += "Regenerated Narration : \n" + getAllocation.MNarration1.Trim() + "\n\n";
        //        alertMess += "Proceed with Regeneration ? ";
        //        System.Web.UI. ScriptManager.RegisterStartupScript(Me, Me.GetType(), "narrMess", "narrMess('" + alertMess + "');", True);
        //        if (hidDateValid.Value == "1")
        //            getAllocation.autoAllocAlert(acDetRow, True, getAllocation.EditNarr, getAllocation.MNarration);
        //    }
        
        //    getAllocation.vuAllocationInit(CType(row.FindControl("gridForAllocation"), GridView), MainDataSet.Tables("tmpMall_vw"), MainDataSet.Tables("main_vw"), CType(row.FindControl("chkAllocExcess"), CheckBox), PageCustomProps.PcvType, PageCustomProps.AddMode, PageCustomProps.EditMode, Convert.ToDecimal(acDetRow("amount")), CType(row.FindControl("lblAmount"), Label), CType(row.FindControl("lblTotAlloc"), Label), CType(row.FindControl("lblBalance"), Label))
        //    CType(row.FindControl("gridForAllocation"), GridView).DataSource = MainDataSet.Tables("tmpMall_vw")
        //    CType(row.FindControl("gridForAllocation"), GridView).DataBind()

        //    If DBNull.Value.Equals(row) = True Then
        //        Exit Sub
        //    End If
        
        //}

        // used only for btnAllocate_Click method
        private decimal oTds;
        public decimal OTds
        {
            get { return oTds; }
            set { oTds = value; }
        }

        private decimal oDisc;
        public decimal ODisc
        {
            get { return oDisc; }
            set { oDisc = value; }
        }
        //end

        public DataRow btnAllocate_Click(DataSet MainDataSet,
                GridView grdAllocation,
                int rowIndex,
                DataRow acDetRow)
        {
            try
            {
                string key = grdAllocation.DataKeys[rowIndex].Value.ToString();
                acDetRow = MainDataSet.Tables["acdet_vw"].Select("acSerial = '" + key + "'")[0];
                if (numFunction.toDecimal(acDetRow["tds"]) > 0 &&
                    numFunction.toDecimal(acDetRow["re_all"]) > 0)
                {
                    throw new Exception("Allocation can not be done, TDS amount allocated");
                }

                vuAllocation getAllocation = new vuAllocation();
                //getAllocation.DBPropsSession = PageCustProps;

                getDateFormat dateFormat = new getDateFormat();

                if (MainDataSet.Tables.Contains("mall_vw") == false)
                    getAllocation.CreateMallVw(MainDataSet, DBPropsSession.PcvType);
                else
                    MainDataSet.Tables["tmpMall_vw"].Rows.Clear();

                getAllocation.Allocate(DBPropsSession.AddMode,
                                       DBPropsSession.EditMode,
                                       MainDataSet.Tables["tmpMall_vw"],
                                       MainDataSet.Tables["mall_vw"],
                                       DBPropsSession.PcvType,
                                       acDetRow,
                                       MainDataSet.Tables["main_vw"],
                                       MainDataSet.Tables["company"]);

                if (MainDataSet.Tables["tmpMall_vw"].Rows.Count == 0)
                {
                    throw new Exception("No transaction found for Allocation");
                }

                string filterExpr = "";
                decimal oTds = 0;
                decimal oDisc = 0;
                filterExpr = "entry_ty ='" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Entry_ty"]).Trim() + "' and ";
                filterExpr += " date ='" + DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]) + "' and ";
                filterExpr += " doc_no = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim() + "' ";

                try
                {
                    oTds = ((decimal)MainDataSet.Tables["tmpMall_vw"].Compute("Sum(tds)", filterExpr));
                    oDisc = ((decimal)MainDataSet.Tables["tmpMall_vw"].Compute("Sum(disc)", filterExpr));
                }
                catch
                {
                }

                getAllocation.autoAllocate(DBPropsSession.AddMode,
                                           DBPropsSession.EditMode,
                                           MainDataSet.Tables["tmpMall_vw"],
                                           MainDataSet.Tables["Mall_vw"],
                                           DBPropsSession.PcvType,
                                           acDetRow,
                                           MainDataSet.Tables["main_vw"],
                                           MainDataSet.Tables["company"],
                                           MainDataSet.Tables["lcode_vw"],
                                           false);

                Narration = getAllocation.MNarration1;
                EditNarration = getAllocation.EditNarr;
                ODisc = oDisc;
                OTds = oTds;
                acDetRow.AcceptChanges();
                return acDetRow; 
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            
        }


        public void AdditionalInfoShow(DataSet MainDataSet,
            HtmlTable tblAddInfo)
        {
            DataTable xtra_tbl = MainDataSet.Tables["lother_vw"].Clone();
            xtra_tbl.TableName = "xtra_vw";
            xtra_tbl.AcceptChanges();
            foreach (DataRow lotherRow in MainDataSet.Tables["lother_vw"].Select("att_file = 1 and ingrid = 0 and defa_fld = 0"))
            {
                DataRow xtraRow = xtra_tbl.NewRow();
                for (int i=0;i<=MainDataSet.Tables["lother_vw"].Columns.Count - 1;i++)
                {   
                    xtraRow[i] = lotherRow[i];
                }
                xtra_tbl.Rows.Add(xtraRow);
            }
            xtra_tbl.AcceptChanges();

            if (xtra_tbl.Rows.Count <= 0)
            {
                throw new Exception("No Additional Info.");
            }

            if (MainDataSet.Tables.Contains("xtra_vw") == true)
                MainDataSet.Tables.Remove("xtra_vw");
            
            MainDataSet.Tables.Add(xtra_tbl);
            MainDataSet.AcceptChanges();

            DataView xtra_vw = new DataView();  
            xtra_vw = xtra_tbl.DefaultView;
            xtra_vw.Sort = "serial";

            vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
            try
            {
                vuAddInfo.genControls(xtra_vw,
                        MainDataSet.Tables["main_vw"].Rows[0],
                        tblAddInfo);
            }
            catch (Exception Ex)
            {
                throw new Exception(Ex.Message); 
            }

        }

        public void DateValidation(TextBox txtdate,
                TextBox txtDueDate,
                TextBox txtDueDays,
                HtmlTableRow trduedt, 
                System.Web.UI.Page thisPage,
                HiddenField hidDateValid,
                DataTable main_vw,
                DataTable company,
                DataTable lcode_vw,
                DataTable item_vw,
                DataTable acdet_vw,
                bool Fst)
        {
            try
            {
                if (!(DateFormat.TodateTime(txtdate.Text) >= DateFormat.TodateTime(company.Rows[0]["sta_dt"])
                    && DateFormat.TodateTime(txtdate.Text) <= DateFormat.TodateTime(company.Rows[0]["end_dt"])))
                {
                    if (Fst == false)
                    {
                        //hidDateValid.Value = Convert.ToString(txtdate.Text).Trim();
                        System.Web.UI.ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), null, "DateValidation('Transaction Date Not in Financial Year. Continue anyway?','" + txtdate.ClientID + "');", true);
                        //System.Web.UI.ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), null, "alert('Transaction Date Not in Financial Year. Continue anyway?');", true);
                    }
                    else
                    {
                        if ((System.Convert.IsDBNull(lcode_vw.Rows[0]["cur_date"]) ?
                             false :
                             System.Convert.ToBoolean(lcode_vw.Rows[0]["cur_date"])) == false)
                        {
                            txtdate.Text = "";
                            return;
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                System.Web.UI.ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(),"alert","alert('" + ex.Message.ToString().Trim() + "');", true);
                return;
            }
        
            if (DBPropsSession.LbackDated == true)
            {
                if (DBPropsSession.PBackDate > DateFormat.TodateTime(main_vw.Rows[0]["date"]))
                {
                    System.Web.UI.ScriptManager.RegisterStartupScript(thisPage, thisPage.GetType(), "alert", "alert('Date cannot be less than last entry date');", true);
                    return;
                }   
            }

            main_vw.Rows[0]["date"] = DateFormat.TodateTime(txtdate.Text);
            main_vw.AcceptChanges();

            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
            {
                if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ||
                    Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                {
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR", "GT" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR", "GT" }) == true) &&
                        bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == false)
                    {
                        //foreach (DataRow ManuDTRow in manu_det_vw.Select("manudate <" + )
                        //{

                        //}
                    }

                }
            }
            vuInit initProc = new vuInit(); 
            //getTables _getTables = new getTables();  
            initProc.UpdateFinYear(main_vw, 
                    company, 
                    main_vw);

            if (DBPropsSession.ItemPage == true)
            {
                foreach (DataRow itemRow in item_vw.Rows)
                {
                    itemRow["date"] = DateFormat.TodateTime(txtdate.Text); 
                }
                item_vw.AcceptChanges();
            }

            if (DBPropsSession.AccountPage == true)
            {
                foreach (DataRow acdetRow in acdet_vw.Rows)
                {
                    acdetRow["date"] = DateFormat.TodateTime(txtdate.Text);
                }
                acdet_vw.AcceptChanges();
            }

            if (trduedt.Visible == true)
            {
                if (System.Convert.IsDBNull(main_vw.Rows[0]["due_dt"]) ||
                    !(DateFormat.TodateTime(main_vw.Rows[0]["due_dt"]) > DBPropsSession.AppDate &&
                    DateFormat.TodateTime(main_vw.Rows[0]["due_dt"]) < DateTime.MaxValue))
                {
                    main_vw.Rows[0]["due_dt"] = DateFormat.TodateTime(txtdate.Text);
                    main_vw.AcceptChanges();
                    if (txtDueDate.Text == "")
                    {
                        if (txtDueDays.Text != "")
                        {
                            txtDueDate.Text = DateFormat.TodateTime(main_vw.Rows[0]["due_dt"]).AddDays(Convert.ToInt32(txtDueDays)).ToString("dd/MM/yyyy");
                        }
                        else
                        {
                            txtDueDate.Text = DateFormat.TodateTime(main_vw.Rows[0]["due_dt"]).ToString("dd/MM/yyyy");
                        }
                    }
                }
            }
           //DataAcess.Connclose();
        }

        public string DeletePreValidation(DataRow mainRow,
            DataTable acdet_vw)
        {
            SqlDataReader Dr;
            vuAllocation getChkTable = new vuAllocation();
            string sqlStr = "";
            string isFound = "";
            //PageCustomProperties pageCustProps = new PageCustomProperties();

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            if (DBPropsSession.ItemPage == true)
            {
                if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
                  (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                          strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
                {
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR", "DC" }) == true ||
                         strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR", "DC" }) == true) ||
                         ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                         bitFunction.toBoolean(mainRow["u_sinfo"]) == false))
                    {
                        sqlStr = "Select top 1 Entry_ty From " +
                                 " Litemall where Pentry_ty ='" +
                                 Convert.ToString(mainRow["Entry_ty"]).Trim() + "' and " +
                                 " Ptran_Cd = " + numFunction.toInt32(mainRow["tran_cd"]);

                        bool isfound = false;
                        string sqlvar = "";
                        string mcodenm = "";

                        Dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
                        if (Dr.HasRows == true)
                        {
                            isfound = true;
                            while (Dr.Read())
                            {
                                sqlvar = Convert.ToString(Dr["entry_ty"]).Trim();
                            }
                        }
                        Dr.Close();
                        Dr.Dispose();
                        DataAcess.Connclose(connHandle);

                        if (isfound == true)
                        {
                            sqlStr = "Select top 1 Code_nm From Lcode where cd ='" +
                                sqlvar.Trim() + "'";

                            Dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
                            if (Dr.HasRows == true)
                            {
                                while (Dr.Read())
                                {
                                    mcodenm = Convert.ToString(Dr["code_nm"]).Trim();
                                }
                            }
                            Dr.Close();
                            Dr.Dispose();
                            DataAcess.Connclose(connHandle);
                        }

                        if (isfound == true)
                        {
                            throw new Exception("Entry passed against " + mcodenm.Trim() + "\n" +
                                " Transaction cannot be deleted..");
                        }
                    }
                }

                sqlStr = "Select Or_sr,Re_qty From " + DBPropsSession.Entry_Tbl.Trim() + "item" +
                         " where tran_cd = " + numFunction.toInt32(mainRow["tran_cd"]);

                Dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);

                if (Dr.HasRows == true)
                {
                    while (Dr.Read())
                    {
                        if (numFunction.toDecimal(Dr["re_qty"]) > 0)
                        {
                            isFound = Convert.ToString(Dr["or_sr"]).Trim();
                            break; 
                        }
                    }
                }
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle); 


                if (DBPropsSession.Vchkprod.Trim().IndexOf("vuexc") >= 0 &&
                    isFound.Trim() == "")
                {
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "LI", "RL" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "LI", "RL" }) == true)
                    {
                        string rmDet = (DBPropsSession.PcvType == "LI" || DBPropsSession.Behave == "LI") ?
                            "IR" : "II" + "rmdet";
                        sqlStr = "Select Top 1 Entry_ty From " + rmDet.Trim() + " where li_tran_id = " +
                                 numFunction.toInt32(mainRow["tran_cd"]);

                        Dr = DataAcess.ExecuteDataReader(sqlStr, ref connHandle);
                        if (Dr.HasRows == true)
                        {
                            while (Dr.Read())
                            {
                                isFound = Convert.ToString(Dr["entry_ty"]).Trim();
                                break;
                            }
                        }
                        Dr.Close();
                        Dr.Dispose();
                        DataAcess.Connclose(connHandle);  
                                        
                    }
                }

                if (isFound.Trim() != "")
                {
                    throw new Exception("Entry Passed against " + isFound.Trim() + " Entry cannot be deleted..!!");
                }
            } // end ItemPage

            if (DBPropsSession.AllocationPage == true)
            {
        		string meref_no = "";
                decimal mre_all	 = 0;
                decimal mdisc 	 = 0;
                decimal mtds  	 = 0;
                decimal mdisc1   = 0;
                decimal mtds1 = 0;

                foreach (DataRow acDetRow in acdet_vw.Rows)
                {
                    if (numFunction.toDecimal(acDetRow["re_all"]) > 0)
                    {
                        string mref_no = "";
                        mre_all = mre_all + numFunction.toDecimal(acDetRow["re_all"]);
                        mdisc = mdisc + numFunction.toDecimal(acDetRow["disc"]);
                        mtds = mtds + numFunction.toDecimal(acDetRow["tds"]);
                        mref_no = Convert.ToString(mainRow["entry_ty"]) +
                                  "/" +
                                  (DBNull.Value.Equals(acDetRow["ref_no"]) ? "" : Convert.ToString(acDetRow["ref_no"]));
                        string mentry_ty = "";
                        while (mref_no.Trim() != "")
                        {
                            mentry_ty = strFunction.Left(mref_no, 2);
                            mref_no = mref_no.Trim().Substring(3);

                            if (mref_no.Trim().IndexOf(mentry_ty) < 0)
                            {
                                meref_no = meref_no + mentry_ty + "/";
                            }

                            if (mref_no.Trim() == "")
                            {
                                break;
                            }
                        }
                    }
                }

                string _chktbl = "";
                string _chkentry = "#";

                while (meref_no.Trim() != "")
                {
                    string mentry_ty = strFunction.Left(meref_no, 2);
                    meref_no = meref_no.Trim().Substring(3);
                    string sqlMall = "";
                    if (mentry_ty == Convert.ToString(mainRow["entry_ty"]).Trim())
                        sqlMall = DBPropsSession.Entry_Tbl + "mall";
                    else
                    {
                        _chktbl = mentry_ty != _chkentry ?
                                  getChkTable.chkTable(mentry_ty, null,ref connHandle) :
                                 _chktbl.Trim();

                        _chkentry = mentry_ty;
                        sqlMall = _chktbl + "mall";
                    }
                   
                    sqlStr = "Select Tds,Disc From " + sqlMall.Trim() + " where entry_all ='" +
                             Convert.ToString(mainRow["entry_ty"]) + 
                             "' and main_tran = " + Convert.ToInt32(mainRow["tran_cd"]);

                    DataTable tmpTblVw = DataAcess.ExecuteDataTable(sqlStr, "_tmp", connHandle);
                    if (tmpTblVw.Rows.Count > 0)
                    {
                        mdisc1 = (decimal)tmpTblVw.Compute("SUM(disc)", "");
                        mtds1 =  (decimal)tmpTblVw.Compute("SUM(tds)", "");
                    }
                    else
                    {
                        mdisc1 = -1;
                        mtds1 = -1;
                    }

                    if (mdisc1 != 0 || mtds1 != 0 || meref_no.Trim() == "")
                        break;
                       
                }

                if (mdisc1 != 0 || mtds1 != 0)
                {
                    throw new Exception("Entry cannot be deleted..!!" +
                        (mtds !=0 ? "\\n TDS has been Deducted in this entry " : "") +
                        (mdisc !=0 ? "\\n Discount has been given in this entry " : "") +
                        "\\n\\n  Please remove allocation to delete this entry ");
                }
                
                if (mdisc != 0 || mtds != 0)
                {
                    throw new Exception(mtds != 0 ? "TDS has been Deducted in this entry \\n" : "" +
                        (mdisc !=0 ? "Discount has been given in this entry \\n" : "") +
                        "\\n \\n Are you sure you wish to delete this Voucher?");
                }
                else
                {
                    if (mre_all != 0)
                    {
                        return " Some Allocation is done against this Voucher, Wish to Delete this Voucher ?";
                    }
                }   

            } // Allocation Page End

            DataAcess.Connclose(connHandle); 
            return "";
        }
        
        public void DoDelete(DataRow mainRow,
                DataTable lcode_vw,
                DataTable company,
                DataTable acdet_vw)
        {
            string sqlStr = "";
            SqlCommand cmd = new SqlCommand();
            SqlDataReader dr;
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;


            vuAllocation getChkTable = new vuAllocation();
            if (bitFunction.toBoolean(lcode_vw.Rows[0]["auto_inv"]) == true)
            {
                GenerateInvoiceNo_Delete genInvoiceDelete = new GenerateInvoiceNo_Delete();
                genInvoiceDelete.Cmd = cmd; 
                //genInvoiceDelete.DBPropsSession = PageCustProps;

                bool isRetInvoiceNo = genInvoiceDelete.GenInvNo_Delete(Convert.ToString(mainRow["entry_ty"]).Trim(),
                                    Convert.ToString(mainRow["inv_sr"]).Trim(),
                                    Convert.ToString(mainRow["inv_no"]).Trim(),
                                    Convert.ToDateTime(mainRow["Date"]),
                                    Convert.ToString(mainRow["l_yn"]).Trim(),
                                    Convert.ToString(mainRow["inv_sr"]).Trim(),
                                    Convert.ToString(mainRow["inv_no"]).Trim(),ref connHandle);

                if (isRetInvoiceNo == false)
                {
                    throw new Exception("Cannot Delete this Transaction..!!!"); 
                }
            }

            
            if (DBPropsSession.ItemPage == true)
            {
                if (DBPropsSession.Vchkprod.Trim().IndexOf("vuexc") >=0)
                {
                    // It_Ref is pending

                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "LR", "IL" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "LR", "IL" }) == true)
                    {
                        sqlStr = DataAcess.GenDeleteString(DBPropsSession.Entry_Tbl.Trim()+"RmDet","tran_cd = " + Convert.ToInt32(mainRow["tran_cd"]));
                        cmd = DataAcess.ExecuteNonQuery(cmd, sqlStr, "TX", true, ref connHandle);
                        try
                        {
                            cmd.ExecuteNonQuery(); 
                        }
                        catch (Exception Ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connHandle); 
                            throw Ex; 
                        }
                    }
                }

                if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
                   (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                           strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
                {
                    if (((strFunction.InList(DBPropsSession.PcvType, new string[] { "SS", "IR", "DC" }) == true ||
                         strFunction.InList(DBPropsSession.Behave, new string[] { "SS", "IR", "DC" }) == true) ||
                         ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                         bitFunction.toBoolean(mainRow["u_sinfo"]) == true)) &&
                         strFunction.InList(Convert.ToString(mainRow["rule"]).Trim(),
                         new string[] {"EXCISE","NON-EXCISE"}) == true)
                    {
                        sqlStr = " select * from litemall where tran_cd =" +
                            numFunction.toInt32(mainRow["tran_cd"]);

                        DataTable tmptbl_vw = DataAcess.ExecuteDataTable(sqlStr,cmd.Transaction, ref connHandle);  
                        string _chktbl = "";
                        string mentry_ty = "#";
                        foreach (DataRow tmpRow in tmptbl_vw.Rows)
                        {
                            sqlStr = "";
                            if (Convert.ToString(tmpRow["entry_ty"]).Trim() != "GT")
                            {
                                _chktbl = mentry_ty != Convert.ToString(tmpRow["pentry_ty"]).Trim() ?
                                        getChkTable.chkTable(Convert.ToString(tmpRow["pentry_ty"]).Trim(), cmd,ref connHandle) :
                                            _chktbl.Trim();
                                mentry_ty = Convert.ToString(tmpRow["pentry_ty"]).Trim();

                                sqlStr = " update " + _chktbl.Trim() + "item" +
                                    " set balqty=(balqty + " + numFunction.toDecimal(tmpRow["qty"]) + ")";

                                for (int i = 0; i < DBPropsSession.Tex_exe; i++)
                                {
                                    sqlStr = sqlStr + ("," + SessionProxy.Tex_ExAr[i, 2].Trim() + "=(" +
                                            SessionProxy.Tex_ExAr[i, 2].Trim() + 
                                            "+"
                                            + tmpRow[SessionProxy.Tex_ExAr[i, 1].Trim()] + ")");
                                }

                                sqlStr = sqlStr + (" where entry_ty ='" + Convert.ToString(tmpRow["pentry_ty"]).Trim() + "'" +
                                            " and tran_cd = " + numFunction.toDecimal(tmpRow["ptran_cd"]) + " and " +
                                            " itserial ='" + Convert.ToString(tmpRow["pitserial"]).Trim() + "'");
                            }
                            else
                            {
                                _chktbl = mentry_ty != Convert.ToString(tmpRow["rEntry_ty"]).Trim() ?
                                        getChkTable.chkTable(Convert.ToString(tmpRow["rEntry_ty"]).Trim(), cmd,ref connHandle) :
                                            _chktbl.Trim();

                                mentry_ty = Convert.ToString(tmpRow["rentry_ty"]).Trim();
                                sqlStr = " update " + _chktbl.Trim() + "item" +
                                       " set balqty=(balqty + " + numFunction.toDecimal(tmpRow["qty"]) + ")";

                                for (int i = 0; i < DBPropsSession.Tex_exe; i++)
                                {
                                    sqlStr = sqlStr + ("," + SessionProxy.Tex_ExAr[i,2].Trim() + "=(" +
                                            SessionProxy.Tex_ExAr[i, 2].Trim() + "+" + tmpRow[SessionProxy.Tex_ExAr[i, 1].Trim()] + ")");
                                }

                                sqlStr = sqlStr + (" where entry_ty ='" + Convert.ToString(tmpRow["rentry_ty"]).Trim() + "'" +
                                            " and tran_cd = " + numFunction.toDecimal(tmpRow["rtran_cd"]) + " and " +
                                            " itserial ='" + Convert.ToString(tmpRow["ritserial"]).Trim() + "'");
                            }

                            cmd = DataAcess.ExecuteNonQuery(cmd, sqlStr, "TX", true, ref connHandle);
                            try
                            {
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception Ex)
                            {
                                DataAcess.RollBackTransaction(cmd.Transaction);
                                DataAcess.Connclose(connHandle); 
                                throw Ex;
                            }
                            
                        }
                        tmptbl_vw.Dispose();
                        sqlStr = "";
                        sqlStr = DataAcess.GenDeleteString("Litemall", "tran_cd = " + Convert.ToInt32(mainRow["tran_cd"]));
                        cmd = DataAcess.ExecuteNonQuery(cmd, sqlStr, "TX", true, ref connHandle);
                        try
                        {
                            cmd.ExecuteNonQuery(); 
                        }
                        catch (Exception Ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connHandle);  
                            throw Ex; 
                        }
                    } // End DC

                    if ((strFunction.InList(DBPropsSession.PcvType,new string[] {"AR","IR","GT"}) == true ||
                        strFunction.InList(DBPropsSession.Behave,new string[] {"AR","IR","GT"}) == true) &&
                        strFunction.InList(Convert.ToString(mainRow["rule"]).Trim().ToUpper(),
                                new string[] {"EXCISE","NON-EXCISE"}) == true)
                    {
                        sqlStr = "";
                        sqlStr = DataAcess.GenDeleteString("manu_det", "tran_cd = " + Convert.ToInt32(mainRow["tran_cd"]));
                        cmd = DataAcess.ExecuteNonQuery(cmd,sqlStr, "TX", true,ref connHandle);
                        try
                        {
                            cmd.ExecuteNonQuery(); 
                        }
                        catch (Exception Ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connHandle);  
                            throw Ex; 
                        }

                        sqlStr = DataAcess.GenDeleteString("gen_srno", "tran_cd = " + Convert.ToInt32(mainRow["tran_cd"]));
                        cmd = DataAcess.ExecuteNonQuery(cmd,sqlStr, "TX", true,ref connHandle);
                        try
                        {
                            cmd.ExecuteNonQuery(); 
                        }
                        catch (Exception Ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connHandle);  
                            throw Ex; 
                        }
                    }

                    if ((DBPropsSession.PcvType == "IR" || DBPropsSession.Behave == "IR") &&
                        strFunction.InList(Convert.ToString(mainRow["rule"]).Trim().ToUpper(),
                                new string[] {"EXCISE","NON-EXCISE"}) == true)
                    {
                        //deletefromlitemallforet Pending
                    }

                }

                sqlStr += "select it_code,ware_nm,dc_no,qty " +
                          " from " + DBPropsSession.Entry_Tbl + "item" +
                          " where tran_cd = " +
                          Convert.ToInt32(mainRow["tran_cd"]);

                DataTable tmpTable = DataAcess.ExecuteDataTable(sqlStr, cmd.Transaction, ref connHandle);
                foreach (DataRow tmpDtRow in tmpTable.Rows)
                {
                    decimal mQty = (Convert.ToString(tmpDtRow["dc_no"]) == "" ?
                        numFunction.toDecimal(tmpDtRow["qty"]) : 0);
                    string mFld = DBPropsSession.Entry_Tbl + "Qty";
                    sqlStr = " update it_bal set " + mFld.Trim() + " = " + mFld.Trim() + " - " + mQty + 
                             " where it_code = " + Convert.ToInt32(tmpDtRow["it_code"]);
                    cmd = DataAcess.ExecuteNonQuery(cmd,sqlStr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        try
                        {
                            sqlStr = " update it_balw set " +
                                     " qty = isnull(qty,0) - " + mQty +
                                     " where it_code = " + Convert.ToInt32(tmpDtRow["it_code"]) +
                                     " and ware_nm = '" + Convert.ToString(tmpDtRow["ware_nm"]).Trim() + "'" +
                                     " and entry_ty = '" + Convert.ToString(mainRow["entry_ty"]) + "'" +
                                     " and date = '" + DateFormat.dateformat(Convert.ToDateTime(mainRow["date"])) + "'";

                            cmd = DataAcess.ExecuteNonQuery(cmd,sqlStr, "TX", true,ref connHandle);
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception EX)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connHandle);  
                            throw EX;
                        }
                    }
                    catch (Exception EX)
                    {
                        throw EX;  
                    }
                }

                sqlStr = "";
                sqlStr = DataAcess.GenDeleteString(DBPropsSession.Entry_Tbl + "Item", "tran_cd = " +
                            Convert.ToInt32(mainRow["tran_cd"]));
                cmd = DataAcess.ExecuteNonQuery(cmd,sqlStr, "TX", true,ref connHandle);
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception EX)
                {
                    DataAcess.RollBackTransaction(cmd.Transaction);
                    DataAcess.Connclose(connHandle);  
                    throw EX; 
                }
            } // End ItemPage

            if (DBPropsSession.AccountPage == true)
            {
                sqlStr = "Select Ac_id,Amount,Amt_ty,Ref_no,re_all from " + DBPropsSession.Entry_Tbl +
                         "acdet" + " where tran_cd = " +
                         Convert.ToInt32(mainRow["tran_cd"]);
                DataTable tmpAc_vw = DataAcess.ExecuteDataTable(sqlStr, cmd.Transaction,ref connHandle);

                if (DBPropsSession.AllocationPage == true)
                {
                    string meref_no = "";
                    string mentry_ty = "";
                    foreach (DataRow tmpAcRow in tmpAc_vw.Rows)
                    {
                        if (numFunction.toDecimal(tmpAcRow["re_all"]) > 0)
                        {
                            string mref_no = Convert.ToString(mainRow["entry_ty"]) +
                                             "/" +
                                             (DBNull.Value.Equals(tmpAcRow["ref_no"]) ? "" : Convert.ToString(tmpAcRow["re_no"]).Trim());

                            while (mref_no != "")
                            {
                                mentry_ty = strFunction.Left(mref_no, 2);
                                mref_no = mref_no.Trim().Substring(3);

                                if (mref_no.Trim().IndexOf(mentry_ty) < 0)
                                {
                                    meref_no = meref_no + mentry_ty + "/";
                                }

                                if (mref_no.Trim() == "")
                                {
                                    break;
                                }
                            }
                        }
                    }

                    string _tmpTbl = "";
                    string _chkTbl = "";
                    string _chkentry = "#";

                    while (meref_no != "")
                    {
                        mentry_ty = strFunction.Left(meref_no, 2);
                        meref_no = meref_no.Trim().Substring(3);
                        string sqlMall = "";
                        string sqlCond = "";
                        if (mentry_ty == Convert.ToString(mainRow["entry_ty"]).Trim())
                        {
                            sqlMall = DBPropsSession.Entry_Tbl + "mall";
                            sqlCond = " entry_ty ='" + Convert.ToString(mainRow["entry_ty"]).Trim() +
                                      " and tran_cd = " + Convert.ToInt32(mainRow["tran_cd"]);
                        }
                        else
                        {
                            _chkTbl = mentry_ty != _chkentry ?
                                      getChkTable.chkTable(mentry_ty, cmd,ref connHandle) :
                                     _chkTbl.Trim();
                            _chkentry = mentry_ty;
                            sqlMall = _chkTbl + "Mall";
                            sqlCond = " entry_all = '" + Convert.ToString(mainRow["entry_ty"]).Trim() +
                                      " and main_tran = " + Convert.ToInt32(mainRow["tran_cd"]);

                        }

                        sqlStr = "Select Tran_cd,Entry_ty,Date,Doc_no,Main_tran,Entry_all,Date_all,Doc_no,Ac_id," +
                                 " New_all,Tds,Disc From " + sqlMall.Trim() + " where " + sqlCond.Trim();

                        DataTable tmpMallVw = DataAcess.ExecuteDataTable(sqlStr, cmd.Transaction, ref connHandle);

                        foreach (DataRow tmpMallRow in tmpMallVw.Rows)
                        {
                            decimal mamt = numFunction.toDecimal(tmpMallRow["new_all"]);
                            decimal mamttds = numFunction.toDecimal(tmpMallRow["tds"]);
                            decimal mamtdisc = numFunction.toDecimal(tmpMallRow["disc"]);

                            sqlStr = "";
                            sqlCond = "";

                            if (Convert.ToString(tmpMallRow["entry_ty"]).Trim() ==
                                Convert.ToString(mainRow["entry_ty"]).Trim() &&
                                Convert.ToInt32(tmpMallRow["tran_cd"]) ==
                                Convert.ToInt32(mainRow["tran_cd"]))
                            {
                                
                                _chkTbl = Convert.ToString(tmpMallRow["entry_all"]) != _chkentry ?
                                    getChkTable.chkTable(Convert.ToString(tmpMallRow["entry_all"]), cmd,ref connHandle) :
                                    _chkTbl.Trim();
                                _tmpTbl = DBPropsSession.Entry_Tbl;
                                _chkentry = Convert.ToString(tmpMallRow["entry_all"]);
                                sqlMall = _chkTbl + "acdet";
                                sqlStr = " re_all = re_all - (" + mamt + mamttds + mamtdisc +")";
                                sqlCond = " entry_ty = '" + Convert.ToString(tmpMallRow["entry_all"]) + "'" +
                                          " and tran_cd = " + Convert.ToInt32(tmpMallRow["main_tran"]) +
                                          " and ac_id = " + Convert.ToInt32(tmpMallRow["ac_id"]);
                            }
                            else
                            {
                                _chkTbl = Convert.ToString(tmpMallRow["entry_ty"]).Trim() != _chkentry ?
                                    getChkTable.chkTable(Convert.ToString(tmpMallRow["entry_ty"]), cmd,ref connHandle) : _chkTbl;
                                _tmpTbl = _chkTbl;
                                _chkentry = Convert.ToString(tmpMallRow["entry_ty"]);
                                sqlMall = _chkTbl + "acdet";
                                sqlStr = " re_all = re_all - (" + mamt + mamttds + mamtdisc + ")" +
                                         ",tds = tds - " + mamttds + ",disc = disc - " + mamtdisc;
                                sqlCond = " entry_ty = '" + Convert.ToString(tmpMallRow["entry_ty"]).Trim() + "'" +
                                          " and tran_cd = " + Convert.ToInt32(tmpMallRow["tran_cd"]) +
                                          " and ac_id = " + Convert.ToInt32(tmpMallRow["ac_id"]);
                            }

                            cmd = DataAcess.ExecuteNonQuery(cmd, "update " + sqlMall + " set " + sqlStr + " where " + sqlCond, "TX", true, ref connHandle);
                            try
                            {
                                cmd.ExecuteNonQuery();
                                try
                                {
                                    sqlStr = DataAcess.GenDeleteString(_tmpTbl.Trim() + "mall", "entry_ty ='" + Convert.ToString(tmpMallRow["entry_ty"]) + "'" +
                                             " and tran_cd = " + Convert.ToInt32(tmpMallRow["tran_cd"]) +
                                             " and entry_all ='" + Convert.ToString(tmpMallRow["entry_all"]).Trim() + "'" +
                                             " and main_tran = " + Convert.ToInt32(tmpMallRow["main_tran"]) +
                                             " and ac_id = " + Convert.ToInt32(tmpMallRow["ac_id"]));
                                    cmd = DataAcess.ExecuteNonQuery(cmd, sqlStr, "TX", true, ref connHandle);
                                    cmd.ExecuteNonQuery();
                                }
                                catch (Exception EX)
                                {
                                    DataAcess.RollBackTransaction(cmd.Transaction);
                                    DataAcess.Connclose(connHandle);  
                                    throw EX;
                                }
                            }
                            catch (Exception EX)
                            {
                                throw EX;
                            }
                        }

                        if (meref_no.Trim() == "")
                            break;
                    } // End While
                } // End Allocation Page

                if (tmpAc_vw != null)
                {
                    foreach (DataRow tmpAcRow in tmpAc_vw.Rows)
                    {
                        decimal mamt = Convert.ToDecimal(tmpAcRow["amount"]);
                        string mfld = Convert.ToString(tmpAcRow["amt_ty"]);

                        sqlStr = " update ac_bal set " + mfld.Trim() + " = " +
                                 mfld + " - " + mamt + " where ac_id = " +
                                 Convert.ToInt32(tmpAcRow["ac_id"]);
                        cmd = DataAcess.ExecuteNonQuery(cmd, sqlStr, "TX", true, ref connHandle);
                        try
                        {
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception EX)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connHandle);  
                            throw EX;
                        }
                    }
                }

                sqlStr = "";
                sqlStr = DataAcess.GenDeleteString(DBPropsSession.Entry_Tbl + "acdet", " tran_cd = " +
                         Convert.ToInt32(mainRow["tran_cd"]));

                cmd = DataAcess.ExecuteNonQuery(cmd, sqlStr, "TX", true, ref connHandle);  
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception EX)
                {
                    DataAcess.RollBackTransaction(cmd.Transaction);
                    DataAcess.Connclose(connHandle);      
                    throw EX;
                }
            } // End AccountPage

            sqlStr = "";
            sqlStr = DataAcess.GenDeleteString(DBPropsSession.Entry_Tbl + "main"," tran_cd = " +
                     Convert.ToInt32(mainRow["tran_cd"]));
            cmd = DataAcess.ExecuteNonQuery(cmd,sqlStr, "TX", true,ref connHandle);  
            try
            {
                cmd.ExecuteNonQuery(); 
            }
            catch (Exception EX)
            {
                DataAcess.RollBackTransaction(cmd.Transaction);
                DataAcess.Connclose(connHandle);  
                throw EX;
            }

            DataAcess.CommitTransaction(cmd.Transaction);  
        }

        public void GridItem_RowDeleting(ref DataSet MainDataSet,
            GridView GridItem,
            GridView grdCharges,
            GridView GridAccount,
            GridView grdAllocation,
            TextBox txtItemTotal, 
            TextBox txtTotalQty, 
            TextBox txtNetAmount, 
            TextBox txtAccNetAmount,
            TextBox txtGrossAmt,
            TextBox txtdedBefTax,
            TextBox txtTaxCharges,
            TextBox txtExAmt,
            TextBox txtAddCharges,
            TextBox txtTaxAmt,
            TextBox txtNonTax,
            TextBox txtfdisc,
            TextBox txtRoundoff,
            TextBox txtNetAmountTax)
        {
            DataTable main_vw, item_vw, tax_vw1, tax_vw, dcmast_vw, litemall_vw, manu_det_vw, stockStatus_vw, company;
            main_vw = MainDataSet.Tables["Main_vw"];
            item_vw = MainDataSet.Tables["item_vw"];
            tax_vw1 = MainDataSet.Tables["tax_vw1"];
            tax_vw = MainDataSet.Tables["tax_vw"];
            dcmast_vw = MainDataSet.Tables["dcmast_vw"];
            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
            {
                litemall_vw = MainDataSet.Tables["litemall_vw"];
                manu_det_vw = MainDataSet.Tables["manu_det_vw"];
            }
            else
            {
                litemall_vw = null;
                manu_det_vw = null;
            }

           
            company = MainDataSet.Tables["company"];
            SqlDataReader dr;
            vuGridCalculation taxCalculation = new vuGridCalculation();
            vuAccountPosting  accPosting = new vuAccountPosting();
            vouGridFill gridFill = new vouGridFill();

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            //delete row from Item_vw
            DataRow viewRow = null;
            for (int i = 0; i < GridItem.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)GridItem.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    string key = GridItem.DataKeys[i].Values[0].ToString().Trim();
                    viewRow = item_vw.Select("ItSerial='" + key + "'")[0];

                    string sqlstr = "";
                    if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
                        strFunction.InList(Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper(),
                                    new string[] { "EXCISE", "NON-EXCISE" }) == true)
                    {
                        if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR", "DC" }) == true ||
                            strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR", "DC" }) == true) ||
                            ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                            bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == false))
                        {
                            sqlstr = "Select top 1 Entry_ty From Litemall where pentry_ty ='" + 
                                     Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and ptran_cd =" +
                                     numFunction.toInt32(main_vw.Rows[0]["tran_cd"]) + " and pitserial ='" +
                                     Convert.ToString(viewRow["itserial"]).Trim() + "'";
                            dr = DataAcess.ExecuteDataReader(sqlstr,ref connHandle);
                            if (dr.HasRows == true)
                            {
                                dr.Close();
                                dr.Dispose();
                                DataAcess.Connclose(connHandle); 
                                throw new Exception("Delete not allow, \\n Transaction has been passed against this item");
                            }
                            dr.Close();
                            dr.Dispose();
                            DataAcess.Connclose(connHandle);  
                        }
                    }


                    bool isFound = false;
                    sqlstr = "Select top 1 Re_qty From " + DBPropsSession.Entry_Tbl.Trim() + "item where tran_cd = " + numFunction.toInt32(main_vw.Rows[0]["tran_cd"]) +
                             " and itserial = '" + Convert.ToString(viewRow["itserial"]).Trim() +"'";

                    dr = DataAcess.ExecuteDataReader(sqlstr,ref connHandle);
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            if (numFunction.toDecimal(dr["re_qty"]) > 0)
                            {
                                isFound = true;
                            }
                        }
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);
  
                    if (DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0 && isFound == false)
                    {
                        if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "LI", "RL" }) == true ||
                             strFunction.InList(DBPropsSession.Behave, new string[] { "LI", "RL" }) == true))
                        {
                            string rmdet = ((DBPropsSession.PcvType == "LI" || DBPropsSession.Behave == "LI") ?
                                "IR" : "II") + "RMDET";
                            sqlstr = "Select Top 1 Entry_ty From " + rmdet + " where li_tran_cd =" +
                                     numFunction.toInt32(main_vw.Rows[0]["tran_cd"]) +
                                     " and li_itserial ='" + Convert.ToString(viewRow["itserial"]).Trim() + "'";
                            dr = DataAcess.ExecuteDataReader(sqlstr,ref connHandle);
                            if (dr.HasRows == true)
                            {
                                isFound = true;
                            }
                            dr.Dispose();
                            dr.Close();
                            DataAcess.Connclose(connHandle);      
                        }
                    }

                    if (isFound == true)
                    {
                        throw new Exception("Delete not allow, Transaction has been passed against this transaction");
                    }

                    if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
                       strFunction.InList(Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper(),
                                   new string[] { "EXCISE", "NON-EXCISE" }) == true)
                    {
                        if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                           strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
                        {
                            if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS", "IR"}) == true ||
                               strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS", "IR" }) == true) ||
                               ((DBPropsSession.PcvType == "GT" ||  DBPropsSession.Behave == "GT") &&
                               bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == true))
                            {
                                string filterExp = "entry_ty ='" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and "+
                                                   " tran_cd =" + numFunction.toInt32(main_vw.Rows[0]["tran_cd"]) + " and " +
                                                   " itserial ='" + Convert.ToString(viewRow["itserial"]).Trim() + "'";
                                foreach (DataRow litemallRow in litemall_vw.Select(filterExp))
                                {
                                    litemallRow.Delete();  
                                }

                                litemall_vw.AcceptChanges(); 
                            }

                            if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR" }) == true ||
                                strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR" }) == true) ||
                                ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                                 bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == false))
                            {
                                string filterExp = "entry_ty ='" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                                                   " tran_cd =" + numFunction.toInt32(main_vw.Rows[0]["tran_cd"]) + " and " +
                                                   " itserial ='" + Convert.ToString(viewRow["itserial"]).Trim() + "'";

                                foreach (DataRow manuRow in manu_det_vw.Select(filterExp))
                                {
                                    manuRow.Delete();
                                }

                                manu_det_vw.AcceptChanges(); 
                            }
                        }
                    }

                    viewRow.Delete();
                    viewRow.AcceptChanges();
                    item_vw.AcceptChanges();
                }
            }

            // Regenerate item No 
            int itemNo = 1;
            foreach (DataRow itviewRow in item_vw.Rows)
            {
                itviewRow["item_no"] = Convert.ToString(itemNo);
                itemNo = itemNo + 1;
                itviewRow.AcceptChanges();
            }
            
            item_vw.AcceptChanges();

            taxCalculation.SumColumns(main_vw,
                    item_vw,
                    dcmast_vw, 
                    tax_vw, 
                    tax_vw1, 
                    "", "", "", 
                    DBPropsSession.ItemPage, 
                    DBPropsSession.ChargesPage, 
                    DBPropsSession.AccountPage, 
                    txtItemTotal, 
                    txtTotalQty, 
                    txtNetAmount, 
                    txtAccNetAmount, 
                    DBPropsSession.HowtoCalculateExAmt, 
                    DBPropsSession.Vchkprod, 
                    DBPropsSession.PcvType, 
                    DBPropsSession.Behave, 
                    DBPropsSession.AddMode, 
                    DBPropsSession.EditMode);

            grdCharges.DataSource = tax_vw1;
            grdCharges.DataBind();


            if (DBPropsSession.AccountPage == true)
            {
                accPosting.AccountPosting(MainDataSet, 
                        txtItemTotal, 
                        txtNetAmount, 
                        txtAccNetAmount, 
                        DBPropsSession.ItemPage, 
                        DBPropsSession.ChargesPage, 
                        DBPropsSession.AccountPage, 
                        DBPropsSession.Vchkprod, 
                        DBPropsSession.PcvType, 
                        DBPropsSession.Behave, 
                        DBPropsSession.HowtoCalculateExAmt, 
                        DBPropsSession.SalesTaxItem,ref connHandle);

                GridAccount.DataSource = MainDataSet.Tables["acdet_vw"]; ;
                gridFill.gridBind(GridAccount, null);
                if (DBPropsSession.AllocationPage)
                {
                    string[] grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdAllocation.DataSource = MainDataSet.Tables["acdet_vw"]; ;
                    gridFill.gridBind(grdAllocation, grdCols);
                }
                
            }

            //Binding Griditem
            GridItem.DataSource = item_vw;
            if (item_vw.Rows.Count > 0)
                gridFill.gridBind(GridItem, null);
            else
            {
                string[] grdCols = new string[GridItem.Columns.Count];
                grdCols[0] = "0";
                string[] grdAtt;
                for (int i = 0; i < GridItem.Columns.Count; i++)
                {
                    if (GridItem.Columns[i].AccessibleHeaderText.Trim().IndexOf('|') >= 0)
                    {
                        grdAtt = GridItem.Columns[i].AccessibleHeaderText.Trim().ToUpper().Split('|');
                        if (grdAtt[1].Trim() == "GRAPHICALCHECKBOX")
                        {
                            grdCols[i] = i.ToString().Trim();
                        }
                    }
                }

                gridFill.gridBind(GridItem, grdCols);
                grdCols = null;
                grdAtt = null;
            }
            
            // Refresh header fields
            RefreshHeaderField(company,
                main_vw,
                txtGrossAmt,
                txtdedBefTax,
                txtTaxCharges,
                txtExAmt,
                txtAddCharges,
                txtTaxAmt,
                txtNonTax,
                txtfdisc,
                txtRoundoff,
                txtNetAmountTax);

            main_vw.Dispose();
            item_vw.Dispose();

            if (litemall_vw != null) 
                litemall_vw.Dispose();

            tax_vw1.Dispose();
            tax_vw.Dispose();
            dcmast_vw.Dispose();

            if (manu_det_vw !=null) 
                manu_det_vw.Dispose();

            company.Dispose();
            DataAcess.Connclose(connHandle);  // Close connection
        }

        public void btnAddSave_Click(DataTable main_vw,
                    DataTable acdet_vw,
                    DataTable lcode_vw,
                    GridView GridAccount,
                    GridView grdAllocation,
                    DropDownList DropAddDRCR,
                    TextBox txtBPName,
                    HtmlTable tblAcadd,
                    NumericTextBox txtAddAmt)
        {
            try
            {
                decimal SumAmt = (txtAddAmt.Text == "" ? 0 : numFunction.toDecimal(txtAddAmt.Text));
                vuAccountPosting AccountPosting = new vuAccountPosting();
                
                int acID = 0;
                string sqlStr = " select Ac_id from ac_mast where ac_name ='" + txtBPName.Text + "'";
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                SqlDataReader dr = DataAcess.ExecuteDataReader(sqlStr,ref connHandle);
                if (dr.HasRows == false)
                {
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);  
                    throw new Exception("Party name not found in master");
                }

                while (dr.Read())
                {
                    acID = numFunction.toInt32(dr["ac_id"]);
                }
                dr.Close();
                dr.Dispose();
                DataAcess.Connclose(connHandle);

                AccountPosting.addtoEffect(acdet_vw,
                        main_vw,
                        SumAmt,
                        DropAddDRCR.SelectedValue.ToString().Trim(),
                        txtBPName.Text.ToString().Trim(),
                        Convert.ToInt32(acID));

                vouGridFill vouGridInit = new vouGridFill();
                GridAccount.DataSource = acdet_vw;
                string[] grdCols = vouGridInit.grdAccountColSHide(lcode_vw);
                vouGridInit.gridBind(GridAccount, grdCols);
                if (DBPropsSession.AllocationPage)
                {
                    grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdAllocation.DataSource = acdet_vw;
                    vouGridInit.gridBind(grdAllocation, grdCols);
                }

                tblAcadd.Visible = false;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        public void GridAccount_RowDeleting(DataTable acdet_vw,
                DataTable lcode_vw,
                DataTable mall_vw,
                GridView GridAccount,
                GridView grdAllocation,
                bool isContainsMall_vw,
                int RowIndex)
        {
            try
            {
                if (acdet_vw.Rows.Count > 2)
                {
                    if (DBPropsSession.AllocationPage == true &&
                        isContainsMall_vw == true)
                    {
                        // code is pending
                        string acName = GridAccount.Rows[RowIndex].Cells[0].Text.Trim();
                        //bool found = false;
                        //decimal disc = 0;
                        //decimal tds = 0;
                        try
                        {
                            DataRow MallVwRow = mall_vw.Select("Party_nm = '" + acName + "'")[0];
                        }
                        catch
                        {
                        }
                        // code is pending
                    }
                    DataRow DeleteRow;
                    string key = GridAccount.DataKeys[RowIndex].Value.ToString();
                    DeleteRow = acdet_vw.Select("acSerial = '" + key + "'")[0];
                    DeleteRow.Delete();
                    DeleteRow.AcceptChanges();

                    vouGridFill vouGridInit = new vouGridFill();
                    GridAccount.DataSource = acdet_vw;
                    string[] grdCols = vouGridInit.grdAccountColSHide(lcode_vw);
                    vouGridInit.gridBind(GridAccount, grdCols);
                    if (DBPropsSession.AllocationPage == true)
                    {
                        grdCols = new string[2];
                        grdCols[0] = "0";
                        grdCols[1] = "";
                        grdAllocation.DataSource = acdet_vw;
                        vouGridInit.gridBind(grdAllocation, grdCols);
                    }
                }
                else
                {
                    throw new Exception("There should be atleast 2 accounting effects..!!");
                }

            }
            catch (Exception Ex)
            {
                throw Ex; 
            }
        }

        public DataTable StockStatus(DataSet MainDataSet, 
                int deci,
                string pWhat,
                int itCode,
                string itName,
                string itSerial,
                decimal[] StockArr)
        {
            string FormatQty = "";
            DataRow row;
            if (deci != 0)
            {
                for(int i=0;i<deci;i++)
                {
                    FormatQty += "0";
                }
                FormatQty = "{0:000." + FormatQty+";Nothing}";
            }
            else
            {
                FormatQty = "{0:000.00;Nothing}";
            }
            

            if (pWhat == "S")
            {
                DataTable itStockTbl = new DataTable("StockDis");
                DataColumn itStockCol = new DataColumn();

                itStockCol.DataType = Type.GetType("System.Int32");
                itStockCol.ColumnName = "it_code";
                itStockTbl.Columns.Add(itStockCol);

                itStockCol = new DataColumn();
                itStockCol.DataType = Type.GetType("System.String");
                itStockCol.ColumnName = "itSerial";
                itStockTbl.Columns.Add(itStockCol);

                itStockCol = new DataColumn();
                itStockCol.DataType = Type.GetType("System.String");
                itStockCol.ColumnName = "it_name";
                itStockTbl.Columns.Add(itStockCol);

                itStockCol = new DataColumn();
                itStockCol.DataType = Type.GetType("System.Decimal");
                itStockCol.ColumnName = "StockBal";
                itStockTbl.Columns.Add(itStockCol);

                itStockCol = new DataColumn();
                itStockCol.DataType = Type.GetType("System.Decimal");
                itStockCol.ColumnName = "StockBalW";
                itStockTbl.Columns.Add(itStockCol);

                itStockCol = new DataColumn();
                itStockCol.DataType = Type.GetType("System.Decimal");
                itStockCol.ColumnName = "StockPoBal";
                itStockTbl.Columns.Add(itStockCol);

                itStockCol = new DataColumn();
                itStockCol.DataType = Type.GetType("System.Decimal");
                itStockCol.ColumnName = "StockSoBal";
                itStockTbl.Columns.Add(itStockCol);

                itStockCol = new DataColumn();
                itStockCol.DataType = Type.GetType("System.Decimal");
                itStockCol.ColumnName = "LogicalStk";
                itStockTbl.Columns.Add(itStockCol);

                if (MainDataSet.Tables.Contains("StockDis") == true)
                    MainDataSet.Tables.Remove("StockDis");
                
                row = itStockTbl.NewRow();
                row["it_code"] = itCode;
                row["it_name"] = itName.Trim();
                row["itserial"] = itSerial.Trim();
                row["StockBal"] = StockArr[0] > 0 ? string.Format(FormatQty, StockArr[0]) :
                                    string.Format("{0:00.00}",StockArr[0]);
                row["StockBalW"] = StockArr[1] > 0 ? string.Format(FormatQty,StockArr[1]) :
                                    string.Format("{0:00.00}", StockArr[1]);
                row["StockPoBal"] = StockArr[2] > 0 ? string.Format(FormatQty,StockArr[2]) :
                                    string.Format("{0:00.00}", StockArr[2]);
                row["StockSoBal"] = StockArr[3] > 0 ? string.Format(FormatQty,StockArr[3]) :
                                            string.Format("{0:00.00}", StockArr[3]);
                row["LogicalStk"] = StockArr[3] > 0 ? string.Format(FormatQty, (StockArr[0] + (StockArr[2] - StockArr[3]))) :
                                                string.Format("{0:00.00}", (StockArr[0] + (StockArr[2] - StockArr[3])));
                itStockTbl.Rows.Add(row);
                itStockTbl.AcceptChanges();

                MainDataSet.Tables.Add(itStockTbl);
                MainDataSet.AcceptChanges();
                return itStockTbl;
            }
            else
            {
                DataRow PrevRow = MainDataSet.Tables["StockDis"].Rows[0];
                if (MainDataSet.Tables.Contains("StockStatus") == false)
                {
                    DataTable itStockTbl = new DataTable("StockStatus");
                    DataColumn itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.Int32");
                    itStockCol.ColumnName = "it_code";
                    itStockTbl.Columns.Add(itStockCol);

                    itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.String");
                    itStockCol.ColumnName = "itSerial";
                    itStockTbl.Columns.Add(itStockCol);

                    itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.String");
                    itStockCol.ColumnName = "it_name";
                    itStockTbl.Columns.Add(itStockCol);

                    itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.Decimal");
                    itStockCol.ColumnName = "StockBal";
                    itStockTbl.Columns.Add(itStockCol);

                    itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.Decimal");
                    itStockCol.ColumnName = "StockBalW";
                    itStockTbl.Columns.Add(itStockCol);

                    itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.Decimal");
                    itStockCol.ColumnName = "StockPoBal";
                    itStockTbl.Columns.Add(itStockCol);

                    itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.Decimal");
                    itStockCol.ColumnName = "StockSoBal";
                    itStockTbl.Columns.Add(itStockCol);

                    itStockCol = new DataColumn();
                    itStockCol.DataType = Type.GetType("System.Decimal");
                    itStockCol.ColumnName = "LogicalStk";
                    itStockTbl.Columns.Add(itStockCol);

                    MainDataSet.Tables.Add(itStockTbl);

                    row = MainDataSet.Tables["StockStatus"].NewRow();
                    row["it_code"] = Convert.ToInt32(PrevRow["it_code"]);
                    row["itSerial"] = Convert.ToString(PrevRow["ItSerial"]);
                    row["it_name"] = Convert.ToString(PrevRow["It_name"]);
                    row["StockBal"] = numFunction.toDecimal(PrevRow["StockBal"]);
                    row["StockBalW"] = numFunction.toDecimal(PrevRow["StockBalW"]);
                    row["StockPoBal"] = numFunction.toDecimal(PrevRow["StockPoBal"]);
                    row["StockSoBal"] = numFunction.toDecimal(PrevRow["StockSoBal"]);
                    row["LogicalStk"] = string.Format(FormatQty,
                            numFunction.toDecimal(PrevRow["StockBal"]) +
                            (numFunction.toDecimal(PrevRow["StockPoBal"]) -
                             numFunction.toDecimal(PrevRow["StockSoBal"])));
                }
                else
                {
                    row = MainDataSet.Tables["StockStatus"].NewRow();
                    row["it_code"] = Convert.ToInt32(PrevRow["it_code"]);
                    row["itSerial"] = Convert.ToString(PrevRow["ItSerial"]);
                    row["it_name"] = Convert.ToString(PrevRow["It_name"]);
                    row["StockBal"] = numFunction.toDecimal(PrevRow["StockBal"]);
                    row["StockBalW"] = numFunction.toDecimal(PrevRow["StockBalW"]);
                    row["StockPoBal"] = numFunction.toDecimal(PrevRow["StockPoBal"]);
                    row["StockSoBal"] = numFunction.toDecimal(PrevRow["StockSoBal"]);
                    row["LogicalStk"] = string.Format(FormatQty,numFunction.toDecimal(PrevRow["StockBal"]) + 
                                                                (numFunction.toDecimal(PrevRow["StockPoBal"]) - 
                                                                numFunction.toDecimal(PrevRow["StockSoBal"])));
                }
                MainDataSet.Tables["StockStatus"].Rows.Add(row);
                MainDataSet.Tables["StockStatus"].AcceptChanges();
                MainDataSet.Tables.Remove("StockDis");
                MainDataSet.AcceptChanges();
                return MainDataSet.Tables["StockStatus"];

            }
        }

        public void dropSaleTax_SelectedIndexChanged(DataTable main_vw,
                DataTable tax_vw1,
                DataTable item_vw,
                DataTable dcmast_vw,
                DataTable tax_vw,
                DataTable Stax_vw,
                DataTable company,
                GridView grdCharges)
        {

            string strSTaxCode = "";
            strSTaxCode = ((DropDownList)grdCharges.Rows[grdCharges.EditIndex].FindControl("dropSaleTax")).SelectedValue.ToString().Trim();

            //For Each staxRow In MainDataSet.Tables("Stax_vw").Select("tax_name = '" + strSTaxCode + "'")
            foreach (DataRow staxRow in Stax_vw.Rows)
            {
                if (Convert.ToString(staxRow["tax_name"]).Trim() == strSTaxCode ||
                    strSTaxCode == "NO-TAX")
                {
                    main_vw.Rows[0]["tax_name"] = Convert.ToString(staxRow["tax_name"]).Trim();
                    main_vw.Rows[0]["taxamt"] = 0;
                    main_vw.Rows[0]["Form_nm"] = Convert.ToString(staxRow["form_nm"]).Trim();
                    main_vw.Rows[0]["Form_no"] = "";

                    DataRow taxRow = null;
                    bool isFoundRow = false;
                    try  // find row in tax_Vw1 for replace sale tax
                    {
                        taxRow = tax_vw1.Select("head_nm = 'NO-TAX'")[0];
                        isFoundRow = true;
                    }
                    catch 
                    {
                        isFoundRow = false;
                    }

                    if (isFoundRow == true)
                    {
                        taxRow["amtexpr"] = Convert.ToString(staxRow["amtexpr"]).Trim();
                        taxRow["entry_ty"] = DBPropsSession.Behave.Trim();
                        taxRow["code"] = "S";
                        taxRow["Head_Nm"] = strSTaxCode;
                        taxRow["def_amt"] = 0;
                        taxRow["form_nm"] = "";
                        taxRow["def_pert"] = numFunction.toDecimal(staxRow["level1"]);
                        taxRow["fld_nm"] = "TAXAMT";
                        taxRow["round_off"] = bitFunction.toBoolean(company.Rows[0]["ssamt_op"]);
                        taxRow["att_file"] = true;
                        taxRow["disp_sign"] = "%";

                        if (strFunction.Left(DBPropsSession.Behave, 1) == "P")
                            taxRow["dac_name"] = Convert.ToString(staxRow["ac_name3"]).Trim();
                        else
                            taxRow["dac_name"] = Convert.ToString(staxRow["ac_name1"]).Trim();

                        DataRow staxVwRow = null;
                        bool isFoundStaxRow = false;
                        try
                        {
                            staxVwRow = tax_vw.Select("Code = 'S'")[0];
                            isFoundStaxRow = true;
                        }
                        catch
                        {
                            isFoundStaxRow = false;
                        }

                        if (isFoundStaxRow == true)
                        {
                            // if record is found then update row from tax_vw1 table
                            for (int i = 0; i <= tax_vw1.Columns.Count - 1; i++)
                            {
                                staxVwRow[i] = taxRow[i];
                            }
                        }
                        else
                        {
                            // record not found in tax_vw table then add new row from tax_vw1
                            staxVwRow = tax_vw.NewRow();
                            for (int i = 0; i <= tax_vw1.Columns.Count - 1; i++)
                            {
                                staxVwRow[i] = taxRow[i];
                            }
                           tax_vw.Rows.Add(staxVwRow);
                        }
                    }
                    else
                    {
                        taxRow = tax_vw1.Select("code = 'S'")[0];
                        taxRow["amtexpr"] = Convert.ToString(staxRow["amtexpr"]).Trim();
                        taxRow["entry_ty"] = DBPropsSession.Behave.Trim();
                        taxRow["code"] = "S";
                        taxRow["Head_Nm"] = strSTaxCode;
                        taxRow["def_amt"] = 0;
                        taxRow["form_nm"] = "";
                        taxRow["def_pert"] = numFunction.toDecimal(staxRow["level1"]);
                        taxRow["fld_nm"] = "TAXAMT";
                        taxRow["round_off"] = bitFunction.toBoolean(company.Rows[0]["ssamt_op"]);
                        taxRow["att_file"] = true;
                        taxRow["disp_sign"] = "%";

                        if (strFunction.Left(DBPropsSession.Behave, 1) == "P")
                            taxRow["dac_name"] = Convert.ToString(staxRow["ac_name3"]).Trim();
                        else
                            taxRow["dac_name"] = Convert.ToString(staxRow["ac_name1"]).Trim();


                        DataRow staxVwRow = null;
                        bool isFoundStaxRow = false;
                        try
                        {
                            staxVwRow = tax_vw.Select("Code = 'S'")[0];
                            isFoundStaxRow = true;
                        }
                        catch
                        {
                            isFoundStaxRow = false;
                        }

                        if (isFoundStaxRow == true)
                        {
                            // if record is found then update row from tax_vw1 table
                            for (int i = 0; i <= tax_vw1.Columns.Count - 1; i++)
                            {
                                staxVwRow[i] = taxRow[i];
                            }

                        }
                        else
                        {
                            // record not found in tax_vw table then add new row from tax_vw1
                            staxVwRow = tax_vw.NewRow();
                            for (int i = 0; i <= tax_vw1.Columns.Count - 1; i++)
                            {
                                staxVwRow[i] = taxRow[i];
                            }

                            tax_vw.Rows.Add(staxVwRow);
                        }
                    }
                    if (strSTaxCode == "NO-TAX")
                    {
                        taxRow["def_pert"] = 0.0;
                        taxRow["def_amt"] = 0.0;
                    }

                    ((TextBox)grdCharges.Rows[grdCharges.EditIndex].FindControl("txtChargesPer")).Text = Convert.ToString(taxRow["def_pert"]);
                    ((TextBox)grdCharges.Rows[grdCharges.EditIndex].FindControl("txtChargesAmt")).Text = Convert.ToString(taxRow["def_amt"]);

                    taxRow.AcceptChanges();
                }

               
                tax_vw1.AcceptChanges();
                tax_vw.AcceptChanges();
                main_vw.AcceptChanges();  
            }


        }

        public void btnitadd_Click(DataSet MainDataSet,
                GridView grdCharges,
                GridView GridAccount,
                GridView GridItem,
                GridView grdAllocation,
                HtmlTable tblItDetails, 
                Panel pnlItDetails,
                TextBox txtGrossAmt,
                TextBox txtdedBefTax,
                TextBox txtTaxCharges,
                TextBox txtExAmt,
                TextBox txtAddCharges,
                TextBox txtTaxAmt,
                TextBox txtNonTax,
                TextBox txtfdisc,
                TextBox txtRoundoff,
                TextBox txtNetAmountTax,
                TextBox txtItemTotal, 
                TextBox txtTotalQty, 
                TextBox txtNetAmount, 
                TextBox txtAccNetAmount,
                TextBox txtdate,
                HiddenField hidItDetStatus,
                ref DataRow itemPreRow)
                
                
        {
            string itSerialvar = "";
            string[] doWhat = hidItDetStatus.Value.Split('|');
            DataRow Item_Row = null;

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            if (doWhat[1].ToString().Trim() == "NEW")
            {
                if (itemPreRow == null)
                {
                    vuGenerateNo genItemNo = new vuGenerateNo();
                    getNullUpdate DataNullUpdate = new getNullUpdate();

                    Item_Row = MainDataSet.Tables["item_vw"].NewRow();
                    Item_Row = DataNullUpdate.NullUpdate(Item_Row);
                    Item_Row["entry_ty"] = DBPropsSession.PcvType.Trim();
                    Item_Row["doc_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim();
                    Item_Row["tran_cd"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                    Item_Row["pmKey"] = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["inv_stk"]).Trim();
                    Item_Row["Item_no"] = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
                    Item_Row["party_nm"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]);
                    Item_Row["ac_id"] = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["ac_id"]);
                    itSerialvar = genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "itSerial", true, 5);
                    Item_Row["ItSerial"] = itSerialvar;
                    Item_Row["Date"] = DateFormat.TodateTime(txtdate.Text);
                }
                else
                {
                    Item_Row = MainDataSet.Tables["item_vw"].NewRow();
                    Item_Row = DataAcess.ExactScatterGatherRow(itemPreRow,Item_Row);
                    itemPreRow = null;  // null DataRow
                }
            }
            else
            {
                if (doWhat[1].ToString().Trim() == "EDIT")
                {
                    Item_Row = MainDataSet.Tables["item_vw"].Select("ItSerial = '" + doWhat[0].ToString().Trim() + "'")[0];
                    if (itemPreRow != null)
                    {
                        Item_Row = DataAcess.ExactScatterGatherRow(itemPreRow, Item_Row);
                        itemPreRow = null;  // null DataRow
                    }
                }
            }

            // Retrive data from dynamic columns to item_vw
            vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
            readDynamicTbl.btnClick(tblItDetails, Item_Row,"BOXING",null);

            int itId = 0;
            string sqlStr = "select Top 1 It_code,chapno,exrate,ldeactive,deactfrom,mrprate " +
                            " from it_mast where it_name ='" +
                            Convert.ToString(Item_Row["item"]).Trim()  + "'";
            DataTable DtIt = DataAcess.ExecuteDataTable(sqlStr,"_qq",connHandle);
            DataAcess.Connclose(connHandle); 
            if (DtIt.Rows.Count == 0)
            {
                DtIt.Dispose();
                DataAcess.Connclose(connHandle);  
                throw new Exception("Item name not found in master");
            }
            else
            {
                itId = numFunction.toInt32(DtIt.Rows[0]["It_code"]);
            }
            
            Item_Row["it_code"] = itId;
            if (Item_Row.Table.Columns.Contains("u_mrprate") == true)
            {
                Item_Row["u_mrprate"] = numFunction.toDecimal(DtIt.Rows[0]["mrprate"]); 
            }

            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(), new string[] { "EXCISE", "NON-EXCISE" }) == true
                && (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
            {
                if ((DBPropsSession.PcvType == "AR" || DBPropsSession.Behave == "AR") ||
                     ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                      bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true))
                {
                    if (numFunction.toDecimal(Item_Row["u_basduty"]) == 0 &&
                        numFunction.toDecimal(Item_Row["exrate"]) != 0 &&
                        Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                    {
                        Item_Row["u_basduty"] = numFunction.toDecimal(DtIt.Rows[0]["exrate"]);
                    }
                    Item_Row["tariff"] = Convert.ToString(DtIt.Rows[0]["chapno"]).Trim();
                }

                if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                {
                    if (Convert.ToString(DtIt.Rows[0]["chapno"]).Trim() == "")
                    {
                        DtIt.Dispose();
                        DataAcess.Connclose(connHandle);
                        throw new Exception("Chapter Head No. not properly entered...");
                    }
                }

                if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" &&
                   (strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "DC", "GT" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "DC", "GT" }) == true))
                {
                    bool isShiptoRec = false;
                    if (MainDataSet.Tables["main_vw"].Columns.Contains("scons_id") == true)
                    {
                        if (numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["scons_id"]) > 0)
                        {
                            isShiptoRec = true;
                        }
                    }

                    if (isShiptoRec == true)
                    {
                        sqlStr = "select Top 1 Eccno from " +
								 " Shipto where Ac_id = " + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]) +
                                 " And Shipto_id = " + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["scons_id"]);
                     }
                    else
                    {
                        sqlStr = "select Top 1 Eccno from " +
								 " ac_mast where Ac_id = " + numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]);
                    }

                    SqlDataReader dr = DataAcess.ExecuteDataReader(sqlStr,ref connHandle);
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            if (Convert.ToString(dr["eccno"]).Trim() == "")
                            {
                                dr.Dispose();
                                DataAcess.Connclose(connHandle); 
                                throw new Exception("Ecc. No. cannot be blank.."); 
                            }
                        }
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle);
                }

                if (bitFunction.toBoolean(MainDataSet.Tables["manufact"].Rows[0]["et_flag"]) == true &&
                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                {
                    DBPropsSession.VarETGoDown = ""; 
                }

                if (bitFunction.toBoolean(MainDataSet.Tables["manufact"].Rows[0]["net_flag"]) == true &&
                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                {
                    DBPropsSession.VarETGoDown = "";
                }

                if (DBPropsSession.PcvType == "IR")
                {
                    Item_Row["ware_nm"] = DBPropsSession.VarETGodownTo.Trim();
                    Item_Row["warenm_fr"] = DBPropsSession.VarETGoDown.Trim();
                }
                else
                {
                    Item_Row["ware_nm"] = DBPropsSession.VarETGoDown.Trim();
                }
            }
            if (doWhat[1].ToString().Trim() == "NEW")
                MainDataSet.Tables["item_vw"].Rows.Add(Item_Row);

            MainDataSet.Tables["item_vw"].AcceptChanges();

            vuGridCalculation ItemGridCalculation = new vuGridCalculation(); 
            ItemGridCalculation.gridItemCal(GridItem, MainDataSet, Item_Row,DBPropsSession.PcvType.Trim(), 
                                            DBPropsSession.Behave.Trim(), DBPropsSession.Vchkprod.Trim(), DBPropsSession.HowtoCalculateExAmt,
                                            DBPropsSession.ItemPage, DBPropsSession.ChargesPage, DBPropsSession.AccountPage, 
                                            txtItemTotal, txtTotalQty, txtNetAmount, txtAccNetAmount, DBPropsSession.SalesTaxItem, 
                                            DBPropsSession.AddMode, DBPropsSession.EditMode);

            GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
            GridAccount.DataBind();

            grdAllocation.DataSource = MainDataSet.Tables["acdet_vw"];
            grdAllocation.DataBind();

            vouGridFill gridDe = new vouGridFill();
            GridItem.DataSource = MainDataSet.Tables["item_vw"];
            gridDe.gridBind(GridItem, null);

            grdCharges.DataSource = MainDataSet.Tables["tax_vw1"];
            grdCharges.DataBind();

            tblItDetails.Rows.Clear();
            tblItDetails.Controls.Clear();  
            pnlItDetails.Style.Add("display", "none");

            RefreshHeaderField(MainDataSet.Tables["Company"],
                    MainDataSet.Tables["main_vw"],
                    txtGrossAmt,
                    txtdedBefTax,
                    txtTaxCharges,
                    txtExAmt,
                    txtAddCharges,
                    txtTaxAmt,
                    txtNonTax,
                    txtfdisc,
                    txtRoundoff,
                    txtNetAmountTax); // Refresh header fields 

            DataAcess.Connclose(connHandle);
        }

        public void dropItem_SelectedIndexChanged(TextBox txtItem,
                    TextBox txtrate,
                    TextBox txtqty,
                    GridView grdStockStatus,
                    HiddenField hidbalQty,
                    HiddenField hiddItemTag,
                    HiddenField hidInvStk,
                    HiddenField hidNegItBal,
                    HiddenField hidNonStk, 
                    DataSet MainDataSet,
                    Button btnItAdd)
        {
            if (txtItem.Text == "")
                throw new Exception("Item cannot be blank..");

            vuStockCheck stockCheck = new vuStockCheck();
            decimal[] stock = new decimal[4];
            decimal Rate = 0;
            decimal u_qty = 0;
            string nonStk = "";
            string sqlStr = "";

            int itId = 0;
            SqlParameter[] spParam = new SqlParameter[1];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@itName";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = txtItem.Text.Trim();

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_item_validation",
                                            spParam,ref connHandle);
            if (Dr.HasRows == false)
            {
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle);
                throw new Exception("Item name not found in master");
            }
            else
            {
                while (Dr.Read())
                {
                    itId = numFunction.toInt32(Dr["It_code"]);
                    Rate = numFunction.toDecimal(Dr["rate"]);
                    nonStk = Convert.ToString(Dr["nonStk"]);
                    //txtrate.Enabled = bitFunction.toBoolean(Dr["RateChange"]);  
                }
            }


            Dr.Close();
            Dr.Dispose();
            DataAcess.Connclose(connHandle);

            txtrate.Text = Convert.ToString(Rate);

            bool isWithStock = false;
            if (DBPropsSession.Vchkprod.Trim().IndexOf("vuord") >=0 &&
                DBPropsSession.Vchkprod.Trim().IndexOf("vuinv") >=0 &&
                MainDataSet.Tables["lcode_vw"].Columns.Contains("with_stock") == true)
                isWithStock = bitFunction.toBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["with_stock"]);

            if ((bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["it_bchk"]) == true &&
                isWithStock == false) &&
                !(DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
                 strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true &&
                 strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true &&
                 strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(), new string[] { "EXCISE", "NON-EXCISE" }) == true))
            {
                try
                {
                    stock = stockCheck.StockChecking(txtItem.Text.ToString().Trim(),
                                            Convert.ToInt32(itId),
                                            "",
                                            DBPropsSession.AddMode,
                                            DBPropsSession.Entry_Tbl,
                                            MainDataSet.Tables["lcode_vw"],
                                            MainDataSet.Tables["company"],
                                            MainDataSet.Tables["main_vw"],
                                            DBPropsSession.Vchkprod,btnItAdd,
                                            hidInvStk,
                                            hidNegItBal,
                                            hidNonStk);
                    hidbalQty.Value = Convert.ToString(stock[0]);

                    vuGenerateNo genItemNo = new vuGenerateNo();
                    string itSerialVar = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "itSerial", true, 5));
                    grdStockStatus.DataSource = StockStatus(MainDataSet,
                                                    Convert.ToInt32(MainDataSet.Tables["company"].Rows[0]["deci"]),
                                                    "S",
                                                    Convert.ToInt32(itId),
                                                    txtItem.Text.ToString().Trim(),
                                                    itSerialVar,
                                                    stock);
                    grdStockStatus.DataBind();
                }
                catch (Exception Ex)
                {
                    throw Ex;
                }
            }
            else
            {
                if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                    (strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(), new string[] { "EXCISE", "NON-EXCISE" }) == true) &&
                    ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS", "IR" }) == true ||
                     strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS", "IR" }) == true) ||
                     ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                     bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["U_sinfo"]) == true)))
                {
                    DataTable CurLitem = null;
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS", "IR" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS", "IR" }) == true)
                    {
                        CurLitem = stockCheck.GenStock(Convert.ToInt32(itId),
                                MainDataSet.Tables["main_vw"],
                                MainDataSet.Tables["manufact"],
                                MainDataSet.Tables["lcode_vw"],
                                MainDataSet.Tables["litemall_vw"],
                                null,
                                DBPropsSession.VarETGoDown,
                                DBPropsSession.Tex_exe,
                                SessionProxy.Tex_ExAr);

                    }

                    if ((DBPropsSession.PcvType == "GT" ||
                        DBPropsSession.Behave == "GT") &&
                        bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == true)
                    {
                        CurLitem = stockCheck.GenSRStock(Convert.ToInt32(itId),
                                        MainDataSet.Tables["main_vw"],
                                        MainDataSet.Tables["manufact"],
                                        MainDataSet.Tables["lcode_vw"],
                                        MainDataSet.Tables["litemall_vw"],
                                        null,
                                        DBPropsSession.VarETGoDown,
                                        DBPropsSession.Tex_exe,
                                        SessionProxy.Tex_ExAr);
                    }

                    DataTable curStock = new DataTable();
                    DataColumn curColumn = new DataColumn();
                    string[] curColCaption = new string[CurLitem.Columns.Count];

                    int iFldno = 0;
                    GenCol(curColumn,"System.String","It_name",curStock);    // It_name
                    curColCaption[iFldno] = "It_Name";
                    GenCol(curColumn, "System.Int32", "It_code", curStock);    // It_name
                    iFldno = iFldno + 1;
                    curColCaption[iFldno] = "It_Code";
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS", "IR" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS", "IR" }) == true)
                    {
                        if (Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["it_fields"]).Trim().IndexOf("CHAPNO") >= 0)
                        {
                            GenCol(curColumn,"System.String","chapno",curStock);    // Chapter No.
                            iFldno = iFldno + 1;
                            curColCaption[iFldno] = "Chapter No.";
                        }
                        GenCol(curColumn,"System.Decimal","balqty",curStock);    // Balance Qty
                        iFldno = iFldno + 1;
                        curColCaption[iFldno] = "Balance Qty.";
                    }
                    else
                    {
                        if (Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["it_fields"]).Trim().IndexOf("CHAPNO") >= 0)
                        {
                            GenCol(curColumn,"System.String","chapno",curStock);    // Chapter No.
                            iFldno = iFldno + 1;
                            curColCaption[iFldno] = "Chapter No.";
                        }
                        GenCol(curColumn,"System.Decimal","qty",curStock);    // Balance Qty
                        iFldno = iFldno + 1;
                        curColCaption[iFldno] = "Balance Qty.";
                    }

                }
                else
                {
                    hidbalQty.Value = "0";
                }
            }


            //string SqlStr = "select top 1 it_code,it_name,RatePer,RateUnit,NonStk from it_mast where it_code = " + itId;
            //Dr = DataAcess.ExecuteDataReader(SqlStr);  
            //while (Dr.Read())
            //{
            //    txtrate.Text = Convert.ToString(numFunction.toDecimal(Dr["RatePer"]));
            //}
            
            //Dr.Close();
            //Dr.Dispose();

            //EBItemSelectionTrigger ItemSelectionTrigger = new EBItemSelectionTrigger(MainDataSet);
            //ItemSelectionTrigger.ItemSelectedIndexChanged();
  
            if (bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["it_bchk"]) == true &&
                !(DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
                 strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true &&
                 strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true &&
                 strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(), new string[] { "EXCISE", "NON-EXCISE" }) == true))
            {
                grdStockStatus.Columns[0].Visible = true;
                grdStockStatus.Columns[1].Visible = true;

                if ((DBNull.Value.Equals(MainDataSet.Tables["lcode_vw"].Rows[0]["logi_stk"]) ?
                    false : bitFunction.toBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["logi_stk"])) == true)
                    grdStockStatus.Columns[5].Visible = true;
                else
                    grdStockStatus.Columns[5].Visible = false;

                if (stock[2] > 0)
                    grdStockStatus.Columns[3].Visible = true;
                else
                    grdStockStatus.Columns[3].Visible = false;


                if (stock[3] > 0)
                    grdStockStatus.Columns[4].Visible = true;
                else
                    grdStockStatus.Columns[4].Visible = false;

                //divHtml.Visible = true;
                //divHtml.Style.Add("display", "");
            }            
            DataAcess.Connclose(connHandle); 
        }


        protected DataColumn GenCol(DataColumn ToShowcol,
                    string DataType,
                    string colName,
                    DataTable DbTable)
        {
            ToShowcol = new DataColumn();
            ToShowcol.DataType = Type.GetType(DataType);
            ToShowcol.ColumnName = colName;
            DbTable.Columns.Add(ToShowcol);
            return ToShowcol;
        }

        public void txtDueDays_TextChanged(TextBox txtDueDate,
                    TextBox txtdate,
                    TextBox txtDueDays,
                    DataTable main_vw)
        {
            txtDueDate.Text = DateFormat.TodateTime(txtdate.Text).AddDays(Convert.ToInt32(txtDueDays.Text)).ToString("dd/MM/yyyy");
            main_vw.Rows[0]["due_dt"] = DateFormat.TodateTime(txtDueDate.Text);
            main_vw.AcceptChanges(); 
        }
    }

    delegate void DropDelegate(object sender, DropEventArgs e);
    class DropEventArgs : System.EventArgs
    {
        public string astring;
        public DropEventArgs(string a)
        {
            astring = a;
        }
    }


    class DropDelegatesAndEvents
    {
        private DropDelegate youDoIt;
        private string param;

        public DropDelegatesAndEvents(DropDelegate d, string p)
        {
            youDoIt = d;
            param = p;
        }

        public void SelectedIndexChanged(object sender, EventArgs e)
        {
            youDoIt(sender, new DropEventArgs(param));
        }



    }
}
