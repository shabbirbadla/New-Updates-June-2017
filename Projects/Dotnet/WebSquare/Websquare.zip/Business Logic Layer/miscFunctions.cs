using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI; 
    
namespace Business.Logic.Layer
{
    public class miscFunctions : IDisposable
    {
        public miscFunctions()
        {
        }

        public void EnableDisableControlsRecursive(Control root, bool isflag)
        {
            if (root is TextBox)
            {
                ((TextBox)root).Enabled = isflag;
            }

            if (root is DropDownList)
            {
                ((DropDownList)root).Enabled = isflag;
            }

            if (root is ImageButton)
            {
                ((ImageButton)root).Enabled = isflag;
            }

            if (root is LinkButton)
            {
                ((LinkButton)root).Enabled = isflag;
            }

            if (root is Button)
            {
                ((Button)root).Enabled = isflag;
            }

            if (root is GridView)
            {
                ((GridView)root).Enabled = isflag; 
            }

            foreach (Control child in root.Controls)
            {
                EnableDisableControlsRecursive(child, isflag);
            }
        }

        public void ClearControlsRecursive(Control root, bool isflag) // By  Deepa
        {
            if (root is TextBox)
            {
                ((TextBox)root).Text = "";
            }

            if (root is DropDownList)
            {
                ((DropDownList)root).SelectedIndex = 0;
            }
            if (root is CheckBox)
            {
                ((CheckBox)root).Checked = false;
            }

            foreach (Control child in root.Controls)
            {
                ClearControlsRecursive(child,isflag);
            }
        }

        public void Dispose()
        {
        }

    }
}
