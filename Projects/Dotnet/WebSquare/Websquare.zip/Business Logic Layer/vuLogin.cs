using System;
using System.Collections.Generic;
using System.Text;
using Data.Acess.Layer;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;

namespace Business.Logic.Layer
{
    public class vuLogin
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private SqlConnection connHandle;
        public vuLogin()
        {
        }

        
        public void txtReqCode_TextChanged(TextBox txtReqCode,
                DropDownList dropFinYear)
        {
            if (txtReqCode.Text != "")
            {
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = "Vudyog";

                SqlParameter[] spParam = new SqlParameter[1];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@reqcode";
                spParam[0].SqlDbType = SqlDbType.VarChar;
                spParam[0].Value = txtReqCode.Text.Trim();

                SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_login_getFinyear",
                                                spParam, ref connHandle);

                if (Dr.HasRows == true)
                {
                    dropFinYear.Items.Clear();  
                    while (Dr.Read())
                    {
                        dropFinYear.Items.Add(Convert.ToString(Dr["Year"]));
                    }
                }
                else
                {
                    Dr.Close();
                    Dr.Dispose();
                    DataAcess.Connclose(connHandle);
                    throw new Exception("Invalid Request Code...!!!");
                }
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle);
            }

        }

        public void btnSign_Click(TextBox txtReqCode,
                    TextBox txtPass,
                    TextBox txtUserId,
                    DropDownList dropFinYear,
                    System.Web.UI.Page thisPage)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = "Vudyog"; 
            SqlDataReader Dr;
            bool validCompany = false;

            string companyName = "";
            string userCompany = "";
            string dbName = "";
            string Product = "";
            string folderName = "";

            SqlParameter[] spParam = new SqlParameter[4];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@reqcode";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = txtReqCode.Text.Trim();

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@finyear";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = dropFinYear.SelectedValue.Trim();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@user";
            spParam[2].SqlDbType = SqlDbType.VarChar;
            spParam[2].Value = txtUserId.Text.Trim();

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@pass";
            spParam[3].SqlDbType = SqlDbType.VarChar;
            spParam[3].Value = txtPass.Text.Trim(); 

            DataSet DTLogin = new DataSet();
            ArrayList dbList = new ArrayList();
            dbList.Add("company");
            dbList.Add("user");  
            DTLogin = DataAcess.ExecuteDataset(DTLogin,
                                "sp_ent_web_login",
                                spParam,
                                dbList,connHandle);
            DataAcess.Connclose(connHandle);

            foreach (DataRow compRow in DTLogin.Tables["company"].Rows)
            {
                companyName = Convert.ToString(compRow["co_name"]);
                dbName = Convert.ToString(compRow["dbname"]);
                folderName = Convert.ToString(compRow["foldername"]);
                Product = Convert.ToString(compRow["PsrPrd"]).Trim();
            }

            if (folderName == string.Empty)
                throw new Exception("Directory name cannot be empty...");

            userCompany = dropFinYear.SelectedValue.ToString().Trim() + ":" + companyName.ToString().Trim() + ";";
            if (DTLogin.Tables["user"].Rows.Count != 0)
            {
                foreach (DataRow userRow in DTLogin.Tables["user"].Rows)
                {
                    if (userCompany.Trim() == Convert.ToString(userRow["company"]).Trim())
                    {
                        SessionProxy.UserID = txtUserId.Text.Trim();
                        SessionProxy.ReqCode = txtReqCode.Text.Trim();
                        SessionProxy.FinYear = dropFinYear.SelectedValue.ToString().Trim();
                        SessionProxy.DbName = dbName.Trim();
                        SessionProxy.CoName = companyName.Trim();
                        SessionProxy.VChkProd = Product;
                        //SessionProxy.FolderName = folderName;  
                        validCompany = true;
                        break;
                    }
                }

                DataAcess.DataBaseName = SessionProxy.DbName;  
                SessionProxy.Company = DTLogin.Tables["company"];
 
                DataAcess.Connclose(connHandle);
                DTLogin.Dispose();

                if (validCompany == false)
                {
                    throw new Exception("User has no rights for this company...!!!");
                }
            }
            else
            {
                DataAcess.Connclose(connHandle);
                DTLogin.Dispose(); 
                throw new Exception("Invalid UserId OR Invalid Password OR Invalid RequestCode");
            }
        }
    }
}
