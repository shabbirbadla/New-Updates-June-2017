using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data; 
using System.Web.UI.WebControls;

namespace Business.Logic.Layer
{
    public class getGridColumn
    {
        public getGridColumn()
        {
        }

        public BoundField grdBoundField(BoundField bndField,string dataField,string headerText)
        {
            bndField.DataField = dataField.ToString().Trim();
            //bndField.HeaderText = headerText.ToString().Trim();
            bndField.HeaderText = headerText.ToString();
            bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
            bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right; 
            return bndField;    
        }

        //public TemplateField grdTemplateField(TemplateField templateField, ListItemType lstType, string dataField, string headerText,string dataType, string objControls)
        //{
        //    PlaceHolder placeholder = new PlaceHolder();
        //    switch (lstType)
        //    {
        //        case ListItemType.EditItem :
        //            switch (objControls.ToString().ToUpper().Trim())
        //            {
        //                case "TEXTBOX":
        //                    TextBox textBox = new TextBox();
        //                    textBox.ID = "txt" + dataField.ToString().Trim();
        //                    textBox.Visible = true;
        //                    //placeholder                
        //                case "DROPDOWNLIST":
        //                case "LABEL":
        //            }
        //        case ListItemType.Item : 
        //    }
        //}
    }
}
