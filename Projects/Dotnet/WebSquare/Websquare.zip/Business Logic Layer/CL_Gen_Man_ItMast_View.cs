using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient; 
using Data.Acess.Layer;   

namespace Business.Logic.Layer
{
    public class CL_Gen_Man_ItMast_View: CL_Gen_Ent_ItMast_View, ICommonBLL 
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;
        
        #region ICommonBLL Events Members
        public void Select()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Insert()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Update()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Delete()
        {
            DataTier m_Obj_Dal = new DataTier();
            SqlCommand m_Obj_Cmd = new SqlCommand();
            try
            {
                m_Obj_Cmd = m_Obj_Dal.ExecuteNonQuery(m_Obj_Cmd, "sp_ent_web_Itmast_Delete", "SP", true,ref connHandle);
                m_Obj_Cmd.Parameters.AddWithValue("@It_code", It_Code);
                m_Obj_Cmd.ExecuteNonQuery();
                m_Obj_Dal.CommitTransaction(m_Obj_Cmd.Transaction);
            }
            catch (SqlException Ex)
            {
                throw m_Obj_Dal.SqlExceptionErrorsTraping(Ex);
            }
            catch (Exception Ex)
            {
                m_Obj_Dal.RollBackTransaction(m_Obj_Cmd.Transaction);
                throw Ex;
            }
            finally
            {
                m_Obj_Cmd.Dispose();
                m_Obj_Dal.Connclose(connHandle);  
                m_Obj_Dal = null;
            }
        }
        #endregion
    }
}

