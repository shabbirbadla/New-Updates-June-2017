using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;  
using Data.Acess.Layer;  

namespace Business.Logic.Layer
{
    public class GetLocationDetails
    {
        private string sqlStr = "";
        public GetLocationDetails()
        {
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        public DataTable ListLocationDetails(string locfld,
                        string locretfld,
                        int locid,
                        string loccap,
                        string loccond,
                        bool isDefaGroup,
                        DataTable retTable)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            
            string loccondition = locid == 0 ? " and b.ac_name = '" + loccap.Trim() + "'" :
                            " and a.ac_id = " + locid +
                            (loccond.Trim() != "" ? " and " + loccond.Trim() : "");

            if (locfld.Trim() != "" && isDefaGroup == false)
            {
                sqlStr = " select top 1 a.shipto_id from shipto a, ac_mast b " +
                         " where a.ac_id = b.ac_id and shipto_id = " + locfld +
                         loccondition;

                retTable = DataAcess.ExecuteDataTable(sqlStr, "_re",connHandle);    
            }

            if (retTable.Rows.Count == 0 || isDefaGroup == true)
            {
                sqlStr = " select " + locretfld + ", a.shipto_id from shipto a, " +
                         " ac_mast b where a.ac_id = b.ac_id " + loccondition;

                retTable = DataAcess.ExecuteDataTable(sqlStr, "_re",connHandle);    
            }

            DataAcess.Connclose(connHandle);
  
            return retTable; 
        }
    }
}
