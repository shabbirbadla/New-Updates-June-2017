using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Data.Acess.Layer;  

namespace Business.Logic.Layer
{
    public class GenerateRGPage
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        public GenerateRGPage()
        {
        }

        

        public string GenRGPageNo(DataTable itemvw,
            DataRow itemRow,
            SqlCommand cmd,
            ref SqlConnection connHandle)
        {
            DataTable CoAdditional  = new DataTable();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            stringFunction strFunction = new stringFunction();

            SqlDataReader dr;
            getCoAdditional CompAddOn = new getCoAdditional();
            if (cmd == null)
                CoAdditional = CompAddOn.CoAdditional(CoAdditional);
            else
                CoAdditional = CompAddOn.CoAdditional(CoAdditional,cmd);

            string vGoDown = Convert.ToString(itemRow["ware_nm"]).Trim();
            string sqlstr = "";
            int vrgPage = 0;
            string retRGPage = "";

            if (bitFunction.toBoolean(CoAdditional.Rows[0]["invwise"]) == false &&
                bitFunction.toBoolean(CoAdditional.Rows[0]["rgbillg"]) == false)
            {
                foreach (DataRow itemvwRow in itemvw.Rows)
                {
                    if (Convert.ToString(itemvwRow["ware_nm"]).Trim() == vGoDown.Trim())
                    {
                        if (numFunction.toInt32(itemvwRow["rgpage"]) > vrgPage)
                        {
                            vrgPage = numFunction.toInt32(itemvwRow["rgpage"]);
                        }
                    }
                }

                if (vrgPage != 0)
                {
                    retRGPage = Convert.ToString(vrgPage+1).Trim();
                }
                else
                {
                    sqlstr = "SELECT ISNULL(MAX(CONVERT(INT,NPGNO)),' ') AS NPGNO FROM " +
                             " GEN_SRNO WHERE CTYPE = 'RGPAGE' AND CWARE = '" + vGoDown.Trim() + "'" +
                             " And IsNumeric(NPGNO) > 0";
                    if (cmd == null)
                        dr = DataAcess.ExecuteDataReader(sqlstr,ref connHandle );
                    else
                        dr = DataAcess.ExecuteDataReader(sqlstr, cmd,ref connHandle);

                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            vrgPage = numFunction.toInt32(dr["npgno"]) + 1;
                        }
                        retRGPage = Convert.ToString(vrgPage).Trim();
                    }
                    dr.Close();
                    dr.Dispose();
                }
            }
            else
            {
                if (bitFunction.toBoolean(CoAdditional.Rows[0]["invwise"]) == true)
                {
                    foreach (DataRow itemvwRow in itemvw.Rows)
                    {
                        if (Convert.ToString(itemvwRow["ware_nm"]).Trim() == vGoDown.Trim())
                        {
                            if (numFunction.toInt32(itemvwRow["rgpage"]) !=0)
                            {
                                retRGPage = Convert.ToString(itemvwRow["rgpage"]);
                            }
                        }
                    }
                    int cnt = 0;
                    if (vrgPage != 0)
                    {
                        string leftStr = Convert.ToString(numFunction.toInt32(strFunction.Left(retRGPage, ((retRGPage.IndexOf('/')) < 0 ? 0 : (retRGPage.IndexOf('/')))))).Trim();
                        string rightStr = Convert.ToString(System.Math.Max(cnt, numFunction.toInt32(retRGPage.Substring(retRGPage.IndexOf('/') + 1))) + 1).Trim();
                        retRGPage = leftStr + "/" + rightStr;
                        retRGPage = retRGPage.PadRight(10, ' ');
                    }
                    else
                    {
                        sqlstr = "SELECT ISNULL(MAX(CONVERT(INT,SUBSTRING(NPGNO,1,CHARINDEX('/',NPGNO,1)-1))),0) AS NPGNO " +
                                 " FROM GEN_SRNO WHERE CTYPE = 'RGPAGE' AND CWARE ='" + vGoDown.Trim() + "' And " +
                                 " CHARINDEX('/',NPGNO) > 1 ";
                        if (cmd == null)
                            dr = DataAcess.ExecuteDataReader(sqlstr, ref connHandle);
                        else
                            dr = DataAcess.ExecuteDataReader(sqlstr, cmd, ref connHandle);

                        if (dr.HasRows == true)
                        {
                            vrgPage = numFunction.toInt32(dr["npgno"]) + 1;
                            retRGPage = Convert.ToString(vrgPage).Trim()+"/1";
                            retRGPage = retRGPage.Trim().PadRight(10,' ');  
                        }
                        dr.Close();
                        dr.Dispose();
                    }
                }
                else
                {
                    if (bitFunction.toBoolean(CoAdditional.Rows[0]["rgbillg"]) == true)
                    {
                        foreach (DataRow itemvwRow in itemvw.Rows)
                        {
                            if (numFunction.toInt32(itemvwRow["rgpage"]) > vrgPage)
                            {
                                vrgPage = numFunction.toInt32(itemvwRow["rgpage"]);  
                            }
                        }

                        if (vrgPage != 0)
                        {
                            retRGPage = Convert.ToString(vrgPage + 1).Trim();
                        }
                        else
                        {
                            sqlstr = "SELECT ISNULL(MAX(CONVERT(INT,NPGNO)),' ') AS NPGNO FROM GEN_SRNO " +
                                     " WHERE CTYPE = 'RGPAGE' AND IsNumeric(NPGNO) > 0";

                            if (cmd == null)
                                dr = DataAcess.ExecuteDataReader(sqlstr,ref connHandle);
                            else
                                dr = DataAcess.ExecuteDataReader(sqlstr, cmd, ref connHandle);

                            if (dr.HasRows == true)
                            {
                                vrgPage = numFunction.toInt32(dr["npgno"]) + 1;
                                retRGPage = Convert.ToString(vrgPage).Trim();
                            }
                            dr.Close();
                            dr.Dispose();
                        }

                    }

                }
            }

            return retRGPage; 
        }

        public void RgPageValidation(string what,
            DataRow itemRow,
            DataRow mainRow,
            DataRow CoAdditionalRow,
            DataRow companyRow,
            bool AddMode,
            bool EditMode,
            SqlCommand cmd,
            ref SqlConnection connHandle)    
            
        {
            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();
            boolFunction bitFunction = new boolFunction();
            getDateFormat DateFormat = new getDateFormat();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            string sqlstr = "";

            if (what.Trim().ToUpper() == "CHECK")
            {
                string _mrgpage = "";
                
                if (Convert.ToString(itemRow["rgpage"]).Trim() != "")
                {
                    if (bitFunction.toBoolean(CoAdditionalRow["invwise"]) == false &&
                        bitFunction.toBoolean(CoAdditionalRow["rgbillg"]) == false)
                    {
                        _mrgpage = Convert.ToString(itemRow["rgpage"]);
                        sqlstr = " select top 1 entry_ty,tran_cd,itserial,ctype,npgno,cware,compid " +
                                 " from gen_srno where ctype ='RGPAGE' and cware ='" + Convert.ToString(itemRow["ware_nm"]).Trim() + "' and " +
                                 " npgno ='" + _mrgpage.Trim() + "'";
                    }
                    else
                    {
                        if (bitFunction.toBoolean(CoAdditionalRow["invwise"]) == true)
                        {
                            _mrgpage = Convert.ToString(itemRow["rgpage"]);
                            _mrgpage = _mrgpage.Trim().Substring(1,(_mrgpage.Trim().IndexOf('/') >=0 ? _mrgpage.Trim().IndexOf('/'): 0));
                            sqlstr = " select top 1 entry_ty,tran_cd,itserial,ctype,npgno,cware,compid from " +
                                     " gen_srno where ctype ='RGPAGE' and cware ='" + Convert.ToString(itemRow["ware_nm"]).Trim() + "' and " +
                                     " npgno='" + _mrgpage.Trim() + "'";
                        }
                        else
                        {
                            _mrgpage = Convert.ToString(itemRow["rgpage"]);
                            sqlstr = "select top 1 entry_ty,tran_cd,itserial,ctype,npgno,compid from gen_srno "+
                                     "where ctype='RGPAGE' and npgno='" + _mrgpage.Trim() + "'";
                        }
                    }

                    DataTable tmptbl = DataAcess.ExecuteDataTable(sqlstr, cmd.Transaction, ref connHandle);
                    if (tmptbl.Rows.Count > 0)
                    {
                        if (AddMode == true)
                        {
                            // pending
                            _mrgpage = Convert.ToString(itemRow["rgpage"]).Trim();
                            throw new Exception("RG Page " + _mrgpage.Trim() + " already exist..");
                        }
                        
                        if (EditMode == true)
                        {
                            if (Convert.ToString(tmptbl.Rows[0]["entry_ty"]).Trim() == Convert.ToString(itemRow["entry_ty"]).Trim() &&
                                numFunction.toInt32(tmptbl.Rows[0]["tran_cd"]) == numFunction.toInt32(itemRow["tran_cd"]) &&
                                Convert.ToString(tmptbl.Rows[0]["itserial"]).Trim() == Convert.ToString(itemRow["itserial"]).Trim())
                            {
                            }
                            else
                            {
                                _mrgpage = Convert.ToString(itemRow["rgpage"]).Trim();
                                throw new Exception("RG Page " + _mrgpage.Trim() + " already exist..");
                            }
                        }
                    }
                } // end if rgpage not empty

            } // end check 
            else
            {
                if (what == "INSERT")
                {
                    if (Convert.ToString(itemRow["rgpage"]).Trim() != "")
                    {
                        string _mrgpage = Convert.ToString(itemRow["rgpage"]).Trim();
                        sqlstr = "select top 1 entry_ty,tran_cd,date,ctype,npgno,cit_code,cware,itserial,compid " +
                                 "from gen_srno where 1=2";
                        DataTable tmptbl = DataAcess.ExecuteDataTable(sqlstr, cmd.Transaction, ref connHandle);
                        DataRow tmpRow = tmptbl.NewRow();
                        tmpRow["entry_ty"] = Convert.ToString(itemRow["entry_ty"]);
                        tmpRow["tran_cd"] = numFunction.toInt32(mainRow["tran_cd"]);
                        tmpRow["date"] =  DateFormat.TodateTime(mainRow["date"]);
                        tmpRow["ctype"] = "RGPAGE";
                        tmpRow["npgno"] = _mrgpage;
                        tmpRow["cit_code"] = numFunction.toInt32(itemRow["it_code"]);
                        tmpRow["cware"] = Convert.ToString(itemRow["ware_nm"]).Trim();
                        tmpRow["itserial"] = Convert.ToString(itemRow["itserial"]).Trim();
                        tmpRow["compid"] = numFunction.toInt32(companyRow["compid"]);
                        tmptbl.Rows.Add(tmpRow);

                        sqlstr = DataAcess.GenInsertString(tmptbl,"gen_srno",null,null);

                        try
                        {
                            cmd = DataAcess.ExecuteNonQuery(cmd, sqlstr, "TX", true, ref connHandle);
                            cmd.ExecuteNonQuery(); 
                        }
                        catch (Exception ex)
                        {
                            DataAcess.RollBackTransaction(cmd.Transaction);
                            DataAcess.Connclose(connHandle);
                            throw ex;
                        }

                    }
                } // end Insert
            }
        }

        /// Generate RG Page String for Insert Record


    }
}
