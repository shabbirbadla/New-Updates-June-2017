using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    interface ICommonBLL
    {
        void Select();
        void Insert();
        void Update();
        void Delete();
    }
}
