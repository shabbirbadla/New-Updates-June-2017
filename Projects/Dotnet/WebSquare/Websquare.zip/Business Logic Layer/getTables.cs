using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Data.Acess.Layer;  

namespace Business.Logic.Layer
{
    public class getTables
    {
        public getTables()
        {
        }

        private string errorMessage;
        private SqlConnection connHandle;
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        public string ErrorMessage
        {
            get 
            { 
                return errorMessage; 
            }
            set 
            { 
                errorMessage = value; 
            }
        }

        private string behave;

        public string Behave
        {
            get { return behave; }
            set { behave = value; }
        }

        private string entry_tbl;

        public string Entry_tbl
        {
            get { return entry_tbl; }
            set { entry_tbl = value; }
        }

        private string maintbl;

        public string Maintbl
        {
            get { return maintbl; }
            set { maintbl = value; }
        }

        private string howtoCalculateExAmt;

        public string HowtoCalculateExAmt
        {
            get { return howtoCalculateExAmt; }
            set { howtoCalculateExAmt = value; }
        }

        public DataSet openTables(DataSet opDS, string pcvType,string vChkProd)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
 
            stringFunction strFunction = new stringFunction();

            // Create dataTable Lcode
            opDS = _datatier.ExecuteDataset(opDS, "select * from lcode where cd = '" + pcvType.ToString().Trim() + "'", "lcode_vw",connHandle); 
            if (opDS.Tables["lcode_vw"].Rows.Count == 0)
            {
                throw new Exception("Invalid Voucher Type");
            }
            else
            {
                if (opDS.Tables["lcode_vw"].Rows[0]["bcode_nm"].ToString().Trim() == "")
                {
                    Behave = opDS.Tables["lcode_vw"].Rows[0]["cd"].ToString().Trim();
                }
                else
                {
                    Behave = opDS.Tables["lcode_vw"].Rows[0]["bcode_nm"].ToString().Trim();
                }
            }
            
            // End

            // Create Lother DataTable
            opDS = _datatier.ExecuteDataset(opDS,"select * from lother where e_code = '" + pcvType.ToString().Trim() + "'", "lother_vw",connHandle); 


            // Create Dcmast DataTable
            opDS = _datatier.ExecuteDataset(opDS, "select *,space(15) as form_nm,space(15) as form_no from dcmast where entry_ty = '" + pcvType.ToString().Trim() + "'", "dcmast_vw",connHandle);
            _datatier.Connclose(connHandle);
            try
            {
                DataRow dcMast_Row = opDS.Tables["dcmast_vw"].Select("code = 'E'")[0];
                if (Convert.ToBoolean(dcMast_Row["att_file"]) == true)
                {
                    HowtoCalculateExAmt = "V";
                }
                else
                {
                    HowtoCalculateExAmt = "I";
                }
            }
            catch
            {
                HowtoCalculateExAmt = "N";
            }
            // End

            // Create Sale Tax DataTable
            opDS = _datatier.ExecuteDataset(opDS,"select * from stax_mas", "stax_vw",connHandle);
            // End


            // Create Main DataTable
            DataSet DS = new DataSet();
            DS = _datatier.ExecuteDataset("select name from sysobjects where xtype = 'U' and name like '%Main%'", "_sysObjects",connHandle);
            _datatier.Connclose(connHandle);  

            if (DS.Tables["_sysObjects"].Rows.Count > 0)
            {
                bool found=true;
                foreach (DataRow RW in DS.Tables["_sysObjects"].Rows)
                {
                    if (System.Convert.ToString(RW["name"]).ToUpper().Trim() == pcvType.Trim().ToUpper() + "MAIN")
                    {
                        Entry_tbl = pcvType.ToString().Trim();
                        break;
                    }
                    else
                    {
                        found = false;
                    }
                }

                if (found == false)
                {
                    foreach (DataRow RW in DS.Tables["_sysObjects"].Rows)
                    {
                        if (System.Convert.ToString(RW["name"]).ToUpper().Trim() == Behave.ToString().Trim().ToUpper()  + "MAIN")  
                        {
                            Entry_tbl = Behave.ToString().Trim();
                            break;
                        }
                    }
                }
            }
            DS.Clear();
            DS.Dispose();
            Maintbl = Entry_tbl.ToString().Trim();  

            opDS = _datatier.ExecuteDataset(opDS,"select * from " + Entry_tbl.ToString().Trim() + "Main where 1=0", "Main_vw",connHandle);
            
            // End

            // Create Item Table
            opDS = _datatier.ExecuteDataset(opDS,"select * from " + Entry_tbl.ToString().Trim() + "Item where 1=0", "item_vw",connHandle);
            //End

            // Create Account Table
            opDS = _datatier.ExecuteDataset(opDS,"select * from " + Entry_tbl.ToString().Trim() + "acdet where 1=0", "acdet_vw",connHandle);
            //End

            if (vChkProd.Trim().IndexOf("vutex") >= 0)
            {
                SqlDataReader dr;
                dr = _datatier.ExecuteDataReader("select entry_ty from litemall where 1=0",ref connHandle);
                if (dr.HasRows == true)
                {
                    dr.Close(); 
                    dr.Dispose();
                    _datatier.Connclose(connHandle); 
                    throw new Exception("Litemall table not found in Database");
                }
                dr.Close();
                dr.Dispose();
                _datatier.Connclose(connHandle);

                dr = _datatier.ExecuteDataReader("select entry_ty from manu_det where 1=0",ref connHandle);
                if (dr.HasRows == true)
                {
                    dr.Close();
                    dr.Dispose();
                    _datatier.Connclose(connHandle);
                    throw new Exception("Manufacture Detail table not found in Database");
                }
                dr.Close();
                dr.Dispose();
                _datatier.Connclose(connHandle);

                // Create manufacture table
                if (strFunction.InList(pcvType, new string[] { "AR", "IR", "GT" }) == true ||
                strFunction.InList(Behave, new string[] { "AR", "IR", "GT" }) == true)
                {
                    opDS = _datatier.ExecuteDataset(opDS, "select * from manu_det where 1=0", "manu_det_vw",connHandle);
                    _datatier.Connclose(connHandle);
                }

                // Create manufacture table
                if (strFunction.InList(pcvType, new string[] { "DC", "IR", "SS", "GT" }) == true ||
                strFunction.InList(Behave, new string[] { "DC", "IR", "SS", "GT" }) == true)
                {
                    opDS = _datatier.ExecuteDataset(opDS, "select * from litemall where 1=0", "litemall_vw",connHandle);
                    _datatier.Connclose(connHandle);
                }

            }
            return opDS;
        }

        public bool checkldcw(string tblName, string fldName, string pcvType)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            SqlDataReader Dr;
            string sqlStr = "select top 1 " + fldName.ToString().Trim() + " from " + tblName.ToString().Trim() + 
                            " where validity like '%" + pcvType.ToString().Trim() + 
                            "%' and ltrim(" + fldName.ToString().Trim() + ") != ''";

            Dr = _datatier.ExecuteDataReader(sqlStr,ref connHandle);
            if (Dr.HasRows == true)
            {
                Dr.Close();
                Dr.Dispose();
                _datatier.Connclose(connHandle);
                return true;
            }
            else
            {
                Dr.Close();
                Dr.Dispose();
                _datatier.Connclose(connHandle);
                return false;
            }
        }

        public void getObjects(string SqlStr, string TableName)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            _datatier.ExecuteDataReader(SqlStr, ref connHandle);
        }

        public void AppendBlankRec(DataTable Rs)
        {
            DataRow Row;
            Row = Rs.NewRow(); 
            Row["tran_cd"] = 0;
            Rs.Rows.Add(Row);
            Rs.AcceptChanges(); 

            //mainDataSet.Tables[TblName].Rows.Add(Row);
            //mainDataSet.Tables[TblName].AcceptChanges();
           
        }
    }
}
