using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;   


namespace Business.Logic.Layer
{
    public class UdyogSessionProxy : SessionProxyChildProxyBase
    {
        #region Constructors
        public UdyogSessionProxy()
        {
        }
        #endregion
        //internal UdyogSessionProxy() 
        //{ 
        //}  

        private const string PAGEPROPS = "PageCustomProperties";
        private const string MAINDATASET = "MainDataSet";
        private const string GRIDITEMCOLVIEW = "GridItemColView";
        private const string TMPMALLDTSESS = "tmpMallDtSess";
        private const string MALLDTSESS = "mallDtSess";
        private const string MAINDTSESS = "mainDtSess";
        private const string ACDETROWCESS = "AcDetRowSess";
        private const string ALLOCDATAROW = "AllocDataRow";
        private const string RSTATUSVIEW = "RstatusView";
        private const string MAINQUERYSTRING = "MainQueryString";
        private const string SUBQUERYSTRING = "SubQueryString";
        private const string ISSUBREPORT = "IsSubReport";
        private const string REPORTDATASET = "ReportDataSet";
        private const string REQCODE = "ReqCode";
        private const string FINYEAR = "FinYear";
        private const string VCHKPROD = "VChkProd";
        private const string RETITEMROW = "RetItemRow";
        private const string DSETHEADERDETAIL = "DsETHeaderDetail";
        private const string DSETITEMDETAIL = "DsETItemDetail";
        private const string ETMANUROW = "EtManuRow";
        private const string ETITEMROW = "EtItemRow";
        private const string ETARITEMDATASET = "EtARItemDataSet";
        private const string DUTYPERUNITDEC = "DutyPerUnitDec";
        private const string TOSHOW = "ToShow";
        private const string VIEWINITQUERY = "ViewInitQuery";
        private const string COMPANY = "Company";
        private const string LIKEINITQUERY = "LikeInitQuery";
        private const string VIEWTRANVIEW = "ViewTranView";
        private const string LCODEVIEW = "LcodeView";
        private const string TRANITDETVIEW = "TranItDetView";
        private const string TRANACDETVIEW = "TranAcDetView";
        private const string REPORTPATH = "ReportPath";
        private const string USERID = "UserID";
        private const string DBNAME = "DbName";
        private const string CONAME = "CoName";
        private const string REPMAINDATASET = "RepMainDataSet";
        private const string ACMASTDATASET = "AcmastDataSet";
        private const string ITMASTDATASET = "ItmastDataSet";
        private const string CURPURCHASEDET = "CurPurchaseDet";
        private const string DISCCHRGVIEW = "DiscChrgView";
        private const string DISCCHRGDATASET = "DiscChrgDataSet";
        private const string ADDINFOVIEW = "AddinfoView";
        private const string PRLISTCODE = "PrListCode";
        private const string FOLDERNAME = "FolderName";
        private const string DBPROPERTIES = "DBProperties";
        private const string TEX_EXAR = "Tex_ExAr";

        public string[,] Tex_ExAr
        {
            get
            {
                if (Session[TEX_EXAR] == null)
                {
                    return null;
                }
                else
                {
                    return (string[,])Session[TEX_EXAR];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(TEX_EXAR);
                }
                else
                    Session[TEX_EXAR] = value;
            }
        }

        public DataTable DbProperties
        {
            get
            {
                if (Session[DBPROPERTIES] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[DBPROPERTIES];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(DBPROPERTIES);
                }
                else
                    Session[DBPROPERTIES] = value;
            }
        }

        // String variable for PriceList
        public string FolderName
        {
            get
            {
                if (Session[FOLDERNAME] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[FOLDERNAME];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(FOLDERNAME);
                }
                else
                    Session[FOLDERNAME] = value;
            }
        }

        // String variable for PriceList
        public string PrlistCode
        {
            get
            {
                if (Session[PRLISTCODE] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[PRLISTCODE];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(PRLISTCODE);
                }
                else
                    Session[PRLISTCODE] = value;
            }
        }

        // DataTable For Additional Info Master for View Page
        public DataTable AddinfoView
        {
            get
            {
                if (Session[ADDINFOVIEW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[ADDINFOVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ADDINFOVIEW);
                }
                else
                    Session[ADDINFOVIEW] = value;
            }
        }

        // DataTable For Discount & Charges Master 
        public DataSet DiscChrgDataSet
        {
            get
            {
                if (Session[DISCCHRGDATASET] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[DISCCHRGDATASET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(DISCCHRGDATASET);
                }
                else
                    Session[DISCCHRGDATASET] = value;
            }
        }

        // DataTable For Discount & Charges Master for View Page
        public DataTable DiscChrgView
        {
            get
            {
                if (Session[DISCCHRGVIEW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[DISCCHRGVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(DISCCHRGVIEW);
                }
                else
                    Session[DISCCHRGVIEW] = value;
            }
        }
        
        // Sales Return Datatable For Excise Trading Sales Return Page
        public DataTable CurPurchaseDet
        {
            get
            {
                if (Session[CURPURCHASEDET] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[CURPURCHASEDET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(CURPURCHASEDET);
                }
                else
                    Session[CURPURCHASEDET] = value;
            }
        }

        // Dataset For Item Details
        public DataSet ItmastDataSet
        {
            get
            {
                if (Session[ITMASTDATASET] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[ITMASTDATASET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ITMASTDATASET);
                }
                else
                    Session[ITMASTDATASET] = value;
            }
        }


        // Dataset For Account Details
        public DataSet AcmastDataSet
        {
            get
            {
                if (Session[ACMASTDATASET] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[ACMASTDATASET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ACMASTDATASET);
                }
                else
                    Session[ACMASTDATASET] = value;
            }
        }

        // Dataset For Excise Trading Item Details
        public DataSet RepMainDataSet
        {
            get
            {
                if (Session[REPMAINDATASET] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[REPMAINDATASET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(REPMAINDATASET);
                }
                else
                    Session[REPMAINDATASET] = value;
            }
        }

        // String variable for Login
        public string CoName
        {
            get
            {
                if (Session[CONAME] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[CONAME];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(CONAME);
                }
                else
                    Session[CONAME] = value;
            }
        }

        // String variable for Login
        public string DbName
        {
            get
            {
                if (Session[DBNAME] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[DBNAME];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(DBNAME);
                }
                else
                    Session[DBNAME] = value;
            }
        }

        // String variable for Login
        public string UserID
        {
            get
            {
                if (Session[USERID] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[USERID];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(USERID);
                }
                else
                    Session[USERID] = value;
            }
        }

        // String variable for View Report
        public string ReportPath
        {
            get
            {
                if (Session[REPORTPATH] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[REPORTPATH];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(REPORTPATH);
                }
                else
                    Session[REPORTPATH] = value;
            }
        }

        // Account Detail Datatable For Transaction View Page
        public DataTable TranAcDetView
        {
            get
            {
                if (Session[TRANACDETVIEW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[TRANACDETVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(TRANACDETVIEW);
                }
                else
                    Session[TRANACDETVIEW] = value;
            }
        }


        // Item Detail Datatable For Transaction View Page
        public DataTable TranItDetView
        {
            get
            {
                if (Session[TRANITDETVIEW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[TRANITDETVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(TRANITDETVIEW);
                }
                else
                    Session[TRANITDETVIEW] = value;
            }
        }

        // Lcode Datatable For Transaction View Page
        public DataTable LcodeView
        {
            get
            {
                if (Session[LCODEVIEW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[LCODEVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(LCODEVIEW);
                }
                else
                    Session[LCODEVIEW] = value;
            }
        }


        // Datatable For Transaction View Page
        public DataTable ViewTranView
        {
            get
            {
                if (Session[VIEWTRANVIEW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[VIEWTRANVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(VIEWTRANVIEW);
                }
                else
                    Session[VIEWTRANVIEW] = value;
            }
        }

        // String variable for Transaction View Page
        public string LikeInitQuery
        {
            get
            {
                if (Session[LIKEINITQUERY] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[LIKEINITQUERY];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(LIKEINITQUERY);
                }
                else
                    Session[LIKEINITQUERY] = value;
            }
        }

        // Datatable For Company
        public DataTable Company
        {
            get
            {
                if (Session[COMPANY] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[COMPANY];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(COMPANY);
                }
                else
                    Session[COMPANY] = value;
            }
        }

        // String variable for Transaction View Page
        public string ViewInitQuery
        {
            get
            {
                if (Session[VIEWINITQUERY] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[VIEWINITQUERY];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(VIEWINITQUERY);
                }
                else
                    Session[VIEWINITQUERY] = value;
            }
        }

        // Datatable For Print Preview
        public DataTable ToShow
        {
            get
            {
                if (Session[TOSHOW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[TOSHOW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(TOSHOW);
                }
                else
                    Session[TOSHOW] = value;
            }
        }


        // Duty Per unit Int for Excise Trading AR Item Details 
        public Int32 DutyPerUnitDec
        {
            get
            {
                if (Session[DUTYPERUNITDEC] == null)
                {
                    return 0;
                }
                else
                {
                    return (Int32)Session[DUTYPERUNITDEC];
                }
            }
            set
            {
                if (value == 0)
                {
                    Session.Remove(DUTYPERUNITDEC);
                }
                else
                    Session[DUTYPERUNITDEC] = value;
            }
        }

        // Dataset For Excise Trading Item Details
        public DataSet EtARItemDataSet
        {
            get
            {
                if (Session[ETARITEMDATASET] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[ETARITEMDATASET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ETARITEMDATASET);
                }
                else
                    Session[ETARITEMDATASET] = value;
            }
        }

        // DataRow For Excise Trading AR Item Detail
        public DataRow EtItemRow
        {
            get
            {
                if (Session[ETITEMROW] == null)
                {
                    return null;
                }
                else
                {
                    return (DataRow)Session[ETITEMROW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ETITEMROW);
                }
                else
                    Session[ETITEMROW] = value;
            }
        }

        // DataRow For Excise Trading AR Item Detail
        public DataRow EtManuRow
        {
            get
            {
                if (Session[ETMANUROW] == null)
                {
                    return null;
                }
                else
                {
                    return (DataRow)Session[ETMANUROW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ETMANUROW);
                }
                else
                    Session[ETMANUROW] = value;
            }
        }

        // Dataset For Excise Trading Item Details
        public DataSet DsETItemDetail
        {
            get
            {
                if (Session[DSETITEMDETAIL] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[DSETITEMDETAIL];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(DSETITEMDETAIL);
                }
                else
                    Session[DSETITEMDETAIL] = value;
            }
        }

        // Dataset For Excise Trading Header Details
        public DataSet DsETHeaderDetail
        {
            get
            {
                if (Session[DSETHEADERDETAIL] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[DSETHEADERDETAIL];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(DSETHEADERDETAIL);
                }
                else
                    Session[DSETHEADERDETAIL] = value;
            }
        }

        // DataRow For Item Update
        public DataRow RetItemRow
        {
            get
            {
                if (Session[RETITEMROW] == null)
                {
                    return null;
                }
                else
                {
                    return (DataRow)Session[RETITEMROW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(RETITEMROW);
                }
                else
                    Session[RETITEMROW] = value;
            }
        }

        // Company Financial year
        public string VChkProd
        {
            get
            {
                if (Session[VCHKPROD] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[VCHKPROD];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(VCHKPROD);
                }
                else
                    Session[VCHKPROD] = value;
            }
        }

        // Company Financial year
        public string FinYear
        {
            get
            {
                if (Session[FINYEAR] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[FINYEAR];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(FINYEAR);
                }
                else
                    Session[FINYEAR] = value;
            }
        }

        // Company Request code 
        public string ReqCode
        {
            get
            {
                if (Session[REQCODE] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[REQCODE];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(REQCODE);
                }
                else
                    Session[REQCODE] = value;
            }
        }

        // Dataset 
        public DataSet ReportDataSet
        {
            get
            {
                if (Session[REPORTDATASET] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[REPORTDATASET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(REPORTDATASET);
                }
                else
                    Session[REPORTDATASET] = value;
            }
        }

        // Sub report bool flag for Report Viewer
        public bool IsSubReport
        {
            get
            {
                if (Session[ISSUBREPORT] == null)
                {
                    return false;
                }
                else
                {
                    return (bool)Session[ISSUBREPORT];
                }
            }
            set
            {
                if (value == false)
                {
                    Session.Remove(ISSUBREPORT);
                }
                else
                    Session[ISSUBREPORT] = value;
            }
        }

        // Sub Command String for Report viewer
        public string SubQueryString
        {
            get
            {
                if (Session[SUBQUERYSTRING] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[SUBQUERYSTRING];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(SUBQUERYSTRING);
                }
                else
                    Session[SUBQUERYSTRING] = value;
            }
        }

        // Main Command String for Report viewer
        public string MainQueryString
        {
            get
            {
                if (Session[MAINQUERYSTRING] == null)
                {
                    return string.Empty;
                }
                else
                {
                    return (string)Session[MAINQUERYSTRING];
                }
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Session.Remove(MAINQUERYSTRING);
                }
                else
                    Session[MAINQUERYSTRING] = value;
            }
        }

        

        // Datatable For Print Preview
        public DataTable RStatusView
        {
            get
            {
                if (Session[RSTATUSVIEW] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[RSTATUSVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(RSTATUSVIEW);
                }
                else
                    Session[RSTATUSVIEW] = value;
            }
        }

        // DataRow For Allocation
        public DataRow AllocDataRow
        {
            get
            {
                if (Session[ALLOCDATAROW] == null)
                {
                    return null;
                }
                else
                {
                    return (DataRow)Session[ALLOCDATAROW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ALLOCDATAROW);
                }
                else
                    Session[ALLOCDATAROW] = value;
            }
        }

        // DataRow For Allocation
        public DataRow AcdetRowCess
        {
            get
            {
                if (Session[ACDETROWCESS] == null)
                {
                    return null;
                }
                else
                {
                    return (DataRow)Session[ACDETROWCESS];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(ACDETROWCESS);
                }
                else
                    Session[ACDETROWCESS] = value;
            }
        }

        // Main View for Allocation
        public DataTable MainDtSess
        {
            get
            {
                if (Session[MAINDTSESS] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[MAINDTSESS];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(MAINDTSESS);
                }
                else
                    Session[MAINDTSESS] = value;
            }
        }

        // Mall View for Allocation
        public DataTable MallDtSess
        {
            get
            {
                if (Session[MALLDTSESS] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[MALLDTSESS];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(MALLDTSESS);
                }
                else
                    Session[MALLDTSESS] = value;
            }
        }


        // Temp DataTable for Allocation
        public DataTable TmpMallDtSess
        {
            get
            {
                if (Session[TMPMALLDTSESS] == null)
                {
                    return new DataTable();
                }
                else
                {
                    return (DataTable)Session[TMPMALLDTSESS];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(TMPMALLDTSESS);
                }
                else
                    Session[TMPMALLDTSESS] = value;
            }
        }

        // GridItem Column View
        public DataView GridItemColView
        {
            get
            {
                if (Session[GRIDITEMCOLVIEW] == null)
                {
                    return new DataView();
                }
                else
                {
                    return (DataView)Session[GRIDITEMCOLVIEW];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(GRIDITEMCOLVIEW);
                }
                else
                    Session[GRIDITEMCOLVIEW] = value;
            }
        }

        // Dataset 
        public DataSet MainDataSet
        {
            get
            {
                if (Session[MAINDATASET] == null)
                {
                    return new DataSet();
                }
                else
                {
                    return (DataSet)Session[MAINDATASET];
                }
            }
            set
            {
                if (value == null)
                {
                    Session.Remove(MAINDATASET);
                }
                else
                    Session[MAINDATASET] = value;
            }
        }

       

        #region Methods
        public void Clear()
        {
            Session.Clear();
        }

        public void Abandon()
        {
            Session.Abandon();
        }

        public void Remove(string sessionname)
        {
            Session.Remove(sessionname);
        }
        #endregion
    }
}
