using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data; 
using Data.Acess.Layer;
using System.Collections;  

namespace Business.Logic.Layer
{
    public class TransactionData
    {
        public TransactionData()
        {
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;
       
        public List<TransactionList> GetAllRows(int startIndex,
                    int pageSize,
                    string sortBy,
                    string trantype,
                    string searchtext,
                    ref int totalRec,
                    ref DataTable lcodevw,
                    ref DataTable colParam)
        {
            List<TransactionList> TranList;

            SqlParameter[] spParam = new SqlParameter[6];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@startIndex";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = startIndex;

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@pageSize";
            spParam[1].SqlDbType = SqlDbType.Int;
            spParam[1].Value = pageSize;

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@sortBy";
            spParam[2].SqlDbType = SqlDbType.NVarChar;
            spParam[2].Value = sortBy;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@trantype";
            spParam[3].SqlDbType = SqlDbType.NVarChar;
            spParam[3].Value = trantype;

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@searchtext";
            spParam[4].SqlDbType = SqlDbType.NVarChar;
            spParam[4].Value = searchtext;

            spParam[5] = new SqlParameter();
            spParam[5].ParameterName = "@totRecOUT";
            spParam[5].SqlDbType = SqlDbType.NVarChar;
            spParam[5].Value = 0;
            spParam[5].Direction = ParameterDirection.Output;
            
            DataSet DSList = new DataSet();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
  
            ArrayList dblist = new ArrayList();
            dblist.Add("TranView");
            dblist.Add("TotRec");
            dblist.Add("Lcodevw");
            dblist.Add("ColParam");
            DSList = DataAcess.ExecuteDataset(DSList,
                                "sp_ent_web_tranview_initquery",
                                spParam,
                                dblist,connHandle);
            DataAcess.Connclose(connHandle); 
            lcodevw = DSList.Tables["lcodevw"];

            if (lcodevw.Rows.Count == 0)
                throw new Exception("Invalid Transaction Type");

            colParam = DSList.Tables["colParam"];
            totalRec = Convert.ToInt32(DSList.Tables["TotRec"].Rows[0]["TotRecords"]);
            TranList = ConvertorTransactionList(DSList);
            return TranList;
        }

        private List<TransactionList> ConvertorTransactionList(DataSet TranListDS)
        {
            getDateFormat DateFormat = new getDateFormat();
            if (TranListDS == null || TranListDS.Tables.Count == 0)
                throw new ArgumentException("DataSet is null or empty.", "TranListDS");

            List<TransactionList> tranList = new List<TransactionList>();
            try
            {
                foreach (DataRow TranRow in TranListDS.Tables["TranView"].Rows)
                {
                    TransactionList TranviewList = new TransactionList();
                    TranviewList.Select = Convert.ToBoolean(TranRow["Select"]);
                    TranviewList.Entry_ty = Convert.ToString(TranRow["entry_ty"]);
                    TranviewList.Tran_cd = Convert.ToInt32(TranRow["tran_cd"]);
                    TranviewList.Inv_no = Convert.ToString(TranRow["inv_no"]);
                    TranviewList.Date = DateFormat.TodateTime(Convert.ToDateTime(TranRow["date"]));
                    TranviewList.Party_nm = Convert.ToString(TranRow["party_nm"]);
                    TranviewList.Net_amt = Convert.ToDecimal(TranRow["net_amt"]);
                    TranviewList.Dept = Convert.ToString(TranRow["dept"]);
                    TranviewList.Cate = Convert.ToString(TranRow["cate"]);
                    TranviewList.Inv_sr = Convert.ToString(TranRow["inv_sr"]);
                    TranviewList.Rule = Convert.ToString(TranRow["rule"]);
                    TranviewList.Bank_nm = Convert.ToString(TranRow["bank_nm"]);
                    TranviewList.U_pinvno = Convert.ToString(TranRow["u_pinvno"]);
                    TranviewList.U_pinvdt = DateFormat.TodateTime(TranRow["u_pinvdt"]);
                    tranList.Add(TranviewList);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Error occur while parsing dataset into Transaction List. Error Detail: {0} {1} ", Environment.NewLine, ex.Message));
            }
            return tranList;
        }


        public List<AcMast> GetAcMastRows(int startIndex,
              int pageSize,
              string sortBy,
              string searchtext,
              ref int totalRec)
        {
            List<AcMast> AcMastList;

            SqlParameter[] spParam = new SqlParameter[5];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@startIndex";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = startIndex;

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@pageSize";
            spParam[1].SqlDbType = SqlDbType.Int;
            spParam[1].Value = pageSize;

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@sortBy";
            spParam[2].SqlDbType = SqlDbType.NVarChar;
            spParam[2].Value = sortBy;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@searchtext";
            spParam[3].SqlDbType = SqlDbType.NVarChar;
            spParam[3].Value = searchtext;

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@totRecOUT";
            spParam[4].SqlDbType = SqlDbType.Int;
            spParam[4].Value = 0;
            spParam[4].Direction = ParameterDirection.Output;

            DataSet Ds = new DataSet();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
 
            ArrayList dblist = new ArrayList();
            dblist.Add("AcMast");
            Ds = DataAcess.ExecuteDataset(Ds,
                                "sp_ent_web_acMastView",
                                spParam,
                                dblist,connHandle);
            DataAcess.Connclose(connHandle);  
            totalRec = Convert.ToInt32(spParam[4].Value); 
            AcMastList = ConvertorAcMastList(Ds);
            return AcMastList;
        }


        private List<AcMast> ConvertorAcMastList(DataSet Ds)
        {
            getDateFormat DateFormat = new getDateFormat();
            if (Ds == null || Ds.Tables.Count == 0)
                throw new ArgumentException("DataSet is null or empty.", "Ds");

            List<AcMast> AcMastList = new List<AcMast>();
            try
            {
                foreach (DataRow AcMastRow in Ds.Tables["AcMast"].Rows)
                {
                    AcMast Acmast = new AcMast();
                    Acmast.Select = Convert.ToBoolean(AcMastRow["Select"]);
                    Acmast.Ac_Name = Convert.ToString(AcMastRow["ac_name"]);
                    Acmast.Ac_id = Convert.ToInt32(AcMastRow["ac_id"]);
                    Acmast.Group = Convert.ToString(AcMastRow["group"]);
                    Acmast.Mailname = Convert.ToString(AcMastRow["mailname"]);
                    Acmast.Defa_ac = Convert.ToBoolean(AcMastRow["defa_ac"]);
                    AcMastList.Add(Acmast);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Error occur while parsing dataset into Transaction List. Error Detail: {0} {1} ", Environment.NewLine, ex.Message));
            }
            return AcMastList;
        }

        public List<ItMast> GetItMastRows(int startIndex,
             int pageSize,
             string sortBy,
             string searchtext,
             ref int totalRec)
        {
            List<ItMast> ItMastList;

            SqlParameter[] spParam = new SqlParameter[5];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@startIndex";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = startIndex;

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@pageSize";
            spParam[1].SqlDbType = SqlDbType.Int;
            spParam[1].Value = pageSize;

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@sortBy";
            spParam[2].SqlDbType = SqlDbType.NVarChar;
            spParam[2].Value = sortBy;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@searchtext";
            spParam[3].SqlDbType = SqlDbType.NVarChar;
            spParam[3].Value = searchtext;

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@totRecOUT";
            spParam[4].SqlDbType = SqlDbType.Int;
            spParam[4].Value = 0;
            spParam[4].Direction = ParameterDirection.Output;

            DataSet Ds = new DataSet();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName  = SessionProxy.DbName;

            ArrayList dblist = new ArrayList();
            dblist.Add("ItMast");
            Ds = DataAcess.ExecuteDataset(Ds,
                                "sp_ent_web_itMastView",
                                spParam,
                                dblist,connHandle);
            DataAcess.Connclose(connHandle); 
            totalRec = Convert.ToInt32(spParam[4].Value);
            ItMastList = ConvertorItMastList(Ds);
            return ItMastList;
        }

        private List<ItMast> ConvertorItMastList(DataSet Ds)
        {
            getDateFormat DateFormat = new getDateFormat();
            if (Ds == null || Ds.Tables.Count == 0)
                throw new ArgumentException("DataSet is null or empty.", "Ds");

            List<ItMast> ItMastList = new List<ItMast>();
            try
            {
                foreach (DataRow ItMastRow in Ds.Tables["ItMast"].Rows)
                {
                    ItMast Itmast = new ItMast();
                    Itmast.Select = Convert.ToBoolean(ItMastRow["Select"]);
                    Itmast.It_name = Convert.ToString(ItMastRow["it_name"]);
                    Itmast.It_code = Convert.ToInt32(ItMastRow["it_code"]);
                    Itmast.Itgroup = Convert.ToString(ItMastRow["itgroup"]);
                    Itmast.Type = Convert.ToString(ItMastRow["type"]);
                    Itmast.NonStk = Convert.ToString(ItMastRow["NonStk"]);
                    ItMastList.Add(Itmast);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Error occur while parsing dataset into Transaction List. Error Detail: {0} {1} ", Environment.NewLine, ex.Message));
            }
            return ItMastList;
        }

    }

    public class ItMast
    {
        private bool select;
        public bool Select
        {
            get { return select; }
            set { select = value; }
        }

        private string it_name;
        public string It_name
        {
            get { return it_name; }
            set { it_name = value; }
        }
        private int it_code;
        public int It_code
        {
            get { return it_code; }
            set { it_code = value; }
        }
        private string itgroup;
        public string Itgroup
        {
            get { return itgroup; }
            set { itgroup = value; }
        }
        private string type;
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        private string nonStk;
        public string NonStk
        {
            get { return nonStk; }
            set { nonStk = value; }
        }


    }
    public class AcMast
    {
        private bool select;
        public bool Select
        {
            get { return select; }
            set { select = value; }
        }
        private string ac_Name;

        public string Ac_Name
        {
            get { return ac_Name; }
            set { ac_Name = value; }
        }
        private int ac_id;

        public int Ac_id
        {
            get { return ac_id; }
            set { ac_id = value; }
        }
        
        private string group;

        public string Group
        {
            get { return group; }
            set { group = value; }
        }
        private string mailname;

        public string Mailname
        {
            get { return mailname; }
            set { mailname = value; }
        }
        private bool defa_ac;

        public bool Defa_ac
        {
            get { return defa_ac; }
            set { defa_ac = value; }
        }
    }

    public class TransactionList
    {
        private bool select;
        public bool Select
        {
            get { return select; }
            set { select = value; }
        }
        private string entry_ty;

        public string Entry_ty
        {
            get { return entry_ty; }
            set { entry_ty = value; }
        }
        private int tran_cd;

        public int Tran_cd
        {
            get { return tran_cd; }
            set { tran_cd = value; }
        }
        private string inv_no;

        public string Inv_no
        {
            get { return inv_no; }
            set { inv_no = value; }
        }
        private DateTime date;

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
        private string party_nm;

        public string Party_nm
        {
            get { return party_nm; }
            set { party_nm = value; }
        }
        private decimal net_amt;

        public decimal Net_amt
        {
            get { return net_amt; }
            set { net_amt = value; }
        }
        private string dept;

        public string Dept
        {
            get { return dept; }
            set { dept = value; }
        }
        private string cate;

        public string Cate
        {
            get { return cate; }
            set { cate = value; }
        }
        private string inv_sr;

        public string Inv_sr
        {
            get { return inv_sr; }
            set { inv_sr = value; }
        }
        private string rule;

        public string Rule
        {
            get { return rule; }
            set { rule = value; }
        }
        private string bank_nm;

        public string Bank_nm
        {
            get { return bank_nm; }
            set { bank_nm = value; }
        }

        private string u_pinvno;

        public string U_pinvno
        {
            get { return u_pinvno; }
            set { u_pinvno = value; }
        }
        private DateTime u_pinvdt;

        public DateTime U_pinvdt
        {
            get { return u_pinvdt; }
            set { u_pinvdt = value; }
        }
    }

}
