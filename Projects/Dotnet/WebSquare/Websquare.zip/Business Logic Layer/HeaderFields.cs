using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class HeaderFields
    {
        private decimal txtGrossAmt;
        public decimal TxtGrossAmt
        {
            get { return txtGrossAmt; }
            set { txtGrossAmt = value; }
        }

        private decimal txtdedBefTax;
        public decimal TxtdedBefTax
        {
            get { return txtdedBefTax; }
            set { txtdedBefTax = value; }
        }

        private decimal txtTaxCharges;
        public decimal TxtTaxCharges
        {
            get { return txtTaxCharges; }
            set { txtTaxCharges = value; }
        }

        private decimal txtExAmt;
        public decimal TxtExAmt
        {
            get { return txtExAmt; }
            set { txtExAmt = value; }
        }
        private decimal txtAddCharges;
        public decimal TxtAddCharges
        {
            get { return txtAddCharges; }
            set { txtAddCharges = value; }
        }
        private decimal txtTaxAmt;
        public decimal TxtTaxAmt
        {
            get { return txtTaxAmt; }
            set { txtTaxAmt = value; }
        }
        private decimal txtNonTax;
        public decimal TxtNonTax
        {
            get { return txtNonTax; }
            set { txtNonTax = value; }
        }
        private decimal txtfdisc;
        public decimal Txtfdisc
        {
            get { return txtfdisc; }
            set { txtfdisc = value; }
        }
        private decimal txtRoundoff;
        public decimal TxtRoundoff
        {
            get { return txtRoundoff; }
            set { txtRoundoff = value; }
        }
        private decimal txtNetAmountTax;
        public decimal TxtNetAmountTax
        {
            get { return txtNetAmountTax; }
            set { txtNetAmountTax = value; }
        }
        private decimal txtItemTotal;
        public decimal TxtItemTotal
        {
            get { return txtItemTotal; }
            set { txtItemTotal = value; }
        }
        private decimal txtNetAmount;
        public decimal TxtNetAmount
        {
            get { return txtNetAmount; }
            set { txtNetAmount = value; }
        }
        private decimal txtAccNetAmount;
        public decimal TxtAccNetAmount
        {
            get { return txtAccNetAmount; }
            set { txtAccNetAmount = value; }
        }

    }
}
