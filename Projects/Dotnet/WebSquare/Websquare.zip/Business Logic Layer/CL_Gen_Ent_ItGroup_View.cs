using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class CL_Gen_Ent_ItGroup_Grid_Columns 
    {
        #region DataTable field Structure
        private bool chkSelect;

        public bool ChkSelect
        {
            get { return chkSelect; }
            set { chkSelect = value; }
        }
        private string it_group_name;

        public string It_group_name
        {
            get { return it_group_name; }
            set { it_group_name = value; }
        }
        private int itgrid;

        public int Itgrid
        {
            get { return itgrid; }
            set { itgrid = value; }
        }
        private string itgroup;

        public string Itgroup
        {
            get { return itgroup; }
            set { itgroup = value; }
        }
        private string type;

        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        #endregion
    }

    public class CL_Gen_Ent_ItGroup_view : CL_Gen_Ent_ItGroup_Grid_Columns
    {
        private int startIndex;
        private int pageSize;
        private string sortBy;
        private string trantype;
        private string searchtext;
        private int totalRec;
        private int groupId;

        public int GroupId
        {
            get { return groupId; }
            set { groupId = value; }
        }

        public int TotalRec
        {
            get { return totalRec; }
            set { totalRec = value; }
        }

        public int StartIndex
        {
            get { return startIndex; }
            set { startIndex = value; }
        }

        public int PageSize
        {
            get { return pageSize; }
            set { pageSize = value; }
        }

        public string SortBy
        {
            get { return sortBy; }
            set { sortBy = value; }
        }

        public string Trantype
        {
            get { return trantype; }
            set { trantype = value; }
        }

        public string Searchtext
        {
            get { return searchtext; }
            set { searchtext = value; }
        }

    }
}
