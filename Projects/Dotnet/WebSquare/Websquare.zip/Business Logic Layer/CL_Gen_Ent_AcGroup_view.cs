using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class CL_Gen_Ent_AcGroup_Grid_Columns
    {
        #region DataTable field Structure
        private string ac_group_name;

        public string Ac_group_name
        {
            get { return ac_group_name; }
            set { ac_group_name = value; }
        }
        private int ac_group_id;

        public int Ac_group_id
        {
            get { return ac_group_id; }
            set { ac_group_id = value; }
        }

        private string acgroup;

        public string Acgroup
        {
            get { return acgroup; }
            set { acgroup = value; }
        }
        private bool chkselect;

        public bool Chkselect
        {
            get { return chkselect; }
            set { chkselect = value; }
        }


        #endregion
    }

    public class CL_Gen_Ent_AcGroup_view : CL_Gen_Ent_AcGroup_Grid_Columns 
    {
        private int startIndex;
        private int pageSize;
        private string sortBy;
        private string trantype;
        private string searchtext;
        private int totalRec;
        private int groupId;

        public int GroupId
        {
            get { return groupId; }
            set { groupId = value; }
        }

        public int TotalRec
        {
            get { return totalRec; }
            set { totalRec = value; }
        }

        public int StartIndex
        {
            get { return startIndex; }
            set { startIndex = value; }
        }

        public int PageSize
        {
            get { return pageSize; }
            set { pageSize = value; }
        }

        public string SortBy
        {
            get { return sortBy; }
            set { sortBy = value; }
        }

        public string Trantype
        {
            get { return trantype; }
            set { trantype = value; }
        }

        public string Searchtext
        {
            get { return searchtext; }
            set { searchtext = value; }
        }

    }
}
