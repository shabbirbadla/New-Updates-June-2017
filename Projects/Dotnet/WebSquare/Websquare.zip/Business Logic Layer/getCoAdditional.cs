using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient; 
using Data.Acess.Layer; 

namespace Business.Logic.Layer
{
    public class getCoAdditional
    {
        public getCoAdditional()
        {
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        public DataSet CoAdditional(DataSet DS)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
            DS = _datatier.ExecuteDataset(DS, "select * from manufact","manufact",connHandle);
            _datatier.Connclose(connHandle);
            return DS;
        }

        public DataTable CoAdditional(DataTable Coadditional)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            Coadditional = _datatier.ExecuteDataTable("select * from manufact", "manufact",connHandle);
            _datatier.Connclose(connHandle);
            return Coadditional;
        }

        public DataTable CoAdditional(DataTable Coadditional,SqlCommand cmd)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;

            Coadditional = _datatier.ExecuteDataTable("select * from manufact",cmd.Transaction,ref connHandle);
            return Coadditional;
        }

    }
}
