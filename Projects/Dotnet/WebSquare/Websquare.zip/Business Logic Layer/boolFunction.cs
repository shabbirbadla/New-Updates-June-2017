using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public class boolFunction 
    {
        public boolFunction()
        {
        }

        public bool toBoolean(object boolVal)
        {
            if (!DBNull.Value.Equals(boolVal))
            {
                boolVal = Convert.ToBoolean(boolVal);
            }
            else
            {
                boolVal = false; 
            }
            return (Boolean)boolVal;
        }

    }

    
}
