using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls.WebParts;   
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.ComponentModel;
using System.Collections;
using System.Web;
using System.Configuration;
using AjaxControlToolkit;
  

  
 

namespace Business.Logic.Layer
{
    public class DynamicTemplate : ITemplate
    {
        System.Web.UI.WebControls.ListItemType templateType;
        System.Collections.Hashtable htControls = new System.Collections.Hashtable();
        System.Collections.Hashtable htBindPropertiesNames = new System.Collections.Hashtable();
        System.Collections.Hashtable htBindExpression = new System.Collections.Hashtable();
        private static getDateFormat DateFormat = new getDateFormat();
        public DynamicTemplate(ListItemType Type)
        {
            templateType = Type;
        }

        public void AddControl(WebControl wbControl, string BindPropertyName, string BindExpression)
        {
            htControls.Add(htControls.Count, wbControl);
            htBindPropertiesNames.Add(htBindPropertiesNames.Count, BindPropertyName);
            htBindExpression.Add(htBindExpression.Count, BindExpression);
        }

        public void InstantiateIn(System.Web.UI.Control container)
        {
            PlaceHolder ph =
            new PlaceHolder();
            for (int i = 0; i < htControls.Count;
            i++)
            {
                //clone control 
                Control cntrl =
                CloneControl((Control)htControls[i]);
                switch
                (templateType)
                {
                    case ListItemType.Item:
                        ph.Controls.Add(cntrl);
                        ph.DataBinding += new
                        EventHandler(Item_DataBinding);
                        break;
                    case ListItemType.Header:
                    //ph.Controls.Add(cntrl);
                    //break;
                    case ListItemType.AlternatingItem:
                        ph.Controls.Add(cntrl);
                        ph.DataBinding += new
                        EventHandler(Item_DataBinding);
                        break;
                    case ListItemType.Footer:
                        break;
                }
            }
            ph.DataBinding += new
            EventHandler(Item_DataBinding);
            container.Controls.Add(ph);
        }

        private Control CloneControl(System.Web.UI.Control src_ctl)
        {
            Type t = src_ctl.GetType();
            Object obj = Activator.CreateInstance(t);
            Control dst_ctl = (Control)obj;
            PropertyDescriptorCollection src_pdc = TypeDescriptor.GetProperties(src_ctl);
            PropertyDescriptorCollection dst_pdc = TypeDescriptor.GetProperties(dst_ctl);

            for (int i = 0; i < src_pdc.Count; i++)
            {

                if (src_pdc[i].Attributes.Contains(DesignerSerializationVisibilityAttribute.Content))
                {

                    object collection_val = src_pdc[i].GetValue(src_ctl);
                    if ((collection_val is IList) == true)
                    {
                        foreach (object child in (IList)collection_val)
                        {
                            Control new_child = CloneControl(child as Control);
                            object dst_collection_val = dst_pdc[i].GetValue(dst_ctl);
                            ((IList)dst_collection_val).Add(new_child);
                        }
                    }
                }
                else
                {

                       dst_pdc[src_pdc[i].Name].SetValue(dst_ctl, src_pdc[i].GetValue(src_ctl));
                }
            }

            return dst_ctl;

        }

        public void Item_DataBinding(object sender, System.EventArgs e)
        {
            PlaceHolder ph = (PlaceHolder)sender;
            GridViewRow ri = (GridViewRow)ph.NamingContainer;

            for (int i = 0; i < htControls.Count; i++)
            {
                if (htBindPropertiesNames[i].ToString().Length > 0)
                {
                    Control tmpCtrl = (Control)htControls[i];
                    String item1Value = "";
                    bool itemBitValue = false;
                    if (htBindExpression[i].ToString() != "")
                    {
                        if (!System.Convert.IsDBNull(DataBinder.Eval(ri.DataItem, htBindExpression[i].ToString())))
                        {
                            //item1Value = (String)DataBinder.Eval(ri.DataItem , htBindExpression[i].ToString());
                            switch (DataBinder.Eval(ri.DataItem, htBindExpression[i].ToString()).GetType().ToString().Trim().ToUpper())
                            {
                                case "SYSTEM.DATETIME":
                                    item1Value = DataBinder.Eval(ri.DataItem, htBindExpression[i].ToString(),"{0:dd/M/yyyy}");
                                    break;
                                case "SYSTEM.BOOLEAN":
                                    itemBitValue = Convert.ToBoolean(DataBinder.Eval(ri.DataItem, htBindExpression[i].ToString()));
                                    break; 
                                default:
                                    item1Value = Convert.ToString(DataBinder.Eval(ri.DataItem, htBindExpression[i].ToString()));
                                    break;
                            }

                            Control ctrl = ph.FindControl(tmpCtrl.ID);
                            Type t = ctrl.GetType();
                            System.Reflection.PropertyInfo pi = t.GetProperty(htBindPropertiesNames[i].ToString());

                            if (item1Value.ToString().Trim() != "")
                            {
                                pi.SetValue(ctrl, item1Value.ToString(), null);
                            }
                            else
                            {
                                if (itemBitValue != false)
                                    pi.SetValue(ctrl, itemBitValue, null);
                            }
                        }
                    }
                    //Control ctrl = ph.FindControl(tmpCtrl.ID);
                    //Type t = ctrl.GetType();
                    //System.Reflection.PropertyInfo pi = t.GetProperty(htBindPropertiesNames[i].ToString());

                    //pi.SetValue(ctrl, item1Value.ToString(), null);

                }

            }
        }
    }

}
    

