using System;
using System.Collections.Generic;
using System.Text;
using System.Web.SessionState;
using System.Web;  

namespace Business.Logic.Layer
{
    public abstract class SessionProxyChildProxyBase
    {
        public SessionProxyChildProxyBase()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Properties
        protected HttpSessionState Session
        {
            get
            { return HttpContext.Current.Session; }
        }
        #endregion
    }
}
