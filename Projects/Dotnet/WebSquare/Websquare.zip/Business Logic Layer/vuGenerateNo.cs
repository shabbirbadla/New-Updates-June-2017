using System;
using System.Collections.Generic;
using System.Text;
using System.Data; 

namespace Business.Logic.Layer
{
    public class vuGenerateNo
    {
        public vuGenerateNo()
        {
        }
        
        public string GenerateNo(DataTable table, 
                        string fldName, 
                        bool tableUpdate,
                        int padNum)
        {
            int serialNo = 0;
            if (table.Rows.Count > 0)
            {
                if (table.Columns[fldName].DataType.ToString().Trim().ToUpper() !=
                    "SYSTEM.INT32" ||
                    table.Columns[fldName].DataType.ToString().Trim().ToUpper() !=
                    "SYSTEM.DECIMAL")
                {
                    numericFunction numFunction = new numericFunction();

                    DataTable tblItNo = new DataTable();
                    DataColumn tblItNoCol = new DataColumn();
                    tblItNoCol.DataType = Type.GetType("System.Int32");
                    tblItNoCol.ColumnName = "MaxNo";
                    tblItNo.Columns.Add(tblItNoCol);

                    foreach (DataRow tblRow in table.Rows)
                    {
                        DataRow ItNoRow = tblItNo.NewRow();
                        ItNoRow["MaxNo"] = numFunction.toInt32(tblRow[fldName]);
                        tblItNo.Rows.Add(ItNoRow);
                    }
                    tblItNo.AcceptChanges();

                    serialNo = (Convert.ToString(tblItNo.Compute("max(MaxNo)", "")) == "" ?
                        0 :
                        Convert.ToInt32(tblItNo.Compute("max(MaxNo)", "")));
                        serialNo = serialNo + 1;
                }
                else
                {
                    serialNo = (Convert.ToString(table.Compute("max(" + fldName.Trim() + ")", "")) == "" ?
                            0 :
                            Convert.ToInt32(table.Compute("max(" + fldName.Trim() + ")", "")));
                    serialNo = serialNo + 1;
                }
            }
            else
            {
                serialNo = 1;
            }

            if (tableUpdate == true)
            {
                foreach (DataRow tableRow in table.Rows)
                {
                    if (Convert.ToString(tableRow[fldName]) == "")
                    {
                        tableRow[fldName] = Convert.ToString(serialNo).Trim().PadLeft(padNum, '0');
                        serialNo = serialNo + 1;
                    }
                    tableRow.AcceptChanges();
                }
            }

            string strMaxNo = "";
            if (padNum > 0)
                strMaxNo = Convert.ToString(serialNo).Trim().PadLeft(padNum, '0');
            else
                strMaxNo = Convert.ToString(serialNo).Trim();


            return strMaxNo; 
        }
    }
}
