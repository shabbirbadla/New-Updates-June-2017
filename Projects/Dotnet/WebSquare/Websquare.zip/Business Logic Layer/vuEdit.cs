using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Data.Acess.Layer;
using System.Web.UI.WebControls;
using System.Collections;   

namespace Business.Logic.Layer
{
    public class vuEdit
    {
        public vuEdit()
        {
        }

        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

       

        private string SqlStr = "";
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();
        private SqlConnection connHandle;

        public void getParentChildRecords(DataSet MainDataSet,
                                     int tranCd, TextBox txtTotalQty)
        {
            SqlParameter[] spParam = new SqlParameter[9];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@pcvtype";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = DBPropsSession.PcvType;

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@behave";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = DBPropsSession.Behave;

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@entryTbl";
            spParam[2].SqlDbType = SqlDbType.VarChar;
            spParam[2].Value = DBPropsSession.Entry_Tbl;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@tran_cd";
            spParam[3].SqlDbType = SqlDbType.Int;
            spParam[3].Value = tranCd;

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@prod";
            spParam[4].SqlDbType = SqlDbType.VarChar;
            spParam[4].Value = DBPropsSession.Vchkprod.Trim();

            spParam[5] = new SqlParameter();
            spParam[5].ParameterName = "@itPage";
            spParam[5].SqlDbType = SqlDbType.Bit;
            spParam[5].Value = DBPropsSession.ItemPage;
            
            spParam[6] = new SqlParameter();
            spParam[6].ParameterName = "@accPage";
            spParam[6].SqlDbType = SqlDbType.Bit;
            spParam[6].Value = DBPropsSession.AccountPage;

            spParam[7] = new SqlParameter();
            spParam[7].ParameterName = "@allocPage";
            spParam[7].SqlDbType = SqlDbType.Bit;
            spParam[7].Value = DBPropsSession.AllocationPage;

            spParam[8] = new SqlParameter();
            spParam[8].ParameterName = "@itRate";
            spParam[8].SqlDbType = SqlDbType.Bit;
            spParam[8].Value = DBPropsSession.ItRate; 


            ArrayList dblist = new ArrayList();
            dblist.Add("main_vw");
            if (DBPropsSession.ItemPage == true)
            {
                dblist.Add("item_vw");
            }

            stringFunction strFunction = new stringFunction();
            if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0)
            {
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR", "GT" }) == true ||
                          strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR", "GT" }) == true)
                {
                    dblist.Add("manu_det");
                }

                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS", "GT" }) == true ||
                           strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS", "GT" }) == true)
                {
                    dblist.Add("litemall");
                }
            }

            if (DBPropsSession.AccountPage == true)
            {
                dblist.Add("acdet_vw");
            }

            if (DBPropsSession.AllocationPage == true)
            {
                dblist.Add("mainall_tran_vw");
                dblist.Add("mainall_main_vw");
            }
            DataSet DSEdit = new DataSet();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName; 
            DSEdit = DataAcess.ExecuteDataset(DSEdit,
                                "sp_ent_web_get_editRec",
                                spParam,
                                dblist,connHandle);

            DataAcess.Connclose(connHandle);  
            if (MainDataSet.Tables.Contains("main_vw") == true)
            {
                // Remove all data of main_vw
                MainDataSet.Tables["main_vw"].Clear();
                MainDataSet.Tables["main_vw"].AcceptChanges();
            }
            DataAcess.ScatterGatherTable(DSEdit.Tables["main_vw"],
                            MainDataSet.Tables["main_vw"], false);
            MainDataSet.Tables["main_vw"].AcceptChanges();

            if (DBPropsSession.ItemPage == true)
            {
                if (MainDataSet.Tables.Contains("item_vw") == true)
                {
                    // Remove all data of item_vw
                    MainDataSet.Tables["item_vw"].Clear();
                    MainDataSet.Tables["item_vw"].AcceptChanges();
                }

                DataAcess.ScatterGatherTable(DSEdit.Tables["item_vw"], 
                            MainDataSet.Tables["item_vw"], 
                            false);
                MainDataSet.Tables["item_vw"].AcceptChanges();

                foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
                {
                    itemRow["sr_sr"] = "YYYYY";
                    itemRow.AcceptChanges();
                }
                MainDataSet.Tables["item_vw"].AcceptChanges();

                boolFunction bitFunction = new boolFunction();
                if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
                    (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ||
                     Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE") &&
                     (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                     strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
                {
                    DBPropsSession.VarETGoDown = "";
                    DBPropsSession.VarETGodownTo = "";
                    int itemRows = MainDataSet.Tables["item_vw"].Rows.Count - 1;
                    if (DBPropsSession.PcvType == "IR")
                    {
                        if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                        {
                            if (bitFunction.toBoolean(MainDataSet.Tables["Company"].Rows[0]["et_flag"]) == false)
                            {
                                DBPropsSession.VarETGodownTo = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
                                DBPropsSession.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["warenm_fr"]).Trim();
                            }
                        }

                        if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                        {
                            if (bitFunction.toBoolean(MainDataSet.Tables["Company"].Rows[0]["net_flag"]) == false)
                            {
                                DBPropsSession.VarETGodownTo = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
                                DBPropsSession.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["warenm_fr"]).Trim();
                            }
                        }

                    }
                    else
                    {
                        if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                        {
                            if (bitFunction.toBoolean(MainDataSet.Tables["manufact"].Rows[0]["et_flag"]) == false)
                            {
                                DBPropsSession.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
                            }
                        }

                        if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                        {
                            if (bitFunction.toBoolean(MainDataSet.Tables["manufact"].Rows[0]["net_flag"]) == false)
                            {
                                DBPropsSession.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
                            }
                        }
                    }
                }

                // Litemall & Manudet
                if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0)
                {
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR", "GT" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR", "GT" }) == true)
                    {
                        DataAcess.ScatterGatherTable(DSEdit.Tables["manu_det"], MainDataSet.Tables["manu_det_vw"], false);
                        MainDataSet.Tables["manu_det_vw"].AcceptChanges();
                    }

                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS", "GT" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS", "GT" }) == true)
                    {
                        DataAcess.ScatterGatherTable(DSEdit.Tables["litemall"], MainDataSet.Tables["litemall_vw"], false);
                        MainDataSet.Tables["litemall_vw"].AcceptChanges();
                    }
                }

                decimal totQty = Convert.ToDecimal(MainDataSet.Tables["item_vw"].Compute("sum(qty)", ""));
                txtTotalQty.Text = Convert.ToString(totQty);
            } // end Item Page

            if (DBPropsSession.AccountPage == true)
            {
                if (MainDataSet.Tables.Contains("acdet_vw") == true)
                {
                    // Remove all data of item_vw
                    MainDataSet.Tables["acdet_vw"].Clear();
                    MainDataSet.Tables["acdet_vw"].AcceptChanges();
                }

                DataAcess.ScatterGatherTable(DSEdit.Tables["acdet_vw"], MainDataSet.Tables["acdet_vw"], false);
                MainDataSet.Tables["acdet_vw"].AcceptChanges();

                if (DBPropsSession.AllocationPage == true)
                {
                    vuAllocation createMallTable = new vuAllocation();
                    createMallTable.CreateMallVw(MainDataSet, DBPropsSession.PcvType);
                    DataAcess.ScatterGatherTable(DSEdit.Tables["mainall_tran_vw"], MainDataSet.Tables["mall_vw"], true);
                    DataAcess.ScatterGatherTable(DSEdit.Tables["mainall_main_vw"], MainDataSet.Tables["mall_vw"], true);
                    MainDataSet.Tables["mall_vw"].AcceptChanges();
                }
            }
            DSEdit.Dispose();
        }


        //public void getParentRecords(DataSet MainDataSet,
        //                             int tranCd)
        //{
        //    SqlStr = "select top 1 * from " + DBPropsSession.Entry_Tbl + "main" +
        //             " where tran_cd = " + tranCd;

        //    if (MainDataSet.Tables.Contains("main_vw") == true)
        //    {
        //        // Remove all data of item_vw
        //        MainDataSet.Tables["main_vw"].Clear();
        //        MainDataSet.Tables["main_vw"].AcceptChanges();
        //    }

        //    DataTable tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, "_tmp");
        //    DataAcess.ScatterGatherTable(tmpTblVw, MainDataSet.Tables["main_vw"],false);
        //    MainDataSet.Tables["main_vw"].AcceptChanges();
        //}

        //public void getChildRecords(DataSet MainDataSet,
        //                            TextBox txtTotalQty)
                                    
                                    
        //{
             
        //    if (DBPropsSession.ItemPage == true)
        //    {
        //        if (MainDataSet.Tables.Contains("item_vw") == true)
        //        {
        //            // Remove all data of item_vw
        //            MainDataSet.Tables["item_vw"].Clear();
        //            MainDataSet.Tables["item_vw"].AcceptChanges(); 
        //        }

        //        SqlStr = " select * from " + DBPropsSession.Entry_Tbl+"item" +
        //                 " where tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);

        //        DataTable tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, "_tmp");
        //        DataAcess.ScatterGatherTable(tmpTblVw, MainDataSet.Tables["item_vw"],false);
        //        MainDataSet.Tables["item_vw"].AcceptChanges();

        //        if (DBPropsSession.EditMode == true)
        //        {
        //            foreach (DataRow itemRow in MainDataSet.Tables["item_vw"].Rows)
        //            {
        //                itemRow["sr_sr"] = "YYYYY";
        //                itemRow.AcceptChanges();  
        //            }
        //            MainDataSet.Tables["item_vw"].AcceptChanges();

        //            boolFunction bitFunction = new boolFunction();
        //            if (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 &&
        //                (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper()  == "EXCISE" ||
        //                 Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE") &&
        //                 (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
        //                 strFunction.InList(PageCustProps.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
        //            {
        //                PageCustProps.VarETGoDown = "";
        //                PageCustProps.VarETGodownTo = "";
        //                int itemRows = MainDataSet.Tables["item_vw"].Rows.Count - 1;
        //                if (PageCustProps.PcvType == "IR")
        //                {
        //                    if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
        //                    {
        //                        if (bitFunction.toBoolean(MainDataSet.Tables["Company"].Rows[0]["et_flag"]) == false)
        //                        {
        //                            PageCustProps.VarETGodownTo = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
        //                            PageCustProps.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["warenm_fr"]).Trim();
        //                        }
        //                    }

        //                    if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
        //                    {
        //                        if (bitFunction.toBoolean(MainDataSet.Tables["Company"].Rows[0]["net_flag"]) == false)
        //                        {
        //                            PageCustProps.VarETGodownTo = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
        //                            PageCustProps.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["warenm_fr"]).Trim();
        //                        }
        //                    }

        //                }
        //                else
        //                {
        //                    if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
        //                    {
        //                        if (bitFunction.toBoolean(MainDataSet.Tables["manufact"].Rows[0]["et_flag"]) == false)
        //                        {
        //                            PageCustProps.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
        //                        }
        //                    }

        //                    if (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
        //                    {
        //                        if (bitFunction.toBoolean(MainDataSet.Tables["manufact"].Rows[0]["net_flag"]) == false)
        //                        {
        //                            PageCustProps.VarETGoDown = Convert.ToString(MainDataSet.Tables["item_vw"].Rows[itemRows]["ware_nm"]).Trim();
        //                        }
        //                    }
        //                }
        //            }


        //            // Litemall & Manudet
        //            if (PageCustProps.Vchkprod.Trim().IndexOf("vutex") >= 0)
        //            {
        //                if (strFunction.InList(PageCustProps.PcvType, new string[] { "AR", "IR", "GT" }) == true ||
        //                    strFunction.InList(PageCustProps.Behave, new string[] { "AR", "IR", "GT" }) == true)
        //                {
        //                    SqlStr = "select * from manu_det where tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
        //                    tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, "_tmp");
        //                    DataAcess.ScatterGatherTable(tmpTblVw, MainDataSet.Tables["manu_det_vw"], false);
        //                    MainDataSet.Tables["manu_det_vw"].AcceptChanges();
        //                }

        //                if (strFunction.InList(PageCustProps.PcvType, new string[] { "DC", "IR", "SS", "GT" }) == true ||
        //                    strFunction.InList(PageCustProps.Behave, new string[] { "DC", "IR", "SS", "GT" }) == true)
        //                {
        //                    SqlStr = "select * from litemall where tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
        //                    tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, "_tmp");
        //                    DataAcess.ScatterGatherTable(tmpTblVw, MainDataSet.Tables["litemall_vw"], false);
        //                    MainDataSet.Tables["litemall_vw"].AcceptChanges();
        //                }
        //            }
        //        }

        //        decimal totQty = Convert.ToDecimal(MainDataSet.Tables["item_vw"].Compute("sum(qty)",""));
        //        txtTotalQty.Text = Convert.ToString(totQty);

        //    } // End ItemPage

        //    if (PageCustProps.AccountPage == true)
        //    {
        //        if (MainDataSet.Tables.Contains("acdet_vw") == true)
        //        {
        //            // Remove all data of item_vw
        //            MainDataSet.Tables["acdet_vw"].Clear();
        //            MainDataSet.Tables["acdet_vw"].AcceptChanges();
        //        }

        //        SqlStr = " select * from " + PageCustProps.Entry_Tbl + "acdet" +
        //                 " where tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);


        //        DataTable tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, "_tmp");
        //        DataAcess.ScatterGatherTable(tmpTblVw, MainDataSet.Tables["acdet_vw"],false);
        //        MainDataSet.Tables["acdet_vw"].AcceptChanges();

        //        if (PageCustProps.AllocationPage == true &&
        //            PageCustProps.EditMode == true)
        //        {
        //            vuAllocation createMallTable = new vuAllocation();
        //            createMallTable.CreateMallVw(MainDataSet, PageCustProps.PcvType);

        //            foreach (DataRow acDetRow in MainDataSet.Tables["acdet_vw"].Rows)
        //            {
        //                if (Convert.ToDecimal(acDetRow["re_all"])>0)
        //                {
        //                    SqlStr = "select top 1 entry_ty from mainall_vw " +
        //                             " where entry_ty ='" +
        //                             Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
        //                             " and tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
        //                             " and ac_id = " + Convert.ToInt32(acDetRow["ac_id"]);

        //                    DR = DataAcess.ExecuteDataReader(SqlStr);
        //                    if (DR.HasRows == true)
        //                    {
        //                        DR.Close();
        //                        DR.Dispose();

        //                        SqlStr = "select * from mainall_vw where entry_ty ='" +
        //                                 Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
        //                                 " and tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
        //                                 " and ac_id = " + Convert.ToInt32(acDetRow["ac_id"]);

        //                        tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, "_tmp");
        //                        DataAcess.ScatterGatherTable(tmpTblVw, MainDataSet.Tables["mall_vw"],true);
        //                        MainDataSet.Tables["mall_vw"].AcceptChanges();

        //                    }
        //                    DR.Close();
        //                    DR.Dispose();

        //                    SqlStr = "select top 1 entry_ty from mainall_vw " +
        //                             " where entry_all ='" +
        //                             Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
        //                             " and main_tran = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
        //                             " and ac_id = " + Convert.ToInt32(acDetRow["ac_id"]);

        //                    DR = DataAcess.ExecuteDataReader(SqlStr);
        //                    if (DR.HasRows == true)
        //                    {
        //                        DR.Close();
        //                        DR.Dispose();

        //                        SqlStr = "select * from mainall_vw where entry_all ='" +
        //                                 Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
        //                                 " and main_tran = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
        //                                 " and ac_id = " + Convert.ToInt32(acDetRow["ac_id"]);

        //                        tmpTblVw = DataAcess.ExecuteDataTable(SqlStr, "_tmp");
        //                        DataAcess.ScatterGatherTable(tmpTblVw, MainDataSet.Tables["mall_vw"],true);
        //                        MainDataSet.Tables["mall_vw"].AcceptChanges();

        //                    }
        //                    DR.Close();
        //                    DR.Dispose();

        //                }
        //            }
        //        }

        //    } // End AccountPage

           
        //}
    }
}
