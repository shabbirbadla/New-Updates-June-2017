using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    class Class1 : IEBilling 
    {
        public void SelectedIndexChanged(object sender, EventArgs e)
        {
            string uyuytest = "";
        }
    }
}
