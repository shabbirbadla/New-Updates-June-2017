using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient; 
using Data.Acess.Layer; 
    

namespace Business.Logic.Layer
{

    public class vuAccountBalance
    {
        //private static DataTier DataAccess = new DataTier();  

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        public vuAccountBalance()
        {
        }

        public decimal getAccountBalance(int acId,string acName,int tranCd,bool addMode,string Entry_tbl)
        {
            decimal acBal = 0;
            try
            {
                numericFunction numFunction = new numericFunction();
                DataTier DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName;

                string sqlStr = "";
                if (acId != 0)
                    sqlStr = "select top 1 DR,CR from ac_bal where ac_id = " + acId.ToString().Trim();
                else
                    sqlStr = "select top 1 DR,CR from ac_bal where ac_name = '" + acName.ToString().Trim() + "'";

                DataTable acbal_vw = new DataTable();

                acbal_vw = DataAccess.ExecuteDataTable(sqlStr, "_acBal",connHandle);
                DataAccess.Connclose(connHandle);  
                if (acbal_vw.Rows.Count > 0)
                {
                    acBal = (numFunction.toDecimal(acbal_vw.Rows[0]["DR"])) - numFunction.toDecimal(acbal_vw.Rows[0]["CR"]);
                    if (addMode == false)
                    {
                        if (acId != 0)
                            sqlStr = "select top 1 amount,amt_ty from " + Entry_tbl.Trim() + "acdet" +
                                 " where tran_cd = " + tranCd + " and ac_id = " + acId;
                        else
                            sqlStr = "select top 1 amount,amt_ty from " + Entry_tbl.Trim() + "acdet" +
                                 " where tran_cd = " + tranCd + " and ac_name = '" + acName.ToString().Trim() + "'";

                        acbal_vw = DataAccess.ExecuteDataTable(sqlStr, "_acBal",connHandle);
                        DataAccess.Connclose(connHandle); 
                        if (acbal_vw.Rows.Count > 0)
                        {
                            foreach (DataRow acBalRow in acbal_vw.Rows)
                            {
                                if (Convert.ToString(acBalRow["Amt_ty"]) == "DR")
                                {
                                    acBal = acBal + (-numFunction.toDecimal(acBalRow["Amount"]));
                                }
                                else
                                {
                                    acBal = acBal + (+numFunction.toDecimal(acBalRow["Amount"]));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR found in getAccountBalance method |" + Ex.Message.Trim());
            }

            return acBal;
        }
    }
}
