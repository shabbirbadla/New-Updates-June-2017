using System;
using System.Collections.Generic;
using System.Text;
using System.Data; 

namespace Business.Logic.Layer
{
    public class CL_DBPageProperties
    {
        public DataTable DbProperties()
        {
            DataTable m_Db_Properties = new DataTable();
            AddDbColumns(m_Db_Properties, "ItemPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "AccountPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ChargesPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "IchargesPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "AllocationPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "AinfoPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "TdsPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ServiceTaxPage", "System.Boolean");
            AddDbColumns(m_Db_Properties, "AddMode", "System.Boolean");
            AddDbColumns(m_Db_Properties, "LTodaySDate", "System.Boolean"); 
            AddDbColumns(m_Db_Properties, "EditMode", "System.Boolean");
            AddDbColumns(m_Db_Properties, "SalesTaxItem", "System.Boolean");
            AddDbColumns(m_Db_Properties, "IsOpenGridForAllocation", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ColDept", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ColCate", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ColSeries", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ColRule", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ColBankNm", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ColUInvnodt", "System.Boolean");
            AddDbColumns(m_Db_Properties, "ItRate", "System.Boolean");
            AddDbColumns(m_Db_Properties, "LbackDated", "System.Boolean");

            AddDbColumns(m_Db_Properties, "PcvType", "System.String");
            AddDbColumns(m_Db_Properties, "Behave", "System.String");
            AddDbColumns(m_Db_Properties, "Entry_Tbl", "System.String");
            AddDbColumns(m_Db_Properties, "Vchkprod", "System.String");
            AddDbColumns(m_Db_Properties, "HowtoCalculateExAmt", "System.String");
            AddDbColumns(m_Db_Properties, "JustSeries", "System.String");
            AddDbColumns(m_Db_Properties, "JustInvoice", "System.String");
            AddDbColumns(m_Db_Properties, "EditSeries", "System.String");
            AddDbColumns(m_Db_Properties, "EditInvoice", "System.String");

            AddDbColumns(m_Db_Properties, "VarETGodownTo", "System.String");
            AddDbColumns(m_Db_Properties, "VarETGoDown", "System.String");


            AddDbColumns(m_Db_Properties, "AppDate", "System.DateTime");
            AddDbColumns(m_Db_Properties, "PBackDate", "System.DateTime");

                        
            AddDbColumns(m_Db_Properties, "Tex_exe", "System.Int32");
            AddDbColumns(m_Db_Properties, "AllocRowIndex", "System.Int32");
            AddDbColumns(m_Db_Properties, "InitStartWithTranCd", "System.Int32");
            AddDbColumns(m_Db_Properties, "WareCol", "System.Int32");

            AddDbColumns(m_Db_Properties, "VAmt", "System.Decimal");
            AddDbColumns(m_Db_Properties, "VchrAmt", "System.Decimal");
            AddDbColumns(m_Db_Properties, "FromAcAmt", "System.Decimal");

            return m_Db_Properties; 

        }

        private void AddDbColumns(DataTable m_dt,
                                  string m_colName,
                                  string m_Dtype)
        {
            DataColumn m_Db_Col = new DataColumn();
            m_Db_Col.ColumnName = m_colName;
            m_Db_Col.DataType = Type.GetType(m_Dtype);
            m_dt.Columns.Add(m_Db_Col);   
        }
        
        

    }
}
