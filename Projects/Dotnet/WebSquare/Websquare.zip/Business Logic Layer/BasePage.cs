using System;
using System.IO;
using System.IO.Compression;
using System.Collections;
using System.ComponentModel;
using System.Web.UI;
using System.Configuration;
using System.Threading;
using System.Globalization;
using System.Text;

namespace Business.Logic.Layer
{
    public abstract class BasePage : System.Web.UI.Page
    {
        private static string _url;

        /// <summary> 
        /// property to hold the redirect url we will 
        /// use if the users session is expired or has 
        /// timed out. 
        /// </summary> 
        public static string URL
        {
            get { return _url; }
            set { _url = value; }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);


            //check to see if the Session is null (doesnt exist) 
            if (Context.Session != null)
            {
                //check the IsNewSession value, this will tell us if the session has been reset. 
                //IsNewSession will also let us know if the users session has timed out 
                if (Session.IsNewSession)
                {
                    //now we know it's a new session, so we check to see if a cookie is present 
                    string cookie = Request.Headers["Cookie"];
                    //now we determine if there is a cookie does it contains what we're looking for 
                    if ((null != cookie) && (cookie.IndexOf("ASP.NET_SessionId") >= 0))
                    {
                        //since it's a new session but a ASP.Net cookie exist we know 
                        //the session has expired so we need to redirect them 
                        Response.Redirect("SessionTimeout.htm");
                    }
                }
            }

        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }

        public void DisplayMessage(string strMsg)
        {
            strMsg = strMsg.Replace("\r\n", "\\n");
            strMsg = strMsg.Replace("\n", "\\n");
            strMsg = strMsg.Replace("'", "");
            string scriptString = "alert('" + strMsg + "');";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), null, scriptString, true);
        }
    }
}
