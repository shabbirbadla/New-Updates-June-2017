using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;  

namespace Business.Logic.Layer
{
    class PostBackEvents
    {
        private GridView grdStockStatus;
        public GridView GrdStockStatus
        {
            get { return grdStockStatus; }
            set { grdStockStatus = value; }
        }

        public void SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

      
    }
}
