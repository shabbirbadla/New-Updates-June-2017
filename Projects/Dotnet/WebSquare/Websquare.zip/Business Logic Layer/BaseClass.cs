using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Logic.Layer
{
    public abstract class BaseClass
    {
        public string DisplayMessage(string strMsg)
        {
            strMsg = strMsg.Replace("\r\n", "\\n");
            strMsg = strMsg.Replace("\n", "\\n");
            strMsg = strMsg.Replace("'", "");
            string scriptString = "alert('" + strMsg + "');";
            return scriptString; 
        }
    }
}
