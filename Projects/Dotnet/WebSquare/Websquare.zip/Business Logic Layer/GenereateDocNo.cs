using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;   
using Data.Acess.Layer;

namespace Business.Logic.Layer
{
    public class GenereateDocNo
    {
        private string SqlStr = "";
        //private static DataTier DataAcess = new DataTier();

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();

        public GenereateDocNo() // Constructor
        {
        }

       


        public string GenDocNo(string entryType,
            DateTime InvoiceDate,
            int docLength,
            SqlCommand cmd,
            bool isTransaction,
            ref SqlConnection connHandle)
                        
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlStr = "select * from gen_doc with (nolock) where 1=0";
            DataTable gendoc_vw = null;
            if (cmd != null)
                gendoc_vw = DataAcess.ExecuteDataTable(SqlStr,cmd.Transaction,ref connHandle);
            else
                gendoc_vw = DataAcess.ExecuteDataTable(SqlStr,"genDoc",connHandle);

            DataRow genDocRow = gendoc_vw.NewRow();
            getDateFormat DateFormat = new getDateFormat();
            genDocRow["entry_ty"] = entryType.Trim();
            genDocRow["date"] = InvoiceDate;
            bool isRollBack = true;
            string mDocNo = "";
            while (true)
            {
                SqlStr = "select top 1 doc_no from gen_doc with (TABLOCKX) " +
                         " where entry_ty = '" + Convert.ToString(genDocRow["entry_ty"]).Trim() + "'" +
                         " and date ='" + DateFormat.dateformat(Convert.ToDateTime(genDocRow["date"])) + "'";

                SqlDataReader Dr;
                Dr = DataAcess.ExecuteDataReader(SqlStr,cmd,ref connHandle);
                if (Dr.HasRows == false)
                {
                    genDocRow["doc_no"] = 1;
                    gendoc_vw.Rows.Add(genDocRow);    
                    gendoc_vw.AcceptChanges();
                    SqlStr = DataAcess.GenInsertString(gendoc_vw, 
                            "gen_doc", 
                            null, 
                            null);
                }
                else
                {
                    while (Dr.Read())
                    {
                        genDocRow["doc_no"] = Convert.ToInt32(Dr["doc_no"]) + 1;
                        gendoc_vw.Rows.Add(genDocRow);
                        gendoc_vw.AcceptChanges();
                        string cond = "entry_ty ='" + Convert.ToString(gendoc_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                                      " and date ='" + DateFormat.dateformat(Convert.ToDateTime(gendoc_vw.Rows[0]["date"])) + "'";

                        SqlStr = DataAcess.GenUpdateString(gendoc_vw,
                                        "gen_doc",
                                        null,
                                        new string[] { "doc_no" },
                                        cond,
                                        null);
                    }
                 }
                 Dr.Close();
                 Dr.Dispose();

                 if (cmd == null)
                 {
                     cmd = new SqlCommand();
                 }

                 cmd = DataAcess.ExecuteNonQuery(cmd,SqlStr,"TX", true,ref connHandle);
                 int roweffected = 0;
                 try
                 {
                     roweffected = cmd.ExecuteNonQuery();
                     if (isTransaction == false)
                        DataAcess.CommitTransaction(cmd.Transaction);

                     mDocNo = Convert.ToString(gendoc_vw.Rows[0]["doc_no"]).Trim();
                     mDocNo = mDocNo.PadLeft(docLength, '0');
                     SqlStr = "select top 1 entry_ty from " + DBPropsSession.Entry_Tbl.Trim() + "main" +
                              " where entry_ty ='" + Convert.ToString(gendoc_vw.Rows[0]["entry_ty"]).Trim() + "'" +
                              " and date ='" + DateFormat.dateformat(Convert.ToDateTime(gendoc_vw.Rows[0]["date"]))+ "'" +
                              " and doc_no ='" + mDocNo.Trim() + "'";
                     Dr = DataAcess.ExecuteDataReader(SqlStr,cmd,ref connHandle);
                     if (Dr.HasRows == false)
                     {
                         Dr.Close();
                         Dr.Dispose();
                         isRollBack = false;
                         break;
                     }
                     Dr.Close();
                     Dr.Dispose();

                 }
                 catch (Exception ex)
                 {
                     throw ex;
                 }
            }

            if (isRollBack == true)
            {
                if (isTransaction == false)
                    DataAcess.RollBackTransaction(cmd.Transaction);  
            }

            if (isTransaction == false)
                DataAcess.Connclose(connHandle);  

            return mDocNo;
        }

    }
}
