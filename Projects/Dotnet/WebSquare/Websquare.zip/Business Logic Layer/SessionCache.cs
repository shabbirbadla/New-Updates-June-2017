using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Caching; 

namespace Business.Logic.Layer
{
    public class SessionCache
    {
        #region Fields and Properties
        private string _uniqueId;
        public object this[string key]
        {
            get { return HttpRuntime.Cache[CreateKey(key)]; }
            set { Insert(key, value); }
        }
        #endregion

        #region Constructors
        public SessionCache()
        {
            if (HttpContext.Current == null)
            {
                Init(Guid.NewGuid().ToString());
            }
            else
            {
                Init(HttpContext.Current.Session.SessionID);
            }
        }

        public SessionCache(string uniqueId)
        {
            Init(uniqueId);
        }

        private void Init(string uniqueId)
        {
            if (string.IsNullOrEmpty(uniqueId))
            {
                throw new ArgumentNullException("uniqueId");
            }
            _uniqueId = uniqueId;
        }
        #endregion

        #region Inserts
        public void Insert(string key,object data)
        {
            HttpRuntime.Cache.Insert(CreateKey(key), data);
        }

        public void Insert(string key,object data, CacheDependency dependency)
        {
            HttpRuntime.Cache.Insert(CreateKey(key), data, dependency);
        }
        //more inserts
        #endregion

        #region Private Methods
        private string CreateKey(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentNullException("key");
            }
            return string.Format("{0}:{1}", key, _uniqueId);
        }
        #endregion

    }
}
