using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data; 
using System.Web.UI.WebControls;
using Data.Acess.Layer;
using Controls;


namespace Business.Logic.Layer
{
    public class vouGridFill
    {
        public vouGridFill()
        {
        }

        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

        private bool  salesTaxItem;
        public bool SalesTaxItem
        {
            get { return salesTaxItem; }
            set { salesTaxItem = value; }
        }

        //private PageCustomProperties pageCustProps;
        //public PageCustomProperties PageCustProps
        //{
        //    get { return pageCustProps; }
        //    set { pageCustProps = value; }
        //}


        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();
        SqlConnection connHandle;

        public DataView ItemgridTemplate(DataTable lother_vw,
                                          DataTable company,
                                          DataTable lcode_vw,
                                          DataTable item_vw,
                                          DataTable TexExe,
                                          string Rule)
        {
            int colSerial = 1;
            int getSerial = 1;
            string SqlStr = "";
            boolFunction bitFunction = new boolFunction();
            stringFunction strFunction = new stringFunction();
            numericFunction numFunction = new numericFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            DataColumn lotherNewCol = new DataColumn();
            lotherNewCol.DataType = Type.GetType("System.Int32");
            lotherNewCol.ColumnName = "dserial";
            lother_vw.Columns.Add(lotherNewCol);

            lotherNewCol = new DataColumn();
            lotherNewCol.DataType = Type.GetType("System.String");
            lotherNewCol.ColumnName = "tag";
            lother_vw.Columns.Add(lotherNewCol);

            DataView lotherview = lother_vw.DefaultView;
            lotherview.RowFilter = "(att_file = 0 and ingrid = 1 and inter_use = 0)";
            lotherview.Sort = "serial ASC";

            // Item No. Col
            getSerial = findSerial(lotherview,colSerial, "serial = 1 and ingrid = 1 and inter_use = 0");
            colSerial = getSerial > 0 ? getSerial : colSerial + 1;

            insertRow(lotherview, DBPropsSession.PcvType, "Item_No", "Item No.", colSerial,
                      25, 0, "", ".f.", "Numeric", false, true, 999, "STANDARD ITEM NO.", "", false, false, "", "", "");

            // Item Name
            insertRow(lotherview, DBPropsSession.PcvType, "Item", "Item Name",
                      colSerial, 250, 0, "", "", "VARCHAR", false, true, 998, "STANDARD ITEM NAME", "", true, true, "", "onfocus", "javascript:DropItemFocus();");

            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
               (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS", "GT" }) == true &&
                strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS", "GT" }) == true))
            {
                insertRow(lotherview, DBPropsSession.PcvType, "Alloc", "Allocation",
                          3, 50, 0, "", "", "LINKBUTTON", false, true, 999, "Allocation", "", false, false, "", "", "");
            }

            // Qty
            getSerial = findSerial(lotherview,colSerial, "serial = 2 and ingrid = 1 and inter_use = 0");
            colSerial = (getSerial > 0 ? getSerial : colSerial + 1);
            int deci = 2;
            
            if (numFunction.toInt32(company.Rows[0]["deci"]) > 0)
            {
                deci = numFunction.toInt32(company.Rows[0]["deci"]);
            }

            insertRow(lotherview, DBPropsSession.PcvType, "Qty", "Quantity",
                        colSerial, 50, deci, "1", "", "Decimal", false, true, 999, "QUANTITY", "", true, false, "", "onfocusout", "javascript:calAssesableValue();");

            // Rate
            //precolSerial = colSerial;
            getSerial = findSerial(lotherview,colSerial, "serial = 3 and ingrid = 1 and inter_use = 0");
            colSerial = (getSerial > 0 ? getSerial : colSerial + 1);
            insertRow(lotherview, DBPropsSession.PcvType, "rate", "Rate",
                        colSerial, 50, 2, "1", "", "Decimal", false, true, 999, "RATE", "", true, false, "", "onfocusout", "javascript:calAssesableValue();");


            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true &&
                 strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true))
            {
                insertRow(lotherview, DBPropsSession.PcvType, "EXdet", "Excise Details",
                          colSerial, 50, 0, "", "", "BUTTON", false, true, 999, "EXCISE DETAILS", "", false, false, "", "", "");
            }

            int precolSerial = 0;
            precolSerial = findSerial(lotherview, colSerial, "att_file = 0 and ingrid = 0 and inter_use = 0");
            if (precolSerial > 0)
            {
                getSerial = findSerial(lotherview, colSerial, "serial = 4 and ingrid = 1 and inter_use = 0");
                colSerial = (getSerial > 0 ? getSerial : colSerial + 1);

                insertRow(lotherview, DBPropsSession.PcvType, "XtraData", "Additional Info.",
                          colSerial, 20, 0, "", "", "BUTTON", false, true, 999, "EXTRA DATA", "", false, false, "", "", "");
            }

            //if (bitFunction.toBoolean(lcode_vw.Rows[0]["i_narr"]) == true)
            //{
            //    getSerial = findSerial(lotherview, colSerial, "serial = 5 and ingrid = 1 and inter_use = 0");
            //    colSerial = (getSerial > 0 ? getSerial : colSerial + 1);
            //    insertRow(lotherview, DBPropsSession.PcvType, "CmdNarr", "Narration",
            //              colSerial, 20, 0, "", "", "BUTTON", false, true, 999, "NARRATION", "", false, false, "", "", "");
            //}

            if (bitFunction.toBoolean(lcode_vw.Rows[0]["i_narr"]) == true)
            {
                getSerial = findSerial(lotherview, colSerial, "serial = 5 and ingrid = 1 and inter_use = 0");
                colSerial = (getSerial > 0 ? getSerial : colSerial + 1);
                insertRow(lotherview, DBPropsSession.PcvType, "Narr", "Narration",
                          colSerial, 250, 0, "", "", "VARCHAR", false, true, 999, "Narration", "", false, false, "", "", "");

            }


            if (!(DBPropsSession.Vchkprod.IndexOf("vutex") >= 0) &&
                (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "GT", "IR" }) == true &&
                 strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "GT", "IR" }) == true))
            {
                getTables checkLdc = new getTables();
                if (checkLdc.checkldcw("WAREHOUSE", "ware_nm", DBPropsSession.PcvType) == true)
                {
                    colSerial = findSerial(lotherview, colSerial, "serial = 6 and ingrid = 1 and inter_use = 0");
                    colSerial = (getSerial > 0 ? getSerial : colSerial + 1);

                    insertRow(lotherview, DBPropsSession.PcvType, "ware_nm", "Warehouse Name",
                              colSerial, 100, 0, "", "", "DROPDOWNLIST", false, true, 999, "WAREHOUSE NAME", "", true, false, "", "", "");
                }
            }

            if ((DBPropsSession.Vchkprod.IndexOf("vutex") >= 0) &&
                 (strFunction.InList(DBPropsSession.PcvType, new string[] {"DC","AR","IR","GT","SS"}) == true ||
                  strFunction.InList(DBPropsSession.Behave, new string[] {"DC","AR","IR","GT","SS"}) == true))
            {
                //SqlStr = "select Head_nm,Fld_nm,Pert_name,Fld_excbal,Fld_manu,Fld_bill " +
                //         " from Dcmast where code = 'E' And Entry_Ty='AR' order by corder";

                //DataTable tmptbl_vw = DataAcess.ExecuteDataTable(SqlStr, "_qq");
                DBPropsSession.Tex_exe = 0;
                if (TexExe.Rows.Count > 0)
                {
                    string[,] TexArr = new string[TexExe.Rows.Count, 8];
                    foreach (DataRow TexExeRow in TexExe.Rows)
                    {
                        TexArr[DBPropsSession.Tex_exe, 0] = Convert.ToString(TexExeRow["head_nm"]).Trim();
                        TexArr[DBPropsSession.Tex_exe, 1] = Convert.ToString(TexExeRow["fld_nm"]).Trim().ToUpper();
                        TexArr[DBPropsSession.Tex_exe, 2] = Convert.ToString(TexExeRow["fld_excbal"]).Trim().ToUpper();
                        TexArr[DBPropsSession.Tex_exe, 3] = Convert.ToString(TexExeRow["fld_manu"]).Trim().ToUpper();
                        TexArr[DBPropsSession.Tex_exe, 4] = Convert.ToString(TexExeRow["fld_bill"]).Trim().ToUpper();
                        TexArr[DBPropsSession.Tex_exe, 5] = Convert.ToString(TexExeRow["pert_name"]).Trim().ToUpper();
                        TexArr[DBPropsSession.Tex_exe, 6] = Convert.ToString(TexExeRow["fld_duty"]).Trim().ToUpper();
                        TexArr[DBPropsSession.Tex_exe, 7] = Convert.ToString(TexExeRow["fld_mduty"]).Trim().ToUpper();

                        DBPropsSession.Tex_exe = DBPropsSession.Tex_exe + 1;
                    }

                    SessionProxy.Tex_ExAr = TexArr;  
                }
                TexExe.Dispose();  
            }

            bool AssessFieldFlag = false;
            bool SaleTaxFlag = false;
            if (DBPropsSession.IchargesPage == true)
            {

                if (item_vw.Columns.Contains("u_asseamt") == true)
                    AssessFieldFlag = true;


                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "II", "IR", "OP", "IP", "WI", "WO", "ES", "SS" }) == false ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "II", "IR", "OP", "IP", "WI", "WO", "ES", "SS" }) == false)
                {
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[5] { "ST", "SR", "SO", "SQ", "DC" }) ||
                         strFunction.InList(DBPropsSession.Behave, new string[5] { "ST", "SR", "SO", "SQ", "DC" }))
                         &&
                         System.Convert.ToBoolean(company.Rows[0]["sittax_op"]) == true)
                    {
                        SaleTaxFlag = true;
                    }

                    if ((strFunction.InList(DBPropsSession.PcvType, new string[5] { "PT", "PR", "PO", "EP", "AR" }) ||
                         strFunction.InList(DBPropsSession.Behave, new string[5] { "PT", "PR", "PO", "EP", "AR" }))
                         &&
                         System.Convert.ToBoolean(company.Rows[0]["pittax_op"]) == true)
                    {
                        SaleTaxFlag = true;
                    }

                }

                SqlStr = "Select code,corder,fld_nm,head_nm,disp_pert," +
                         "pert_name,disp_sign,bef_aft,att_file,postbackevent,javascript,javaevent From dcmast where Entry_ty = '" + DBPropsSession.PcvType.ToString().Trim() +
                         "' order by (case when bef_aft = 1 then 'A' else 'B' end ) +" +
                         "(case when code = 'D' " +
                         "   then 'A'" +
                         "else" +
                         "  case when code = 'T'" +
                         "       then 'B'" +
                         "  else" +
                         "      case when code = 'E'" +
                         "          then 'C'" +
                         "		else" +
                         "          case when code = 'A'" +
                         "              then 'D'" +
                         "          else" +
                         "              case when code = 'N'" +
                         "                then 'E'" +
                         "              else" +
                         "                  'F'" +
                         "              end" +
                         "           end" +
                         "     end" +
                         "   end" +
                         " end + corder)";

                DataTable tmptbl_vw = DataAcess.ExecuteDataTable(SqlStr, "_qq",connHandle);
                DataAcess.Connclose(connHandle);  

                foreach (DataRow tmpRow in tmptbl_vw.Rows)
                {
                    if (bitFunction.toBoolean(tmpRow["att_file"]) == true)
                    {
                        continue;
                    }

                    if (AssessFieldFlag == true &&
                        Convert.ToInt32(tmpRow["bef_aft"]) != 1)
                    {
                        AssessFieldFlag = false;
                        colSerial = colSerial + 1;

                        insertRow(lotherview, DBPropsSession.PcvType, "u_asseamt", "Ass. Value",
                                  colSerial, 50, 2, "", "", "DECIMAL", false, true, 999, "ASS. VALUE", "", true, false, "", "onfocusout", "javascript:AssesableLostFocus();");

                    }

                    if (SaleTaxFlag == true && Convert.ToString(tmpRow["code"]) == "N")
                    {
                        SaleTaxFlag = false;
                        getSerial = findSerial(lotherview, colSerial, "serial = 6 and ingrid = 1 and inter_use = 0");
                        colSerial = (getSerial != 0 ? getSerial : colSerial + 1);

                        insertRow(lotherview, DBPropsSession.PcvType, "tax_name", "Tax Name",
                                  colSerial, 50, 0, "", "", "VARCHAR", false, true, 999, "S#SX#TAX NAME", "",true, false, "", "", "");

                        colSerial = colSerial + 1;
                        insertRow(lotherview, DBPropsSession.PcvType, "taxamt", "Tax Amount",
                                  colSerial, 50, 0, "", "", "DECIMAL", false, true, 999, "V#SX#TAX NAME", "",true, false, "", "", "");
                        SalesTaxItem = true; // Itemwise Sale Tax Class Properties
                    }

                    getSerial = findSerial(lotherview, colSerial, "serial = 6 and ingrid = 1 and inter_use = 0");
                    colSerial = (getSerial != 0 ? getSerial : colSerial + 1);
                    if (bitFunction.toBoolean(tmpRow["disp_pert"]) == true)
                    {
                        switch (System.Convert.ToString(tmpRow["disp_sign"]).Trim())
                        {
                            case "@":
                                insertRow(lotherview, DBPropsSession.PcvType, Convert.ToString(tmpRow["pert_name"]), "@",
                                          colSerial, 50, 0, "", "", "DECIMAL", false, true, 999, "@#" + Convert.ToString(tmpRow["CODE"]) + "#" + Convert.ToString(tmpRow["head_nm"]).Trim().ToUpper(), "", false, false, Convert.ToString(tmpRow["postbackevent"]), Convert.ToString(tmpRow["javaevent"]), Convert.ToString(tmpRow["javascript"]));
                                break;
                            case "%":
                                insertRow(lotherview, DBPropsSession.PcvType, Convert.ToString(tmpRow["pert_name"]), "%",
                                          colSerial, 50, 0, "", "", "DECIMAL", false, true, 999, "%#" + Convert.ToString(tmpRow["CODE"]) + "#" + Convert.ToString(tmpRow["head_nm"]).Trim().ToUpper(), "",false, false, Convert.ToString(tmpRow["postbackevent"]),Convert.ToString(tmpRow["javaevent"]), Convert.ToString(tmpRow["javascript"]));
                                break;
                            default:
                                insertRow(lotherview, DBPropsSession.PcvType, Convert.ToString(tmpRow["pert_name"]), "%",
                                          colSerial, 50, 0, "", "", "DECIMAL", false, true, 999, "*#" + Convert.ToString(tmpRow["CODE"]) + "#" + Convert.ToString(tmpRow["head_nm"]).Trim().ToUpper(), "",false, false, Convert.ToString(tmpRow["postbackevent"]),Convert.ToString(tmpRow["javaevent"]), Convert.ToString(tmpRow["javascript"]));
                                break;
                        }
                    }

                    insertRow(lotherview, DBPropsSession.PcvType, Convert.ToString(tmpRow["fld_nm"]), Convert.ToString(tmpRow["head_nm"]),
                              colSerial,50, 0, "", "", "DECIMAL", false, true, 999, "V#" + Convert.ToString(tmpRow["CODE"]) + "#" + Convert.ToString(tmpRow["head_nm"]).Trim().ToUpper(), "", false,false,Convert.ToString(tmpRow["postbackevent"]),Convert.ToString(tmpRow["javaevent"]), Convert.ToString(tmpRow["javascript"]));

                    //break;

                }

                if (AssessFieldFlag == true)
                {
                    AssessFieldFlag = false;
                    colSerial = colSerial + 1;

                    insertRow(lotherview, DBPropsSession.PcvType, "u_asseamt", "Ass. Value",
                              colSerial, 50, 0, "", "", "DECIMAL", false, true, 999, "ASS. VALUE", "", true, false, "", "onfocusout", "javascript:AssesableLostFocus();");

                }
                if (SaleTaxFlag == true)
                {
                    SaleTaxFlag = false;
                    getSerial = findSerial(lotherview, colSerial, "serial = 7 and ingrid = 1 and inter_use = 0");
                    colSerial = (getSerial != 0 ? getSerial : colSerial + 1);

                    insertRow(lotherview, DBPropsSession.PcvType, "tax_name", "Tax Name",
                              colSerial, 150, 0, "", "", "DROPDOWNLIST", false, true, 999, "S#SX#TAX NAME", "",true, false, "", "", "");

                    insertRow(lotherview, DBPropsSession.PcvType, "taxamt", "Tax Amount",
                              colSerial, 50, 0, "", "", "DECIMAL", false, true, 999, "V#SX#TAX NAME", "", true,false, "", "", "");
                     
                }
            }

            getSerial = findSerial(lotherview, colSerial, "serial = 8 and ingrid = 1 and inter_use = 0");
            colSerial = (getSerial != 0 ? getSerial : colSerial + 1);

            insertRow(lotherview, DBPropsSession.PcvType, "gro_amt", "Amount",
                      colSerial, 50, 0, "", ".f.", "DECIMAL", false, true, 999, "GROSS AMOUNT", "",true, false, "", "", "");

       
            lotherview.Sort = "serial ASC,dserial DESC";
            return lotherview;
 
        }

        public void grdItemSettingforET(string Rule,
                DataView lotherview,
                string oldRowFilter)
        {
            stringFunction strFunction = new stringFunction();
           if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
           (strFunction.InList(Rule.Trim(), new string[] { "EXCISE", "NON-EXCISE" }) == true))
            {
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true)
                {
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS" }) == true)
                    {
                        lotherview.RowFilter = "fld_nm = 'Qty' and dserial = 999";
                        foreach (DataRowView drv in lotherview)
                        {
                            drv["whn_con"] = ".f.";
                        }
                        lotherview.RowFilter = "";
                    }

                    lotherview.RowFilter = "substring(tag,2,2) = '#E'";

                    foreach (DataRowView drv in lotherview)
                    {
                        drv["whn_con"] = ".f.";
                    }

                    lotherview.RowFilter = oldRowFilter.Trim(); 

                }
            }
        }
        protected int findSerial(DataView lotherview,int colSerial, string filtCond)
        {
            string PrevFilterCondition = lotherview.RowFilter; 
            lotherview.RowFilter = filtCond;
            if (lotherview.Count > 0)
                colSerial = colSerial + 1;
            else
                colSerial = 0;

            lotherview.RowFilter = PrevFilterCondition;  
            return colSerial;
        }

        protected void insertRow(DataView lotherview,
                 string pcvtype,
                 string fldname,
                 string headName,
                 int serial,
                 int fldWid,
                 int flddec,
                 string defaVal,
                 string whncon,
                 string dataType,
                 bool attFile,
                 bool ingrid,
                 int dSerial,
                 string tag,
                 string filtcond,
                 bool mandatory,
                 bool isAutoPostBack,
                 string postBackEvent,
                 string javaEvent,
                 string javaScript)
        {
            DataRowView LotherViewRow = lotherview.AddNew();
            LotherViewRow["e_code"] = pcvtype;
            LotherViewRow["fld_nm"] = fldname.Trim().ToLower();
            LotherViewRow["head_nm"] = headName;
            LotherViewRow["serial"] = serial;
            LotherViewRow["fld_wid"] = fldWid;
            LotherViewRow["fld_dec"] = flddec;
            LotherViewRow["defa_val"] = defaVal;
            LotherViewRow["whn_con"] = whncon;
            LotherViewRow["data_ty"] = dataType;
            LotherViewRow["att_file"] = attFile;
            LotherViewRow["ingrid"] = ingrid;
            LotherViewRow["dSerial"] = dSerial;
            LotherViewRow["Tag"] = tag;
            LotherViewRow["filtcond"] = filtcond;
            LotherViewRow["att_file"] = false;
            LotherViewRow["Ingrid"] = true;
            LotherViewRow["inter_use"] = false;
            LotherViewRow["mandatory"] = mandatory;
            LotherViewRow["IsPostBack"] = isAutoPostBack;
            LotherViewRow["PostBackEvent"] = postBackEvent;
            LotherViewRow["JavaScript"] = javaScript;
            LotherViewRow["JavaEvent"] = javaEvent;
            LotherViewRow.EndEdit();  
        }


        public GridView gridItemGen(GridView grdItem,
                                    DataView grdItemColView,
                                    DataTable item_vw)
        {
            grdItem.Columns.Clear();

            stringFunction strFunction = new stringFunction();
            TemplateField templateField = new TemplateField();
            DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            CheckBox chkBoxSel = new CheckBox();
            chkBoxSel.ID = "chkSelect";
            dynamictemplateItem.AddControl(chkBoxSel, "", "");
            templateField.ItemTemplate = dynamictemplateItem;
            grdItem.Columns.Add(templateField);
            grdItem.Columns[0].HeaderText = " Select ";


            BoundField bndField;
            int cnt = 1;
            int arrCnt = 1;
            string[] grdCols = new string[grdItemColView.Count];
            grdCols[0] = "00";
            //grdCols[1] = "01";
            foreach (DataRowView drv in grdItemColView)
            {
                if (Convert.ToString(drv["data_ty"]).Trim().ToUpper() == "BIT")
                {
                    templateField = new TemplateField();
                    dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
                    GraphicalCheckBox chkBox = new GraphicalCheckBox();
                    chkBox.ID = "chk" + Convert.ToString(drv["fld_nm"]).Trim();
                    chkBox.CheckedImg = "checked.png";
                    chkBox.CheckedOverImg = "checked-over.png";
                    chkBox.CheckedDisImg = "checked.png";
                    chkBox.UncheckedDisImg = "unchecked.png";
                    chkBox.UncheckedImg = "unchecked.png";
                    chkBox.UncheckedOverImg = "unchecked-over.png";
                    chkBox.Style.Value = "z-index: 100";
                    chkBox.Enabled = false;
                    dynamictemplateItem.AddControl(chkBox, "Checked", Convert.ToString(drv["fld_nm"]).Trim());
                    templateField.ItemTemplate = dynamictemplateItem;
                    grdItem.Columns.Add(templateField);
                    grdItem.Columns[cnt].HeaderText = Convert.ToString(drv["head_nm"]);
                    grdItem.Columns[cnt].AccessibleHeaderText = Convert.ToString(drv["tag"]) + "|GRAPHICALCHECKBOX";
                    grdCols[arrCnt] = cnt.ToString();  
                    cnt = cnt + 1;

                }
                else
                {
                    if (strFunction.InList(Convert.ToString(drv["data_ty"]).Trim().ToUpper(),new string[] {"BUTTON","LINKBUTTON"}) == false)
                    {
                        bndField = new BoundField();
                        bndField.DataField = Convert.ToString(drv["fld_nm"]).Trim();
                        bndField.HeaderText = Convert.ToString(drv["head_nm"]).Trim();
                        bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                        bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;

                        // Set Column formatting according data type
                        switch (Convert.ToString(drv["data_ty"]).Trim().ToUpper())
                        {
                            case "DECIMAL":
                                bndField.DataFormatString = "{0:F2}";
                                break;
                            case "DATETIME":
                                bndField.DataFormatString = "{0:dd/M/yyyy}";
                                break;
                        }
                        grdItem.Columns.Add(bndField);
                        // Set Column Item Style alignment according data type
                        switch (Convert.ToString(drv["data_ty"]).Trim().ToUpper())
                        {
                            case "DECIMAL":
                                grdItem.Columns[cnt].ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                                break;
                            case "NUMERIC":
                            case "INT":
                                grdItem.Columns[cnt].ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                                break;
                            case "VARCHAR":
                            case "TEXT":
                                grdItem.Columns[cnt].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                                break;
                            case "DATETIME":
                                grdItem.Columns[cnt].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                                break;
                            default:
                                grdItem.Columns[cnt].ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                                break;
                        }

                        grdItem.Columns[cnt].AccessibleHeaderText = Convert.ToString(drv["tag"]);
                        //grdItem.Columns[cnt].HeaderStyle.Width  = Unit.Pixel(Convert.ToInt32(drv["fld_wid"]));
                        grdItem.Columns[cnt].ItemStyle.Width = Unit.Pixel(Convert.ToInt32(drv["fld_wid"]));

                        cnt = cnt + 1;
                    }
                    else
                    {
                        grdCols[arrCnt] = cnt.ToString();
                    }
                }
                
            }
            grdItem.DataSource = item_vw; 
            if (item_vw.Rows.Count > 0)
                gridBind(grdItem, null);
            else
                gridBind(grdItem, grdCols);

            return grdItem;

        }


        // Below griditemfill method is not in used
        public GridView gridItemFill(bool ItemPage,
                                     DataTable lother_vw,
                                     GridView grdItem,
                                     DataTable item_vw,
                                     bool ItemChargeDisplay,
                                     DataTable dcmast_vw,
                                     DataTable Company,
                                     DataTable lcode_vw,
                                     string pcvType,
                                     string beHave,
                                     int mainvw_acid)
        {
            getGridColumn _getGridColumn = new getGridColumn();
            BoundField bndField;
            //CommandField cmdField;
            stringFunction strFunction = new stringFunction();  // String Function 

            TemplateField templateField1 = new TemplateField();
            DynamicTemplate dynamictemplateItem1 = new DynamicTemplate(ListItemType.Item);
            DynamicTemplate dynamictemplateEdit1 = new DynamicTemplate(ListItemType.EditItem);

            Button edit_button = new Button();
            edit_button.ID = "edit_button";
            //edit_button.ImageUrl = "~/images/edit.gif";
            edit_button.CommandName = "Edit";
            edit_button.ToolTip = "Edit";
            dynamictemplateItem1.AddControl(edit_button, "","");  

            templateField1.ItemTemplate = dynamictemplateItem1;
            grdItem.Columns.Add(templateField1);

            // Item Serial No.
            bndField = new BoundField();
            bndField = _getGridColumn.grdBoundField(bndField, "item_no", "Item No.");
            grdItem.Columns.Add(bndField);
            grdItem.Columns[0].AccessibleHeaderText = "Item No.";
            grdItem.Columns[0].ItemStyle.HorizontalAlign = HorizontalAlign.Center;
            grdItem.Columns[0].ItemStyle.Width = 10;
  
            // Item Name
            bndField = new BoundField();
            bndField = _getGridColumn.grdBoundField(bndField, "item", "Item Name");
            bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
            bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Left;
            grdItem.Columns.Add(bndField);
            grdItem.Columns[1].AccessibleHeaderText = "Item Name";

            // Qty
            bndField = new BoundField();
            bndField = _getGridColumn.grdBoundField(bndField, "qty", "Unit");
            grdItem.Columns.Add(bndField);
            grdItem.Columns[2].AccessibleHeaderText = "Unit";  

            // Rate
            bndField = new BoundField();
            bndField = _getGridColumn.grdBoundField(bndField, "rate", "Rate");
            grdItem.Columns.Add(bndField);
            grdItem.Columns[3].AccessibleHeaderText = "Rate";  


            # region Extra data columns add in Item grid
            foreach (DataRow row in lother_vw.Rows) 
            {
                if (System.Convert.ToBoolean(row["att_file"]) == false &&
                    System.Convert.ToBoolean(row["ingrid"]) == true)
                {
                    switch (System.Convert.ToString(row["data_ty"]).ToUpper().Trim())
                    {
                        case "C":
                            TemplateField templateField = new TemplateField();
                            DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
                            DynamicTemplate dynamictemplateEdit = new DynamicTemplate(ListItemType.EditItem);

                            Label labl = new Label();
                            labl.ID = "lbl" +System.Convert.ToString(row["fld_nm"]).Trim();
                            labl.Visible = true;
                            dynamictemplateItem.AddControl(labl,"Text",System.Convert.ToString(row["fld_nm"]).Trim());
                            templateField.ItemTemplate = dynamictemplateItem;

                            TextBox txtBox = new TextBox();
                            txtBox.ID = "txt" + System.Convert.ToString(row["fld_nm"]).Trim();
                            txtBox.Visible = true;
                            dynamictemplateEdit.AddControl(txtBox, "Text", System.Convert.ToString(row["fld_nm"]).Trim());
                            templateField.EditItemTemplate = dynamictemplateEdit;
                            templateField.HeaderText = System.Convert.ToString(row["head_nm"]).Trim();

                            grdItem.Columns.Add(templateField);    
                            break;
                     }
                }
            }
            #endregion

            #region Discount & Charges Columns add in Item Grid
            bool AssessFieldFlag,SaleTaxFlag = false;
            if (ItemChargeDisplay == true)
            {
                try
                {
                    string RW = "";
                    RW = item_vw.Columns["u_asseamt"].ToString();
                    AssessFieldFlag = true;
                }
                catch
                {
                    AssessFieldFlag = false; 
                }

                pcvType = pcvType.ToString().Trim();
                beHave = beHave.ToString().Trim(); 

                if ((strFunction.InList(pcvType,new string[5]{"ST","SR","SO","SQ","DC"}) ||
                    strFunction.InList(beHave,new string[5]{"ST","SR","SO","SQ","DC"}))
                    &&
                    System.Convert.ToBoolean(Company.Rows[0]["sittax_op"]) == true)
                {
                    SaleTaxFlag = true;
                }

                if ((strFunction.InList(pcvType,new string[5]{"PT","PR","PO","EP","AR"}) ||
                    strFunction.InList(beHave,new string[5]{"PT","PR","PO","EP","AR"}))
                    &&
                    System.Convert.ToBoolean(Company.Rows[0]["pittax_op"]) == true)
                {
                    SaleTaxFlag = true;
                }

                DataTier _datatier = new DataTier();
                _datatier.DataBaseName = SessionProxy.DbName;
   
                string SqlStr = "";
                SqlStr = "Select code,corder,fld_nm,head_nm,disp_pert," +
                         "pert_name,disp_sign,bef_aft,att_file From dcmast where Entry_ty = '" + pcvType.ToString().Trim() +
                         "' order by (case when bef_aft = 1 then 'A' else 'B' end ) +" +
                         "(case when code = 'D' " +
                         "   then 'A'" +
                         "else" +
                         "  case when code = 'T'" +
                         "       then 'B'" +
                         "  else" +
                         "      case when code = 'E'" +
                         "          then 'C'" +
                         "		else" +
                         "          case when code = 'A'" +
                         "              then 'D'" +
                         "          else" +
                         "              case when code = 'N'" +
                         "                then 'E'" +
                         "              else" +
                         "                  'F'" +
                         "              end" +
                         "           end" +
                         "     end" +
                         "   end" +
                         " end + corder)";

                DataSet DsTmp = new DataSet();
                DsTmp = _datatier.ExecuteDataset(SqlStr, "tmptbl_vw",connHandle);
                _datatier.Connclose(connHandle);
                foreach (DataRow Row in DsTmp.Tables["tmptbl_vw"].Rows)
                {
                    if (System.Convert.ToBoolean(Row["att_file"]) == false)
                    {
                        if (AssessFieldFlag == true && System.Convert.ToInt32(Row["bef_aft"]) != 1)
                        {
                            AssessFieldFlag = false;
                            bndField = new BoundField();
                            bndField = _getGridColumn.grdBoundField(bndField, "u_asseamt", "Ass. Value");
                            grdItem.Columns.Add(bndField);
                            grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "ASS. VALUE";
                        }

                        if (SaleTaxFlag == true && System.Convert.ToString(Row["code"]) == "N")
                        {
                            SaleTaxFlag = false;
                            TemplateField templateField = new TemplateField();
                            DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
                            DynamicTemplate dynamictemplateEdit = new DynamicTemplate(ListItemType.EditItem);

                            Label labl = new Label();
                            labl.ID = "lbltaxName";
                            labl.Visible = true;
                            dynamictemplateItem.AddControl(labl, "Text", "tax_name");
                            templateField.ItemTemplate = dynamictemplateItem;

                            DropDownList dropdown = new DropDownList();
                            dropdown.ID = "droptaxName"; 
                            dropdown.DataSource = (SaleTaxNameList(pcvType.ToString().Trim(), mainvw_acid.ToString())).Tables["LstTbl"];
                            dropdown.DataTextField = "tax_name";
                            dropdown.DataValueField = "tax_name";
                            dropdown.Visible = true;
                            dynamictemplateEdit.AddControl(dropdown, "SelectedValue", "tax_name");
                            templateField.EditItemTemplate  = dynamictemplateEdit;
                            templateField.HeaderText = "Tax Name"; 
                            grdItem.Columns.Add(templateField);
                            grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "S#SX#TAX NAME";

                            bndField = new BoundField();
                            bndField = _getGridColumn.grdBoundField(bndField, "taxamt", "Tax Amount");
                            bndField.HeaderText = "Tax Amount"; 
                            grdItem.Columns.Add(bndField);
                            grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "V#SX#TAX NAME";
                            SalesTaxItem = true; // Itemwise Sale Tax
                        }

                        // Add Discount Percentage column
                        if (System.Convert.ToBoolean(Row["disp_pert"]) == true)
                        {
                            if (System.Convert.ToString(Row["disp_sign"]).Trim() != null)
                            {
                                switch (System.Convert.ToString(Row["disp_sign"]).Trim())
                                {
                                    case "@":
                                        bndField = new BoundField();
                                        bndField = _getGridColumn.grdBoundField(bndField, System.Convert.ToString(Row["pert_name"]).Trim(), System.Convert.ToString(Row["disp_sign"]).Trim());
                                        bndField.HeaderText = "@"; 
                                        grdItem.Columns.Add(bndField);
                                        grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "@#" +
                                                                         System.Convert.ToString(Row["Code"]).Trim() + "#" +
                                                                         System.Convert.ToString(Row["Head_NM"]).ToUpper().Trim(); 
                                        break; 
                                    case "%" :
                                        bndField = new BoundField();
                                        bndField = _getGridColumn.grdBoundField(bndField, System.Convert.ToString(Row["pert_name"]).Trim(), System.Convert.ToString(Row["disp_sign"]).Trim());
                                        bndField.HeaderText = "@";
                                        grdItem.Columns.Add(bndField);
                                        grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "%#" +
                                                                         System.Convert.ToString(Row["Code"]).Trim() + "#" +
                                                                         System.Convert.ToString(Row["Head_NM"]).ToUpper().Trim();
                                        break; 
                                    default :
                                        bndField = new BoundField();
                                        bndField = _getGridColumn.grdBoundField(bndField, System.Convert.ToString(Row["pert_name"]).Trim(), System.Convert.ToString(Row["disp_sign"]).Trim());
                                        bndField.HeaderText = "%";
                                        grdItem.Columns.Add(bndField);
                                        grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "*#" +
                                                                         System.Convert.ToString(Row["Code"]).Trim() + "#" +
                                                                         System.Convert.ToString(Row["Head_NM"]).ToUpper().Trim();
                                        break; 

                                }
                            }
                          
                        }

                        bndField = new BoundField();
                        bndField = _getGridColumn.grdBoundField(bndField, System.Convert.ToString(Row["fld_nm"]).Trim(), System.Convert.ToString(Row["head_nm"]).Trim());
                        grdItem.Columns.Add(bndField);
                        grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "V#" +
                                                                     System.Convert.ToString(Row["Code"]).Trim() + "#" +
                                                                     System.Convert.ToString(Row["Head_NM"]).ToUpper().Trim();
                            
                    }
                }

                if (AssessFieldFlag == true)
                {
                    AssessFieldFlag = false;
                    bndField = new BoundField();
                    bndField = _getGridColumn.grdBoundField(bndField, "u_asseamt", "Ass. Value");
                    grdItem.Columns.Add(bndField);
                    grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "ASS. VALUE";

                }

                if (SaleTaxFlag == true)
                {
                    SaleTaxFlag = false;
                    TemplateField templateField = new TemplateField();
                    DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
                    DynamicTemplate dynamictemplateEdit = new DynamicTemplate(ListItemType.EditItem);

                    Label labl = new Label();
                    labl.ID = "lbltaxName";
                    labl.Visible = true;
                    dynamictemplateItem.AddControl(labl, "Text", "tax_name");
                    templateField.ItemTemplate = dynamictemplateItem;
                    
                    DropDownList dropdown = new DropDownList();
                    dropdown.ID = "droptaxName";
                    dropdown.DataSource = (SaleTaxNameList(pcvType.ToString().Trim(), mainvw_acid.ToString())).Tables["LstTbl"];
                    dropdown.DataTextField = "tax_name";
                    dropdown.DataValueField = "tax_name";
                    dropdown.Visible = true;
                    //dropdown.AppendDataBoundItems = true;
                    dynamictemplateEdit.AddControl(dropdown, "SelectedValue", "tax_name");
                    templateField.EditItemTemplate = dynamictemplateEdit;
                    templateField.HeaderText = "Tax Name";
                    grdItem.Columns.Add(templateField);
                    grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "S#SX#TAX NAME";                    

                    bndField = new BoundField();
                    bndField = _getGridColumn.grdBoundField(bndField, "taxamt", "Tax Amount");
                    bndField.HeaderText = "Tax Amount"; 
                    grdItem.Columns.Add(bndField);
                    grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "V#SX#TAX NAME";                    
                }
            }

            // Add Gross Amount
            bndField = new BoundField();
            bndField = _getGridColumn.grdBoundField(bndField, "gro_amt", "Amount");
            grdItem.Columns.Add(bndField);
            grdItem.Columns[grdItem.Columns.Count - 1].AccessibleHeaderText = "GROSS AMOUNT";


            //TemplateField templateFieldDel = new TemplateField();
            //DynamicTemplate dynamictemplateItemDel = new DynamicTemplate(ListItemType.Item);
            //Button btnDel = new Button();
            //btnDel.ID = "btnDel";
            //btnDel.CommandName = "DELETE";
            //dynamictemplateItemDel.AddControl(btnDel, "", "");
            //templateFieldDel.ItemTemplate = dynamictemplateItemDel;
            //grdItem.Columns.Add(templateFieldDel);


            if (item_vw.Rows.Count > 0)
            {
                grdItem.DataSource = item_vw;
                grdItem.DataBind();
            }
            else
            {
                DataTable tmpTb = item_vw.Clone();
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                grdItem.Columns[grdItem.Columns.Count-1].Visible = false;
                grdItem.DataSource = tmpTb;
                grdItem.DataBind();
            }

            #endregion
  
            return grdItem; 
        }

        public DataSet SaleTaxNameList(string pcvType,string mainvw_ac_id)
        {
            DataTier _datatier = new DataTier();
            _datatier.DataBaseName = SessionProxy.DbName;
   
            SqlDataReader Dr;
            DataSet DS = new DataSet();
            stringFunction strFunction = new stringFunction();  // String Function 

            string SqlStr = "select top 1 st_type from ac_mast where ac_id = " + mainvw_ac_id.ToString();
            string SaleTaxType = "";
            string AccPostingFld = "";

            Dr = _datatier.ExecuteDataReader(SqlStr,ref connHandle);
            if (Dr.HasRows == true)
            {
                SaleTaxType = Dr["st_type"].ToString().Trim();
            }
            Dr.Close();
            Dr.Dispose();
            _datatier.Connclose(connHandle);

            AccPostingFld = "Ac_name1";
            if (strFunction.Left(pcvType.ToString().Trim(), 1) == "P")
            {
                AccPostingFld = "Ac_name3";
            }

            if (SaleTaxType.ToString().Trim() != "")
            {
                SqlStr = "select tax_name from stax_mas where st_type = '" + SaleTaxType.ToString().Trim() + "'" +
                         " and rtrim(ltrim(upper(" + AccPostingFld.ToString().Trim() + "))) != ''" +
                         " order by tax_name ";
            }
            else
            {
                SqlStr = "select tax_name from stax_mas where " +
                         " rtrim(ltrim(upper(" + AccPostingFld.ToString().Trim() + "))) != ''" +
                         " order by tax_name ";
            }

            DS = _datatier.ExecuteDataset(SqlStr, "LstTbl",connHandle);
            _datatier.Connclose(connHandle);
            DataRow Dtrow;
            Dtrow = DS.Tables["LstTbl"].NewRow(); 
            Dtrow["tax_name"] = "No Tax";
            DS.Tables["LstTbl"].Rows.Add(Dtrow);

            return DS;

        }

        public GridView gridAcccountFill(GridView grdAccount,DataTable acdet_vw, DataTable lcode_vw)
        {
            //if (System.Convert.ToBoolean(lcode_vw.Rows[0]["a_narr"]) == true)
            //{
            //    grdAccount.Columns[3].Visible = true;
            //}
            //else
            //{
            //    grdAccount.Columns[3].Visible = false;
            //}
            boolFunction bitFunction = new boolFunction();
            if (acdet_vw.Rows.Count > 0)
            {
                grdAccount.DataSource = acdet_vw;
            }
            else
            {
                DataTable tmpTb = acdet_vw.Clone();
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                //grdAccount.Columns[4].Visible = false;    
                grdAccount.DataSource =tmpTb;

            }
            string[] grdCols = new string[5];
            if (acdet_vw.Rows.Count > 0)
                grdCols = grdAccountColSHide(lcode_vw);
            else
                grdCols[0] = "00";
                grdCols[1] = "01";
                grdCols[2] = "06";
                grdCols[3] = "07";
                grdCols[4] = "08";

            gridBind(grdAccount, grdCols);
            return grdAccount;

        }

        public string[] grdAccountColSHide(DataTable lcode_vw)
        {
            boolFunction bitFunction = new boolFunction();
            string[] grdCols = new string[5];
            if (bitFunction.toBoolean(lcode_vw.Rows[0]["a_narr"]) == true &&
                bitFunction.toBoolean(lcode_vw.Rows[0]["l_dbcr"]) == false)
            {
                grdCols[0] = "0";
                grdCols[1] = "06";
                grdCols[2] = "07";
                grdCols[3] = "08";
            }
            else
            {
                if (bitFunction.toBoolean(lcode_vw.Rows[0]["a_narr"]) == false &&
                    bitFunction.toBoolean(lcode_vw.Rows[0]["l_dbcr"]) == true)
                {
                    grdCols[0] = "05";
                    grdCols[1] = "06";
                    grdCols[2] = "07";
                    grdCols[3] = "08";

                }
                else
                {
                    if (bitFunction.toBoolean(lcode_vw.Rows[0]["a_narr"]) == true &&
                        bitFunction.toBoolean(lcode_vw.Rows[0]["l_dbcr"]) == true)
                    {
                        grdCols[0] = "06";
                        grdCols[1] = "07";
                        grdCols[2] = "08";
                    }
                    else
                    {
                        if (bitFunction.toBoolean(lcode_vw.Rows[0]["a_narr"]) == false &&
                            bitFunction.toBoolean(lcode_vw.Rows[0]["l_dbcr"]) == false)
                        {
                            grdCols[0] = "00";
                            grdCols[0] = "05";
                            grdCols[1] = "06";
                            grdCols[2] = "07";
                            grdCols[3] = "08";
                        }
                    }
                }
            }

            return grdCols;
        }

        public GridView gridTaxFill(GridView grdTax, 
                            DataTable dcmast_vw, 
                            DataTable lcode_vw, 
                            DataTable tax_vw, 
                            DataTable tax_vw1, 
                            DataTable main_vw, 
                            DataTable item_vw, 
                            DataTable company, 
                            DataTable stax_vw, 
                            bool EditMode, 
                            bool AddMode, 
                            string pcvType, 
                            string beHave)
        {
            if (AddMode == true || EditMode == true)
            {
                DataRow GatherRow;
                string mTbl = "";
                foreach (DataRow ScatterRow in dcmast_vw.Select("(Att_file = 1 or (Att_file = 0 AND CODE = 'E')) AND not code In('X')"))
                {
                    if (System.Convert.ToBoolean(ScatterRow["att_file"]) == true)
                    {
                        mTbl = "main_vw";
                    }
                    else
                    {
                        if (System.Convert.ToBoolean(lcode_vw.Rows[0]["i_disc"]) == true)
                        {
                            mTbl = "item_vw";
                        }
                        else
                        {
                            mTbl = "";
                        }
                    }

                    if (mTbl != "") // not empty tableName
                    {

                        // Pert Name
                        if (System.Convert.ToString(ScatterRow["pert_name"]).Trim() != "" && EditMode == true)
                        {
                            if (mTbl.ToString().ToUpper().Trim() == "MAIN_VW")
                            {
                                string maincol = ScatterRow["pert_name"].ToString().Trim();
                                ScatterRow["def_pert"] = main_vw.Rows[0][maincol];
                            }
                            else
                            {
                                string itemcol = ScatterRow["pert_name"].ToString().Trim();
                                ScatterRow["def_pert"] = item_vw.Rows[0][itemcol];
                            }

                            dcmast_vw.AcceptChanges();  
                        }

                        // Field Amount
                        if (EditMode == true)
                        {
                            if (mTbl.ToString().ToUpper().Trim() == "MAIN_VW")
                            {
                                string maincol = ScatterRow["fld_nm"].ToString().Trim();
                                ScatterRow["def_amt"] = main_vw.Rows[0][maincol];
                            }
                            else
                            {
                                string itemcol = ScatterRow["fld_nm"].ToString().Trim();
                                ScatterRow["def_amt"] = item_vw.Rows[0][itemcol];
                            }

                            dcmast_vw.AcceptChanges();  
                        }

                        // Exclude Net 
                        if (System.Convert.ToBoolean(ScatterRow["att_file"]) == false && System.Convert.ToString(ScatterRow["code"]) == "E")
                        {
                            ScatterRow["excl_net"] = "E";
                        }

                        if (AddMode == true)
                        {
                            string itemcol = ScatterRow["pert_name"].ToString().Trim();
                            if (main_vw.Columns.Contains(itemcol) == true)
                            {
                                main_vw.Rows[0][itemcol] = System.Convert.ToUInt32(ScatterRow["def_pert"]);
                            }
                            itemcol = ScatterRow["fld_nm"].ToString().Trim();
                            main_vw.Rows[0][itemcol] = System.Convert.ToUInt32(ScatterRow["def_amt"]);
                            main_vw.AcceptChanges();
                        }

                        GatherRow = tax_vw.NewRow();
                        for (int i = 0; i < dcmast_vw.Columns.Count; i++)
                        {
                            GatherRow[i] = ScatterRow[i];
                        }
                        tax_vw.Rows.Add(GatherRow);
                        tax_vw.AcceptChanges();
                    }
                }

                stringFunction strFunction = new stringFunction();  // String Function 
                bool companyStax = false;
                if (strFunction.InList(pcvType, new string[5] { "ST", "SR", "SO", "SQ", "DC" }) == true ||
                    strFunction.InList(beHave, new string[5] { "ST", "SR", "SO", "SQ", "DC" }) == true)
                {
                    companyStax = System.Convert.ToBoolean(company.Rows[0]["sStax_op"]);
                }
                else
                {
                    if (strFunction.InList(pcvType, new string[5] { "PT", "PR", "PO", "EP", "AR" }) == true ||
                        strFunction.InList(beHave, new string[5] { "PT", "PR", "PO", "EP", "AR" }) == true)
                    {
                        companyStax = System.Convert.ToBoolean(company.Rows[0]["pStax_op"]);
                    }
                    else
                    {
                        companyStax = false;
                    }
                }

                if (companyStax == true)
                {
                    // Add record in tax_vw 
                    DataRow staxRow = null;
                    bool isFound = false;
                    try
                    {
                        staxRow = stax_vw.Select("tax_name = '" + System.Convert.ToString(main_vw.Rows[0]["tax_name"]).Trim() + "'")[0];
                        isFound = true;
                    }
                    catch
                    {
                        isFound = false;
                    }

                    if (isFound == true)
                    {
                        DataRow taxRow = tax_vw.NewRow();
                        for (int i = 0; i <= staxRow.Table.Columns.Count - 1; i++)
                        {
                            if (taxRow.Table.Columns[i].ColumnName.Trim() !=
                                staxRow.Table.Columns[i].ColumnName.Trim())
                            {
                                for (int j = 0; j <= taxRow.Table.Columns.Count - 1; j++)
                                {
                                    if (taxRow.Table.Columns[j].ColumnName.Trim() ==
                                        staxRow.Table.Columns[i].ColumnName.Trim())
                                    {
                                        taxRow[j] = staxRow[i];
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                taxRow[i] = staxRow[i];
                            }

                        }
                        taxRow["entry_ty"] = beHave.ToString().Trim();
                        taxRow["code"] = "S";
                        taxRow["head_nm"] = System.Convert.ToString(main_vw.Rows[0]["tax_name"]).Trim();
                        taxRow["def_amt"] = System.Convert.ToDecimal(main_vw.Rows[0]["taxamt"]);
                        taxRow["Form_no"] = System.Convert.ToString(main_vw.Rows[0]["form_no"]).Trim();
                        taxRow["def_pert"] = System.Convert.ToDecimal(staxRow["level1"]);
                        taxRow["fld_nm"] = "TAXAMT";
                        taxRow["round_off"] = System.Convert.ToBoolean(company.Rows[0]["ssamt_op"]);
                        taxRow["att_file"] = true;
                        taxRow["disp_sign"] = "%";
                        taxRow["Pert_name"] = "";

                        if (strFunction.Left(beHave, 1) == "P")
                        {
                            taxRow["dac_name"] = System.Convert.ToString(staxRow["ac_name3"]);
                        }
                        else
                        {
                            taxRow["dac_name"] = System.Convert.ToString(staxRow["ac_name1"]);
                        }
                        tax_vw.Rows.Add(taxRow);
                        tax_vw.AcceptChanges();
                    }
                    else
                    {
                        DataRow taxRow = tax_vw.NewRow();
                        taxRow["entry_ty"] = beHave.ToString().Trim();
                        taxRow["code"] = "S";
                        taxRow["fld_nm"] = "TAXAMT";
                        taxRow["round_off"] = System.Convert.ToBoolean(company.Rows[0]["ssamt_op"]);
                        taxRow["att_file"] = true;
                        taxRow["disp_sign"] = "%";
                        tax_vw.Rows.Add(taxRow);
                        tax_vw.AcceptChanges();
                    }
                }

                //call update Tax
                tax_vw1 = pgTaxUpdate(tax_vw, tax_vw1, main_vw, item_vw, AddMode, EditMode);

                if (tax_vw1.Rows.Count > 0)
                {
                    grdTax.DataSource = tax_vw1;
                    grdTax.DataBind();
                }
                else
                {
                    DataTable tmpTb = tax_vw1.Clone();
                    tmpTb.Rows.Add(tmpTb.NewRow());
                    tmpTb.Rows.Add(tmpTb.NewRow());
                    tmpTb.Rows.Add(tmpTb.NewRow());
                    tmpTb.Rows.Add(tmpTb.NewRow());
                    grdTax.Columns[3].Visible = false;
                    grdTax.DataSource = tmpTb;
                    grdTax.DataBind();   
                }
          }
          return grdTax;
        }

        public GridView gridBindAllocation(GridView grdAllocation, DataTable acdet_vw)
        {
            grdAllocation.DataSource = acdet_vw;
            grdAllocation.DataBind();

            return grdAllocation; 
        }

        public GridView gridAllocation(GridView grdAllocation, DataTable lal_vw, DataTable acdet_vw, DataTable company)
        {
            if (System.Convert.ToBoolean(company.Rows[0]["allo_op"]) == true &&
                System.Convert.ToBoolean(company.Rows[0]["acc_adj"]) == true)
            {
                grdAllocation.DataSource = lal_vw;
            }
            else
            {
                grdAllocation.DataSource = acdet_vw; 
            }

            if (grdAllocation.DataSource is DataTable)
            {
                DataTable allocView = ((DataTable)grdAllocation.DataSource);
                if (allocView.Rows.Count > 0)
                {
                    string[] grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdAllocation.DataSource = allocView;
                    gridBind(grdAllocation, grdCols);
                    //grdAllocation.DataBind();
                }
                else
                {
                    //DataTable tmpTb = acdet_vw.Clone();
                    //tmpTb.Rows.Add(tmpTb.NewRow());
                    //tmpTb.Rows.Add(tmpTb.NewRow());
                    //tmpTb.Rows.Add(tmpTb.NewRow());
                    //tmpTb.Rows.Add(tmpTb.NewRow());
                    //grdAllocation.Columns[0].Visible = false;
                    //grdAllocation.Columns[1].Visible = false;   
                    //grdAllocation.DataSource = tmpTb;
                    //grdAllocation.DataBind();

                    string[] grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdAllocation.DataSource = allocView;
                    gridBind(grdAllocation, grdCols);

                }
            }
            return grdAllocation; 
        }

        public DataTable pgTaxUpdate(DataTable tax_vw, DataTable tax_vw1, DataTable main_vw, DataTable item_vw,bool addMode, bool editMode)
        {
            if (addMode == true || editMode == true)
            {
                // remove all record if record already exist in table
                numericFunction numFunction = new numericFunction();
                boolFunction bitFunction = new boolFunction();
                getDateFormat DateFormat = new getDateFormat();
                tax_vw1.Clear();
                tax_vw1.AcceptChanges();
 
                DataRow GatherRow;
                string mTbl = "";
                string mainCol = "";
                foreach (DataRow Row in tax_vw.Rows)
                {
                    if (bitFunction.toBoolean(Row["ldeactive"]) == false ||
                        (bitFunction.toBoolean(Row["ldeactive"]) == true &&
                         DateFormat.TodateTime(Row["deactfrom"]) <= DateFormat.TodateTime(main_vw.Rows[0]["Date"])))
                    {
                        if ((DBNull.Value.Equals(Row["att_file"]) ? false : System.Convert.ToBoolean(Row["att_file"])) == true)
                        {
                            mTbl = "MAIN_VW";
                        }
                        else
                        {
                            mTbl = "ITEM_VW";
                        }

                        if (main_vw.Columns.Contains(Convert.ToString(Row["fld_nm"])) == false)
                        {
                            continue; 
                        }

                        if (System.Convert.ToString(Row["pert_name"]).Trim() != "")
                        {
                            mainCol = System.Convert.ToString(Row["Pert_name"]).Trim();
                            if (mTbl.ToString().Trim() == "MAIN_VW")
                            {
                                Row["def_pert"] = numFunction.toDecimal(main_vw.Rows[0][mainCol]);
                            }

                        }
                        else
                        {
                            if (!Convert.IsDBNull(Row["def_pert"]))
                            {
                                Row["def_pert"] = numFunction.toDecimal(Row["def_pert"]);
                            }
                            else
                            {
                                Row["def_pert"] = 0;
                            }
                        }


                        if (System.Convert.ToString(Row["fld_nm"]).Trim() != "")
                        {
                            mainCol = System.Convert.ToString(Row["fld_nm"]).Trim();
                            Row["def_amt"] = numFunction.toDecimal(main_vw.Rows[0][mainCol]);
                        }
                        else
                        {
                            if (!Convert.IsDBNull(Row["def_amt"]))
                            {
                                Row["def_amt"] = numFunction.toDecimal(Row["def_amt"]);
                            }
                            else
                            {
                                Row["def_amt"] = 0;
                            }
                        }

                        tax_vw.AcceptChanges();

                        GatherRow = tax_vw1.NewRow();
                        for (int i = 0; i < tax_vw.Columns.Count; i++)
                        {
                            GatherRow[i] = Row[i];
                        }

                        stringFunction strFunction = new stringFunction();
                        if ((System.Convert.ToString(GatherRow["a_s"]).Trim() == "-") ||
                            (strFunction.InList(System.Convert.ToString(GatherRow["code"]).Trim(), new string[2] { "D", "F" }) == true &&
                             System.Convert.ToString(GatherRow["a_s"]).Trim() != "+"))
                        {
                            GatherRow["Head_Nm"] = "(-) " + System.Convert.ToString(GatherRow["Head_Nm"]).Trim();
                        }

                        if (System.Convert.ToString(GatherRow["code"]).Trim() == "S" && System.Convert.ToString(GatherRow["Head_nm"]).Trim() == "")
                        {
                            GatherRow["Head_Nm"] = "NO-TAX";
                        }

                        tax_vw1.Rows.Add(GatherRow);


                        //foreach (DataRow taxRow in tax_vw1.Rows)
                        //{
                        //    if ((System.Convert.ToString(taxRow["a_s"]).Trim() == "-") ||
                        //        (strFunction.InList(System.Convert.ToString(taxRow["code"]).Trim(), new string[2] { "D", "F" }) == true &&
                        //         System.Convert.ToString(taxRow["a_s"]).Trim() != "+"))
                        //    {
                        //        taxRow["Head_Nm"] = "(-) " + System.Convert.ToString(taxRow["Head_Nm"]).Trim();
                        //    }

                        //    if (System.Convert.ToString(taxRow["code"]).Trim() == "S" && System.Convert.ToString(taxRow["Head_nm"]).Trim() == "")
                        //    {
                        //        taxRow["Head_Nm"] = "NO-TAX";
                        //    }
                        //}
                        tax_vw1.AcceptChanges();
                    }
                }
            }
            return tax_vw1; 
        }

        public void gridBind(GridView grdView,string[] cols)
        {
            //try
            //{
                if (grdView.DataSource is DataTable)
                {
                    DataTable tmpTb = ((DataTable)grdView.DataSource);
                    if (tmpTb.Rows.Count == 0)
                    {
                        tmpTb = tmpTb.Clone();
                        tmpTb.Rows.Add(tmpTb.NewRow());
                        tmpTb.Rows.Add(tmpTb.NewRow());
                        tmpTb.Rows.Add(tmpTb.NewRow());
                        tmpTb.Rows.Add(tmpTb.NewRow());

                        if (cols != null)
                        {
                            foreach (string strcols in cols)
                            {
                                if (strcols != null && strcols != "")
                                {
                                    grdView.Columns[Convert.ToInt32(strcols)].Visible = false;
                                }
                            }
                        }

                        grdView.DataSource = tmpTb;
                        grdView.DataBind();

                        if (grdView.ID == "grdlAllocDet")
                        {
                            for (int i = 0; i < grdView.Rows.Count; i++)
                            {
                                ImageButton imgBtn = (ImageButton)grdView.Rows[i].Cells[1].FindControl("imgCollapsible");
                                imgBtn.Visible = false;                                     
                            }
                        }

                    }
                    else
                    {
                        // first visible all columns
                        for (int i = 0; i < grdView.Columns.Count; i++)
                        {
                            grdView.Columns[i].Visible = true;
                        }

                        // if cols arraylist is not null then visible false specified columns

                        if (cols != null)
                        {
                            foreach (string strcols in cols)
                            {
                                if (strcols != null && strcols != "")
                                {
                                    grdView.Columns[Convert.ToInt32(strcols)].Visible = false;
                                }
                            }

                        }

                        grdView.DataSource = tmpTb;
                        grdView.DataBind();

                        if (grdView.ID == "grdlAllocDet")
                        {
                            for (int i = 0; i < grdView.Rows.Count; i++)
                            {
                                ImageButton imgBtn = (ImageButton)grdView.Rows[i].Cells[1].FindControl("imgCollapsible");
                                imgBtn.Visible = true;
                            }
                        }
                    }

                   

                }
            //}
            //catch (Exception Ex)
            //{
            //    throw new Exception("ERROR found in gridBind Method |" + Ex.Message.Trim()); 
            //}

        }
       
    }
}
