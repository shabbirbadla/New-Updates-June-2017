using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Business.Logic.Layer;
using Controls;

namespace Udyog.E.Billing
{
    public partial class uwPriceListMaster : System.Web.UI.Page
    {
        //private static bool AddMode = false;
        //private static bool EditMode = false;
        //private static string ItDetMode = "";
        //private static int ItDetKey = 0;
        //private static Int32 prLstcd;
        //private static DataSet ItRateSet;

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }

        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private Int32 prLstcd;

        public Int32 PrLstcd
        {
            get { return prLstcd; }
            set { prLstcd = value; }
        }

        DataTier DataAccess = new DataTier();

        private string sqlStr = "";
        SqlConnection connHandle;
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        protected void Page_Load(object sender, EventArgs e)
        {
            radPrType.Items[0].Attributes.Add("onclick", "javascript:return GetRadioButtonSale('Sales');");
            radPrType.Items[1].Attributes.Add("onclick", "javascript:return GetRadioButtonSale('Purchase');");

            if (IsPostBack == true)
            {
                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                PrLstcd = Convert.ToInt32(Request.QueryString["prlistcd"]);
                return;
            }

            AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
            PrLstcd = Convert.ToInt32(Request.QueryString["prlistcd"]);

            hidItDetRows.Value = ""; 
            txtFlatRate.Attributes.Add("onfocusout", "javascript:return CallConfirmWindow('txtFlatRate','Old Flat rate will be removed and New Flat Rate will be applicable for all Items, \\n Continue ?');");
            txtDiscount.Attributes.Add("onfocusout", "javascript:return CallConfirmWindow('txtDiscount','Old Discount rate will be remove and New Discount Rate will be applicable for all Items, \\n Continue ?');");
            //radPrType.Attributes.Add("onclick", "javascript:return GetRadioButtoValue();");
            lblTrType.Text = "Price List Master"; 
            DataSet ItRateSet = new DataSet();
            hidItDetMode.Value = "";
            hidItDetKey.Value = "0"; 
            //ItDetKey = 0;
            if (AddMode == true)
                addRec(ItRateSet);
            else
                if (EditMode == true)
                    editRec(PrLstcd,ItRateSet);

            ItRateSet.Dispose();
        }

        protected void editRec(Int32 PrLstcd,
            DataSet ItRateSet)
        {
            DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;
  
            sqlStr = "select * from it_rate where prlistcd = " + PrLstcd;
            ItRateSet = DataAccess.ExecuteDataset(ItRateSet, sqlStr, "it_rate_vw",connHandle);

            sqlStr = "select a.prlistcd,a.it_code,a.flatrate,a.discount,a.cmputrate," +
                     "a.minqty,a.maxqty,it_mast.it_name, it_mast.[it_alias]," +
                     "it_mast.rateper as srate, it_mast.curr_cost as prate," +
                     "(case when it_rate.prlistty='S' then it_mast.rateper " +
                     "when it_rate.prlistty = 'P' then it_mast.curr_cost end) as rate" +
                     " from it_rate_det a right join it_mast on a.it_code = it_mast.it_code" +
                     " right join it_rate on it_rate.prlistcd = a.prlistcd" +
                     " where a.prlistcd =" + PrLstcd; 

            ItRateSet = DataAccess.ExecuteDataset(ItRateSet, sqlStr, "it_rate_det_vw",connHandle);
            DataAccess.Connclose(connHandle);
 
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();
            boolFunction bitFunction = new boolFunction();
            DataRow itDetRow = ItRateSet.Tables["it_rate_vw"].Rows[0];
            txtPrLstCode.Text = Convert.ToString(itDetRow["prcode"]);
            radPrType.SelectedValue = Convert.ToString(itDetRow["prlistty"]).Trim() == "S" ? "Sales" :
                (Convert.ToString(itDetRow["prlistty"]).Trim() == "P" ? "Purchase" : "");
            txtPrLstDesc.Text = Convert.ToString(itDetRow["prdesc"]);
            txtFlatRate.Text = Convert.ToString(numFunction.toDecimal(itDetRow["flatrate"]));
            txtDiscount.Text = Convert.ToString(numFunction.toDecimal(itDetRow["discount"]));
            txtExpDate.Text = DateFormat.dateformatBR(Convert.ToString(itDetRow["expirydt"]));
            txtEffDate.Text = DateFormat.dateformatBR(Convert.ToString(itDetRow["effectdt"]));
            chkDiscont.Checked = bitFunction.toBoolean(itDetRow["discont"]);

            radPrType.Enabled = false;
            txtPrLstCode.ReadOnly = true; 
            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_Vw"];
            Session["ItRateSet"] = ItRateSet;
            grdBind(false);
            fillDropDown(ItRateSet);
        }

        protected void addRec(DataSet ItRateSet)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;
 
            sqlStr = "select * from it_rate where 1=2";
            ItRateSet = DataAccess.ExecuteDataset(ItRateSet,sqlStr, "it_rate_vw",connHandle);
            DataRow itRateRow = ItRateSet.Tables["it_rate_vw"].NewRow();
            itRateRow["effectdt"] = DateTime.Today.Date;
            itRateRow["expirydt"] = DateTime.Today.Date.AddDays(30);
            itRateRow["prlistcd"] = 9999;
            DataNullUpdate.NullUpdate(itRateRow);

            ItRateSet.Tables["it_rate_vw"].Rows.Add(itRateRow); 
            ItRateSet.Tables["it_rate_vw"].AcceptChanges();

            sqlStr = "select it_rate_det.*, it_mast.it_name, it_mast.it_alias," +
                     "it_mast.rateper as srate, it_mast.curr_cost as prate, cast(0 as decimal) as rate " +
                     "from it_rate_det,it_mast where 1=2";
            ItRateSet = DataAccess.ExecuteDataset(ItRateSet, sqlStr, "it_rate_det_vw",connHandle);
            DataAccess.Connclose(connHandle); 
            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_Vw"];
            Session["ItRateSet"] = ItRateSet;
            grdBind(false);

            getDateFormat DateFormat = new getDateFormat();
            txtEffDate.Text = DateFormat.dateformatBR(Convert.ToString(itRateRow["effectdt"]));
            txtExpDate.Text = DateFormat.dateformatBR(Convert.ToString(itRateRow["expirydt"])); 
        }

        protected void grdBind(bool isSelColDisplay)
        {
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            if (ItRateSet.Tables["it_rate_det_Vw"].Rows.Count == 0)
            {
                DataTable tmpTb = ((DataTable)grdItRateDet.DataSource);
                tmpTb = tmpTb.Clone();
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());

                grdItRateDet.DataSource = tmpTb;
                grdItRateDet.DataBind();
                grdItRateDet.Columns[0].Visible = false;
            }
            else
            {
                grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_Vw"];
                grdItRateDet.DataBind();
                grdItRateDet.Columns[0].Visible = true;
            }
            ItRateSet.Dispose(); 
        }

        protected void fillDropDown(DataSet ItRateSet)
        {
            numericFunction numFunction = new numericFunction();
            DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            sqlStr = "Select It_Code,It_Name,Rateunit, rate as srate, curr_cost as prate From It_Mast order by It_Name";
            ItRateSet = DataAccess.ExecuteDataset(ItRateSet, sqlStr, "itMastVw",connHandle);
            DataAccess.Connclose(connHandle);

            if (hidItDetMode.Value != "")
            {
                if (ItRateSet.Tables["it_rate_det_vw"].Rows.Count > 0)
                {
                    //DataRow itDetFoundRow;
                    foreach (DataRow itDetFoundRow in ItRateSet.Tables["it_rate_det_vw"].Rows)
                    {
                        DataRow delItRateRow;
                        try
                        {
                            delItRateRow = ItRateSet.Tables["itMastVw"].Select("it_code = "
                                            + numFunction.toInt32(itDetFoundRow["it_code"]))[0];
                            delItRateRow.Delete();
                            delItRateRow.AcceptChanges();
                        }
                        catch { }
                    }
                    ItRateSet.Tables["itMastVw"].AcceptChanges();
                }
            }
            dropItem.DataSource = ItRateSet.Tables["itMastVw"];
            dropItem.DataTextField = "it_name";
            dropItem.DataValueField = "it_code";
            dropItem.DataBind();
            dropItem.Items.Insert(0,"--Select Item--");  
        }

        protected void dropItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropItem.SelectedIndex == 0) { return; }

            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            DataRow ItDetRow;
            try
            {
                ItDetRow = ItRateSet.Tables["it_rate_det_vw"].Select("it_code = " +
                            dropItem.SelectedValue)[0];
                dropItem.SelectedIndex = 0; 
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Cannot add Item, Item already Exist');", true);
                return;
            }
            catch { }

            //hidRate.Value = "";
            numericFunction numFunction = new numericFunction();
            DataRow itMastRow;
            try
            {
                itMastRow = ItRateSet.Tables["itMastVw"].Select("it_code = " +
                             dropItem.SelectedValue)[0];
                decimal Rate = 0;
                decimal ComputeRate = 0;
                decimal FlatRate = 0;
                decimal Discount = 0;

                // Item Rate
                if (radPrType.Items[0].Selected)
                {
                    Rate = numFunction.toDecimal(itMastRow["srate"]);
                }
                else
                {
                    Rate = numFunction.toDecimal(itMastRow["prate"]);
                }
                txtItRate.Text = Convert.ToString(Rate);

                // FlatRate
                if (txtItFlatRate.Text != "" && txtItFlatRate.Text != "0.00")
                {
                    FlatRate = numFunction.toDecimal(txtItFlatRate.Text);
                }
                else
                {
                    if (txtFlatRate.Text != "" && txtFlatRate.Text != "0.00")
                    {
                        FlatRate = numFunction.toDecimal(txtFlatRate.Text);
                        txtItFlatRate.Text = Convert.ToString(FlatRate); 
                    }
                }

                // Discount
                if (txtItDiscount.Text != "" && txtItDiscount.Text != "0.00")
                {
                    Discount = numFunction.toDecimal(txtItDiscount.Text);
                }
                else
                {
                    if (txtDiscount.Text != "" && txtDiscount.Text != "0.00")
                    {
                        Discount = numFunction.toDecimal(txtDiscount.Text);
                        txtItDiscount.Text = Convert.ToString(Discount);  
                    }
                }

                ComputeRate = numFunction.toDecimal(((Rate - (Rate * Discount / 100)) +
                                FlatRate),2);
                txtItCompRate.Text = Convert.ToString(ComputeRate);  
            }
            catch(Exception Ex) 
            { 
                throw new Exception("Item not found..");
            }

            ItRateSet.Dispose();
        }

        protected void imgITNew_Click(object sender, ImageClickEventArgs e)
        {
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            fillDropDown(ItRateSet);
            Session["ItRateSet"] = ItRateSet;
            ItRateSet.Dispose();
            trPrItDetails.Style.Add("display", ""); 
            txtItFlatRate.Attributes.Add("onfocusout", "calFlatRateOnLostFocus();");
            txtItDiscount.Attributes.Add("onfocusout", "calDiscountOnLostFocus();");
            dropItem.SelectedIndex = 0;
            txtItCompRate.Text = "0.00";
            txtItDiscount.Text = "0.00";
            txtItFlatRate.Text = "0.00";
            txtItMaxQty.Text = "0.00";
            txtItMinQty.Text = "0.00";
            txtItRate.Text = "0.00"; 
            hidItDetMode.Value = "ADD";

        }

        protected void imgITEdit_Click(object sender, ImageClickEventArgs e)
        {
            bool isSelect = false;
            int keyValue = 0;
            for (int i = 0; i < grdItRateDet.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)grdItRateDet.Rows[i].FindControl("chkSelect");
                if (isSelect == true && chkSelect.Checked == true)
                {
                    trPrItDetails.Style.Add("display", "none");
                    return;
                }

                if (chkSelect.Checked == true)
                {
                    keyValue += Convert.ToInt32(grdItRateDet.DataKeys[i].Value);
                    isSelect = true;
                }
            }

            if (isSelect == false)
            {
                return;
            }

             
            DataRow editRow;
            numericFunction numFunction = new numericFunction();
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            editRow = ItRateSet.Tables["it_rate_det_vw"].Select("it_code = " +
                            keyValue)[0];

            dropItem.SelectedValue = Convert.ToString(numFunction.toInt32(editRow["it_code"]));
            txtItRate.Text = Convert.ToString(numFunction.toDecimal(editRow["rate"]));
            txtItFlatRate.Text = Convert.ToString(numFunction.toDecimal(editRow["flatrate"]));
            txtItDiscount.Text = Convert.ToString(numFunction.toDecimal(editRow["discount"]));
            txtItCompRate.Text = Convert.ToString(numFunction.toDecimal(editRow["cmputrate"]));
            txtItMinQty.Text = Convert.ToString(numFunction.toDecimal(editRow["minqty"]));
            txtItMaxQty.Text = Convert.ToString(numFunction.toDecimal(editRow["maxqty"]));
            hidItDetMode.Value = "EDIT";
            //ItDetKey = keyValue;
            hidItDetKey.Value = Convert.ToString(keyValue);
            trPrItDetails.Style.Add("display", "");
            ItRateSet.Dispose();
        }

        protected void imgITDelete_Click(object sender, ImageClickEventArgs e)
        {
            bool isSelect = false;
            int keyValue = 0;
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            for (int i = 0; i < grdItRateDet.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)grdItRateDet.Rows[i].FindControl("chkSelect");
                if (isSelect == true && chkSelect.Checked == true)
                {
                    trPrItDetails.Style.Add("display", "none");
                }

                if (chkSelect.Checked == true)
                {
                    keyValue = Convert.ToInt32(grdItRateDet.DataKeys[i].Value);

                    DataRow DeleRow = ItRateSet.Tables["it_rate_det_vw"]
                                        .Select("it_code = " +keyValue)[0];  
                    DeleRow.Delete();
                    DeleRow.AcceptChanges();  
                }
            }
            ItRateSet.Tables["it_rate_det_vw"].AcceptChanges();
            lblItRowStatus.Text = "Records Deleted..";
            lblItRowStatus.Style.Add("display", "");
            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_vw"];
            hidItDetRows.Value = Convert.ToString(ItRateSet.Tables["it_rate_det_vw"].Rows.Count); 
            Session["ItRateSet"] = ItRateSet; 
            grdBind(true);
            ItRateSet.Dispose(); 
        }

        protected void btnItUpdate_Click(object sender, EventArgs e)
        {
            if (dropItem.SelectedIndex == 0)
                return;

            numericFunction numFunction = new numericFunction();
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            DataRow ItDetRow = null;
            // temp. update prlistcd transcation code
            if (AddMode == true && hidItDetMode.Value == "ADD")
            {
                ItDetRow = ItRateSet.Tables["it_rate_det_vw"].NewRow();
                ItDetRow["prlistcd"] = 9999;
            }
            else
            {
                if (AddMode == true && hidItDetMode.Value == "EDIT")
                {
                    ItDetRow = ItRateSet.Tables["it_rate_det_vw"].Select("it_code = " + hidItDetKey.Value)[0];
                }
                else
                {
                    if (EditMode == true && hidItDetMode.Value == "ADD")
                    {
                        ItDetRow = ItRateSet.Tables["it_rate_det_vw"].NewRow();
                        ItDetRow["prlistcd"] = numFunction.toInt32(ItRateSet.Tables["it_rate_vw"].Rows[0]["prlistcd"]);
                    }
                    else
                    {
                        if (EditMode == true && hidItDetMode.Value == "EDIT")
                        {
                            ItDetRow = ItRateSet.Tables["it_rate_det_vw"].Select("it_code = " + hidItDetKey.Value)[0];
                        }
                    }
                }
            }
            
            ItDetRow["it_code"] = numFunction.toInt32(dropItem.SelectedValue);
            ItDetRow["it_name"] = dropItem.SelectedItem.Text.ToString().Trim();
            ItDetRow["rate"] = numFunction.toDecimal(txtItRate.Text);

            decimal Rate = numFunction.toDecimal(txtItRate.Text);
            decimal FlatRate = 0;
            decimal Discount = 0;

            // FlatRate
            if (txtItFlatRate.Text != "" && txtItFlatRate.Text != "0.00")
            {
                FlatRate = numFunction.toDecimal(txtItFlatRate.Text);
            }
            else
            {
                if (txtFlatRate.Text != "" && txtFlatRate.Text != "0.00")
                {
                    FlatRate = numFunction.toDecimal(txtFlatRate.Text);
                }
            }

            // Discount
            if (txtItDiscount.Text != "" && txtItDiscount.Text != "0.00")
            {
                Discount = numFunction.toDecimal(txtItDiscount.Text);
            }
            else
            {
                if (txtDiscount.Text != "" && txtDiscount.Text != "0.00")
                {
                    Discount = numFunction.toDecimal(txtDiscount.Text);
                }
            }

            ItDetRow["flatrate"] = FlatRate;
            ItDetRow["discount"] = Discount; 

            // Calculate Computed Rate
            if (Rate > 0 && Discount > 0 && FlatRate > 0)
                ItDetRow["cmputrate"] = numFunction.toDecimal((Rate - (Rate * Discount / 100)) +
                                         FlatRate, 2);
            else
                ItDetRow["cmputrate"] = numFunction.toDecimal(txtItCompRate.Text);

            ItDetRow["minqty"] = numFunction.toDecimal(txtItMinQty.Text);
            ItDetRow["maxqty"] = numFunction.toDecimal(txtItMaxQty.Text);

            if ((AddMode == true && hidItDetMode.Value == "ADD") ||
                (EditMode == true && hidItDetMode.Value == "ADD"))
            {
                ItRateSet.Tables["it_rate_det_vw"].Rows.Add(ItDetRow);
            }
            ItRateSet.Tables["it_rate_det_vw"].AcceptChanges();
            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_vw"];
            trPrItDetails.Style.Add("display", "none");
            hidItDetRows.Value = Convert.ToString(ItRateSet.Tables["it_rate_det_vw"].Rows.Count);
            hidTrType.Value = radPrType.SelectedItem.Text.ToString().Trim();
            Session["ItRateSet"] = ItRateSet;
            grdBind(true);
            ItRateSet.Dispose();

        }

        protected void txtFlatRate_TextChanged(object sender, EventArgs e)
        {
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            if (ItRateSet.Tables["it_rate_det_vw"].Rows.Count == 0)
                return;

            if (hidConfirm.Value == "" || hidConfirm.Value == "0")
                return;

            
            hidConfirm.Value = ""; 
            numericFunction numFunction = new numericFunction();
            foreach (DataRow ItDetRow in ItRateSet.Tables["It_rate_det_vw"].Rows)
            {
                decimal ComputeRate = 0;
                decimal Rate = 0;
                decimal Discount = 0;
                DataRow itMastRow;
                try
                {
                    itMastRow = ItRateSet.Tables["itMastVw"].Select("it_code = " +
                                 numFunction.toInt32(ItDetRow["it_code"]))[0];
                    
                    if (radPrType.Items[0].Selected)
                    {
                        Rate = numFunction.toDecimal(itMastRow["srate"]);
                    }
                    else
                    {
                        Rate = numFunction.toDecimal(itMastRow["prate"]);
                    }
                } catch {}

                // Discount
                if (txtDiscount.Text != "" && txtDiscount.Text != "0.00")
                {
                    Discount = numFunction.toDecimal(txtDiscount.Text);
                }
                else
                {
                    Discount = numFunction.toDecimal(ItDetRow["discount"]);
                }


                decimal DiscountRate = (Rate * Discount / 100);
                ComputeRate = ((Rate - DiscountRate) +
                                numFunction.toDecimal(txtFlatRate.Text));

                ItDetRow["flatRate"] = numFunction.toDecimal(txtFlatRate.Text);
                ItDetRow["cmputrate"] = numFunction.toDecimal(ComputeRate,2);

            }
            ItRateSet.Tables["It_rate_det_vw"].AcceptChanges();

            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_vw"];
            Session["ItRateSet"] = ItRateSet; 
            grdBind(true);
            ItRateSet.Dispose(); 

        }

        protected void txtDiscount_TextChanged(object sender, EventArgs e)
        {
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            if (ItRateSet.Tables["it_rate_det_vw"].Rows.Count == 0)
                return;

            if (hidConfirm.Value == "" && hidConfirm.Value == "0")
                return;

            hidConfirm.Value = "";            
            numericFunction numFunction = new numericFunction();
            foreach (DataRow ItDetRow in ItRateSet.Tables["It_rate_det_vw"].Rows)
            {
                decimal ComputeRate = 0;
                decimal Rate = 0;
                decimal FlatRate = 0;
                DataRow itMastRow;
                try
                {
                    itMastRow = ItRateSet.Tables["itMastVw"].Select("it_code = " +
                                 numFunction.toInt32(ItDetRow["it_code"]))[0];

                    if (radPrType.Items[0].Selected)
                    {
                        Rate = numFunction.toDecimal(itMastRow["srate"]);
                    }
                    else
                    {
                        Rate = numFunction.toDecimal(itMastRow["prate"]);
                    }
                }
                catch { }

                // FlatRate
                if (txtFlatRate.Text != "" && txtFlatRate.Text != "0.00")
                {
                    FlatRate = numFunction.toDecimal(txtFlatRate.Text);
                }
                else
                {
                    FlatRate = numFunction.toDecimal(ItDetRow["flatrate"]);
                }


                decimal DiscountRate = (Rate * numFunction.toDecimal(txtDiscount.Text) / 100);
                ComputeRate = ((Rate - DiscountRate) +
                                FlatRate);

                ItDetRow["discount"] = numFunction.toDecimal(txtDiscount.Text);
                ItDetRow["cmputrate"] = numFunction.toDecimal(ComputeRate,2);

            }

            ItRateSet.Tables["It_rate_det_vw"].AcceptChanges();

            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_vw"];
            Session["ItRateSet"] = ItRateSet; 
            grdBind(true);
            ItRateSet.Dispose(); 
        }

        protected void grdItRateDet_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            grdItRateDet.PageIndex = e.NewPageIndex;
            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_vw"];
            Session["ItRateSet"] = ItRateSet; 
            grdBind(true);
            ItRateSet.Dispose(); 
        }

        protected void radPrType_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet ItRateSet = (DataSet)Session["ItRateSet"];
            ItRateSet.Tables["it_rate_det_vw"].Clear();
            grdItRateDet.DataSource = ItRateSet.Tables["it_rate_det_vw"];
            Session["ItRateSet"] = ItRateSet; 
            grdBind(false);
            ItRateSet.Dispose();
        }

        protected void btnBottomSave_Click(object sender, EventArgs e)
        {
            Save(); 
        }

        protected void Validation(DataSet ItRateSet)
        {
            if (txtPrLstCode.Text == "")
            {
                throw new Exception("Price List code cannot be blank..");
            }
            
            if (grdItRateDet.Columns[0].Visible == true &&
                ItRateSet.Tables["it_rate_det_vw"].Rows.Count == 0)
            {
                throw new Exception("Price details cannot be blank..");
            }

            if (AddMode == true && EditMode == false)
            {
                sqlStr = "select prlistcd from it_rate where prcode = '"
                                + Convert.ToString(txtPrLstCode.Text) + "'";
                DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName;

                SqlDataReader Dr = DataAccess.ExecuteDataReader(sqlStr,ref connHandle);
                if (Dr.HasRows == true)
                {
                    Dr.Close();
                    Dr.Dispose();
                    DataAccess.Connclose(connHandle);
                    throw new Exception("Price List code already exist, cannot save.");
                }
                Dr.Close();
                Dr.Dispose();
                DataAccess.Connclose(connHandle);

            }
            
        }

        protected void BindSave(ref DataSet ItRateSet)
        {
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();
            boolFunction bitFunction = new boolFunction();
            DataRow itDetRow = ItRateSet.Tables["it_rate_vw"].Rows[0];
            itDetRow["prcode"] = txtPrLstCode.Text.ToString().Trim();
            itDetRow["prlistty"] = radPrType.SelectedItem.Text.ToString().Trim() == "Sales" ? "S" : "P";
            itDetRow["prdesc"] = txtPrLstDesc.Text.ToString().Trim();
            itDetRow["flatrate"] = numFunction.toDecimal(txtFlatRate.Text);
            itDetRow["discount"] = numFunction.toDecimal(txtDiscount.Text);
            itDetRow["expirydt"] = DateFormat.TodateTime(txtExpDate.Text);
            itDetRow["effectdt"] = DateFormat.TodateTime(txtEffDate.Text);
            itDetRow["discont"] = bitFunction.toBoolean(chkDiscont.Checked);
            itDetRow.AcceptChanges();
            ItRateSet.Tables["it_rate_vw"].AcceptChanges();
        }
        protected void Save()
        {
            try
            {
                DataSet ItRateSet = (DataSet)Session["ItRateSet"];
                Validation(ItRateSet);
                BindSave(ref ItRateSet);

                DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName;

                numericFunction numFunction = new numericFunction();
                SqlCommand cmd = new SqlCommand();
                int prlistcd = 0;
                if (AddMode == true)
                {
                    sqlStr = DataAccess.GenInsertString(ItRateSet.Tables["it_rate_vw"].Rows[0], "it_rate", new string[] { "prlistcd" }, null);
                }
                else
                {
                    if (EditMode == true)
                    {
                        sqlStr = DataAccess.GenUpdateString(ItRateSet.Tables["it_rate_vw"], "it_rate",
                                                new string[] { "prlistcd", "prcode" }, null, "", new string[] { "prlistcd" });
                    }
                }
                if (sqlStr != "")
                {
                    cmd = DataAccess.ExecuteNonQuery(sqlStr, "TX", true, ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        if (AddMode == true)
                        {
                            sqlStr = "select prlistcd from it_rate where prcode = '"
                                    + Convert.ToString(ItRateSet.Tables["it_rate_vw"].Rows[0]["prcode"]) + "'";
                            SqlDataReader Dr;
                            Dr = DataAccess.ExecuteDataReader(sqlStr, cmd,ref connHandle);
                            if (Dr.HasRows == true)
                            {
                                while (Dr.Read())
                                {
                                    prlistcd = numFunction.toInt32(Dr["prlistcd"]);
                                }
                            }
                            Dr.Close();
                            Dr.Dispose();

                            // update prlistcd to item rate detail 
                            foreach (DataRow ItDetRow in ItRateSet.Tables["it_rate_det_vw"].Rows)
                            {
                                ItDetRow["prlistcd"] = prlistcd;
                                ItDetRow.AcceptChanges();
                            }
                            ItRateSet.Tables["it_rate_det_vw"].AcceptChanges();

                            sqlStr = DataAccess.GenInsertString(ItRateSet.Tables["it_rate_det_vw"], "it_rate_det",
                                            new string[] { "it_name", "it_alias", "srate", "prate", "rate","it_name1","prate1"}, null);
                        }
                        else
                        {
                            if (EditMode == true)
                            {
                                sqlStr = "delete from it_rate_det where prlistcd = " + numFunction.toInt32(ItRateSet.Tables["it_rate_vw"].Rows[0]["prlistcd"]);  
                                cmd = DataAccess.ExecuteNonQuery(cmd, sqlStr, "TX", true, ref  connHandle);
                                try
                                {
                                    cmd.ExecuteNonQuery();

                                    sqlStr = DataAccess.GenInsertString(ItRateSet.Tables["it_rate_det_vw"], "it_rate_det",
                                             new string[] { "it_name", "it_alias", "srate", "prate", "rate"}, null);
                                }
                                catch (Exception Ex)
                                {
                                    throw Ex;
                                }
                            }
                        }

                        if (sqlStr != "")
                        {
                            cmd = DataAccess.ExecuteNonQuery(cmd,sqlStr, "TX",true, ref connHandle);
                            try
                            {
                                cmd.ExecuteNonQuery();
                                DataAccess.CommitTransaction(cmd.Transaction);
                                DataAccess.Connclose(connHandle);
                                tblError.Visible = false;
                                ItRateSet.Dispose();  
                                Response.Redirect("uwPriceMasterView.aspx?ShowStatus=true");

                            }
                            catch (Exception Ex)
                            {
                                throw Ex;
                            }
                        }
                        else
                        {
                            throw new Exception("ItRate detail table insert string cannot generate");
                        }

                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        DataAccess.Connclose(connHandle);
                        ItRateSet.Dispose();
                        throw Ex;
                    }
                }
            }
            catch (Exception Ex)
            {
          
                tblError.Visible = true;
                lblErrorHeading.Text = "Please Check Error details below";
                lblErrorDetails.Text = Ex.Message; 
            }
        }

        protected void lnkBtnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwPriceMasterview.aspx");
        }
    }
}
