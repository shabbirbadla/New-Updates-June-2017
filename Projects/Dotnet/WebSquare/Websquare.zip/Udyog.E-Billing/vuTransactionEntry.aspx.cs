using System;
using System.Data;
using System.Data.SqlClient;  
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Controls;
using Business.Logic.Layer;
using Data.Acess.Layer;
using AjaxControlToolkit;
using System.Text;
using Customised.Trigger.Layer;  



namespace Udyog.E.Billing
{
    public partial class vuTransactionEntry : BasePage     
    {

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();

        private string sqlStr;
        private SqlConnection connHandle;
        protected override void OnInit(EventArgs e)
        {
            Page.Load += new EventHandler(Page_Load);
            if (IsPostBack == true)
            {
                DataSet MainDataSet = SessionProxy.MainDataSet;
                if (DBPropsSession.ItemPage == true)
                {
                    DataView grdItemColView = new DataView();
                    grdItemColView = SessionProxy.GridItemColView;
                    GenGridItemRows(grdItemColView, MainDataSet);
                    SessionProxy.GridItemColView = grdItemColView; 
                    //grdItemColView.Dispose();
                    MainDataSet.Dispose();
                }
            }
            else
            {
                SessionsRemove(); // Remove existing Session Variables
            }

            base.OnInit(e);
        }

        //protected void Page_Init(object sender, EventArgs e)
        //{
        //    string test = "";
        //}

        protected void Page_Load(object sender, EventArgs e)
        {
            // Set UK Culture for DD/MM/YYYY
            //int UKLocal = 2057;
            //Session.LCID = UKLocal;

            if (IsPostBack == false)
            {
                DataSet MainDataSet = new DataSet();

                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //PageCustomProperties PageCustomProps = new PageCustomProperties();
                CL_DBPageProperties DBProps = new CL_DBPageProperties();
                SessionProxy.DbProperties = DBProps.DbProperties();
                DataRow DbRow = SessionProxy.DbProperties.NewRow();
                SessionProxy.DbProperties.Rows.Add(DbRow);

                //SessionProxy.PageCustomProps = PageCustomProps;

                DBPropsSession.VAmt = 0; // define this variable for Allocation 
                DBPropsSession.VchrAmt = 0;
                DBPropsSession.FromAcAmt = 0;
                DBPropsSession.AllocRowIndex = 0;
                DBPropsSession.IsOpenGridForAllocation = false;
                DBPropsSession.InitStartWithTranCd = 0;

                getTables GetTables = new getTables();
                getData GetData = new getData();
                getCompany GetCompany = new getCompany();
                getCoAdditional GetCoAdditional = new getCoAdditional();

                DBPropsSession.PcvType = Request.QueryString["PcvType"];
                DBPropsSession.Behave = Request.QueryString["Behave"];
                if (Request.QueryString["PcvType"] != string.Empty)
                    DBPropsSession.Entry_Tbl = Request.QueryString["PcvType"];
                else
                    DBPropsSession.Entry_Tbl = Request.QueryString["Behave"];
                
                DBPropsSession.AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                DBPropsSession.EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                DBPropsSession.Vchkprod = SessionProxy.VChkProd.Trim();  
                int tranCd = Convert.ToInt16(Request.QueryString["tranCd"]);
                DBPropsSession.InitStartWithTranCd = tranCd;

                try
                {
                    InitGetTables(ref MainDataSet); // Initial Create Tables
                }
                catch (Exception Ex)
                {
                    DisplayMessage(Ex.Message.Trim());
                    return; 
                }

                
                //Page Caption
                lblTrType.Text = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["code_nm"]).Trim();
                this.Title = lblTrType.Text.Trim();

                ConditionalControlEnabled(ref MainDataSet); 
                GeneralControlEnabled(ref MainDataSet);

                BindDropDown(ref MainDataSet); // Fill Dropdown 

                // call AddMethods and EditMethod
                if (DBPropsSession.AddMode == true)
                {
                    newRec(ref MainDataSet);
                }
                else
                {
                    if (DBPropsSession.EditMode == true)
                    {
                        EditRec(tranCd,ref MainDataSet);
                    }
                }

                DataView grdItemColView = new DataView();
                BindGridView(ref MainDataSet,ref grdItemColView); // Fill All GridView 

                // uday
                if (DBPropsSession.ItemPage == true)
                {
                    vouGridFill vouGridInit = new vouGridFill();
                    //vouGridInit.PageCustProps = SessionProxy.PageCustomProps;
                    if (grdItemColView == null || grdItemColView.Count <= 0)
                        grdItemColView = vouGridInit.ItemgridTemplate(MainDataSet.Tables["lother_vw"],
                                                                                MainDataSet.Tables["company"],
                                                                                MainDataSet.Tables["lcode_vw"],
                                                                                MainDataSet.Tables["item_vw"],
                                                                                MainDataSet.Tables["TexExe"],
                                                                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim());
                    GenGridItemRows(grdItemColView,MainDataSet);
                    SessionProxy.GridItemColView = grdItemColView;
                    if (DBPropsSession.EditMode == true)
                        pnlItDetails.Style.Add("display", "none");
                    else
                        if (DBPropsSession.AddMode == true)
                        {
                            //hidItRowItSerial.Value = "|NEW"; // store status into hidden  variable
                            //pnlItDetails.Visible = false;
                        }

                    
                }

                //boolFunction bitFunction = new boolFunction();
                //if (bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["ac_bchk"]) == true &&
                //   SessionProxy.PageCustomProps.AccountPage == true)
                //{
                    
                //}
                if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 ||
                    DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0)
                    trExciseDetail.Visible = true;
                else
                    trExciseDetail.Visible = false;

                DataAcess.Connclose(connHandle);
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                SessionProxy.MainDataSet = MainDataSet; // Set Session Variable for access
                        // DataSet inside Page
                string itmess,tranmess = "";
                if ((DBPropsSession.PcvType == "DC" || DBPropsSession.PcvType == "DC") &&
                    (DBPropsSession.Vchkprod.Trim().IndexOf("vutex") >= 0 && 
                     Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim() == "EXCISE"))
                {
                    itmess = "As per Excise rule you cannot delete the item from invoice \\n " +
                            "Continue ? ";
                }
                else
                {
                    itmess = " Delete this item ?";
                }

                imgITDelete.Attributes.Add("onclick", "javascript:ItemCheckDeleteRows('" + itmess.Trim() + "');");
                //lnkDelete.Attributes.Add("onclick", "javascript:if (!window.confirm('" + tranmess.Trim() + "')) return false;");   

            }
            else
            {
                    DataSet MainDataSet = SessionProxy.MainDataSet;  
                    vuTransactionevent TransactionEvent = new vuTransactionevent();
                    //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                    if (tblAddinfoDet.Visible == true)
                    {
                        if (MainDataSet.Tables["xtra_vw"]!= null)
                        {
                            DataView xtra_vw = new DataView();
                            xtra_vw = MainDataSet.Tables["xtra_vw"].DefaultView;
                            xtra_vw.Sort = "serial";

                            vuAdditionalInfo vuAdditionalInfo = new vuAdditionalInfo();
                            try
                            {
                                vuAdditionalInfo.genControls(xtra_vw, MainDataSet.Tables["main_vw"].Rows[0], tblAddInfo);
                            }
                            catch (Exception Ex)
                            {
                                DisplayMessage(Ex.Message.Trim());
                                //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
                            }

                        }
                    }

                    if (DBPropsSession.IsOpenGridForAllocation == true)  // gridForallocation gridview is created
                    {
                        gridBindAfterPostback(DBPropsSession.AllocRowIndex);
                    }

                    vouGridFill vouGridInit = new vouGridFill();
                    if (DBPropsSession.ItemPage == true)
                    {
                        GridItem.Columns.Clear();
                        //vouGridInit.PageCustProps = SessionProxy.PageCustomProps;
                        DataView grdItemColView = SessionProxy.GridItemColView;  
                        if (grdItemColView == null || grdItemColView.Table.Rows.Count <= 0)
                            grdItemColView = vouGridInit.ItemgridTemplate(MainDataSet.Tables["lother_vw"],
                                                                                    MainDataSet.Tables["company"],
                                                                                    MainDataSet.Tables["lcode_vw"],
                                                                                    MainDataSet.Tables["item_vw"],
                                                                                    MainDataSet.Tables["TexExe"],
                                                                                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim());

                        vouGridInit.gridItemGen(GridItem, grdItemColView, MainDataSet.Tables["item_vw"]);
                        SessionProxy.GridItemColView = grdItemColView;
                        //grdItemColView.Dispose();  
                        //GenGridItemRows(grdItemColView);

                        DBPropsSession.SalesTaxItem = vouGridInit.SalesTaxItem;
                    }
                //}
                    //tblGenTest(); 
            }
            //lblItRowStatus.Visible = false;
            tdErrorMess.Visible = false; 
            lnkBack.Attributes.Add("OnClick", "javascript: return linkBackConf('" + btnSaveTop.ClientID + "','" + btnBack.ClientID + "');");
        }

        
        protected void txtDateB_TextChanged(object sender, EventArgs e)
        {

            if (txtDateB.Text != "" && txtDateB.Text != "__/__/____")
            {
                DataSet MainDataSet = SessionProxy.MainDataSet;  
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                TransactionEvent.DateValidation(txtDateB,
                        null,
                        null,
                        trduedt,
                        this.Page,
                        hidDateValid,
                        MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["company"],
                        MainDataSet.Tables["lcode_vw"],
                        MainDataSet.Tables["item_vw"],
                        MainDataSet.Tables["acdet_vw"],
                        false);

                SessionProxy.MainDataSet = MainDataSet; 
            }
            //else
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Date cannot be Blank..!!!');", true);
            //    return;
            //}

        }

        protected void txtBankName_TextChanged(object sender, EventArgs e)
        {

            DataSet MainDataSet = SessionProxy.MainDataSet; 

            try
            {
                
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                //Label lblBankBalAmt = (Label)Page.Form.Controls[2].FindControl("tblPage").FindControl("lblBankBalAmt");
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;    
                TransactionEvent.cboBankName_SelectedIndexChanged(txtBankName,
                                txtPartyNameB,
                                MainDataSet.Tables["main_vw"],
                                MainDataSet.Tables["acdet_vw"],
                                MainDataSet.Tables["Company"],
                                MainDataSet.Tables["lcode_vw"],
                                lblBankBalAmt, 
                                GridAccount,
                                grdlAllocDet,
                                hiddBankName);

                if (lblBankBalAmt.Text != "" )
                    hiddBankBalance.Value = "GET";
                
                SessionProxy.MainDataSet = MainDataSet; 

                if (TransactionEvent.ErrorMessage != "")
                {
                    DisplayMessage(TransactionEvent.ErrorMessage);
                }
                ScriptManager1.SetFocus(txtBankName);  
                
            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message.Trim());
                return;
            }


            
            //divBal.Style.Add("");   

            //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "getAbsolutePosition('" + cboBankName.ClientID + "');", true);

        }
        protected void txtPartyNameB_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataSet MainDataSet = SessionProxy.MainDataSet;  
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                TransactionEvent.cboPartyNameB_SelectedIndexChanged(txtPartyNameB,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["acdet_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            MainDataSet.Tables["company"],
                            lblBnkPartyBalAmt,
                            grdlAllocDet,
                            GridAccount,
                            hiddBnkPartyName);

                if (lblBnkPartyBalAmt.Text != "")
                    hiddBnkPartyBalance.Value = "GET"; 

                SessionProxy.MainDataSet = MainDataSet;
                if (TransactionEvent.ErrorMessage != "")
                {
                    DisplayMessage(TransactionEvent.ErrorMessage);
                }
            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message.Trim());
            }
  
        }
        protected void cboInvSeriesB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboInvSeriesB.SelectedIndex == 0)
                return;

            DataSet MainDataSet = SessionProxy.MainDataSet;  
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"] = cboInvSeriesB.SelectedItem.ToString().Trim();
            vuInit initProc = new vuInit();
            initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode,
                    DBPropsSession.EditMode,
                    DBPropsSession.Entry_Tbl,
                    MainDataSet.Tables["main_vw"], 
                    MainDataSet.Tables["lcode_vw"], 
                    "SERIES");
            SessionProxy.MainDataSet = MainDataSet;
            DataAcess.Connclose(connHandle);
        }

        protected void txtInvoiceNoB_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;  
            vuInit initProc = new vuInit();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            txtInvoiceNoB.Text = initProc.txtInvoiceNo_LostFocus(DBPropsSession.AddMode,
                    DBPropsSession.EditMode,
                    DBPropsSession.PcvType,
                    DBPropsSession.Behave,
                    DBPropsSession.Entry_Tbl, 
                    MainDataSet.Tables["main_vw"], 
                    MainDataSet.Tables["lcode_vw"], 
                    hiddInvOldValueB.Value, 
                    txtInvoiceNoB.Text, 
                    "ttt");
            SessionProxy.MainDataSet = MainDataSet;
            DataAcess.Connclose(connHandle);

            if (initProc.ErrorMessage.Trim() != "")
            {
                //DisplayMessage(initProc.ErrorMessage.Trim());

                MainDataSet.Tables["main_vw"].Rows[0]["inv_no"] = "";
                MainDataSet.Tables["main_vw"].AcceptChanges();

                initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode,
                            DBPropsSession.EditMode,
                            DBPropsSession.Entry_Tbl,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            "BUTTON");

                txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                DataAcess.Connclose(connHandle);
                txtInvoiceNoB.Focus();
            }
            
        }
        protected void btnGetInvoiceGotFocusB_Click(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;  
            vuInit initProc = new vuInit();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode,
                    DBPropsSession.EditMode,
                    DBPropsSession.Entry_Tbl,
                    MainDataSet.Tables["main_vw"],
                    MainDataSet.Tables["lcode_vw"], "BUTTON");

            SessionProxy.MainDataSet = MainDataSet;

            DataAcess.Connclose(connHandle);
            txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            txtInvoiceNoB.Focus();
        }

        protected void txtdate_TextChanged(object sender, EventArgs e)
        {
            if (txtdate.Text != "" && txtdate.Text != "__/__/____")
            {
                DataSet MainDataSet = SessionProxy.MainDataSet; 
                DateValidation(txtdate,MainDataSet);
                MainDataSet.Dispose(); 
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                //TransactionEvent.DateValidation(txtdate,
                //      txtDueDate,
                //      txtDueDays,
                //      trduedt,
                //      this.Page,
                //      hidDateValid,
                //      MainDataSet.Tables["main_vw"],
                //      MainDataSet.Tables["company"],
                //      MainDataSet.Tables["lcode_vw"],
                //      MainDataSet.Tables["item_vw"],
                //      MainDataSet.Tables["acdet_vw"],  
                //      false);
                //Session["MainDataSet"] = MainDataSet;

                txtPartyName.Focus(); 
            }
            //else
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Date cannot be Blank..!!!');", true);
            //    return;
            //}
        }

        protected void txtPartyName_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            try
            {
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                TransactionEvent.dropParty_SelectedIndexChanged(txtPartyName,
                    GridAccount,
                    grdlAllocDet,
                    MainDataSet.Tables["main_vw"],
                    MainDataSet.Tables["lcode_vw"],
                    MainDataSet.Tables["company"],
                    MainDataSet.Tables["acdet_vw"],
                    txtdate,
                    txtDueDays,
                    txtDueDate,
                    lblAccBalAmt,
                    hiddPartyName);

                if (lblAccBalAmt.Text != "")
                    hiddAcBalAmt.Value = "GET";

                SessionProxy.MainDataSet = MainDataSet;
                if (TransactionEvent.ErrorMessage != "")
                {
                    DisplayMessage(TransactionEvent.ErrorMessage);
                }
            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message.Trim());
            }
            finally
            {
                MainDataSet.Dispose();
            }
        }
        //protected void dropParty_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
        //    DataSet MainDataSet = (DataSet)Session["MainDataSet"];
        //    TransactionEvent.dropParty_SelectedIndexChanged(dropParty,
        //        GridAccount,
        //        grdlAllocDet,
        //        MainDataSet.Tables["main_vw"],
        //        MainDataSet.Tables["lcode_vw"],
        //        MainDataSet.Tables["company"],
        //        MainDataSet.Tables["acdet_vw"],
        //        txtdate,
        //        txtDueDays,
        //        txtDueDate,
        //        lblAccBalAmt,
        //        hiddPartyName,
        //        trOthTranDivParty);

        //    Session["MainDataSet"] = MainDataSet;
        //    if (TransactionEvent.ErrorMessage != "")
        //    {
        //        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + TransactionEvent.ErrorMessage + "');", true);
        //    }   
                
        //}

        protected void txtInvNo_TextChanged(object sender, EventArgs e)
        {
            vuInit initProc = new vuInit();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            DataSet MainDataSet = SessionProxy.MainDataSet; 
            initProc.txtInvoiceNo_LostFocus(DBPropsSession.AddMode,
                        DBPropsSession.EditMode,
                        DBPropsSession.PcvType,
                        DBPropsSession.Behave,
                        DBPropsSession.Entry_Tbl, 
                        MainDataSet.Tables["main_vw"], 
                        MainDataSet.Tables["lcode_vw"], 
                        hiddInvOldValue.Value, 
                        txtInvNo.Text,
                        "Invoice No.");

            if (initProc.ErrorMessage.Trim() != "")
            {
                //DisplayMessage(initProc.ErrorMessage.Trim());

                MainDataSet.Tables["main_vw"].Rows[0]["inv_no"] = "";
                MainDataSet.Tables["main_vw"].AcceptChanges(); 

                initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode,
                            DBPropsSession.EditMode,
                            DBPropsSession.Entry_Tbl,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            "BUTTON");

                txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                DataAcess.Connclose(connHandle);
                txtInvNo.Focus();
            }

            SessionProxy.MainDataSet = MainDataSet;
            MainDataSet.Dispose(); 
        }
        protected void btnGetInvoiceGotFocus_Click(object sender, EventArgs e)
        {
            vuInit initProc = new vuInit();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            DataSet MainDataSet = SessionProxy.MainDataSet; 
            initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode,
                        DBPropsSession.EditMode,
                        DBPropsSession.Entry_Tbl,
                        MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["lcode_vw"],
                        "BUTTON");
            DataAcess.Connclose(connHandle);
            SessionProxy.MainDataSet = MainDataSet;
            txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            txtInvNo.Focus();
            
        }

        protected void btnAddInfoOk_Click(object sender, EventArgs e)
        {
            vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
            DataSet MainDataSet = SessionProxy.MainDataSet;
            vuAddInfo.btnClick(tblAddInfo,
                               MainDataSet.Tables["main_vw"].Rows[0],"BOXING",null);
            MainDataSet.Tables["main_vw"].AcceptChanges(); // save data in DataTable 
            SessionProxy.MainDataSet = MainDataSet; 
            cpAdditionalInfo.Collapsed = false;
            cpAdditionalInfo.ClientState = "false"; 
        }

        protected void GridItem_RowDataBound(object sender, GridViewRowEventArgs e)
        {
           if (e.Row.RowType != DataControlRowType.DataRow)
                return;
            
            //e.Row.Attributes.Add("onclick", "javascript:ChangeRowColor('" + e.Row.ClientID + "')");

            int lastcellindex = 0;
            CheckBox chkSelect = ((CheckBox)e.Row.Cells[lastcellindex].Controls[0].FindControl("chkSelect"));
            chkSelect.Attributes.Add("onclick", "javascript:HighlightGridRow('" + chkSelect.ClientID + "','" + e.Row.ClientID + "');");

                        
            //int lastcellindex = 0;
            //ImageButton EditButton = new ImageButton();
            //EditButton.ImageUrl = "~/Images/Edit.gif";
            //EditButton.CommandName = "EDIT";
            //EditButton.AlternateText = "Edit";
            //e.Row.Cells[lastcellindex].Controls.Add(EditButton);
            //((Button)e.Row.Cells[lastcellindex].Controls[0].FindControl("btnEdit")).Visible = false;

            //lastcellindex = 1;
            //ImageButton deleteButton = new ImageButton();
            //deleteButton.ImageUrl = "~/Images/TrashCan.gif";
            //deleteButton.CommandName = "DELETE";
            //deleteButton.AlternateText = "Delete";
            //e.Row.Cells[lastcellindex].Controls.Add(deleteButton);
            //((Button)e.Row.Cells[lastcellindex].Controls[0].FindControl("btnDel")).Visible = false;
            
            //deleteButton = ((ImageButton)e.Row.Cells[lastcellindex].Controls[0]);
            //deleteButton.OnClientClick = "if (!window.confirm('Are you sure you want to delete this item?')) return false;";

            //int lastcellindex = e.Row.Cells.Count - 1;
            //ImageButton deleteButton = new ImageButton();
            //deleteButton = ((ImageButton)e.Row.Cells[lastcellindex].Controls[0]);
            //deleteButton.OnClientClick = "if (!window.confirm('Are you sure you want to delete this item?')) return false;";

        }

        //protected void GridItem_RowEditing(object sender, GridViewEditEventArgs e)
        //{
        //    //GridItem.EditIndex = e.NewEditIndex; 
        //    //GridItem.DataSource = MainDataSet.Tables["item_vw"];
        //    //GridItem.DataBind(); 
        //    GenGridItemRows(grdItemColView);
        //    //pnlItDetails.Visible = true;


        //}

        protected void grdCharges_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            MainDataSet.Tables["main_vw"].RejectChanges();
            MainDataSet.Tables["tax_vw1"].RejectChanges();
            MainDataSet.Tables["tax_vw"].RejectChanges();
            grdCharges.EditIndex = -1;
            grdCharges.DataSource = MainDataSet.Tables["tax_vw1"];
            grdCharges.DataBind();
            MainDataSet.Dispose(); 
        }

        protected void grdCharges_RowEditing(object sender, GridViewEditEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            //TransactionEvent.PageCustProps = DBPropsSession;  
            TransactionEvent.grdCharges_RowEditing(grdCharges,
                        MainDataSet.Tables["tax_vw1"],
                        MainDataSet.Tables["Stax_vw"],
                        e.NewEditIndex);
            MainDataSet.Dispose();
            grdCharges.Focus(); 
        }

        protected void grdCharges_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            DataSet MainDataSet = SessionProxy.MainDataSet;
            TransactionEvent.grdCharges_RowUpdating(MainDataSet, grdCharges, e.RowIndex, GridAccount,
                                                    grdlAllocDet, txtItemTotal, txtTotalQty, txtNetAmount,
                                                    txtAccNetAmount, txtGrossAmt, txtdedBefTax, txtTaxCharges,
                                                    txtTaxExAmt, txtAddCharges, txtTaxAmt, txtNonTax, txtfdisc, 
                                                    txtRoundoff,txtNetAmountTax);
            MainDataSet.Dispose();

        }
        protected void dropSaleTax_SelectedIndexChanged(object sender, EventArgs e)
        {
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            DataSet MainDataSet = SessionProxy.MainDataSet;
            TransactionEvent.dropSaleTax_SelectedIndexChanged(MainDataSet.Tables["main_Vw"],
                                                              MainDataSet.Tables["tax_vw1"],
                                                              MainDataSet.Tables["item_Vw"],
                                                              MainDataSet.Tables["dcmast_vw"],
                                                              MainDataSet.Tables["tax_vw"],
                                                              MainDataSet.Tables["stax_vw"],
                                                              MainDataSet.Tables["company"],
                                                              grdCharges);
            MainDataSet.Dispose();
        }
        protected void btnAllocate_Click(object sender, EventArgs e)
        {
           Button btnAllocate = ((Button)sender);
           GridViewRow row = ((GridViewRow)btnAllocate.NamingContainer);
           DataRow acDetRow = null;
           DataSet MainDataSet = SessionProxy.MainDataSet;
           DataTier DataAcess = new DataTier();
           DataAcess.DataBaseName = SessionProxy.DbName;

           vuTransactionevent TransactionEvent = new vuTransactionevent();
           //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
           acDetRow =   TransactionEvent.btnAllocate_Click(MainDataSet,
                                    GridAccount,
                                    row.RowIndex,
                                    acDetRow);

           decimal oTds = TransactionEvent.OTds;
           decimal oDisc = TransactionEvent.ODisc; 

           if (TransactionEvent.ErrorMessage != "" && TransactionEvent.ErrorMessage != null)
           {
               DisplayMessage(TransactionEvent.ErrorMessage);
               TransactionEvent.ErrorMessage = "";
               return;
           }

           if (TransactionEvent.Narration != "" && TransactionEvent.Narration != null)
           {
               string alertMess = "";
               alertMess = "Existing Narration     : \n " + Convert.ToString(acDetRow["narr"]).Trim() + "\n\n ";
               alertMess += "Regenerated Narration : \n" + TransactionEvent.Narration.Trim() + "\n\n";
               alertMess += "Proceed with Regeneration ? ";
               ScriptManager.RegisterStartupScript(Page, Page.GetType(), "narrMess", "narrMess('" + alertMess + "');", true);
               if (hidDateValid.Value == "1")
               {
                   vuAllocation getAllocation = new vuAllocation();
                   //getAllocation.PageCustProps = SessionProxy.PageCustomProps;  
                   getAllocation.autoAllocAlert(acDetRow, 
                                true,
                                TransactionEvent.EditNarration,
                                TransactionEvent.Narration.Trim());
                   hidDateValid.Value = "";
               }
           }
           SessionProxy.TmpMallDtSess = MainDataSet.Tables["tmpMall_vw"];
           SessionProxy.MainDtSess = MainDataSet.Tables["Mall_vw"];
           SessionProxy.MainDtSess = MainDataSet.Tables["main_vw"];

           DataAcess.Connclose(connHandle);

           string strOpenWin  = "";
           strOpenWin = "OpenDialog('" + "Allocation.aspx?pcvType=" + DBPropsSession.PcvType.Trim() +
                        "&addMode=" + Convert.ToString(DBPropsSession.AddMode) + "&editMode=" +
                        Convert.ToString(DBPropsSession.EditMode) + 
                        "&vAmt=" + Convert.ToString(acDetRow["amount"]).Trim() + 
                        "&acName=" + Convert.ToString(acDetRow["ac_name"]).Trim() + 
                        "','','" + 
                        hiddVuAcBal.ClientID + "','" + 
                        btnHiddenPerson.ClientID + "');";
           
            ScriptManager.RegisterStartupScript(this, this.GetType(), "openDialoge()", strOpenWin, true);
            hiddOTDS.Value = Convert.ToString(oTds);
            hiddODISC.Value = Convert.ToString(oDisc);
            SessionProxy.AcdetRowCess = acDetRow;  // Store DataRow in Session Variable
            MainDataSet.Dispose(); 
        }

        protected void btnHiddenPerson_Click(object sender, EventArgs e)
        {
           DataSet MainDataSet = SessionProxy.MainDataSet;
           numericFunction numFunction = new numericFunction();

           MainDataSet.Tables.Remove("mall_vw");
           MainDataSet.Tables.Remove("tmpMall_vw");
           MainDataSet.Tables.Add((DataTable)SessionProxy.MallDtSess);
           MainDataSet.Tables.Add((DataTable)SessionProxy.TmpMallDtSess);
           MainDataSet.AcceptChanges();


           DataRow acDetRow = SessionProxy.AcdetRowCess;

           vuAllocation Allocation = new vuAllocation();
           Allocation.AfterCloseAllocationWindow(DBPropsSession.AddMode,
                    DBPropsSession.EditMode,
                    DBPropsSession.PcvType, 
                    MainDataSet.Tables["main_vw"], 
                    MainDataSet.Tables["item_vw"], 
                    MainDataSet.Tables["lcode_vw"], 
                    MainDataSet.Tables["acdet_vw"], 
                    MainDataSet.Tables["tmpMall_vw"], 
                    MainDataSet.Tables["Mall_vw"], 
                    numFunction.toDecimal(hiddVuAcBal.Value),
                    numFunction.toDecimal(hiddOTDS.Value), 
                    numFunction.toDecimal(hiddODISC.Value), 
                    acDetRow, 
                    MainDataSet.Tables["Company"]);

           GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
           GridAccount.DataBind();

           SessionProxy.MainDataSet = MainDataSet; // Again Add DataSet in
           // Session Variable
           MainDataSet.Dispose();
        }

        protected void grdAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }
        protected void grdAllocation_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton imgBtn = (ImageButton)e.Row.FindControl("imgCollapsible");
                if (imgBtn != null)
                    imgBtn.Attributes.Add("onClick", "javascript: return ShowHide('div" + Convert.ToString(e.Row.RowIndex) + "','" + imgBtn.ClientID + "');");
                  

            }
        }


        protected void grdAllocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            //TransactionEvent.grdAllocation_SelectedIndexChanged(GridAccount,
            //    MainDataSet,
            //    sender);

            //if (TransactionEvent.ErrorMessage != "")
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + TransactionEvent.ErrorMessage + "');", true);
            //}   

            //vuAllocation getAllocation = new vuAllocation();
            //if (TransactionEvent.Narration != "")
            //{
            //    string alertMess = "";
            //    alertMess = "Existing Narration     : \n " + Convert.ToString(TransactionEvent.AcdetRowVar["narr"]).Trim()+ "\n\n ";
            //    alertMess += "Regenerated Narration : \n" + TransactionEvent.Narration.Trim() + "\n\n";
            //    alertMess += "Proceed with Regeneration ? ";
            //    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "narrMess", "narrMess('" + alertMess + "');", True);
            //    if (hidDateValid.Value == "1")
            //        getAllocation.autoAllocAlert(TransactionEvent.AcdetRowVar, true, TransactionEvent.EditNarration,TransactionEvent.Narration.Trim());
            //}

            //getAllocation.vuAllocationInit(((GridView)row.FindControl("gridForAllocation")),
            //                                MainDataSet.Tables("tmpMall_vw"), 
            //                                MainDataSet.Tables("main_vw"), 
            //                                ((CheckBox)(row.FindControl("chkAllocExcess")), 
            //                                SessionProxy.PageCustomProps.PcvType, 
            //                                SessionProxy.PageCustomProps.AddMode, 
            //                                SessionProxy.PageCustomProps.EditMode, 
            //                                Convert.ToDecimal(TransactionEvent.AcdetRowVar["amount"]), 
            //                                ((Label)(row.FindControl("lblAmount"))),
            //                                ((Label)row.FindControl("lblTotAlloc")),
            //                                ((Label)row.FindControl("lblBalance")))); 
            //((GridView)row.FindControl("gridForAllocation")).DataSource = MainDataSet.Tables("tmpMall_vw");
            //((GridView)row.FindControl("gridForAllocation")).DataBind();

        //    If DBNull.Value.Equals(row) = True Then
        //        Exit Sub
        //    End If
        
                    
        }
        protected void txtAccNetAmount_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            try
            {
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                TransactionEvent.txtAccNetAmount_TextChanged(MainDataSet.Tables["main_vw"],
                                MainDataSet.Tables["acdet_vw"],
                                MainDataSet.Tables["item_vw"],
                                MainDataSet.Tables["lcode_vw"],
                                GridAccount,
                                grdlAllocDet,
                                LinkAcAdd,
                                txtAccNetAmount,
                                null);

                SessionProxy.MainDataSet = MainDataSet;  
            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
                return;
            }
            finally
            {
                MainDataSet.Dispose();
            }
        }

        protected void txtHtAcName_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            try
            {
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                TransactionEvent.dropBPName_SelectedIndexChanged(txtHtAcName,
                    DropHTDRCR,
                    lblHTAcBalAmt,
                    MainDataSet.Tables["acdet_vw"],
                    MainDataSet.Tables["company"],
                    MainDataSet.Tables["main_vw"],
                    txtHTAddAmt);

                SessionProxy.MainDataSet = MainDataSet;

                if (lblHTAcBalAmt.Text != "")
                    hiddHTAcBal.Value = "GET";

            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
            }
            finally
            {
                MainDataSet.Dispose();
            }

        }

        //protected void LinkItemAdd_Click(object sender, EventArgs e)
        //{
           

        //    GenGridItemRows(grdItemColView);
        //    //pnlItDetails.Visible = true;
        //    btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");
        //}

        protected void btnitadd_Click(object sender, EventArgs e)
        {
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            //TransactionEvent.btnitadd_Click(MainDataSet,
            //    grdCharges,
            //    GridAccount,
            //    GridItem,
            //    grdlAllocDet,
            //    grdStockStatus,
            //    tblItemTotal,
            //    tblAddItem,
            //    txtGrossAmt,
            //    txtdedBefTax,
            //    txtTaxCharges,
            //    txtExAmt,
            //    txtAddCharges,
            //    txtTaxAmt,
            //    txtNonTax,
            //    txtfdisc,
            //    txtRoundoff,
            //    txtNetAmountTax,
            //    txtItemTotal,
            //    txtTotalQty,
            //    txtNetAmount,
            //    txtAccNetAmount,
            //    txtdate,
            //    txtitqty,
            //    txtitrate,
            //    dropItem);


            vouGridFill gridFill = new vouGridFill();
            DataSet MainDataSet = SessionProxy.MainDataSet;
            gridFill.gridBindAllocation(grdlAllocDet, MainDataSet.Tables["acdet_vw"]);
            MainDataSet.Dispose(); 
        }

        protected void GridItem_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            //DataSet test = MainDataSet;
            //TransactionEvent.GridItem_RowDeleting(MainDataSet,
            //        GridItem,
            //        grdStockStatus,
            //        grdCharges,
            //        GridAccount,
            //        grdlAllocDet,
            //        e.RowIndex,
            //        txtItemTotal,
            //        txtTotalQty,
            //        txtNetAmount,
            //        txtAccNetAmount,
            //        txtGrossAmt,
            //        txtdedBefTax,
            //        txtTaxCharges,
            //        txtExAmt,
            //        txtAddCharges,
            //        txtTaxAmt,
            //        txtNonTax,
            //        txtfdisc,
            //        txtRoundoff,
            //        txtNetAmountTax); 
 
 
            
        }

        protected void GridItem_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;

            GridItem.PageIndex = e.NewPageIndex;  
            GridItem.DataSource = MainDataSet.Tables["item_vw"];
            GridItem.DataBind();
            MainDataSet.Dispose(); 
        }

        protected void LinkAcAdd_Click(object sender, EventArgs e)
        {
            tblAcAdd.Visible = true;
            //trAcAddBal.Visible = false;
            //vouFillDropdownList voufilldrops = new vouFillDropdownList();
            //DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            //if (txtPartyNameB.Visible == true ||
            //    (strFunction.InList(SessionProxy.PageCustomProps.PcvType, new string[] { "DN", "CN","JV","PC" }) == true ||
            //    strFunction.InList(SessionProxy.PageCustomProps.Behave, new string[] { "DN", "CN","JV","PC" }) == true))
            //    voufilldrops.fillDropDownList(dropHTAcName,
            //            "--Select Party Name--",
            //            "ac_id",
            //            "ac_name",
            //            "PARTY",
            //            SessionProxy.PageCustomProps.PcvType,
            //            SessionProxy.PageCustomProps.Behave,
            //            MainDataSet.Tables["lcode_vw"],
            //            "ac_name,ac_id", 0,SessionProxy.PageCustomProps.Vchkprod);

            //DropHTDRCR.Focus();
            txtHtAcName.Focus(); 
            txtHTAddAmt.Text = "0.00";
            //txtHTAddAmt.Attributes["onfocus"] = "this.select();";
        }

        protected void btnAddSave_Click(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            try
            {
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                TransactionEvent.btnAddSave_Click(MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["acdet_vw"],
                        MainDataSet.Tables["lcode_vw"],
                        GridAccount,
                        grdlAllocDet,
                        DropHTDRCR,
                        txtHtAcName,
                        tblAcAdd,
                        txtHTAddAmt);

                SessionProxy.MainDataSet = MainDataSet;

            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
            }
            finally
            {
                MainDataSet.Dispose(); 
            }
        }

        protected void GridAccount_RowCommand(object sender, GridViewCommandEventArgs e)
        {
           
            switch (e.CommandName.Trim().ToUpper())
            {
                //case "EDIT":
                //    numericFunction numFunction = new numericFunction();

                //    string acId = ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblacId")).Text.Trim();
                //    string amt =  ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblAmount")).Text.Trim();
                //    string amtType = ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblAmtType")).Text.Trim();
                //    string narr = ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblNarr")).Text.Trim();
                //    GridAccount.EditIndex = row.RowIndex;
                //    GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
                //    GridAccount.DataBind();
 
                //    vouFillDropdownList voufilldrops = new vouFillDropdownList();
                //    DropDownList dropBPName = (DropDownList)GridAccount.Rows[row.RowIndex].FindControl("dropETAcName");
                //    DropDownList dropDrCr = (DropDownList)GridAccount.Rows[row.RowIndex].FindControl("DropETDRCR");
                     
                //    voufilldrops.fillDropDownList(dropBPName,
                //                                   "--Select Party Name--",
                //                                   "ac_id",
                //                                   "ac_name",
                //                                   "ACCOUNT",
                //                                   SessionProxy.PageCustomProps.PcvType,
                //                                   SessionProxy.PageCustomProps.Behave,
                //                                   MainDataSet.Tables["lcode_vw"],
                //                                   "ac_name,ac_id", 0);


                //    TextBox txtAddAmt = (TextBox)GridAccount.Rows[row.RowIndex].FindControl("txtETAddAmt");
                //    TextBox txtNarr = (TextBox)GridAccount.Rows[row.RowIndex].FindControl("txtETNarr");
                //    dropBPName.SelectedValue = acId.Trim();
                //    txtAddAmt.Text = amt.Trim();
                //    txtNarr.Text = narr.Trim();  
                //    dropDrCr.SelectedValue = amtType.Trim(); 
                //    txtAddAmt.Attributes["onfocus"] = "this.select();";
                //    break; 
                case "DELETE":
                    DataSet MainDataSet = SessionProxy.MainDataSet;
                    try
                    {
                        GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                        vuTransactionevent TransactionEvent = new vuTransactionevent();
                        //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                        TransactionEvent.GridAccount_RowDeleting(MainDataSet.Tables["acdet_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            MainDataSet.Tables["mall_vw"],
                            GridAccount,
                            grdlAllocDet,
                            MainDataSet.Tables.Contains("mall_vw"),
                            row.RowIndex);

                        SessionProxy.MainDataSet = MainDataSet;
                    }
                    catch (Exception Ex)
                    {
                        MessageErrorDisp(Ex);
                    }
                    finally
                    {
                        MainDataSet.Dispose();
                    }
                    break;
            }
        }

        protected void GridAccount_RowEditing(object sender, GridViewEditEventArgs e)
        {
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();
            string acName = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblAcName")).Text.Trim();
            string amt = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblAmount")).Text.Trim();
            string amtType = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblAmtType")).Text.Trim();
            string narr = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblNarr")).Text.Trim();

            GridAccount.EditIndex = e.NewEditIndex;
            DataSet MainDataSet = SessionProxy.MainDataSet;

            vouGridFill vouGridInit = new vouGridFill();
            GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
            string[] grdCols = vouGridInit.grdAccountColSHide(MainDataSet.Tables["lcode_vw"]);
            vouGridInit.gridBind(GridAccount, grdCols);

            vouFillDropdownList voufilldrops = new vouFillDropdownList();
            TextBox txtBPName = (TextBox)GridAccount.Rows[e.NewEditIndex].FindControl("txtETAcName");
            DropDownList dropDrCr = (DropDownList)GridAccount.Rows[e.NewEditIndex].FindControl("DropETDRCR");

            //voufilldrops.fillDropDownList(dropBPName,
            //                               "--Select Party Name--",
            //                               "ac_id",
            //                               "ac_name",
            //                               "ACCOUNT",
            //                               SessionProxy.PageCustomProps.PcvType,
            //                               SessionProxy.PageCustomProps.Behave,
            //                               MainDataSet.Tables["lcode_vw"],
            //                               "ac_name,ac_id", 0, SessionProxy.PageCustomProps.Vchkprod);


            NumericTextBox txtAddAmt = (NumericTextBox)GridAccount.Rows[e.NewEditIndex].FindControl("txtETAddAmt");
            TextBox txtNarr = (TextBox)GridAccount.Rows[e.NewEditIndex].FindControl("txtETNarr");
            txtBPName.Text = acName.Trim();
            txtAddAmt.Text = amt.Trim();
            txtNarr.Text = narr.Trim();
            dropDrCr.SelectedValue = amtType.Trim();
            MainDataSet.Dispose(); 
            //txtAddAmt.Attributes["onfocus"] = "this.select();";

           

  
        }
        protected void GridAccount_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow)
                return;

            int lastcellindex = 1;
            ImageButton deleteButton = new ImageButton();
            deleteButton.CommandName = "DELETE"; 
            deleteButton = ((ImageButton)e.Row.Cells[lastcellindex].Controls[1]);
            deleteButton.OnClientClick = "if (!window.confirm('Are you sure you want to delete this A/c?')) return false;";
        }

        protected void GridAccount_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //try
            //{
            //    TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            //    TransactionEvent.GridAccount_RowDeleting(MainDataSet.Tables["acdet_vw"],
            //        MainDataSet.Tables["lcode_vw"],
            //        MainDataSet.Tables["mall_vw"],
            //        GridAccount,
            //        grdlAllocDet,
            //        MainDataSet.Tables.Contains("mall_vw"),
            //        e.RowIndex);
            //}
            //catch (Exception Ex)
            //{
            //    MessageErrorDisp(Ex); 
            //}
        }

        protected void LoadTab(object sender, EventArgs e)
        {
               switch (((LinkButton)sender).ID)
                {
                    case "lnkTab1":
                        lnkTab1.CssClass = "activeTab";
                        lnkTab2.CssClass = "";
                        lnkTab3.CssClass = "";
                        lnkTab4.CssClass = "";
                        pnlItemDetails.Visible = true; 
                        pnlTaxCharges.Visible = false; 
                        pnlAccountDetails.Visible = false; 
                        pnlAllocationDetails.Visible = false; 
                        break;
                    case "lnkTab2":
                        lnkTab2.CssClass = "activeTab";
                        lnkTab1.CssClass = "";
                        lnkTab3.CssClass = "";
                        lnkTab4.CssClass = ""; 
                        pnlItemDetails.Visible = false;
                        pnlTaxCharges.Visible = true;
                        pnlAccountDetails.Visible = false;
                        pnlAllocationDetails.Visible = false;
                        break;
                    case "lnkTab3":
                        lnkTab3.CssClass = "activeTab";
                        lnkTab1.CssClass = "";
                        lnkTab2.CssClass = "";
                        lnkTab4.CssClass = "";
                        pnlItemDetails.Visible = false;
                        pnlTaxCharges.Visible = false;
                        pnlAccountDetails.Visible = true;
                        pnlAllocationDetails.Visible = false;
                        break;
                     case "lnkTab4":
                        lnkTab4.CssClass = "activeTab";
                        lnkTab1.CssClass = "";
                        lnkTab2.CssClass = "";
                        lnkTab3.CssClass = "";
                        pnlItemDetails.Visible = false;
                        pnlTaxCharges.Visible = false;
                        pnlAccountDetails.Visible = false;
                        pnlAllocationDetails.Visible = true;
                        break;
                }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblTrType.Text = "uu";
        }

        protected void DropInvSer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            txtInvNo.Text = "";
            MainDataSet.Tables["main_vw"].Rows[0]["inv_no"] = "";
            MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"] = DropInvSer.SelectedIndex == 0 ? "" : DropInvSer.SelectedItem.ToString().Trim();
            MainDataSet.Tables["main_vw"].AcceptChanges(); 
            vuInit initProc = new vuInit();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode,
                    DBPropsSession.EditMode,
                    DBPropsSession.Entry_Tbl,
                    MainDataSet.Tables["main_vw"],
                    MainDataSet.Tables["lcode_vw"],
                    "SERIES");
            txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            SessionProxy.MainDataSet = MainDataSet;
            DataAcess.Connclose(connHandle);
        }

       

        protected void dropItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextBox txtItem = ((TextBox)((Control)sender).Parent.Parent.FindControl("txt_item"));
            NumericTextBox txtQty = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("num_qty"));
            NumericTextBox txtRate = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("num_rate"));
            GridView grdStock = ((GridView)((Control)sender).Parent.Parent.FindControl("grdStock"));
            HiddenField hidBalQty = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidbalQty"));
            HiddenField hidDropItemTag = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidDropItemTag"));
            HiddenField hidInvStk = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidInvStk"));
            HiddenField hidNegItBal = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidNegItBal"));
            HiddenField hidNonStk = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidNonStk"));

            vuTransactionevent TransactionEvent = new vuTransactionevent();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            DataSet MainDataSet = SessionProxy.MainDataSet;  
            try
            {
                TransactionEvent.dropItem_SelectedIndexChanged(txtItem,
                                txtRate,
                                txtQty,
                                grdStock,
                                hidBalQty,
                                hidDropItemTag,
                                hidInvStk,
                                hidNegItBal,
                                hidNonStk,
                                MainDataSet,
                                btnItemUpdate);

                uwTRTrigItemTextChanged TRTrigItemTextChanged = new uwTRTrigItemTextChanged();

                //DisplayMessage(" This is Price list flag:" + SessionProxy.PageCustomProps.ItRate.ToString().Trim());

                //System.Web.Caching.Cache cache = HttpRuntime.Cache;
                //string xmlPath = Convert.ToString(SessionProxy.Company.Rows[0]["dir_nm"]).Trim() +
                //         "\\xml\\ItMast.xml";

                //TRTrigItemTextChanged.Item_TextChanged(MainDataSet,
                //    txtItem.Text.Trim(),
                //    xmlPath,
                //    cache,
                //    sender,
                //    e);

                DataAcess.Connclose(connHandle);
            }
            catch (Exception Ex)
            {

                DisplayMessage(Ex.Message.Trim());
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
                txtItem.Text = "";
            }
            finally
            {
                MainDataSet.Dispose();
                DataAcess.Connclose(connHandle);
            }
            //ScriptManager1.SetFocus(txtItem);
        }

        protected void gridForAllocation_RowCreated(object sender, GridViewRowEventArgs e)
        {

        }

        protected void gridForAllocation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView grd = (GridView)((Control)sender);
            DataSet MainDataSet = SessionProxy.MainDataSet;
            grd.PageIndex = e.NewPageIndex;
            grd.DataSource = MainDataSet.Tables["tmpMall_vw"];  
            grd.DataBind();
            MainDataSet.Dispose();
        }

        protected void gridForAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            try
            {
                if (e.CommandName.ToString().ToUpper().Trim() != "SELECT")
                {
                    return;
                }

                int rowIndex = Convert.ToInt32(e.CommandArgument);
               
                GridView grd = (GridView)((Control)sender);
                CheckBox chkAllocExecess = (CheckBox)((Control)sender).Parent.Parent.FindControl("chkAllocExecess");
                Label lblAcName = (Label)((Control)sender).Parent.Parent.FindControl("lblAcName");
                Label lblAmount = (Label)((Control)sender).Parent.Parent.FindControl("lblAmount");
                Label lblTotAlloc = (Label)((Control)sender).Parent.Parent.FindControl("lblTotAlloc");
                Label lblBalance = (Label)((Control)sender).Parent.Parent.FindControl("lblBalance");


                GridViewRow grdRow = grd.Rows[rowIndex];

                string key = grd.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString().Trim();
                ////Dim key As String = Me.GridAccount.DataKeys(CInt(e.CommandArgument)).Value.ToString()
                ////acDetRow = MainDataSet.Tables("acdet_vw").Select("acSerial = '" + key + "'")(0)

                decimal allocate = 0;
                decimal tds = 0;
                decimal disc = 0;

                numericFunction numFunction = new numericFunction();

                allocate = numFunction.toDecimal((((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtnew_all")) == null ? "0" :
                                                ((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtnew_all")).Text));
                tds = numFunction.toDecimal(numFunction.toDecimal((((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txttds")) == null ? "0" :
                                           ((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txttds")).Text)));
                disc = numFunction.toDecimal((((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtdisc")) == null ? "0" :
                                            ((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtdisc")).Text));

                DataRow tmpRow = MainDataSet.Tables["tmpMall_vw"].Select("id = '" + key + "'")[0];
                tmpRow["new_all"] = allocate;
                tmpRow["tds"] = tds;
                tmpRow["disc"] = disc;
                tmpRow.AcceptChanges();

                vuAllocation getAllocation = new vuAllocation();


                //getAllocation.PageCustProps = SessionProxy.PageCustomProps;
                if (allocate != 0)
                {
                    getAllocation.allocateTxtBox_TextChanged(DBPropsSession.AddMode,
                                DBPropsSession.EditMode,
                                MainDataSet.Tables["tmpMall_vw"],
                                MainDataSet.Tables["main_vw"],
                                lblAmount,
                                lblTotAlloc,
                                lblBalance,
                                allocate,
                                DBPropsSession.VAmt,
                                numFunction.toDecimal(this.hiddAllocate.Value),
                                chkAllocExecess,
                                tmpRow);
                    DBPropsSession.VchrAmt = getAllocation.VchrAmt;

                    if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                    {
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                        throw new Exception(getAllocation.ErrorMessage.Trim());
                    }

                }

                if (tds != 0)
                {
                    getAllocation.tdsamtTxtBox_TextChanged(DBPropsSession.AddMode,
                                DBPropsSession.EditMode,
                                MainDataSet.Tables["tmpMall_vw"],
                                MainDataSet.Tables["main_vw"],
                                tds,
                                numFunction.toDecimal(this.hiddTds.Value),
                                DBPropsSession.VAmt,
                                tmpRow);

                    if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                    {
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                        throw new Exception(getAllocation.ErrorMessage.Trim());
                    }

                }

                if (disc != 0)
                {
                    getAllocation.discountTxtBox_TextChanged(DBPropsSession.AddMode,
                            DBPropsSession.EditMode,
                            MainDataSet.Tables["tmpMall_vw"],
                            MainDataSet.Tables["main_vw"],
                            disc,
                            numFunction.toDecimal(this.hiddDisc.Value),
                            DBPropsSession.VAmt,
                            tmpRow);

                    if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                    {
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                        throw new Exception(getAllocation.ErrorMessage.Trim());
                    }
                }
                grd.DataSource = MainDataSet.Tables["tmpMall_vw"];
                grd.DataBind();
                SessionProxy.MainDataSet = MainDataSet;   
            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
            }
            finally
            {
                MainDataSet.Dispose();
                DataTier DataAcess = new DataTier();
                DataAcess.Connclose(connHandle);
            }
        }

        protected void gridForAllocation_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row == null)
                    return;

                if (e.Row.DataItem == null)
                    return;

                if (e.Row.RowType != DataControlRowType.DataRow)
                    return;

                if (e.Row.RowType != DataControlRowType.Header &&
                    e.Row.RowType != DataControlRowType.Footer &&
                    e.Row.RowType != DataControlRowType.Pager)
                {
                    Button btn = new Button();
                    btn = (Button)e.Row.FindControl("btnAlloc");
                    btn.Text = "Allocate";
                    btn.CssClass = "AllocButton";
                    btn.CommandArgument = e.Row.RowIndex.ToString();
                }
                numericFunction numFunction = new numericFunction();

                if (numFunction.toDecimal((((TextBox)e.Row.FindControl("txtnew_all")) == null ? "0" :
                                         ((TextBox)e.Row.FindControl("txtnew_all")).Text)) != 0 ||
                    numFunction.toDecimal((((TextBox)e.Row.FindControl("txttds")) == null ? "0" :
                                         ((TextBox)e.Row.FindControl("txttds")).Text)) != 0 ||
                    numFunction.toDecimal((((TextBox)e.Row.FindControl("txtdisc")) == null ? "0" :
                                         ((TextBox)e.Row.FindControl("txtdisc")).Text)) != 0)
                {
                    e.Row.ForeColor = System.Drawing.Color.Red;
                }

                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#ebebeb'");
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F8F8F8' ");

                NumericTextBox txtTds = ((NumericTextBox)e.Row.FindControl("txttds"));
                if (txtTds != null)
                {
                    if (numFunction.toDecimal(txtTds.Text) != 0)
                    {
                        txtTds.ForeColor = System.Drawing.Color.Red;
                    }

                    txtTds.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddTds.ClientID + "','" + txtTds.ClientID + "')");
                }

                NumericTextBox txtDisc = ((NumericTextBox)e.Row.FindControl("txtdisc"));
                if (txtDisc != null)
                {
                    if (numFunction.toDecimal(txtDisc.Text) != 0)
                    {
                        txtDisc.ForeColor = System.Drawing.Color.Red;
                    }
                    txtDisc.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddDisc.ClientID + "','" + txtDisc.ClientID + "')");
                }

                NumericTextBox txtAllocate = ((NumericTextBox)e.Row.FindControl("txtnew_all"));
                if (txtAllocate != null)
                {
                    if (numFunction.toDecimal(txtAllocate.Text) != 0)
                    {
                        txtAllocate.ForeColor = System.Drawing.Color.Red;
                    }
                    txtAllocate.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddAllocate.ClientID + "','" + txtAllocate.ClientID + "')");
                }
            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex); 
            }
        }

        protected void gridForAllocation_RowEditing(object sender, GridViewEditEventArgs e)
        {
            lblTrType.Text = "test"; 
        }

        protected void imgCollapsible_Click(object sender, ImageClickEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;  
            try
            {
                ImageButton img = (ImageButton)((Control)sender);
                int rowIndex = Convert.ToInt32(img.CommandArgument);
                numericFunction numFunction = new numericFunction();
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                if (img != null)
                {
                    if (img.AlternateText.Trim() == "+")
                    {
                        hiddODISC.Value = "";
                        hiddOTDS.Value = "";
                        hiddFld.Value = "";
                        DataRow AllocDataRow = null;  // null Static DataRow Variable
                        DataRow acDetRow = null;
                        decimal oTds = 0;
                        decimal oDisc = 0;

                        try
                        {
                            DBPropsSession.AllocRowIndex = rowIndex;
                            //TransactionEvent.PageCustProps = DBPropsSession;  
                            acDetRow = TransactionEvent.btnAllocate_Click(MainDataSet,
                                                     grdlAllocDet,
                                                     rowIndex,
                                                     acDetRow);

                            oTds = TransactionEvent.OTds;
                            oDisc = TransactionEvent.ODisc;
                        }
                        catch (Exception EX)
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(rowIndex) + "');", true);
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "SetDivTitle", "SetDivTitle();", true);
                            throw new Exception(EX.Message);
                        }

                        vuAllocation getAllocation = new vuAllocation();
                        //getAllocation.PageCustProps = SessionProxy.PageCustomProps;
                        if (TransactionEvent.Narration != "" && TransactionEvent.Narration != null)
                        {
                            string alertMess = "";
                            alertMess = "Existing Narration     : \n " + Convert.ToString(acDetRow["narr"]).Trim() + "\n\n ";
                            alertMess += "Regenerated Narration : \n" + TransactionEvent.Narration.Trim() + "\n\n";
                            alertMess += "Proceed with Regeneration ? ";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "narrMess", "narrMess('" + alertMess + "');", true);
                            if (hidDateValid.Value == "1")
                            {
                                try
                                {
                                    getAllocation.autoAllocAlert(acDetRow,
                                                 true,
                                                 TransactionEvent.EditNarration,
                                                 TransactionEvent.Narration.Trim());
                                    hidDateValid.Value = "";
                                }
                                catch (Exception Ex)
                                {
                                    throw new Exception(Ex.Message);
                                }
                            }
                        }


                        GridView grd = (GridView)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                        FindControl("TabContainer2").
                                        FindControl("TabPanel1").FindControl("gridForAllocation");
                        CheckBox chk = (CheckBox)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                        FindControl("TabContainer2").
                                        FindControl("TabPanel1").FindControl("chkAllocExecess");
                        Label lblAcName = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                          FindControl("TabContainer2").
                                          FindControl("TabPanel1").FindControl("lblAcName");
                        Label lblAmount = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                          FindControl("TabContainer2").
                                          FindControl("TabPanel1").FindControl("lblAmount");
                        Label lblTotAlloc = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                            FindControl("TabContainer2").
                                            FindControl("TabPanel1").FindControl("lblTotAlloc");
                        Label lblBalance = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                            FindControl("TabContainer2").
                                            FindControl("TabPanel1").FindControl("lblTotAlloc");


                        getAllocation.vuAllocationGridInit(grd,
                                        MainDataSet.Tables["tmpMall_vw"],
                                        MainDataSet.Tables["main_vw"],
                                        chk,
                                        DBPropsSession.PcvType,
                                        DBPropsSession.AddMode,
                                        DBPropsSession.EditMode,
                                        DBPropsSession.ChargesPage,
                                        numFunction.toDecimal(acDetRow["amount"]),
                                        lblAmount,
                                        lblTotAlloc,
                                        lblBalance,
                                        false);
                        DBPropsSession.VAmt = getAllocation.VAmt; // set static variable of Page 
                        DBPropsSession.FromAcAmt = getAllocation.FromAcAmt;

                        lblAcName.Text = Convert.ToString(acDetRow["ac_name"]).Trim();

                        grd.DataSource = MainDataSet.Tables["tmpMall_vw"];
                        grd.DataBind();

                        //((TabContainer)grdAllocation.Rows[rowIndex].FindControl("TabContainer2")).Visible = true;

                        ((Panel)grdlAllocDet.Rows[rowIndex].FindControl("Panel3")).Visible = true;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(rowIndex) + "');", true);

                        DBPropsSession.IsOpenGridForAllocation = true;
                        img.AlternateText = "-";
                        img.ImageUrl = "~/img/minus.png";
                        hiddFld.Value = "1";
                        AllocDataRow = acDetRow; // pass DataRow value to Static Variable 
                        hiddODISC.Value = Convert.ToString(oDisc); // Pass Data in hidden field
                        hiddOTDS.Value = Convert.ToString(oTds); // Pass Data in hidden field

                        Button btnOk = (Button)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                        FindControl("TabContainer2").
                                        FindControl("TabPanel1").FindControl("btnAllocDone");

                        btnOk.Attributes.Add("onClick", "javascript: return ShowHide('div" + Convert.ToString(rowIndex) + "','" + btnOk.ClientID + "');");
                        SessionProxy.AllocDataRow = AllocDataRow;
                    }
                    else
                    {
                        if (img.AlternateText == "-")
                        {
                            vuAllocation getAllocation = new vuAllocation();
                            DataRow AllocDataRow = (DataRow)SessionProxy.AllocDataRow;
                            //getAllocation.PageCustProps = SessionProxy.PageCustomProps;
                            getAllocation.ErrorMessage = "";
                            getAllocation.AfterCloseAllocationWindow(DBPropsSession.AddMode,
                                           DBPropsSession.EditMode,
                                           DBPropsSession.PcvType,
                                           MainDataSet.Tables["main_vw"],
                                           MainDataSet.Tables["item_vw"],
                                           MainDataSet.Tables["lcode_vw"],
                                           MainDataSet.Tables["acdet_vw"],
                                           MainDataSet.Tables["tmpMall_vw"],
                                           MainDataSet.Tables["mall_vw"],
                                           DBPropsSession.VchrAmt,
                                           numFunction.toDecimal(hiddOTDS.Value),
                                           numFunction.toDecimal(hiddODISC.Value),
                                           AllocDataRow,
                                           MainDataSet.Tables["Company"]);

                            SessionProxy.AllocDataRow = AllocDataRow;
                            if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                            {
                                DisplayMessage(getAllocation.ErrorMessage);
                                getAllocation.ErrorMessage = "";
                            }

                            ((Panel)grdlAllocDet.Rows[rowIndex].FindControl("Panel3")).Visible = false;
                            img.AlternateText = "+";
                            img.ImageUrl = "~/img/plus.png";

                            GridView grd = (GridView)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                      FindControl("TabContainer2").
                                      FindControl("TabPanel1").FindControl("gridForAllocation");
                            CheckBox chk = (CheckBox)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                            FindControl("TabContainer2").
                                            FindControl("TabPanel1").FindControl("chkAllocExecess");
                            Label lblAcName = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                              FindControl("TabContainer2").
                                              FindControl("TabPanel1").FindControl("lblAcName");
                            Label lblAmount = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                              FindControl("TabContainer2").
                                              FindControl("TabPanel1").FindControl("lblAmount");
                            Label lblTotAlloc = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                                FindControl("TabContainer2").
                                                FindControl("TabPanel1").FindControl("lblTotAlloc");
                            Label lblBalance = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                                FindControl("TabContainer2").
                                                FindControl("TabPanel1").FindControl("lblTotAlloc");

                            DBPropsSession.IsOpenGridForAllocation = false;
                            grd.Columns.Clear();
                            grd.Dispose();
                            chk.Checked = false;
                            lblAcName.Text = "";
                            lblAmount.Text = "";
                            lblBalance.Text = "";
                            lblTotAlloc.Text = "";
                            hiddODISC.Value = "";
                            hiddOTDS.Value = "";
                            hiddFld.Value = "";

                            ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(rowIndex) + "');", true);
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "SetDivTitle", "SetDivTitle();", true);

                        }
                    }

                    SessionProxy.MainDataSet = MainDataSet;  
                }
            }
            catch (Exception EX)
            {
                MessageErrorDisp(EX);
                DisplayMessage(EX.Message.Trim());
            }
            finally
            {
                MainDataSet.Dispose();
                DataTier DataAcess = new DataTier();
                DataAcess.Connclose(connHandle);
            }
        }

        protected void chkAllocExecess_CheckedChanged(object sender, EventArgs e)
        {
            numericFunction numFunction = new numericFunction();
            decimal vchrBal1 = numFunction.toDecimal(((Label)((Control)sender).Parent.FindControl("lblTotAlloc")).Text);
            if (((CheckBox)(Control)sender).Checked == true)
            {
                DBPropsSession.VchrAmt = vchrBal1;
            }
            else
            {
                DBPropsSession.VchrAmt  = DBPropsSession.FromAcAmt;
            }

        }

        protected void gridBindAfterPostback(int rowIndex)
        {
            GridView grd = (GridView)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                FindControl("TabContainer2").
                FindControl("TabPanel1").FindControl("gridForAllocation");
            CheckBox chk = (CheckBox)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                            FindControl("TabContainer2").
                            FindControl("TabPanel1").FindControl("chkAllocExecess");
            Label lblAcName = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                              FindControl("TabContainer2").
                              FindControl("TabPanel1").FindControl("lblAcName");
            Label lblAmount = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                              FindControl("TabContainer2").
                              FindControl("TabPanel1").FindControl("lblAmount");
            Label lblTotAlloc = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                FindControl("TabContainer2").
                                FindControl("TabPanel1").FindControl("lblTotAlloc");
            Label lblBalance = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                FindControl("TabContainer2").
                                FindControl("TabPanel1").FindControl("lblTotAlloc");


            DataSet MainDataSet = SessionProxy.MainDataSet;

            vuAllocation getAllocation = new vuAllocation();
            //getAllocation.PageCustProps = SessionProxy.PageCustomProps; 
            getAllocation.vuAllocationGridInit(grd,
                            MainDataSet.Tables["tmpMall_vw"],
                            MainDataSet.Tables["main_vw"],
                            chk,
                            DBPropsSession.PcvType,
                            DBPropsSession.AddMode,
                            DBPropsSession.EditMode,
                            DBPropsSession.ChargesPage,
                            DBPropsSession.VAmt,
                            lblAmount,
                            lblTotAlloc,
                            lblBalance,
                            true);

            //vAmt = getAllocation.VAmt; // set static variable of Page 

            //lblAcName.Text = Convert.ToString(acDetRow["ac_name"]).Trim();
            grd.DataSource = MainDataSet.Tables["tmpMall_vw"];
            grd.DataBind();
            SessionProxy.MainDataSet = MainDataSet;  
            MainDataSet.Dispose();

        }

        protected void btnAllocDone_Click(object sender, EventArgs e)
        {
            vuAllocation getAllocation = new vuAllocation();
            //getAllocation.PageCustProps = SessionProxy.PageCustomProps;
            DataSet MainDataSet = SessionProxy.MainDataSet;
            DataRow AllocDataRow = SessionProxy.AllocDataRow;  
            getAllocation.AfterCloseAllocationWindow(DBPropsSession.AddMode,
                           DBPropsSession.EditMode,
                           DBPropsSession.PcvType,
                           MainDataSet.Tables["main_vw"],
                           MainDataSet.Tables["item_vw"],
                           MainDataSet.Tables["lcode_vw"],
                           MainDataSet.Tables["acdet_vw"],
                           MainDataSet.Tables["tmpMall_vw"],
                           MainDataSet.Tables["mall_vw"],
                           DBPropsSession.VchrAmt,
                           Convert.ToDecimal((hiddOTDS.Value == string.Empty ? "0":hiddOTDS.Value)),
                           Convert.ToDecimal((hiddODISC.Value == string.Empty ? "0":hiddODISC.Value)),
                           AllocDataRow,
                           MainDataSet.Tables["Company"]);

            SessionProxy.AllocDataRow = AllocDataRow;
            SessionProxy.MainDataSet = MainDataSet;  
            GridView grd = (GridView)((Control)sender).Parent.FindControl("gridForAllocation");
            CheckBox chk = (CheckBox)((Control)sender).Parent.FindControl("chkAllocExecess");
            Label lblAcName = (Label)((Control)sender).Parent.FindControl("lblAcName");
            Label lblAmount = (Label)((Control)sender).Parent.FindControl("lblAmount");
            Label lblTotAlloc = (Label)((Control)sender).Parent.FindControl("lblTotAlloc");
            Label lblBalance = (Label)((Control)sender).Parent.FindControl("lblTotAlloc");

            ((Panel)((Control)sender).Parent.Parent.Parent.Parent).Visible = false;
            ImageButton img = (ImageButton)((Control)sender).Parent.Parent.Parent.
                              Parent.Parent.FindControl("imgCollapsible");
            
            img.AlternateText = "+";
            img.ImageUrl = "~/img/plus.png";
            //Dispose all objects
            grd.Columns.Clear(); 
            grd.Dispose();

            DBPropsSession.IsOpenGridForAllocation = false;
            chk.Checked = false;
            lblAcName.Text = "";
            lblAmount.Text = "";
            lblBalance.Text = "";
            lblTotAlloc.Text = "";
            hiddODISC.Value = "";
            hiddOTDS.Value = "";
            hiddFld.Value = "";
            MainDataSet.Dispose();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(DBPropsSession.AllocRowIndex) + "');", true);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "SetDivTitle", "SetDivTitle();", true);

             
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;  
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            try
            {
                vuSave updateTrans = new vuSave();
                bool isSave = false;
                stringFunction strFunction = new stringFunction();
                //updateTrans.PageCustProps = DBPropsSession;
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "BR", "BP", "CR", "CP" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "BR", "BP", "CR", "CP" }) == true)
                {
                    isSave = updateTrans.Saveit(txtDateB,
                                       txtPartyNameB,
                                       txtBankName,
                                       cboInvSeriesB,
                                       cboCategoryB,
                                       cboDepartMentB,
                                       null,
                                       txtInvoiceNoB,
                                       txtNetAmount,
                                       MainDataSet,
                                       this,
                                       hidDateValid,
                                       txtBillNo,
                                       txtBillDate,
                                       txtNarr,
                                       txtNarrB,
                                       txtChequeNoB,
                                       txtDrawnOnB);


                }
                else
                {
                    isSave = updateTrans.Saveit(txtdate,
                                       txtPartyName,
                                       null,
                                       DropInvSer,
                                       cboCategory,
                                       cboDepartMent,
                                       cboRule,
                                       txtInvNo,
                                       txtNetAmount,
                                       MainDataSet,
                                       this,
                                       hidDateValid,
                                       txtBillNo,
                                       txtBillDate,
                                       txtNarr,
                                       txtNarrB,
                                       txtChequeNoB,
                                       txtDrawnOnB);
                }
                SessionProxy.MainDataSet = MainDataSet;

                if (isSave == true)
                {
                    lblSaveMessTop.Visible = true;
                    lblSaveMessTop.Text = "Record has been saved sucessfully...";
                    lblSaveMessBottom.Visible = true;
                    lblSaveMessBottom.Text = "Record has been saved sucessfully...";
                    //EnableDisableControls(Page, false);
                    //ControlShouldbeEnabled(true);
                    //liEdit.Style.Clear();

                    tdErrorMess.Visible = false;
                    DBPropsSession.EditMode = false;
                    DBPropsSession.AddMode = false;
                    DBPropsSession.InitStartWithTranCd = 0;

                    SessionsRemove(); // Remove existing Session Variables
                    Response.Redirect("uwTransactionList.aspx?pcvtype=" + DBPropsSession.PcvType.Trim());

                }
            }
            catch (Exception Ex)
            {
                //string genMess = Ex.Message.Trim().Substring(0,Ex.Message.Trim().IndexOf('|')) + "This is a test sss ss sss ";
                //string techMess = Ex.Message.Trim().Substring(Ex.Message.Trim().IndexOf('|')+1, (Ex.Message.Trim().Length - Ex.Message.Trim().IndexOf('|'))-1);
                //lblErrMess.Text = genMess.Trim();
                //if (techMess.Trim() != "")
                //{
                //    cpErrorMess.Enabled = true;
                //    lblErrTechMess.Text = techMess.Trim();
                //    lblErrTechMess.Visible = true;
                //}
                //else
                //{
                //    lblErrTechMess.Visible = false;
                //    cpErrorMess.Enabled = false;
                //}
                //tdErrorMess.Visible = true;
                MessageErrorDisp(Ex);
            }
            finally
            {
                MainDataSet.Dispose();
                DataAcess.Connclose(connHandle);              
            }

        }

        protected void MessageErrorDisp(Exception Ex)
        {
            string genMess = "";
            string techMess = "";

            if (Ex.Message.Trim().IndexOf('|') >= 0)
            {
                genMess = Ex.Message.Trim().Substring(0, Ex.Message.Trim().IndexOf('|'));
                techMess = Ex.Message.Trim().Substring(Ex.Message.Trim().IndexOf('|') + 1, (Ex.Message.Trim().Length - Ex.Message.Trim().IndexOf('|')) - 1);
            }
            else
                genMess = Ex.Message.Trim();  
                

            lblErrMess.Text = genMess.Trim();
            if (techMess.Trim() != string.Empty)
            {
                //cpErrorMess.Enabled = true;
                lblErrTechMess.Text = techMess.Trim();
                lblErrTechMess.Visible = true;
            }
            else
            {
                lblErrTechMess.Visible = true;
                lblErrTechMess.Text = "No Technical Error found...";  
                //lblErrTechMess.Visible = false;
                //cpErrorMess.Enabled = false;
            }
            tdErrorMess.Visible = true;
        }

        protected void txtDueDays_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            getDateFormat GetDateFormat = new getDateFormat();
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            //TransactionEvent.PageCustProps = DBPropsSession; 
            TransactionEvent.txtDueDays_TextChanged(txtDueDate,
                                        txtdate,
                                        txtDueDays,
                                        MainDataSet.Tables["main_vw"]);
            SessionProxy.MainDataSet = MainDataSet;
            txtDueDate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["due_dt"]));

        }

        protected void newRec(ref DataSet MainDataSet)
        {
            getTables GetTables = new getTables();
            DBPropsSession.AddMode = true;
            DBPropsSession.EditMode = false;

            stringFunction strFunction = new stringFunction();
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps; 
            boolFunction bitFunction = new boolFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;


            // Below Variable use for Allocation
            DBPropsSession.IsOpenGridForAllocation = false; // always false in postback is false
            DBPropsSession.VAmt = 0; // always false in postback is false
            DBPropsSession.VchrAmt = 0; // always false in postback is false
            DBPropsSession.FromAcAmt = 0; // always false in postback is false
            // End
            
            vuInit initProc = new vuInit();
            initProc.AddNew(MainDataSet.Tables["main_vw"], 
                            MainDataSet.Tables["lcode_vw"], 
                            MainDataSet.Tables["company"], 
                            DBPropsSession.Entry_Tbl.ToString(), 
                            DBPropsSession.PcvType.ToString());

            DBPropsSession.LbackDated = initProc.LbackDated;
            DBPropsSession.LTodaySDate = initProc.LTodaySDate;
            DBPropsSession.PBackDate = initProc.PBackDated;
            DBPropsSession.JustInvoice = "";
            DBPropsSession.JustSeries = "";
            DBPropsSession.EditSeries = "";
            DBPropsSession.EditInvoice = "";
            DBPropsSession.VarETGoDown = "";
            DBPropsSession.VarETGodownTo = "";
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            TransactionEvent.ErrorMessage = "";

            if (strFunction.InList(DBPropsSession.PcvType, new string[] { "OB", "OS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "OB", "OS" }))
            {
                MainDataSet.Tables["main_vw"].Rows[0]["u_choice"] = true;  
            }


            if ((DBPropsSession.PcvType == "BR" || DBPropsSession.PcvType == "BP" || DBPropsSession.PcvType == "CP" || DBPropsSession.PcvType == "CR")
                || (DBPropsSession.Behave == "BR" || DBPropsSession.Behave == "BP" || DBPropsSession.PcvType == "CP" || DBPropsSession.Behave == "CR"))
            {
                if (bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["inv_sr"]) == false)
                {
                    initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode, DBPropsSession.EditMode, DBPropsSession.Entry_Tbl, MainDataSet.Tables["main_vw"], MainDataSet.Tables["lcode_vw"], "BUTTON");
                    txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                }

            }

            //if (SessionProxy.PageCustomProps.ChargesPage == true)
            //{
            //    MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw");
            //    MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw1");
            //}

            if (DBPropsSession.AllocationPage == true)
            {
                if (System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["allo_op"]) == true && System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["acc_adj"]))
                {
                    //MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select * from " + SessionProxy.PageCustomProps.Entry_Tbl.Trim() + "acdet where 1=0", "lal_vw");
                    DataTable lal_vw = MainDataSet.Tables["acdet_vw"];
                    MainDataSet.Tables.Add(lal_vw.Copy());     
                }
            }


            if (tblOtherTran.Visible == true)
            {
                if (txtPartyName.Visible == true && txtPartyName.Enabled == true)
                {
                    //dropParty.SelectedIndex = 0;
                    txtPartyName.Attributes.Add("Onfocus", "javascript:updateHiddenTextField('" + hiddPartyName.ClientID + "','" + txtPartyName.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboCategory.Visible == true && cboCategory.Enabled == true)
                {
                    cboCategory.SelectedIndex = 0;
                }

                if (DropInvSer.Visible == true && DropInvSer.Enabled == true)
                {
                    DropInvSer.SelectedIndex = 0;
                }

                if (cboDepartMent.Visible == true && cboDepartMent.Enabled == true)
                {
                    cboDepartMent.SelectedIndex = 0;
                }

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    cboRule.SelectedIndex = 0;
                }

            }

            if (tblBankTran.Visible == true)
            {
                if (txtPartyNameB.Visible == true && txtPartyNameB.Enabled == true)
                {
                    //txtPartyNameB.SelectedIndex = 0;
                    txtPartyNameB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBnkPartyName.ClientID + "','" + txtPartyNameB.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboInvSeriesB.Visible == true && cboInvSeriesB.Enabled == true)
                {
                    cboInvSeriesB.SelectedIndex = 0;
                }

                if (cboDepartMentB.Visible == true && cboDepartMentB.Enabled == true)
                {
                    cboDepartMentB.SelectedIndex = 0;
                }

                if (txtBankName.Visible == true && txtBankName.Enabled == true)
                {
                    txtBankName.Text = "";
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "BR", "BP" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "BR", "BP" }))
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    else
                    {
                        if (strFunction.InList(DBPropsSession.PcvType, new string[] { "CR", "CP" }) == true ||
                            strFunction.InList(DBPropsSession.Behave, new string[] { "CR", "CP" }))
                            txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    }

                    if (trforBank.Visible == true)
                        txtDrawnOnB.Text = "";
                }

            }

            //vouGridFill vouGridInit = new vouGridFill();
            //if (SessionProxy.PageCustomProps.ItemPage == true)
            //{
            //    vouGridInit.gridItemFill(true, MainDataSet.Tables["lother_vw"], GridItem, MainDataSet.Tables["Item_vw"],
            //                             SessionProxy.PageCustomProps.ChargesPage, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["company"], SessionProxy.PageCustomProps.PcvType,
            //                             SessionProxy.PageCustomProps.Behave, 0);
            //    SessionProxy.PageCustomProps.SalesTaxItem = vouGridInit.SalesTaxItem;
            //}

            //if (SessionProxy.PageCustomProps.AccountPage == true)
            //    vouGridInit.gridAcccountFill(GridAccount, MainDataSet.Tables["acdet_vw"], MainDataSet.Tables["lcode_vw"]);

            //if (SessionProxy.PageCustomProps.AllocationPage == true)
            //{
            //    vouGridInit.gridAllocation(grdlAllocDet, MainDataSet.Tables["lal_vw"], MainDataSet.Tables["acdet_vw"],
            //                               MainDataSet.Tables["company"]);
            //    grdlAllocDet.Columns[0].Visible = false; 
            //}

            //if (SessionProxy.PageCustomProps.ChargesPage == true)
            //    vouGridInit.gridTaxFill(grdCharges, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["lcode_vw"],
            //                            MainDataSet.Tables["tax_vw"], MainDataSet.Tables["tax_vw1"],
            //                            MainDataSet.Tables["main_vw"], MainDataSet.Tables["item_vw"],
            //                            MainDataSet.Tables["company"], MainDataSet.Tables["stax_vw"],
            //                            SessionProxy.PageCustomProps.EditMode, SessionProxy.PageCustomProps.AddMode,
            //                            SessionProxy.PageCustomProps.PcvType, SessionProxy.PageCustomProps.Behave);

            if (DBPropsSession.AinfoPage == true)
            {
                foreach (DataRow lotherRow in MainDataSet.Tables["lother_vw"].Rows)
                {
                    if (Convert.ToBoolean(lotherRow["att_file"]) == true && Convert.ToBoolean(lotherRow["inter_use"]) == false)
                    {
                        DBPropsSession.AinfoPage = true;
                        break;
                    }
                }
            }

            if (DBPropsSession.AinfoPage == true)
            {
                if (MainDataSet.Tables["lother_vw"].Rows.Count > 0)
                {
                    tblAddinfoDet.Visible = true;
                    try
                    {
                        TransactionEvent.AdditionalInfoShow(MainDataSet,
                                    tblAddInfo);
                    }
                    catch (Exception Ex)
                    {
                        tblAddinfoDet.Visible = false;
                        DBPropsSession.AinfoPage = false;
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message + "');", true);
                    }
                }
                else
                {
                    tblAddinfoDet.Visible = false;
                }
            }
            else
            {
                tblAddinfoDet.Visible = false;
            }

            DataAcess.Connclose(connHandle);

           // TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;

            if (DBPropsSession.AddMode)
            {
                getDateFormat GetDateFormat = new getDateFormat();
                if ((DBPropsSession.PcvType == "BR" ||
                   DBPropsSession.PcvType == "BP" ||
                   DBPropsSession.PcvType == "CP" ||
                   DBPropsSession.PcvType == "CR") ||
                   (DBPropsSession.Behave == "BR" ||
                    DBPropsSession.Behave == "BP" ||
                    DBPropsSession.Behave == "CP" ||
                    DBPropsSession.Behave == "CR"))
                {
                    txtDateB.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                    if (txtDateB.Text != "")
                    {
                        TransactionEvent.DateValidation(txtDateB,
                            null,
                            null,
                            trduedt,
                            this.Page,
                            hidDateValid,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["Company"],
                            MainDataSet.Tables["lcode_vw"],
                            MainDataSet.Tables["item_vw"],
                            MainDataSet.Tables["acdet_vw"],
                            true);
                    }
                    txtDateB.Focus();

                }
                else
                {
                    if (DropInvSer.Visible == false || DropInvSer.Enabled == false)
                    {
                        initProc.txtInvoiceNo_GotFocus(DBPropsSession.AddMode,
                                    DBPropsSession.EditMode,
                                    DBPropsSession.Entry_Tbl,
                                    MainDataSet.Tables["main_vw"],
                                    MainDataSet.Tables["lcode_vw"],
                                    "BUTTON");
                        txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                    }

                    txtdate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                    if (txtdate.Text != "")
                    {
                        DateValidation(txtdate,MainDataSet);
                      
                    }
                    txtdate.Focus();
                }


            }
        }

        protected void btnDiscard_Click(object sender, EventArgs e)
        {
            //trOthTranDivParty.Visible = false;
            //trAcAddBal.Visible = false;

            SessionsRemove(); // Remove existing Session Variables
            Response.Redirect("uwTransactionList.aspx?pcvtype=" + DBPropsSession.PcvType);

            //if (SessionProxy.PageCustomProps.AddMode == true && InitStartWithTranCd == 0)
            //{
            //    if (InitStartWithTranCd == 0)
            //    {
            //        Session.Remove("MainDataSet");  
            //        Response.Redirect("vutransactionview.aspx?pcvtype="+SessionProxy.PageCustomProps.PcvType);
            //    }
            //}
            //else
            //{
            //    if (SessionProxy.PageCustomProps.EditMode == true && InitStartWithTranCd != 0)
            //    {
            //        //lnkNew.CssClass = "";
            //        //lnkEdit.CssClass = "";
            //        //lnkDelete.CssClass = "";
            //        //lnkCopy.CssClass = "";
            //        //lnkPrint.CssClass = "";
            //        //EnableDisableControls(Page, false);
            //        //pnlTran.Visible = true;
            //        //pnlPrint.Visible = false;
            //        //txtAccNetAmount.Enabled = false;
            //        //lblSaveMessBottom.Visible = false;
            //        //lblSaveMessTop.Visible = false;
            //        //lnkEdit.Font.Underline = true;
            //        //SessionProxy.PageCustomProps.EditMode = false;
            //        //SessionProxy.PageCustomProps.AddMode = false;  
            //        //ControlShouldbeEnabled(true);

            //        //EnableDisableControls(Page, false);
            //        //pnlTran.Visible = true;
            //        //txtAccNetAmount.Enabled = false;
            //        lblSaveMessBottom.Visible = false;
            //        lblSaveMessTop.Visible = false;
            //        SessionProxy.PageCustomProps.EditMode = true;
            //        Session.Remove("MainDataSet");

            //        DataSet MainDataSet = new DataSet();
            //        DataView grdItemColView = new DataView();
            //        InitGetTables(ref MainDataSet);
            //        EditRec(Convert.ToInt32(InitStartWithTranCd),ref MainDataSet);
            //        BindGridView(ref MainDataSet,ref grdItemColView);

            //        Session["MainDataSet"] = MainDataSet;
            //        Session["GridItemColView"] = grdItemColView;
            //        //ConditionalControlEnabled();
            //        SessionProxy.PageCustomProps.EditMode = false;
            //        SessionProxy.PageCustomProps.AddMode = false;
            //        //ControlShouldbeEnabled(true);
            //    }
            //    else
            //    {
            //        if (SessionProxy.PageCustomProps.AddMode == true || InitStartWithTranCd != 0)
            //        {
            //            //EnableDisableControls(Page, false);
            //            //pnlTran.Visible = true;
            //            //txtAccNetAmount.Enabled = false;
            //            lblSaveMessBottom.Visible = false;
            //            lblSaveMessTop.Visible = false;
            //            SessionProxy.PageCustomProps.EditMode = true;

            //            Session.Remove("MainDataSet");
            //            DataSet MainDataSet = new DataSet();
            //            DataView grdItemColView = new DataView();
            //            InitGetTables(ref MainDataSet);
            //            EditRec(Convert.ToInt32(InitStartWithTranCd),ref MainDataSet);
            //            BindGridView(ref MainDataSet,ref grdItemColView);

            //            Session["MainDataSet"] = MainDataSet;
            //            Session["GridItemColView"] = grdItemColView; 
            //            //ConditionalControlEnabled();
            //            SessionProxy.PageCustomProps.EditMode = false;
            //            SessionProxy.PageCustomProps.AddMode = false;
            //            //ControlShouldbeEnabled(true);
            //        }

            //    }
            //}

        }


        protected void GridItem_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.Trim() == "DELETE")
            {
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                //TransactionEvent.GridItem_RowDeleting(MainDataSet,
                //        GridItem,
                //        grdStockStatus,
                //        grdCharges,
                //        GridAccount,
                //        grdlAllocDet,
                //        row.RowIndex,
                //        txtItemTotal,
                //        txtTotalQty,
                //        txtNetAmount,
                //        txtAccNetAmount,
                //        txtGrossAmt,
                //        txtdedBefTax,
                //        txtTaxCharges,
                //        txtExAmt,
                //        txtAddCharges,
                //        txtTaxAmt,
                //        txtNonTax,
                //        txtfdisc,
                //        txtRoundoff,
                //        txtNetAmountTax);
            }
            else
            {
                if (e.CommandName.Trim() == "EDIT")
                {
                    //vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
                    //GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                    //DataRow editRow;
                    //string key = GridItem.DataKeys[row.RowIndex].Value.ToString();
                    //editRow = MainDataSet.Tables["item_vw"].Select("ItSerial='" + key + "'")[0];
                    
                    //pnlItDetails.Visible = true;
                    //tblItDetails.Visible = true; 
                    //SetGridValue.btnClick(tblItDetails, editRow, "UNBOXING");    
                    
                    //btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");

                }
            }
        }


        private void EnableDisableControls(Control root,bool isflag)
        {
            miscFunctions miscFunc = new miscFunctions();
            miscFunc.EnableDisableControlsRecursive(root, isflag);
            miscFunc.Dispose();
            lnkBack.Enabled = true;
            btnBack.Enabled = true; 
        }

        protected void ControlShouldbeEnabled(bool flag)
        {
            lnkTab1.Enabled = flag;
            lnkTab2.Enabled = flag;
            lnkTab3.Enabled = flag;
            lnkTab4.Enabled = flag;
        }

        protected void ConditionalControlEnabled(ref DataSet MainDataSet)
        {
            getTables GetTables = new getTables();
            stringFunction strFunction = new stringFunction();
            boolFunction bitFunction = new boolFunction();

            if ((DBPropsSession.PcvType == "BR" || DBPropsSession.PcvType == "BP" || DBPropsSession.PcvType == "CP" || DBPropsSession.PcvType == "CR")
                || (DBPropsSession.Behave == "BR" || DBPropsSession.Behave == "BP" || DBPropsSession.PcvType == "CP" || DBPropsSession.Behave == "CR"))
            {
                cboInvSeriesB.Enabled = bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["inv_sr"]);
                cboCategoryB.Enabled = bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["cate"]);
                cboDepartMentB.Enabled = bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["dept"]);

                if (cboDepartMentB.Enabled == false)
                {
                    trBnkDept.Visible = false;
                }
                else
                {
                    trBnkDept.Visible = true;
                }
            }
            else
            {
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DN", "CN" }) == false ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DN", "CN" }) == false)
                    cboRule.Enabled = bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["rule"]);
                else
                    cboRule.Enabled = false;

                DropInvSer.Enabled = bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["inv_sr"]);
                cboCategory.Enabled = bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["cate"]);
                cboDepartMent.Enabled = bitFunction.toBoolean(MainDataSet.Tables["param"].Rows[0]["dept"]);

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    trRule.Visible = true;
                    cboRule.Enabled = true;
                }
                else
                {
                    trRule.Visible = false;
                }

                if (cboCategory.Enabled == true && cboDepartMent.Enabled == true)
                {
                    tdCatDept.Visible = true;
                }
                else
                {
                    tdCatDept.Visible = false;
                }
            }

            if (System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_dbcr"]) == true)
                LinkAcAdd.Enabled = true;
            else
                LinkAcAdd.Enabled = false;

            if ((DBPropsSession.PcvType == "BR" || 
                 DBPropsSession.PcvType == "BP" || 
                 DBPropsSession.PcvType == "CP" || 
                 DBPropsSession.PcvType == "CR" || 
                 DBPropsSession.PcvType == "EP" || 
                 DBPropsSession.PcvType == "PC")|| 
                 (DBPropsSession.Behave == "BR" || 
                  DBPropsSession.Behave == "BP" || 
                  DBPropsSession.PcvType == "CP" || 
                  DBPropsSession.Behave == "CR" || 
                  DBPropsSession.Behave == "EP" || 
                  DBPropsSession.Behave == "PC"))
            {
                txtAccNetAmount.Enabled = true;
            }
            else
            {
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DN", "CN", "JV", "OB" }) == false ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DN", "CN", "JV", "OB" }) == false)
                    txtAccNetAmount.Enabled = false;
                else
                    txtAccNetAmount.Enabled = true;
            }
        }

        protected void GeneralControlEnabled(ref DataSet MainDataSet)
        {
            getTables GetTables = new getTables();
            stringFunction strFunction = new stringFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            if (System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_item"]) == true)
            {
                if (System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["inv_op"]) == false && System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["bill_inven"]) == false)
                {
                    DBPropsSession.ItemPage = false;
                }
                else
                {
                    DBPropsSession.ItemPage = true;
                }
            }

            DBPropsSession.AccountPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_account"]);
            DBPropsSession.ChargesPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_disc"]);
            DBPropsSession.IchargesPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["i_disc"]);
            DBPropsSession.ItRate = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["it_rate"]);

            if (DBPropsSession.AccountPage == true)
            {
                DBPropsSession.AllocationPage = true;
            }

            DBPropsSession.AinfoPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_extra"]);
            DBPropsSession.TdsPage = false;

            if (DBPropsSession.PcvType == "EP" || 
                DBPropsSession.PcvType == "BP" ||
                DBPropsSession.PcvType == "CP")
                DBPropsSession.TdsPage = true;

            DBPropsSession.ServiceTaxPage = false;

            if (DBPropsSession.PcvType == "IS" || DBPropsSession.PcvType == "SB")
            {
                DBPropsSession.ServiceTaxPage = true;
            }

            //if (DBPropsSession.TdsPage == false)
            //{
            //    tdCatDept.Visible = false;
            //}
            //else
            //{
            //    tdCatDept.Visible = true;
            //}

            trduedt.Visible = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_duedt"]);
            trNarration.Visible = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_narr"]);
            trNarrationB.Visible = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_narr"]);

            if ((DBPropsSession.PcvType == "BR" ||
                 DBPropsSession.PcvType == "BP" ||
                 DBPropsSession.PcvType == "CP" ||
                 DBPropsSession.PcvType == "CR")
                || (DBPropsSession.Behave == "BR" ||
                    DBPropsSession.Behave == "BP" ||
                    DBPropsSession.PcvType == "CP" ||
                    DBPropsSession.Behave == "CR"))
            {
                tblBankTran.Visible = true;
                tblOtherTran.Visible = false;
                //txtAccNetAmount.Enabled = true;
                txtInvoiceNoB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddInvOldValueB.ClientID + "','" + txtInvoiceNoB.ClientID + "',null,'');");
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "BR", "BP" }) == true ||
                    strFunction.InList(DBPropsSession.PcvType, new string[] { "BR", "BP" }) == true)
                {
                    trforBank.Visible = true;
                    lblBnkAcCaption.Text = "Bank Name :";
                }
                else
                {
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "CR", "CP" }) == true ||
                        strFunction.InList(DBPropsSession.PcvType, new string[] { "CR", "CP" }) == true)
                    {
                        trforBank.Visible = false;
                        lblBnkAcCaption.Text = "A/c Name :";
                    }
                }
            }
            else
            {
                tblBankTran.Visible = false;
                tblOtherTran.Visible = true;
                //txtAccNetAmount.Enabled = false;
                txtInvNo.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddInvOldValue.ClientID + "','" + txtInvNo.ClientID + "',null,'');");
            }


            if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "PT", "EP" }) == true ||
                 strFunction.InList(DBPropsSession.Behave, new string[] { "PT", "EP" }) == true) ||
                 (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                 DBPropsSession.PcvType == "AR" ||
                 DBPropsSession.Behave == "AR"))
            {
                tblBill.Visible = true;
            }
            else
            {
                tblBill.Visible = false;
            }

            if (DBPropsSession.ItemPage == true)
            {
                lnkTab1.Visible = true;
                lnkTab1.CssClass = "activeTab";
                pnlItemDetails.CssClass = "pnlTabShow";
                liItem.Visible = true;
            }
            else
            {
                lnkTab1.Visible = false;
                lnkTab1.CssClass = "";
                liItem.Visible = false;
                pnlItemDetails.CssClass = "pnlTabHide";
            }

            if (DBPropsSession.ChargesPage == true)
            {
                lnkTab2.Visible = true;
                liTaxCharges.Visible = true;
            }
            else
            {
                lnkTab2.Visible = false;
                lnkTab2.CssClass = "";
                liTaxCharges.Visible = false;
            }

            if (DBPropsSession.AccountPage == true)
            {
                if (DBPropsSession.ItemPage == false)
                {
                    lnkTab3.CssClass = "activeTab";
                    pnlAccountDetails.CssClass = "pnlTabShow";
                }
                lnkTab3.Visible = true;
                liAccount.Visible = true;
            }
            else
            {
                lnkTab3.Visible = false;
                liAccount.Visible = false;
            }


            if (DBPropsSession.AllocationPage == true)
            {
                lnkTab4.Visible = true;
                liAllocation.Visible = true;
            }
            else
            {
                lnkTab4.Visible = true;
                liAllocation.Visible = false;
            }

            if (tblOtherTran.Visible == true)
            {
                // DueDate Row
                if (Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_duedt"]) == true)
                    trduedt.Visible = true;
                else
                    trduedt.Visible = false;

                // Narration Row
                if (Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_narr"]) == true)
                    trNarration.Visible = true;
                else
                    trNarration.Visible = false;

                // Bill Row
                if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "PT", "EP" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "PT", "EP" }) == true) ||
                    (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                     DBPropsSession.PcvType == "AR" ||
                     DBPropsSession.Behave == "AR"))
                {
                    tblBill.Visible = true;
                    txtBillDate.Attributes.Add("onfocus", "javascript:getBillDate();");
   
                }
                else
                {
                    tblBill.Visible = false;
                }

            }

            if (DBPropsSession.AinfoPage == true)
            {
                foreach (DataRow lotherRow in MainDataSet.Tables["lother_vw"].Rows)
                {
                    if (Convert.ToBoolean(lotherRow["att_file"]) == true && Convert.ToBoolean(lotherRow["inter_use"]) == false)
                    {
                        DBPropsSession.AinfoPage = true;
                        break;
                    }
                }
            }

            if (DBPropsSession.AinfoPage == true)
            {
                if (MainDataSet.Tables["lother_vw"].Rows.Count > 0)
                {
                    tblAddinfoDet.Visible = true;
                }
                else
                {
                    tblAddinfoDet.Visible = false;
                }
            }
            else
            {
                tblAddinfoDet.Visible = false;
            }


            //if (SessionProxy.PageCustomProps.ChargesPage == true)
            //{
            //    MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw");
            //    MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw1");
            //}

            if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "OB" }) == true ||
                 strFunction.InList(DBPropsSession.Behave, new string[] { "OB" }) == true))
            {
                trOpBalDBCR.Visible = true;
            }
            else
            {
                trOpBalDBCR.Visible = false;
            }




        }


        protected void grdPrintDialog_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "PrintLink")
            {
                DataSet MainDataSet = SessionProxy.MainDataSet;
                DataTable RStatus_vw = SessionProxy.RStatusView;   
                GridViewRow PrintRow = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                GridView grdPrintDialog = ((GridView)((Control)e.CommandSource).Parent.Parent.Parent.Parent);
                string desc = grdPrintDialog.DataKeys[PrintRow.RowIndex].Values[0].ToString().Trim();
                string repName = grdPrintDialog.DataKeys[PrintRow.RowIndex].Values[1].ToString().Trim();

                string filterExp = "desc ='" + desc.Trim() + "' and rep_nm='" + repName.Trim() + "'";
                try
                {
                    DataRow rStatusRow = RStatus_vw.Select(filterExp)[0];
                    if (Convert.ToString(rStatusRow["SqlQuery"]).Trim() == "")
                        throw new Exception("Cannot run Report,Query is blank in Report Wizard Master");
                    else
                        if (Convert.ToString(rStatusRow["retTable"]).Trim() == "")
                            throw new Exception("Cannot run Report,Temp Tablename is blank in Report Wizard Master");
                        else
                            if (Convert.ToString(rStatusRow["QTable"]).Trim() == "")
                                throw new Exception("Cannot run Report,Main Tablename is blank in Report Wizard Master");

                    string repSqlStr = "";
                    if (Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("EXECUTE") >= 0)
                    {
                        string pCond1 = "";
                        string pCond2 = "";
                        repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).ToUpper().Trim().Substring(0, Convert.ToString(rStatusRow["SqlQuery"]).Trim().LastIndexOf(';') - 1);
                        pCond1 = Convert.ToString(rStatusRow["QTable"]).Trim() + ".entry_ty ='" +
                                 Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'";
                        pCond2 = Convert.ToString(rStatusRow["QTable"]).Trim() + ".tran_cd =" +
                                 Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                        repSqlStr = repSqlStr.Trim() + '"' + pCond1 + " and " + pCond2 + '"';
                    }
                    else
                    {
                        string pCond = Convert.ToString(rStatusRow["QTable"]).Trim() +
                                       ".entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                       " and " + Convert.ToString(rStatusRow["QTable"]).Trim() + ".tran_cd = " +
                                       Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);

                        repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).Trim();
                        int whPos = Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("WHERE");

                        if (whPos >= 0)
                        {
                            repSqlStr = repSqlStr.Trim().Substring(0, whPos + 5) + " " +
                                        pCond.Trim() + " and " + repSqlStr.Trim().Substring(whPos + 6);
                        }
                        else
                            repSqlStr = repSqlStr + " WHERE " + pCond.Trim();


                    }

                    if (repSqlStr.Trim() != "")
                    {
                        repSqlStr.Replace("REPORT HEADER", Convert.ToString(rStatusRow["desc"]).Trim());
                        SessionProxy.MainQueryString = repSqlStr.Trim();
                        SessionProxy.SubQueryString = null;
                        SessionProxy.IsSubReport = false;
                        SessionProxy.ReportDataSet = MainDataSet;
                    }

                    string strOpenWin = "";
                    strOpenWin = "open_window_max('uwCRViewer.aspx','Report');";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "openWindow()", strOpenWin, true);
                }
                catch (Exception EX)
                {
                    DisplayMessage(EX.Message.Trim());
                }

            }

        }

        //protected void btnDelete_Click(object sender, EventArgs e)
        //{
        //    // Call this event by Javascript
        //    try
        //    {
        //        DataSet MainDataSet = (DataSet)Session["MainDataSet"];
        //        boolFunction bitFunction = new boolFunction();
        //        if (bitFunction.toBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["apgenps"]) == true &&
        //            Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["apgen"]).Trim().ToUpper() == "YES")
        //        {
        //            throw new Exception("Approved Transaction cannot be deleted");
        //        }

        //        TransactionEvent.DoDelete(MainDataSet);
        //        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Transaction Deleted..!!!');", true);
        //        Response.Redirect("vuTransactionview.aspx?pcvtype="+SessionProxy.PageCustomProps.PcvType);
        //    }
        //    catch (Exception EX)
        //    {
        //        DataAcess.RollBackTransaction(); 
        //        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + EX.Message + "');", true);
        //        return;
        //    }
        //}

        protected void btnAddCancel_Click(object sender, EventArgs e)
        {
            txtHtAcName.Text = "";
            txtHTAddAmt.Text = "0";
            tblAcAdd.Visible = false; 
        }

        protected void EditRec(Int32 tranCd,ref DataSet MainDataSet)
        {

            vuEdit editProc = new vuEdit();
            stringFunction strFunction = new stringFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            //editProc.PageCustProps = SessionProxy.PageCustomProps;
            editProc.getParentChildRecords(MainDataSet, tranCd,txtTotalQty);
            DBPropsSession.EditSeries = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
            DBPropsSession.EditInvoice = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            DBPropsSession.JustInvoice = "";
            DBPropsSession.JustSeries = "";

            // Below Variable use for Allocation
            DBPropsSession.IsOpenGridForAllocation = false; // always false in postback is false
            DBPropsSession.VAmt = 0; // always false in postback is false
            DBPropsSession.VchrAmt = 0; // always false in postback is false
            DBPropsSession.FromAcAmt = 0; // always false in postback is false
            // End

            if (strFunction.InList(DBPropsSession.PcvType, new string[] { "OB", "OS" }) == true ||
            strFunction.InList(DBPropsSession.Behave, new string[] { "OB", "OS" }))
            {
                boolFunction bitFunction = new boolFunction();
                if (bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_choice"]) == true)
                    radDrCr.SelectedValue = "Debit";
                else
                    if (bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_choice"]) == false)
                        radDrCr.SelectedValue = "Credit";
            }


            if (tblOtherTran.Visible == true)
            {
                if (txtPartyName.Visible == true && txtPartyName.Enabled == true)
                {
                    //dropParty.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["ac_id"]).Trim();
                    txtPartyName.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim();
                    txtPartyName.Attributes.Add("Onfocus", "javascript:updateHiddenTextField('" + hiddPartyName.ClientID + "','" + txtPartyName.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboCategory.Visible == true && cboCategory.Enabled == true)
                {
                    cboCategory.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim() == "" ?
                                                "--Select Category--" :
                                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim();
                }

                if (DropInvSer.Visible == true && DropInvSer.Enabled == true)
                {
                    DropInvSer.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim() == "" ?
                                               "--Select Invoice Series--" :
                                               Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                }

                if (cboDepartMent.Visible == true && cboDepartMent.Enabled == true)
                {
                    cboDepartMent.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim() == "" ?
                                                  "--Select Department--" :
                                                  Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim();

                }

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    cboRule.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim() == "" ?
                                            "--Select Rule--" :
                                            Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim();
                }
            }

            if (tblBankTran.Visible == true)
            {
                if (txtPartyNameB.Visible == true )
                {
                    txtPartyNameB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim();
                    txtPartyNameB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBnkPartyName.ClientID + "','" + txtPartyNameB.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboInvSeriesB.Visible == true && cboInvSeriesB.Enabled == true)
                {
                    cboInvSeriesB.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim() == "" ?
                                                  "--Select Invoice Series--" :
                                                  Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                }

                if (cboDepartMentB.Visible == true && cboDepartMentB.Enabled == true)
                {
                    cboDepartMentB.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim() == "" ?
                                                   "--Select Department--" :
                                                   Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim();
                }

                if (txtChequeNoB.Visible == true && txtChequeNoB.Visible == true)
                {
                    txtChequeNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cheq_no"]).Trim();
                    
                }
                if (txtBankName.Visible == true )
                {
                    txtBankName.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["bank_nm"]).Trim();
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "BR", "BP" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "BR", "BP" }) == true)
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    else
                        if (strFunction.InList(DBPropsSession.PcvType, new string[] { "CR", "CP" }) == true ||
                            strFunction.InList(DBPropsSession.Behave, new string[] { "CR", "CP" }) == true)
                            txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");

                    if (trforBank.Visible == true)
                        txtDrawnOnB.Text =  Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Drawn_On"]).Trim();
                    
                }

                if (cboCategoryB.Visible == true && cboCategoryB.Enabled == true)
                {
                    cboCategoryB.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim() == "" ?
                                                   "--Select Category--" :
                                                   Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim();

                }

                if (txtNarrB.Visible == true)
                {
                    txtNarrB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Narr"]).Trim();
                }
            }

            // Called child methods in Editmode
            DBPropsSession.JustInvoice = "";
            DBPropsSession.JustSeries = "";
            //editProc.PageCustProps = SessionProxy.PageCustomProps;
            //editProc.getChildRecords(MainDataSet, txtTotalQty);
            getDateFormat GetDateFormat = new getDateFormat();
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps; 

            if (DBPropsSession.ChargesPage == true)
            {
                //MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw");
                //MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw1");
                
                TransactionEvent.RefreshHeaderField(MainDataSet.Tables["company"],
                    MainDataSet.Tables["main_vw"],
                    txtGrossAmt,
                    txtdedBefTax,
                    txtTaxCharges,
                    txtTaxExAmt,
                    txtAddCharges,
                    txtTaxAmt,
                    txtNonTax,
                    txtfdisc,
                    txtRoundoff,
                    txtNetAmountTax);
            }

            if (DBPropsSession.ItemPage == true)
            {
                txtItemTotal.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"]);
                txtNetAmount.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["net_amt"]);
            }

            if (DBPropsSession.AccountPage == true)
            {
                txtAccNetAmount.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["net_amt"]);
            }

            if (trduedt.Visible == true)
            {

                txtDueDate.Text = GetDateFormat.dateformatBR(Convert.ToString(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["due_dt"])));
                string dueDays = Convert.ToString(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["due_dt"]) - Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"])).Trim();
                if (dueDays.IndexOf('.') >= 0)
                    dueDays = dueDays.Substring(0, dueDays.IndexOf('.'));
                else
                    dueDays = "0";
                txtDueDays.Text = dueDays.Trim();
            }

            if (trNarration.Visible == true)
                txtNarr.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["narr"]);

            if (tblBill.Visible == true)
            {
                txtBillNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["u_pinvno"]);
                txtBillDate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["u_pinvdt"]));
            }

            DBPropsSession.EditSeries = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
            DBPropsSession.EditInvoice = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();

            if (tblOtherTran.Visible == true)
            {
                txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            }
            else
            {
                if (tblBankTran.Visible == true)
                    txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            }

            if (DBPropsSession.AinfoPage == true && tblAddInfo.Visible == true)
            {
                try
                {
                    TransactionEvent.AdditionalInfoShow(MainDataSet, tblAddInfo);
                }
                catch (Exception Ex)
                {
                   //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message  + "');", true);
                   tblAddinfoDet.Visible = false;
                   DBPropsSession.AinfoPage = false;  
                }
            }



            if ((DBPropsSession.PcvType == "BR" ||
                 DBPropsSession.PcvType == "BP" ||
                 DBPropsSession.PcvType == "CP" ||
                 DBPropsSession.PcvType == "CR") ||
                (DBPropsSession.Behave == "BR" ||
                 DBPropsSession.Behave == "BP" ||
                 DBPropsSession.Behave == "CP" ||
                 DBPropsSession.Behave == "CR"))
            {
                txtDateB.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                txtDateB.Focus();
            }
            else
            {
                txtdate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                txtdate.Focus();
            }

            if (DBPropsSession.ItRate == true)
            {
                SqlParameter[] spParam = new SqlParameter[4];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@partyNM";
                spParam[0].SqlDbType = SqlDbType.VarChar;
                spParam[0].Value = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim();
                spParam[0].Direction = ParameterDirection.Input;

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@prod";
                spParam[1].SqlDbType = SqlDbType.VarChar;
                spParam[1].Value = DBPropsSession.Vchkprod;
                spParam[1].Direction = ParameterDirection.Input;

                spParam[2] = new SqlParameter();
                spParam[2].ParameterName = "@accPage";
                spParam[2].SqlDbType = SqlDbType.Bit;
                spParam[2].Value = false;
                spParam[2].Direction = ParameterDirection.Input;

                spParam[3] = new SqlParameter();
                spParam[3].ParameterName = "@hidPartynm";
                spParam[3].SqlDbType = SqlDbType.VarChar;
                spParam[3].Value = "";
                spParam[3].Direction = ParameterDirection.Input;

                SqlDataReader dr = DataAcess.ExecuteDataReader("sp_ent_web_tran_party_validation",
                                                spParam, ref connHandle);

                if (dr.HasRows == true)
                {
                    while (dr.Read())
                    {
                        SessionProxy.PrlistCode = Convert.ToString(dr["prlstname"]).Trim(); 
                    }
                }
                dr.Close();
                dr.Dispose();
                DataAcess.Connclose(connHandle); 
            }
            //EnableDisableControls(Page, false); // Disable all controls on the Page
            //ControlShouldbeEnabled(true);

        }

        protected void InitGetTables(ref DataSet MainDataSet)
        {
            MainDataSet = new DataSet();
            getTables GetTables = new getTables();
            getCompany GetCompany = new getCompany();
            getCoAdditional GetCoAdditional = new getCoAdditional();
            stringFunction strFunction = new stringFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlParameter[] spParam = new SqlParameter[4];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@pcvtype";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = DBPropsSession.PcvType.Trim();

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@behave";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = DBPropsSession.Behave.Trim();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@entryTbl";
            spParam[2].SqlDbType = SqlDbType.VarChar;
            spParam[2].Value = DBPropsSession.Entry_Tbl.Trim();

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@prod";
            spParam[3].SqlDbType = SqlDbType.VarChar;
            spParam[3].Value = SessionProxy.VChkProd;

            ArrayList dblist = new ArrayList();
            dblist.Add("lcode_vw");
            dblist.Add("lother_vw");
            dblist.Add("dcmast_vw");
            dblist.Add("stax_vw");
            dblist.Add("main_vw");
            dblist.Add("item_vw");
            dblist.Add("acdet_vw");
            dblist.Add("tax_vw");
            dblist.Add("tax_vw1");
            if (SessionProxy.VChkProd.Trim().IndexOf("vutex") >=0)
            {
                if (strFunction.InList(DBPropsSession.PcvType.Trim(),
                        new string[] {"AR","IR","GT"}) == true ||
                    strFunction.InList(DBPropsSession.Behave.Trim(),
                        new string[] {"AR","IR","GT"}) == true)
                {
                    dblist.Add("manu_det_vw");
                }
                
                if (strFunction.InList(DBPropsSession.PcvType.Trim(),
                        new string[] {"DC", "IR", "SS", "GT"}) == true ||
                    strFunction.InList(DBPropsSession.Behave.Trim(),
                        new string[] {"DC", "IR", "SS", "GT"}) == true)
                {
                    dblist.Add("litemall_vw");
                }
            }
            dblist.Add("category");
            dblist.Add("series");
            dblist.Add("department");
            dblist.Add("rules");
            dblist.Add("Param"); 
            dblist.Add("manufact");

            if ((SessionProxy.VChkProd.Trim().IndexOf("vutex") >= 0) &&
                 (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true ||
                  strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true))
            {
                dblist.Add("TexExe");
            }

            MainDataSet = DataAcess.ExecuteDataset(MainDataSet,
                                "sp_ent_web_tran_gencursor",
                                            spParam,dblist,connHandle);

            DataAcess.Connclose(connHandle);
            MainDataSet.Tables.Add(((DataTable)SessionProxy.Company).Copy());
            try
            {
                DataRow dcMastRow = MainDataSet.Tables["dcmast_vw"].Select("code = 'E'")[0];
                if (Convert.ToBoolean(dcMastRow["att_file"]) == true)
                {
                    DBPropsSession.HowtoCalculateExAmt = "V";
                }
                else
                {
                    DBPropsSession.HowtoCalculateExAmt = "I";
                }
            }
            catch
            {
                DBPropsSession.HowtoCalculateExAmt = "N";
            }
            DBPropsSession.Entry_Tbl = DBPropsSession.PcvType;

            //try
            //{
            //    MainDataSet = GetTables.openTables(MainDataSet, , DBPropsSession.Vchkprod);
            //    MainDataSet = GetCompany.Company(MainDataSet, SessionProxy.ReqCode.Trim(), SessionProxy.FinYear.Trim());
            //    MainDataSet = GetCoAdditional.CoAdditional(MainDataSet);
            //}
            //catch (Exception Ex)
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Replace("'","/") + "');", true);
            //    return;
            //}

            //DBPropsSession.HowtoCalculateExAmt = GetTables.HowtoCalculateExAmt;
            //DBPropsSession.Behave = GetTables.Behave.ToString().Trim();
            //if (DBPropsSession.Behave == "" || DBPropsSession.Behave == null)
            //{
            //    DBPropsSession.Behave = SessionProxy.PageCustomProps.PcvType;
            //}
            

            //if (SessionProxy.PageCustomProps.Vchkprod.Trim().IndexOf("vutex") > 0 &&
            //    (strFunction.InList(SessionProxy.PageCustomProps.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
            //            strFunction.InList(SessionProxy.PageCustomProps.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
            //{
            //    SqlDataReader dr;
            //    sqlStr = "select top 2 ware_nm from warehouse where validity like " + "%" + SessionProxy.PageCustomProps.PcvType + "% " +
            //             " and ltrim(ware_nm) != ''";
            //    dr = DataAcess.ExecuteDataReader(sqlStr);
            //    bool isRows = false;
            //    int isRowsEffected = 0;
            //    if (dr.HasRows == true)
            //    {
            //        isRows = true;
            //        isRowsEffected = dr.RecordsAffected; 
            //    }
            //    else
            //        isRows = false;

            //    dr.Close();
            //    dr.Dispose();

            //    if (isRows == true)
            //    {
            //        if (isRowsEffected < 2 && SessionProxy.PageCustomProps.PcvType == "IR")
            //        {
            //            throw new Exception("There should be atleast 2 warehose for this entry..");
            //        }
            //    }
            //    else
            //    {
            //        if (SessionProxy.PageCustomProps.PcvType != "IR")
            //        {
            //            throw new Exception("There should be atleast 1 warehose for this entry..");
            //        }
            //        else
            //        {
            //            throw new Exception("Warehouse details not found..");
            //        }
            //    }
            //}
        }

        protected void BindDropDown(ref DataSet MainDataSet)
        {
            if (tblOtherTran.Visible == true)
            {
                vouFillDropdownList voufilldrops = new vouFillDropdownList();
                if (cboCategory.Visible == true && cboCategory.Enabled == true)
                {
                    cboCategory.DataSource = MainDataSet.Tables["category"];
                    cboCategory.DataTextField = "cate";
                    cboCategory.DataValueField = "cate";
                    cboCategory.DataBind();

                    cboCategory.Items.Insert(0, "--Select Category--");
   
                    //voufilldrops.fillDropDownList(cboCategory, "--Select Category--", "cate", "category", "cate", "cate", "validity like '%" + SessionProxy.PageCustomProps.PcvType + "%'");
                }


                if (DropInvSer.Visible == true && DropInvSer.Enabled == true)
                {
                    dropdownBind(DropInvSer, MainDataSet.Tables["series"],
                            "inv_sr", "inv_sr", "--Select Invoice Series--");

                    //voufilldrops.fillDropDownList(DropInvSer, "--Select Invoice Series--", "inv_sr", "inv_sr", "series", "inv_sr", "validity like '%" + SessionProxy.PageCustomProps.PcvType + "%'");
                }

                if (cboDepartMent.Visible == true && cboDepartMent.Enabled == true)
                {
                    dropdownBind(cboDepartMent, MainDataSet.Tables["department"],
                                "dept", "dept", "--Select Department--");

                    //voufilldrops.fillDropDownList(cboDepartMent, "--Select Department--", "dept", "dept", "department", "dept", "validity like '%" + SessionProxy.PageCustomProps.PcvType + "%'");
                }

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    dropdownBind(cboRule, MainDataSet.Tables["rules"],
                                "rule", "rule", "--Select Rule--");

                    //voufilldrops.fillDropDownList(cboRule, "--Select Rule--", "rule", "rule", "Rules", "[rule]", "validity like '%" + SessionProxy.PageCustomProps.PcvType + "%'");
                }
            }

            if (tblBankTran.Visible == true)
            {
                vouFillDropdownList voufilldrops = new vouFillDropdownList();
                if (txtPartyNameB.Visible == true && txtPartyNameB.Enabled == true)
                {
                    //voufilldrops.fillDropDownList(cboPartyNameB, "--Select Party Name--", "ac_id", "ac_name", "PARTY", SessionProxy.PageCustomProps.PcvType, SessionProxy.PageCustomProps.Behave,
                    //                              MainDataSet.Tables["lcode_vw"], "ac_name,ac_id", 0, SessionProxy.PageCustomProps.Vchkprod);
                    txtPartyNameB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBnkPartyName.ClientID + "','" + txtPartyNameB.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboInvSeriesB.Visible == true && cboInvSeriesB.Enabled == true)
                {
                    dropdownBind(cboInvSeriesB, MainDataSet.Tables["series"],
                                "inv_sr", "inv_sr", "--Select Series--");

                    //voufilldrops.fillDropDownList(cboInvSeriesB, "--Select Invoice Series--", "inv_sr", "inv_sr", "series", "Inv_sr", "validity like '%" + SessionProxy.PageCustomProps.PcvType + "%'");
                }

                if (cboDepartMentB.Visible == true && cboDepartMentB.Enabled == true)
                {
                    dropdownBind(cboDepartMentB, MainDataSet.Tables["department"],
                                "dept", "dept", "--Select Series--");

                    //voufilldrops.fillDropDownList(cboDepartMentB, "--Select Department--", "dept", "dept", "department", "dept", "validity like '%" + SessionProxy.PageCustomProps.PcvType + "%'");
                }

                if (cboCategoryB.Visible == true && cboCategoryB.Enabled == true)
                {
                    dropdownBind(cboCategoryB, MainDataSet.Tables["category"],
                                "cate", "cate", "--Select Category--");

                    //voufilldrops.fillDropDownList(cboCategoryB, "--Select Category--", "dept", "dept", "department", "cate", "validity like '%" + SessionProxy.PageCustomProps.PcvType + "%'");
                }

                if (txtBankName.Visible == true)
                {
                    stringFunction strFunction = new stringFunction();

                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "CR", "CP" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "CR", "CP" }) == true)
                    {
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    }
                    else
                    {
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");

                    }
                    
                    //if (trforBank.Visible == true) 
                    //    voufilldrops.fillDropDownList(cboDrawnOnB, "--Select Drawn On--", "Drawn_on", "Drawn_On", SessionProxy.PageCustomProps.PcvType.Trim() + "main", "Drawn_On", " entry_ty = '" + SessionProxy.PageCustomProps.PcvType + "'");
    
                }
            }

        }

        private void dropdownBind(DropDownList cbo,
            DataTable srctable,
            string valuefld,
            string textfld,
            string fstItem)
        {
            cbo.DataSource = srctable;
            cbo.DataTextField = textfld;
            cbo.DataValueField = valuefld;
            cbo.DataBind();
            cbo.Items.Insert(0, fstItem); 
        }

        protected void BindGridView(ref DataSet MainDataSet,
                    ref DataView grdItemColView)
        {
            vouGridFill vouGridInit = new vouGridFill();
            if (DBPropsSession.ItemPage == true)
            {
                //vouGridInit.PageCustProps = SessionProxy.PageCustomProps;
                //DataView grdItemColView = (DataView)Session["GridItemColView"];
                if (grdItemColView == null || grdItemColView.Table == null  || grdItemColView.Table.Rows.Count <= 0)
                    grdItemColView = vouGridInit.ItemgridTemplate(MainDataSet.Tables["lother_vw"],
                                                                            MainDataSet.Tables["company"],
                                                                            MainDataSet.Tables["lcode_vw"],
                                                                            MainDataSet.Tables["item_vw"],
                                                                            MainDataSet.Tables["TexExe"],
                                                                            Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim());

                vouGridInit.gridItemGen(GridItem, grdItemColView, MainDataSet.Tables["item_vw"]);
                //SessionProxy.GridItemColView = grdItemColView; 
                //vouGridInit.gridItemFill(true, MainDataSet.Tables["lother_vw"], GridItem, MainDataSet.Tables["Item_vw"],
                //                         SessionProxy.PageCustomProps.ChargesPage, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["company"], MainDataSet.Tables["lcode_vw"],SessionProxy.PageCustomProps.PcvType,
                //                         SessionProxy.PageCustomProps.Behave, 0);
                DBPropsSession.SalesTaxItem = vouGridInit.SalesTaxItem;
            }

            if (DBPropsSession.AccountPage == true)
                vouGridInit.gridAcccountFill(GridAccount, MainDataSet.Tables["acdet_vw"], MainDataSet.Tables["lcode_vw"]);

            if (DBPropsSession.AllocationPage == true)
            {
                vouGridInit.gridAllocation(grdlAllocDet, MainDataSet.Tables["lal_vw"], MainDataSet.Tables["acdet_vw"],
                                           MainDataSet.Tables["company"]);
                //grdlAllocDet.Columns[0].Visible = false;
                //grdlAllocDet.Columns[1].Visible = false;
            }

            if (DBPropsSession.ChargesPage == true)
                vouGridInit.gridTaxFill(grdCharges, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["lcode_vw"],
                                        MainDataSet.Tables["tax_vw"], MainDataSet.Tables["tax_vw1"],
                                        MainDataSet.Tables["main_vw"], MainDataSet.Tables["item_vw"],
                                        MainDataSet.Tables["company"], MainDataSet.Tables["stax_vw"],
                                        DBPropsSession.EditMode,
                                        DBPropsSession.AddMode,
                                        DBPropsSession.PcvType,
                                        DBPropsSession.Behave);

        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwTransactionList.aspx?pcvtype=" + DBPropsSession.PcvType);  
        }

        protected void txtETAcName_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet; 
            HtmlTable tblAcBal = new HtmlTable();
            try
            {
                TextBox txtAcName = ((TextBox)sender);
                GridViewRow row = ((GridViewRow)txtAcName.NamingContainer);
                tblAcBal = (HtmlTable)GridAccount.Rows[row.RowIndex].FindControl("tblETAcBal");
                Label lblEtAcBalAmt = (Label)GridAccount.Rows[row.RowIndex].FindControl("lblETAccBalAmt");
                HiddenField hiddETAcBal = (HiddenField)GridAccount.Rows[row.RowIndex].FindControl("hiddETAcBal");
                DropDownList dropDrCr = (DropDownList)GridAccount.Rows[row.RowIndex].FindControl("DropETDRCR");
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;

                TransactionEvent.dropETAcName_SelectedIndexChanged(txtAcName,
                    dropDrCr,
                    lblEtAcBalAmt,
                    MainDataSet.Tables["acdet_vw"],
                    MainDataSet.Tables["company"],
                    MainDataSet.Tables["main_vw"]);

                SessionProxy.MainDataSet = MainDataSet;

                if (lblEtAcBalAmt.Text != "")
                    hiddETAcBal.Value = "GET"; 

            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
            }
            finally
            {
                DataTier DataAcess = new DataTier();
                DataAcess.Connclose(connHandle);
                MainDataSet.Dispose();
                tblAcBal.Dispose();
            }
        }

        protected void GridAccount_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            HtmlTable tblAcBal = new HtmlTable();
            try
            {
                boolFunction bitFunction = new boolFunction();
                numericFunction numFunction = new numericFunction();
                tblAcBal = (HtmlTable)GridAccount.Rows[e.RowIndex].FindControl("tblETAcBal");
                Label lblEtAcBalAmt = (Label)GridAccount.Rows[e.RowIndex].FindControl("lblETAccBalAmt");
                DropDownList dropDrCr = (DropDownList)GridAccount.Rows[e.RowIndex].FindControl("DropETDRCR");
                DropDownList dropAcName = (DropDownList)GridAccount.Rows[e.RowIndex].FindControl("DropETAcName");
                decimal mAmt = numFunction.toDecimal(((NumericTextBox)GridAccount.Rows[e.RowIndex].FindControl("txtETAddAmt")).Text);     
                string acSerial = GridAccount.DataKeys[e.RowIndex].Value.ToString().Trim();

                vuCheckDbCrBalance CheckDbCrBalance = new vuCheckDbCrBalance();
                
  
                foreach (DataRow acDetRow in MainDataSet.Tables["acdet_vw"].Select("acserial = '" + acSerial.Trim() +"'"))
                {
                    acDetRow["ac_name"] = dropAcName.SelectedItem.ToString().Trim();
                    acDetRow["ac_id"] = dropAcName.SelectedValue;
                    acDetRow["amount"] = mAmt;
                    acDetRow["amt_ty"] = dropDrCr.SelectedValue.Trim();
                }

                string WarningMess = CheckDbCrBalance.DbCrBalanceCheck(MainDataSet.Tables["acdet_vw"], false);
                if (WarningMess != "")
                    throw new Exception(WarningMess);

                MainDataSet.Tables["acdet_vw"].AcceptChanges();

                GridAccount.EditIndex = -1;
                GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];  

                vouGridFill vouGridInit = new vouGridFill();
                GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
                string[] grdCols = vouGridInit.grdAccountColSHide(MainDataSet.Tables["lcode_vw"]);
                vouGridInit.gridBind(GridAccount, grdCols);

                if (DBPropsSession.AllocationPage)
                {
                    grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdlAllocDet.DataSource = MainDataSet.Tables["acdet_vw"];
                    vouGridInit.gridBind(grdlAllocDet, grdCols);
                }

                SessionProxy.MainDataSet = MainDataSet;
 
            }
            catch (Exception Ex)
            {
                MainDataSet.Tables["acdet_vw"].RejectChanges();
                SessionProxy.MainDataSet = MainDataSet;
                MessageErrorDisp(Ex);
            }
            finally
            {
                DataTier DataAcess = new DataTier();
                DataAcess.Connclose(connHandle);
                MainDataSet.Dispose();
                tblAcBal.Dispose();
            }
            
        }

        protected void GridAccount_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            MainDataSet.Tables["acdet_vw"].RejectChanges();
            SessionProxy.MainDataSet = MainDataSet; 

            GridAccount.EditIndex = -1;
            GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];

            vouGridFill vouGridInit = new vouGridFill();
            string[] grdCols = vouGridInit.grdAccountColSHide(MainDataSet.Tables["lcode_vw"]);
            vouGridInit.gridBind(GridAccount, grdCols);
            MainDataSet.Dispose(); 
        }


        protected void grdModal()
        {
            HtmlTableRow r1 = null;
            r1 = new HtmlTableRow();
            r1.VAlign = "TOP";
        }

        protected void GenGridItemRows(DataView lotherview,
                    DataSet MainDataSet)
        {
            tblItDetails.Controls.Clear();
            tblItDetails.Rows.Clear();
            tblItDetails.Dispose();

            //DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            stringFunction strFunction = new stringFunction();

            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
            (strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim()
                            , new string[] { "EXCISE", "NON-EXCISE" }) == true))
            {
                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true)
                {
                    vouGridFill gridFill = new vouGridFill();
                    //gridFill.PageCustProps = DBPropsSession;  
                    gridFill.grdItemSettingforET(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim(),
                        lotherview,
                        lotherview.RowFilter);
                }
            }
 
            HtmlTableRow r1 = new HtmlTableRow();
            int cnt = 0;
            int viewRCount = 1;
            foreach (DataRowView xtraRow in lotherview)
            {
                if (cnt == 0)
                {
                    r1 = new HtmlTableRow(); // Create New Row
                    r1.VAlign = "Top";
                }

                r1 = cellGen("LABEL", r1, xtraRow, null, MainDataSet.Tables["lcode_vw"]);
                r1 = cellGen(Convert.ToString(xtraRow["data_ty"]).Trim().ToUpper(), r1, xtraRow, null, MainDataSet.Tables["lcode_vw"]);

                cnt = cnt + 1;
                viewRCount = viewRCount + 1;
                if (cnt == 2 || viewRCount > lotherview.Count)
                {
                    tblItDetails.Rows.Add(r1);
                    cnt = 0;
                }
            }

            r1 = new HtmlTableRow();
            HtmlTableCell cellD = new HtmlTableCell();
            r1.Controls.Add(cellD);
            cellD = new HtmlTableCell();
            Sample.Web.UI.Compatibility.ValidationSummary valItSummary = new Sample.Web.UI.Compatibility.ValidationSummary();
            //ValidationSummary valItSummary = new ValidationSummary();
            valItSummary.ShowMessageBox = true;
            valItSummary.ShowSummary = false;
            valItSummary.ValidationGroup = "valGrpITDet";
            valItSummary.DisplayMode = ValidationSummaryDisplayMode.BulletList;
            valItSummary.EnableClientScript = true; 
            cellD.Controls.Add(valItSummary);
            r1.Controls.Add(cellD);
            tblItDetails.Rows.Add(r1);
        }

        protected HtmlTableRow cellGen(string cntType,
                  HtmlTableRow htmlRow,
                  DataRowView xtraRow,
                  DataRow data_vw,
                  DataTable lcode_vw)
        {

            boolFunction bitFunction = new boolFunction();
            HtmlTableCell cellD = new HtmlTableCell();
            stringFunction strFunction = new stringFunction();

            cellD.Align = "Left";
            cellD.VAlign = "Top";
            switch (cntType.Trim())
            {
                case "LABEL":
                    Label lblS = new Label();
                    lblS.ID = "lbl_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    if (strFunction.InList(Convert.ToString(xtraRow["data_ty"]).Trim(), new string[] { "BUTTON", "LINKBUTTON" }) == false)
                    {
                        lblS.Text = Convert.ToString(xtraRow["head_nm"]).Trim();
                    }
                    else
                        lblS.Text = "";

                    lblS.CssClass = "forms_ItemLeft5";
                    cellD.Controls.Add(lblS);
                  

                    if (Convert.ToString(xtraRow["fld_nm"]).Trim().ToUpper() == "ITEM" &&
                       Convert.ToInt32(xtraRow["dSerial"]) == 998)
                    {
                        HtmlGenericControl divHtmlItem = new HtmlGenericControl("div");
                        divHtmlItem.ID = "divItemProgress";
                        //divHtmlItem.Attributes.Add("class", "AutoCompleteXProgress");   
                        divHtmlItem.Style.Add("display", "none");
                        Image img = new Image();
                        img.ImageUrl = "~/img/smallwaitprogressbar.gif";
                        divHtmlItem.Controls.Add(img);
                        cellD.Controls.Add(divHtmlItem);
                    }
                    cellD.Align = "Right";

                    break;
                case "LINKBUTTON":
                    LinkButton lnk = new LinkButton();
                    lnk.ID = "lnk_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    lnk.Text = Convert.ToString(xtraRow["head_nm"]).Trim();
                    lnk.CssClass = "gridItLinks";
                    if (lnk.ID.Trim().ToUpper() == "LNKALLOC" &&
                        Convert.ToInt32(xtraRow["dSerial"]) == 999)
                    {
                        lnk.Click += new System.EventHandler(this.btnItemValid_Click);
                    }
                    cellD.Controls.Add(lnk);
                    break;
                case "BUTTON":
                    Button btn = new Button();
                    btn.ID = "btn_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    btn.Text = Convert.ToString(xtraRow["head_nm"]).Trim();
                    if (btn.ID.Trim().ToUpper() == "BTNEXDET" &&
                        Convert.ToInt32(xtraRow["dSerial"]) == 999)
                    {
                        btn.Click += new System.EventHandler(this.btnITExcisePostBack_Click);
                    }
                    cellD.Controls.Add(btn);
                    break; 
                case "BIT":
                    GraphicalCheckBox chkBox = new GraphicalCheckBox();
                    chkBox.ID = "chk_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    chkBox.CheckedImg = "checked.png";
                    chkBox.CheckedOverImg = "checked-over.png";
                    chkBox.CheckedDisImg = "checked.png";
                    chkBox.UncheckedDisImg = "unchecked.png";
                    chkBox.UncheckedImg = "unchecked.png";
                    chkBox.UncheckedOverImg = "unchecked-over.png";
                    chkBox.Style.Add("z-index", "100");
                    chkBox.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                    cellD.Controls.Add(chkBox);
                    break;
                case "DECIMAL":
                case "NUMERIC":
                    // Generate Item no. while adding item details
                    numericFunction numFunction = new numericFunction();
                    if (Convert.ToString(xtraRow["fld_nm"]).Trim().ToUpper() == "ITEM_NO" &&
                        numFunction.toInt32(xtraRow["dserial"]) == 999 &&
                        Convert.ToString(xtraRow["tag"]) == "STANDARD ITEM NO.")
                    {
                        Label lblItemNo = new Label();
                        lblItemNo.ID = "lblstd_" + Convert.ToString(xtraRow["fld_nm"]).Trim(); 
                        //vuGenerateNo genItemNo = new vuGenerateNo();
                        //lblItemNo.Text = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
                        // store value in hidden field for postback
                        if (hidForItemNo.Value != "")
                            lblItemNo.Text = hidForItemNo.Value;
                        lblItemNo.Style.Add("font-weight", "bold");
                        lblItemNo.Style.Add("font-size", "12pt");
                        lblItemNo.Style.Add("color", "Blue");
                        lblItemNo.Style.Add("font-name", "verdana");
                        cellD.Controls.Add(lblItemNo);
                        break;
                    }
                    NumericTextBox numTxtBox = new NumericTextBox();
                    numTxtBox.ID = "num_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    numTxtBox.AlignStyle = "RIGHT";
                    numTxtBox.AllowMinusValue = true;
                    numTxtBox.SelectOnEntry = true;
                    numTxtBox.MaxLength = numFunction.toInt32(xtraRow["fld_wid"]);
                    numTxtBox.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                    if (cntType.Trim().ToUpper() == "DECIMAL")
                    {
                        if (numFunction.toInt32((xtraRow["fld_dec"])) > 0)
                        {
                            string formatDeci = "";
                            for (int i = 0; i < numFunction.toInt32(xtraRow["fld_dec"]); i++)
                            {
                                formatDeci += "0";
                            }
                            numTxtBox.Format = "0." + formatDeci.Trim();
                            numTxtBox.Text = "0." + formatDeci.Trim();
                        }
                        else
                        {
                            numTxtBox.Format = "0";
                            numTxtBox.Text = "0";
                        }
                    }
                    else
                    {
                        if (cntType.Trim().ToUpper() == "NUMERIC")
                        {
                            numTxtBox.Format = "0";
                            numTxtBox.Text = "0";
                        }
                    }

                    numTxtBox.CssClass = "form_textfield3";
                    numTxtBox.Width = numFunction.toInt32(xtraRow["fld_wid"]) <= 50 ? 80 : numFunction.toInt32(xtraRow["fld_wid"]);

                    //xtraSetValue<decimal> numGetDefaValueO = new xtraSetValue<decimal>();
                    //xtraSetValue<string> numGetDefaValueS = new xtraSetValue<string>();
                    //try
                    //{
                    //    if (data_vw != null)
                    //    {
                    //        if (numFunction.toDecimal(data_vw[Convert.ToString(xtraRow["fld_nm"])]) > 0)
                    //            numTxtBox.Text = Convert.ToString(numGetDefaValueO.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw));
                    //        else
                    //            numTxtBox.Text = Convert.ToString(numGetDefaValueS.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"])));
                    //    }
                    //    else
                    //        if (Convert.ToString(xtraRow["defa_val"]).Trim() != "") 
                    //            numTxtBox.Text = Convert.ToString(numGetDefaValueS.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"])));
                    //}
                    //catch (Exception Ex)
                    //{
                    //    throw new Exception(Ex.Message);
                    //}

                    cellD.Controls.Add(numTxtBox);
                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("num_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), numTxtBox.Format));
                    }

                    if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["javaScript"]).Trim().IndexOf("function ") >= 0)
                        {
                            string funcName = Convert.ToString(xtraRow["javaScript"]).Trim().Substring(09,
                                              Convert.ToString(xtraRow["javaScript"]).Trim().IndexOf("()", 0) - 9);

                            string strJs = Convert.ToString(xtraRow["javaScript"]).Replace("\r", "\n");
                            if (!Page.IsClientScriptBlockRegistered(funcName))
                                System.Web.UI.ScriptManager.RegisterStartupScript(Page, Page.GetType(), funcName, strJs, false);

                            if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                numTxtBox.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                        funcName.Trim());
                            else
                                throw new Exception("Javascript Event cannot be empty");

                        }
                        else
                        {
                            if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                numTxtBox.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                        Convert.ToString(xtraRow["javaScript"]).Trim());
                            else
                                throw new Exception("Javascript Event cannot be empty");
                        }
                    }
                    break;
                case "TEXT":
                    Panel panel1 = new Panel();
                    panel1.ID = "Pan1_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    panel1.Width = 140;
                    panel1.CssClass = "CollapsePanelHeader";
                    panel1.ToolTip = "Click for Expand..";
                    Label label = new Label();
                    label.ID = "lblPan1_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    label.Text = "+ Show Memo Details";
                    panel1.Controls.Add(label);
                    panel1.Controls.Add(new LiteralControl("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;"));

                    Panel panel2 = new Panel();
                    panel2.ID = "Pan2_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    panel2.Width = 140;
                    panel2.Height = 50;
                    TextBox txtText = new TextBox();
                    txtText.ID = "mut_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    txtText.TextMode = TextBoxMode.MultiLine;
                    txtText.Height = 100;
                    txtText.Width = 140;
                    txtText.CssClass = "form_textfield3";

                    if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                            txtText.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                    Convert.ToString(xtraRow["javaScript"]).Trim());
                        else
                            throw new Exception("Javascript Event cannot be empty");
                    }

                    //xtraSetValue<string> textGetDefaValue = new xtraSetValue<string>();
                    //try
                    //{
                    //    if (data_vw != null)
                    //        if (Convert.ToString(data_vw[Convert.ToString(xtraRow["fld_nm"])]) != "")
                    //            txtText.Text = textGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                    //        else
                    //            txtText.Text = textGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                    //    else
                    //        txtText.Text = textGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                    //}
                    //catch (Exception Ex)
                    //{
                    //    throw new Exception(Ex.Message);
                    //}


                    panel2.Controls.Add(txtText);

                    cellD.Controls.Add(panel1);
                    cellD.Controls.Add(panel2);

                    CollapsiblePanelExtender collExtender = new CollapsiblePanelExtender();
                    collExtender.ID = "coll_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.TargetControlID = "Pan2_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.SuppressPostBack = true;
                    collExtender.CollapsedImage = "~/images/expand_blue.jpg";
                    collExtender.ExpandedImage = "~/images/collapse_blue.jpg";
                    collExtender.CollapsedText = "+ Show Memo Details";
                    collExtender.ExpandedText = "- Hide Memo Details";
                    //collExtender.ImageControlID = "Image1";
                    collExtender.TextLabelID = "lblPan1_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.Collapsed = true;
                    collExtender.CollapseControlID = "Pan1_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.ExpandControlID = "Pan1_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    cellD.Controls.Add(collExtender);

                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("mum_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), ""));

                    }
                    break;
                case "VARCHAR":
                    if (Convert.ToString(xtraRow["filtcond"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Substring(0, 4) != "SELE")
                        {
                            DropDownList cboList = new DropDownList();
                            cboList.ID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cboList.CssClass = "forms_drop";
                            cboList.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                            cboList.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                            string[] cboValue;
                            cboValue = Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Split(',');
                            for (int i = 0; i < cboValue.Length; i++)
                            {
                                cboList.Items.Insert(i, cboValue[i].ToString().Trim());
                            }
                            cboList.Items.Insert(0, "-- Select --");

                            xtraSetValue<string> varGetDefaValue = new xtraSetValue<string>();
                            try
                            {
                                string listValue = "";
                                if (data_vw != null)
                                {
                                    if (Convert.ToString(data_vw[Convert.ToString(xtraRow["fld_nm"])]) != "")
                                    {
                                        listValue = varGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                                        if (listValue == "")
                                            cboList.SelectedIndex = 0;
                                        else
                                            cboList.SelectedValue = listValue; 
                                    }
                                    else
                                        listValue = varGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                                        if (listValue == "")
                                        {   
                                            cboList.SelectedIndex = 0;
                                        }
                                        else
                                            cboList.SelectedValue =  "-- Select --";
                                }
                                else
                                {
                                    listValue = varGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                                    if (listValue == "")
                                    {   
                                        cboList.SelectedIndex = 0;
                                    }
                                    else
                                        cboList.SelectedValue =  "-- Select --";
                                }
                                                                                            
                            }
                            catch (Exception Ex)
                            {
                                throw new Exception(Ex.Message);
                            }

                            cellD.Controls.Add(cboList);

                            if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                            {
                                cellD.Controls.Add(genValidator("cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), cboList.Items[0].Text));
                            }

                            if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                            {
                                if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                    cboList.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                            Convert.ToString(xtraRow["javaScript"]).Trim());
                                else
                                    throw new Exception("Javascript Event cannot be empty");
                            }

                            ListSearchExtender lstExtender = new ListSearchExtender();
                            lstExtender.PromptPosition = ListSearchPromptPosition.Top;
                            lstExtender.PromptText = "Type to search..";
                            lstExtender.PromptCssClass = "ListSearchExtenderPrompt";
                            lstExtender.TargetControlID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cellD.Controls.Add(lstExtender);
                        }
                        else
                        {
                            CustDropDownList cboList = new CustDropDownList();
                            cboList.ID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cboList.CssClass = "forms_drop";
                            cboList.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                            cboList.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;

                            if (cboList.ID.Trim().ToUpper() == "CBOITEM" &&
                                    Convert.ToInt32(xtraRow["dSerial"]) == 998)
                            {
                                vouFillDropdownList voufilldrops = new vouFillDropdownList();
                                cboList.DbDataValueField = "it_code";
                                voufilldrops.fillDropDownList(cboList, "--Select Item Name--", "it_code", "it_name", "ITEM", DBPropsSession.PcvType,
                                    DBPropsSession.Behave, 
                                    lcode_vw, "it_name,it_code", 0,
                                    DBPropsSession.Vchkprod);
                                    DataTier DataAcess = new DataTier();
                                    DataAcess.Connclose(connHandle);
                            }
                            else
                            {
                                string dataFldName = Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Substring(6, Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().IndexOf("FROM") - 6);
                                DataTable dtDrop;
                                DataTier DataAcess = new DataTier();
                                DataAcess.DataBaseName = SessionProxy.DbName;
                                dtDrop = DataAcess.ExecuteDataTable(Convert.ToString(xtraRow["filtcond"]).Trim(), "tblQuery",connHandle);
                                cboList.DataSource = dtDrop;
                                cboList.DataTextField = dataFldName.Trim();
                                cboList.DataValueField = dataFldName.Trim();
                                cboList.DataBind();
                                cboList.Items.Insert(0, "-- Select --");
                            }
                            cellD.Controls.Add(cboList);

                            if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == true)
                            {
                                cboList.AutoPostBack = true;
                            }

                            if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                            {
                                cellD.Controls.Add(genValidator("cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), "--Select--"));
                            }

                            if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                            {
                                if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                    cboList.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                            Convert.ToString(xtraRow["javaScript"]).Trim());
                                else
                                    throw new Exception("Javascript Event cannot be empty");
                            }

                            if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == false)
                            {
                                ListSearchExtender lstExtender = new ListSearchExtender();
                                lstExtender.PromptPosition = ListSearchPromptPosition.Top;
                                lstExtender.PromptText = "Type to search..";
                                lstExtender.PromptCssClass = "ListSearchExtenderPrompt";
                                lstExtender.TargetControlID = "cbo_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                                cellD.Controls.Add(lstExtender);
                            }
                        }
                    }
                    else
                    {
                        Literal lt = new Literal();
                        //?"copy \"c:\\source file name with spaces.txt\" c:\\newfilename.txt"
                        lt.Text = "<span class=\"tt\" onmouseover=\"balloon.showTooltip(event,'load:divStock',1,300,null,'ctl00_ContentPlaceHolder1_hidBalQty')\">";
                        cellD.Controls.Add(lt);  
                        TextBox txtBox = new TextBox();
                        txtBox.ID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                        txtBox.MaxLength = Convert.ToInt32(xtraRow["fld_wid"]);
                        txtBox.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                        txtBox.CssClass = "form_textfield3";
                        txtBox.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                        cellD.Controls.Add(txtBox);
                        lt = new Literal();
                        lt.Text = "</span>";
                        cellD.Controls.Add(lt);  


                        

                        if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == true)
                        {
                            txtBox.AutoPostBack = true;
                        }


                        if (txtBox.ID.Trim().ToUpper() == "TXT_ITEM" &&
                            Convert.ToInt32(xtraRow["dSerial"]) == 998)
                        {
                            txtBox.TextChanged += new System.EventHandler(this.dropItem_SelectedIndexChanged);

                            AutoCompleteExtender autoCompXItem = new AutoCompleteExtender();
                            autoCompXItem.BehaviorID = "autocompxtenderitem";
                            autoCompXItem.ServicePath = "listHelp.asmx";
                            autoCompXItem.TargetControlID = "txt_Item";
                            autoCompXItem.ServiceMethod = "getList";
                            autoCompXItem.Enabled = true;
                            autoCompXItem.EnableCaching = true;
                            autoCompXItem.ContextKey = "ITEM"; 
                            autoCompXItem.MinimumPrefixLength = 1;
                            autoCompXItem.UseContextKey = true;
                            autoCompXItem.CompletionInterval = 1000;
                            autoCompXItem.CompletionSetCount = 20;
                            autoCompXItem.CompletionListCssClass="autocomplete_completionListElement";
                            autoCompXItem.CompletionListItemCssClass = "autocomplete_listItem";
                            autoCompXItem.CompletionListHighlightedItemCssClass = "autocomplete_highlightedListItem";
                            autoCompXItem.OnClientPopulating = "ShowImageForItem";
                            autoCompXItem.OnClientPopulated = "HideImageForItem";

                            //autoCompXItem.CompletionListHighlightedItemCssClass="AutoCompleteExtender_CompletionList";
                            //autoCompXItem.CompletionListCssClass = "AutoCompleteExtender_HighlightedItem";
                            //autoCompXItem.CompletionListItemCssClass = "AutoCompleteExtender_CompletionListItem"; 
                            cellD.Controls.Add(autoCompXItem);

                            TextBoxWatermarkExtender txtBoxWMXItName = new TextBoxWatermarkExtender();
                            txtBoxWMXItName.WatermarkCssClass = "watermarked";
                            txtBoxWMXItName.TargetControlID = "txt_Item";
                            txtBoxWMXItName.WatermarkText = "Type Here for Search Item";
                            cellD.Controls.Add(txtBoxWMXItName);  

                            HiddenField hidBalQty = new HiddenField();
                            hidBalQty.ID = "hidBalQty";
                            HiddenField hidDropItemTag = new HiddenField();
                            hidDropItemTag.ID = "hidDropItemTag";
                            HiddenField hidInvStk = new HiddenField();
                            hidInvStk.ID = "hidInvStk";
                            HiddenField hidNegItBal = new HiddenField();
                            hidNegItBal.ID = "hidNegItBal";
                            HiddenField hidNonStk = new HiddenField();
                            hidNonStk.ID = "hidNonStk";

                            cellD.Controls.Add(hidBalQty);
                            cellD.Controls.Add(hidDropItemTag);
                            cellD.Controls.Add(hidInvStk);
                            cellD.Controls.Add(hidNegItBal);
                            cellD.Controls.Add(hidNonStk);
                            txtBox.Attributes.Add("onfocus", "javascript:DropItemFocus();");

                            //HtmlGenericControl divHtml = new HtmlGenericControl("div");

                            //divHtml.ID = "divStockTitle";

                            //divHtml.Style.Add("display", "none");
                            //GridView grdStock = new GridView();
                            //grdStock.ID = "grdStock";
                            //grdStock.AutoGenerateColumns = false;
                            //grdStock.AlternatingRowStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                            //grdStock.AlternatingRowStyle.ForeColor = System.Drawing.Color.Black;
                            //grdStock.EditRowStyle.BackColor = System.Drawing.Color.BlueViolet;
                            //grdStock.HeaderStyle.BackColor = System.Drawing.Color.Gainsboro;
                            //grdStock.HeaderStyle.ForeColor = System.Drawing.Color.Brown;
                            //grdStock.RowStyle.BackColor = System.Drawing.Color.Transparent;

                            //BoundField bndField = new BoundField();
                            //bndField.DataField = "it_code";
                            //bndField.HeaderText = "Item code";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "it_name";
                            //bndField.HeaderText = "Item Name";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "stockBal";
                            //bndField.HeaderText = "Phy. Stock";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "stockPoBal";
                            //bndField.HeaderText = "Open PO.";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "stockSOBal";
                            //bndField.HeaderText = "Open SO(-)";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "logicalstk";
                            //bndField.HeaderText = "Logical Stock";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);
                            //grdStock.Font.Size = 7;
                            //grdStock.Font.Bold = true;
                            //grdStock.Width = Unit.Parse("98%");
                            //divHtml.InnerText = "Stock Details";
                            ////border-right: darkred 1px solid; border-top: darkred 1px solid; border-left: darkred 1px solid; border-bottom: darkred 1px solid; 
                            //divHtml.Attributes["Style"] = "clear: both; height:auto; text-align:center; width=98%" +
                            //    "font-weight: bold; font-size: 7pt; color: darkred; font-family: Verdana; background-color: WhiteSmoke; float: left;";



                            //divHtml.Controls.Add(grdStock);
                            //cellD.Controls.Add(divHtml);
                        }

                        if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                        {
                            if (txtBox.ID.Trim().ToUpper() == "TXT_ITEM" &&
                               Convert.ToInt32(xtraRow["dSerial"]) == 998)
                            {
                                Sample.Web.UI.Compatibility.RequiredFieldValidator reqFldValidator = new Sample.Web.UI.Compatibility.RequiredFieldValidator();
                                reqFldValidator.ID = "reqItem";
                                reqFldValidator.ControlToValidate = txtBox.UniqueID;
                                reqFldValidator.Display = ValidatorDisplay.Static;
                                reqFldValidator.Text = " * ";
                                reqFldValidator.ValidationGroup = "valGrpITDet";
                                reqFldValidator.ErrorMessage = "Item cannot be blank..!!!";
                                reqFldValidator.SetFocusOnError = true;
                                reqFldValidator.Enabled = true;
                                reqFldValidator.Visible = true;
                                reqFldValidator.EnableViewState = true;
                                reqFldValidator.EnableClientScript = true;
                                cellD.Controls.Add(reqFldValidator); 
                            }
                            else
                            {
                                cellD.Controls.Add(genValidator("txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), ""));
                            }
                        }

                        if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                        {
                            if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                txtBox.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                        Convert.ToString(xtraRow["javaScript"]).Trim());
                            else
                                throw new Exception("Javascript Event cannot be empty");
                        }
                    }
                    break;
                case "DATETIME":
                    TextBox txtXDate = new TextBox();
                    txtXDate.ID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    txtXDate.CssClass = "form_textfield3";
                    txtXDate.Width = 80;
                    txtXDate.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                    getDateFormat DateFormat = new getDateFormat();
                    //xtraSetValue<DateTime> dtGetDefaValue = new xtraSetValue<DateTime>();
                    
                    //try
                    //{
                    //    if (data_vw != null)
                    //        if (DateFormat.TodateTime(data_vw[Convert.ToString(xtraRow["fld_nm"])]) > Convert.ToDateTime("01/01/1900"))
                    //            retDate = dtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                    //        else
                    //            retDate = dtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                    //    else
                    //        retDate = dtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));

                        
                    //}
                    //catch (Exception Ex)
                    //{
                    //    throw new Exception(Ex.Message);
                    //}

                    DateTime retDate = DateTime.MinValue;
                    if (retDate == DateTime.MinValue || retDate == DateTime.MaxValue)
                    {
                        txtXDate.Text = "";
                    }
                    else
                    {
                        if (retDate > Convert.ToDateTime("01/01/1900"))
                            txtXDate.Text = DateFormat.dateformatBR(Convert.ToString(retDate).Trim());
                        else
                            txtXDate.Text = "";
                    }

                    cellD.Controls.Add(txtXDate);
                    cellD.Controls.Add(new LiteralControl("&nbsp;"));

                    if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                            txtXDate.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                    Convert.ToString(xtraRow["javaScript"]).Trim());
                        else
                            throw new Exception("Javascript Event cannot be empty");
                    }

                    ImageButton imgBtnCal = new ImageButton();
                    imgBtnCal.ID = "imgBtn_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    imgBtnCal.ImageUrl = "~/images/Calendar_scheduleHS.png";
                    imgBtnCal.CausesValidation = false;
                    cellD.Controls.Add(imgBtnCal);

                    CalendarExtender calExtender = new CalendarExtender();
                    calExtender.ID = "calExt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.PopupButtonID = "imgBtn_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.TargetControlID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.Format = "dd/MM/yyyy";
                    calExtender.PopupPosition = CalendarPosition.TopLeft;
                    //calExtender.CssClass = "CalendarExtender";
                    cellD.Controls.Add(calExtender);

                    MaskedEditExtender maskEditExtender = new MaskedEditExtender();
                    maskEditExtender.ID = "maskExt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    maskEditExtender.TargetControlID = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    maskEditExtender.Mask = "99/99/9999";
                    maskEditExtender.MessageValidatorTip = true;
                    maskEditExtender.OnFocusCssClass = "MaskedEditFocus";
                    maskEditExtender.OnInvalidCssClass = "MaskedEditError";
                    maskEditExtender.MaskType = MaskedEditType.Date;
                    maskEditExtender.DisplayMoney = MaskedEditShowSymbol.Left;
                    maskEditExtender.AcceptNegative = MaskedEditShowSymbol.Left;
                    maskEditExtender.ErrorTooltipEnabled = true;
                    maskEditExtender.UserDateFormat = MaskedEditUserDateFormat.DayMonthYear;
                    cellD.Controls.Add(maskEditExtender);

                    //RegularExpressionValidator ReqFldValid = new RegularExpressionValidator();
                    Sample.Web.UI.Compatibility.RegularExpressionValidator ReqFldValid = new Sample.Web.UI.Compatibility.RegularExpressionValidator();
                    ReqFldValid.ControlToValidate = "txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    ReqFldValid.ValidationExpression = "(0[1-9]|(1[0-9])|(2[0-9])|(3[0-1]))/(0[1-9]|(1[0-2]))/(200[5678910]$)";
                    ReqFldValid.SetFocusOnError = true;
                    ReqFldValid.ToolTip = "Invalid Date Format";
                    ReqFldValid.Display = ValidatorDisplay.Static;
                    ReqFldValid.ErrorMessage = "Invalid Date";
                    ReqFldValid.EnableViewState = true;
                    ReqFldValid.EnableClientScript = true;
                    ReqFldValid.ValidationGroup = "valGrpITDet"; 
                    cellD.Controls.Add(ReqFldValid);
                    
                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("txt_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req_" + Convert.ToString(xtraRow["fld_nm"]).Trim(), "__\\__\\"));

                    }

                    break;

            }
            //htmlRow.Cells.Add(cellD);
            htmlRow.Controls.Add(cellD);

            return htmlRow; 
        }

        protected RequiredFieldValidator genValidator(string cntValidate, string errMess, string Id, string initValue)
        {
            //RequiredFieldValidator reqFldValidator = new RequiredFieldValidator();
            Sample.Web.UI.Compatibility.RequiredFieldValidator reqFldValidator = new Sample.Web.UI.Compatibility.RequiredFieldValidator();
            reqFldValidator.ID = Id.Trim();
            reqFldValidator.ControlToValidate = cntValidate;
            reqFldValidator.Display = ValidatorDisplay.Static; 
            reqFldValidator.ValidationGroup = "valGrpITDet"; 
            reqFldValidator.ErrorMessage = errMess.Trim();
            reqFldValidator.SetFocusOnError = true;
            reqFldValidator.InitialValue = initValue.Trim();
            reqFldValidator.Enabled = true;
            reqFldValidator.EnableViewState = true;
            reqFldValidator.EnableClientScript = true; 
            reqFldValidator.Visible = true;
            reqFldValidator.Text = "*";
            return reqFldValidator;
        }

        protected void btnItemUpdate_Click(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            DataRow RetItemRow = null;
            RetItemRow = SessionProxy.RetItemRow;

            //uwTRTrigItemTextChanged TRTrigItem = new uwTRTrigItemTextChanged();
            //TRTrigItem.item_Update(sender, e);
   
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
            TransactionEvent.btnitadd_Click(MainDataSet,
                grdCharges,
                GridAccount,
                GridItem,
                grdlAllocDet,
                tblItDetails,
                pnlItDetails,
                txtGrossAmt,
                txtdedBefTax,
                txtTaxCharges,
                txtTaxExAmt,
                txtAddCharges,
                txtTaxAmt,
                txtNonTax,
                txtfdisc,
                txtRoundoff,
                txtNetAmountTax,
                txtItemTotal,
                txtTotalQty,
                txtNetAmount,
                txtAccNetAmount,
                txtdate,
                hidItRowItSerial,
                ref RetItemRow);

                // Remove value of hidden field after close Item details
                hidForItemNo.Value = "";

                SessionProxy.MainDataSet = MainDataSet;
                MainDataSet.Dispose();
                if (RetItemRow == null)
                    SessionProxy.RetItemRow = null;
                else
                    SessionProxy.RetItemRow = RetItemRow;
            //}

        }

        protected bool showItemListWithExcise(DataSet MainDataSet)
        {
            vuStockCheck StockCheck = new vuStockCheck();
            bool isFound = false;
            try
            {


                DataTable curLitem = GenStock(0, MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["Manufact"],
                        MainDataSet.Tables["lcode_vw"],
                        MainDataSet.Tables["litemall_vw"], null,
                        DBPropsSession.VarETGoDown,
                        DBPropsSession.Tex_exe,
                        SessionProxy.Tex_ExAr);

                string[] filterExpBal = new string[DBPropsSession.Tex_exe + 2];
                filterExpBal[0] ="SUM(balqty)";
                filterExpBal[1] ="SUM(balqty1)";
 
                //uday
                int arrcnt = 1;
                for (int i = 0; i < DBPropsSession.Tex_exe; i++)
                {
                    arrcnt = arrcnt + 1;
                    filterExpBal[arrcnt] = "SUM(" + SessionProxy.Tex_ExAr[i, 2].Trim() + ")";
                }

                decimal sumTot = 0;
                DataView curview = curLitem.DefaultView;
                DataTable curFilterview = new DataTable();
                numericFunction numFunction = new numericFunction();

                foreach (DataRow curLitemRow in curLitem.Rows)
                {
                    curview.RowFilter = "it_code = " +
                            numFunction.toInt32(curLitemRow["it_code"]);
                    curFilterview = curview.ToTable();
                    foreach (string sumstr in filterExpBal)
                    {
                        if (sumstr != null)
                        {
                            sumTot = (decimal)curFilterview.Compute(sumstr, "");
                            if (sumTot >= 0)
                            {
                                isFound = true;
                                break;
                            }
                        }
                    }
                }
                curFilterview.Dispose();  
                curview.Dispose();
                curLitem.Dispose();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            return isFound;
        }
        protected bool ETValidationForItem(DataSet MainDataSet)
        {
            boolFunction bitFunction = new boolFunction();
            stringFunction strFunction = new stringFunction();
            numericFunction numFunction = new numericFunction();

            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 &&
                strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Rule"]).Trim().ToUpper(),
                        new string[] { "EXCISE", "NON-EXCISE" }) == true)
            {
                if ((DBPropsSession.PcvType == "AR" || DBPropsSession.Behave == "AR") ||
                    ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                    bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false))
                {
                    if (numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]) == 0)
                    {
                        DisplayMessage("Consignor name cannot be blank..");
                        return false;
                    }
                }

                if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS" })) ||
                    ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                    bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false))
                {
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "GT" }) == true ||
                         strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "GT" }) == true) &&
                         (numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]) == 0))
                    {
                        DisplayMessage("Consignee name cannot be blank..");
                        return false;
                    }
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS" }) == true))
                    {
                        if (showItemListWithExcise(MainDataSet) == false)
                        {
                            string mess = (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
                                "No Modavatable" : "NO ") + "Stock Available..., No Addition...";

                            DisplayMessage(mess);
                            return false;
                        }
                    }

                }
            }
            return true;
        }

        protected void imgITNew_Click(object sender, ImageClickEventArgs e)
        {

            DataSet MainDataSet = SessionProxy.MainDataSet;
            if (ETValidationForItem(MainDataSet) == false)
                return;
            DataView grdItemColView = SessionProxy.GridItemColView;  
            GenGridItemRows(grdItemColView,MainDataSet);

            //TextBox txtItem = ((TextBox)((Control)sender).Parent.Parent.FindControl("txtitem"));
            //NumericTextBox txtQty = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numqty"));
            //NumericTextBox txtRate = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numrate"));
            //GridView grdStock = ((GridView)((Control)sender).Parent.Parent.FindControl("grdStock"));
            //HiddenField hidbalQty = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidbalQty"));
            //HiddenField hidDropItemTag = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidDropItemTag"));
            //HtmlGenericControl divHtml = new HtmlGenericControl("div");
            //divHtml = ((HtmlGenericControl)((Control)sender).Parent.Parent.FindControl("divStockTitle"));

 
            //UpdatePanel updtPanelQty = new UpdatePanel();
            //updtPanelQty.UpdateMode = UpdatePanelUpdateMode.Conditional;
            //updtPanelQty.ChildrenAsTriggers = false;
            //updtPanelQty.ContentTemplateContainer.Controls.Add(txtQty);
            //AsyncPostBackTrigger trigger = new AsyncPostBackTrigger();
            //trigger.ControlID = txtItem.ID;
            //trigger.EventName = "TextChanged";
            //updtPanelQty.Triggers.Add(trigger);
            //form1.Controls.Add(updtPanelQty);

            //UpdatePanel updtPanelRate = new UpdatePanel();
            //updtPanelRate.UpdateMode = UpdatePanelUpdateMode.Conditional;
            //updtPanelRate.ChildrenAsTriggers = false;
            //updtPanelRate.ContentTemplateContainer.Controls.Add(txtRate);
            //trigger = new AsyncPostBackTrigger();
            //trigger.ControlID = txtItem.ID;
            //trigger.EventName = "TextChanged";
            //updtPanelRate.Triggers.Add(trigger);
            //form1.Controls.Add(updtPanelRate);

            //updtPanelItem.ContentTemplateContainer.Controls.Add(grdStock);
            //updtPanelItem.ContentTemplateContainer.Controls.Add(hidbalQty);
            //updtPanelItem.ContentTemplateContainer.Controls.Add(hidDropItemTag);
            //updtPanelItem.ContentTemplateContainer.Controls.Add(divHtml);
            //AsyncPostBackTrigger trigger = new AsyncPostBackTrigger();
            //trigger.ControlID = txtItem.ID;
            //trigger.EventName = "TextChanged";
            //updtPanelItem.Triggers.Add(trigger);
            //form1.Controls.Add(updtPanelItem);  
 
            DataTable itemvwClone = MainDataSet.Tables["item_vw"].Clone();    
            DataRow itemRowClone =  itemvwClone.NewRow();
            getNullUpdate DataNullUpdate = new getNullUpdate();
            itemRowClone = DataNullUpdate.NullUpdate(itemRowClone);
            itemvwClone.Rows.Add(itemRowClone);   
            ItemGridEvents ItemEvents = new ItemGridEvents();
            itemRowClone = ItemEvents.addItemCharges(MainDataSet.Tables["dcmast_vw"],
                                      itemvwClone.Rows[0],
                                      MainDataSet.Tables["main_vw"],
                                      MainDataSet.Tables["lother_vw"],
                                      DBPropsSession.Vchkprod,
                                      DBPropsSession.PcvType,
                                      DBPropsSession.Behave, true);

            vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
            SetGridValue.btnClick(tblItDetails,
                        itemRowClone,
                        "UNBOXING",
                        new string[] { "item", "qty", "rate" });

            itemvwClone.Dispose(); // remove table
   
            vuGenerateNo genItemNo = new vuGenerateNo();
            //Label lblItemNo = ((Label)tblItDetails.FindControl("lbl_stditem_no"));
            Label lblItemNo = ((Label)tblItDetails.FindControl("lbl_item_no"));

            lblItemNo.Text = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
            hidForItemNo.Value = lblItemNo.Text;
            pnlItDetails.Style.Add("display", ""); 
            lblPnlItCap.Text = "New Item Details"; 
            btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");
            hidItRowItSerial.Value = "|NEW"; // store status into hidden  variable
            SessionProxy.MainDataSet = MainDataSet;
            //grdItemColView.Dispose();
            itemvwClone.Dispose();
            MainDataSet.Dispose();
            TextBox txtItem = ((TextBox)((Control)sender).Parent.Parent.FindControl("txt_item"));
            ScriptManager1.SetFocus(txtItem);  
        }

        protected void imgITEdit_Click(object sender, ImageClickEventArgs e)
        {
            System.Drawing.ColorConverter colConvert = new System.Drawing.ColorConverter();
            string keyValue = "";
            bool isSelect = false;
            for (int i = 0; i < GridItem.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)GridItem.Rows[i].FindControl("chkSelect");
                if (isSelect == true && chkSelect.Checked == true)
                {
                    //pnlItDetails.Visible = false;
                    pnlItDetails.Style.Add("display", "none"); 
                    return;
                }


                if (chkSelect.Checked == true)
                {
                    keyValue += GridItem.DataKeys[i].Values[0].ToString().Trim();
                    isSelect = true;
                }
            }

            if (isSelect == false)
            {
                return; 
            }

            DataRow editRow;
            DataSet MainDataSet = SessionProxy.MainDataSet;
            if (ETValidationForItem(MainDataSet) == false)
                return;
            editRow = MainDataSet.Tables["item_vw"].Select("ItSerial='" + keyValue  + "'")[0];
            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
                SessionProxy.RetItemRow = editRow; 

            DataView grdItemColView = SessionProxy.GridItemColView;
            GenGridItemRows(grdItemColView,MainDataSet);
            //Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));
            Label lblItemNo = ((Label)tblItDetails.FindControl("lbl_item_no"));
            lblItemNo.Text = Convert.ToString(editRow["item_no"]).Trim();
            hidForItemNo.Value = lblItemNo.Text;
            hidItRowItSerial.Value = keyValue + "|" + "EDIT"; // Temp store Item serial in hiddenfield 
            vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
            SetGridValue.btnClick(tblItDetails, editRow, "UNBOXING",null);
            
            pnlItDetails.Style.Add("display", ""); 
            lblPnlItCap.Text = "Edit Item Details"; 
            btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");
            
            for (int i = 0; i < GridItem.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)GridItem.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    GridItem.Rows[i].BackColor = (System.Drawing.Color)colConvert.ConvertFromString("#fafad2");
                    GridItem.Rows[i].ForeColor = (System.Drawing.Color)colConvert.ConvertFromString("Red");
                }
            }
            MainDataSet.Dispose();
        }

        protected void imgITDelete_Click(object sender, ImageClickEventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            try
            {
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                TransactionEvent.GridItem_RowDeleting(ref MainDataSet,
                        GridItem,
                        grdCharges,
                        GridAccount,
                        grdlAllocDet,
                        txtItemTotal,
                        txtTotalQty,
                        txtNetAmount,
                        txtAccNetAmount,
                        txtGrossAmt,
                        txtdedBefTax,
                        txtTaxCharges,
                        txtTaxExAmt,
                        txtAddCharges,
                        txtTaxAmt,
                        txtNonTax,
                        txtfdisc,
                        txtRoundoff,
                        txtNetAmountTax);

                SessionProxy.MainDataSet = MainDataSet;
            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message.Trim());
                return;
            }
            finally
            {
                MainDataSet.Dispose();
                DataTier DataAcess = new DataTier();
                DataAcess.Connclose(connHandle);
            }

        }


        protected void btnExciseDetail_Click(object sender, EventArgs e)
        {
            HeaderDetPostBackForExcise();
 
            if (DBPropsSession.Vchkprod.IndexOf("vutex") >=0) 
            {
                DataSet MainDataSet = SessionProxy.MainDataSet;
                getDateFormat GetDateFormat = new getDateFormat();
                if (DBPropsSession.PcvType == "AR" || DBPropsSession.Behave == "AR")
                {
                    if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                        cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                    {
                        if (tblBill.Visible == true)
                        {
                            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvno"] = txtBillNo.Text;
                            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvdt"] = GetDateFormat.TodateTime(txtBillDate.Text);     
                            MainDataSet.Tables["main_vw"].AcceptChanges();  
                        }

                        SessionProxy.DsETHeaderDetail = MainDataSet;

                        string url = "uwETARHeaderDetail.aspx?AddMode=" + Convert.ToString(DBPropsSession.AddMode).Trim() + "&editMode=" +
                                    Convert.ToString(DBPropsSession.EditMode).Trim() + "&pcvType=" + Convert.ToString(DBPropsSession.PcvType).Trim() +
                                    "&beHave=" + Convert.ToString(DBPropsSession.Behave).Trim() + "&vChkProd=" + Convert.ToString(DBPropsSession.Vchkprod).Trim() +
                                    "&entryTbl=" + Convert.ToString(DBPropsSession.Entry_Tbl).Trim();

                        ScriptManager.RegisterStartupScript(this, this.GetType(), null, "OpenModalDialog('" + url + "',300,500,'" + btnHDExcisePostBack.ClientID + "');", true);
                    }
                }
                else
                {
                    if (DBPropsSession.PcvType == "DC" || DBPropsSession.Behave == "DC")
                    {
                        if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                            cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                        {

                            SessionProxy.DsETHeaderDetail  = MainDataSet;

                            string url = "uwETDCHeaderDetail.aspx?AddMode=" + Convert.ToString(DBPropsSession.AddMode).Trim() + "&editMode=" +
                                        Convert.ToString(DBPropsSession.EditMode).Trim() + "&pcvType=" + Convert.ToString(DBPropsSession.PcvType).Trim() +
                                        "&beHave=" + Convert.ToString(DBPropsSession.Behave).Trim() + "&vChkProd=" + Convert.ToString(DBPropsSession.Vchkprod).Trim() +
                                        "&entryTbl=" + Convert.ToString(DBPropsSession.Entry_Tbl).Trim();

                            ScriptManager.RegisterStartupScript(this, this.GetType(), null, "OpenModalDialog('" + url + "',400,710,'" + btnHDExcisePostBack.ClientID + "');", true);
                        }
                    }
                    else
                        if (DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT")
                        {
                            if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                                cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                            {

                                SessionProxy.MainDataSet = MainDataSet;

                                string url = "uwETGTHeaderDetail.aspx";

                                ScriptManager.RegisterStartupScript(this, this.GetType(), null, "OpenModalDialog('" + url + "',350,720,'" + btnHDExcisePostBack.ClientID + "');", true);
                            }

                        }
                }
                MainDataSet.Dispose();
            }       
        }

        protected void cboRule_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboRule.SelectedIndex == 0)
                return;

            DataSet MainDataSet = SessionProxy.MainDataSet;

            MainDataSet.Tables["main_vw"].Rows[0]["rule"] = cboRule.SelectedItem.Text.ToString().Trim();
            MainDataSet.Tables["main_vw"].AcceptChanges();

            SessionProxy.MainDataSet = MainDataSet;
            MainDataSet.Dispose(); 
            ScriptManager1.SetFocus(cboRule);  
        }

        protected void btnHDExcisePostBack_Click(object sender, EventArgs e)
        {
            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
            {
                DataSet MainDataSet = new DataSet();
                if (DBPropsSession.PcvType == "AR" || DBPropsSession.Behave == "AR")
                {
                    MainDataSet = SessionProxy.DsETHeaderDetail;
                    SessionProxy.DsETHeaderDetail = null; 
                    SessionProxy.MainDataSet = MainDataSet;        
                }
                else
                {
                    if (DBPropsSession.PcvType == "DC" || DBPropsSession.Behave == "DC")
                    {
                        MainDataSet = SessionProxy.DsETHeaderDetail;
                        SessionProxy.DsETHeaderDetail = null;
                        SessionProxy.MainDataSet = MainDataSet;
                    }
                    else
                    {
                        if (DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT")
                        {
                        }
                    }
                }
                MainDataSet.Dispose(); 
            }
            imgITNew.Focus(); 
        }


        protected void btnITExcisePostBack_Click(object sender, EventArgs e)
        {
            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
            {
                stringFunction strFunction = new stringFunction();
                getDateFormat GetDateFormat = new getDateFormat();
                if (DBPropsSession.PcvType == "AR" || DBPropsSession.Behave == "AR")
                {
                    if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                        cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                    {
                        DataSet MainDataSet = SessionProxy.MainDataSet;
                        DataRow RetItemRow = SessionProxy.RetItemRow;
                        DataTable itemvwClone = MainDataSet.Tables["item_vw"].Clone();
                        DataRow itemRowClone = null;
                        DataTier DataAcess = new DataTier();
                        DataAcess.DataBaseName = SessionProxy.DbName;

                        if (hidItRowItSerial.Value.ToString().Substring(hidItRowItSerial.Value.ToString().Trim().IndexOf('|') + 1, 3) == "NEW")
                        {
                            if (RetItemRow == null)
                            {
                                vuGenerateNo genItemNo = new vuGenerateNo();
                                getNullUpdate DataNullUpdate = new getNullUpdate();

                                string itSerialvar = "";
                                itemRowClone = itemvwClone.NewRow();
                                itemRowClone = DataNullUpdate.NullUpdate(itemRowClone);
                                itemRowClone["entry_ty"] = DBPropsSession.PcvType.Trim();
                                itemRowClone["doc_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim();
                                itemRowClone["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                                itemRowClone["pmKey"] = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["inv_stk"]).Trim();
                                itemRowClone["Item_no"] = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
                                itSerialvar = genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "itSerial", true, 5);
                                itemRowClone["ItSerial"] = itSerialvar;
                                itemRowClone["Date"] = GetDateFormat.TodateTime(txtdate.Text);

                                vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                                readDynamicTbl.btnClick(tblItDetails, itemRowClone, "BOXING", null);
                                itemvwClone.Rows.Add(itemRowClone);

                            }
                            else
                            {

                                itemRowClone = itemvwClone.NewRow();
                                itemRowClone = DataAcess.ExactScatterGatherRow(RetItemRow, itemRowClone);

                                vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                                readDynamicTbl.btnClick(tblItDetails, itemRowClone, "BOXING", null);
                                itemvwClone.Rows.Add(itemRowClone);

                            }
                        }
                        else
                        {
                            if (hidItRowItSerial.Value.ToString().Substring(hidItRowItSerial.Value.ToString().Trim().IndexOf('|') + 1, 4) == "EDIT")
                            {
                                string itSerial = hidItRowItSerial.Value.ToString().Substring(0, hidItRowItSerial.Value.ToString().Trim().IndexOf('|'));
                                DataRow itRowExist = MainDataSet.Tables["item_vw"].Select("itserial ='" + itSerial + "'")[0];
                                itemRowClone = itemvwClone.NewRow();
                                itemRowClone = DataAcess.ExactScatterGatherRow(itRowExist, itemRowClone);

                                vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                                readDynamicTbl.btnClick(tblItDetails, itemRowClone, "BOXING", null);
                                itemvwClone.Rows.Add(itemRowClone);

                             }
                        }

                        DataSet DsETItemDetail = new DataSet();
                        DsETItemDetail.Tables.Add(MainDataSet.Tables["main_vw"].Copy());
                        DsETItemDetail.Tables.Add(MainDataSet.Tables["lcode_vw"].Copy());
                        DsETItemDetail.Tables.Add(itemvwClone.Copy());
                        DsETItemDetail.Tables.Add(MainDataSet.Tables["manu_det_vw"].Copy() );
                        DsETItemDetail.Tables.Add(MainDataSet.Tables["company"].Copy());

                        SessionProxy.DsETItemDetail = DsETItemDetail;

                        DsETItemDetail.Dispose();
                        MainDataSet.Dispose();
                        itemvwClone.Dispose(); 

                        string itemNo = Convert.ToString(itemRowClone["Item_no"]).Trim();
                        string url = "uwETARItemDetail.aspx?AddMode=" + Convert.ToString(DBPropsSession.AddMode).Trim() + "&editMode=" +
                                    Convert.ToString(DBPropsSession.EditMode).Trim() + "&pcvType=" + Convert.ToString(DBPropsSession.PcvType).Trim() +
                                    "&beHave=" + Convert.ToString(DBPropsSession.Behave).Trim() + "&vChkProd=" + Convert.ToString(DBPropsSession.Vchkprod).Trim() +
                                    "&entryTbl=" + Convert.ToString(DBPropsSession.Entry_Tbl).Trim() + "&rowPos=" + itemNo;

                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',550,675,'" + btnHDITDetailExcisePostBack.ClientID + "');", true);
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',490,640,'Test');", true);
                    }
                }
                else
                {
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS" }) == true)
                    {
                        if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                            cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                        {
                            DataRow RetItemRow = SessionProxy.RetItemRow;
                            if (RetItemRow != null)
                                ETItGridExciseDetails(RetItemRow);
                        }
                    }
                }
            }            
        }

        protected void ETItGridExciseDetails(DataRow itemRow)
        {
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();

            ArrayList dblist = new ArrayList();
            dblist.Add("ExcDcMast_vw");
            dblist.Add("tax_sh_vw");
            dblist.Add("tax_sh_vw1");


            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            DataSet EtDs = new DataSet();
            EtDs = DataAcess.ExecuteDataset(EtDs,
                                "sp_ent_web_ETItGridExciseDetails",
                                            null, dblist,connHandle);
            DataAcess.Connclose(connHandle);  
            //sqlStr = "select * from dcmast where entry_ty='AR' and code ='E' " +
            //         " and att_file=0";

           
            //DataAcess.DataBaseName = SessionProxy.DbName;   

            //DataTable ExcDcMast_vw = DataAcess.ExecuteDataTable(sqlStr, "_ss");
            //sqlStr = "select * from dcmast where 1=0";

            //DataTable tax_sh_vw = DataAcess.ExecuteDataTable(sqlStr, "_tax_sh_vw");
            //DataTable tax_sh_vw1 = DataAcess.ExecuteDataTable(sqlStr, "_tax_sh_vw1");
            DataRow DiscRow = null;
            foreach (DataRow ExcDcMastRows in EtDs.Tables["ExcDcMast_vw"].Rows)
            {
                DiscRow = EtDs.Tables["tax_sh_vw"].NewRow();
                DiscRow = DataAcess.ExactScatterGatherRow(ExcDcMastRows,
                    DiscRow);

                DiscRow["def_pert"] = Convert.ToString(DiscRow["pert_name"]).Trim() != "" ?
                    numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["pert_name"]).Trim()]) :
                    numFunction.toDecimal(DiscRow["def_pert"]);
                DiscRow["def_amt"] = numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["fld_nm"]).Trim()]);
                DiscRow["excl_net"] = bitFunction.toBoolean(DiscRow["att_file"]) == false && Convert.ToString(DiscRow["code"]).Trim() == "E" ?
                    "E" : Convert.ToString(DiscRow["excl_net"]);

                EtDs.Tables["tax_sh_vw"].Rows.Add(DiscRow);   
            }

            EtDs.Tables["tax_sh_vw"].AcceptChanges();
 
            if (DBPropsSession.AddMode == true ||
                DBPropsSession.EditMode == true)
            {
                foreach (DataRow taxShVwRow in EtDs.Tables["tax_sh_vw"].Rows)
                {
                    DiscRow = EtDs.Tables["tax_sh_vw1"].NewRow();
                    DiscRow = DataAcess.ExactScatterGatherRow(taxShVwRow,
                                DiscRow);

                    if (itemRow.Table.Columns[Convert.ToString(DiscRow["fld_nm"]).Trim()]
                        .DataType.ToString().Trim().ToUpper() != "SYSTEM.DECIMAL")
                        continue;

                    DiscRow["def_pert"] = Convert.ToString(DiscRow["pert_name"]).Trim() != "" ?
                        numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["pert_name"]).Trim()]) :
                        numFunction.toDecimal(DiscRow["def_pert"]);
                    DiscRow["def_amt"] = Convert.ToString(DiscRow["fld_nm"]).Trim() != "" ?
                        numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["fld_nm"]).Trim()]) :
                        numFunction.toDecimal(DiscRow["def_amt"]);

                    EtDs.Tables["tax_sh_vw1"].Rows.Add(DiscRow);   
                }
            }


            
            grdETItDetailDC.DataSource = EtDs.Tables["tax_sh_vw1"];
            grdETItDetailDC.DataBind();
            DataAcess.Connclose(connHandle);
            EtDs.Dispose();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "PanelShow('ctl00_ContentPlaceHolder1_btnexdet','" + pnlETItDetailDC.ClientID + "');", true);
        }

        protected void btnHDITDetailExcisePostBack_Click(object sender, EventArgs e)
        {   
            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
            {
                stringFunction strFunction = new stringFunction();
                numericFunction numFunction = new numericFunction();
                if (DBPropsSession.PcvType == "AR" || DBPropsSession.Behave == "AR")
                {
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('reach in btnHDITDetailExcisePostBack');", true);

                    DataSet MainDataSet = SessionProxy.MainDataSet;
                    MainDataSet.Tables.Remove("main_vw");
                    MainDataSet.Tables.Remove("manu_det_vw");
                    MainDataSet.Tables.Add(SessionProxy.DsETItemDetail.Tables["main_vw"].Copy());
                    MainDataSet.Tables.Add((SessionProxy.DsETItemDetail.Tables["manu_det_vw"].Copy()));
                    SessionProxy.RetItemRow = SessionProxy.EtItemRow;  ;
                    DataRow RetItemRow = SessionProxy.RetItemRow;

                    SessionProxy.DsETItemDetail = null;
                    SessionProxy.EtItemRow = null; 

                    SessionProxy.MainDataSet = MainDataSet;

                    //Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));
                    Label lblItemNo = ((Label)tblItDetails.FindControl("lbl_item_no"));
                    lblItemNo.Text = Convert.ToString(RetItemRow["item_no"]).Trim();
                    hidForItemNo.Value = lblItemNo.Text;

                    vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
                    SetGridValue.btnClick(tblItDetails,
                                RetItemRow,
                                "UNBOXING",
                                new string[] { "item", "qty", "rate" });

                    SessionProxy.RetItemRow = RetItemRow;  
                }
                else
                {
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS" }) == true)
                    {
                        DataSet MainDataSet = SessionProxy.MainDataSet;
                        MainDataSet.Tables.Remove("main_vw");
                        MainDataSet.Tables.Remove("litemall_vw");
                        MainDataSet.Tables.Add(SessionProxy.DsETItemDetail.Tables["main_vw"].Copy());
                        MainDataSet.Tables.Add(SessionProxy.DsETItemDetail.Tables["litemall_vw"].Copy());
                        SessionProxy.RetItemRow = SessionProxy.EtItemRow;
                        DataRow RetItemRow = SessionProxy.EtItemRow;

                        SessionProxy.ToShow = null;
                        SessionProxy.DsETItemDetail = null;
                        SessionProxy.EtItemRow = null;
                        SessionProxy.MainDataSet = MainDataSet;

                        //Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));
                        Label lblItemNo = ((Label)tblItDetails.FindControl("lbl_item_no"));
                        lblItemNo.Text = Convert.ToString(RetItemRow["item_no"]).Trim();
                        hidForItemNo.Value = lblItemNo.Text;


                        vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
                        SetGridValue.btnClick(tblItDetails,
                                    RetItemRow,
                                    "UNBOXING",
                                    new string[] { "item" });

                        if (numFunction.toDecimal(RetItemRow["u_cvdamt"]) > 0)
                            ((GraphicalCheckBox)tblItDetails.FindControl("chkCvdPass")).Enabled = true;
                        else
                            ((GraphicalCheckBox)tblItDetails.FindControl("chkCvdPass")).Enabled = false;

                        SessionProxy.RetItemRow = RetItemRow;

                        // UpdatePanel16.Update();  
                    }
                    else
                    {
                        // Sale Return
                        if (strFunction.InList(DBPropsSession.PcvType, new string[] { "GT" }) == true ||
                                                strFunction.InList(DBPropsSession.Behave, new string[] { "GT" }) == true)
                        {
                            SessionProxy.RetItemRow = SessionProxy.EtItemRow;
                            DataRow RetItemRow = SessionProxy.EtItemRow;

                            SessionProxy.ToShow = null;
                            SessionProxy.EtItemRow = null;
                            SessionProxy.CurPurchaseDet = null;
  
                            //Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));
                            Label lblItemNo = ((Label)tblItDetails.FindControl("lbl_item_no"));
                            lblItemNo.Text = Convert.ToString(RetItemRow["item_no"]).Trim();
                            hidForItemNo.Value = lblItemNo.Text;


                            vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
                            SetGridValue.btnClick(tblItDetails,
                                        RetItemRow,
                                        "UNBOXING",
                                        new string[] { "item" });

                            SessionProxy.RetItemRow = RetItemRow;

                            // UpdatePanel16.Update();  
                        }
                    }
                }
            }

            Button btnExciseDet = ((Button)tblItDetails.FindControl("BTNEXDET"));
            ScriptManager1.SetFocus(btnExciseDet);
            btnExciseDet.Dispose();  
        }


        protected void btnPickup_Click(object sender, EventArgs e)
        {
            //DataSet MainDataSet = SessionProxy.MainDataSet;  
            //Session["company"] = MainDataSet.Tables["company"];
            //string url = "ELFERPTranPickup.aspx?pcvType=" + Convert.ToString(DBPropsSession.PcvType);
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',500,650,'" + btnAfterPickup.ClientID + "');", true);
        }

        protected void btnAfterPickup_Click(object sender, EventArgs e)
        {
            DataRow mainRow = (DataRow)Session["MainRow"];
            DataTable ItemView = (DataTable)Session["ItemView"];
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            numericFunction numFunction = new numericFunction();
            getDateFormat GetDateFormat = new getDateFormat();

            MainDataSet.Tables["main_vw"].Rows[0]["date"] = GetDateFormat.TodateTime(mainRow["trandate"]);
            MainDataSet.Tables["main_vw"].Rows[0]["inv_no"] = Convert.ToString(mainRow["tranno"]);
            if (DBPropsSession.PcvType == "AR") 
                MainDataSet.Tables["main_vw"].Rows[0]["party_nm"] = Convert.ToString(mainRow["supplier"]);
            else
                if (DBPropsSession.PcvType == "DC")
                {
                    MainDataSet.Tables["main_vw"].Rows[0]["party_nm"] = Convert.ToString(mainRow["customer"]);
                }

            MainDataSet.Tables["main_vw"].Rows[0]["ac_id"] = numFunction.toInt32(mainRow["ac_id"]);  
            MainDataSet.Tables["main_vw"].Rows[0]["rule"] = "EXCISE";
            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvno"] = Convert.ToString(mainRow["suppinvno"]).Trim();
            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvdt"] = GetDateFormat.TodateTime(mainRow["suppinvdt"]);
            MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"] = numFunction.toDecimal(mainRow["tranamount"],2);

            vuGenerateNo genItemNo = new vuGenerateNo();
            ItemGridEvents ItemEvents = new ItemGridEvents();
            DataRow ItemRow = null;
            foreach (DataRow ItemViewRow in ItemView.Rows)
            {
                ItemRow = MainDataSet.Tables["item_vw"].NewRow();
                ItemRow["Entry_ty"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim();
                ItemRow["date"] = GetDateFormat.TodateTime(mainRow["trandate"]);
                ItemRow["doc_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim();
                ItemRow["inv_no"] = Convert.ToString(mainRow["tranno"]).Trim();
                ItemRow["ac_id"] = numFunction.toInt32(mainRow["ac_id"]);
                if (DBPropsSession.PcvType == "AR") 
                    ItemRow["party_nm"] = Convert.ToString(mainRow["supplier"]).Trim();
                else
                    if (DBPropsSession.PcvType == "DC")
                        ItemRow["party_nm"] = Convert.ToString(mainRow["customer"]).Trim();

                //ItemRow["rule"] = "EXCISE";
                string itNo = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));

                ItemRow["it_code"] = numFunction.toInt32(ItemViewRow["it_code"]);
                ItemRow["Item_no"] = itNo.Trim();
                ItemRow["Itserial"] = itNo.Trim().PadLeft(5, '0');
                ItemRow["item"] = Convert.ToString(ItemViewRow["itemcode"]).Trim();
                ItemRow["qty"] = numFunction.toDecimal(ItemViewRow["qty"],2);
                ItemRow["rate"] = 0;
                ItemRow["U_xRate"] = numFunction.toDecimal(ItemViewRow["rate"]);
                ItemRow["gro_amt"] = numFunction.toDecimal(ItemViewRow["lineamount"],2);
                ItemRow["ware_nm"] = Convert.ToString(ItemViewRow["warehousecode"]).Trim();
                MainDataSet.Tables["item_vw"].Rows.Add(ItemRow);

                ItemRow = ItemEvents.addItemCharges(MainDataSet.Tables["dcmast_vw"],
                                        ItemRow,
                                        MainDataSet.Tables["main_vw"],
                                        MainDataSet.Tables["lother_vw"],
                                        DBPropsSession.Vchkprod,
                                        DBPropsSession.PcvType,
                                        DBPropsSession.Behave,false);

                MainDataSet.Tables["item_vw"].AcceptChanges(); 
            }

            MainDataSet.Tables["main_vw"].AcceptChanges();

            // Binding Header Details
            txtdate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["date"]));
            if (txtdate.Text != "")
            {
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps; 
                TransactionEvent.DateValidation(txtdate,
                    null,
                    null,
                    trduedt,
                    this.Page,
                    hidDateValid,
                    MainDataSet.Tables["main_vw"],
                    MainDataSet.Tables["Company"],
                    MainDataSet.Tables["lcode_vw"],
                    MainDataSet.Tables["item_vw"],
                    MainDataSet.Tables["acdet_vw"],
                    true);
            }
            txtdate.Focus();

            txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["inv_no"]);
            //dropParty.SelectedValue = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["ac_id"]);
            txtPartyName.Text = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["party_nm"]); 
            cboRule.SelectedValue = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["rule"]);
            txtBillNo.Text = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["u_pinvno"]);
            txtBillDate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["u_pinvdt"]));

            // Binding Item Details
            vouGridFill gridDe = new vouGridFill();
            GridItem.DataSource = MainDataSet.Tables["item_vw"];

            Session["MainDataSet"] = MainDataSet;
            MainDataSet.Dispose();

            gridDe.gridBind(GridItem, null);

       }

        protected void btnItemValid_Click(object sender, EventArgs e)
        {
            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
            {
                DataSet MainDataSet = SessionProxy.MainDataSet; 
                boolFunction bitFunction = new boolFunction();
                stringFunction strFunction = new stringFunction();
                numericFunction numFunction = new numericFunction();

                if (strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(),
                    new string[] { "EXCISE", "NON-EXCISE" }) == true &&
                    (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
                {
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS" }) == true) ||
                        ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                          bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["U_sinfo"]) == true))
                    {

                        NumericTextBox txtQty = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numqty"));
                        bool isFound = false;
                        string[] doWhat = hidItRowItSerial.Value.Split('|');
                        if (doWhat[1].ToString().Trim() == "EDIT")
                        {
                            string filterExp = "entry_ty='" + DBPropsSession.PcvType.Trim() + "' and " +
                                " tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                " and itserial='" + doWhat[0].ToString().Trim() + "'";
                            try
                            {
                                DataRow litemAllRow = MainDataSet.Tables["litemall_vw"].Select(filterExp)[0];
                                isFound = true;
                            }
                            catch { isFound = false;}
                        }

                        if (numFunction.toDecimal(txtQty.Text) == 0 || isFound == false)
                        {
                            if (bitFunction.toBoolean(MainDataSet.Tables["Manufact"].Rows[0]["ET_FLAG"]) == true ||
                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                            {
                                DBPropsSession.VarETGoDown = "";
                            }

                            if (bitFunction.toBoolean(MainDataSet.Tables["Manufact"].Rows[0]["NET_FLAG"]) == true ||
                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                            {
                                DBPropsSession.VarETGoDown = "";
                            }

                            //string[] doWhat = hidItRowItSerial.Value.Split('|');
                            vuGenerateNo genItemNo = new vuGenerateNo();
                            
                            DataRow Item_Row = null;
                            if (doWhat[1].ToString().Trim() == "NEW")
                            {
                                getDateFormat GetDateFormat = new getDateFormat();
                                getNullUpdate DataNullUpdate = new getNullUpdate();
                                Item_Row = MainDataSet.Tables["item_vw"].NewRow();
                                Item_Row = DataNullUpdate.NullUpdate(Item_Row);
                                Item_Row["entry_ty"] = DBPropsSession.PcvType.Trim();
                                Item_Row["doc_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim();
                                Item_Row["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                                Item_Row["pmKey"] = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["inv_stk"]).Trim();
                                Item_Row["Item_no"] = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
                                Item_Row["ItSerial"] = genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "itSerial", true, 5);
                                Item_Row["Date"] = GetDateFormat.TodateTime(txtdate.Text);
                            }
                            else
                            {
                                if (doWhat[1].ToString().Trim() == "EDIT")
                                {
                                    Item_Row = MainDataSet.Tables["item_vw"].Select("ItSerial = '" + doWhat[0].ToString().Trim() + "'")[0];
                                }
                            }

                             // Retrive data from dynamic columns to item_vw
                            vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                            readDynamicTbl.btnClick(tblItDetails, Item_Row,"BOXING",null);
                            eTradingSelectQty(Item_Row,
                                            MainDataSet.Tables["main_vw"],
                                            MainDataSet.Tables["lcode_vw"],
                                            MainDataSet.Tables["Manufact"],
                                            MainDataSet.Tables["litemall_vw"],
                                            MainDataSet.Tables["company"]);
                        }
                    }
                }
                MainDataSet.Dispose();
            }

        }

        protected void eTradingSelectQty(DataRow itemRow,
        DataTable main_vw,
        DataTable lcode_vw,
        DataTable coAdditional,
        DataTable litemall_vw,
        DataTable company)
        {
            if (DBPropsSession.AddMode == true || DBPropsSession.EditMode == true)
            {
                stringFunction strFunction = new stringFunction();
                numericFunction numFunction = new numericFunction();
                getDateFormat GetDateFormat = new getDateFormat();
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName; 

                if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                    strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS" }) == true)
                {
                    vuStockCheck StockEvents = new vuStockCheck();
                    DataTable CurLitem1 = StockEvents.GenStock(numFunction.toInt32(itemRow["it_code"]),
                                                    main_vw,
                                                    coAdditional,
                                                    lcode_vw,
                                                    litemall_vw,
                                                    itemRow,
                                                    DBPropsSession.VarETGoDown,
                                                    DBPropsSession.Tex_exe,
                                                    SessionProxy.Tex_ExAr);
                    

                    DataTable ToShow = new DataTable();
                    DataColumn ToShowCol = null;

                    GenCol(ToShowCol, "System.Boolean", "ToCheck", ToShow);
                    GenCol(ToShowCol, "System.String", "Inv_no", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "Date", ToShow);
                    GenCol(ToShowCol, "System.String", "SuppName", ToShow);
                    GenCol(ToShowCol, "System.String", "SuppLoc", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Suppac_id", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Suppsac_id", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "Excbal", ToShow);

                    string fldname = "";
                    for (int tex_exs = 0; tex_exs < DBPropsSession.Tex_exe; tex_exs++)
                    {
                        fldname = "";
                        fldname = SessionProxy.Tex_ExAr[tex_exs, 2].ToString().Trim();
                        if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                        {
                            GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                        }

                        fldname = "";
                        fldname = SessionProxy.Tex_ExAr[tex_exs, 3].ToString().Trim();
                        if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                        {
                            GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                        }
                    }

                    GenCol(ToShowCol, "System.String", "u_pinvno", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "u_pinvdt", ToShow);
                    GenCol(ToShowCol, "System.String", "pu_pinvno", ToShow);
                    GenCol(ToShowCol, "System.String", "ware_nm", ToShow);
                    GenCol(ToShowCol, "System.String", "manuname", ToShow);
                    GenCol(ToShowCol, "System.String", "manuloc", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Manuac_id", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Manusac_id", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "pu_pinvdt", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "balqty", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "alloqty", ToShow);
                    GenCol(ToShowCol, "System.String", "rgpage", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "mtduty", ToShow);
                    GenCol(ToShowCol, "System.String", "entry_ty", ToShow);
                    GenCol(ToShowCol, "System.String", "item_no", ToShow);
                    GenCol(ToShowCol, "System.Int32", "tran_cd", ToShow);
                    GenCol(ToShowCol, "System.String", "itserial", ToShow);
                    GenCol(ToShowCol, "System.String", "pinv_no", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "pdate", ToShow);
                    GenCol(ToShowCol, "System.String", "pentry_ty", ToShow);
                    GenCol(ToShowCol, "System.String", "pitem_no", ToShow);
                    GenCol(ToShowCol, "System.Int32", "ptran_cd", ToShow);
                    GenCol(ToShowCol, "System.String", "pitserial", ToShow);
                    GenCol(ToShowCol, "System.Int32", "sentno", ToShow);
                    GenCol(ToShowCol, "System.String", "spageno", ToShow);

                    foreach (DataRow curLitemRow in CurLitem1.Rows)
                    {
                        DataRow ToShowRow = ToShow.NewRow();
                        ToShowRow["ToCheck"] = false;
                        ToShowRow["Inv_no"] = Convert.ToString(curLitemRow["u_pinvno"]).Trim();
                        ToShowRow["Date"] = GetDateFormat.TodateTime(curLitemRow["date"]);
                        ToShowRow["Suppname"] = Convert.ToString(curLitemRow["Suppname"]).Trim();
                        ToShowRow["Supploc"] = Convert.ToString(curLitemRow["Supploc"]).Trim();
                        ToShowRow["Suppac_id"] = numFunction.toInt32(curLitemRow["cons_id"]);
                        ToShowRow["Suppsac_id"] = numFunction.toInt32(curLitemRow["Scons_id"]);

                        for (int tex_exs = 0; tex_exs < DBPropsSession.Tex_exe; tex_exs++)
                        {
                            ToShowRow[SessionProxy.Tex_ExAr[tex_exs, 2]] =
                                        numFunction.toDecimal(curLitemRow[SessionProxy.Tex_ExAr[tex_exs, 2]]);
                        }
                        ToShowRow["balqty"] = numFunction.toDecimal(curLitemRow["balqty"]);
                        ToShowRow["rgpage"] = Convert.ToString(curLitemRow["rgpage"]).Trim();
                        ToShowRow["mtduty"] = numFunction.toDecimal(curLitemRow["mtduty"]);
                        ToShowRow["entry_ty"] = Convert.ToString(curLitemRow["entry_ty"]).Trim();
                        ToShowRow["tran_cd"] = numFunction.toInt32(curLitemRow["tran_cd"]);
                        ToShowRow["itserial"] = Convert.ToString(curLitemRow["itserial"]).Trim();
                        ToShowRow["u_pinvno"] = Convert.ToString(curLitemRow["u_pinvno"]).Trim();
                        ToShowRow["u_pinvdt"] = GetDateFormat.TodateTime(curLitemRow["u_pinvdt"]);
                        ToShowRow["Ware_nm"] = Convert.ToString(curLitemRow["Ware_nm"]).Trim();
                        ToShowRow["ManuName"] = Convert.ToString(curLitemRow["ManuName"]).Trim();
                        ToShowRow["ManuLoc"] = Convert.ToString(curLitemRow["ManuLoc"]).Trim();
                        ToShowRow["Manuac_id"] = numFunction.toInt32(curLitemRow["Manuac_id"]);
                        ToShowRow["Manusac_id"] = numFunction.toInt32(curLitemRow["Manusac_id"]);
                        ToShow.Rows.Add(ToShowRow);
                        ToShow.AcceptChanges();
                    }
                    
                    if (strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "SS" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "SS" }) == true)
                    {
                        string url = "uwETDCItemDetail.aspx?Tex_exe=" + DBPropsSession.Tex_exe +
                                    "&VarETGoDown=" + DBPropsSession.VarETGoDown +
                                    "&VarETGodownTo=" + DBPropsSession.VarETGodownTo;

                        DataSet DsETItemDetail = new DataSet();
                        DsETItemDetail.Tables.Add(main_vw.Copy());
                        DsETItemDetail.Tables.Add(litemall_vw.Copy());
                        DsETItemDetail.Tables.Add(coAdditional.Copy());
                        DsETItemDetail.Tables.Add(company.Copy());
                        DsETItemDetail.AcceptChanges();

                        SessionProxy.DsETItemDetail = null;
                        SessionProxy.DsETItemDetail = DsETItemDetail;
                        SessionProxy.ToShow = ToShow;
                        SessionProxy.EtItemRow = itemRow;

                        //Session["ToShow"] = ToShow;
                        //Session["main_vw"] = main_vw;
                        //Session["itemRow"] = itemRow;
                        //Session["Company"] = company;
                        //Session["CoAdditional"] = coAdditional;
                        //Session["Tex_ExAr"] = SessionProxy.PageCustomProps.Tex_ExAr;
                        //Session["litemall_vw"] = litemall_vw;

                        
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',500,750,'" + btnHDITDetailExcisePostBack.ClientID + "');", true);
                    }

                    ToShow.Dispose();
                    CurLitem1.Dispose();

                }
                else
                {
                    boolFunction bitFunction = new boolFunction();
                    if ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                        bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == true)
                    {
                        vuStockCheck StockEvents = new vuStockCheck();
                        DataTable CurLitem1 = StockEvents.GenSRStock(numFunction.toInt32(itemRow["it_code"]),
                                                        main_vw,
                                                        coAdditional,
                                                        lcode_vw,
                                                        litemall_vw,
                                                        itemRow,
                                                        DBPropsSession.VarETGoDown,
                                                        DBPropsSession.Tex_exe,
                                                        SessionProxy.Tex_ExAr);

                        DataTable ToShow = new DataTable();

                        DataColumn ToShowCol = null;

                        GenCol(ToShowCol, "System.Boolean", "ToCheck", ToShow);
                        GenCol(ToShowCol, "System.String", "Inv_no", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "Date", ToShow);
                        GenCol(ToShowCol, "System.String", "SuppName", ToShow);
                        GenCol(ToShowCol, "System.String", "SuppLoc", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Suppac_id", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Suppsac_id", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "Excbal", ToShow);

                        string fldname = "";
                        for (int tex_exs = 0; tex_exs < DBPropsSession.Tex_exe; tex_exs++)
                        {
                            fldname = "";
                            fldname = SessionProxy.Tex_ExAr[tex_exs, 2].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                            }

                            fldname = "";
                            fldname = SessionProxy.Tex_ExAr[tex_exs, 3].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                            }
                        }

                        GenCol(ToShowCol, "System.String", "u_pinvno", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "u_pinvdt", ToShow);
                        GenCol(ToShowCol, "System.String", "pu_pinvno", ToShow);
                        GenCol(ToShowCol, "System.String", "ware_nm", ToShow);
                        GenCol(ToShowCol, "System.String", "manuname", ToShow);
                        GenCol(ToShowCol, "System.String", "manuloc", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Manuac_id", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Manusac_id", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "pu_pinvdt", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "qty", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "balqty", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "alloqty", ToShow);
                        GenCol(ToShowCol, "System.String", "rgpage", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "mtduty", ToShow);
                        GenCol(ToShowCol, "System.String", "entry_ty", ToShow);
                        GenCol(ToShowCol, "System.String", "item_no", ToShow);
                        GenCol(ToShowCol, "System.Int32", "tran_cd", ToShow);
                        GenCol(ToShowCol, "System.String", "itserial", ToShow);
                        GenCol(ToShowCol, "System.String", "pinv_no", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "pdate", ToShow);
                        GenCol(ToShowCol, "System.String", "pentry_ty", ToShow);
                        GenCol(ToShowCol, "System.String", "pitem_no", ToShow);
                        GenCol(ToShowCol, "System.Int32", "ptran_cd", ToShow);
                        GenCol(ToShowCol, "System.String", "pitserial", ToShow);

                        // CurPurchaseDetail

                        DataTable curPurchaseDet = new DataTable();

                        DataColumn curPurchaseDetCol = null;

                        GenCol(curPurchaseDetCol, "System.Boolean", "ToCheck", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "Inv_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "Date", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "SuppName", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "SuppLoc", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Suppac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Suppsac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "Excbal", curPurchaseDet);

                        fldname = "";
                        for (int tex_exs = 0; tex_exs < DBPropsSession.Tex_exe; tex_exs++)
                        {
                            fldname = "";
                            fldname = SessionProxy.Tex_ExAr[tex_exs, 2].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(curPurchaseDetCol, "System.Decimal", fldname.Trim(), curPurchaseDet);
                            }

                            fldname = "";
                            fldname = SessionProxy.Tex_ExAr[tex_exs, 3].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(curPurchaseDetCol, "System.Decimal", fldname.Trim(), curPurchaseDet);
                            }
                        }

                        GenCol(curPurchaseDetCol, "System.String", "u_pinvno", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "u_pinvdt", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pu_pinvno", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "ware_nm", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "manuname", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "manuloc", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Manuac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Manusac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "pu_pinvdt", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "qty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "balqty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "alloqty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "rgpage", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "mtduty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "entry_ty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "item_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "tran_cd", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "itserial", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pinv_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "pdate", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pentry_ty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pitem_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "ptran_cd", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pitserial", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "rentry_ty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "rtran_cd", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "ritserial", curPurchaseDet);
                        
                        // end

                        string mfldname = "";
                        string mfields = " Excbal ";
                        string mfields1 = " Examt ";
                        for (int tex_exs = 0; tex_exs < DBPropsSession.Tex_exe; tex_exs++)
                        {
                            fldname = SessionProxy.Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                            if (fldname.Trim().ToUpper() != "EXAMT")
                            {
                                mfields1 = mfields1 + "," + fldname.Trim();
                            }
                            fldname = SessionProxy.Tex_ExAr[tex_exs, 2].Trim().Replace("ITEM_VW", "");
                            if (fldname.Trim().ToUpper() != "EXCBAL")
                            {
                                mfields = mfields + "," + fldname.Trim();
                            }
                        }

                        foreach (DataRow curLitemRow in CurLitem1.Rows)
                        {
                            sqlStr = "select pentry_ty,ptran_cd,pitserial,qty,rgpage,"
                                + mfields1.Trim().Replace("curLitem1.", "") +
                                " from litemall where entry_ty ='"
                                + Convert.ToString(curLitemRow["entry_ty"]).Trim() + "' and " +
                                " tran_cd =" + numFunction.toInt32(curLitemRow["tran_cd"]) +
                                " and itserial='" + Convert.ToString(curLitemRow["itserial"]).Trim() + "'";

                            DataTable tmptable_vw = DataAcess.ExecuteDataTable(sqlStr, "_ss", connHandle);
                            decimal totQty = 0;
                            foreach (DataRow tmptableRow in tmptable_vw.Rows)
                            {
                                totQty = totQty + numFunction.toDecimal(tmptableRow["qty"]);  
                                sqlStr = "SELECT A.TRAN_CD,A.ENTRY_TY,A.ITSERIAL,A.INV_NO,RGPAGE," +
                                         " MTDUTY,WARE_NM,B.CONS_ID AS SUPPAC_ID,B.SCONS_ID AS SUPPSAC_ID," +
                                         " A.MANUAC_ID,A.MANUSAC_ID,E.AC_NAME AS SUPPNAME,C.LOCATION_ID AS SUPPLOC," +
                                         " F.AC_NAME AS MANUNAME,D.LOCATION_ID AS MANULOC " +
                                         " FROM TRADEITEM A INNER JOIN TRADEMAIN B ON A.ENTRY_TY=B.ENTRY_TY " +
                                         " AND A.TRAN_CD=B.TRAN_CD " +
                                         " INNER JOIN AC_MAST E ON E.AC_ID = B.CONS_ID " +
                                         " LEFT JOIN SHIPTO C ON B.CONS_ID = C.AC_ID AND B.SCONS_ID = C.SHIPTO_ID " +
                                         " INNER JOIN AC_MAST F ON F.AC_ID = A.MANUAC_ID " +
                                         " LEFT JOIN SHIPTO D ON A.MANUAC_ID = D.AC_ID And A.MANUSAC_ID = D.SHIPTO_ID " +
                                         " WHERE A.ENTRY_TY ='" + Convert.ToString(tmptableRow["pentry_ty"]).Trim() + "'" +
                                         " AND A.TRAN_CD = " + numFunction.toInt32(tmptableRow["ptran_cd"]) +
                                         " AND A.ITSERIAL ='" + Convert.ToString(tmptableRow["pitserial"]).Trim() + "'";

                                DataTable tmptable_vwAr = DataAcess.ExecuteDataTable(sqlStr, "_sss",connHandle);

                                DataRow curPurchaseDetRow = curPurchaseDet.NewRow();
                                curPurchaseDetRow["ToCheck"] = false;
                                curPurchaseDetRow["ptran_cd"] = numFunction.toInt32(curLitemRow["tran_cd"]);
                                curPurchaseDetRow["pentry_ty"] = Convert.ToString(curLitemRow["entry_ty"]).Trim();
                                curPurchaseDetRow["pdate"] = GetDateFormat.TodateTime(curLitemRow["date"]);
                                curPurchaseDetRow["pitserial"] = Convert.ToString(curLitemRow["itserial"]).Trim();
                                curPurchaseDetRow["qty"] = numFunction.toDecimal(curLitemRow["qty"]);
                                curPurchaseDetRow["balqty"] = numFunction.toDecimal(curLitemRow["qty"]);
                                curPurchaseDetRow["alloqty"] = 0;

                                mfields = "";
                                mfields1 = "";
                                curPurchaseDetRow["Excbal"] = numFunction.toDecimal(tmptableRow["Examt"]);
                                for (int tex_exs = 0; tex_exs < DBPropsSession.Tex_exe; tex_exs++)
                                {
                                    mfields = SessionProxy.Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                                    mfields1 = SessionProxy.Tex_ExAr[tex_exs, 2].Trim().Replace("ITEM_VW", "");

                                    if (mfields.Trim().ToUpper() != "EXAMT")
                                    {                                    
                                        if (mfields1.Trim().ToUpper() != "EXCBAL")
                                            curPurchaseDetRow[mfields1] = numFunction.toDecimal(tmptableRow[mfields]);

                                    }
                                }

                                DataRow tmpARRow = tmptable_vwAr.Rows[0];

                                curPurchaseDetRow["rgpage"] = Convert.ToString(tmpARRow["rgpage"]);
                                curPurchaseDetRow["mtduty"] = numFunction.toDecimal(tmpARRow["mtduty"]);
                                curPurchaseDetRow["tran_cd"] = numFunction.toInt32(tmpARRow["tran_cd"]);
                                curPurchaseDetRow["entry_ty"] = Convert.ToString(tmpARRow["entry_ty"]).Trim();
                                curPurchaseDetRow["itserial"] = Convert.ToString(tmpARRow["itserial"]).Trim();
                                curPurchaseDetRow["rtran_cd"] = numFunction.toInt32(tmpARRow["tran_cd"]);
                                curPurchaseDetRow["rentry_ty"] = Convert.ToString(tmpARRow["entry_ty"]).Trim();
                                curPurchaseDetRow["ritserial"] = Convert.ToString(tmpARRow["itserial"]).Trim();
                                //curPurchaseDetRow["u_pinvno"] = Convert.ToString(tmptableRow["u_pinvno"]).Trim();
                                //curPurchaseDetRow["u_pinvdt"] = GetDateFormat.TodateTime(tmptableRow["u_pinvdt"]);
                                curPurchaseDetRow["Ware_nm"] = Convert.ToString(tmpARRow["Ware_nm"]).Trim();
                                curPurchaseDetRow["Suppname"] = Convert.ToString(tmpARRow["Suppname"]).Trim();
                                curPurchaseDetRow["SuppLoc"] = Convert.ToString(tmpARRow["SuppLoc"]).Trim();
                                curPurchaseDetRow["Suppac_id"] = numFunction.toInt32(tmpARRow["Suppac_id"]);
                                curPurchaseDetRow["Suppsac_id"] = numFunction.toInt32(tmpARRow["Suppsac_id"]);

                                curPurchaseDetRow["ManuName"] = Convert.ToString(tmpARRow["ManuName"]).Trim();
                                curPurchaseDetRow["ManuLoc"] = Convert.ToString(tmpARRow["ManuLoc"]).Trim();
                                curPurchaseDetRow["Manuac_id"] = numFunction.toInt32(tmpARRow["Manuac_id"]);
                                curPurchaseDetRow["Manusac_id"] = numFunction.toInt32(tmpARRow["Manusac_id"]);
                                curPurchaseDet.Rows.Add(curPurchaseDetRow);
                                curPurchaseDet.AcceptChanges();
                            }
 
                            DataRow ToShowRow = ToShow.NewRow();
                            ToShowRow["ToCheck"] = false;
                            ToShowRow["Inv_no"] = Convert.ToString(curLitemRow["Inv_no"]).Trim();
                            ToShowRow["Date"] = GetDateFormat.TodateTime(curLitemRow["date"]);
                            
                            mfields = "";
                            mfields1 = "";
                            ToShowRow["ExcBal"] = numFunction.toDecimal(curLitemRow["Examt"]);

                            for (int tex_exs = 0; tex_exs < DBPropsSession.Tex_exe; tex_exs++)
                            {
                                mfields = SessionProxy.Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                                mfields1 = SessionProxy.Tex_ExAr[tex_exs, 2].Trim().Replace("ITEM_VW", "");

                                if (mfields.Trim().ToUpper() != "EXAMT")
                                {
                                    if (mfields1.Trim().ToUpper() != "EXCBAL")
                                        ToShowRow[mfields1] = numFunction.toDecimal(curLitemRow[mfields]);
                                }
                            }

                            ToShowRow["qty"] = totQty; 
                            ToShowRow["balqty"] = numFunction.toDecimal(curLitemRow["qty"]);
                            ToShowRow["rgpage"] = "";
                            ToShowRow["mtduty"] = 0;
                            ToShowRow["tran_cd"] = numFunction.toInt32(curLitemRow["tran_cd"]);
                            ToShowRow["entry_ty"] = Convert.ToString(curLitemRow["entry_ty"]).Trim();
                            ToShowRow["itserial"] = Convert.ToString(curLitemRow["itserial"]).Trim();
                            ToShowRow["u_pinvno"] = "";
                            ToShowRow["u_pinvdt"] = GetDateFormat.TodateTime(Convert.ToDateTime("01/01/1900"));
                            ToShowRow["Ware_nm"] = Convert.ToString(curLitemRow["Ware_nm"]).Trim();
                            ToShowRow["Suppname"] = "";
                            ToShowRow["Supploc"] = "";
                            ToShowRow["Suppac_id"] = 0;
                            ToShowRow["Suppsac_id"] = 0;
                            ToShowRow["ManuName"] = "";
                            ToShowRow["ManuLoc"] = "";
                            ToShowRow["Manuac_id"] = 0;
                            ToShowRow["Manusac_id"] = 0;
                            ToShow.Rows.Add(ToShowRow);
                            ToShow.AcceptChanges();

                        } // end for each loop of curlitem

                        foreach (DataRow litemallRow in litemall_vw.Rows)
                        {
                            try
                            {
                                string filterExp = "rentry_ty ='" +
                                    Convert.ToString(litemallRow["rentry_ty"]).Trim() + "' and " +
                                    " rtran_cd = " + numFunction.toInt32(litemallRow["rtran_cd"]) +
                                    " and ritserial ='" + Convert.ToString(litemallRow["ritserial"]).Trim() + "'";

                                DataRow litemallFindRow = curPurchaseDet.Select(filterExp)[0];
                                litemallFindRow["balqty"] = numFunction.toDecimal(litemallFindRow["balqty"]) -
                                    numFunction.toDecimal(litemallFindRow["qty"]);
                            }
                            catch { }
                        }

                        string url = "uwETGTItemDetail.aspx?Tex_exe=" + DBPropsSession.Tex_exe;
                        SessionProxy.ToShow = ToShow;
                        SessionProxy.EtItemRow = itemRow;
                        SessionProxy.CurPurchaseDet = curPurchaseDet;

                        //Session["main_vw"] = main_vw;
                        //Session["itemRow"] = itemRow;
                        //Session["Company"] = company;
                        //Session["CoAdditional"] = coAdditional;
                        ////Session["Tex_ExAr"] = DBPropsSession.Tex_ExAr;
                        //Session["litemall_vw"] = litemall_vw;
                        //ToShow.Dispose();
                        curPurchaseDet.Dispose();


                        ScriptManager.RegisterStartupScript(this, this.GetType(), null, "OpenModalDialog('" + url + "',550,800,'" + btnHDITDetailExcisePostBack.ClientID + "');", true);
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "openWindow()", strOpenWin, true);

                        //string strOpenWin = "open_window_max('" + url +"','Report');";
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "open_window_max()", strOpenWin, true);

                    } // end GT
                }
            }
            main_vw.Dispose();
            company.Dispose();
            coAdditional.Dispose();
            litemall_vw.Dispose();
        }

        protected DataColumn GenCol(DataColumn ToShowcol,
                    string DataType,
                    string colName,
                    DataTable DbTable)
        {
            ToShowcol = new DataColumn();
            ToShowcol.DataType = Type.GetType(DataType);
            ToShowcol.ColumnName = colName;
            DbTable.Columns.Add(ToShowcol);
            return ToShowcol;
        }


        private void DateValidation(TextBox txtDatevalid,DataSet MainDataSet)
        {
            DataTable company = MainDataSet.Tables["company"];
            boolFunction bitFunction = new boolFunction();
            //DataTier DataAcess = new DataTier();
            getDateFormat GetDateFormat = new getDateFormat();
            bool Fst = false;
            SqlDataReader dr;
            try
            {
                if (!(GetDateFormat.TodateTime(txtdate.Text) >= GetDateFormat.TodateTime(company.Rows[0]["sta_dt"])
                    && GetDateFormat.TodateTime(txtdate.Text) <= GetDateFormat.TodateTime(company.Rows[0]["end_dt"])))
                {
                    if (GetDateFormat.TodateTime(txtdate.Text) < GetDateFormat.TodateTime(company.Rows[0]["sta_dt"]))
                    {
                        try
                        {
                            DataRow compRow = company.Select("end_dt < '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(company.Rows[0]["sta_dt"])) + "'")[0];
                            Fst = true;
                        }
                        catch
                        {
                            Fst = false;
                        }

                        //sqlStr = "select Top 1 CompId from servicetax..co_mast where " +
                        //    "co_name ='" + Convert.ToString(company.Rows[0]["co_name"]).Trim() + "'" +
                        //    " and end_dt < '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(company.Rows[0]["sta_dt"])) + "'";
                        //dr = DataAcess.ExecuteDataReader(sqlStr);
                        //if (dr.HasRows == true)
                        //    Fst = true;
                        //else
                        //    Fst = false;
                        //dr.Close();
                    }

                    if (GetDateFormat.TodateTime(txtdate.Text) > GetDateFormat.TodateTime(company.Rows[0]["end_dt"]))
                    {
                        try
                        {
                            DataRow compRow = company.Select("sta_dt > '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(company.Rows[0]["end_dt"])) + "'")[0];
                            Fst = true;
                        }
                        catch
                        {
                            Fst = false;
                        }

                        //sqlStr = "select Top 1 CompId from servicetax..co_mast where " +
                        //    "co_name ='" + Convert.ToString(company.Rows[0]["co_name"]).Trim() + "'" +
                        //    " and sta_dt > '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(company.Rows[0]["end_dt"])) + "'";

                        //dr = DataAcess.ExecuteDataReader(sqlStr);
                        //if (dr.HasRows == true)
                        //    Fst = true;
                        //else
                        //    Fst = true;
                        //dr.Close();
                    }

                    //DataAcess.Connclose();
                    if (Fst == false)
                    {
                        System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "DateValidation('Transaction Date Not in Financial Year. Continue anyway?','" + txtDatevalid.ClientID + "');", true);
                    }
                    else
                    {
                        if (Fst == true)
                        {
                            throw new Exception("Date not in financial year");
                        }
                    }
                }

                SessionProxy.MainDataSet = MainDataSet;
                callDateValidation();
            }
            catch (Exception ex)
            {
                DisplayMessage(ex.Message.Trim());
            }
            finally
            {
                MainDataSet.Dispose();
                company.Dispose();
            }

        }

        protected void callDateValidation()
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            DataTable company = MainDataSet.Tables["company"];
            DataTable lcode_vw = MainDataSet.Tables["lcode_vw"];
            DataTable main_vw = MainDataSet.Tables["main_vw"];
            DataTable item_vw = MainDataSet.Tables["item_vw"];
            DataTable acdet_vw = MainDataSet.Tables["acdet_vw"];
            boolFunction bitFunction = new boolFunction();
            stringFunction strFunction = new stringFunction();
            getDateFormat GetDateFormat = new getDateFormat();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            if (DBPropsSession.LbackDated == true)
            {
                if (DBPropsSession.PBackDate > GetDateFormat.TodateTime(main_vw.Rows[0]["date"]))
                {
                    DisplayMessage("Date can not be less than last entry date");
                    return;
                }
            }

            main_vw.Rows[0]["date"] = GetDateFormat.TodateTime(txtdate.Text);
            main_vw.AcceptChanges();


            if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0)
            {
                if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ||
                    Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                {
                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "AR", "IR", "GT" }) == true ||
                        strFunction.InList(DBPropsSession.Behave, new string[] { "AR", "IR", "GT" }) == true) &&
                        bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == false)
                    {
                        DataTable manu_det_vw = MainDataSet.Tables["manu_det_vw"];
                        try
                        {
                            DataRow ManuDTRow = manu_det_vw.Select("manudate < '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'")[0];
                            manu_det_vw.Dispose();
                        }
                        catch
                        {
                            manu_det_vw.Dispose();
                            DisplayMessage("Date can't be less than Manufacture Date");
                            return;
                        }
                    }

                    if ((strFunction.InList(DBPropsSession.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                            strFunction.InList(DBPropsSession.Behave, new string[] { "DC", "IR", "SS" }) == true) ||
                            ((DBPropsSession.PcvType == "GT" || DBPropsSession.Behave == "GT") &&
                            bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == false))
                    {
                        DataTable litemall_vw = MainDataSet.Tables["litemall_vw"];
                        try
                        {
                            DataRow LitemallRow = litemall_vw.Select("padate < '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'")[0];
                            litemall_vw.Dispose();

                        }
                        catch
                        {
                            litemall_vw.Dispose();
                            DisplayMessage("Date can't be less than purchase Date");
                            return;
                        }
                    }

                }
            }
            vuInit initProc = new vuInit();
            //getTables _getTables = new getTables();  
            initProc.UpdateFinYear(main_vw,
                    company,
                    main_vw);

            if (DBPropsSession.ItemPage == true)
            {
                foreach (DataRow itemRow in item_vw.Rows)
                {
                    itemRow["date"] = GetDateFormat.TodateTime(txtdate.Text);
                }
                item_vw.AcceptChanges();
            }

            if (DBPropsSession.AccountPage == true)
            {
                foreach (DataRow acdetRow in acdet_vw.Rows)
                {
                    acdetRow["date"] = GetDateFormat.TodateTime(txtdate.Text);
                }
                acdet_vw.AcceptChanges();
            }

            if (trduedt.Visible == true)
            {
                if (System.Convert.IsDBNull(main_vw.Rows[0]["due_dt"]) ||
                    !(GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]) > DBPropsSession.AppDate &&
                    GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]) < DateTime.MaxValue))
                {
                    main_vw.Rows[0]["due_dt"] = GetDateFormat.TodateTime(txtdate.Text);
                    main_vw.AcceptChanges();
                    if (txtDueDate.Text == "")
                    {
                        if (txtDueDays.Text != "")
                        {
                            txtDueDate.Text = GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]).AddDays(Convert.ToInt32(txtDueDays)).ToString("dd/MM/yyyy");
                        }
                        else
                        {
                            txtDueDate.Text = GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]).ToString("dd/MM/yyyy");
                        }
                    }
                }
            }

            MainDataSet.AcceptChanges();  
            SessionProxy.MainDataSet = MainDataSet;

            MainDataSet.Dispose();
            company.Dispose();
            lcode_vw.Dispose();
            main_vw.Dispose();
            item_vw.Dispose();
            acdet_vw.Dispose();
            DataAcess.Connclose(connHandle);
        }
        protected void btnDateValidation_Click(object sender, EventArgs e)
        {
            callDateValidation(); 
        }



        public DataTable GenStock(int ItemName,
            DataTable main_vw,
            DataTable coAdditional,
            DataTable lcode_vw,
            DataTable litemall_vw,
            DataRow itemRow,
            string varETGoDown,
            int Tex_exe,
            string[,] Tex_ExAr)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            getDateFormat DateFormat = new getDateFormat();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;


            //mentry_tyar = "";
            //mentry_tygt = "";

            bool etFlag = false;
            int pParty, pPartyS, manuName, manuNameS = 0;

            pParty = numFunction.toInt32(main_vw.Rows[0]["suppac_id"]);
            pPartyS = numFunction.toInt32(main_vw.Rows[0]["suppsac_id"]);
            manuName = numFunction.toInt32(main_vw.Rows[0]["manuac_id"]);
            manuNameS = numFunction.toInt32(main_vw.Rows[0]["manusac_id"]);

            
            etFlag = Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
                bitFunction.toBoolean(coAdditional.Rows[0]["et_flag"]) :
                bitFunction.toBoolean(coAdditional.Rows[0]["net_flag"]);

            string mFieldlist = Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() != "" ?
                Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() : "it_mast.it_name";

            string fldName, fldName1, fldnewName = "";
            fldName = mFieldlist;

            while (fldName.Trim() != "")
            {
                fldName1 = fldName.Trim().IndexOf(",") >= 0 ?
                    fldName.Trim().Substring(0, fldName.Trim().IndexOf(',')) : fldName.Trim();
                fldnewName = fldnewName + (fldnewName.Trim() != "" ? "," : "") +
                            (fldName1.Trim().IndexOf(':') >= 0 ?
                            fldName1.Trim().Substring(0, fldName1.IndexOf(':')) : fldName1.Trim());
                fldName = fldName.Trim().IndexOf(',') > 0 ?
                    fldName.Trim().Substring(fldName.Trim().IndexOf(',') + 1) : "";
            }

            SqlParameter[] spParam = new SqlParameter[12];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@date";
            spParam[0].SqlDbType = SqlDbType.DateTime;
            spParam[0].Value = DateFormat.TodateTime(main_vw.Rows[0]["date"]);

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@rule";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(main_vw.Rows[0]["rule"]).Trim();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@pPartyId";
            spParam[2].SqlDbType = SqlDbType.Int;
            spParam[2].Value = pParty;

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@sPartyId";
            spParam[3].SqlDbType = SqlDbType.Int;
            spParam[3].Value = pPartyS;

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@etflag";
            spParam[4].SqlDbType = SqlDbType.Bit; 
            spParam[4].Value = etFlag;

            spParam[5] = new SqlParameter();
            spParam[5].ParameterName = "@itcode";
            spParam[5].SqlDbType = SqlDbType.Int;
            spParam[5].Value = ItemName;

            spParam[6] = new SqlParameter();
            spParam[6].ParameterName = "@godown";
            spParam[6].SqlDbType = SqlDbType.VarChar;
            spParam[6].Value = varETGoDown;

            StringBuilder texEx = new StringBuilder();
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                texEx.Append("," + "A." + Tex_ExAr[tex_exs, 2]);
            }

            spParam[7] = new SqlParameter();
            spParam[7].ParameterName = "@AtexExAr";
            spParam[7].SqlDbType = SqlDbType.VarChar;
            spParam[7].Value = texEx.ToString().Trim();

            texEx = new StringBuilder();
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                texEx.Append("," + "B." + Tex_ExAr[tex_exs, 2]);
            }

            spParam[8] = new SqlParameter();
            spParam[8].ParameterName = "@BtexExAr";
            spParam[8].SqlDbType = SqlDbType.VarChar;
            spParam[8].Value = texEx.ToString().Trim();

            fldName = fldnewName.Trim().ToUpper().Replace("IT_MAST.", "B.");

            spParam[9] = new SqlParameter();
            spParam[9].ParameterName = "@fldname";
            spParam[9].SqlDbType = SqlDbType.VarChar;
            spParam[9].Value = fldName; 

            spParam[10] = new SqlParameter();
            spParam[10].ParameterName = "@ManuId";
            spParam[10].SqlDbType = SqlDbType.Int;
            spParam[10].Value = manuName;

            spParam[11] = new SqlParameter();
            spParam[11].ParameterName = "@ManuSId";
            spParam[11].SqlDbType = SqlDbType.Int;
            spParam[11].Value = manuNameS;

            DataTable trdtbl_vw = DataAcess.ExecuteDataTable("sp_ent_web_genstock", spParam, connHandle);
            
            //sqlstr = " select entry_ty,bcode_nm from lcode where entry_ty " +
            //         " in ('AR','IR','GT') or bcode_nm in ('AR','IR','GT') ";

            //dr = DataAcess.ExecuteDataReader(sqlstr);
            //if (dr.HasRows == true)
            //{
            //    while (dr.Read())
            //    {
            //        if (Convert.ToString(dr["entry_ty"]).Trim() == "GT" ||
            //            Convert.ToString(dr["bcode_nm"]).Trim() == "GT")
            //        {
            //            mentry_tygt = mentry_tygt + (mentry_tygt.Trim() != "" ?
            //                "," : "") + "'" + Convert.ToString(dr["entry_ty"]).Trim() + "'";
            //        }
            //        else
            //        {
            //            mentry_tyar = mentry_tyar + (mentry_tyar.Trim() != "" ?
            //                "," : "") + "'" + Convert.ToString(dr["entry_ty"]).Trim() + "'";
            //        }
            //    }
            //}
            //else
            //{
            //    dr.Close();
            //    DataAcess.Connclose();
            //    throw new Exception("ERROR!!! Lcode table not found OR Records not found in Lcode");
            //}
            //dr.Close();
            //dr.Dispose();

            ////StringBuilder mcond = new StringBuilder();
            ////mcond.Append(" ((A.Entry_ty In (" + mentry_tyar + ")) Or (A.Entry_ty In (");
            ////mcond.Append(mentry_tygt + ") And A.U_sinfo = 0)) And A.Date <='");
            ////mcond.Append(DateFormat.dateformat(DateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'");
            ////mcond.Append(Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE"
            ////             ? " And A.[Rule] = 'EXCISE' " : " And A.[Rule] In('EXCISE','NON-EXCISE') ");
            ////mcond.Append((pParty != 0 && etFlag == false) ? " And A.Cons_id = " + pParty +
            ////    " And A.Scons_id = " + pPartyS : "");

            //StringBuilder mcond = new StringBuilder();
            
            //mcond = " ((A.Entry_ty In (" + mentry_tyar + ")) Or (A.Entry_ty In (" +
            //            mentry_tygt + ") And A.U_sinfo = 0)) And A.Date <='" +
            //            DateFormat.dateformat(DateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'";
            //mcond = mcond + (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
            //    " And A.[Rule] = 'EXCISE' " : " And A.[Rule] In('EXCISE','NON-EXCISE') ");
            //mcond = mcond + ((pParty != 0 && etFlag == false) ? " And A.Cons_id = " + pParty +
            //    " And A.Scons_id = " + pPartyS : "");

            //sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Date,A.U_pinvno,A.U_pinvdt, " +
            //         " A.Cons_id,A.Scons_id,C.Ac_name As SuppName,B.Location_id As SuppLoc " +
            //         " into #tmptbl_vwv " +
            //         " From TradeMain A ";
            //sqlstr = sqlstr + " Inner Join Ac_mast C On A.Cons_id = C.Ac_id " +
            //         " Left Join Shipto B On A.Cons_id = B.Ac_id And A.Scons_id = B.Shipto_id " +
            //         " Where " + mcond;


            //try
            //{
            //    rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}

            //mcond = " ((A.Entry_ty In (" + mentry_tyar + ")) Or (A.Entry_ty In (" + mentry_tygt + "))) ";
            //mcond = mcond + (ItemName != 0 ? " And A.It_code = " + ItemName : "");
            //mcond = mcond + ((pParty != 0 && etFlag == false) ? " And A.ware_nm = '" + GodownName.Trim() + "'" : "");
            //sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Itserial,A.It_code,A.Ware_nm,A.Rgpage,A.Mtduty,A.Balqty,A.Balqty1 ";

            //for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            //{
            //    sqlstr = sqlstr + "," + "A." + Tex_ExAr[tex_exs, 2];
            //}

            //sqlstr = sqlstr + "," + fldName +
            //    " into #tmptbl_vwi " +
            //    " From TradeItem A,It_mast B Where A.It_Code = B.It_code And " + mcond;

            //try
            //{
            //    rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}


            //mcond = ((pParty != 0 && etFlag == false) ? " A.Manuac_id = " + manuName +
            //    " And A.Manusac_id = " + manuNameS : "");
            //mcond = mcond.Trim() != "" ? " Where " + mcond.Trim() : "";
            //sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Itserial,A.Manuac_id,A.Manusac_id, " +
            //    " C.Ac_name as ManuName,B.Location_id as ManuLoc " +
            //    " into #tmptbl_vwm " +
            //    " From Manu_det A";
            //sqlstr = sqlstr + " Left Join Ac_mast C On A.Manuac_id = C.Ac_id " +
            //         " Left Join Shipto B On A.Manuac_id = B.Ac_id And A.Manusac_id = B.Shipto_id " +
            //         mcond;

            //try
            //{
            //    rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}

            //sqlstr = " A.Tran_cd,A.Entry_ty,A.Date,A.U_pinvno,A.U_pinvdt,A.Cons_id,A.Scons_id,A.SuppName,A.SuppLoc," +
            //    " B.Itserial,B.It_code,B.Ware_nm,B.Rgpage,B.Mtduty,B.Balqty,B.Balqty1 ";

            //for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            //{
            //    sqlstr = sqlstr + "," + "B." + Tex_ExAr[tex_exs, 2];
            //}

            //sqlstr = sqlstr + "," + fldName + ",C.Manuac_id,C.Manusac_id,C.ManuName,C.ManuLoc ";
            //mcond = " A.Entry_ty = B.Entry_ty And A.Tran_cd = B.Tran_cd " +
            //    " And B.Entry_ty = C.Entry_ty And B.Tran_cd = C.Tran_cd And B.Itserial = C.Itserial ";
            //mcond = mcond + (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
            //    " And B.BalQty > 0 And (B.Excbal > 0 Or B.U_Cessbal > 0) " :
            //    " And B.BalQty > 0 ");

            //sqlstr = " select " + sqlstr + " From #tmptbl_vwv A,#tmptbl_vwi B,#tmptbl_vwm C " +
            //         " where " + mcond;

            //DataTable trdtbl_vw = new DataTable();
            //try
            //{
            //    trdtbl_vw = DataAcess.ExecuteDataTable(sqlstr, "_trdtbl_vw");
            //}
            //catch (Exception Ex)
            //{
            //    DataAcess.Connclose();
            //    throw Ex;
            //}

            //sqlstr = " drop table #tmptbl_vwv " +
            //         " drop table #tmptbl_vwi " +
            //         " drop table #tmptbl_vwm ";

            //DataAcess.ExecuteNonQuery(sqlstr, "TX");

            foreach (DataRow litemAllRow in litemall_vw.Rows)
            {
                try
                {
                    string filterExp = "(Entry_ty ='" + Convert.ToString(litemAllRow["pentry_ty"]).Trim() + "' and " +
                           " tran_cd = " + numFunction.toInt32(litemAllRow["ptran_cd"]) +
                           " and itserial ='" + Convert.ToString(litemAllRow["pitserial"]).Trim() + "') and " +
                           " is null date";

                    DataRow findRow = trdtbl_vw.Select(filterExp)[0];
                    findRow["balqty"] = numFunction.toDecimal(findRow["balqty"]) -
                                        numFunction.toDecimal(litemAllRow["qty"]);
                    findRow["balqty1"] = numFunction.toDecimal(findRow["balqty1"]) -
                                        numFunction.toDecimal(litemAllRow["u_lqty"]);

                    for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                    {
                        findRow[Tex_ExAr[tex_exs, 2]]
                                = numFunction.toDecimal(findRow[Tex_ExAr[tex_exs, 2]]) -
                                numFunction.toDecimal(litemAllRow[Tex_ExAr[tex_exs, 1]]);
                    }

                    if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim() == "EXCISE")
                    {
                        if (!(numFunction.toDecimal(findRow["Balqty"]) > 0 &&
                            (numFunction.toDecimal(findRow["excbal"]) > 0 ||
                             numFunction.toDecimal(findRow["u_cessbal"]) > 0)))
                        {
                            findRow.Delete();
                        }
                    }
                    else
                    {
                        if (!(numFunction.toDecimal(findRow["balqty"]) > 0))
                        {
                            findRow.Delete();
                        }
                    }
                    findRow.AcceptChanges();
                }
                catch
                {
                    if (itemRow != null)
                    {
                        if (Convert.ToString(litemAllRow["itserial"]).Trim() ==
                            Convert.ToString(itemRow["itserial"]))
                        {
                            litemAllRow["Qty"] = 0;
                            litemAllRow.AcceptChanges();
                        }
                    }

                }
            }
            trdtbl_vw.AcceptChanges();
            DataAcess.Connclose(connHandle);
            return trdtbl_vw;
        }


        protected void SessionsRemove()
        {
            if (SessionProxy.MainDataSet != null) 
                SessionProxy.MainDataSet.Dispose();

            if (SessionProxy.GridItemColView != null) 
                SessionProxy.GridItemColView.Dispose();

            if (SessionProxy.RStatusView != null) 
                SessionProxy.RStatusView.Dispose();

            SessionProxy.AllocDataRow = null;
            SessionProxy.MainQueryString = null;
            SessionProxy.SubQueryString = null;
            SessionProxy.IsSubReport = false;

            if (SessionProxy.ReportDataSet != null)  
                SessionProxy.ReportDataSet.Dispose();

            SessionProxy.ReportDataSet = null;
            SessionProxy.RetItemRow = null; 
            Session.Remove("curPurchaseDet");
            Session.Remove("itemRow");
        }

        protected void radDrCr_SelectedIndexChanged(object sender, EventArgs e)
        {
            // This method use for Openning Balances Transaction
            DataSet MainDataSet = SessionProxy.MainDataSet; 
                try
                {
                    if (radDrCr.SelectedValue.ToString().Trim().ToUpper() == "DEBIT")
                    {
                        MainDataSet.Tables["main_vw"].Rows[0]["u_choice"] = true;
                    }
                    else
                    {
                        if (radDrCr.SelectedValue.ToString().Trim().ToUpper() == "CREDIT")
                        {
                            MainDataSet.Tables["main_vw"].Rows[0]["u_choice"] = false;
                        }
                    }

                    if (DBPropsSession.AccountPage == true)
                    {
                        vuTransactionevent TransactionEvent = new vuTransactionevent();
                        //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;
                        TransactionEvent.txtAccNetAmount_TextChanged(MainDataSet.Tables["main_vw"],
                                        MainDataSet.Tables["acdet_vw"],
                                        MainDataSet.Tables["item_vw"],
                                        MainDataSet.Tables["lcode_vw"],
                                        GridAccount,
                                        grdlAllocDet,
                                        LinkAcAdd,
                                        txtAccNetAmount,
                                        Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["u_choice"]).Trim().ToUpper());
                    }
                    SessionProxy.MainDataSet = MainDataSet; 
                }
                catch (Exception Ex)
                {
                    MessageErrorDisp(Ex);
                    return;
                }
                finally
                {
                    MainDataSet.Dispose();
                }
        }


        private void HeaderDetPostBackForExcise()
        {
            //if (hidHdPostBackChecked.Value != "1")
            //{
                DataSet MainDataSet = SessionProxy.MainDataSet;  
                getDateFormat DateFormat = new getDateFormat();
                vuTransactionevent TransactionEvent = new vuTransactionevent();
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                //TransactionEvent.PageCustProps = SessionProxy.PageCustomProps;

                // Transaction Date
                if (txtdate.Text != DateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["date"]))) 
                {
                    if (txtdate.Text != string.Empty || txtdate.Text != "__/__/____")
                    {
                        DateValidation(txtdate, MainDataSet);
                    }
                }

                // Transaction Party Name
                if (txtPartyName.Text.Trim() != Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["party_nm"]))
                {
                    try
                    {
                        TransactionEvent.dropParty_SelectedIndexChanged(txtPartyName,
                            GridAccount,
                            grdlAllocDet,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            MainDataSet.Tables["company"],
                            MainDataSet.Tables["acdet_vw"],
                            txtdate,
                            txtDueDays,
                            txtDueDate,
                            lblAccBalAmt,
                            hiddPartyName);

                        if (lblAccBalAmt.Text != "")
                            hiddAcBalAmt.Value = "GET";

                        SessionProxy.MainDataSet = MainDataSet;
                        if (TransactionEvent.ErrorMessage != "")
                        {
                            DisplayMessage(TransactionEvent.ErrorMessage.Trim());
                        }
                    }
                    catch (Exception Ex)
                    {
                        DisplayMessage(Ex.Message.Trim());
                    }
                }

                // Rule
                if (cboRule.SelectedItem.Text.ToString().Trim() !=
                        Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim())
                {
                    MainDataSet.Tables["main_vw"].Rows[0]["rule"] = cboRule.SelectedIndex != 0 ?
                        cboRule.SelectedItem.Text.ToString().Trim() : "";
                    MainDataSet.Tables["main_vw"].AcceptChanges();
                }

                // Due Days
                if (txtDueDate.Text != DateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["due_dt"])))
                {
                    TransactionEvent.txtDueDays_TextChanged(txtDueDate,
                                                txtdate,
                                                txtDueDays,
                                                MainDataSet.Tables["main_vw"]);
                    txtDueDate.Text = DateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["due_dt"]));
                }

                SessionProxy.MainDataSet = MainDataSet;
                MainDataSet.Dispose();
                DataAcess.Connclose(connHandle);
                hidHdPostBackChecked.Value = "1"; 
            //}
        }

        //protected void Button1_Click1(object sender, EventArgs e)
        //{
        //    //string xmlPath = Convert.ToString(SessionProxy.Company.Rows[0]["dir_nm"]).Trim() +
        //    //                                      "\\xml\\ItMast.xml";

        //    string xmlPath = Convert.ToString(ConfigurationManager.AppSettings["XmlPath"]).Trim() +
        //                                    "\\xml\\AcMast.xml";
        //    Label1.Text = xmlPath;
        //}
        
      

        //[System.Web.Services.WebMethod()]
        //public static string GetBalance(string pParam)
        //{
        //    //string acId, string tranCd, string addMode, string entryType
        //    string[] paramList = new string[7];
        //    paramList =  pParam.Split(',');
        //    string acId = paramList[1];
        //    string tranCd = paramList[3];
        //    string addMode = paramList[5];
        //    string entryType = paramList[7];

        //    System.Threading.Thread.Sleep(500);
        //    Page page = new Page();
        //    wcAccBal ctl = (wcAccBal)Page.LoadControl("~/wcAccBal.ascx");
        //    ctl.AcId = acId;
        //    ctl.TranCd = tranCd;
        //    ctl.AddMode = addMode;
        //    ctl.EntryType = entryType.Trim();

        //    Page.Controls.Add(ctl);
        //    System.IO.StringWriter writer = new System.IO.StringWriter();
        //    HttpContext.Current.Server.Execute(page, writer, false);
        //    string output = writer.ToString();
        //    writer.Close();
        //    return output;
        //}        

    }



   


}

