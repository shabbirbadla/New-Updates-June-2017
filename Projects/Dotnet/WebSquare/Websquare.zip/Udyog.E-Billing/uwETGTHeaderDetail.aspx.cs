using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Business.Logic.Layer;

namespace Udyog.E.Billing
{
    public partial class uwETGTHeaderDetail : System.Web.UI.Page
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();

            if (numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]) == 0)
            {
                MainDataSet.Tables["main_vw"].Rows[0]["cons_id"] =
                    numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["ac_id"]);
            }

            if (!(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["U_gddate"]) >= DateTime.MinValue  &&
                Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["U_gddate"]) <= DateTime.MaxValue)) 
            {
                MainDataSet.Tables["main_vw"].Rows[0]["U_gddate"] = DateFormat.TodateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"]);
            }

            chkSaleExceed.Text = "Sale Exceeds " + Convert.ToString(MainDataSet.Tables["manufact"].Rows[0]["Sr_Days"]).Trim() + 
                                 " Days ? ";

            if (numFunction.toInt32(MainDataSet.Tables["manufact"].Rows[0]["sr_days"]) <= 0)
            {
                chkSaleExceed.Enabled = false; 
            }

            if (txtBillNo.Text == string.Empty)
            {
                chkSaleInfo.Checked = true; 
            }

            if (chkSaleInfo.Checked == false)
            {
                txtBillNo.Enabled = true;
                txtBillDate.Enabled = true;
            }
            else
            {
                txtBillNo.Enabled = false;
                txtBillDate.Enabled = false;
            }

            
            int acId = 0;
            SqlParameter[] spParam = new SqlParameter[2];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@acId";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]);

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@AcName";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = string.Empty;

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_Acc_validation",
                                            spParam,ref connHandle);

            if (Dr.HasRows == false)
            {
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle);
                throw new Exception("No Manufacturer/Supplier details found");
            }
            else
            {
                while (Dr.Read())
                {
                    txtConsignee.Text = Convert.ToString(Dr["ac_name"]);
                }
                Dr.Dispose();
                Dr.Close();
                DataAcess.Connclose(connHandle);
            }
            MainDataSet.Tables["main_vw"].AcceptChanges();

            if (txtBillDate.Text == string.Empty || txtBillDate.Text == "__/__/____")
                txtBillDate.Text = DateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));


            if (txtGoodRecd.Text == string.Empty || txtGoodRecd.Text == "__/__/____")
                txtGoodRecd.Text = DateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));    

            SessionProxy.MainDataSet = MainDataSet; 
            MainDataSet.Dispose();
            txtGoodRecd.Focus(); 
         }

        protected void txtConsignee_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            numericFunction numFunction = new numericFunction();
            if (txtConsignee.Text != string.Empty)
            {
                SqlParameter[] spParam = new SqlParameter[2];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@acId";
                spParam[0].SqlDbType = SqlDbType.Int;
                spParam[0].Value = 0;

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@AcName";
                spParam[1].SqlDbType = SqlDbType.VarChar;
                spParam[1].Value = Convert.ToString(txtConsignee.Text).Trim();

                spParam[2] = new SqlParameter();
                spParam[2].ParameterName = "@sconsId";
                spParam[2].SqlDbType = SqlDbType.Int;
                spParam[2].Value = numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["scons_id"]);

                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                ArrayList dbList = new ArrayList();
                dbList.Add("acMast");
                dbList.Add("Shipto");
                DataSet Ds = new DataSet();
                Ds = DataAcess.ExecuteDataset(Ds,"sp_ent_web_Acc_validation_shipto",
                                                spParam,dbList,connHandle);
                DataAcess.Connclose(connHandle);

                MainDataSet.Tables["main_vw"].Rows[0]["cons_id"] =
                    numFunction.toInt32(Ds.Tables["acMast"].Rows[0]["ac_id"]);

                Ds.Dispose();
            }
            else
            {
                MainDataSet.Tables["main_vw"].Rows[0]["cons_id"] = 0;
                MainDataSet.Tables["main_vw"].Rows[0]["scons_id"] = 0;  
            }
            MainDataSet.Tables["main_vw"].AcceptChanges();
            SessionProxy.MainDataSet = MainDataSet;
            MainDataSet.Dispose();
        }

        private void CheckValidation()
        {
            DataSet MainDataSet = SessionProxy.MainDataSet;
            DataRow MainRow = MainDataSet.Tables["main_vw"].Rows[0];

            getDateFormat DateFormat = new getDateFormat();
            stringFunction strFunction = new stringFunction();
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();

            MainRow["u_sinfo"] = chkSaleInfo.Checked ? true : false;
            MainRow["u_osale"] = chkSaleExceed.Checked ? true : false;
            MainRow["u_cominvno"] = txtBillNo.Text;
            MainRow["u_cominvdt"] = DateFormat.TodateTime(txtBillDate.Text);
            MainRow["u_gddate"] = DateFormat.TodateTime(txtGoodRecd.Text);

            if (strFunction.InList(Convert.ToString(MainRow["rule"]).Trim()
                , new string[] { "EXCISE", "NON-EXCISE" }))
            {
                if (Convert.ToString(MainRow["u_cominvno"]).Trim() == string.Empty &&
                    bitFunction.toBoolean(MainRow["u_sinfo"]) == false)
                {
                    throw new Exception("Sale Bill No. cannot be Empty..");
                }

                if (!(Convert.ToDateTime(MainRow["u_cominvdt"]) >= DateTime.MinValue  &&
                    Convert.ToDateTime(MainRow["u_cominvdt"]) <= DateTime.MinValue) &&
                    bitFunction.toBoolean(MainRow["u_sinfo"]) == false)
                {
                    throw new Exception("Sale Bill Date cannot be Empty..");
                }
            }

            if ((Convert.ToDateTime(MainRow["u_cominvdt"]) >= DateTime.MinValue &&
                Convert.ToDateTime(MainRow["u_cominvdt"]) <= DateTime.MinValue) &&
                Convert.ToDateTime(MainRow["u_cominvdt"]) > 
                Convert.ToDateTime(MainRow["Date"]))
            {
                throw new Exception("Sales Bill Date can't be more than Sales Return Date");
            }

            if (numFunction.toInt32(MainRow["cons_id"]) != 0)
            {
                SqlParameter[] spParam = new SqlParameter[2];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@consId";
                spParam[0].SqlDbType = SqlDbType.Int;
                spParam[0].Value = numFunction.toInt32(MainRow["Cons_id"]);  

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@sconsId";
                spParam[1].SqlDbType = SqlDbType.Int;
                spParam[1].Value = numFunction.toInt32(MainRow["sCons_id"]);  

                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                ArrayList dbList = new ArrayList();
                dbList.Add("acMast");
                if (numFunction.toInt32(MainRow["sCons_id"]) != 0)
                {
                    dbList.Add("Shipto");
                }
                dbList.Add("SConsID");
                DataSet Ds = new DataSet();
                Ds = DataAcess.ExecuteDataset(Ds,"sp_ent_web_ETGTHeaderDetail_validation",
                                                spParam,dbList,connHandle);
                DataAcess.Connclose(connHandle);

                if (Ds.Tables["acMast"].Rows.Count == 0)
                {
                    throw new Exception("Consignee not found in A/c Master"); 
                }

                if (numFunction.toInt32(MainRow["sCons_id"]) != 0)
                {
                    if (Ds.Tables["Shipto"].Rows.Count == 0)
                    {
                        throw new Exception("Consignee Location details not found in master");
                    }
                }

                if (Ds.Tables["SconsID"].Rows.Count == 0)
                {
                    throw new Exception("Consignee Location details not found in master"); 
                }

                if (Convert.ToString(Ds.Tables["SconsID"].Rows[0]["EccNo"]).Trim() == string.Empty)
                {
                    throw new Exception("Ecc No. cannot be empty.."); 
                }

                MainRow["ettype"] = Convert.ToString(Ds.Tables["Sconsid"].Rows[0]["vend_type"]).Trim();
                if (strFunction.InList(Convert.ToString(Ds.Tables["Sconsid"].Rows[0]["vend_type"]).Trim()
                , new string[] { "MANUFACTURER","IMPORTER" }))
                {
                    foreach (DataRow ManuRow in MainDataSet.Tables["manu_det_Vw"].Rows)
                    {
                        ManuRow["ManuAc_Id"] = numFunction.toInt32(MainRow["cons_id"]);
                        ManuRow["ManuSAc_id"] = numFunction.toInt32(MainRow["scons_id"]);
                        ManuRow["ManuBill"] = Convert.ToString(MainRow["u_pinvno"]).Trim();
                        ManuRow["ManuDate"] = DateFormat.TodateTime(MainRow["u_pinvdt"]);  
                    }
                    MainDataSet.Tables["manu_det_vw"].AcceptChanges();  
                }

                Ds.Dispose(); 
            }
            MainRow.AcceptChanges();
            MainDataSet.Tables["main_vw"].AcceptChanges();
            SessionProxy.MainDataSet = MainDataSet;

            MainDataSet.Dispose(); 
 
        }

        protected void btnDone_Click(object sender, EventArgs e)
        {
            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();

            DataSet MainDataSet = SessionProxy.MainDataSet;
            DataRow MainRow = MainDataSet.Tables["main_vw"].Rows[0];

            try
            {
                if (strFunction.InList(Convert.ToString(MainRow["rule"]).Trim()
                    , new string[] { "EXCISE", "NON-EXCISE" }) &&
                    numFunction.toInt32(MainRow["cons_id"]) == 0)
                {
                    DisplayMessage("Consignee name cannot be empty");
                }

                if (numFunction.toInt32(MainRow["cons_id"]) != 0)
                {
                    CheckValidation();
                }
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "doneDialog();", true);
            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message);
            }
            finally
            {
                SessionProxy.MainDataSet = MainDataSet;
                MainDataSet.Dispose();
            }

        }

        private void DisplayMessage(string strMsg)
        {
            strMsg = strMsg.Replace("\r\n", "\\n");
            strMsg = strMsg.Replace("\n", "\\n");
            strMsg = strMsg.Replace("'", "");
            string scriptString = "alert('" + strMsg + "');";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), null, scriptString, true);

        }

    }
}
