using System;
using System.Data;
using System.Data.SqlClient;  
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Controls;
using Business.Logic.Layer;
using Data.Acess.Layer;
using AjaxControlToolkit;
using Customised.Trigger.Layer;  



namespace Udyog.E.Billing
{
    public partial class vuTransactionEntry : BasePage 
    {

        private static stringFunction strFunction;
        private static numericFunction numFunction;
        //private static DataSet MainDataSet;
        private static PageCustomProperties PageCustomProps;
        private static DataTier DataAcess;
        private static getDateFormat GetDateFormat;
        private static getNullUpdate DataNullUpdate;
        private static vuTransactionevent TransactionEvent;
        //private static DataTable RStatus_vw = null;
        //private static DataView grdItemColView = null;
        private static decimal vAmt = 0; // define this variable for Allocation 
        private static decimal VchrAmt = 0;
        private static decimal FromAcAmt = 0;
        private static int allocRowIndex = 0; // define this variable for Allocation 
        //private static DataRow AllocDataRow;
        //private static DataRow RetItemRow; // define this datarow for Excise Trading Itewise Page
        private static bool isOpenGridForAllocation = false;
        private static Int32 InitStartWithTranCd = 0;
        private string sqlStr;     
         
        protected override void OnInit(EventArgs e)
        {
            Page.Load += new EventHandler(Page_Load);
            if (IsPostBack == true)
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                if (PageCustomProps.ItemPage == true)
                {
                    DataView grdItemColView = (DataView)Session["GridItemColView"];
                    GenGridItemRows(grdItemColView,MainDataSet);
                }

                boolFunction bitFunction = new boolFunction();
                if (bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["ac_bchk"]) == true &&
                   PageCustomProps.AccountPage == true)
                {
                    //UpdatePanel UpPnlBankBalance = new UpdatePanel();
                    //UpPnlBankBalance.UpdateMode = UpdatePanelUpdateMode.Conditional ;
 
                    //AsyncPostBackTrigger Trigger = new AsyncPostBackTrigger();
                    //Trigger.ControlID = "txtBankName";
                    //Trigger.EventName = "TextChanged";
                    //UpPnlBankBalance.Triggers.Add(Trigger);

                    //Panel PnlBankBalance = new Panel();
                    //PnlBankBalance.ID = "PnlBankBalance";
                    //PnlBankBalance.Width = Unit.Parse("200px");
                    //PnlBankBalance.BackColor = System.Drawing.Color.Goldenrod;
                    //PnlBankBalance.Font.Bold = true;
                    //PnlBankBalance.ForeColor = System.Drawing.Color.White;
                    //PnlBankBalance.Font.Size = 8;

                    //Label lblBankBalAmt = new Label();
                    //lblBankBalAmt.ID = "lblBankBalAmt";
                    //PnlBankBalance.Controls.Add(lblBankBalAmt);

                    //PopupControlExtender PopBankBalance = new PopupControlExtender();
                    //PopBankBalance.ID = "PopBankBalance";
                    //PopBankBalance.TargetControlID = "txtBankName";
                    //PopBankBalance.Position = PopupControlPopupPosition.Top;
                    //PopBankBalance.PopupControlID = "PnlBankBalance";

                    //UpPnlBankBalance.ContentTemplateContainer.Controls.Add(PnlBankBalance);

                    //UpPnlTmp.ContentTemplateContainer.Controls.Add(PnlBankBalance);
                    //tdBank.Controls.Add(PopBankBalance);

                    //Panel PnlPartyBalance = new Panel();
                    //PnlPartyBalance.ID = "PnlPartyBalance";
                    //PnlPartyBalance.Width = Unit.Parse("200px");
                    //PnlPartyBalance.BackColor = System.Drawing.Color.Goldenrod;
                    //PnlPartyBalance.Font.Bold = true;
                    //PnlPartyBalance.ForeColor = System.Drawing.Color.White;
                    //PnlPartyBalance.Font.Size = 8;

                    //Label lblPartyBalAmt = new Label();
                    //lblPartyBalAmt.ID = "lblPartyBalAmt";
                    //PnlPartyBalance.Controls.Add(lblPartyBalAmt);

                    //PopupControlExtender PopPartyBalance = new PopupControlExtender();
                    //PopPartyBalance.ID = "PopPartyBalance";
                    //PopPartyBalance.TargetControlID = "txtPartyNameB";
                    //PopPartyBalance.Position = PopupControlPopupPosition.Top;
                    //PopPartyBalance.PopupControlID = "PnlPartyBalance";

                    

                    //HtmlTableRow r1 = new HtmlTableRow();
                    //HtmlTableCell cellD = new HtmlTableCell();
                    //r1.Controls.Add(cellD);
                    //cellD.Controls.Add(PnlBankBalance);
                    //cellD.Controls.Add(PopBankBalance);
                    ////cellD.Controls.Add(PnlPartyBalance);
                    ////cellD.Controls.Add(PopPartyBalance);

                    //tblPage.Rows.Add(r1);
                   
                }

            }

            base.OnInit(e);
        }

        //protected void Page_Init(object sender, EventArgs e)
        //{
        //    string test = "";
        //}

        protected void Page_Load(object sender, EventArgs e)
        {
            // Set UK Culture for DD/MM/YYYY
            //int UKLocal = 2057;
            //Session.LCID = UKLocal;

            if (IsPostBack == false)
            {
                DataSet MainDataSet = new DataSet();

                strFunction = new stringFunction();
                numFunction = new numericFunction();
                PageCustomProps = new PageCustomProperties();
                DataAcess = new DataTier();
                GetDateFormat = new getDateFormat();
                DataNullUpdate = new getNullUpdate();
                TransactionEvent = new vuTransactionevent();
                //RStatus_vw = null;
                //grdItemColView = null;
                vAmt = 0; // define this variable for Allocation 
                VchrAmt = 0;
                FromAcAmt = 0;
                allocRowIndex = 0; // define this variable for Allocation 
                //AllocDataRow = null;
                isOpenGridForAllocation = false;
                InitStartWithTranCd = 0;

                SessionsRemove(); // Remove existing Session Variables
                getTables GetTables = new getTables();
                getData GetData = new getData();
                getCompany GetCompany = new getCompany();
                getCoAdditional GetCoAdditional = new getCoAdditional();

                PageCustomProps.PcvType = Request.QueryString["PcvType"];
                PageCustomProps.AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                PageCustomProps.EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                PageCustomProps.Vchkprod = Session["vChkProd"].ToString().Trim();
                int tranCd = Convert.ToInt16(Request.QueryString["tranCd"]);
                InitStartWithTranCd = tranCd;

                try
                {
                    InitGetTables(ref MainDataSet); // Initial Create Tables
                }
                catch (Exception Ex)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
                    return; 
                }

                
                //Page Caption
                lblTrType.Text = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["code_nm"]).Trim();
                this.Title = lblTrType.Text.Trim();

                ConditionalControlEnabled(ref MainDataSet); 
                GeneralControlEnabled(ref MainDataSet);

                BindDropDown(ref MainDataSet); // Fill Dropdown 

                // call AddMethods and EditMethod
                if (PageCustomProps.AddMode == true)
                {
                    newRec(ref MainDataSet);
                }
                else
                {
                    if (PageCustomProps.EditMode == true)
                    {
                        EditRec(tranCd,ref MainDataSet);
                    }
                }

                DataView grdItemColView = new DataView();
                BindGridView(ref MainDataSet,ref grdItemColView); // Fill All GridView 

                // uday
                if (PageCustomProps.ItemPage == true)
                {
                    vouGridFill vouGridInit = new vouGridFill();
                    vouGridInit.PageCustProps = PageCustomProps;
                    if (grdItemColView == null || grdItemColView.Count <= 0)
                        grdItemColView = vouGridInit.ItemgridTemplate(MainDataSet.Tables["lother_vw"],
                                                                                MainDataSet.Tables["company"],
                                                                                MainDataSet.Tables["lcode_vw"],
                                                                                MainDataSet.Tables["item_vw"],
                                                                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim());
                    GenGridItemRows(grdItemColView,MainDataSet);
                    if (PageCustomProps.EditMode == true)
                        pnlItDetails.Style.Add("display", "none");
                    else
                        if (PageCustomProps.AddMode == true)
                        {
                            //hidItRowItSerial.Value = "|NEW"; // store status into hidden  variable
                            //pnlItDetails.Visible = false;
                        }

                    
                }

                boolFunction bitFunction = new boolFunction();
                if (bitFunction.toBoolean(MainDataSet.Tables["company"].Rows[0]["ac_bchk"]) == true &&
                   PageCustomProps.AccountPage == true)
                {
                    //UpdatePanel UpPnlBankBalance = new UpdatePanel();
                    //UpPnlBankBalance.UpdateMode = UpdatePanelUpdateMode.Always;
                    //AsyncPostBackTrigger Trigger = new AsyncPostBackTrigger();
                    //Trigger.ControlID = "txtBankName";
                    //Trigger.EventName = "TextChanged";
                    //UpPnlBankBalance.Triggers.Add(Trigger);

                    //Panel PnlBankBalance = new Panel();
                    //PnlBankBalance.ID = "PnlBankBalance";
                    //PnlBankBalance.Width = Unit.Parse("200px");
                    //PnlBankBalance.BackColor = System.Drawing.Color.Goldenrod;
                    //PnlBankBalance.Font.Bold = true;
                    //PnlBankBalance.ForeColor = System.Drawing.Color.White;
                    //PnlBankBalance.Font.Size = 8;

                    //Label lblBankBalAmt = new Label();
                    //lblBankBalAmt.ID = "lblBankBalAmt";
                    //PnlBankBalance.Controls.Add(lblBankBalAmt);

                    //PopupControlExtender PopBankBalance = new PopupControlExtender();
                    //PopBankBalance.ID = "PopBankBalance";
                    //PopBankBalance.TargetControlID = "txtBankName";
                    //PopBankBalance.Position = PopupControlPopupPosition.Top;
                    //PopBankBalance.PopupControlID = "PnlBankBalance";

                    //UpPnlBankBalance.ContentTemplateContainer.Controls.Add(PnlBankBalance);

                    //UpPnlTmp.ContentTemplateContainer.Controls.Add(PnlBankBalance);
                    //tdBank.Controls.Add(PopBankBalance);

                    //Panel PnlPartyBalance = new Panel();
                    //PnlPartyBalance.ID = "PnlPartyBalance";
                    //PnlPartyBalance.Width = Unit.Parse("200px");
                    //PnlPartyBalance.BackColor = System.Drawing.Color.Goldenrod;
                    //PnlPartyBalance.Font.Bold = true;
                    //PnlPartyBalance.ForeColor = System.Drawing.Color.White;
                    //PnlPartyBalance.Font.Size = 8;

                    //Label lblPartyBalAmt = new Label();
                    //lblPartyBalAmt.ID = "lblPartyBalAmt";
                    //PnlPartyBalance.Controls.Add(lblPartyBalAmt);

                    //PopupControlExtender PopPartyBalance = new PopupControlExtender();
                    //PopPartyBalance.ID = "PopPartyBalance";
                    //PopPartyBalance.TargetControlID = "txtPartyNameB";
                    //PopPartyBalance.Position = PopupControlPopupPosition.Top;
                    //PopPartyBalance.PopupControlID = "PnlPartyBalance";

                    //HtmlTableRow r1 = new HtmlTableRow();
                    //HtmlTableCell cellD = new HtmlTableCell();
                    //r1.Controls.Add(cellD);
                    //cellD.Controls.Add(PnlBankBalance);
                    //cellD.Controls.Add(PopBankBalance);
                    ////cellD.Controls.Add(PnlPartyBalance);
                    ////cellD.Controls.Add(PopPartyBalance);

                    //tblPage.Rows.Add(r1);
                }

                if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0 ||
                    PageCustomProps.Vchkprod.IndexOf("vuexc") >= 0)
                    trExciseDetail.Visible = true;
                else
                    trExciseDetail.Visible = false;

                DataAcess.Connclose();
                TransactionEvent.PageCustProps = PageCustomProps;
                Session["MainDataSet"] = MainDataSet; // Set Session Variable for access
                        // DataSet inside Page
                Session["GridItemColView"] = grdItemColView; 
                string itmess,tranmess = "";
                if ((PageCustomProps.PcvType == "DC" || PageCustomProps.PcvType == "DC") &&
                    (PageCustomProps.Vchkprod.Trim().IndexOf("vutex") >= 0 && 
                     Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim() == "EXCISE"))
                {
                    itmess = "As per Excise rule you cannot delete the item from invoice \\n " +
                            "Continue ? ";
                }
                else
                {
                    itmess = " Delete this item ?";
                }

                imgITDelete.Attributes.Add("onclick", "javascript:ItemCheckDeleteRows('" + itmess.Trim() + "');");
                //lnkDelete.Attributes.Add("onclick", "javascript:if (!window.confirm('" + tranmess.Trim() + "')) return false;");   

            }
            else
            {
                    DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                    if (tblAddinfoDet.Visible == true)
                    {
                        if (MainDataSet.Tables["xtra_vw"]!= null)
                        {
                            DataView xtra_vw = new DataView();
                            xtra_vw = MainDataSet.Tables["xtra_vw"].DefaultView;
                            xtra_vw.Sort = "serial";

                            vuAdditionalInfo vuAdditionalInfo = new vuAdditionalInfo();
                            try
                            {
                                vuAdditionalInfo.genControls(xtra_vw, MainDataSet.Tables["main_vw"].Rows[0], tblAddInfo);
                            }
                            catch (Exception Ex)
                            {
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
                            }

                        }
                    }

                    TransactionEvent.PageCustProps = PageCustomProps;

                    if (isOpenGridForAllocation == true)  // gridForallocation gridview is created
                    {
                        gridBindAfterPostback(allocRowIndex);
                    }

                    vouGridFill vouGridInit = new vouGridFill();
                    if (PageCustomProps.ItemPage == true)
                    {
                        GridItem.Columns.Clear();
                        vouGridInit.PageCustProps = PageCustomProps;
                        DataView grdItemColView = (DataView)Session["GridItemColView"];
                        if (grdItemColView == null || grdItemColView.Count <= 0)
                            grdItemColView = vouGridInit.ItemgridTemplate(MainDataSet.Tables["lother_vw"],
                                                                                    MainDataSet.Tables["company"],
                                                                                    MainDataSet.Tables["lcode_vw"],
                                                                                    MainDataSet.Tables["item_vw"],
                                                                                    Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim());

                        vouGridInit.gridItemGen(GridItem, grdItemColView, MainDataSet.Tables["item_vw"]);
                        Session["GridItemColView"] = grdItemColView; 
                        //GenGridItemRows(grdItemColView);

                        PageCustomProps.SalesTaxItem = vouGridInit.SalesTaxItem;
                    }
                //}
                    //tblGenTest(); 
            }
            //lblItRowStatus.Visible = false;
            tdErrorMess.Visible = false; 
            lnkBack.Attributes.Add("OnClick", "javascript: return linkBackConf('" + btnSaveTop.ClientID + "','" + btnBack.ClientID + "');");
        }

        
        protected void txtDateB_TextChanged(object sender, EventArgs e)
        {

            if (txtDateB.Text != "" && txtDateB.Text != "__/__/____")
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];

                TransactionEvent.PageCustProps = PageCustomProps;
                TransactionEvent.DateValidation(txtDateB,
                        null,
                        null,
                        trduedt,
                        this.Page,
                        hidDateValid,
                        MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["company"],
                        MainDataSet.Tables["lcode_vw"],
                        MainDataSet.Tables["item_vw"],
                        MainDataSet.Tables["acdet_vw"],
                        false);

                Session["MainDataSet"] = MainDataSet; 
            }
            //else
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Date cannot be Blank..!!!');", true);
            //    return;
            //}

        }

        protected void txtBankName_TextChanged(object sender, EventArgs e)
        {
            
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            try
            {
                
                //TransactionEvent.PageCustProps = PageCustomProps;
                //Label lblBankBalAmt = (Label)Page.Form.Controls[2].FindControl("tblPage").FindControl("lblBankBalAmt");

                TransactionEvent.cboBankName_SelectedIndexChanged(txtBankName,
                                txtPartyNameB,
                                MainDataSet.Tables["main_vw"],
                                MainDataSet.Tables["acdet_vw"],
                                MainDataSet.Tables["Company"],
                                MainDataSet.Tables["lcode_vw"],
                                lblBankBalAmt, 
                                GridAccount,
                                grdlAllocDet,
                                hiddBankName);

                if (lblBankBalAmt.Text != "" )
                    hiddBankBalance.Value = "GET";
                
                Session["MainDataSet"] = MainDataSet; 

                if (TransactionEvent.ErrorMessage != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + TransactionEvent.ErrorMessage + "');", true);
                }
                ScriptManager1.SetFocus(txtBankName);  
                
            }
            catch (Exception Ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
                return;
            }


            
            //divBal.Style.Add("");   

            //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "getAbsolutePosition('" + cboBankName.ClientID + "');", true);

        }
        protected void txtPartyNameB_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                TransactionEvent.PageCustProps = PageCustomProps;

                TransactionEvent.cboPartyNameB_SelectedIndexChanged(txtPartyNameB,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["acdet_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            MainDataSet.Tables["company"],
                            lblBnkPartyBalAmt,
                            grdlAllocDet,
                            GridAccount,
                            hiddBnkPartyName);

                if (lblBnkPartyBalAmt.Text != "")
                    hiddBnkPartyBalance.Value = "GET"; 

                Session["MainDataSet"] = MainDataSet;
                if (TransactionEvent.ErrorMessage != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + TransactionEvent.ErrorMessage + "');", true);
                }
            }
            catch (Exception Ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
            }
  
        }
        protected void cboInvSeriesB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboInvSeriesB.SelectedIndex == 0)
                return;

            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"] = cboInvSeriesB.SelectedItem.ToString().Trim();
            vuInit initProc = new vuInit();
            initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode, 
                    PageCustomProps.EditMode,
                    PageCustomProps.Entry_Tbl,
                    MainDataSet.Tables["main_vw"], 
                    MainDataSet.Tables["lcode_vw"], 
                    "SERIES");
            Session["MainDataSet"] = MainDataSet; 
            DataAcess.Connclose();
        }

        protected void txtInvoiceNoB_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            vuInit initProc = new vuInit(); 
            txtInvoiceNoB.Text = initProc.txtInvoiceNo_LostFocus(PageCustomProps.AddMode,
                    PageCustomProps.EditMode, 
                    PageCustomProps.PcvType, 
                    PageCustomProps.Behave, 
                    PageCustomProps.Entry_Tbl, 
                    MainDataSet.Tables["main_vw"], 
                    MainDataSet.Tables["lcode_vw"], 
                    hiddInvOldValueB.Value, 
                    txtInvoiceNoB.Text, 
                    "ttt");
            Session["MainDataSet"] = MainDataSet;
            DataAcess.Connclose();

            if (initProc.ErrorMessage.Trim() != "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + initProc.ErrorMessage.Trim() + "');", true);
                txtInvoiceNoB.Focus();
            }
            
        }
        protected void btnGetInvoiceGotFocusB_Click(object sender, EventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            vuInit initProc = new vuInit();
            initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode,
                    PageCustomProps.EditMode,
                    PageCustomProps.Entry_Tbl,
                    MainDataSet.Tables["main_vw"],
                    MainDataSet.Tables["lcode_vw"], "BUTTON");

            Session["MainDataSet"] = MainDataSet;

            DataAcess.Connclose();
            txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            txtInvoiceNoB.Focus();
        }

        protected void txtdate_TextChanged(object sender, EventArgs e)
        {
            if (txtdate.Text != "" && txtdate.Text != "__/__/____")
            {
                DataSet MainDataSet = ((DataSet)Session["MainDataSet"]);
                DateValidation(txtdate,MainDataSet);
                MainDataSet.Dispose(); 
                //TransactionEvent.PageCustProps = PageCustomProps;
                //TransactionEvent.DateValidation(txtdate,
                //      txtDueDate,
                //      txtDueDays,
                //      trduedt,
                //      this.Page,
                //      hidDateValid,
                //      MainDataSet.Tables["main_vw"],
                //      MainDataSet.Tables["company"],
                //      MainDataSet.Tables["lcode_vw"],
                //      MainDataSet.Tables["item_vw"],
                //      MainDataSet.Tables["acdet_vw"],  
                //      false);
                //Session["MainDataSet"] = MainDataSet;

                txtPartyName.Focus(); 
            }
            //else
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Date cannot be Blank..!!!');", true);
            //    return;
            //}
        }

        protected void txtPartyName_TextChanged(object sender, EventArgs e)
        {
            if (txtPartyName.Text != "")
            {
                try
                {
                    TransactionEvent.PageCustProps = PageCustomProps;
                    DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                    TransactionEvent.dropParty_SelectedIndexChanged(txtPartyName,
                        GridAccount,
                        grdlAllocDet,
                        MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["lcode_vw"],
                        MainDataSet.Tables["company"],
                        MainDataSet.Tables["acdet_vw"],
                        txtdate,
                        txtDueDays,
                        txtDueDate,
                        lblAccBalAmt,
                        hiddPartyName);

                    if (lblAccBalAmt.Text != "")
                        hiddAcBalAmt.Value = "GET";

                    Session["MainDataSet"] = MainDataSet;
                    if (TransactionEvent.ErrorMessage != "")
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + TransactionEvent.ErrorMessage + "');", true);
                    }   
                }
                catch (Exception Ex)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
                }

            }
        }
        //protected void dropParty_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    TransactionEvent.PageCustProps = PageCustomProps;
        //    DataSet MainDataSet = (DataSet)Session["MainDataSet"];
        //    TransactionEvent.dropParty_SelectedIndexChanged(dropParty,
        //        GridAccount,
        //        grdlAllocDet,
        //        MainDataSet.Tables["main_vw"],
        //        MainDataSet.Tables["lcode_vw"],
        //        MainDataSet.Tables["company"],
        //        MainDataSet.Tables["acdet_vw"],
        //        txtdate,
        //        txtDueDays,
        //        txtDueDate,
        //        lblAccBalAmt,
        //        hiddPartyName,
        //        trOthTranDivParty);

        //    Session["MainDataSet"] = MainDataSet;
        //    if (TransactionEvent.ErrorMessage != "")
        //    {
        //        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + TransactionEvent.ErrorMessage + "');", true);
        //    }   
                
        //}

        protected void txtInvNo_TextChanged(object sender, EventArgs e)
        {
            vuInit initProc = new vuInit();
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            initProc.txtInvoiceNo_LostFocus(PageCustomProps.AddMode, 
                        PageCustomProps.EditMode, 
                        PageCustomProps.PcvType, 
                        PageCustomProps.Behave, 
                        PageCustomProps.Entry_Tbl, 
                        MainDataSet.Tables["main_vw"], 
                        MainDataSet.Tables["lcode_vw"], 
                        hiddInvOldValue.Value, 
                        txtInvNo.Text,
                        "Invoice No.");

            if (initProc.ErrorMessage.Trim() != "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + initProc.ErrorMessage.Trim() + "');", true);

                initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode,
                            PageCustomProps.EditMode,
                            PageCustomProps.Entry_Tbl,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            "BUTTON");

                txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                DataAcess.Connclose();
                txtInvNo.Focus();
            }

            Session["MainDataSet"] = MainDataSet;
        }
        protected void btnGetInvoiceGotFocus_Click(object sender, EventArgs e)
        {
            vuInit initProc = new vuInit();
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode,
                        PageCustomProps.EditMode,
                        PageCustomProps.Entry_Tbl,
                        MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["lcode_vw"],
                        "BUTTON");
            DataAcess.Connclose();
            Session["MainDataSet"] = MainDataSet;
            txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            txtInvNo.Focus();
            
        }

        protected void btnAddInfoOk_Click(object sender, EventArgs e)
        {
            vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            vuAddInfo.btnClick(tblAddInfo,
                               MainDataSet.Tables["main_vw"].Rows[0],"BOXING",null);
            MainDataSet.Tables["main_vw"].AcceptChanges(); // save data in DataTable 
            Session["MainDataSet"] = MainDataSet; 
            cpAdditionalInfo.Collapsed = false;
            cpAdditionalInfo.ClientState = "false"; 
        }

        protected void GridItem_RowDataBound(object sender, GridViewRowEventArgs e)
        {
           if (e.Row.RowType != DataControlRowType.DataRow)
                return;
            
            //e.Row.Attributes.Add("onclick", "javascript:ChangeRowColor('" + e.Row.ClientID + "')");

            int lastcellindex = 0;
            CheckBox chkSelect = ((CheckBox)e.Row.Cells[lastcellindex].Controls[0].FindControl("chkSelect"));
            chkSelect.Attributes.Add("onclick", "javascript:HighlightGridRow('" + chkSelect.ClientID + "','" + e.Row.ClientID + "');");

                        
            //int lastcellindex = 0;
            //ImageButton EditButton = new ImageButton();
            //EditButton.ImageUrl = "~/Images/Edit.gif";
            //EditButton.CommandName = "EDIT";
            //EditButton.AlternateText = "Edit";
            //e.Row.Cells[lastcellindex].Controls.Add(EditButton);
            //((Button)e.Row.Cells[lastcellindex].Controls[0].FindControl("btnEdit")).Visible = false;

            //lastcellindex = 1;
            //ImageButton deleteButton = new ImageButton();
            //deleteButton.ImageUrl = "~/Images/TrashCan.gif";
            //deleteButton.CommandName = "DELETE";
            //deleteButton.AlternateText = "Delete";
            //e.Row.Cells[lastcellindex].Controls.Add(deleteButton);
            //((Button)e.Row.Cells[lastcellindex].Controls[0].FindControl("btnDel")).Visible = false;
            
            //deleteButton = ((ImageButton)e.Row.Cells[lastcellindex].Controls[0]);
            //deleteButton.OnClientClick = "if (!window.confirm('Are you sure you want to delete this item?')) return false;";

            //int lastcellindex = e.Row.Cells.Count - 1;
            //ImageButton deleteButton = new ImageButton();
            //deleteButton = ((ImageButton)e.Row.Cells[lastcellindex].Controls[0]);
            //deleteButton.OnClientClick = "if (!window.confirm('Are you sure you want to delete this item?')) return false;";

        }

        //protected void GridItem_RowEditing(object sender, GridViewEditEventArgs e)
        //{
        //    //GridItem.EditIndex = e.NewEditIndex; 
        //    //GridItem.DataSource = MainDataSet.Tables["item_vw"];
        //    //GridItem.DataBind(); 
        //    GenGridItemRows(grdItemColView);
        //    //pnlItDetails.Visible = true;


        //}

        protected void grdCharges_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            MainDataSet.Tables["main_vw"].RejectChanges();
            MainDataSet.Tables["tax_vw1"].RejectChanges();
            MainDataSet.Tables["tax_vw"].RejectChanges();
            grdCharges.EditIndex = -1;
            grdCharges.DataSource = MainDataSet.Tables["tax_vw1"];
            grdCharges.DataBind();
        }

        protected void grdCharges_RowEditing(object sender, GridViewEditEventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            TransactionEvent.grdCharges_RowEditing(grdCharges,
                        MainDataSet.Tables["tax_vw1"],
                        MainDataSet.Tables["Stax_vw"],
                        e.NewEditIndex);
            grdCharges.Focus(); 
        }

        protected void grdCharges_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            TransactionEvent.PageCustProps = PageCustomProps;
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            TransactionEvent.grdCharges_RowUpdating(MainDataSet, grdCharges, e.RowIndex, GridAccount,
                                                    grdlAllocDet, txtItemTotal, txtTotalQty, txtNetAmount,
                                                    txtAccNetAmount, txtGrossAmt, txtdedBefTax, txtTaxCharges,
                                                    txtTaxExAmt, txtAddCharges, txtTaxAmt, txtNonTax, txtfdisc, 
                                                    txtRoundoff,txtNetAmountTax); 

        }
        protected void dropSaleTax_SelectedIndexChanged(object sender, EventArgs e)
        {
            TransactionEvent.PageCustProps = PageCustomProps;
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            TransactionEvent.dropSaleTax_SelectedIndexChanged(MainDataSet.Tables["main_Vw"],
                                                              MainDataSet.Tables["tax_vw1"],
                                                              MainDataSet.Tables["item_Vw"],
                                                              MainDataSet.Tables["dcmast_vw"],
                                                              MainDataSet.Tables["tax_vw"],
                                                              MainDataSet.Tables["stax_vw"],
                                                              MainDataSet.Tables["company"],
                                                              grdCharges); 
        }
        protected void btnAllocate_Click(object sender, EventArgs e)
        {
           Button btnAllocate = ((Button)sender);
           GridViewRow row = ((GridViewRow)btnAllocate.NamingContainer);
           DataRow acDetRow = null;
           DataSet MainDataSet = (DataSet)Session["MainDataSet"];
           acDetRow =   TransactionEvent.btnAllocate_Click(MainDataSet,
                                    GridAccount,
                                    row.RowIndex,
                                    acDetRow);

           decimal oTds = TransactionEvent.OTds;
           decimal oDisc = TransactionEvent.ODisc; 

           if (TransactionEvent.ErrorMessage != "" && TransactionEvent.ErrorMessage != null)
           {
               ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + TransactionEvent.ErrorMessage + "');", true);
               TransactionEvent.ErrorMessage = "";
               return;
           }

           if (TransactionEvent.Narration != "" && TransactionEvent.Narration != null)
           {
               string alertMess = "";
               alertMess = "Existing Narration     : \n " + Convert.ToString(acDetRow["narr"]).Trim() + "\n\n ";
               alertMess += "Regenerated Narration : \n" + TransactionEvent.Narration.Trim() + "\n\n";
               alertMess += "Proceed with Regeneration ? ";
               ScriptManager.RegisterStartupScript(Page, Page.GetType(), "narrMess", "narrMess('" + alertMess + "');", true);
               if (hidDateValid.Value == "1")
               {
                   vuAllocation getAllocation = new vuAllocation();
                   getAllocation.PageCustProps = PageCustomProps;  
                   getAllocation.autoAllocAlert(acDetRow, 
                                true,
                                TransactionEvent.EditNarration,
                                TransactionEvent.Narration.Trim());
                   hidDateValid.Value = "";
               }
           }

           Session["tmpMallDtSess"] = MainDataSet.Tables["tmpMall_vw"];
           Session["mallDtSess"] = MainDataSet.Tables["Mall_vw"];
           Session["mainDtSess"] = MainDataSet.Tables["main_vw"];

           DataAcess.Connclose();

           string strOpenWin  = "";
           strOpenWin = "OpenDialog('" + "Allocation.aspx?pcvType=" + PageCustomProps.PcvType.Trim() + 
                        "&addMode=" + Convert.ToString(PageCustomProps.AddMode) + "&editMode=" + 
                        Convert.ToString(PageCustomProps.EditMode) + 
                        "&vAmt=" + Convert.ToString(acDetRow["amount"]).Trim() + 
                        "&acName=" + Convert.ToString(acDetRow["ac_name"]).Trim() + 
                        "','','" + 
                        hiddVuAcBal.ClientID + "','" + 
                        btnHiddenPerson.ClientID + "');";
           
            ScriptManager.RegisterStartupScript(this, this.GetType(), "openDialoge()", strOpenWin, true);
            hiddOTDS.Value = Convert.ToString(oTds);
            hiddODISC.Value = Convert.ToString(oDisc);
            Session["AcDetRowSess"] = acDetRow;  // Store DataRow in Session Variable
        }

        protected void btnHiddenPerson_Click(object sender, EventArgs e)
        {
           DataSet MainDataSet = (DataSet)Session["MainDataSet"];
           MainDataSet.Tables.Remove("mall_vw");
           MainDataSet.Tables.Remove("tmpMall_vw");
           MainDataSet.Tables.Add((DataTable)Session["mallDtSess"]);
           MainDataSet.Tables.Add((DataTable)Session["tmpMallDtSess"]);
           MainDataSet.AcceptChanges();
   
            
           DataRow acDetRow = ((DataRow)Session["AcDetRowSess"]);

           vuAllocation Allocation = new vuAllocation();
           Allocation.AfterCloseAllocationWindow(PageCustomProps.AddMode, 
                    PageCustomProps.EditMode, 
                    PageCustomProps.PcvType, 
                    MainDataSet.Tables["main_vw"], 
                    MainDataSet.Tables["item_vw"], 
                    MainDataSet.Tables["lcode_vw"], 
                    MainDataSet.Tables["acdet_vw"], 
                    MainDataSet.Tables["tmpMall_vw"], 
                    MainDataSet.Tables["Mall_vw"], 
                    numFunction.toDecimal(hiddVuAcBal.Value),
                    numFunction.toDecimal(hiddOTDS.Value), 
                    numFunction.toDecimal(hiddODISC.Value), 
                    acDetRow, 
                    MainDataSet.Tables["Company"]);

           GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
           GridAccount.DataBind();

           Session["MainDataSet"] = MainDataSet; // Again Add DataSet in
           // Session Variable

        }

        protected void grdAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }
        protected void grdAllocation_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton imgBtn = (ImageButton)e.Row.FindControl("imgCollapsible");
                if (imgBtn != null)
                    imgBtn.Attributes.Add("onClick", "javascript: return ShowHide('div" + Convert.ToString(e.Row.RowIndex) + "','" + imgBtn.ClientID + "');");
                  

            }
        }


        protected void grdAllocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            //TransactionEvent.grdAllocation_SelectedIndexChanged(GridAccount,
            //    MainDataSet,
            //    sender);

            //if (TransactionEvent.ErrorMessage != "")
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + TransactionEvent.ErrorMessage + "');", true);
            //}   

            //vuAllocation getAllocation = new vuAllocation();
            //if (TransactionEvent.Narration != "")
            //{
            //    string alertMess = "";
            //    alertMess = "Existing Narration     : \n " + Convert.ToString(TransactionEvent.AcdetRowVar["narr"]).Trim()+ "\n\n ";
            //    alertMess += "Regenerated Narration : \n" + TransactionEvent.Narration.Trim() + "\n\n";
            //    alertMess += "Proceed with Regeneration ? ";
            //    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "narrMess", "narrMess('" + alertMess + "');", True);
            //    if (hidDateValid.Value == "1")
            //        getAllocation.autoAllocAlert(TransactionEvent.AcdetRowVar, true, TransactionEvent.EditNarration,TransactionEvent.Narration.Trim());
            //}

            //getAllocation.vuAllocationInit(((GridView)row.FindControl("gridForAllocation")),
            //                                MainDataSet.Tables("tmpMall_vw"), 
            //                                MainDataSet.Tables("main_vw"), 
            //                                ((CheckBox)(row.FindControl("chkAllocExcess")), 
            //                                PageCustomProps.PcvType, 
            //                                PageCustomProps.AddMode, 
            //                                PageCustomProps.EditMode, 
            //                                Convert.ToDecimal(TransactionEvent.AcdetRowVar["amount"]), 
            //                                ((Label)(row.FindControl("lblAmount"))),
            //                                ((Label)row.FindControl("lblTotAlloc")),
            //                                ((Label)row.FindControl("lblBalance")))); 
            //((GridView)row.FindControl("gridForAllocation")).DataSource = MainDataSet.Tables("tmpMall_vw");
            //((GridView)row.FindControl("gridForAllocation")).DataBind();

        //    If DBNull.Value.Equals(row) = True Then
        //        Exit Sub
        //    End If
        
                    
        }
        protected void txtAccNetAmount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TransactionEvent.PageCustProps = PageCustomProps;
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                TransactionEvent.txtAccNetAmount_TextChanged(MainDataSet.Tables["main_vw"],
                                MainDataSet.Tables["acdet_vw"],
                                MainDataSet.Tables["item_vw"],
                                MainDataSet.Tables["lcode_vw"],
                                GridAccount,
                                grdlAllocDet,
                                LinkAcAdd,
                                txtAccNetAmount,
                                null);
            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
                return;
            }
        }

        protected void txtHtAcName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TransactionEvent.PageCustProps = PageCustomProps;
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                TransactionEvent.dropBPName_SelectedIndexChanged(txtHtAcName,
                    DropHTDRCR,  
                    lblHTAcBalAmt, 
                    MainDataSet.Tables["acdet_vw"],
                    MainDataSet.Tables["company"],
                    MainDataSet.Tables["main_vw"],
                    txtHTAddAmt);

                if (lblHTAcBalAmt.Text != "")
                    hiddHTAcBal.Value = "GET"; 

            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
            }

        }

        //protected void LinkItemAdd_Click(object sender, EventArgs e)
        //{
           

        //    GenGridItemRows(grdItemColView);
        //    //pnlItDetails.Visible = true;
        //    btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");
        //}

        protected void btnitadd_Click(object sender, EventArgs e)
        {
            //TransactionEvent.PageCustProps = PageCustomProps;
            //TransactionEvent.btnitadd_Click(MainDataSet,
            //    grdCharges,
            //    GridAccount,
            //    GridItem,
            //    grdlAllocDet,
            //    grdStockStatus,
            //    tblItemTotal,
            //    tblAddItem,
            //    txtGrossAmt,
            //    txtdedBefTax,
            //    txtTaxCharges,
            //    txtExAmt,
            //    txtAddCharges,
            //    txtTaxAmt,
            //    txtNonTax,
            //    txtfdisc,
            //    txtRoundoff,
            //    txtNetAmountTax,
            //    txtItemTotal,
            //    txtTotalQty,
            //    txtNetAmount,
            //    txtAccNetAmount,
            //    txtdate,
            //    txtitqty,
            //    txtitrate,
            //    dropItem);


            vouGridFill gridFill = new vouGridFill();
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            gridFill.gridBindAllocation(grdlAllocDet, MainDataSet.Tables["acdet_vw"]);     

            
        }

        protected void GridItem_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //TransactionEvent.PageCustProps = PageCustomProps;
            //DataSet test = MainDataSet;
            //TransactionEvent.GridItem_RowDeleting(MainDataSet,
            //        GridItem,
            //        grdStockStatus,
            //        grdCharges,
            //        GridAccount,
            //        grdlAllocDet,
            //        e.RowIndex,
            //        txtItemTotal,
            //        txtTotalQty,
            //        txtNetAmount,
            //        txtAccNetAmount,
            //        txtGrossAmt,
            //        txtdedBefTax,
            //        txtTaxCharges,
            //        txtExAmt,
            //        txtAddCharges,
            //        txtTaxAmt,
            //        txtNonTax,
            //        txtfdisc,
            //        txtRoundoff,
            //        txtNetAmountTax); 
 
 
            
        }

        protected void GridItem_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            GridItem.PageIndex = e.NewPageIndex;  
            GridItem.DataSource = MainDataSet.Tables["item_vw"];
            GridItem.DataBind(); 
        }

        protected void LinkAcAdd_Click(object sender, EventArgs e)
        {
            tblAcAdd.Visible = true;
            //trAcAddBal.Visible = false;
            //vouFillDropdownList voufilldrops = new vouFillDropdownList();
            //DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            //if (txtPartyNameB.Visible == true ||
            //    (strFunction.InList(PageCustomProps.PcvType, new string[] { "DN", "CN","JV","PC" }) == true ||
            //    strFunction.InList(PageCustomProps.Behave, new string[] { "DN", "CN","JV","PC" }) == true))
            //    voufilldrops.fillDropDownList(dropHTAcName,
            //            "--Select Party Name--",
            //            "ac_id",
            //            "ac_name",
            //            "PARTY",
            //            PageCustomProps.PcvType,
            //            PageCustomProps.Behave,
            //            MainDataSet.Tables["lcode_vw"],
            //            "ac_name,ac_id", 0,PageCustomProps.Vchkprod);

            //DropHTDRCR.Focus();
            txtHtAcName.Focus(); 
            txtHTAddAmt.Text = "0.00";
            //txtHTAddAmt.Attributes["onfocus"] = "this.select();";
        }

        protected void btnAddSave_Click(object sender, EventArgs e)
        {
            try
            {
                TransactionEvent.PageCustProps = PageCustomProps;
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                TransactionEvent.btnAddSave_Click(MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["acdet_vw"],
                        MainDataSet.Tables["lcode_vw"],
                        GridAccount,
                        grdlAllocDet,
                        DropHTDRCR,
                        txtHtAcName,
                        tblAcAdd,
                        txtHTAddAmt);
            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
            }
        }

        protected void GridAccount_RowCommand(object sender, GridViewCommandEventArgs e)
        {
           
            switch (e.CommandName.Trim().ToUpper())
            {
                //case "EDIT":
                //    numericFunction numFunction = new numericFunction();

                //    string acId = ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblacId")).Text.Trim();
                //    string amt =  ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblAmount")).Text.Trim();
                //    string amtType = ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblAmtType")).Text.Trim();
                //    string narr = ((Label)GridAccount.Rows[row.RowIndex].FindControl("lblNarr")).Text.Trim();
                //    GridAccount.EditIndex = row.RowIndex;
                //    GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
                //    GridAccount.DataBind();
 
                //    vouFillDropdownList voufilldrops = new vouFillDropdownList();
                //    DropDownList dropBPName = (DropDownList)GridAccount.Rows[row.RowIndex].FindControl("dropETAcName");
                //    DropDownList dropDrCr = (DropDownList)GridAccount.Rows[row.RowIndex].FindControl("DropETDRCR");
                     
                //    voufilldrops.fillDropDownList(dropBPName,
                //                                   "--Select Party Name--",
                //                                   "ac_id",
                //                                   "ac_name",
                //                                   "ACCOUNT",
                //                                   PageCustomProps.PcvType,
                //                                   PageCustomProps.Behave,
                //                                   MainDataSet.Tables["lcode_vw"],
                //                                   "ac_name,ac_id", 0);


                //    TextBox txtAddAmt = (TextBox)GridAccount.Rows[row.RowIndex].FindControl("txtETAddAmt");
                //    TextBox txtNarr = (TextBox)GridAccount.Rows[row.RowIndex].FindControl("txtETNarr");
                //    dropBPName.SelectedValue = acId.Trim();
                //    txtAddAmt.Text = amt.Trim();
                //    txtNarr.Text = narr.Trim();  
                //    dropDrCr.SelectedValue = amtType.Trim(); 
                //    txtAddAmt.Attributes["onfocus"] = "this.select();";
                //    break; 
                case "DELETE":
                    try
                    {
                        GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                        DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                        TransactionEvent.PageCustProps = PageCustomProps;
                        TransactionEvent.GridAccount_RowDeleting(MainDataSet.Tables["acdet_vw"],
                            MainDataSet.Tables["lcode_vw"],
                            MainDataSet.Tables["mall_vw"],
                            GridAccount,
                            grdlAllocDet,
                            MainDataSet.Tables.Contains("mall_vw"),
                            row.RowIndex);
                    }
                    catch (Exception Ex)
                    {
                        MessageErrorDisp(Ex);
                    }
                    break;
            }
        }

        protected void GridAccount_RowEditing(object sender, GridViewEditEventArgs e)
        {
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();
            string acName = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblAcName")).Text.Trim();
            string amt = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblAmount")).Text.Trim();
            string amtType = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblAmtType")).Text.Trim();
            string narr = ((Label)GridAccount.Rows[e.NewEditIndex].FindControl("lblNarr")).Text.Trim();

            GridAccount.EditIndex = e.NewEditIndex;
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            vouGridFill vouGridInit = new vouGridFill();
            GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
            string[] grdCols = vouGridInit.grdAccountColSHide(MainDataSet.Tables["lcode_vw"]);
            vouGridInit.gridBind(GridAccount, grdCols);

            vouFillDropdownList voufilldrops = new vouFillDropdownList();
            TextBox txtBPName = (TextBox)GridAccount.Rows[e.NewEditIndex].FindControl("txtETAcName");
            DropDownList dropDrCr = (DropDownList)GridAccount.Rows[e.NewEditIndex].FindControl("DropETDRCR");

            //voufilldrops.fillDropDownList(dropBPName,
            //                               "--Select Party Name--",
            //                               "ac_id",
            //                               "ac_name",
            //                               "ACCOUNT",
            //                               PageCustomProps.PcvType,
            //                               PageCustomProps.Behave,
            //                               MainDataSet.Tables["lcode_vw"],
            //                               "ac_name,ac_id", 0, PageCustomProps.Vchkprod);


            NumericTextBox txtAddAmt = (NumericTextBox)GridAccount.Rows[e.NewEditIndex].FindControl("txtETAddAmt");
            TextBox txtNarr = (TextBox)GridAccount.Rows[e.NewEditIndex].FindControl("txtETNarr");
            txtBPName.Text = acName.Trim();
            txtAddAmt.Text = amt.Trim();
            txtNarr.Text = narr.Trim();
            dropDrCr.SelectedValue = amtType.Trim();
            //txtAddAmt.Attributes["onfocus"] = "this.select();";

           

  
        }
        protected void GridAccount_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow)
                return;

            int lastcellindex = 1;
            ImageButton deleteButton = new ImageButton();
            deleteButton.CommandName = "DELETE"; 
            deleteButton = ((ImageButton)e.Row.Cells[lastcellindex].Controls[1]);
            deleteButton.OnClientClick = "if (!window.confirm('Are you sure you want to delete this A/c?')) return false;";
        }

        protected void GridAccount_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //try
            //{
            //    TransactionEvent.PageCustProps = PageCustomProps;
            //    TransactionEvent.GridAccount_RowDeleting(MainDataSet.Tables["acdet_vw"],
            //        MainDataSet.Tables["lcode_vw"],
            //        MainDataSet.Tables["mall_vw"],
            //        GridAccount,
            //        grdlAllocDet,
            //        MainDataSet.Tables.Contains("mall_vw"),
            //        e.RowIndex);
            //}
            //catch (Exception Ex)
            //{
            //    MessageErrorDisp(Ex); 
            //}
        }

        protected void LoadTab(object sender, EventArgs e)
        {
               switch (((LinkButton)sender).ID)
                {
                    case "lnkTab1":
                        lnkTab1.CssClass = "activeTab";
                        lnkTab2.CssClass = "";
                        lnkTab3.CssClass = "";
                        lnkTab4.CssClass = "";
                        pnlItemDetails.Visible = true; 
                        pnlTaxCharges.Visible = false; 
                        pnlAccountDetails.Visible = false; 
                        pnlAllocationDetails.Visible = false; 
                        break;
                    case "lnkTab2":
                        lnkTab2.CssClass = "activeTab";
                        lnkTab1.CssClass = "";
                        lnkTab3.CssClass = "";
                        lnkTab4.CssClass = ""; 
                        pnlItemDetails.Visible = false;
                        pnlTaxCharges.Visible = true;
                        pnlAccountDetails.Visible = false;
                        pnlAllocationDetails.Visible = false;
                        break;
                    case "lnkTab3":
                        lnkTab3.CssClass = "activeTab";
                        lnkTab1.CssClass = "";
                        lnkTab2.CssClass = "";
                        lnkTab4.CssClass = "";
                        pnlItemDetails.Visible = false;
                        pnlTaxCharges.Visible = false;
                        pnlAccountDetails.Visible = true;
                        pnlAllocationDetails.Visible = false;
                        break;
                     case "lnkTab4":
                        lnkTab4.CssClass = "activeTab";
                        lnkTab1.CssClass = "";
                        lnkTab2.CssClass = "";
                        lnkTab3.CssClass = "";
                        pnlItemDetails.Visible = false;
                        pnlTaxCharges.Visible = false;
                        pnlAccountDetails.Visible = false;
                        pnlAllocationDetails.Visible = true;
                        break;
                }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblTrType.Text = "uu";
        }

        protected void DropInvSer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropInvSer.SelectedIndex == 0)
                return;

            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"] = DropInvSer.SelectedItem.ToString().Trim();
            MainDataSet.Tables["main_vw"].AcceptChanges(); 
            vuInit initProc = new vuInit();
            initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode,
                    PageCustomProps.EditMode,
                    PageCustomProps.Entry_Tbl,
                    MainDataSet.Tables["main_vw"],
                    MainDataSet.Tables["lcode_vw"],
                    "SERIES");
            txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            Session["MainDataSet"] = MainDataSet; 
            DataAcess.Connclose();
        }

       

        protected void dropItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            //TransactionEvent.PageCustProps = PageCustomProps;
            ////TransactionEvent.dropItem_SelectedIndexChanged(dropItem,
            ////                    txtCarton,
            ////                    txtitrate,
            ////                    txtitqty,
            ////                    txtitamt,
            ////                    txtQtyCar,
            ////                    grdStockStatus,
            ////                    hidbalQty,
            ////                    btnitadd,
            ////                    MainDataSet);

            //if (TransactionEvent.ErrorMessage != "")
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + TransactionEvent.ErrorMessage + "');", true);
            //    TransactionEvent.ErrorMessage = "";
            //    return;
            //}

            TextBox txtItem = ((TextBox)((Control)sender).Parent.Parent.FindControl("txtitem"));
            NumericTextBox txtQty = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numqty"));
            NumericTextBox txtRate = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numrate"));
            GridView grdStock = ((GridView)((Control)sender).Parent.Parent.FindControl("grdStock"));
            HiddenField hidBalQty = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidbalQty"));
            HiddenField hidDropItemTag = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidDropItemTag"));
            HiddenField hidInvStk = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidInvStk"));
            HiddenField hidNegItBal = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidNegItBal"));
            HiddenField hidNonStk = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidNonStk"));

            //HtmlGenericControl divHtml = new HtmlGenericControl("div");
            //divHtml = ((HtmlGenericControl)((Control)sender).Parent.Parent.FindControl("divStockTitle"));
            vuTransactionevent TransactionEvent = new vuTransactionevent();
            TransactionEvent.PageCustProps = PageCustomProps;

            try
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                TransactionEvent.dropItem_SelectedIndexChanged(txtItem,
                                txtRate, 
                                txtQty, 
                                grdStock, 
                                hidBalQty, 
                                hidDropItemTag, 
                                hidInvStk,
                                hidNegItBal,
                                hidNonStk, 
                                MainDataSet, 
                                btnItemUpdate);
                                

                //try
                //{
                //    uwTRTrigItemTextChanged ItemTextChanged = new uwTRTrigItemTextChanged();
                //    ItemTextChanged.Item_TextChanged(MainDataSet,
                //            txtItem.Text.Trim(),
                //            sender,
                //            e);
                //}
                //catch ( Exception Ex)
                //{
                //    throw Ex;
                //}
                DataAcess.Connclose();
            }
            catch (Exception Ex)
            {
                DataAcess.Connclose();
                ScriptManager.RegisterStartupScript(this, this.GetType(), null, "alert('" + Ex.Message.Trim().Replace("'", "\'") + "');", true);
                txtItem.Text = "";
            }
            ScriptManager1.SetFocus(txtItem);
        }

        protected void gridForAllocation_RowCreated(object sender, GridViewRowEventArgs e)
        {

        }

        protected void gridForAllocation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView grd = (GridView)((Control)sender);
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            grd.PageIndex = e.NewPageIndex;
            grd.DataSource = MainDataSet.Tables["tmpMall_vw"];  
            grd.DataBind();
        }

        protected void gridForAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToString().ToUpper().Trim() != "SELECT")
                {
                    return;
                }

                int rowIndex = Convert.ToInt32(e.CommandArgument);

                DataSet MainDataSet = (DataSet)Session["MainDataSet"];

                GridView grd = (GridView)((Control)sender);
                CheckBox chkAllocExecess = (CheckBox)((Control)sender).Parent.Parent.FindControl("chkAllocExecess");
                Label lblAcName = (Label)((Control)sender).Parent.Parent.FindControl("lblAcName");
                Label lblAmount = (Label)((Control)sender).Parent.Parent.FindControl("lblAmount");
                Label lblTotAlloc = (Label)((Control)sender).Parent.Parent.FindControl("lblTotAlloc");
                Label lblBalance = (Label)((Control)sender).Parent.Parent.FindControl("lblBalance");


                GridViewRow grdRow = grd.Rows[rowIndex];

                string key = grd.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString().Trim();
                ////Dim key As String = Me.GridAccount.DataKeys(CInt(e.CommandArgument)).Value.ToString()
                ////acDetRow = MainDataSet.Tables("acdet_vw").Select("acSerial = '" + key + "'")(0)

                decimal allocate = 0;
                decimal tds = 0;
                decimal disc = 0;

                allocate = numFunction.toDecimal((((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtnew_all")) == null ? "0" :
                                                ((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtnew_all")).Text));
                tds = numFunction.toDecimal(numFunction.toDecimal((((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txttds")) == null ? "0" :
                                           ((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txttds")).Text)));
                disc = numFunction.toDecimal((((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtdisc")) == null ? "0" :
                                            ((TextBox)grd.Rows[grdRow.RowIndex].FindControl("txtdisc")).Text));

                DataRow tmpRow = MainDataSet.Tables["tmpMall_vw"].Select("id = '" + key + "'")[0];
                tmpRow["new_all"] = allocate;
                tmpRow["tds"] = tds;
                tmpRow["disc"] = disc;
                tmpRow.AcceptChanges();

                vuAllocation getAllocation = new vuAllocation();
                getAllocation.PageCustProps = PageCustomProps;
                if (allocate != 0)
                {
                    getAllocation.allocateTxtBox_TextChanged(PageCustomProps.AddMode,
                                PageCustomProps.EditMode,
                                MainDataSet.Tables["tmpMall_vw"],
                                MainDataSet.Tables["main_vw"],
                                lblAmount,
                                lblTotAlloc,
                                lblBalance,
                                allocate,
                                vAmt,
                                numFunction.toDecimal(this.hiddAllocate.Value),
                                chkAllocExecess,
                                tmpRow);
                    VchrAmt = getAllocation.VchrAmt;

                    if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                    {
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                        throw new Exception(getAllocation.ErrorMessage.Trim()); 
                    }

                }

                if (tds != 0)
                {
                    getAllocation.tdsamtTxtBox_TextChanged(PageCustomProps.AddMode,
                                PageCustomProps.EditMode,
                                MainDataSet.Tables["tmpMall_vw"],
                                MainDataSet.Tables["main_vw"],
                                tds,
                                numFunction.toDecimal(this.hiddTds.Value),
                                vAmt,
                                tmpRow);

                    if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                    {
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                        throw new Exception(getAllocation.ErrorMessage.Trim()); 
                    }

                }

                if (disc != 0)
                {
                    getAllocation.discountTxtBox_TextChanged(PageCustomProps.AddMode,
                            PageCustomProps.EditMode,
                            MainDataSet.Tables["tmpMall_vw"],
                            MainDataSet.Tables["main_vw"],
                            disc,
                            numFunction.toDecimal(this.hiddDisc.Value),
                            vAmt,
                            tmpRow);

                    if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                    {
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                        throw new Exception(getAllocation.ErrorMessage.Trim()); 
                    }
                }
                grd.DataSource = MainDataSet.Tables["tmpMall_vw"];
                grd.DataBind();
            }
            catch (Exception Ex)
            {
                DataAcess.Connclose(); 
                MessageErrorDisp(Ex); 
            }
        }

        protected void gridForAllocation_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row == null)
                    return;

                if (e.Row.DataItem == null)
                    return;

                if (e.Row.RowType != DataControlRowType.DataRow)
                    return;

                if (e.Row.RowType != DataControlRowType.Header &&
                    e.Row.RowType != DataControlRowType.Footer &&
                    e.Row.RowType != DataControlRowType.Pager)
                {
                    Button btn = new Button();
                    btn = (Button)e.Row.FindControl("btnAlloc");
                    btn.Text = "Allocate";
                    btn.CssClass = "AllocButton";
                    btn.CommandArgument = e.Row.RowIndex.ToString();
                }

                if (numFunction.toDecimal((((TextBox)e.Row.FindControl("txtnew_all")) == null ? "0" :
                                         ((TextBox)e.Row.FindControl("txtnew_all")).Text)) != 0 ||
                    numFunction.toDecimal((((TextBox)e.Row.FindControl("txttds")) == null ? "0" :
                                         ((TextBox)e.Row.FindControl("txttds")).Text)) != 0 ||
                    numFunction.toDecimal((((TextBox)e.Row.FindControl("txtdisc")) == null ? "0" :
                                         ((TextBox)e.Row.FindControl("txtdisc")).Text)) != 0)
                {
                    e.Row.ForeColor = System.Drawing.Color.Red;
                }

                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#ebebeb'");
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F8F8F8' ");

                NumericTextBox txtTds = ((NumericTextBox)e.Row.FindControl("txttds"));
                if (txtTds != null)
                {
                    if (numFunction.toDecimal(txtTds.Text) != 0)
                    {
                        txtTds.ForeColor = System.Drawing.Color.Red;
                    }

                    txtTds.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddTds.ClientID + "','" + txtTds.ClientID + "')");
                }

                NumericTextBox txtDisc = ((NumericTextBox)e.Row.FindControl("txtdisc"));
                if (txtDisc != null)
                {
                    if (numFunction.toDecimal(txtDisc.Text) != 0)
                    {
                        txtDisc.ForeColor = System.Drawing.Color.Red;
                    }
                    txtDisc.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddDisc.ClientID + "','" + txtDisc.ClientID + "')");
                }

                NumericTextBox txtAllocate = ((NumericTextBox)e.Row.FindControl("txtnew_all"));
                if (txtAllocate != null)
                {
                    if (numFunction.toDecimal(txtAllocate.Text) != 0)
                    {
                        txtAllocate.ForeColor = System.Drawing.Color.Red;
                    }
                    txtAllocate.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddAllocate.ClientID + "','" + txtAllocate.ClientID + "')");
                }
            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex); 
            }
        }

        protected void gridForAllocation_RowEditing(object sender, GridViewEditEventArgs e)
        {
            lblTrType.Text = "test"; 
        }

        protected void imgCollapsible_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ImageButton img = (ImageButton)((Control)sender);
                int rowIndex = Convert.ToInt32(img.CommandArgument);
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];

                if (img != null)
                {
                    if (img.AlternateText.Trim() == "+")
                    {
                        hiddODISC.Value = "";
                        hiddOTDS.Value = "";
                        hiddFld.Value = "";
                        DataRow AllocDataRow = null;  // null Static DataRow Variable
                        DataRow acDetRow = null;
                        decimal oTds = 0;
                        decimal oDisc = 0;

                        try
                        {
                            allocRowIndex = rowIndex;
                            acDetRow = TransactionEvent.btnAllocate_Click(MainDataSet,
                                                     grdlAllocDet,
                                                     rowIndex,
                                                     acDetRow);

                            oTds = TransactionEvent.OTds;
                            oDisc = TransactionEvent.ODisc;
                        }
                        catch (Exception EX)
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(rowIndex) + "');", true);
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "SetDivTitle", "SetDivTitle();", true);
                            throw new Exception(EX.Message); 
                        }

                        vuAllocation getAllocation = new vuAllocation();
                        getAllocation.PageCustProps = PageCustomProps;
                        if (TransactionEvent.Narration != "" && TransactionEvent.Narration != null)
                        {
                            string alertMess = "";
                            alertMess = "Existing Narration     : \n " + Convert.ToString(acDetRow["narr"]).Trim() + "\n\n ";
                            alertMess += "Regenerated Narration : \n" + TransactionEvent.Narration.Trim() + "\n\n";
                            alertMess += "Proceed with Regeneration ? ";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "narrMess", "narrMess('" + alertMess + "');", true);
                            if (hidDateValid.Value == "1")
                            {
                                try
                                {
                                    getAllocation.autoAllocAlert(acDetRow,
                                                 true,
                                                 TransactionEvent.EditNarration,
                                                 TransactionEvent.Narration.Trim());
                                    hidDateValid.Value = "";
                                }
                                catch (Exception Ex)
                                {
                                    throw new Exception(Ex.Message); 
                                }
                            }
                        }


                        GridView grd = (GridView)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                        FindControl("TabContainer2").
                                        FindControl("TabPanel1").FindControl("gridForAllocation");
                        CheckBox chk = (CheckBox)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                        FindControl("TabContainer2").
                                        FindControl("TabPanel1").FindControl("chkAllocExecess");
                        Label lblAcName = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                          FindControl("TabContainer2").
                                          FindControl("TabPanel1").FindControl("lblAcName");
                        Label lblAmount = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                          FindControl("TabContainer2").
                                          FindControl("TabPanel1").FindControl("lblAmount");
                        Label lblTotAlloc = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                            FindControl("TabContainer2").
                                            FindControl("TabPanel1").FindControl("lblTotAlloc");
                        Label lblBalance = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                            FindControl("TabContainer2").
                                            FindControl("TabPanel1").FindControl("lblTotAlloc");


                        getAllocation.vuAllocationGridInit(grd,
                                        MainDataSet.Tables["tmpMall_vw"],
                                        MainDataSet.Tables["main_vw"],
                                        chk,
                                        PageCustomProps.PcvType,
                                        PageCustomProps.AddMode,
                                        PageCustomProps.EditMode,
                                        PageCustomProps.ChargesPage,
                                        numFunction.toDecimal(acDetRow["amount"]),
                                        lblAmount,
                                        lblTotAlloc,
                                        lblBalance,
                                        false);
                        vAmt = getAllocation.VAmt; // set static variable of Page 
                        FromAcAmt = getAllocation.FromAcAmt;

                        lblAcName.Text = Convert.ToString(acDetRow["ac_name"]).Trim();

                        grd.DataSource = MainDataSet.Tables["tmpMall_vw"];
                        grd.DataBind();

                        //((TabContainer)grdAllocation.Rows[rowIndex].FindControl("TabContainer2")).Visible = true;

                        ((Panel)grdlAllocDet.Rows[rowIndex].FindControl("Panel3")).Visible = true;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(rowIndex) + "');", true);

                        isOpenGridForAllocation = true;
                        img.AlternateText = "-";
                        img.ImageUrl = "~/img/minus.png";
                        hiddFld.Value = "1";
                        AllocDataRow = acDetRow; // pass DataRow value to Static Variable 
                        hiddODISC.Value = Convert.ToString(oDisc); // Pass Data in hidden field
                        hiddOTDS.Value = Convert.ToString(oTds); // Pass Data in hidden field

                        Button btnOk = (Button)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                        FindControl("TabContainer2").
                                        FindControl("TabPanel1").FindControl("btnAllocDone");

                        btnOk.Attributes.Add("onClick", "javascript: return ShowHide('div" + Convert.ToString(rowIndex) + "','" + btnOk.ClientID + "');");
                        Session["AllocDataRow"] = AllocDataRow; 
                    }
                    else
                    {
                        if (img.AlternateText == "-")
                        {
                            vuAllocation getAllocation = new vuAllocation();
                            DataRow AllocDataRow = (DataRow)Session["AllocDataRow"];
                            getAllocation.PageCustProps = PageCustomProps;
                            getAllocation.ErrorMessage = "";
                            getAllocation.AfterCloseAllocationWindow(PageCustomProps.AddMode,
                                           PageCustomProps.EditMode,
                                           PageCustomProps.PcvType,
                                           MainDataSet.Tables["main_vw"],
                                           MainDataSet.Tables["item_vw"],
                                           MainDataSet.Tables["lcode_vw"],
                                           MainDataSet.Tables["acdet_vw"],
                                           MainDataSet.Tables["tmpMall_vw"],
                                           MainDataSet.Tables["mall_vw"],
                                           VchrAmt,
                                           numFunction.toDecimal(hiddOTDS.Value),  
                                           numFunction.toDecimal(hiddODISC.Value),
                                           AllocDataRow,
                                           MainDataSet.Tables["Company"]);

                            Session["AllocDataRow"] = AllocDataRow; 
                            if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                            {
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "showMess", "alert('" + getAllocation.ErrorMessage + "');", true);
                                getAllocation.ErrorMessage = "";
                            }

                            ((Panel)grdlAllocDet.Rows[rowIndex].FindControl("Panel3")).Visible = false;
                            img.AlternateText = "+";
                            img.ImageUrl = "~/img/plus.png";

                            GridView grd = (GridView)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                      FindControl("TabContainer2").
                                      FindControl("TabPanel1").FindControl("gridForAllocation");
                            CheckBox chk = (CheckBox)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                            FindControl("TabContainer2").
                                            FindControl("TabPanel1").FindControl("chkAllocExecess");
                            Label lblAcName = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                              FindControl("TabContainer2").
                                              FindControl("TabPanel1").FindControl("lblAcName");
                            Label lblAmount = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                              FindControl("TabContainer2").
                                              FindControl("TabPanel1").FindControl("lblAmount");
                            Label lblTotAlloc = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                                FindControl("TabContainer2").
                                                FindControl("TabPanel1").FindControl("lblTotAlloc");
                            Label lblBalance = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                                FindControl("TabContainer2").
                                                FindControl("TabPanel1").FindControl("lblTotAlloc");

                            isOpenGridForAllocation = false;
                            grd.Columns.Clear();
                            grd.Dispose();
                            chk.Checked = false;
                            lblAcName.Text = "";
                            lblAmount.Text = "";
                            lblBalance.Text = "";
                            lblTotAlloc.Text = "";
                            hiddODISC.Value = "";
                            hiddOTDS.Value = "";
                            hiddFld.Value = "";

                            ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(rowIndex) + "');", true);
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "SetDivTitle", "SetDivTitle();", true);

                        }
                    }
                    DataAcess.Connclose();  
                }
            }
            catch (Exception EX)
            {
                DataAcess.Connclose();  
                MessageErrorDisp(EX);
                ScriptManager.RegisterStartupScript(this, this.GetType(), null, "alert('" + EX.Message.Trim().Replace("'","\'")+ "');", true);
            }
        }

        protected void chkAllocExecess_CheckedChanged(object sender, EventArgs e)
        {
            decimal vchrBal1 = numFunction.toDecimal(((Label)((Control)sender).Parent.FindControl("lblTotAlloc")).Text);
            if (((CheckBox)(Control)sender).Checked == true)
            {
                VchrAmt = vchrBal1;
            }
            else
            {
                VchrAmt = FromAcAmt;
            }

        }

        protected void gridBindAfterPostback(int rowIndex)
        {
            GridView grd = (GridView)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                FindControl("TabContainer2").
                FindControl("TabPanel1").FindControl("gridForAllocation");
            CheckBox chk = (CheckBox)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                            FindControl("TabContainer2").
                            FindControl("TabPanel1").FindControl("chkAllocExecess");
            Label lblAcName = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                              FindControl("TabContainer2").
                              FindControl("TabPanel1").FindControl("lblAcName");
            Label lblAmount = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                              FindControl("TabContainer2").
                              FindControl("TabPanel1").FindControl("lblAmount");
            Label lblTotAlloc = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                FindControl("TabContainer2").
                                FindControl("TabPanel1").FindControl("lblTotAlloc");
            Label lblBalance = (Label)grdlAllocDet.Rows[rowIndex].FindControl("Panel3").
                                FindControl("TabContainer2").
                                FindControl("TabPanel1").FindControl("lblTotAlloc");


            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            vuAllocation getAllocation = new vuAllocation();
            getAllocation.PageCustProps = PageCustomProps; 
            getAllocation.vuAllocationGridInit(grd,
                            MainDataSet.Tables["tmpMall_vw"],
                            MainDataSet.Tables["main_vw"],
                            chk,
                            PageCustomProps.PcvType,
                            PageCustomProps.AddMode,
                            PageCustomProps.EditMode,
                            PageCustomProps.ChargesPage,  
                            vAmt,
                            lblAmount,
                            lblTotAlloc,
                            lblBalance,
                            true);

            //vAmt = getAllocation.VAmt; // set static variable of Page 

            //lblAcName.Text = Convert.ToString(acDetRow["ac_name"]).Trim();
            grd.DataSource = MainDataSet.Tables["tmpMall_vw"];
            grd.DataBind();

        }

        protected void btnAllocDone_Click(object sender, EventArgs e)
        {
            vuAllocation getAllocation = new vuAllocation();
            getAllocation.PageCustProps = PageCustomProps;
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            DataRow AllocDataRow = (DataRow)Session["AllocDataRow"];
            getAllocation.AfterCloseAllocationWindow(PageCustomProps.AddMode,
                           PageCustomProps.EditMode,
                           PageCustomProps.PcvType,
                           MainDataSet.Tables["main_vw"],
                           MainDataSet.Tables["item_vw"],
                           MainDataSet.Tables["lcode_vw"],
                           MainDataSet.Tables["acdet_vw"],
                           MainDataSet.Tables["tmpMall_vw"],
                           MainDataSet.Tables["mall_vw"],
                           VchrAmt,
                           Convert.ToDecimal((hiddOTDS.Value==""?"0":hiddOTDS.Value)),
                           Convert.ToDecimal((hiddODISC.Value==""?"0":hiddODISC.Value)),
                           AllocDataRow,
                           MainDataSet.Tables["Company"]);

            Session["AllocDataRow"] = AllocDataRow;
            GridView grd = (GridView)((Control)sender).Parent.FindControl("gridForAllocation");
            CheckBox chk = (CheckBox)((Control)sender).Parent.FindControl("chkAllocExecess");
            Label lblAcName = (Label)((Control)sender).Parent.FindControl("lblAcName");
            Label lblAmount = (Label)((Control)sender).Parent.FindControl("lblAmount");
            Label lblTotAlloc = (Label)((Control)sender).Parent.FindControl("lblTotAlloc");
            Label lblBalance = (Label)((Control)sender).Parent.FindControl("lblTotAlloc");

            ((Panel)((Control)sender).Parent.Parent.Parent.Parent).Visible = false;
            ImageButton img = (ImageButton)((Control)sender).Parent.Parent.Parent.
                              Parent.Parent.FindControl("imgCollapsible");
            
            img.AlternateText = "+";
            img.ImageUrl = "~/img/plus.png";
            //Dispose all objects
            grd.Columns.Clear(); 
            grd.Dispose();

            isOpenGridForAllocation = false;
            chk.Checked = false;
            lblAcName.Text = "";
            lblAmount.Text = "";
            lblBalance.Text = "";
            lblTotAlloc.Text = "";
            hiddODISC.Value = "";
            hiddOTDS.Value = "";
            hiddFld.Value = "";

            ScriptManager.RegisterStartupScript(this, this.GetType(), "HideProgress", "HideProgress('div" + Convert.ToString(allocRowIndex) + "');", true);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "SetDivTitle", "SetDivTitle();", true);

             
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                vuSave updateTrans = new vuSave();
                bool isSave = false;
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];

                updateTrans.PageCustProps = PageCustomProps;
                if (strFunction.InList(PageCustomProps.PcvType, new string[] { "BR", "BP","CR","CP" }) == true ||
                    strFunction.InList(PageCustomProps.Behave, new string[] { "BR", "BP","CR","CP" }) == true)
                {
                    isSave = updateTrans.Saveit(txtDateB,
                                       txtPartyNameB,
                                       txtBankName,
                                       cboInvSeriesB,
                                       cboCategoryB,
                                       cboDepartMentB,
                                       null,
                                       txtInvoiceNoB,
                                       txtNetAmount,
                                       MainDataSet,
                                       this,
                                       hidDateValid,
                                       txtBillNo,
                                       txtBillDate,
                                       txtNarr,
                                       txtNarrB,
                                       txtChequeNoB,
                                       txtDrawnOnB);
                   

                }
                else
                {
                    isSave = updateTrans.Saveit(txtdate,
                                       txtPartyName,
                                       null,
                                       DropInvSer,
                                       cboCategory,
                                       cboDepartMent,
                                       cboRule,
                                       txtInvNo,
                                       txtNetAmount,
                                       MainDataSet,
                                       this,
                                       hidDateValid,
                                       txtBillNo,
                                       txtBillDate,
                                       txtNarr,
                                       txtNarrB,
                                       txtChequeNoB,
                                       txtDrawnOnB);
                }
                Session["MainDataSet"] = MainDataSet;

                if (isSave == true)
                {
                    lblSaveMessTop.Visible = true;
                    lblSaveMessTop.Text = "Record has been saved sucessfully...";
                    lblSaveMessBottom.Visible = true;
                    lblSaveMessBottom.Text = "Record has been saved sucessfully...";
                    //EnableDisableControls(Page, false);
                    //ControlShouldbeEnabled(true);
                    //liEdit.Style.Clear();

                    tdErrorMess.Visible = false;
                    PageCustomProps.EditMode = false;
                    PageCustomProps.AddMode = false;
                    InitStartWithTranCd = 0;

                    SessionsRemove(); // Remove existing Session Variables
                    Response.Redirect("vuTransactionview.aspx?pcvtype=" + PageCustomProps.PcvType.Trim());
                                        
                }
            }
            catch (Exception Ex)
            {
                //string genMess = Ex.Message.Trim().Substring(0,Ex.Message.Trim().IndexOf('|')) + "This is a test sss ss sss ";
                //string techMess = Ex.Message.Trim().Substring(Ex.Message.Trim().IndexOf('|')+1, (Ex.Message.Trim().Length - Ex.Message.Trim().IndexOf('|'))-1);
                //lblErrMess.Text = genMess.Trim();
                //if (techMess.Trim() != "")
                //{
                //    cpErrorMess.Enabled = true;
                //    lblErrTechMess.Text = techMess.Trim();
                //    lblErrTechMess.Visible = true;
                //}
                //else
                //{
                //    lblErrTechMess.Visible = false;
                //    cpErrorMess.Enabled = false;
                //}
                //tdErrorMess.Visible = true;
                MessageErrorDisp(Ex);   
                return;
            }

        }

        protected void MessageErrorDisp(Exception Ex)
        {
            string genMess = "";
            string techMess = "";

            if (Ex.Message.Trim().IndexOf('|') >= 0)
            {
                genMess = Ex.Message.Trim().Substring(0, Ex.Message.Trim().IndexOf('|'));
                techMess = Ex.Message.Trim().Substring(Ex.Message.Trim().IndexOf('|') + 1, (Ex.Message.Trim().Length - Ex.Message.Trim().IndexOf('|')) - 1);
            }
            else
                genMess = Ex.Message.Trim();  
                

            lblErrMess.Text = genMess.Trim();
            if (techMess.Trim() != "")
            {
                //cpErrorMess.Enabled = true;
                lblErrTechMess.Text = techMess.Trim();
                lblErrTechMess.Visible = true;
            }
            else
            {
                lblErrTechMess.Visible = true;
                lblErrTechMess.Text = "No Technical Error found...";  
                //lblErrTechMess.Visible = false;
                //cpErrorMess.Enabled = false;
            }
            tdErrorMess.Visible = true;
        }

        protected void txtDueDays_TextChanged(object sender, EventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            TransactionEvent.txtDueDays_TextChanged(txtDueDate,
                                        txtdate,
                                        txtDueDays,
                                        MainDataSet.Tables["main_vw"]);
            Session["MainDataSet"] = MainDataSet;
            txtDueDate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["due_dt"]));

        }

        protected void newRec(ref DataSet MainDataSet)
        {
            getTables GetTables = new getTables();
            PageCustomProps.AddMode = true;
            PageCustomProps.EditMode = false;
            
            // Below Variable use for Allocation
            isOpenGridForAllocation = false; // always false in postback is false
            vAmt = 0; // always false in postback is false
            VchrAmt = 0; // always false in postback is false
            FromAcAmt = 0; // always false in postback is false
            // End
            
            vuInit initProc = new vuInit();
            initProc.AddNew(MainDataSet.Tables["main_vw"], MainDataSet.Tables["lcode_vw"], MainDataSet.Tables["company"], PageCustomProps.Entry_Tbl.ToString(), PageCustomProps.PcvType.ToString(), "entry_ty+convert(varchar(20),convert(int,date))+doc_no");
            PageCustomProps.LbackDated = initProc.LbackDated;
            PageCustomProps.LTodaySDate = initProc.LTodaySDate;
            PageCustomProps.PBackDate = initProc.PBackDated;
            PageCustomProps.JustInvoice = "";
            PageCustomProps.JustSeries = "";
            PageCustomProps.EditSeries = "";
            PageCustomProps.EditInvoice = "";
            PageCustomProps.VarETGoDown = "";
            PageCustomProps.VarETGodownTo = "";
            TransactionEvent.PageCustProps = PageCustomProps;
            TransactionEvent.ErrorMessage = "";

            if (strFunction.InList(PageCustomProps.PcvType, new string[] { "OB", "OS" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "OB", "OS" }))
            {
                MainDataSet.Tables["main_vw"].Rows[0]["u_choice"] = true;  
            }


            if ((PageCustomProps.PcvType == "BR" || PageCustomProps.PcvType == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.PcvType == "CR")
                || (PageCustomProps.Behave == "BR" || PageCustomProps.Behave == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.Behave == "CR"))
            {
                if (GetTables.checkldcw("Series", "Inv_Sr", PageCustomProps.PcvType.Trim()) == false)
                {
                    initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode, PageCustomProps.EditMode, PageCustomProps.Entry_Tbl, MainDataSet.Tables["main_vw"], MainDataSet.Tables["lcode_vw"], "BUTTON");
                    txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                }

            }

            if (PageCustomProps.ChargesPage == true)
            {
                MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw");
                MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw1");
            }

            if (PageCustomProps.AllocationPage == true)
            {
                if (System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["allo_op"]) == true && System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["acc_adj"]))
                {
                    MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select * from " + PageCustomProps.Entry_Tbl.Trim() + "acdet where 1=0", "lal_vw");
                }
            }


            if (tblOtherTran.Visible == true)
            {
                if (txtPartyName.Visible == true && txtPartyName.Enabled == true)
                {
                    //dropParty.SelectedIndex = 0;
                    txtPartyName.Attributes.Add("Onfocus", "javascript:updateHiddenTextField('" + hiddPartyName.ClientID + "','" + txtPartyName.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboCategory.Visible == true && cboCategory.Enabled == true)
                {
                    cboCategory.SelectedIndex = 0;
                }

                if (DropInvSer.Visible == true && DropInvSer.Enabled == true)
                {
                    DropInvSer.SelectedIndex = 0;
                }

                if (cboDepartMent.Visible == true && cboDepartMent.Enabled == true)
                {
                    cboDepartMent.SelectedIndex = 0;
                }

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    cboRule.SelectedIndex = 0;
                }

            }

            if (tblBankTran.Visible == true)
            {
                if (txtPartyNameB.Visible == true && txtPartyNameB.Enabled == true)
                {
                    //txtPartyNameB.SelectedIndex = 0;
                    txtPartyNameB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBnkPartyName.ClientID + "','" + txtPartyNameB.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboInvSeriesB.Visible == true && cboInvSeriesB.Enabled == true)
                {
                    cboInvSeriesB.SelectedIndex = 0;
                }

                if (cboDepartMentB.Visible == true && cboDepartMentB.Enabled == true)
                {
                    cboDepartMentB.SelectedIndex = 0;
                }

                if (txtBankName.Visible == true && txtBankName.Enabled == true)
                {
                    txtBankName.Text = "";
                    if (strFunction.InList(PageCustomProps.PcvType, new string[] { "BR", "BP" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "BR", "BP" }))
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    else
                    {
                        if (strFunction.InList(PageCustomProps.PcvType, new string[] { "CR", "CP" }) == true ||
                            strFunction.InList(PageCustomProps.Behave, new string[] { "CR", "CP" }))
                            txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    }

                    if (trforBank.Visible == true)
                        txtDrawnOnB.Text = "";
                }

            }

            //vouGridFill vouGridInit = new vouGridFill();
            //if (PageCustomProps.ItemPage == true)
            //{
            //    vouGridInit.gridItemFill(true, MainDataSet.Tables["lother_vw"], GridItem, MainDataSet.Tables["Item_vw"],
            //                             PageCustomProps.ChargesPage, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["company"], PageCustomProps.PcvType,
            //                             PageCustomProps.Behave, 0);
            //    PageCustomProps.SalesTaxItem = vouGridInit.SalesTaxItem;
            //}

            //if (PageCustomProps.AccountPage == true)
            //    vouGridInit.gridAcccountFill(GridAccount, MainDataSet.Tables["acdet_vw"], MainDataSet.Tables["lcode_vw"]);

            //if (PageCustomProps.AllocationPage == true)
            //{
            //    vouGridInit.gridAllocation(grdlAllocDet, MainDataSet.Tables["lal_vw"], MainDataSet.Tables["acdet_vw"],
            //                               MainDataSet.Tables["company"]);
            //    grdlAllocDet.Columns[0].Visible = false; 
            //}

            //if (PageCustomProps.ChargesPage == true)
            //    vouGridInit.gridTaxFill(grdCharges, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["lcode_vw"],
            //                            MainDataSet.Tables["tax_vw"], MainDataSet.Tables["tax_vw1"],
            //                            MainDataSet.Tables["main_vw"], MainDataSet.Tables["item_vw"],
            //                            MainDataSet.Tables["company"], MainDataSet.Tables["stax_vw"],
            //                            PageCustomProps.EditMode, PageCustomProps.AddMode,
            //                            PageCustomProps.PcvType, PageCustomProps.Behave);

            if (PageCustomProps.AinfoPage == true)
            {
                foreach (DataRow lotherRow in MainDataSet.Tables["lother_vw"].Rows)
                {
                    if (Convert.ToBoolean(lotherRow["att_file"]) == true && Convert.ToBoolean(lotherRow["inter_use"]) == false)
                    {
                        PageCustomProps.AinfoPage = true;
                        break;
                    }
                }
            }

            if (PageCustomProps.AinfoPage == true)
            {
                if (MainDataSet.Tables["lother_vw"].Rows.Count > 0)
                {
                    tblAddinfoDet.Visible = true;
                    try
                    {
                        TransactionEvent.AdditionalInfoShow(MainDataSet,
                                    tblAddInfo);
                    }
                    catch (Exception Ex)
                    {
                        tblAddinfoDet.Visible = false;
                        PageCustomProps.AinfoPage = false;
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message + "');", true);
                    }
                }
                else
                {
                    tblAddinfoDet.Visible = false;
                }
            }
            else
            {
                tblAddinfoDet.Visible = false;
            }

            DataAcess.Connclose();

            TransactionEvent.PageCustProps = PageCustomProps;

            if (PageCustomProps.AddMode)
            {
                if ((PageCustomProps.PcvType == "BR" ||
                   PageCustomProps.PcvType == "BP" ||
                   PageCustomProps.PcvType == "CP" ||
                   PageCustomProps.PcvType == "CR") ||
                   (PageCustomProps.Behave == "BR" ||
                    PageCustomProps.Behave == "BP" ||
                    PageCustomProps.Behave == "CP" ||
                    PageCustomProps.Behave == "CR"))
                {
                    txtDateB.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                    if (txtDateB.Text != "")
                    {
                        TransactionEvent.DateValidation(txtDateB,
                            null,
                            null,
                            trduedt,
                            this.Page,
                            hidDateValid,
                            MainDataSet.Tables["main_vw"],
                            MainDataSet.Tables["Company"],
                            MainDataSet.Tables["lcode_vw"],
                            MainDataSet.Tables["item_vw"],
                            MainDataSet.Tables["acdet_vw"],
                            true);
                    }
                    txtDateB.Focus();

                }
                else
                {
                    if (DropInvSer.Visible == false || DropInvSer.Enabled == false)
                    {
                        initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode,
                                    PageCustomProps.EditMode,
                                    PageCustomProps.Entry_Tbl,
                                    MainDataSet.Tables["main_vw"],
                                    MainDataSet.Tables["lcode_vw"],
                                    "BUTTON");
                        txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
                    }

                    txtdate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                    if (txtdate.Text != "")
                    {
                        DateValidation(txtdate,MainDataSet);
                      
                    }
                    txtdate.Focus();
                }


            }
        }

        protected void btnDiscard_Click(object sender, EventArgs e)
        {
            //trOthTranDivParty.Visible = false;
            //trAcAddBal.Visible = false;

            SessionsRemove(); // Remove existing Session Variables
            Response.Redirect("vutransactionview.aspx?pcvtype=" + PageCustomProps.PcvType);

            //if (PageCustomProps.AddMode == true && InitStartWithTranCd == 0)
            //{
            //    if (InitStartWithTranCd == 0)
            //    {
            //        Session.Remove("MainDataSet");  
            //        Response.Redirect("vutransactionview.aspx?pcvtype="+PageCustomProps.PcvType);
            //    }
            //}
            //else
            //{
            //    if (PageCustomProps.EditMode == true && InitStartWithTranCd != 0)
            //    {
            //        //lnkNew.CssClass = "";
            //        //lnkEdit.CssClass = "";
            //        //lnkDelete.CssClass = "";
            //        //lnkCopy.CssClass = "";
            //        //lnkPrint.CssClass = "";
            //        //EnableDisableControls(Page, false);
            //        //pnlTran.Visible = true;
            //        //pnlPrint.Visible = false;
            //        //txtAccNetAmount.Enabled = false;
            //        //lblSaveMessBottom.Visible = false;
            //        //lblSaveMessTop.Visible = false;
            //        //lnkEdit.Font.Underline = true;
            //        //PageCustomProps.EditMode = false;
            //        //PageCustomProps.AddMode = false;  
            //        //ControlShouldbeEnabled(true);

            //        //EnableDisableControls(Page, false);
            //        //pnlTran.Visible = true;
            //        //txtAccNetAmount.Enabled = false;
            //        lblSaveMessBottom.Visible = false;
            //        lblSaveMessTop.Visible = false;
            //        PageCustomProps.EditMode = true;
            //        Session.Remove("MainDataSet");

            //        DataSet MainDataSet = new DataSet();
            //        DataView grdItemColView = new DataView();
            //        InitGetTables(ref MainDataSet);
            //        EditRec(Convert.ToInt32(InitStartWithTranCd),ref MainDataSet);
            //        BindGridView(ref MainDataSet,ref grdItemColView);

            //        Session["MainDataSet"] = MainDataSet;
            //        Session["GridItemColView"] = grdItemColView;
            //        //ConditionalControlEnabled();
            //        PageCustomProps.EditMode = false;
            //        PageCustomProps.AddMode = false;
            //        //ControlShouldbeEnabled(true);
            //    }
            //    else
            //    {
            //        if (PageCustomProps.AddMode == true || InitStartWithTranCd != 0)
            //        {
            //            //EnableDisableControls(Page, false);
            //            //pnlTran.Visible = true;
            //            //txtAccNetAmount.Enabled = false;
            //            lblSaveMessBottom.Visible = false;
            //            lblSaveMessTop.Visible = false;
            //            PageCustomProps.EditMode = true;

            //            Session.Remove("MainDataSet");
            //            DataSet MainDataSet = new DataSet();
            //            DataView grdItemColView = new DataView();
            //            InitGetTables(ref MainDataSet);
            //            EditRec(Convert.ToInt32(InitStartWithTranCd),ref MainDataSet);
            //            BindGridView(ref MainDataSet,ref grdItemColView);

            //            Session["MainDataSet"] = MainDataSet;
            //            Session["GridItemColView"] = grdItemColView; 
            //            //ConditionalControlEnabled();
            //            PageCustomProps.EditMode = false;
            //            PageCustomProps.AddMode = false;
            //            //ControlShouldbeEnabled(true);
            //        }

            //    }
            //}

        }


        protected void GridItem_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.Trim() == "DELETE")
            {
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                TransactionEvent.PageCustProps = PageCustomProps;
                //TransactionEvent.GridItem_RowDeleting(MainDataSet,
                //        GridItem,
                //        grdStockStatus,
                //        grdCharges,
                //        GridAccount,
                //        grdlAllocDet,
                //        row.RowIndex,
                //        txtItemTotal,
                //        txtTotalQty,
                //        txtNetAmount,
                //        txtAccNetAmount,
                //        txtGrossAmt,
                //        txtdedBefTax,
                //        txtTaxCharges,
                //        txtExAmt,
                //        txtAddCharges,
                //        txtTaxAmt,
                //        txtNonTax,
                //        txtfdisc,
                //        txtRoundoff,
                //        txtNetAmountTax);
            }
            else
            {
                if (e.CommandName.Trim() == "EDIT")
                {
                    //vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
                    //GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                    //DataRow editRow;
                    //string key = GridItem.DataKeys[row.RowIndex].Value.ToString();
                    //editRow = MainDataSet.Tables["item_vw"].Select("ItSerial='" + key + "'")[0];
                    
                    //pnlItDetails.Visible = true;
                    //tblItDetails.Visible = true; 
                    //SetGridValue.btnClick(tblItDetails, editRow, "UNBOXING");    
                    
                    //btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");

                }
            }
        }


        private void EnableDisableControls(Control root,bool isflag)
        {
            miscFunctions miscFunc = new miscFunctions();
            miscFunc.EnableDisableControlsRecursive(root, isflag);
            miscFunc.Dispose();
            lnkBack.Enabled = true;
            btnBack.Enabled = true; 
        }

        protected void ControlShouldbeEnabled(bool flag)
        {
            lnkTab1.Enabled = flag;
            lnkTab2.Enabled = flag;
            lnkTab3.Enabled = flag;
            lnkTab4.Enabled = flag;
        }

        protected void ConditionalControlEnabled(ref DataSet MainDataSet)
        {
            getTables GetTables = new getTables();

            if ((PageCustomProps.PcvType == "BR" || PageCustomProps.PcvType == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.PcvType == "CR")
                || (PageCustomProps.Behave == "BR" || PageCustomProps.Behave == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.Behave == "CR"))
            {
                if (GetTables.checkldcw("Series", "Inv_Sr", PageCustomProps.PcvType.Trim()) == false)
                {
                    cboInvSeriesB.Enabled = false;
                }

                if (GetTables.checkldcw("Category", "Cate", PageCustomProps.PcvType.Trim()) == false)
                    cboCategoryB.Enabled = false;

                cboDepartMentB.Enabled = GetTables.checkldcw("Department", "Dept", PageCustomProps.PcvType.Trim());

                if (cboDepartMentB.Enabled == false)
                {
                    trBnkDept.Visible = false;
                }
                else
                {
                    trBnkDept.Visible = true;
                }
            }
            else
            {
                if (strFunction.InList(PageCustomProps.PcvType, new string[] { "DN", "CN" }) == false ||
                    strFunction.InList(PageCustomProps.Behave, new string[] { "DN", "CN" }) == false)
                    cboRule.Enabled = GetTables.checkldcw("Rules", "[Rule]", PageCustomProps.PcvType.Trim());
                else
                    cboRule.Enabled = false;

                DropInvSer.Enabled = GetTables.checkldcw("Series", "Inv_Sr", PageCustomProps.PcvType.Trim());
                cboCategory.Enabled = GetTables.checkldcw("Category", "Cate", PageCustomProps.PcvType.Trim());
                cboDepartMent.Enabled = GetTables.checkldcw("Department", "dept", PageCustomProps.PcvType.Trim());

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    trRule.Visible = true;
                    cboRule.Enabled = true;
                }
                else
                {
                    trRule.Visible = false;
                }

                if (cboCategory.Enabled == true && cboDepartMent.Enabled == true)
                {
                    tdCatDept.Visible = true;
                }
                else
                {
                    tdCatDept.Visible = false;
                }
            }

            if (System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_dbcr"]) == true)
                LinkAcAdd.Enabled = true;
            else
                LinkAcAdd.Enabled = false;

            if ((PageCustomProps.PcvType == "BR" || PageCustomProps.PcvType == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.PcvType == "CR" || PageCustomProps.PcvType == "EP" || PageCustomProps.PcvType == "PC")
                || (PageCustomProps.Behave == "BR" || PageCustomProps.Behave == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.Behave == "CR" || PageCustomProps.Behave == "EP" || PageCustomProps.Behave == "PC"))
            {
                txtAccNetAmount.Enabled = true;
            }
            else
            {
                if (strFunction.InList(PageCustomProps.PcvType,new string[] {"DN","CN","JV","OB"}) == false || 
                    strFunction.InList(PageCustomProps.Behave,new string[] {"DN","CN","JV","OB"}) == false)
                    txtAccNetAmount.Enabled = false;
                else
                    txtAccNetAmount.Enabled = true;
            }
        }

        protected void GeneralControlEnabled(ref DataSet MainDataSet)
        {
            getTables GetTables = new getTables();
            if (System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_item"]) == true)
            {
                if (System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["inv_op"]) == false && System.Convert.ToBoolean(MainDataSet.Tables["company"].Rows[0]["bill_inven"]) == false)
                {
                    PageCustomProps.ItemPage = false;
                }
                else
                {
                    PageCustomProps.ItemPage = true;
                }
            }

            PageCustomProps.AccountPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_account"]);
            PageCustomProps.ChargesPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_disc"]);
            PageCustomProps.IchargesPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["i_disc"]);

            if (PageCustomProps.AccountPage == true)
            {
                PageCustomProps.AllocationPage = true;
            }

            PageCustomProps.AinfoPage = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_extra"]);
            PageCustomProps.TdsPage = false;

            if (PageCustomProps.PcvType == "EP" || PageCustomProps.PcvType == "BP" || PageCustomProps.PcvType == "CP")
                PageCustomProps.TdsPage = true;

            PageCustomProps.ServiceTaxPage = false;

            if (PageCustomProps.PcvType == "IS" || PageCustomProps.PcvType == "SB")
            {
                PageCustomProps.ServiceTaxPage = true;
            }

            //if (PageCustomProps.TdsPage == false)
            //{
            //    tdCatDept.Visible = false;
            //}
            //else
            //{
            //    tdCatDept.Visible = true;
            //}

            trduedt.Visible = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_duedt"]);
            trNarration.Visible = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_narr"]);
            trNarrationB.Visible = System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_narr"]);

            if ((PageCustomProps.PcvType == "BR" || PageCustomProps.PcvType == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.PcvType == "CR")
                || (PageCustomProps.Behave == "BR" || PageCustomProps.Behave == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.Behave == "CR"))
            {
                tblBankTran.Visible = true;
                tblOtherTran.Visible = false;
                //txtAccNetAmount.Enabled = true;
                txtInvoiceNoB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddInvOldValueB.ClientID + "','" + txtInvoiceNoB.ClientID + "',null,'');");
                if (strFunction.InList(PageCustomProps.PcvType,new string[] {"BR","BP"}) == true ||
                    strFunction.InList(PageCustomProps.PcvType,new string[] {"BR","BP"}) == true)
                {
                    trforBank.Visible = true;
                    lblBnkAcCaption.Text = "Bank Name :";
                }
                else
                {
                    if (strFunction.InList(PageCustomProps.PcvType,new string[] {"CR","CP"}) == true ||
                        strFunction.InList(PageCustomProps.PcvType,new string[] {"CR","CP"}) == true)
                    {
                        trforBank.Visible = false;
                        lblBnkAcCaption.Text = "A/c Name :";
                    }
                }
            }
            else
            {
                tblBankTran.Visible = false;
                tblOtherTran.Visible = true;
                //txtAccNetAmount.Enabled = false;
                txtInvNo.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddInvOldValue.ClientID + "','" + txtInvNo.ClientID + "',null,'');");
            }


            if ((strFunction.InList(PageCustomProps.PcvType,new string[] {"PT","EP"}) == true ||
                 strFunction.InList(PageCustomProps.Behave, new string[] {"PT","EP"}) == true) ||
                 (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0 &&
                 PageCustomProps.PcvType == "AR" ||
                 PageCustomProps.Behave == "AR"))
            {
                tblBill.Visible = true;
            }
            else
            {
                tblBill.Visible = false;
            }

            if (PageCustomProps.ItemPage == true)
            {
                lnkTab1.Visible = true;
                lnkTab1.CssClass = "activeTab";
                pnlItemDetails.CssClass = "pnlTabShow";
                liItem.Visible = true;
            }
            else
            {
                lnkTab1.Visible = false;
                lnkTab1.CssClass = "";
                liItem.Visible = false;
                pnlItemDetails.CssClass = "pnlTabHide";
            }

            if (PageCustomProps.ChargesPage == true)
            {
                lnkTab2.Visible = true;
                liTaxCharges.Visible = true;
            }
            else
            {
                lnkTab2.Visible = false;
                lnkTab2.CssClass = "";
                liTaxCharges.Visible = false;
            }

            if (PageCustomProps.AccountPage == true)
            {
                if (PageCustomProps.ItemPage == false)
                {
                    lnkTab3.CssClass = "activeTab";
                    pnlAccountDetails.CssClass = "pnlTabShow";
                }
                lnkTab3.Visible = true;
                liAccount.Visible = true;
            }
            else
            {
                lnkTab3.Visible = false;
                liAccount.Visible = false;
            }


            if (PageCustomProps.AllocationPage == true)
            {
                lnkTab4.Visible = true;
                liAllocation.Visible = true;
            }
            else
            {
                lnkTab4.Visible = true;
                liAllocation.Visible = false;
            }

            if (tblOtherTran.Visible == true)
            {
                // DueDate Row
                if (Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["v_duedt"]) == true)
                    trduedt.Visible = true;
                else
                    trduedt.Visible = false;

                // Narration Row
                if (Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_narr"]) == true)
                    trNarration.Visible = true;
                else
                    trNarration.Visible = false;

                // Bill Row
                if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "PT", "EP" }) == true ||
                    strFunction.InList(PageCustomProps.Behave, new string[] { "PT", "EP" }) == true) ||
                    (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0 &&
                     PageCustomProps.PcvType == "AR" ||
                     PageCustomProps.Behave == "AR"))
                {
                    tblBill.Visible = true;
                    txtBillDate.Attributes.Add("onfocus", "javascript:getBillDate();");
   
                }
                else
                {
                    tblBill.Visible = false;
                }

            }

            if (PageCustomProps.AinfoPage == true)
            {
                foreach (DataRow lotherRow in MainDataSet.Tables["lother_vw"].Rows)
                {
                    if (Convert.ToBoolean(lotherRow["att_file"]) == true && Convert.ToBoolean(lotherRow["inter_use"]) == false)
                    {
                        PageCustomProps.AinfoPage = true;
                        break;
                    }
                }
            }

            if (PageCustomProps.AinfoPage == true)
            {
                if (MainDataSet.Tables["lother_vw"].Rows.Count > 0)
                {
                    tblAddinfoDet.Visible = true;
                }
                else
                {
                    tblAddinfoDet.Visible = false;
                }
            }
            else
            {
                tblAddinfoDet.Visible = false;
            }


            if (PageCustomProps.ChargesPage == true)
            {
                MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw");
                MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw1");
            }

            if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "OB" }) == true ||
                 strFunction.InList(PageCustomProps.Behave, new string[] { "OB" }) == true))
            {
                trOpBalDBCR.Visible = true;
            }
            else
            {
                trOpBalDBCR.Visible = false;
            }

            // ********************** old code ******************************************
            //if ((PageCustomProps.PcvType == "BR" || PageCustomProps.PcvType == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.PcvType == "CR")
            //    || (PageCustomProps.Behave == "BR" || PageCustomProps.Behave == "BP" || PageCustomProps.PcvType == "CP" || PageCustomProps.Behave == "CR"))
            //{
            //    txtAccNetAmount.Enabled = true;
            //    getTables GetTables = new getTables();

            //    if (GetTables.checkldcw("Series", "Inv_Sr", PageCustomProps.PcvType.Trim()) == false)
            //    {
            //        cboInvSeriesB.Enabled = false;
            //        vuInit initProc = new vuInit();
            //        initProc.txtInvoiceNo_GotFocus(PageCustomProps.AddMode, PageCustomProps.EditMode, PageCustomProps.Entry_Tbl, MainDataSet.Tables["main_vw"], MainDataSet.Tables["lcode_vw"], "BUTTON");
            //        txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            //    }

            //    if (GetTables.checkldcw("Category", "Cate", PageCustomProps.PcvType.Trim()) == false)
            //        cboCategoryB.Enabled = false;
            //    else
            //        cboCategoryB.Enabled = true;

            //    cboDepartMentB.Visible = GetTables.checkldcw("Department", "Dept", PageCustomProps.PcvType.Trim());

            //    if (cboDepartMentB.Visible == false)
            //    {
            //        trBnkDept.Visible = false;
            //    }
            //    else
            //    {
            //        trBnkDept.Visible = true;
            //        cboDepartMentB.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim() == "" ?
            //            "--Select Department--" : Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim();


            //    }
            //}
            //else
            //{
            //    txtAccNetAmount.Enabled = false;
            //    getTables GetTables = new getTables();
            //    cboRule.Enabled = GetTables.checkldcw("Rules", "[Rule]", PageCustomProps.PcvType.Trim());
            //    DropInvSer.Enabled = GetTables.checkldcw("Series", "Inv_Sr", PageCustomProps.PcvType.Trim());
            //    cboCategory.Enabled = GetTables.checkldcw("Category", "Cate", PageCustomProps.PcvType.Trim());
            //}

            //if (System.Convert.ToBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["l_dbcr"]) == true)
            //    LinkAcAdd.Enabled = true;
            //else
            //    LinkAcAdd.Enabled = false;


        }


        protected void grdPrintDialog_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "PrintLink")
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                DataTable RStatus_vw = (DataTable)Session["RStatusView"];
                GridViewRow PrintRow = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                GridView grdPrintDialog = ((GridView)((Control)e.CommandSource).Parent.Parent.Parent.Parent);
                string desc = grdPrintDialog.DataKeys[PrintRow.RowIndex].Values[0].ToString().Trim();
                string repName = grdPrintDialog.DataKeys[PrintRow.RowIndex].Values[1].ToString().Trim();

                string filterExp = "desc ='" + desc.Trim() + "' and rep_nm='" + repName.Trim() + "'";
                try
                {
                    DataRow rStatusRow = RStatus_vw.Select(filterExp)[0];
                    if (Convert.ToString(rStatusRow["SqlQuery"]).Trim() == "")
                        throw new Exception("Cannot run Report,Query is blank in Report Wizard Master");
                    else
                        if (Convert.ToString(rStatusRow["retTable"]).Trim() == "")
                            throw new Exception("Cannot run Report,Temp Tablename is blank in Report Wizard Master");
                        else
                            if (Convert.ToString(rStatusRow["QTable"]).Trim() == "")
                                throw new Exception("Cannot run Report,Main Tablename is blank in Report Wizard Master");

                    string repSqlStr = "";
                    if (Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("EXECUTE") >= 0)
                    {
                        string pCond1 = "";
                        string pCond2 = "";
                        repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).ToUpper().Trim().Substring(0, Convert.ToString(rStatusRow["SqlQuery"]).Trim().LastIndexOf(';') - 1);
                        pCond1 = Convert.ToString(rStatusRow["QTable"]).Trim() + ".entry_ty ='" +
                                 Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'";
                        pCond2 = Convert.ToString(rStatusRow["QTable"]).Trim() + ".tran_cd =" +
                                 Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                        repSqlStr = repSqlStr.Trim() + '"' + pCond1 + " and " + pCond2 + '"';
                    }
                    else
                    {
                        string pCond = Convert.ToString(rStatusRow["QTable"]).Trim() +
                                       ".entry_ty = '" + Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim() + "'" +
                                       " and " + Convert.ToString(rStatusRow["QTable"]).Trim() + ".tran_cd = " +
                                       Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);

                        repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).Trim();
                        int whPos = Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("WHERE");

                        if (whPos >= 0)
                        {
                            repSqlStr = repSqlStr.Trim().Substring(0, whPos + 5) + " " +
                                        pCond.Trim() + " and " + repSqlStr.Trim().Substring(whPos + 6);
                        }
                        else
                            repSqlStr = repSqlStr + " WHERE " + pCond.Trim();


                    }

                    if (repSqlStr.Trim() != "")
                    {
                        repSqlStr.Replace("REPORT HEADER", Convert.ToString(rStatusRow["desc"]).Trim());
                        Session["MainQueryString"] = repSqlStr.Trim();
                        Session["SubQueryString"] = null;
                        Session["IsSubReport"] = null;
                        Session["ReportDataSet"] = MainDataSet;
                    }

                    string strOpenWin = "";
                    strOpenWin = "open_window_max('uwCRViewer.aspx','Report');";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "openWindow()", strOpenWin, true);
                }
                catch (Exception EX)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + EX.Message.Trim().Replace("'", "\'") + "');", true);
                }

            }

        }

        //protected void btnDelete_Click(object sender, EventArgs e)
        //{
        //    // Call this event by Javascript
        //    try
        //    {
        //        DataSet MainDataSet = (DataSet)Session["MainDataSet"];
        //        boolFunction bitFunction = new boolFunction();
        //        if (bitFunction.toBoolean(MainDataSet.Tables["lcode_vw"].Rows[0]["apgenps"]) == true &&
        //            Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["apgen"]).Trim().ToUpper() == "YES")
        //        {
        //            throw new Exception("Approved Transaction cannot be deleted");
        //        }

        //        TransactionEvent.DoDelete(MainDataSet);
        //        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Transaction Deleted..!!!');", true);
        //        Response.Redirect("vuTransactionview.aspx?pcvtype="+PageCustomProps.PcvType);
        //    }
        //    catch (Exception EX)
        //    {
        //        DataAcess.RollBackTransaction(); 
        //        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + EX.Message + "');", true);
        //        return;
        //    }
        //}

        protected void btnAddCancel_Click(object sender, EventArgs e)
        {
            txtHtAcName.Text = "";
            txtHTAddAmt.Text = "0";
            tblAcAdd.Visible = false; 
        }

        protected void EditRec(Int32 tranCd,ref DataSet MainDataSet)
        {
            vuEdit editProc = new vuEdit();
            editProc.PageCustProps = PageCustomProps;
            editProc.getParentRecords(MainDataSet, tranCd);
            PageCustomProps.EditSeries = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
            PageCustomProps.EditInvoice = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            PageCustomProps.JustInvoice = "";
            PageCustomProps.JustSeries = "";

            // Below Variable use for Allocation
            isOpenGridForAllocation = false; // always false in postback is false
            vAmt = 0; // always false in postback is false
            VchrAmt = 0; // always false in postback is false
            FromAcAmt = 0; // always false in postback is false
            // End

            if (strFunction.InList(PageCustomProps.PcvType, new string[] { "OB", "OS" }) == true ||
            strFunction.InList(PageCustomProps.Behave, new string[] { "OB", "OS" }))
            {
                boolFunction bitFunction = new boolFunction();
                if (bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_choice"]) == true)
                    radDrCr.SelectedValue = "Debit";
                else
                    if (bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_choice"]) == false)
                        radDrCr.SelectedValue = "Credit";
            }


            if (tblOtherTran.Visible == true)
            {
                if (txtPartyName.Visible == true && txtPartyName.Enabled == true)
                {
                    //dropParty.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["ac_id"]).Trim();
                    txtPartyName.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim();
                    txtPartyName.Attributes.Add("Onfocus", "javascript:updateHiddenTextField('" + hiddPartyName.ClientID + "','" + txtPartyName.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboCategory.Visible == true && cboCategory.Enabled == true)
                {
                    cboCategory.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim() == "" ?
                                                "--Select Category--" :
                                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim();
                }

                if (DropInvSer.Visible == true && DropInvSer.Enabled == true)
                {
                    DropInvSer.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim() == "" ?
                                               "--Select Invoice Series--" :
                                               Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                }

                if (cboDepartMent.Visible == true && cboDepartMent.Enabled == true)
                {
                    cboDepartMent.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim() == "" ?
                                                  "--Select Department--" :
                                                  Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim();

                }

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    cboRule.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim() == "" ?
                                            "--Select Rule--" :
                                            Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim();
                }
            }

            if (tblBankTran.Visible == true)
            {
                if (txtPartyNameB.Visible == true )
                {
                    txtPartyNameB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["party_nm"]).Trim();
                    txtPartyNameB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBnkPartyName.ClientID + "','" + txtPartyNameB.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboInvSeriesB.Visible == true && cboInvSeriesB.Enabled == true)
                {
                    cboInvSeriesB.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim() == "" ?
                                                  "--Select Invoice Series--" :
                                                  Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
                }

                if (cboDepartMentB.Visible == true && cboDepartMentB.Enabled == true)
                {
                    cboDepartMentB.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim() == "" ?
                                                   "--Select Department--" :
                                                   Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["dept"]).Trim();
                }

                if (txtBankName.Visible == true )
                {
                    txtBankName.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["bank_nm"]).Trim();
                    if (strFunction.InList(PageCustomProps.PcvType,new string[] {"BR","BP"}) == true  ||
                        strFunction.InList(PageCustomProps.Behave,new string[] {"BR","BP"}) == true)
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    else
                        if (strFunction.InList(PageCustomProps.PcvType,new string[] {"CR","CP"}) == true  ||
                            strFunction.InList(PageCustomProps.Behave,new string[] {"CR","CP"}) == true)
                            txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");

                    if (trforBank.Visible == true)
                        txtDrawnOnB.Text =  Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Drawn_On"]).Trim();
                    
                }

                if (cboCategoryB.Visible == true && cboCategoryB.Enabled == true)
                {
                    cboCategoryB.SelectedValue = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim() == "" ?
                                                   "--Select Category--" :
                                                   Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["cate"]).Trim();

                }
            }

            // Called child methods in Editmode
            PageCustomProps.JustInvoice = "";
            PageCustomProps.JustSeries = "";
            editProc.PageCustProps = PageCustomProps;
            editProc.getChildRecords(MainDataSet, txtTotalQty);

            if (PageCustomProps.ChargesPage == true)
            {
                MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw");
                MainDataSet = DataAcess.ExecuteDataset(MainDataSet, "select *,space(15) as form_nm,space(15) as form_no from dcmast where 1=0", "tax_vw1");

                TransactionEvent.RefreshHeaderField(MainDataSet.Tables["company"],
                    MainDataSet.Tables["main_vw"],
                    txtGrossAmt,
                    txtdedBefTax,
                    txtTaxCharges,
                    txtTaxExAmt,
                    txtAddCharges,
                    txtTaxAmt,
                    txtNonTax,
                    txtfdisc,
                    txtRoundoff,
                    txtNetAmountTax);
            }

            if (PageCustomProps.ItemPage == true)
            {
                txtItemTotal.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"]);
                txtNetAmount.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["net_amt"]);
            }

            if (PageCustomProps.AccountPage == true)
            {
                txtAccNetAmount.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["net_amt"]);
            }

            if (trduedt.Visible == true)
            {

                txtDueDate.Text = GetDateFormat.dateformatBR(Convert.ToString(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["due_dt"])));
                string dueDays = Convert.ToString(Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["due_dt"]) - Convert.ToDateTime(MainDataSet.Tables["main_vw"].Rows[0]["date"])).Trim();
                if (dueDays.IndexOf('.') >= 0)
                    dueDays = dueDays.Substring(0, dueDays.IndexOf('.'));
                else
                    dueDays = "0";
                txtDueDays.Text = dueDays.Trim();
            }

            if (trNarration.Visible == true)
                txtNarr.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["narr"]);

            if (tblBill.Visible == true)
            {
                txtBillNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["u_pinvno"]);
                txtBillDate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["u_pinvdt"]));
            }

            PageCustomProps.EditSeries = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_sr"]).Trim();
            PageCustomProps.EditInvoice = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();

            if (tblOtherTran.Visible == true)
            {
                txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            }
            else
            {
                if (tblBankTran.Visible == true)
                    txtInvoiceNoB.Text = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["inv_no"]).Trim();
            }

            if (PageCustomProps.AinfoPage == true && tblAddInfo.Visible == true)
            {
                try
                {
                    TransactionEvent.AdditionalInfoShow(MainDataSet, tblAddInfo);
                }
                catch (Exception Ex)
                {
                   //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message  + "');", true);
                   tblAddinfoDet.Visible = false;
                   PageCustomProps.AinfoPage = false;  
                }
            }

           

            if ((PageCustomProps.PcvType == "BR" ||
                 PageCustomProps.PcvType == "BP" ||
                 PageCustomProps.PcvType == "CP" ||
                 PageCustomProps.PcvType == "CR") ||
                (PageCustomProps.Behave == "BR" ||
                 PageCustomProps.Behave == "BP" ||
                 PageCustomProps.Behave == "CP" ||
                 PageCustomProps.Behave == "CR"))
            {
                txtDateB.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                txtDateB.Focus();
            }
            else
            {

                txtdate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["date"]));
                txtdate.Focus();
            }
            //EnableDisableControls(Page, false); // Disable all controls on the Page
            //ControlShouldbeEnabled(true);

        }

        protected void InitGetTables(ref DataSet MainDataSet)
        {
            MainDataSet = new DataSet();
            getTables GetTables = new getTables();
            getCompany GetCompany = new getCompany();
            getCoAdditional GetCoAdditional = new getCoAdditional();
            try
            {
                MainDataSet = GetTables.openTables(MainDataSet, PageCustomProps.PcvType, PageCustomProps.Vchkprod);
                MainDataSet = GetCompany.Company(MainDataSet, Session["ReqCode"].ToString().Trim(), Session["Finyear"].ToString().Trim());
                MainDataSet = GetCoAdditional.CoAdditional(MainDataSet);
            }
            catch (Exception Ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Replace("'","/") + "');", true);
                return;
            }

            PageCustomProps.HowtoCalculateExAmt = GetTables.HowtoCalculateExAmt;
            PageCustomProps.Behave = GetTables.Behave.ToString().Trim();
            if (PageCustomProps.Behave == "" || PageCustomProps.Behave == null)
            {
                PageCustomProps.Behave = PageCustomProps.PcvType;
            }
            PageCustomProps.Entry_Tbl = GetTables.Entry_tbl.ToString().Trim();

            if (PageCustomProps.Vchkprod.Trim().IndexOf("vutex") > 0 &&
                (strFunction.InList(PageCustomProps.PcvType, new string[] { "DC","AR", "SS","IR", "GT" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
            {
                SqlDataReader dr;
                sqlStr = "select top 2 ware_nm from warehouse where validity like " + "%" + PageCustomProps.PcvType + "% " +
                         " and ltrim(ware_nm) != ''";
                dr = DataAcess.ExecuteDataReader(sqlStr);
                bool isRows = false;
                int isRowsEffected = 0;
                if (dr.HasRows == true)
                {
                    isRows = true;
                    isRowsEffected = dr.RecordsAffected; 
                }
                else
                    isRows = false;

                dr.Close();
                dr.Dispose();

                if (isRows == true)
                {
                    if (isRowsEffected  < 2 && PageCustomProps.PcvType == "IR")
                    {
                        throw new Exception("There should be atleast 2 warehose for this entry..");
                    }
                }
                else
                {
                    if (PageCustomProps.PcvType != "IR")
                    {
                        throw new Exception("There should be atleast 1 warehose for this entry..");
                    }
                    else
                    {
                        throw new Exception("Warehouse details not found..");
                    }
                }
            }
        }

        protected void BindDropDown(ref DataSet MainDataSet)
        {
            if (tblOtherTran.Visible == true)
            {
                vouFillDropdownList voufilldrops = new vouFillDropdownList();
                //if (dropParty.Visible == true && dropParty.Enabled == true)
                //{
                //    voufilldrops.fillDropDownList(dropParty, "--Select Party Name--", "ac_id", "ac_name", "PARTY", PageCustomProps.PcvType, PageCustomProps.Behave, MainDataSet.Tables["lcode_vw"], "ac_name,ac_id", 0,PageCustomProps.Vchkprod);
                //    dropParty.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddPartyName.ClientID + "','" + dropParty.ClientID + "',null,'--Select Party Name--');");
                //}

                if (cboCategory.Visible == true && cboCategory.Enabled == true)
                {
                    voufilldrops.fillDropDownList(cboCategory, "--Select Category--", "cate", "category", "cate", "cate", "validity like '%" + PageCustomProps.PcvType + "%'");
                }

                if (DropInvSer.Visible == true && DropInvSer.Enabled == true)
                {
                    voufilldrops.fillDropDownList(DropInvSer, "--Select Invoice Series--", "inv_sr", "inv_sr", "series", "inv_sr", "validity like '%" + PageCustomProps.PcvType + "%'");
                }

                if (cboDepartMent.Visible == true && cboDepartMent.Enabled == true)
                {
                    voufilldrops.fillDropDownList(cboDepartMent, "--Select Department--", "dept", "dept", "department", "dept", "validity like '%" + PageCustomProps.PcvType + "%'");
                }

                if (cboRule.Visible == true && cboRule.Enabled == true)
                {
                    voufilldrops.fillDropDownList(cboRule, "--Select Rule--", "rule", "rule", "Rules", "[rule]", "validity like '%" + PageCustomProps.PcvType + "%'");
                }
            }

            if (tblBankTran.Visible == true)
            {
                vouFillDropdownList voufilldrops = new vouFillDropdownList();
                if (txtPartyNameB.Visible == true && txtPartyNameB.Enabled == true)
                {
                    //voufilldrops.fillDropDownList(cboPartyNameB, "--Select Party Name--", "ac_id", "ac_name", "PARTY", PageCustomProps.PcvType, PageCustomProps.Behave,
                    //                              MainDataSet.Tables["lcode_vw"], "ac_name,ac_id", 0, PageCustomProps.Vchkprod);
                    txtPartyNameB.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBnkPartyName.ClientID + "','" + txtPartyNameB.ClientID + "',null,'Type Here for Search Party Name');");
                }

                if (cboInvSeriesB.Visible == true && cboInvSeriesB.Enabled == true)
                {
                    voufilldrops.fillDropDownList(cboInvSeriesB, "--Select Invoice Series--", "inv_sr", "inv_sr", "series", "Inv_sr", "validity like '%" + PageCustomProps.PcvType + "%'");
                }

                if (cboDepartMentB.Visible == true && cboDepartMentB.Enabled == true)
                {
                    voufilldrops.fillDropDownList(cboDepartMentB, "--Select Department--", "dept", "dept", "department", "dept", "validity like '%" + PageCustomProps.PcvType + "%'");
                }

                if (cboCategoryB.Visible == true && cboCategoryB.Enabled == true)
                {
                    voufilldrops.fillDropDownList(cboCategoryB, "--Select Category--", "dept", "dept", "department", "cate", "validity like '%" + PageCustomProps.PcvType + "%'");
                }

                if (txtBankName.Visible == true)
                {
                    if (strFunction.InList(PageCustomProps.PcvType, new string[] { "CR", "CP" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "CR", "CP" }) == true)
                    {
                        //voufilldrops.fillDropDownList(cboBankName, "--Select A/c Name--", "ac_id", "ac_name", "PARTY", PageCustomProps.PcvType, PageCustomProps.Behave, MainDataSet.Tables["lcode_vw"], "ac_name,ac_id", 0, PageCustomProps.Vchkprod);
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");
                    }
                    else
                    {
                        //voufilldrops.fillDropDownList(BankName, "--Select Bank Name--", "ac_id", "ac_name", "PARTY", PageCustomProps.PcvType, PageCustomProps.Behave, MainDataSet.Tables["lcode_vw"], "ac_name,ac_id", 0, PageCustomProps.Vchkprod);
                        txtBankName.Attributes.Add("Onfocus", "javascript:updateHiddenField('" + hiddBankName.ClientID + "','" + txtBankName.ClientID + "',null,'Type Here for Search Bank Name');");

                    }
                    
                    //if (trforBank.Visible == true) 
                    //    voufilldrops.fillDropDownList(cboDrawnOnB, "--Select Drawn On--", "Drawn_on", "Drawn_On", PageCustomProps.PcvType.Trim() + "main", "Drawn_On", " entry_ty = '" + PageCustomProps.PcvType + "'");
    
                }
            }

        }

        protected void BindGridView(ref DataSet MainDataSet,
                    ref DataView grdItemColView)
        {
            vouGridFill vouGridInit = new vouGridFill();
            if (PageCustomProps.ItemPage == true)
            {
                vouGridInit.PageCustProps = PageCustomProps;
                //DataView grdItemColView = (DataView)Session["GridItemColView"];
                if (grdItemColView == null || grdItemColView.Count <= 0)
                    grdItemColView = vouGridInit.ItemgridTemplate(MainDataSet.Tables["lother_vw"],
                                                                            MainDataSet.Tables["company"],
                                                                            MainDataSet.Tables["lcode_vw"],
                                                                            MainDataSet.Tables["item_vw"],
                                                                            Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim());

                vouGridInit.gridItemGen(GridItem, grdItemColView, MainDataSet.Tables["item_vw"]);
                Session["GridItemColView"] = grdItemColView; 
                //vouGridInit.gridItemFill(true, MainDataSet.Tables["lother_vw"], GridItem, MainDataSet.Tables["Item_vw"],
                //                         PageCustomProps.ChargesPage, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["company"], MainDataSet.Tables["lcode_vw"],PageCustomProps.PcvType,
                //                         PageCustomProps.Behave, 0);
                PageCustomProps.SalesTaxItem = vouGridInit.SalesTaxItem;
            }

            if (PageCustomProps.AccountPage == true)
                vouGridInit.gridAcccountFill(GridAccount, MainDataSet.Tables["acdet_vw"], MainDataSet.Tables["lcode_vw"]);

            if (PageCustomProps.AllocationPage == true)
            {
                vouGridInit.gridAllocation(grdlAllocDet, MainDataSet.Tables["lal_vw"], MainDataSet.Tables["acdet_vw"],
                                           MainDataSet.Tables["company"]);
                //grdlAllocDet.Columns[0].Visible = false;
                //grdlAllocDet.Columns[1].Visible = false;
            }

            if (PageCustomProps.ChargesPage == true)
                vouGridInit.gridTaxFill(grdCharges, MainDataSet.Tables["dcmast_vw"], MainDataSet.Tables["lcode_vw"],
                                        MainDataSet.Tables["tax_vw"], MainDataSet.Tables["tax_vw1"],
                                        MainDataSet.Tables["main_vw"], MainDataSet.Tables["item_vw"],
                                        MainDataSet.Tables["company"], MainDataSet.Tables["stax_vw"],
                                        PageCustomProps.EditMode, PageCustomProps.AddMode,
                                        PageCustomProps.PcvType, PageCustomProps.Behave);

        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("vutransactionview.aspx?pcvtype="+ PageCustomProps.PcvType);  
        }

        protected void txtETAcName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TextBox txtAcName = ((TextBox)sender);
                GridViewRow row = ((GridViewRow)txtAcName.NamingContainer);
                HtmlTable tblAcBal = (HtmlTable)GridAccount.Rows[row.RowIndex].FindControl("tblETAcBal");
                Label lblEtAcBalAmt = (Label)GridAccount.Rows[row.RowIndex].FindControl("lblETAccBalAmt");
                HiddenField hiddETAcBal = (HiddenField)GridAccount.Rows[row.RowIndex].FindControl("hiddETAcBal");
                DropDownList dropDrCr = (DropDownList)GridAccount.Rows[row.RowIndex].FindControl("DropETDRCR");
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];

                TransactionEvent.PageCustProps = PageCustomProps;
                TransactionEvent.dropETAcName_SelectedIndexChanged(txtAcName,
                    dropDrCr,
                    lblEtAcBalAmt,
                    MainDataSet.Tables["acdet_vw"],
                    MainDataSet.Tables["company"],
                    MainDataSet.Tables["main_vw"]);

                Session["MainDataSet"] = MainDataSet;

                if (lblEtAcBalAmt.Text != "")
                    hiddETAcBal.Value = "GET"; 

                MainDataSet.Dispose(); 
                DataAcess.Connclose(); 
            }
            catch (Exception Ex)
            {
                MessageErrorDisp(Ex);
            }
        }

        protected void GridAccount_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                boolFunction bitFunction = new boolFunction();
                HtmlTable tblAcBal = (HtmlTable)GridAccount.Rows[e.RowIndex].FindControl("tblETAcBal");
                Label lblEtAcBalAmt = (Label)GridAccount.Rows[e.RowIndex].FindControl("lblETAccBalAmt");
                DropDownList dropDrCr = (DropDownList)GridAccount.Rows[e.RowIndex].FindControl("DropETDRCR");
                DropDownList dropAcName = (DropDownList)GridAccount.Rows[e.RowIndex].FindControl("DropETAcName");
                decimal mAmt = numFunction.toDecimal(((NumericTextBox)GridAccount.Rows[e.RowIndex].FindControl("txtETAddAmt")).Text);     
                string acSerial = GridAccount.DataKeys[e.RowIndex].Value.ToString().Trim();

                vuCheckDbCrBalance CheckDbCrBalance = new vuCheckDbCrBalance();
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
  
                foreach (DataRow acDetRow in MainDataSet.Tables["acdet_vw"].Select("acserial = '" + acSerial.Trim() +"'"))
                {
                    acDetRow["ac_name"] = dropAcName.SelectedItem.ToString().Trim();
                    acDetRow["ac_id"] = dropAcName.SelectedValue;
                    acDetRow["amount"] = mAmt;
                    acDetRow["amt_ty"] = dropDrCr.SelectedValue.Trim();
                }

                string WarningMess = CheckDbCrBalance.DbCrBalanceCheck(MainDataSet.Tables["acdet_vw"], false);
                if (WarningMess != "")
                    throw new Exception(WarningMess);

                MainDataSet.Tables["acdet_vw"].AcceptChanges();

                GridAccount.EditIndex = -1;
                GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];  

                vouGridFill vouGridInit = new vouGridFill();
                GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];
                string[] grdCols = vouGridInit.grdAccountColSHide(MainDataSet.Tables["lcode_vw"]);
                vouGridInit.gridBind(GridAccount, grdCols);

                if (PageCustomProps.AllocationPage)
                {
                    grdCols = new string[2];
                    grdCols[0] = "0";
                    grdCols[1] = "";
                    grdlAllocDet.DataSource = MainDataSet.Tables["acdet_vw"];
                    vouGridInit.gridBind(grdlAllocDet, grdCols);
                }

                Session["MainDataSet"] = MainDataSet;
 
            }
            catch (Exception Ex)
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                MainDataSet.Tables["acdet_vw"].RejectChanges();
                Session["MainDataSet"] = MainDataSet;
                MessageErrorDisp(Ex);
            }
        }

        protected void GridAccount_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            MainDataSet.Tables["acdet_vw"].RejectChanges();
            Session["MainDataSet"] = MainDataSet; 

            GridAccount.EditIndex = -1;
            GridAccount.DataSource = MainDataSet.Tables["acdet_vw"];

            vouGridFill vouGridInit = new vouGridFill();
            string[] grdCols = vouGridInit.grdAccountColSHide(MainDataSet.Tables["lcode_vw"]);
            vouGridInit.gridBind(GridAccount, grdCols);
        }


        protected void grdModal()
        {
            HtmlTableRow r1 = null;
            r1 = new HtmlTableRow();
            r1.VAlign = "TOP";
        }

        protected void GenGridItemRows(DataView lotherview,
                    DataSet MainDataSet)
        {
            tblItDetails.Controls.Clear();
            tblItDetails.Rows.Clear();
            tblItDetails.Dispose();

            //DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0 &&
            (strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim()
                            , new string[] { "EXCISE", "NON-EXCISE" }) == true))
            {
                if (strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true ||
                    strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "AR", "IR", "GT", "SS" }) == true)
                {
                    vouGridFill gridFill = new vouGridFill();
                    gridFill.PageCustProps = PageCustomProps;  
                    gridFill.grdItemSettingforET(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim(),
                        lotherview,
                        lotherview.RowFilter);
                }
            }
 
            HtmlTableRow r1 = new HtmlTableRow();
            int cnt = 0;
            int viewRCount = 1;
            foreach (DataRowView xtraRow in lotherview)
            {
                if (cnt == 0)
                {
                    r1 = new HtmlTableRow(); // Create New Row
                    r1.VAlign = "Top";
                }

                r1 = cellGen("LABEL", r1, xtraRow, null, MainDataSet.Tables["lcode_vw"]);
                r1 = cellGen(Convert.ToString(xtraRow["data_ty"]).Trim().ToUpper(), r1, xtraRow, null, MainDataSet.Tables["lcode_vw"]);

                cnt = cnt + 1;
                viewRCount = viewRCount + 1;
                if (cnt == 2 || viewRCount > lotherview.Count)
                {
                    tblItDetails.Rows.Add(r1);
                    cnt = 0;
                }
            }

            r1 = new HtmlTableRow();
            HtmlTableCell cellD = new HtmlTableCell();
            r1.Controls.Add(cellD);
            cellD = new HtmlTableCell();
            Sample.Web.UI.Compatibility.ValidationSummary valItSummary = new Sample.Web.UI.Compatibility.ValidationSummary();
            //ValidationSummary valItSummary = new ValidationSummary();
            valItSummary.ShowMessageBox = true;
            valItSummary.ShowSummary = false;
            valItSummary.ValidationGroup = "valGrpITDet";
            valItSummary.DisplayMode = ValidationSummaryDisplayMode.BulletList;
            valItSummary.EnableClientScript = true; 
            cellD.Controls.Add(valItSummary);
            r1.Controls.Add(cellD);
            tblItDetails.Rows.Add(r1);
        }

        protected HtmlTableRow cellGen(string cntType,
                  HtmlTableRow htmlRow,
                  DataRowView xtraRow,
                  DataRow data_vw,
                  DataTable lcode_vw)
        {

            boolFunction bitFunction = new boolFunction();
            HtmlTableCell cellD = new HtmlTableCell();
            cellD.Align = "Left";
            cellD.VAlign = "Top";
            switch (cntType.Trim())
            {
                case "LABEL":
                    Label lblS = new Label();
                    lblS.ID = "lbl" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    if (strFunction.InList(Convert.ToString(xtraRow["data_ty"]).Trim(), new string[] { "BUTTON", "LINKBUTTON" }) == false)
                    {
                        lblS.Text = Convert.ToString(xtraRow["head_nm"]).Trim();
                    }
                    else
                        lblS.Text = "";

                    lblS.CssClass = "forms_ItemLeft5";
                    cellD.Controls.Add(lblS);
                  

                    if (Convert.ToString(xtraRow["fld_nm"]).Trim().ToUpper() == "ITEM" &&
                       Convert.ToInt32(xtraRow["dSerial"]) == 998)
                    {
                        HtmlGenericControl divHtmlItem = new HtmlGenericControl("div");
                        divHtmlItem.ID = "divItemProgress";
                        //divHtmlItem.Attributes.Add("class", "AutoCompleteXProgress");   
                        divHtmlItem.Style.Add("display", "none");
                        Image img = new Image();
                        img.ImageUrl = "~/img/smallwaitprogressbar.gif";
                        divHtmlItem.Controls.Add(img);
                        cellD.Controls.Add(divHtmlItem);
                    }
                    cellD.Align = "Right";

                    break;
                case "LINKBUTTON":
                    LinkButton lnk = new LinkButton();
                    lnk.ID = "lnk" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    lnk.Text = Convert.ToString(xtraRow["head_nm"]).Trim();
                    lnk.CssClass = "gridItLinks";
                    if (lnk.ID.Trim().ToUpper() == "LNKALLOC" &&
                        Convert.ToInt32(xtraRow["dSerial"]) == 999)
                    {
                        lnk.Click += new System.EventHandler(this.btnItemValid_Click);
                    }
                    cellD.Controls.Add(lnk);
                    break;
                case "BUTTON":
                    Button btn = new Button();
                    btn.ID = "btn" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    btn.Text = Convert.ToString(xtraRow["head_nm"]).Trim();
                    if (btn.ID.Trim().ToUpper() == "BTNEXDET" &&
                        Convert.ToInt32(xtraRow["dSerial"]) == 999)
                    {
                        btn.Click += new System.EventHandler(this.btnITExcisePostBack_Click);
                    }
                    cellD.Controls.Add(btn);
                    break; 
                case "BIT":
                    GraphicalCheckBox chkBox = new GraphicalCheckBox();
                    chkBox.ID = "chk" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    chkBox.CheckedImg = "checked.png";
                    chkBox.CheckedOverImg = "checked-over.png";
                    chkBox.CheckedDisImg = "checked-dis.gif";
                    chkBox.UncheckedDisImg = "unchecked-dis.gif";
                    chkBox.UncheckedImg = "unchecked.gif";
                    chkBox.UncheckedOverImg = "unchecked-over.gif";
                    chkBox.Style.Add("z-index", "100");

                    cellD.Controls.Add(chkBox);
                    break;
                case "DECIMAL":
                case "NUMERIC":
                    // Generate Item no. while adding item details
                    if (Convert.ToString(xtraRow["fld_nm"]).Trim().ToUpper() == "ITEM_NO" &&
                        numFunction.toInt32(xtraRow["dserial"]) == 999 &&
                        Convert.ToString(xtraRow["tag"]) == "STANDARD ITEM NO.")
                    {
                        Label lblItemNo = new Label();
                        lblItemNo.ID = "lblstd" + Convert.ToString(xtraRow["fld_nm"]).Trim(); 
                        //vuGenerateNo genItemNo = new vuGenerateNo();
                        //lblItemNo.Text = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
                        // store value in hidden field for postback
                        if (hidForItemNo.Value != "")
                            lblItemNo.Text = hidForItemNo.Value;
                        lblItemNo.Style.Add("font-weight", "bold");
                        lblItemNo.Style.Add("font-size", "12pt");
                        lblItemNo.Style.Add("color", "Blue");
                        lblItemNo.Style.Add("font-name", "verdana");
                        cellD.Controls.Add(lblItemNo);
                        break;
                    }
                    NumericTextBox numTxtBox = new NumericTextBox();
                    numTxtBox.ID = "num" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    numTxtBox.AlignStyle = "RIGHT";
                    numTxtBox.AllowMinusValue = true;
                    numTxtBox.SelectOnEntry = true;
                    numTxtBox.MaxLength = numFunction.toInt32(xtraRow["fld_wid"]);
                    numTxtBox.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                    if (cntType.Trim().ToUpper() == "DECIMAL")
                    {
                        if (numFunction.toInt32((xtraRow["fld_dec"])) > 0)
                        {
                            string formatDeci = "";
                            for (int i = 0; i < numFunction.toInt32(xtraRow["fld_dec"]); i++)
                            {
                                formatDeci += "0";
                            }
                            numTxtBox.Format = "0." + formatDeci.Trim();
                            numTxtBox.Text = "0." + formatDeci.Trim();
                        }
                        else
                        {
                            numTxtBox.Format = "0";
                            numTxtBox.Text = "0";
                        }
                    }
                    else
                    {
                        if (cntType.Trim().ToUpper() == "NUMERIC")
                        {
                            numTxtBox.Format = "0";
                            numTxtBox.Text = "0";
                        }
                    }

                    numTxtBox.CssClass = "form_textfield3";
                    numTxtBox.Width = numFunction.toInt32(xtraRow["fld_wid"]) <= 50 ? 80 : numFunction.toInt32(xtraRow["fld_wid"]);

                    //xtraSetValue<decimal> numGetDefaValueO = new xtraSetValue<decimal>();
                    //xtraSetValue<string> numGetDefaValueS = new xtraSetValue<string>();
                    //try
                    //{
                    //    if (data_vw != null)
                    //    {
                    //        if (numFunction.toDecimal(data_vw[Convert.ToString(xtraRow["fld_nm"])]) > 0)
                    //            numTxtBox.Text = Convert.ToString(numGetDefaValueO.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw));
                    //        else
                    //            numTxtBox.Text = Convert.ToString(numGetDefaValueS.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"])));
                    //    }
                    //    else
                    //        if (Convert.ToString(xtraRow["defa_val"]).Trim() != "") 
                    //            numTxtBox.Text = Convert.ToString(numGetDefaValueS.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"])));
                    //}
                    //catch (Exception Ex)
                    //{
                    //    throw new Exception(Ex.Message);
                    //}

                    cellD.Controls.Add(numTxtBox);
                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("num" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req" + Convert.ToString(xtraRow["fld_nm"]).Trim(), numTxtBox.Format));
                    }

                    if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["javaScript"]).Trim().IndexOf("function ") >= 0)
                        {
                            string funcName = Convert.ToString(xtraRow["javaScript"]).Trim().Substring(09,
                                              Convert.ToString(xtraRow["javaScript"]).Trim().IndexOf("()", 0) - 9);

                            string strJs = Convert.ToString(xtraRow["javaScript"]).Replace("\r", "\n");
                            if (!Page.IsClientScriptBlockRegistered(funcName))
                                System.Web.UI.ScriptManager.RegisterStartupScript(Page, Page.GetType(), funcName, strJs, false);

                            if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                numTxtBox.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                        funcName.Trim());
                            else
                                throw new Exception("Javascript Event cannot be empty");

                        }
                        else
                        {
                            if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                numTxtBox.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                        Convert.ToString(xtraRow["javaScript"]).Trim());
                            else
                                throw new Exception("Javascript Event cannot be empty");
                        }
                    }
                    break;
                case "TEXT":
                    Panel panel1 = new Panel();
                    panel1.ID = "Pan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    panel1.Width = 140;
                    panel1.CssClass = "CollapsePanelHeader";
                    panel1.ToolTip = "Click for Expand..";
                    Label label = new Label();
                    label.ID = "lblPan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    label.Text = "+ Show Memo Details";
                    panel1.Controls.Add(label);
                    panel1.Controls.Add(new LiteralControl("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;"));

                    Panel panel2 = new Panel();
                    panel2.ID = "Pan2" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    panel2.Width = 140;
                    panel2.Height = 50;
                    TextBox txtText = new TextBox();
                    txtText.ID = "mut" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    txtText.TextMode = TextBoxMode.MultiLine;
                    txtText.Height = 100;
                    txtText.Width = 140;
                    txtText.CssClass = "form_textfield3";

                    if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                            txtText.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                    Convert.ToString(xtraRow["javaScript"]).Trim());
                        else
                            throw new Exception("Javascript Event cannot be empty");
                    }

                    //xtraSetValue<string> textGetDefaValue = new xtraSetValue<string>();
                    //try
                    //{
                    //    if (data_vw != null)
                    //        if (Convert.ToString(data_vw[Convert.ToString(xtraRow["fld_nm"])]) != "")
                    //            txtText.Text = textGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                    //        else
                    //            txtText.Text = textGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                    //    else
                    //        txtText.Text = textGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                    //}
                    //catch (Exception Ex)
                    //{
                    //    throw new Exception(Ex.Message);
                    //}


                    panel2.Controls.Add(txtText);

                    cellD.Controls.Add(panel1);
                    cellD.Controls.Add(panel2);

                    CollapsiblePanelExtender collExtender = new CollapsiblePanelExtender();
                    collExtender.ID = "coll" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.TargetControlID = "Pan2" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.SuppressPostBack = true;
                    collExtender.CollapsedImage = "~/images/expand_blue.jpg";
                    collExtender.ExpandedImage = "~/images/collapse_blue.jpg";
                    collExtender.CollapsedText = "+ Show Memo Details";
                    collExtender.ExpandedText = "- Hide Memo Details";
                    //collExtender.ImageControlID = "Image1";
                    collExtender.TextLabelID = "lblPan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.Collapsed = true;
                    collExtender.CollapseControlID = "Pan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    collExtender.ExpandControlID = "Pan1" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    cellD.Controls.Add(collExtender);

                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("mum" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req" + Convert.ToString(xtraRow["fld_nm"]).Trim(), ""));

                    }
                    break;
                case "VARCHAR":
                    if (Convert.ToString(xtraRow["filtcond"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Substring(0, 4) != "SELE")
                        {
                            DropDownList cboList = new DropDownList();
                            cboList.ID = "cbo" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cboList.CssClass = "forms_drop";
                            cboList.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                            cboList.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                            string[] cboValue;
                            cboValue = Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Split(',');
                            for (int i = 0; i < cboValue.Length; i++)
                            {
                                cboList.Items.Insert(i, cboValue[i].ToString().Trim());
                            }
                            cboList.Items.Insert(0, "-- Select --");

                            xtraSetValue<string> varGetDefaValue = new xtraSetValue<string>();
                            try
                            {
                                string listValue = "";
                                if (data_vw != null)
                                {
                                    if (Convert.ToString(data_vw[Convert.ToString(xtraRow["fld_nm"])]) != "")
                                    {
                                        listValue = varGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                                        if (listValue == "")
                                            cboList.SelectedIndex = 0;
                                        else
                                            cboList.SelectedValue = listValue; 
                                    }
                                    else
                                        listValue = varGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                                        if (listValue == "")
                                        {   
                                            cboList.SelectedIndex = 0;
                                        }
                                        else
                                            cboList.SelectedValue =  "-- Select --";
                                }
                                else
                                {
                                    listValue = varGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                                    if (listValue == "")
                                    {   
                                        cboList.SelectedIndex = 0;
                                    }
                                    else
                                        cboList.SelectedValue =  "-- Select --";
                                }
                                                                                            
                            }
                            catch (Exception Ex)
                            {
                                throw new Exception(Ex.Message);
                            }

                            cellD.Controls.Add(cboList);

                            if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                            {
                                cellD.Controls.Add(genValidator("cbo" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req" + Convert.ToString(xtraRow["fld_nm"]).Trim(), cboList.Items[0].Text));
                            }

                            if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                            {
                                if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                    cboList.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                            Convert.ToString(xtraRow["javaScript"]).Trim());
                                else
                                    throw new Exception("Javascript Event cannot be empty");
                            }

                            ListSearchExtender lstExtender = new ListSearchExtender();
                            lstExtender.PromptPosition = ListSearchPromptPosition.Top;
                            lstExtender.PromptText = "Type to search..";
                            lstExtender.PromptCssClass = "ListSearchExtenderPrompt";
                            lstExtender.TargetControlID = "cbo" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cellD.Controls.Add(lstExtender);
                        }
                        else
                        {
                            CustDropDownList cboList = new CustDropDownList();
                            cboList.ID = "cbo" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                            cboList.CssClass = "forms_drop";
                            cboList.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                            cboList.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;

                            if (cboList.ID.Trim().ToUpper() == "CBOITEM" &&
                                    Convert.ToInt32(xtraRow["dSerial"]) == 998)
                            {
                                vouFillDropdownList voufilldrops = new vouFillDropdownList();
                                cboList.DbDataValueField = "it_code";
                                voufilldrops.fillDropDownList(cboList, "--Select Item Name--", "it_code", "it_name", "ITEM", PageCustomProps.PcvType, PageCustomProps.Behave, lcode_vw, "it_name,it_code", 0, PageCustomProps.Vchkprod);
                                DataAcess.Connclose();
                            }
                            else
                            {
                                string dataFldName = Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().Substring(6, Convert.ToString(xtraRow["filtcond"]).ToUpper().Trim().IndexOf("FROM") - 6);
                                DataTable dtDrop;
                                dtDrop = DataAcess.ExecuteDataTable(Convert.ToString(xtraRow["filtcond"]).Trim(), "tblQuery");
                                cboList.DataSource = dtDrop;
                                cboList.DataTextField = dataFldName.Trim();
                                cboList.DataValueField = dataFldName.Trim();
                                cboList.DataBind();
                                cboList.Items.Insert(0, "-- Select --");
                            }
                            cellD.Controls.Add(cboList);

                            if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == true)
                            {
                                cboList.AutoPostBack = true;
                            }

                            if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                            {
                                cellD.Controls.Add(genValidator("cbo" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req" + Convert.ToString(xtraRow["fld_nm"]).Trim(), "--Select--"));
                            }

                            if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                            {
                                if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                    cboList.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                            Convert.ToString(xtraRow["javaScript"]).Trim());
                                else
                                    throw new Exception("Javascript Event cannot be empty");
                            }

                            if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == false)
                            {
                                ListSearchExtender lstExtender = new ListSearchExtender();
                                lstExtender.PromptPosition = ListSearchPromptPosition.Top;
                                lstExtender.PromptText = "Type to search..";
                                lstExtender.PromptCssClass = "ListSearchExtenderPrompt";
                                lstExtender.TargetControlID = "cbo" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                                cellD.Controls.Add(lstExtender);
                            }
                        }
                    }
                    else
                    {
                        //Literal lt = new Literal(); uday
                        //lt.Text = "<span class=\"tt\" onmouseover=\"balloon.showTooltip(event,'load:divStock',1,300,null,'ctl00_ContentPlaceHolder1_hidBalQty')\">"; uday
                        //cellD.Controls.Add(lt);   uday
                        TextBox txtBox = new TextBox();
                        txtBox.ID = "txt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                        txtBox.MaxLength = Convert.ToInt32(xtraRow["fld_wid"]);
                        txtBox.Width = Convert.ToInt32(xtraRow["fld_wid"]) <= 50 ? 80 : Convert.ToInt32(xtraRow["fld_wid"]);
                        txtBox.CssClass = "form_textfield3";
                        txtBox.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                        //cellD.Controls.Add(txtBox); uday
                        //lt = new Literal(); uday
                        //lt.Text = "</span>"; uday
                        //cellD.Controls.Add(lt);  uday


                        

                        if (bitFunction.toBoolean(xtraRow["IsPostBack"]) == true)
                        {
                            txtBox.AutoPostBack = true;
                        }


                        if (txtBox.ID.Trim().ToUpper() == "TXTITEM" &&
                            Convert.ToInt32(xtraRow["dSerial"]) == 998)
                        {
                            txtBox.TextChanged += new System.EventHandler(this.dropItem_SelectedIndexChanged);

                            AutoCompleteExtender autoCompXItem = new AutoCompleteExtender();
                            autoCompXItem.BehaviorID = "autocompxtenderitem";
                            autoCompXItem.ServicePath = "listHelp.asmx";
                            autoCompXItem.TargetControlID = "txtItem";
                            autoCompXItem.ServiceMethod = "getList";
                            autoCompXItem.Enabled = true;
                            autoCompXItem.EnableCaching = true;
                            autoCompXItem.ContextKey = "ITEM";
                            autoCompXItem.MinimumPrefixLength = 1;
                            autoCompXItem.UseContextKey = true;
                            autoCompXItem.CompletionInterval = 1000;
                            autoCompXItem.CompletionSetCount = 20;
                            autoCompXItem.CompletionListCssClass = "autocomplete_completionListElement";
                            autoCompXItem.CompletionListItemCssClass = "autocomplete_listItem";
                            autoCompXItem.CompletionListHighlightedItemCssClass = "autocomplete_highlightedListItem";
                            autoCompXItem.OnClientPopulating = "ShowImageForItem";
                            autoCompXItem.OnClientPopulated = "HideImageForItem";

                            //autoCompXItem.CompletionListHighlightedItemCssClass="AutoCompleteExtender_CompletionList";
                            //autoCompXItem.CompletionListCssClass = "AutoCompleteExtender_HighlightedItem";
                            //autoCompXItem.CompletionListItemCssClass = "AutoCompleteExtender_CompletionListItem"; 
                            //cellD.Controls.Add(autoCompXItem); uday

                            TextBoxWatermarkExtender txtBoxWMXItName = new TextBoxWatermarkExtender();
                            txtBoxWMXItName.WatermarkCssClass = "watermarked";
                            txtBoxWMXItName.TargetControlID = "txtItem";
                            txtBoxWMXItName.WatermarkText = "Type Here for Search Item";
                            //cellD.Controls.Add(txtBoxWMXItName);  uday

                            HiddenField hidBalQty = new HiddenField();
                            hidBalQty.ID = "hidBalQty";
                            HiddenField hidDropItemTag = new HiddenField();
                            hidDropItemTag.ID = "hidDropItemTag";
                            HiddenField hidInvStk = new HiddenField();
                            hidInvStk.ID = "hidInvStk";
                            HiddenField hidNegItBal = new HiddenField();
                            hidNegItBal.ID = "hidNegItBal";
                            HiddenField hidNonStk = new HiddenField();
                            hidNonStk.ID = "hidNonStk";

                            UpdatePanel upPnlItem = new UpdatePanel();
                            upPnlItem.ChildrenAsTriggers = false;  
                            upPnlItem.UpdateMode = UpdatePanelUpdateMode.Conditional;
                            upPnlItem.ContentTemplateContainer.Controls.Add(txtBox);
                            upPnlItem.ContentTemplateContainer.Controls.Add(autoCompXItem);
                            upPnlItem.ContentTemplateContainer.Controls.Add(txtBoxWMXItName);
                            upPnlItem.ContentTemplateContainer.Controls.Add(hidBalQty);
                            upPnlItem.ContentTemplateContainer.Controls.Add(hidDropItemTag);
                            upPnlItem.ContentTemplateContainer.Controls.Add(hidInvStk);
                            upPnlItem.ContentTemplateContainer.Controls.Add(hidNegItBal);
                            upPnlItem.ContentTemplateContainer.Controls.Add(hidNonStk);


                            AsyncPostBackTrigger trig = new AsyncPostBackTrigger();
                            trig.ControlID = txtBox.ID;
                            trig.EventName = "TextChanged";
                            upPnlItem.Triggers.Add(trig);

                            //cellD.Controls.Add(hidBalQty); uday
                            //cellD.Controls.Add(hidDropItemTag); uday
                            //cellD.Controls.Add(hidInvStk); uday
                            //cellD.Controls.Add(hidNegItBal); uday
                            //cellD.Controls.Add(hidNonStk); uday

                            txtBox.Attributes.Add("onfocus", "javascript:DropItemFocus();");

                            //HtmlGenericControl divHtml = new HtmlGenericControl("div");

                            //divHtml.ID = "divStockTitle";

                            //divHtml.Style.Add("display", "none");
                            //GridView grdStock = new GridView();
                            //grdStock.ID = "grdStock";
                            //grdStock.AutoGenerateColumns = false;
                            //grdStock.AlternatingRowStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                            //grdStock.AlternatingRowStyle.ForeColor = System.Drawing.Color.Black;
                            //grdStock.EditRowStyle.BackColor = System.Drawing.Color.BlueViolet;
                            //grdStock.HeaderStyle.BackColor = System.Drawing.Color.Gainsboro;
                            //grdStock.HeaderStyle.ForeColor = System.Drawing.Color.Brown;
                            //grdStock.RowStyle.BackColor = System.Drawing.Color.Transparent;

                            //BoundField bndField = new BoundField();
                            //bndField.DataField = "it_code";
                            //bndField.HeaderText = "Item code";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "it_name";
                            //bndField.HeaderText = "Item Name";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "stockBal";
                            //bndField.HeaderText = "Phy. Stock";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "stockPoBal";
                            //bndField.HeaderText = "Open PO.";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "stockSOBal";
                            //bndField.HeaderText = "Open SO(-)";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);

                            //bndField = new BoundField();
                            //bndField.DataField = "logicalstk";
                            //bndField.HeaderText = "Logical Stock";
                            //bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                            //bndField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                            //grdStock.Columns.Add(bndField);
                            //grdStock.Font.Size = 7;
                            //grdStock.Font.Bold = true;
                            //grdStock.Width = Unit.Parse("98%");
                            //divHtml.InnerText = "Stock Details";
                            ////border-right: darkred 1px solid; border-top: darkred 1px solid; border-left: darkred 1px solid; border-bottom: darkred 1px solid; 
                            //divHtml.Attributes["Style"] = "clear: both; height:auto; text-align:center; width=98%" +
                            //    "font-weight: bold; font-size: 7pt; color: darkred; font-family: Verdana; background-color: WhiteSmoke; float: left;";



                            //divHtml.Controls.Add(grdStock);
                            //cellD.Controls.Add(divHtml);

                            if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                            {
                                if (txtBox.ID.Trim().ToUpper() == "TXTITEM" &&
                                Convert.ToInt32(xtraRow["dSerial"]) == 998)
                                {
                                    Sample.Web.UI.Compatibility.RequiredFieldValidator reqFldValidator = new Sample.Web.UI.Compatibility.RequiredFieldValidator();
                                    reqFldValidator.ID = "reqItem";
                                    reqFldValidator.ControlToValidate = txtBox.UniqueID;
                                    reqFldValidator.Display = ValidatorDisplay.Static;
                                    reqFldValidator.Text = " * ";
                                    reqFldValidator.ValidationGroup = "valGrpITDet";
                                    reqFldValidator.ErrorMessage = "Item cannot be blank..!!!";
                                    reqFldValidator.SetFocusOnError = true;
                                    reqFldValidator.Enabled = true;
                                    reqFldValidator.Visible = true;
                                    reqFldValidator.EnableViewState = true;
                                    reqFldValidator.EnableClientScript = true;
                                    //cellD.Controls.Add(reqFldValidator);  uday

                                    upPnlItem.ContentTemplateContainer.Controls.Add(reqFldValidator);
                                }
                            }

                            cellD.Controls.Add(upPnlItem);
                        }
                        else
                        {
                            cellD.Controls.Add(txtBox);
                        }

                        if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                        {
                            if (txtBox.ID.Trim().ToUpper() != "TXTITEM" &&
                               Convert.ToInt32(xtraRow["dSerial"]) != 998)
                            {
                                cellD.Controls.Add(genValidator("txt" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                             "req" + Convert.ToString(xtraRow["fld_nm"]).Trim(), ""));
                            }
                        }

                        if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                        {
                            if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                                txtBox.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                        Convert.ToString(xtraRow["javaScript"]).Trim());
                            else
                                throw new Exception("Javascript Event cannot be empty");
                        }
                    }
                    break;
                case "DATETIME":
                    TextBox txtXDate = new TextBox();
                    txtXDate.ID = "txt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    txtXDate.CssClass = "form_textfield3";
                    txtXDate.Width = 80;
                    txtXDate.Enabled = Convert.ToString(xtraRow["whn_con"]).Trim() == "" ? true : Convert.ToString(xtraRow["whn_con"]).Trim() == ".f." ? false : true;
                    getDateFormat DateFormat = new getDateFormat();
                    //xtraSetValue<DateTime> dtGetDefaValue = new xtraSetValue<DateTime>();
                    
                    //try
                    //{
                    //    if (data_vw != null)
                    //        if (DateFormat.TodateTime(data_vw[Convert.ToString(xtraRow["fld_nm"])]) > Convert.ToDateTime("01/01/1900"))
                    //            retDate = dtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]), data_vw);
                    //        else
                    //            retDate = dtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));
                    //    else
                    //        retDate = dtGetDefaValue.SetDefaultValue(xtraRow, Convert.ToString(xtraRow["fld_nm"]));

                        
                    //}
                    //catch (Exception Ex)
                    //{
                    //    throw new Exception(Ex.Message);
                    //}

                    DateTime retDate = DateTime.MinValue;
                    if (retDate == DateTime.MinValue || retDate == DateTime.MaxValue)
                    {
                        txtXDate.Text = "";
                    }
                    else
                    {
                        if (retDate > Convert.ToDateTime("01/01/1900"))
                            txtXDate.Text = DateFormat.dateformatBR(Convert.ToString(retDate).Trim());
                        else
                            txtXDate.Text = "";
                    }

                    cellD.Controls.Add(txtXDate);
                    cellD.Controls.Add(new LiteralControl("&nbsp;"));

                    if (Convert.ToString(xtraRow["javaScript"]).Trim() != "")
                    {
                        if (Convert.ToString(xtraRow["javaEvent"]).Trim() != "")
                            txtXDate.Attributes.Add(Convert.ToString(xtraRow["javaEvent"]).Trim(),
                                    Convert.ToString(xtraRow["javaScript"]).Trim());
                        else
                            throw new Exception("Javascript Event cannot be empty");
                    }

                    ImageButton imgBtnCal = new ImageButton();
                    imgBtnCal.ID = "imgBtn" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    imgBtnCal.ImageUrl = "~/images/Calendar_scheduleHS.png";
                    imgBtnCal.CausesValidation = false;
                    cellD.Controls.Add(imgBtnCal);

                    CalendarExtender calExtender = new CalendarExtender();
                    calExtender.ID = "calExt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.PopupButtonID = "imgBtn" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.TargetControlID = "txt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    calExtender.Format = "dd/MM/yyyy";
                    calExtender.PopupPosition = CalendarPosition.TopLeft;
                    //calExtender.CssClass = "CalendarExtender";
                    cellD.Controls.Add(calExtender);

                    MaskedEditExtender maskEditExtender = new MaskedEditExtender();
                    maskEditExtender.ID = "maskExt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    maskEditExtender.TargetControlID = "txt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    maskEditExtender.Mask = "99/99/9999";
                    maskEditExtender.MessageValidatorTip = true;
                    maskEditExtender.OnFocusCssClass = "MaskedEditFocus";
                    maskEditExtender.OnInvalidCssClass = "MaskedEditError";
                    maskEditExtender.MaskType = MaskedEditType.Date;
                    maskEditExtender.DisplayMoney = MaskedEditShowSymbol.Left;
                    maskEditExtender.AcceptNegative = MaskedEditShowSymbol.Left;
                    maskEditExtender.ErrorTooltipEnabled = true;
                    maskEditExtender.UserDateFormat = MaskedEditUserDateFormat.DayMonthYear;
                    cellD.Controls.Add(maskEditExtender);

                    //RegularExpressionValidator ReqFldValid = new RegularExpressionValidator();
                    Sample.Web.UI.Compatibility.RegularExpressionValidator ReqFldValid = new Sample.Web.UI.Compatibility.RegularExpressionValidator();
                    ReqFldValid.ControlToValidate = "txt" + Convert.ToString(xtraRow["fld_nm"]).Trim();
                    ReqFldValid.ValidationExpression = "(0[1-9]|(1[0-9])|(2[0-9])|(3[0-1]))/(0[1-9]|(1[0-2]))/(200[5678910]$)";
                    ReqFldValid.SetFocusOnError = true;
                    ReqFldValid.ToolTip = "Invalid Date Format";
                    ReqFldValid.Display = ValidatorDisplay.Static;
                    ReqFldValid.ErrorMessage = "Invalid Date";
                    ReqFldValid.EnableViewState = true;
                    ReqFldValid.EnableClientScript = true;
                    ReqFldValid.ValidationGroup = "valGrpITDet"; 
                    cellD.Controls.Add(ReqFldValid);
                    
                    if (bitFunction.toBoolean(xtraRow["mandatory"]) == true)
                    {
                        cellD.Controls.Add(genValidator("txt" + Convert.ToString(xtraRow["fld_nm"]).Trim(), Convert.ToString(xtraRow["head_nm"]).Trim() + " cannot be blank..!!!",
                                     "req" + Convert.ToString(xtraRow["fld_nm"]).Trim(), "__\\__\\"));

                    }

                    break;

            }
            //htmlRow.Cells.Add(cellD);
            htmlRow.Controls.Add(cellD);

            return htmlRow; 
        }

        protected RequiredFieldValidator genValidator(string cntValidate, string errMess, string Id, string initValue)
        {
            //RequiredFieldValidator reqFldValidator = new RequiredFieldValidator();
            Sample.Web.UI.Compatibility.RequiredFieldValidator reqFldValidator = new Sample.Web.UI.Compatibility.RequiredFieldValidator();
            reqFldValidator.ID = Id.Trim();
            reqFldValidator.ControlToValidate = cntValidate;
            reqFldValidator.Display = ValidatorDisplay.Static; 
            reqFldValidator.ValidationGroup = "valGrpITDet"; 
            reqFldValidator.ErrorMessage = errMess.Trim();
            reqFldValidator.SetFocusOnError = true;
            reqFldValidator.InitialValue = initValue.Trim();
            reqFldValidator.Enabled = true;
            reqFldValidator.EnableViewState = true;
            reqFldValidator.EnableClientScript = true; 
            reqFldValidator.Visible = true;
            reqFldValidator.Text = "*";
            return reqFldValidator;
        }

        protected void btnItemUpdate_Click(object sender, EventArgs e)
        {
            //if (Page.IsValid == true)
            //{
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                DataRow RetItemRow = null;
                RetItemRow = (DataRow)Session["RetItemRow"];

                //if (strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "SS" }) == true ||
                //    strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "SS" }) == true)
                //{
                //    RetItemRow = (DataRow)Session["RetItemRow"];
                //}
   
                TransactionEvent.PageCustProps = PageCustomProps;
                TransactionEvent.btnitadd_Click(MainDataSet,
                    grdCharges,
                    GridAccount,
                    GridItem,
                    grdlAllocDet,
                    tblItDetails,
                    pnlItDetails,
                    txtGrossAmt,
                    txtdedBefTax,
                    txtTaxCharges,
                    txtTaxExAmt,
                    txtAddCharges,
                    txtTaxAmt,
                    txtNonTax,
                    txtfdisc,
                    txtRoundoff,
                    txtNetAmountTax,
                    txtItemTotal,
                    txtTotalQty,
                    txtNetAmount,
                    txtAccNetAmount,
                    txtdate,
                    hidItRowItSerial,
                    ref RetItemRow);
                // Remove value of hidden field after close Item details
                hidForItemNo.Value = "";
                    
                Session["MainDataSet"] = MainDataSet;
                if (RetItemRow == null)
                    Session.Remove("RetItemRow");
                else
                    Session["RetItemRow"] = RetItemRow;
            //}

        }

        protected bool showItemListWithExcise(DataSet MainDataSet)
        {
            vuStockCheck StockCheck = new vuStockCheck();
            bool isFound = false;
            try
            {
                //DataTable curLitem = StockCheck.GenStock(0, MainDataSet.Tables["main_vw"],
                //        MainDataSet.Tables["Manufact"],
                //        MainDataSet.Tables["lcode_vw"],
                //        MainDataSet.Tables["litemall_vw"], null,
                //        PageCustomProps.VarETGoDown,
                //        PageCustomProps.Tex_exe,
                //        PageCustomProps.Tex_ExAr);

                DataTable curLitem = GenStock(0, MainDataSet.Tables["main_vw"],
                        MainDataSet.Tables["Manufact"],
                        MainDataSet.Tables["lcode_vw"],
                        MainDataSet.Tables["litemall_vw"], null,
                        PageCustomProps.VarETGoDown,
                        PageCustomProps.Tex_exe,
                        PageCustomProps.Tex_ExAr);

                string[] filterExpBal = new string[PageCustomProps.Tex_exe + 2];
                filterExpBal[0] ="SUM(balqty)";
                filterExpBal[1] ="SUM(balqty1)";
 
                int arrcnt = 1;
                for (int i=0; i < PageCustomProps.Tex_exe; i++)
                {
                    arrcnt = arrcnt + 1;
                    filterExpBal[arrcnt] = "SUM(" + PageCustomProps.Tex_ExAr[i, 2].Trim() + ")";
                }

                decimal sumTot = 0;
                DataView curview = curLitem.DefaultView;
                DataTable curFilterview = new DataTable();
                foreach (DataRow curLitemRow in curLitem.Rows)
                {
                    curview.RowFilter = "it_code = " +
                            numFunction.toInt32(curLitemRow["it_code"]);
                    curFilterview = curview.ToTable();
                    foreach (string sumstr in filterExpBal)
                    {
                        if (sumstr != null)
                        {
                            sumTot = (decimal)curFilterview.Compute(sumstr, "");
                            if (sumTot >= 0)
                            {
                                isFound = true;
                                break;
                            }
                        }
                    }
                }
                curFilterview.Dispose();  
                curview.Dispose();
                curLitem.Dispose();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            return isFound;
        }
        protected bool ETValidationForItem(DataSet MainDataSet)
        {
            boolFunction bitFunction = new boolFunction();
            if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0 &&
                strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["Rule"]).Trim().ToUpper(),
                        new string[] { "EXCISE", "NON-EXCISE" }) == true)
            {
                if ((PageCustomProps.PcvType == "AR" || PageCustomProps.Behave == "AR") ||
                    ((PageCustomProps.PcvType == "GT" || PageCustomProps.Behave == "GT") &&
                    bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false))
                {
                    if (numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]) == 0)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Consignor name cannot be blank..');", true);
                        return false;
                    }
                }

                if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                    strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "IR", "SS" })) ||
                    ((PageCustomProps.PcvType == "GT" || PageCustomProps.Behave == "GT") &&
                    bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["u_sinfo"]) == false))
                {
                    if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "GT" }) == true ||
                         strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "GT" }) == true) &&
                         (numFunction.toInt32(MainDataSet.Tables["main_vw"].Rows[0]["cons_id"]) == 0))
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Consignee name cannot be blank..');", true);
                        return false;
                    }
                    if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "IR", "SS" }) == true))
                    {
                        if (showItemListWithExcise(MainDataSet) == false)
                        {
                            string mess = (Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
                                "No Modavatable" : "NO ") + "Stock Available..., No Addition...";

                            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + mess + "');", true);
                            return false;
                        }
                    }

                }
            }
            return true;
        }

        protected void imgITNew_Click(object sender, ImageClickEventArgs e)
        {
            
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            if (ETValidationForItem(MainDataSet) == false)
                return;
            DataView grdItemColView = (DataView)Session["GridItemColView"];
            GenGridItemRows(grdItemColView,MainDataSet);

            //TextBox txtItem = ((TextBox)((Control)sender).Parent.Parent.FindControl("txtitem"));
            //NumericTextBox txtQty = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numqty"));
            //NumericTextBox txtRate = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numrate"));
            //GridView grdStock = ((GridView)((Control)sender).Parent.Parent.FindControl("grdStock"));
            //HiddenField hidbalQty = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidbalQty"));
            //HiddenField hidDropItemTag = ((HiddenField)((Control)sender).Parent.Parent.FindControl("hidDropItemTag"));
            //HtmlGenericControl divHtml = new HtmlGenericControl("div");
            //divHtml = ((HtmlGenericControl)((Control)sender).Parent.Parent.FindControl("divStockTitle"));

 
            //UpdatePanel updtPanelQty = new UpdatePanel();
            //updtPanelQty.UpdateMode = UpdatePanelUpdateMode.Conditional;
            //updtPanelQty.ChildrenAsTriggers = false;
            //updtPanelQty.ContentTemplateContainer.Controls.Add(txtQty);
            //AsyncPostBackTrigger trigger = new AsyncPostBackTrigger();
            //trigger.ControlID = txtItem.ID;
            //trigger.EventName = "TextChanged";
            //updtPanelQty.Triggers.Add(trigger);
            //form1.Controls.Add(updtPanelQty);

            //UpdatePanel updtPanelRate = new UpdatePanel();
            //updtPanelRate.UpdateMode = UpdatePanelUpdateMode.Conditional;
            //updtPanelRate.ChildrenAsTriggers = false;
            //updtPanelRate.ContentTemplateContainer.Controls.Add(txtRate);
            //trigger = new AsyncPostBackTrigger();
            //trigger.ControlID = txtItem.ID;
            //trigger.EventName = "TextChanged";
            //updtPanelRate.Triggers.Add(trigger);
            //form1.Controls.Add(updtPanelRate);

            //updtPanelItem.ContentTemplateContainer.Controls.Add(grdStock);
            //updtPanelItem.ContentTemplateContainer.Controls.Add(hidbalQty);
            //updtPanelItem.ContentTemplateContainer.Controls.Add(hidDropItemTag);
            //updtPanelItem.ContentTemplateContainer.Controls.Add(divHtml);
            //AsyncPostBackTrigger trigger = new AsyncPostBackTrigger();
            //trigger.ControlID = txtItem.ID;
            //trigger.EventName = "TextChanged";
            //updtPanelItem.Triggers.Add(trigger);
            //form1.Controls.Add(updtPanelItem);  
 
            DataTable itemvwClone = MainDataSet.Tables["item_vw"].Clone();    
            DataRow itemRowClone =  itemvwClone.NewRow();
            itemRowClone = DataNullUpdate.NullUpdate(itemRowClone);
            itemvwClone.Rows.Add(itemRowClone);   
            ItemGridEvents ItemEvents = new ItemGridEvents();
            itemRowClone = ItemEvents.addItemCharges(MainDataSet.Tables["dcmast_vw"],
                                      itemvwClone.Rows[0],
                                      MainDataSet.Tables["main_vw"],
                                      MainDataSet.Tables["lother_vw"],
                                      PageCustomProps.Vchkprod,
                                      PageCustomProps.PcvType,
                                      PageCustomProps.Behave, true);

            vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
            SetGridValue.btnClick(tblItDetails,
                        itemRowClone,
                        "UNBOXING",
                        new string[] { "item", "qty", "rate" });

            itemvwClone.Dispose(); // remove table
            
            vuGenerateNo genItemNo = new vuGenerateNo();
            Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));

            lblItemNo.Text = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
            hidForItemNo.Value = lblItemNo.Text;
            //pnlItDetails.Style.Add("display", ""); 
            divPnlItDetails.Style.Add("display", "");
            //divPnlItDetails.Visible = true;
            lblPnlItCap.Text = "New Item Details"; 
            btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");
            hidItRowItSerial.Value = "|NEW"; // store status into hidden  variable
            Session["MainDataSet"] = MainDataSet;
            itemvwClone.Dispose();
            MainDataSet.Dispose();
            TextBox txtItem = ((TextBox)((Control)sender).Parent.Parent.FindControl("txtitem"));
            ScriptManager1.SetFocus(txtItem);  
        }

        protected void imgITEdit_Click(object sender, ImageClickEventArgs e)
        {
            System.Drawing.ColorConverter colConvert = new System.Drawing.ColorConverter();
            string keyValue = "";
            bool isSelect = false;
            for (int i = 0; i < GridItem.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)GridItem.Rows[i].FindControl("chkSelect");
                if (isSelect == true && chkSelect.Checked == true)
                {
                    //pnlItDetails.Visible = false;
                    pnlItDetails.Style.Add("display", "none"); 
                    return;
                }


                if (chkSelect.Checked == true)
                {
                    keyValue += GridItem.DataKeys[i].Values[0].ToString().Trim();
                    isSelect = true;
                }
            }

            if (isSelect == false)
            {
                return; 
            }

            DataRow editRow;
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            if (ETValidationForItem(MainDataSet) == false)
                return;
            editRow = MainDataSet.Tables["item_vw"].Select("ItSerial='" + keyValue  + "'")[0];
            DataView grdItemColView = (DataView)Session["GridItemColView"];
            GenGridItemRows(grdItemColView,MainDataSet);
            Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));
            lblItemNo.Text = Convert.ToString(editRow["item_no"]).Trim();
            hidForItemNo.Value = lblItemNo.Text;
            hidItRowItSerial.Value = keyValue + "|" + "EDIT"; // Temp store Item serial in hiddenfield 
            vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
            SetGridValue.btnClick(tblItDetails, editRow, "UNBOXING",null);
            
            divPnlItDetails.Style.Add("display", ""); 
            lblPnlItCap.Text = "Edit Item Details"; 
            btnItemCancel.Attributes.Add("onclick", "javascript:return onClickItDetailsCancel();");
            
            for (int i = 0; i < GridItem.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)GridItem.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    GridItem.Rows[i].BackColor = (System.Drawing.Color)colConvert.ConvertFromString("#fafad2");
                    GridItem.Rows[i].ForeColor = (System.Drawing.Color)colConvert.ConvertFromString("Red");
                }
            }
    
        }

        protected void imgITDelete_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                TransactionEvent.PageCustProps = PageCustomProps;
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                TransactionEvent.GridItem_RowDeleting(ref MainDataSet,
                        GridItem,
                        grdCharges,
                        GridAccount,
                        grdlAllocDet,
                        txtItemTotal,
                        txtTotalQty,
                        txtNetAmount,
                        txtAccNetAmount,
                        txtGrossAmt,
                        txtdedBefTax,
                        txtTaxCharges,
                        txtTaxExAmt,
                        txtAddCharges,
                        txtTaxAmt,
                        txtNonTax,
                        txtfdisc,
                        txtRoundoff,
                        txtNetAmountTax);
                Session["MainDataSet"] = MainDataSet;
            }
            catch (Exception Ex)
            {
                DataAcess.Connclose(); 
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim() + "');", true);
                return;
            }

        }


        protected void btnExciseDetail_Click(object sender, EventArgs e)
        {
            if (PageCustomProps.Vchkprod.IndexOf("vutex") >=0) 
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                if (PageCustomProps.PcvType == "AR" || PageCustomProps.Behave == "AR")
                {
                    if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                        cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                    {
                        if (tblBill.Visible == true)
                        {
                            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvno"] = txtBillNo.Text;
                            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvdt"] = GetDateFormat.TodateTime(txtBillDate.Text);     
                            MainDataSet.Tables["main_vw"].AcceptChanges();  
                        }

                        Session["main_vw"] = MainDataSet.Tables["main_vw"];
                        Session["lcode_vw"] = MainDataSet.Tables["lcode_vw"];
                        Session["item_vw"] = MainDataSet.Tables["item_vw"];
                        Session["manu_det_vw"] = MainDataSet.Tables["manu_det_vw"];

                        string url = "uwETARHeaderDetail.aspx?AddMode=" + Convert.ToString(PageCustomProps.AddMode).Trim() + "&editMode=" +
                                    Convert.ToString(PageCustomProps.EditMode).Trim() + "&pcvType=" + Convert.ToString(PageCustomProps.PcvType).Trim() +
                                    "&beHave=" + Convert.ToString(PageCustomProps.Behave).Trim() + "&vChkProd=" + Convert.ToString(PageCustomProps.Vchkprod).Trim() +
                                    "&entryTbl=" + Convert.ToString(PageCustomProps.Entry_Tbl).Trim();

                        ScriptManager.RegisterStartupScript(this, this.GetType(), null, "OpenModalDialog('" + url + "',300,500,'" + btnHDExcisePostBack.ClientID + "');", true);
                    }
                }
                else
                {
                    if (PageCustomProps.PcvType == "DC" || PageCustomProps.Behave == "DC")
                    {
                        if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                            cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                        {
                            Session["main_vw"] = MainDataSet.Tables["main_vw"];
                            Session["lcode_vw"] = MainDataSet.Tables["lcode_vw"];

                            string url = "uwETDCHeaderDetail.aspx?AddMode=" + Convert.ToString(PageCustomProps.AddMode).Trim() + "&editMode=" +
                                        Convert.ToString(PageCustomProps.EditMode).Trim() + "&pcvType=" + Convert.ToString(PageCustomProps.PcvType).Trim() +
                                        "&beHave=" + Convert.ToString(PageCustomProps.Behave).Trim() + "&vChkProd=" + Convert.ToString(PageCustomProps.Vchkprod).Trim() +
                                        "&entryTbl=" + Convert.ToString(PageCustomProps.Entry_Tbl).Trim();

                            ScriptManager.RegisterStartupScript(this, this.GetType(), null, "OpenModalDialog('" + url + "',400,710,'" + btnHDExcisePostBack.ClientID + "');", true);
                        }

                    }
                }

            }       
        }

        protected void cboRule_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboRule.SelectedIndex == 0)
                return;

            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            MainDataSet.Tables["main_vw"].Rows[0]["rule"] = cboRule.SelectedItem.Text.ToString().Trim();
            MainDataSet.Tables["main_vw"].AcceptChanges();

            Session["MainDataSet"] = MainDataSet;

            ScriptManager1.SetFocus(cboRule);  
        }

        protected void btnHDExcisePostBack_Click(object sender, EventArgs e)
        {
            if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0)
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                if (PageCustomProps.PcvType == "AR" || PageCustomProps.Behave == "AR")
                {
                    MainDataSet.Tables.Remove("main_vw");
                    MainDataSet.Tables.Remove("manu_det_vw");
                    MainDataSet.Tables.Add((DataTable)Session["main_vw"]);
                    MainDataSet.Tables.Add((DataTable)Session["manu_det_vw"]);

                    Session.Remove("main_vw");
                    Session.Remove("manu_det_vw");

                    Session["MainDataSet"] = MainDataSet;        

                }
                else
                {
                    if (PageCustomProps.PcvType == "DC" || PageCustomProps.Behave == "DC")
                    {
                        MainDataSet.Tables.Remove("main_vw");
                        MainDataSet.Tables.Add((DataTable)Session["main_vw"]);
                        Session.Remove("main_vw");

                        Session["MainDataSet"] = MainDataSet;
                    }
                }
            }
        }


        protected void btnITExcisePostBack_Click(object sender, EventArgs e)
        {
            if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0)
            {
                if (PageCustomProps.PcvType == "AR" || PageCustomProps.Behave == "AR")
                {
                    if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                        cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                    {
                        DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                        DataRow RetItemRow = (DataRow)Session["RetItemRow"];
                        DataTable itemvwClone = MainDataSet.Tables["item_vw"].Clone();
                        DataRow itemRowClone = null;
                        if (hidItRowItSerial.Value.ToString().Substring(hidItRowItSerial.Value.ToString().Trim().IndexOf('|') + 1, 3) == "NEW")
                        {
                            if (RetItemRow == null)
                            {
                                vuGenerateNo genItemNo = new vuGenerateNo();
                                getNullUpdate DataNullUpdate = new getNullUpdate();

                                string itSerialvar = "";
                                itemRowClone = itemvwClone.NewRow();
                                itemRowClone = DataNullUpdate.NullUpdate(itemRowClone);
                                itemRowClone["entry_ty"] = PageCustomProps.PcvType.Trim();
                                itemRowClone["doc_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim();
                                itemRowClone["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                                itemRowClone["pmKey"] = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["inv_stk"]).Trim();
                                itemRowClone["Item_no"] = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
                                itSerialvar = genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "itSerial", true, 5);
                                itemRowClone["ItSerial"] = itSerialvar;
                                itemRowClone["Date"] = GetDateFormat.TodateTime(txtdate.Text);

                                vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                                readDynamicTbl.btnClick(tblItDetails, itemRowClone, "BOXING", null);
                                itemvwClone.Rows.Add(itemRowClone);

                            }
                            else
                            {

                                itemRowClone = itemvwClone.NewRow();
                                itemRowClone = DataAcess.ExactScatterGatherRow(RetItemRow, itemRowClone);

                                vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                                readDynamicTbl.btnClick(tblItDetails, itemRowClone, "BOXING", null);
                                itemvwClone.Rows.Add(itemRowClone);

                            }
                        }
                        else
                        {
                            if (hidItRowItSerial.Value.ToString().Substring(hidItRowItSerial.Value.ToString().Trim().IndexOf('|') + 1, 4) == "EDIT")
                            {
                                string itSerial = hidItRowItSerial.Value.ToString().Substring(0, hidItRowItSerial.Value.ToString().Trim().IndexOf('|'));
                                DataRow itRowExist = MainDataSet.Tables["item_vw"].Select("itserial ='" + itSerial + "'")[0];
                                itemRowClone = itemvwClone.NewRow();
                                itemRowClone = DataAcess.ExactScatterGatherRow(itRowExist, itemRowClone);

                                vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                                readDynamicTbl.btnClick(tblItDetails, itemRowClone, "BOXING", null);
                                itemvwClone.Rows.Add(itemRowClone);

                             }
                        }

                        Session["main_vw"] = MainDataSet.Tables["main_vw"];
                        Session["lcode_vw"] = MainDataSet.Tables["lcode_vw"];
                        Session["item_vw"] = itemvwClone;
                        Session["manu_det_vw"] = MainDataSet.Tables["manu_det_vw"];
                        Session["company"] = MainDataSet.Tables["company"];

                        string itemNo = Convert.ToString(itemRowClone["Item_no"]).Trim();
                        string url = "uwETARItemDetail.aspx?AddMode=" + Convert.ToString(PageCustomProps.AddMode).Trim() + "&editMode=" +
                                    Convert.ToString(PageCustomProps.EditMode).Trim() + "&pcvType=" + Convert.ToString(PageCustomProps.PcvType).Trim() +
                                    "&beHave=" + Convert.ToString(PageCustomProps.Behave).Trim() + "&vChkProd=" + Convert.ToString(PageCustomProps.Vchkprod).Trim() +
                                    "&entryTbl=" + Convert.ToString(PageCustomProps.Entry_Tbl).Trim() + "&rowPos=" + itemNo;

                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',550,675,'" + btnHDITDetailExcisePostBack.ClientID + "');", true);
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',490,640,'Test');", true);
                    }
                }
                else
                {
                    if (strFunction.InList(PageCustomProps.PcvType,new string[]{"DC","SS"}) == true || 
                        strFunction.InList(PageCustomProps.Behave,new string[]{"DC","SS"}) == true)
                    {
                        if (cboRule.SelectedValue.ToString().Trim() == "EXCISE" ||
                            cboRule.SelectedValue.ToString().Trim() == "NON-EXCISE")
                        {
                            DataRow RetItemRow = (DataRow)Session["RetItemRow"];
                            if (RetItemRow !=null)
                                ETItGridExciseDetails(RetItemRow);
                        }
                    }
                }
            }            
        }

        protected void ETItGridExciseDetails(DataRow itemRow)
        {
            boolFunction bitFunction = new boolFunction();
            sqlStr = "select * from dcmast where entry_ty='AR' and code ='E' " +
                     " and att_file=0";

            DataTable ExcDcMast_vw = DataAcess.ExecuteDataTable(sqlStr, "_ss");
            sqlStr = "select * from dcmast where 1=0";

            DataTable tax_sh_vw = DataAcess.ExecuteDataTable(sqlStr, "_tax_sh_vw");
            DataTable tax_sh_vw1 = DataAcess.ExecuteDataTable(sqlStr, "_tax_sh_vw1");
            DataRow DiscRow = null;
            foreach (DataRow ExcDcMastRows in ExcDcMast_vw.Rows)
            {
                DiscRow = tax_sh_vw.NewRow();
                DiscRow = DataAcess.ExactScatterGatherRow(ExcDcMastRows,
                    DiscRow);

                DiscRow["def_pert"] = Convert.ToString(DiscRow["pert_name"]).Trim() != "" ?
                    numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["pert_name"]).Trim()]) :
                    numFunction.toDecimal(DiscRow["def_pert"]);
                DiscRow["def_amt"] = numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["fld_nm"]).Trim()]);
                DiscRow["excl_net"] = bitFunction.toBoolean(DiscRow["att_file"]) == false && Convert.ToString(DiscRow["code"]).Trim() == "E" ?
                    "E" : Convert.ToString(DiscRow["excl_net"]);

                tax_sh_vw.Rows.Add(DiscRow);   
            }

            tax_sh_vw.AcceptChanges();
 
            if (PageCustomProps.AddMode == true ||
                PageCustomProps.EditMode == true)
            {
                foreach (DataRow taxShVwRow in tax_sh_vw.Rows)
                {
                    DiscRow = tax_sh_vw1.NewRow();
                    DiscRow = DataAcess.ExactScatterGatherRow(taxShVwRow,
                                DiscRow);

                    if (itemRow.Table.Columns[Convert.ToString(DiscRow["fld_nm"]).Trim()]
                        .DataType.ToString().Trim().ToUpper() != "SYSTEM.DECIMAL")
                        continue;

                    DiscRow["def_pert"] = Convert.ToString(DiscRow["pert_name"]).Trim() != "" ?
                        numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["pert_name"]).Trim()]) :
                        numFunction.toDecimal(DiscRow["def_pert"]);
                    DiscRow["def_amt"] = Convert.ToString(DiscRow["fld_nm"]).Trim() != "" ?
                        numFunction.toDecimal(itemRow[Convert.ToString(DiscRow["fld_nm"]).Trim()]) :
                        numFunction.toDecimal(DiscRow["def_amt"]);

                    tax_sh_vw1.Rows.Add(DiscRow);   
                }
            }


            
            grdETItDetailDC.DataSource = tax_sh_vw1;
            grdETItDetailDC.DataBind();
            DataAcess.Connclose();
            tax_sh_vw1.Dispose();
            tax_sh_vw.Dispose();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "PanelShow('ctl00_ContentPlaceHolder1_btnexdet','" + pnlETItDetailDC.ClientID + "');", true);
        }

        protected void btnHDITDetailExcisePostBack_Click(object sender, EventArgs e)
        {   
            if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0)
            {
                if (PageCustomProps.PcvType == "AR" || PageCustomProps.Behave == "AR")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('reach in btnHDITDetailExcisePostBack');", true);

                    DataSet MainDataSet = (DataSet)Session["MainDataSet"];

                    MainDataSet.Tables.Remove("main_vw");
                    MainDataSet.Tables.Remove("manu_det_vw");
                    MainDataSet.Tables.Add((DataTable)Session["main_vw"]);
                    MainDataSet.Tables.Add((DataTable)Session["manu_det_vw"]);
                    Session["RetItemRow"] = Session["itemRow"];
                    DataRow RetItemRow = (DataRow)Session["RetItemRow"];

                    Session.Remove("main_vw");
                    Session.Remove("manu_det_vw");
                    Session.Remove("itemRow");

                    Session["MainDataSet"] = MainDataSet;

                    Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));
                    lblItemNo.Text = Convert.ToString(RetItemRow["item_no"]).Trim();
                    hidForItemNo.Value = lblItemNo.Text;

                    vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
                    SetGridValue.btnClick(tblItDetails,
                                RetItemRow,
                                "UNBOXING",
                                new string[] { "item", "qty", "rate" });
                    Session["RetItemRow"] = RetItemRow;

                    //UpdatePanel16.Update();  
                }
                else
                {
                    if (strFunction.InList(PageCustomProps.PcvType,new string[] {"DC","SS"}) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "SS" }) == true)
                    {
                        DataSet MainDataSet = (DataSet)Session["MainDataSet"];

                        MainDataSet.Tables.Remove("main_vw");
                        MainDataSet.Tables.Remove("litemall_vw");
                        MainDataSet.Tables.Add((DataTable)Session["main_vw"]);
                        MainDataSet.Tables.Add((DataTable)Session["litemall_vw"]);
                        Session["RetItemRow"] = Session["itemRow"];
                        DataRow RetItemRow = (DataRow)Session["itemRow"];

                        Session.Remove("main_vw");
                        Session.Remove("manu_det_vw");
                        Session.Remove("litemall_vw");
                        Session.Remove("CoAdditional");
                        Session.Remove("Tex_ExAr");
                        Session.Remove("ToShow");
                        Session.Remove("itemRow"); 
                        Session["MainDataSet"] = MainDataSet;

                        Label lblItemNo = ((Label)tblItDetails.FindControl("lblstditem_no"));
                        lblItemNo.Text = Convert.ToString(RetItemRow["item_no"]).Trim();
                        hidForItemNo.Value = lblItemNo.Text;

                        vuAdditionalInfo SetGridValue = new vuAdditionalInfo();
                        SetGridValue.btnClick(tblItDetails,
                                    RetItemRow,
                                    "UNBOXING",
                                    new string[] { "item"});

                        Session["RetItemRow"] = RetItemRow;

                       // UpdatePanel16.Update();  
                    }
                }
            }

            Button btnExciseDet = ((Button)tblItDetails.FindControl("BTNEXDET"));
            ScriptManager1.SetFocus(btnExciseDet);
            btnExciseDet.Dispose();  
        }


        protected void btnPickup_Click(object sender, EventArgs e)
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            Session["company"] = MainDataSet.Tables["company"];
            string url = "ELFERPTranPickup.aspx?pcvType=" + Convert.ToString(PageCustomProps.PcvType);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',500,650,'" + btnAfterPickup.ClientID + "');", true);
        }

        protected void btnAfterPickup_Click(object sender, EventArgs e)
        {
            DataRow mainRow = (DataRow)Session["MainRow"];
            DataTable ItemView = (DataTable)Session["ItemView"];

            DataSet MainDataSet = (DataSet)Session["MainDataSet"];

            MainDataSet.Tables["main_vw"].Rows[0]["date"] = GetDateFormat.TodateTime(mainRow["trandate"]);
            MainDataSet.Tables["main_vw"].Rows[0]["inv_no"] = Convert.ToString(mainRow["tranno"]);
            if (PageCustomProps.PcvType == "AR") 
                MainDataSet.Tables["main_vw"].Rows[0]["party_nm"] = Convert.ToString(mainRow["supplier"]);
            else
                if (PageCustomProps.PcvType == "DC")
                {
                    MainDataSet.Tables["main_vw"].Rows[0]["party_nm"] = Convert.ToString(mainRow["customer"]);
                }

            MainDataSet.Tables["main_vw"].Rows[0]["ac_id"] = numFunction.toInt32(mainRow["ac_id"]);  
            MainDataSet.Tables["main_vw"].Rows[0]["rule"] = "EXCISE";
            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvno"] = Convert.ToString(mainRow["suppinvno"]).Trim();
            MainDataSet.Tables["main_vw"].Rows[0]["u_pinvdt"] = GetDateFormat.TodateTime(mainRow["suppinvdt"]);
            MainDataSet.Tables["main_vw"].Rows[0]["gro_amt"] = numFunction.toDecimal(mainRow["tranamount"],2);

            vuGenerateNo genItemNo = new vuGenerateNo();
            ItemGridEvents ItemEvents = new ItemGridEvents();
            DataRow ItemRow = null;
            foreach (DataRow ItemViewRow in ItemView.Rows)
            {
                ItemRow = MainDataSet.Tables["item_vw"].NewRow();
                ItemRow["Entry_ty"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["entry_ty"]).Trim();
                ItemRow["date"] = GetDateFormat.TodateTime(mainRow["trandate"]);
                ItemRow["doc_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim();
                ItemRow["inv_no"] = Convert.ToString(mainRow["tranno"]).Trim();
                ItemRow["ac_id"] = numFunction.toInt32(mainRow["ac_id"]);
                if (PageCustomProps.PcvType == "AR") 
                    ItemRow["party_nm"] = Convert.ToString(mainRow["supplier"]).Trim();
                else
                    if (PageCustomProps.PcvType == "DC")
                        ItemRow["party_nm"] = Convert.ToString(mainRow["customer"]).Trim();

                //ItemRow["rule"] = "EXCISE";
                string itNo = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));

                ItemRow["it_code"] = numFunction.toInt32(ItemViewRow["it_code"]);
                ItemRow["Item_no"] = itNo.Trim();
                ItemRow["Itserial"] = itNo.Trim().PadLeft(5, '0');
                ItemRow["item"] = Convert.ToString(ItemViewRow["itemcode"]).Trim();
                ItemRow["qty"] = numFunction.toDecimal(ItemViewRow["qty"],2);
                ItemRow["rate"] = 0;
                ItemRow["U_xRate"] = numFunction.toDecimal(ItemViewRow["rate"]);
                ItemRow["gro_amt"] = numFunction.toDecimal(ItemViewRow["lineamount"],2);
                ItemRow["ware_nm"] = Convert.ToString(ItemViewRow["warehousecode"]).Trim();
                MainDataSet.Tables["item_vw"].Rows.Add(ItemRow);

                ItemRow = ItemEvents.addItemCharges(MainDataSet.Tables["dcmast_vw"],
                                        ItemRow,
                                        MainDataSet.Tables["main_vw"],
                                        MainDataSet.Tables["lother_vw"],
                                        PageCustomProps.Vchkprod,
                                        PageCustomProps.PcvType,
                                        PageCustomProps.Behave,false);

                MainDataSet.Tables["item_vw"].AcceptChanges(); 
            }

            MainDataSet.Tables["main_vw"].AcceptChanges();

            // Binding Header Details
            txtdate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["date"]));
            if (txtdate.Text != "")
            {
                TransactionEvent.PageCustProps = PageCustomProps; 
                TransactionEvent.DateValidation(txtdate,
                    null,
                    null,
                    trduedt,
                    this.Page,
                    hidDateValid,
                    MainDataSet.Tables["main_vw"],
                    MainDataSet.Tables["Company"],
                    MainDataSet.Tables["lcode_vw"],
                    MainDataSet.Tables["item_vw"],
                    MainDataSet.Tables["acdet_vw"],
                    true);
            }
            txtdate.Focus();

            txtInvNo.Text = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["inv_no"]);
            //dropParty.SelectedValue = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["ac_id"]);
            txtPartyName.Text = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["party_nm"]); 
            cboRule.SelectedValue = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["rule"]);
            txtBillNo.Text = Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["u_pinvno"]);
            txtBillDate.Text = GetDateFormat.dateformatBR(Convert.ToString(MainDataSet.Tables["main_Vw"].Rows[0]["u_pinvdt"]));

            // Binding Item Details
            vouGridFill gridDe = new vouGridFill();
            GridItem.DataSource = MainDataSet.Tables["item_vw"];

            Session["MainDataSet"] = MainDataSet;

            gridDe.gridBind(GridItem, null);

       }

        protected void btnItemValid_Click(object sender, EventArgs e)
        {
            if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0)
            {
                DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                boolFunction bitFunction = new boolFunction();
                if (strFunction.InList(Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper(),
                    new string[] { "EXCISE", "NON-EXCISE" }) == true &&
                    (strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true ||
                    strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "AR", "SS", "IR", "GT" }) == true))
                {
                    if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "IR", "SS" }) == true) ||
                        ((PageCustomProps.PcvType == "GT" || PageCustomProps.Behave == "GT") &&
                          bitFunction.toBoolean(MainDataSet.Tables["main_vw"].Rows[0]["U_sinfo"]) == true))
                    {

                        NumericTextBox txtQty = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numqty"));
                        bool isFound = false;
                        string[] doWhat = hidItRowItSerial.Value.Split('|');
                        if (doWhat[1].ToString().Trim() == "EDIT")
                        {
                            string filterExp = "entry_ty='" + PageCustomProps.PcvType.Trim() + "' and " +
                                " tran_cd = " + Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]) +
                                " and itserial='" + doWhat[0].ToString().Trim() + "'";
                            try
                            {
                                DataRow litemAllRow = MainDataSet.Tables["litemall_vw"].Select(filterExp)[0];
                                isFound = true;
                            }
                            catch { isFound = false;}
                        }

                        if (numFunction.toDecimal(txtQty.Text) == 0 || isFound == false)
                        {
                            if (bitFunction.toBoolean(MainDataSet.Tables["Manufact"].Rows[0]["ET_FLAG"]) == true ||
                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                            {
                                PageCustomProps.VarETGoDown = "";
                            }

                            if (bitFunction.toBoolean(MainDataSet.Tables["Manufact"].Rows[0]["NET_FLAG"]) == true ||
                                Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                            {
                                PageCustomProps.VarETGoDown = "";
                            }

                            //string[] doWhat = hidItRowItSerial.Value.Split('|');
                            vuGenerateNo genItemNo = new vuGenerateNo();
                            
                            DataRow Item_Row = null;
                            if (doWhat[1].ToString().Trim() == "NEW")
                            {
                                Item_Row = MainDataSet.Tables["item_vw"].NewRow();
                                Item_Row = DataNullUpdate.NullUpdate(Item_Row);
                                Item_Row["entry_ty"] = PageCustomProps.PcvType.Trim();
                                Item_Row["doc_no"] = Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["doc_no"]).Trim();
                                Item_Row["tran_cd"] = Convert.ToInt32(MainDataSet.Tables["main_vw"].Rows[0]["tran_cd"]);
                                Item_Row["pmKey"] = Convert.ToString(MainDataSet.Tables["lcode_vw"].Rows[0]["inv_stk"]).Trim();
                                Item_Row["Item_no"] = Convert.ToString(genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "item_no", false, 0));
                                Item_Row["ItSerial"] = genItemNo.GenerateNo(MainDataSet.Tables["item_vw"], "itSerial", true, 5);
                                Item_Row["Date"] = GetDateFormat.TodateTime(txtdate.Text);
                            }
                            else
                            {
                                if (doWhat[1].ToString().Trim() == "EDIT")
                                {
                                    Item_Row = MainDataSet.Tables["item_vw"].Select("ItSerial = '" + doWhat[0].ToString().Trim() + "'")[0];
                                }
                            }

                             // Retrive data from dynamic columns to item_vw
                            vuAdditionalInfo readDynamicTbl = new vuAdditionalInfo();
                            readDynamicTbl.btnClick(tblItDetails, Item_Row,"BOXING",null);
                            eTradingSelectQty(Item_Row,
                                            MainDataSet.Tables["main_vw"],
                                            MainDataSet.Tables["lcode_vw"],
                                            MainDataSet.Tables["Manufact"],
                                            MainDataSet.Tables["litemall_vw"],
                                            MainDataSet.Tables["company"]);
                        }
                    }
                }
            }

        }

        protected void eTradingSelectQty(DataRow itemRow,
        DataTable main_vw,
        DataTable lcode_vw,
        DataTable coAdditional,
        DataTable litemall_vw,
        DataTable company)
        {
            if (PageCustomProps.AddMode == true || PageCustomProps.EditMode == true)
            {
                if (strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                    strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "IR", "SS" }) == true)
                {
                    vuStockCheck StockEvents = new vuStockCheck();
                    DataTable CurLitem1 = StockEvents.GenStock(numFunction.toInt32(itemRow["it_code"]),
                                                    main_vw,
                                                    coAdditional,
                                                    lcode_vw,
                                                    litemall_vw,
                                                    itemRow,
                                                    PageCustomProps.VarETGoDown,
                                                    PageCustomProps.Tex_exe,
                                                    PageCustomProps.Tex_ExAr);

                    DataTable ToShow = new DataTable();

                    DataColumn ToShowCol = null;

                    GenCol(ToShowCol, "System.Boolean", "ToCheck", ToShow);
                    GenCol(ToShowCol, "System.String", "Inv_no", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "Date", ToShow);
                    GenCol(ToShowCol, "System.String", "SuppName", ToShow);
                    GenCol(ToShowCol, "System.String", "SuppLoc", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Suppac_id", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Suppsac_id", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "Excbal", ToShow);

                    string fldname = "";
                    for (int tex_exs = 0; tex_exs < PageCustomProps.Tex_exe; tex_exs++)
                    {
                        fldname = "";
                        fldname = PageCustomProps.Tex_ExAr[tex_exs, 2].ToString().Trim();
                        if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                        {
                            GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                        }

                        fldname = "";
                        fldname = PageCustomProps.Tex_ExAr[tex_exs, 3].ToString().Trim();
                        if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                        {
                            GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                        }
                    }

                    GenCol(ToShowCol, "System.String", "u_pinvno", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "u_pinvdt", ToShow);
                    GenCol(ToShowCol, "System.String", "pu_pinvno", ToShow);
                    GenCol(ToShowCol, "System.String", "ware_nm", ToShow);
                    GenCol(ToShowCol, "System.String", "manuname", ToShow);
                    GenCol(ToShowCol, "System.String", "manuloc", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Manuac_id", ToShow);
                    GenCol(ToShowCol, "System.Int32", "Manusac_id", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "pu_pinvdt", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "balqty", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "alloqty", ToShow);
                    GenCol(ToShowCol, "System.String", "rgpage", ToShow);
                    GenCol(ToShowCol, "System.Decimal", "mtduty", ToShow);
                    GenCol(ToShowCol, "System.String", "entry_ty", ToShow);
                    GenCol(ToShowCol, "System.String", "item_no", ToShow);
                    GenCol(ToShowCol, "System.Int32", "tran_cd", ToShow);
                    GenCol(ToShowCol, "System.String", "itserial", ToShow);
                    GenCol(ToShowCol, "System.String", "pinv_no", ToShow);
                    GenCol(ToShowCol, "System.DateTime", "pdate", ToShow);
                    GenCol(ToShowCol, "System.String", "pentry_ty", ToShow);
                    GenCol(ToShowCol, "System.String", "pitem_no", ToShow);
                    GenCol(ToShowCol, "System.Int32", "ptran_cd", ToShow);
                    GenCol(ToShowCol, "System.String", "pitserial", ToShow);
                    GenCol(ToShowCol, "System.Int32", "sentno", ToShow);
                    GenCol(ToShowCol, "System.String", "spageno", ToShow);

                    foreach (DataRow curLitemRow in CurLitem1.Rows)
                    {
                        DataRow ToShowRow = ToShow.NewRow();
                        ToShowRow["ToCheck"] = false;
                        ToShowRow["Inv_no"] = Convert.ToString(curLitemRow["u_pinvno"]).Trim();
                        ToShowRow["Date"] = GetDateFormat.TodateTime(curLitemRow["date"]);
                        ToShowRow["Suppname"] = Convert.ToString(curLitemRow["Suppname"]).Trim();
                        ToShowRow["Supploc"] = Convert.ToString(curLitemRow["Supploc"]).Trim();
                        ToShowRow["Suppac_id"] = numFunction.toInt32(curLitemRow["cons_id"]);
                        ToShowRow["Suppsac_id"] = numFunction.toInt32(curLitemRow["Scons_id"]);

                        for (int tex_exs = 0; tex_exs < PageCustomProps.Tex_exe; tex_exs++)
                        {
                            ToShowRow[PageCustomProps.Tex_ExAr[tex_exs, 2]] =
                                        numFunction.toDecimal(curLitemRow[PageCustomProps.Tex_ExAr[tex_exs, 2]]);
                        }
                        ToShowRow["balqty"] = numFunction.toDecimal(curLitemRow["balqty"]);
                        ToShowRow["rgpage"] = Convert.ToString(curLitemRow["rgpage"]).Trim();
                        ToShowRow["mtduty"] = numFunction.toDecimal(curLitemRow["mtduty"]);
                        ToShowRow["entry_ty"] = Convert.ToString(curLitemRow["entry_ty"]).Trim();
                        ToShowRow["tran_cd"] = numFunction.toInt32(curLitemRow["tran_cd"]);
                        ToShowRow["itserial"] = Convert.ToString(curLitemRow["itserial"]).Trim();
                        ToShowRow["u_pinvno"] = Convert.ToString(curLitemRow["u_pinvno"]).Trim();
                        ToShowRow["u_pinvdt"] = GetDateFormat.TodateTime(curLitemRow["u_pinvdt"]);
                        ToShowRow["Ware_nm"] = Convert.ToString(curLitemRow["Ware_nm"]).Trim();
                        ToShowRow["ManuName"] = Convert.ToString(curLitemRow["ManuName"]).Trim();
                        ToShowRow["ManuLoc"] = Convert.ToString(curLitemRow["ManuLoc"]).Trim();
                        ToShowRow["Manuac_id"] = numFunction.toInt32(curLitemRow["Manuac_id"]);
                        ToShowRow["Manusac_id"] = numFunction.toInt32(curLitemRow["Manusac_id"]);
                        ToShow.Rows.Add(ToShowRow);
                        ToShow.AcceptChanges();
                    }
                    
                    if (strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "SS" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "SS" }) == true)
                    {
                        string url = "uwETDCItemDetail.aspx?Tex_exe=" + PageCustomProps.Tex_exe +
                                    "?VarETGoDown=" + PageCustomProps.VarETGoDown +
                                    "?VarETGodownTo=" + PageCustomProps.VarETGodownTo;

                        Session["ToShow"] = ToShow;
                        Session["main_vw"] = main_vw;
                        Session["itemRow"] = itemRow;
                        Session["Company"] = company;
                        Session["CoAdditional"] = coAdditional;
                        Session["Tex_ExAr"] = PageCustomProps.Tex_ExAr;
                        Session["litemall_vw"] = litemall_vw;

                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',500,750,'" + btnHDITDetailExcisePostBack.ClientID + "');", true);
                    }

                }
                else
                {
                    boolFunction bitFunction = new boolFunction();
                    if ((PageCustomProps.PcvType == "GT" || PageCustomProps.Behave == "GT") &&
                        bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == true)
                    {
                        vuStockCheck StockEvents = new vuStockCheck();
                        DataTable CurLitem1 = StockEvents.GenSRStock(numFunction.toInt32(itemRow["it_code"]),
                                                        main_vw,
                                                        coAdditional,
                                                        lcode_vw,
                                                        litemall_vw,
                                                        itemRow,
                                                        PageCustomProps.VarETGoDown,
                                                        PageCustomProps.Tex_exe,
                                                        PageCustomProps.Tex_ExAr);

                        DataTable ToShow = new DataTable();

                        DataColumn ToShowCol = null;

                        GenCol(ToShowCol, "System.Boolean", "ToCheck", ToShow);
                        GenCol(ToShowCol, "System.String", "Inv_no", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "Date", ToShow);
                        GenCol(ToShowCol, "System.String", "SuppName", ToShow);
                        GenCol(ToShowCol, "System.String", "SuppLoc", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Suppac_id", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Suppsac_id", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "Excbal", ToShow);

                        string fldname = "";
                        for (int tex_exs = 0; tex_exs < PageCustomProps.Tex_exe; tex_exs++)
                        {
                            fldname = "";
                            fldname = PageCustomProps.Tex_ExAr[tex_exs, 2].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                            }

                            fldname = "";
                            fldname = PageCustomProps.Tex_ExAr[tex_exs, 3].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(ToShowCol, "System.Decimal", fldname.Trim(), ToShow);
                            }
                        }

                        GenCol(ToShowCol, "System.String", "u_pinvno", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "u_pinvdt", ToShow);
                        GenCol(ToShowCol, "System.String", "pu_pinvno", ToShow);
                        GenCol(ToShowCol, "System.String", "ware_nm", ToShow);
                        GenCol(ToShowCol, "System.String", "manuname", ToShow);
                        GenCol(ToShowCol, "System.String", "manuloc", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Manuac_id", ToShow);
                        GenCol(ToShowCol, "System.Int32", "Manusac_id", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "pu_pinvdt", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "balqty", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "alloqty", ToShow);
                        GenCol(ToShowCol, "System.String", "rgpage", ToShow);
                        GenCol(ToShowCol, "System.Decimal", "mtduty", ToShow);
                        GenCol(ToShowCol, "System.String", "entry_ty", ToShow);
                        GenCol(ToShowCol, "System.String", "item_no", ToShow);
                        GenCol(ToShowCol, "System.Int32", "tran_cd", ToShow);
                        GenCol(ToShowCol, "System.String", "itserial", ToShow);
                        GenCol(ToShowCol, "System.String", "pinv_no", ToShow);
                        GenCol(ToShowCol, "System.DateTime", "pdate", ToShow);
                        GenCol(ToShowCol, "System.String", "pentry_ty", ToShow);
                        GenCol(ToShowCol, "System.String", "pitem_no", ToShow);
                        GenCol(ToShowCol, "System.Int32", "ptran_cd", ToShow);
                        GenCol(ToShowCol, "System.String", "pitserial", ToShow);

                        // CurPurchaseDetail

                        DataTable curPurchaseDet = new DataTable();

                        DataColumn curPurchaseDetCol = null;

                        GenCol(curPurchaseDetCol, "System.Boolean", "ToCheck", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "Inv_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "Date", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "SuppName", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "SuppLoc", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Suppac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Suppsac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "Excbal", curPurchaseDet);

                        fldname = "";
                        for (int tex_exs = 0; tex_exs < PageCustomProps.Tex_exe; tex_exs++)
                        {
                            fldname = "";
                            fldname = PageCustomProps.Tex_ExAr[tex_exs, 2].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(curPurchaseDetCol, "System.Decimal", fldname.Trim(), curPurchaseDet);
                            }

                            fldname = "";
                            fldname = PageCustomProps.Tex_ExAr[tex_exs, 3].ToString().Trim();
                            if (fldname.Trim().ToUpper().IndexOf("EXCBAL") < 0)
                            {
                                GenCol(curPurchaseDetCol, "System.Decimal", fldname.Trim(), curPurchaseDet);
                            }
                        }

                        GenCol(curPurchaseDetCol, "System.String", "u_pinvno", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "u_pinvdt", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pu_pinvno", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "ware_nm", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "manuname", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "manuloc", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Manuac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "Manusac_id", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "pu_pinvdt", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "balqty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "alloqty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "rgpage", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Decimal", "mtduty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "entry_ty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "item_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "tran_cd", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "itserial", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pinv_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.DateTime", "pdate", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pentry_ty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pitem_no", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "ptran_cd", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "pitserial", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "rentry_ty", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.Int32", "rtran_cd", curPurchaseDet);
                        GenCol(curPurchaseDetCol, "System.String", "ritserial", curPurchaseDet);
                        
                        // end

                        string mfldname = "";
                        string mfields = " Excbal ";
                        string mfields1 = " curLItem1.Examt ";
                        for (int tex_exs = 0; tex_exs < PageCustomProps.Tex_exe; tex_exs++)
                        {
                            fldname = PageCustomProps.Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                            if (fldname.Trim().ToUpper() != "EXAMT")
                            {
                                mfields1 = mfields1 + "," + "curLitem1." + fldname.Trim();
                            }
                            fldname = PageCustomProps.Tex_ExAr[tex_exs, 3].Trim().Replace("ITEM_VW", "");
                            if (fldname.Trim().ToUpper() != "EXCBAL")
                            {
                                mfields = mfields + "," + fldname.Trim();
                            }
                        }

                        foreach (DataRow curLitemRow in CurLitem1.Rows)
                        {
                            sqlStr = "select pentry_ty,ptran_cd,pitserial,qty,rgpage,"
                                + mfields1.Trim().Replace("curlitem1.", "") +
                                " from litemall where entry_ty ='"
                                + Convert.ToString(curLitemRow["entry_ty"]).Trim() + "' and " +
                                " tran_cd =" + numFunction.toInt32(curLitemRow["tran_cd"]) +
                                " and itserial='" + Convert.ToString(curLitemRow["itserial"]).Trim() + "'";

                            DataTable tmptable_vw = DataAcess.ExecuteDataTable(sqlStr,"_ss");
                            decimal totQty = 0;
                            foreach (DataRow tmptableRow in tmptable_vw.Rows)
                            {
                                totQty = totQty + numFunction.toDecimal(tmptableRow["qty"]);  
                                sqlStr = "SELECT A.TRAN_CD,A.ENTRY_TY,A.ITSERIAL,A.INV_NO,RGPAGE," +
                                         " MTDUTY,WARE_NM,B.CONS_ID AS SUPPAC_ID,B.SCONS_ID AS SUPPSAC_ID," +
                                         " A.MANUAC_ID,A.MANUSAC_ID,E.AC_NAME AS SUPPNAME,C.LOCATION_ID AS SUPPLOC," +
                                         " F.AC_NAME AS MANUNAME,D.LOCATION_ID AS MANULOC " +
                                         " FROM TRADEITEM A INNER JOIN TRADEMAIN B ON A.ENTRY_TY=B.ENTRY_TY " +
                                         " AND A.TRAN_CD=B.TRAN_CD " +
                                         " INNER JOIN AC_MAST E ON E.AC_ID = B.CONS_ID " +
                                         " LEFT JOIN SHIPTO C ON B.CONS_ID = C.AC_ID AND B.SCONS_ID = C.SHIPTO_ID " +
                                         " INNER JOIN AC_MAST F ON F.AC_ID = A.MANUAC_ID " +
                                         " LEFT JOIN SHIPTO D ON A.MANUAC_ID = D.AC_ID And A.MANUSAC_ID = D.SHIPTO_ID " +
                                         " WHERE A.ENTRY_TY ='" + Convert.ToString(tmptableRow["pentry_ty"]).Trim() + "'" +
                                         " AND A.TRAN_CD = " + numFunction.toInt32(tmptableRow["ptran_cd"]) +
                                         " AND A.ITSERIAL ='" + Convert.ToString(tmptableRow["pentry_ty"]).Trim() + "'";

                                DataTable tmptable_vwAr = DataAcess.ExecuteDataTable(sqlStr, "_sss");

                                DataRow curPurchaseDetRow = curPurchaseDet.NewRow();
                                curPurchaseDetRow["ToCheck"] = false;
                                curPurchaseDetRow["ptran_cd"] = Convert.ToString(curLitemRow["u_pinvno"]).Trim();
                                curPurchaseDetRow["pentry_ty"] = GetDateFormat.TodateTime(curLitemRow["date"]);
                                curPurchaseDetRow["pdate"] = Convert.ToString(curLitemRow["Suppname"]).Trim();
                                curPurchaseDetRow["pitserial"] = Convert.ToString(curLitemRow["Supploc"]).Trim();
                                curPurchaseDetRow["qty"] = numFunction.toInt32(curLitemRow["cons_id"]);
                                curPurchaseDetRow["balqty"] = numFunction.toInt32(curLitemRow["Scons_id"]);

                                mfields = " Excbal ";
                                mfields1 = "Examt";
                                for (int tex_exs = 0; tex_exs < PageCustomProps.Tex_exe; tex_exs++)
                                {
                                    mfields = PageCustomProps.Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                                    mfields1 = PageCustomProps.Tex_ExAr[tex_exs, 2].Trim().Replace("ITEM_VW", "");

                                    if (mfields.Trim().ToUpper() != "EXCBAL" && mfields1.Trim().ToUpper() != "EXAMT")
                                    {
                                        curPurchaseDetRow[mfields] = numFunction.toDecimal(tmptableRow[mfields1]);
                                    }
                                }

                                curPurchaseDetRow["rgpage"] = Convert.ToString(tmptableRow["rgpage"]);
                                curPurchaseDetRow["mtduty"] = numFunction.toDecimal(tmptableRow["mtduty"]);
                                curPurchaseDetRow["tran_cd"] = numFunction.toInt32(tmptableRow["tran_cd"]);
                                curPurchaseDetRow["entry_ty"] = Convert.ToString(tmptableRow["entry_ty"]).Trim();
                                curPurchaseDetRow["tran_cd"] = numFunction.toInt32(tmptableRow["tran_cd"]);
                                curPurchaseDetRow["itserial"] = Convert.ToString(tmptableRow["itserial"]).Trim();
                                curPurchaseDetRow["u_pinvno"] = Convert.ToString(tmptableRow["u_pinvno"]).Trim();
                                curPurchaseDetRow["u_pinvdt"] = GetDateFormat.TodateTime(tmptableRow["u_pinvdt"]);
                                curPurchaseDetRow["Ware_nm"] = Convert.ToString(tmptableRow["Ware_nm"]).Trim();
                                curPurchaseDetRow["ManuName"] = Convert.ToString(tmptableRow["ManuName"]).Trim();
                                curPurchaseDetRow["ManuLoc"] = Convert.ToString(tmptableRow["ManuLoc"]).Trim();
                                curPurchaseDetRow["Manuac_id"] = numFunction.toInt32(tmptableRow["Manuac_id"]);
                                curPurchaseDetRow["Manusac_id"] = numFunction.toInt32(tmptableRow["Manusac_id"]);
                                curPurchaseDet.Rows.Add(curPurchaseDetRow);
                                curPurchaseDet.AcceptChanges();
                            }
 
                            DataRow ToShowRow = ToShow.NewRow();
                            ToShowRow["ToCheck"] = false;
                            ToShowRow["Inv_no"] = Convert.ToString(curLitemRow["u_pinvno"]).Trim();
                            ToShowRow["Date"] = GetDateFormat.TodateTime(curLitemRow["date"]);
                            
                            mfields = " Excbal ";
                            mfields1 = "Examt";
                            for (int tex_exs = 0; tex_exs < PageCustomProps.Tex_exe; tex_exs++)
                            {
                                mfields = PageCustomProps.Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                                mfields1 = PageCustomProps.Tex_ExAr[tex_exs, 2].Trim().Replace("ITEM_VW", "");

                                if (mfields.Trim().ToUpper() != "EXCBAL" && mfields1.Trim().ToUpper() != "EXAMT")
                                {
                                    ToShowRow[mfields] = numFunction.toDecimal(curLitemRow[mfields1]);
                                }
                            }

                            ToShowRow["qty"] = totQty; 
                            ToShowRow["balqty"] = numFunction.toDecimal(curLitemRow["qty"]);
                            ToShowRow["rgpage"] = "";
                            ToShowRow["mtduty"] = 0;
                            ToShowRow["entry_ty"] = Convert.ToString(curLitemRow["entry_ty"]).Trim();
                            ToShowRow["itserial"] = Convert.ToString(curLitemRow["itserial"]).Trim();
                            ToShowRow["u_pinvno"] = "";
                            ToShowRow["u_pinvdt"] = GetDateFormat.TodateTime(Convert.ToDateTime("01/01/1900"));
                            ToShowRow["Ware_nm"] = Convert.ToString(curLitemRow["Ware_nm"]).Trim();
                            ToShowRow["Suppname"] = Convert.ToString(curLitemRow["Suppname"]).Trim();
                            ToShowRow["Supploc"] = Convert.ToString(curLitemRow["Supploc"]).Trim();
                            ToShowRow["Suppac_id"] = numFunction.toInt32(curLitemRow["cons_id"]);
                            ToShowRow["Suppsac_id"] = numFunction.toInt32(curLitemRow["Scons_id"]);
                            ToShowRow["ManuName"] = Convert.ToString(curLitemRow["ManuName"]).Trim();
                            ToShowRow["ManuLoc"] = Convert.ToString(curLitemRow["ManuLoc"]).Trim();
                            ToShowRow["Manuac_id"] = numFunction.toInt32(curLitemRow["Manuac_id"]);
                            ToShowRow["Manusac_id"] = numFunction.toInt32(curLitemRow["Manusac_id"]);
                            ToShow.Rows.Add(ToShowRow);
                            ToShow.AcceptChanges();

                        } // end for each loop of curlitem

                        foreach (DataRow litemallRow in litemall_vw.Rows)
                        {
                            try
                            {
                                string filterExp = "rentry_ty ='" +
                                    Convert.ToString(litemallRow["rentry_ty"]).Trim() + "' and " +
                                    " rtran_cd = " + numFunction.toInt32(litemallRow["rtran_cd"]) +
                                    " and ritserial ='" + Convert.ToString(litemallRow["ritserial"]).Trim() + "'";

                                DataRow litemallFindRow = curPurchaseDet.Select(filterExp)[0];
                                litemallFindRow["balqty"] = numFunction.toDecimal(litemallFindRow["balqty"]) -
                                    numFunction.toDecimal(litemallFindRow["qty"]);
                            }
                            catch { }
                        }

                        string url = "uwETSRItemDetail.aspx?Tex_exe=" + PageCustomProps.Tex_exe;
                        Session["ToShow"] = ToShow;
                        Session["curPurchaseDet"] = curPurchaseDet;
                        Session["main_vw"] = main_vw;
                        Session["itemRow"] = itemRow;
                        Session["Company"] = company;
                        Session["CoAdditional"] = coAdditional;
                        Session["Tex_ExAr"] = PageCustomProps.Tex_ExAr;
                        Session["litemall_vw"] = litemall_vw;

                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "OpenModalDialog('" + url + "',500,750,'" + btnHDITDetailExcisePostBack.ClientID + "');", true);
                    } // end GT
                }
            }
        }

        protected DataColumn GenCol(DataColumn ToShowcol,
                    string DataType,
                    string colName,
                    DataTable DbTable)
        {
            ToShowcol = new DataColumn();
            ToShowcol.DataType = Type.GetType(DataType);
            ToShowcol.ColumnName = colName;
            DbTable.Columns.Add(ToShowcol);
            return ToShowcol;
        }


        protected void DateValidation(TextBox txtDatevalid,DataSet MainDataSet)
        {
            DataTable company = MainDataSet.Tables["company"];
            boolFunction bitFunction = new boolFunction();
            bool Fst = false;
            SqlDataReader dr;
            try
            {
                if (!(GetDateFormat.TodateTime(txtdate.Text) >= GetDateFormat.TodateTime(company.Rows[0]["sta_dt"])
                    && GetDateFormat.TodateTime(txtdate.Text) <= GetDateFormat.TodateTime(company.Rows[0]["end_dt"])))
                {
                    if (GetDateFormat.TodateTime(txtdate.Text) < GetDateFormat.TodateTime(company.Rows[0]["sta_dt"]))
                    {
                        sqlStr = "select Top 1 CompId from servicetax..co_mast where " +
                            "co_name ='" + Convert.ToString(company.Rows[0]["co_name"]).Trim() + "'" +
                            " and end_dt < '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(company.Rows[0]["sta_dt"])) + "'";

                        dr = DataAcess.ExecuteDataReader(sqlStr);
                        if (dr.HasRows == true)
                            Fst = true;
                        else
                            Fst = true;
                        dr.Close(); 
                    }

                    if (GetDateFormat.TodateTime(txtdate.Text) > GetDateFormat.TodateTime(company.Rows[0]["end_dt"]))
                    {
                        sqlStr = "select Top 1 CompId from servicetax..co_mast where " +
                            "co_name ='" + Convert.ToString(company.Rows[0]["co_name"]).Trim() + "'" +
                            " and sta_dt > '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(company.Rows[0]["end_dt"])) + "'";

                        dr = DataAcess.ExecuteDataReader(sqlStr);
                        if (dr.HasRows == true)
                            Fst = true;
                        else
                            Fst = true;
                        dr.Close();
                    }

                    DataAcess.Connclose(); 
                    if (Fst == false)
                    {
                        company.Dispose();
                        System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "DateValidation('Transaction Date Not in Financial Year. Continue anyway?','" + txtDatevalid.ClientID + "');", true);
                    }
                    else
                    {
                        if (Fst == true)
                        {
                            throw new Exception("Date not in financial year"); 
                        }
                    }
                }

                Session["MainDataSet"] = MainDataSet; 
                callDateValidation();
            }
            catch (Exception ex)
            {
                company.Dispose();
                System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "alert('" + ex.Message + "');", true);
            }

        }

        protected void callDateValidation()
        {
            DataSet MainDataSet = (DataSet)Session["MainDataSet"];
            DataTable company = MainDataSet.Tables["company"];
            DataTable lcode_vw = MainDataSet.Tables["lcode_vw"];
            DataTable main_vw = MainDataSet.Tables["main_vw"];
            DataTable item_vw = MainDataSet.Tables["item_vw"];
            DataTable acdet_vw = MainDataSet.Tables["acdet_vw"];
            boolFunction bitFunction = new boolFunction();

            if (PageCustomProps.LbackDated == true)
            {
                if (PageCustomProps.PBackDate > GetDateFormat.TodateTime(main_vw.Rows[0]["date"]))
                {
                    System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "alert('Date can not be less than last entry date');", true);
                    return;
                }
            }

            main_vw.Rows[0]["date"] = GetDateFormat.TodateTime(txtdate.Text);
            main_vw.AcceptChanges();


            if (PageCustomProps.Vchkprod.IndexOf("vutex") >= 0)
            {
                if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ||
                    Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                {
                    if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "AR", "IR", "GT" }) == true ||
                        strFunction.InList(PageCustomProps.Behave, new string[] { "AR", "IR", "GT" }) == true) &&
                        bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == false)
                    {
                        DataTable manu_det_vw = MainDataSet.Tables["manu_det_vw"];
                        try
                        {
                            DataRow ManuDTRow = manu_det_vw.Select("manudate < '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'")[0];
                            manu_det_vw.Dispose();
                        }
                        catch
                        {
                            manu_det_vw.Dispose();
                            System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "alert('Date can't be less than Manufacture Date');", true);
                            return;
                        }
                    }

                    if ((strFunction.InList(PageCustomProps.PcvType, new string[] { "DC", "IR", "SS" }) == true ||
                            strFunction.InList(PageCustomProps.Behave, new string[] { "DC", "IR", "SS" }) == true) ||
                            ((PageCustomProps.PcvType == "GT" || PageCustomProps.Behave == "GT") &&
                            bitFunction.toBoolean(main_vw.Rows[0]["u_sinfo"]) == false))
                    {
                        DataTable litemall_vw = MainDataSet.Tables["litemall_vw"];
                        try
                        {
                            DataRow LitemallRow = litemall_vw.Select("padate < '" + GetDateFormat.dateformat(GetDateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'")[0];
                            litemall_vw.Dispose();

                        }
                        catch
                        {
                            litemall_vw.Dispose();
                            System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "alert('Date can't be less than purchase Date');", true);
                            return;
                        }
                    }

                }
            }
            vuInit initProc = new vuInit();
            //getTables _getTables = new getTables();  
            initProc.UpdateFinYear(main_vw,
                    company,
                    main_vw);

            if (PageCustomProps.ItemPage == true)
            {
                foreach (DataRow itemRow in item_vw.Rows)
                {
                    itemRow["date"] = GetDateFormat.TodateTime(txtdate.Text);
                }
                item_vw.AcceptChanges();
            }

            if (PageCustomProps.AccountPage == true)
            {
                foreach (DataRow acdetRow in acdet_vw.Rows)
                {
                    acdetRow["date"] = GetDateFormat.TodateTime(txtdate.Text);
                }
                acdet_vw.AcceptChanges();
            }

            if (trduedt.Visible == true)
            {
                if (System.Convert.IsDBNull(main_vw.Rows[0]["due_dt"]) ||
                    !(GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]) > PageCustomProps.AppDate &&
                    GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]) < DateTime.MaxValue))
                {
                    main_vw.Rows[0]["due_dt"] = GetDateFormat.TodateTime(txtdate.Text);
                    main_vw.AcceptChanges();
                    if (txtDueDate.Text == "")
                    {
                        if (txtDueDays.Text != "")
                        {
                            txtDueDate.Text = GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]).AddDays(Convert.ToInt32(txtDueDays)).ToString("dd/MM/yyyy");
                        }
                        else
                        {
                            txtDueDate.Text = GetDateFormat.TodateTime(main_vw.Rows[0]["due_dt"]).ToString("dd/MM/yyyy");
                        }
                    }
                }
            }

            MainDataSet.AcceptChanges();  
            Session["MainDataSet"] = MainDataSet;

            MainDataSet.Dispose();
            company.Dispose();
            lcode_vw.Dispose();
            main_vw.Dispose();
            item_vw.Dispose();
            acdet_vw.Dispose();
            DataAcess.Connclose();
        }
        protected void btnDateValidation_Click(object sender, EventArgs e)
        {
            callDateValidation(); 
        }



        public DataTable GenStock(int ItemName,
            DataTable main_vw,
            DataTable coAdditional,
            DataTable lcode_vw,
            DataTable litemall_vw,
            DataRow itemRow,
            string varETGoDown,
            int Tex_exe,
            string[,] Tex_ExAr)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            getDateFormat DateFormat = new getDateFormat();
            DataTier DataAcess = new DataTier();
            SqlDataReader dr;
            int rowsEffected = 0;
            string GodownName, mentry_tyar, mentry_tygt = "";
            mentry_tyar = "";
            mentry_tygt = "";
            string sqlstr = "";
            bool etFlag = false;
            int pParty, pPartyS, manuName, manuNameS = 0;

            pParty = numFunction.toInt32(main_vw.Rows[0]["suppac_id"]);
            pPartyS = numFunction.toInt32(main_vw.Rows[0]["suppsac_id"]);
            manuName = numFunction.toInt32(main_vw.Rows[0]["manuac_id"]);
            manuNameS = numFunction.toInt32(main_vw.Rows[0]["manusac_id"]);

            GodownName = varETGoDown;
            etFlag = Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
                bitFunction.toBoolean(coAdditional.Rows[0]["et_flag"]) :
                bitFunction.toBoolean(coAdditional.Rows[0]["net_flag"]);

            string mFieldlist = Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() != "" ?
                Convert.ToString(lcode_vw.Rows[0]["it_fields"]).Trim() : "it_mast.it_name";

            string fldName, fldName1, fldnewName = "";
            fldName = mFieldlist;

            while (fldName.Trim() != "")
            {
                fldName1 = fldName.Trim().IndexOf(",") >= 0 ?
                    fldName.Trim().Substring(0, fldName.Trim().IndexOf(',')) : fldName.Trim();
                fldnewName = fldnewName + (fldnewName.Trim() != "" ? "," : "") +
                            (fldName1.Trim().IndexOf(':') >= 0 ?
                            fldName1.Trim().Substring(0, fldName1.IndexOf(':')) : fldName1.Trim());
                fldName = fldName.Trim().IndexOf(',') > 0 ?
                    fldName.Trim().Substring(fldName.Trim().IndexOf(',') + 1) : "";
            }

            fldName = fldnewName.Trim().ToUpper().Replace("IT_MAST.", "B.");

            sqlstr = " select entry_ty,bcode_nm from lcode where entry_ty " +
                     " in ('AR','IR','GT') or bcode_nm in ('AR','IR','GT') ";

            dr = DataAcess.ExecuteDataReader(sqlstr);
            if (dr.HasRows == true)
            {
                while (dr.Read())
                {
                    if (Convert.ToString(dr["entry_ty"]).Trim() == "GT" ||
                        Convert.ToString(dr["bcode_nm"]).Trim() == "GT")
                    {
                        mentry_tygt = mentry_tygt + (mentry_tygt.Trim() != "" ?
                            "," : "") + "'" + Convert.ToString(dr["entry_ty"]).Trim() + "'";
                    }
                    else
                    {
                        mentry_tyar = mentry_tyar + (mentry_tyar.Trim() != "" ?
                            "," : "") + "'" + Convert.ToString(dr["entry_ty"]).Trim() + "'";
                    }
                }
            }
            else
            {
                dr.Close();
                DataAcess.Connclose();
                throw new Exception("ERROR!!! Lcode table not found OR Records not found in Lcode");
            }
            dr.Close();
            dr.Dispose();

            string mcond = "";
            mcond = " ((A.Entry_ty In (" + mentry_tyar + ")) Or (A.Entry_ty In (" +
                        mentry_tygt + ") And A.U_sinfo = 0)) And A.Date <='" +
                        DateFormat.dateformat(DateFormat.TodateTime(main_vw.Rows[0]["date"])) + "'";
            mcond = mcond + (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
                " And A.[Rule] = 'EXCISE' " : " And A.[Rule] In('EXCISE','NON-EXCISE') ");
            mcond = mcond + ((pParty != 0 && etFlag == false) ? " And A.Cons_id = " + pParty +
                " And A.Scons_id = " + pPartyS : "");
            sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Date,A.U_pinvno,A.U_pinvdt, " +
                     " A.Cons_id,A.Scons_id,C.Ac_name As SuppName,B.Location_id As SuppLoc " +
                     " into #tmptbl_vwv " +
                     " From TradeMain A ";
            sqlstr = sqlstr + " Inner Join Ac_mast C On A.Cons_id = C.Ac_id " +
                     " Left Join Shipto B On A.Cons_id = B.Ac_id And A.Scons_id = B.Shipto_id " +
                     " Where " + mcond;


            try
            {
                rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            }
            catch (Exception Ex)
            {
                DataAcess.Connclose();
                throw Ex;
            }

            mcond = " ((A.Entry_ty In (" + mentry_tyar + ")) Or (A.Entry_ty In (" + mentry_tygt + "))) ";
            mcond = mcond + (ItemName != 0 ? " And A.It_code = " + ItemName : "");
            mcond = mcond + ((pParty != 0 && etFlag == false) ? " And A.ware_nm = '" + GodownName.Trim() + "'" : "");
            sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Itserial,A.It_code,A.Ware_nm,A.Rgpage,A.Mtduty,A.Balqty,A.Balqty1 ";

            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                sqlstr = sqlstr + "," + "A." + Tex_ExAr[tex_exs, 2];
            }

            sqlstr = sqlstr + "," + fldName +
                " into #tmptbl_vwi " +
                " From TradeItem A,It_mast B Where A.It_Code = B.It_code And " + mcond;

            try
            {
                rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            }
            catch (Exception Ex)
            {
                DataAcess.Connclose();
                throw Ex;
            }


            mcond = ((pParty != 0 && etFlag == false) ? " A.Manuac_id = " + manuName +
                " And A.Manusac_id = " + manuNameS : "");
            mcond = mcond.Trim() != "" ? " Where " + mcond.Trim() : "";
            sqlstr = " Select A.Tran_cd,A.Entry_ty,A.Itserial,A.Manuac_id,A.Manusac_id, " +
                " C.Ac_name as ManuName,B.Location_id as ManuLoc " +
                " into #tmptbl_vwm " +
                " From Manu_det A";
            sqlstr = sqlstr + " Left Join Ac_mast C On A.Manuac_id = C.Ac_id " +
                     " Left Join Shipto B On A.Manuac_id = B.Ac_id And A.Manusac_id = B.Shipto_id " +
                     mcond;

            try
            {
                rowsEffected = DataAcess.ExecuteNonQuery(sqlstr, "TX");
            }
            catch (Exception Ex)
            {
                DataAcess.Connclose();
                throw Ex;
            }

            sqlstr = " A.Tran_cd,A.Entry_ty,A.Date,A.U_pinvno,A.U_pinvdt,A.Cons_id,A.Scons_id,A.SuppName,A.SuppLoc," +
                " B.Itserial,B.It_code,B.Ware_nm,B.Rgpage,B.Mtduty,B.Balqty,B.Balqty1 ";

            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                sqlstr = sqlstr + "," + "B." + Tex_ExAr[tex_exs, 2];
            }

            sqlstr = sqlstr + "," + fldName + ",C.Manuac_id,C.Manusac_id,C.ManuName,C.ManuLoc ";
            mcond = " A.Entry_ty = B.Entry_ty And A.Tran_cd = B.Tran_cd " +
                " And B.Entry_ty = C.Entry_ty And B.Tran_cd = C.Tran_cd And B.Itserial = C.Itserial ";
            mcond = mcond + (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE" ?
                " And B.BalQty > 0 And (B.Excbal > 0 Or B.U_Cessbal > 0) " :
                " And B.BalQty > 0 ");

            sqlstr = " select " + sqlstr + " From #tmptbl_vwv A,#tmptbl_vwi B,#tmptbl_vwm C " +
                     " where " + mcond;

            DataTable trdtbl_vw = new DataTable();
            try
            {
                trdtbl_vw = DataAcess.ExecuteDataTable(sqlstr, "_trdtbl_vw");
            }
            catch (Exception Ex)
            {
                DataAcess.Connclose();
                throw Ex;
            }

            sqlstr = " drop table #tmptbl_vwv " +
                     " drop table #tmptbl_vwi " +
                     " drop table #tmptbl_vwm ";

            DataAcess.ExecuteNonQuery(sqlstr, "TX");

            foreach (DataRow litemAllRow in litemall_vw.Rows)
            {
                try
                {
                    string filterExp = "(Entry_ty ='" + Convert.ToString(litemAllRow["pentry_ty"]).Trim() + "' and " +
                           " tran_cd = " + numFunction.toInt32(litemAllRow["ptran_cd"]) +
                           " and itserial ='" + Convert.ToString(litemAllRow["pitserial"]).Trim() + "') and " +
                           " is null date";

                    DataRow findRow = trdtbl_vw.Select(filterExp)[0];
                    findRow["balqty"] = numFunction.toDecimal(findRow["balqty"]) -
                                        numFunction.toDecimal(litemAllRow["qty"]);
                    findRow["balqty1"] = numFunction.toDecimal(findRow["balqty1"]) -
                                        numFunction.toDecimal(litemAllRow["u_lqty"]);

                    for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                    {
                        findRow[Tex_ExAr[tex_exs, 2]]
                                = numFunction.toDecimal(findRow[Tex_ExAr[tex_exs, 2]]) -
                                numFunction.toDecimal(litemAllRow[Tex_ExAr[tex_exs, 1]]);
                    }

                    if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim() == "EXCISE")
                    {
                        if (!(numFunction.toDecimal(findRow["Balqty"]) > 0 &&
                            (numFunction.toDecimal(findRow["excbal"]) > 0 ||
                             numFunction.toDecimal(findRow["u_cessbal"]) > 0)))
                        {
                            findRow.Delete();
                        }
                    }
                    else
                    {
                        if (!(numFunction.toDecimal(findRow["balqty"]) > 0))
                        {
                            findRow.Delete();
                        }
                    }
                    findRow.AcceptChanges();
                }
                catch
                {
                    if (itemRow != null)
                    {
                        if (Convert.ToString(litemAllRow["itserial"]).Trim() ==
                            Convert.ToString(itemRow["itserial"]))
                        {
                            litemAllRow["Qty"] = 0;
                            litemAllRow.AcceptChanges();
                        }
                    }

                }
            }
            trdtbl_vw.AcceptChanges();
            DataAcess.Connclose();
            return trdtbl_vw;
        }


        protected void SessionsRemove()
        {
            Session.Remove("MainDataSet");
            Session.Remove("GridItemColView");
            Session.Remove("AllocDataRow");
            Session.Remove("RStatusView");
            Session.Remove("MainQueryString");
            Session.Remove("SubQueryString");
            Session.Remove("IsSubReport");
            Session.Remove("ReportDataSet");
            Session.Remove("RetItemRow");
            Session.Remove("main_vw");
            Session.Remove("lcode_vw");
            Session.Remove("item_vw");
            Session.Remove("manu_det_vw");
            Session.Remove("litemall_vw");
            Session.Remove("company");
            Session.Remove("Tex_ExAr");
            Session.Remove("CoAdditional");
            Session.Remove("curPurchaseDet");
            Session.Remove("itemRow");
        }

        protected void radDrCr_SelectedIndexChanged(object sender, EventArgs e)
        {
            // This method use for Openning Balances Transaction
                try
                {
                    DataSet MainDataSet = (DataSet)Session["MainDataSet"];
                    if (radDrCr.SelectedValue.ToString().Trim().ToUpper()  == "DEBIT")
                    {
                        MainDataSet.Tables["main_vw"].Rows[0]["u_choice"] = true;  
                    }
                    else
                    {
                        if (radDrCr.SelectedValue.ToString().Trim().ToUpper() == "CREDIT")
                        {
                            MainDataSet.Tables["main_vw"].Rows[0]["u_choice"] = false;  
                        }
                    }

                    if (PageCustomProps.AccountPage == true)
                    {
                        TransactionEvent.PageCustProps = PageCustomProps;
                        TransactionEvent.txtAccNetAmount_TextChanged(MainDataSet.Tables["main_vw"],
                                        MainDataSet.Tables["acdet_vw"],
                                        MainDataSet.Tables["item_vw"],
                                        MainDataSet.Tables["lcode_vw"],
                                        GridAccount,
                                        grdlAllocDet,
                                        LinkAcAdd,
                                        txtAccNetAmount,
                                        Convert.ToString(MainDataSet.Tables["main_vw"].Rows[0]["u_choice"]).Trim().ToUpper());
                    }
                    Session["MainDataSet"] = MainDataSet; 
                    MainDataSet.Dispose();
                }
                catch (Exception Ex)
                {
                    MessageErrorDisp(Ex);
                    return;
                }

        }

       
        
      

        //[System.Web.Services.WebMethod()]
        //public static string GetBalance(string pParam)
        //{
        //    //string acId, string tranCd, string addMode, string entryType
        //    string[] paramList = new string[7];
        //    paramList =  pParam.Split(',');
        //    string acId = paramList[1];
        //    string tranCd = paramList[3];
        //    string addMode = paramList[5];
        //    string entryType = paramList[7];

        //    System.Threading.Thread.Sleep(500);
        //    Page page = new Page();
        //    wcAccBal ctl = (wcAccBal)Page.LoadControl("~/wcAccBal.ascx");
        //    ctl.AcId = acId;
        //    ctl.TranCd = tranCd;
        //    ctl.AddMode = addMode;
        //    ctl.EntryType = entryType.Trim();

        //    Page.Controls.Add(ctl);
        //    System.IO.StringWriter writer = new System.IO.StringWriter();
        //    HttpContext.Current.Server.Execute(page, writer, false);
        //    string output = writer.ToString();
        //    writer.Close();
        //    return output;
        //}        

    }



   


}
