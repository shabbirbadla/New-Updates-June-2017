using System;
using System.Data;
using System.Data.SqlClient; 
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using Business.Logic.Layer;
using System.Collections.Generic;
using System.ComponentModel; 


namespace Udyog.E.Billing
{
    public partial class uwAcMasterView : BasePage 
    {
        private String m_strSortExp;
        private SortDirection m_SortDirection = SortDirection.Ascending;
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        CL_Gen_Man_AcMast_View obj_Gen_AcMast_View = new CL_Gen_Man_AcMast_View();

        string SearchString = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                m_strSortExp = "[ac_name]";
                ViewState["_Direction_"] = m_SortDirection;
                ViewState["_SortExp_"] = m_strSortExp;

                lblTrType.Text = "Account Master";
                txtSearch.Attributes.Add("onkeypress", "return OnKeyEnter();");
                txtSearch.Attributes.Add("onfocus", "select();");
                bool ShowStatus = Convert.ToBoolean(Request.QueryString["ShowStatus"]);

                if (ShowStatus == true)
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Sucessfully Saved.');", true);

                txtSearch.Focus();
            }
            else
            {
                if (null != ViewState["_SortExp_"])
                {
                    m_strSortExp = ViewState["_SortExp_"] as String;
                }

                if (null != ViewState["_Direction_"])
                {
                    m_SortDirection = (SortDirection)ViewState["_Direction_"];
                }
            }

        }

        private void bindGridView()
        {
            grdAcMaster.DataBind();
        }

        int GetSortColumnIndex(String strCol)
        {
            foreach (DataControlField field in grdAcMaster.Columns)
            {
                if (field.SortExpression == strCol)
                {
                    return grdAcMaster.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        void AddSortImage(GridViewRow headerRow)
        {
            Int32 iCol = !string.IsNullOrEmpty(m_strSortExp) ? GetSortColumnIndex(m_strSortExp.Trim().ToUpper()) : -1;
            if (-1 == iCol)
            {
                return;
            }
            // Create the sorting image based on the sort direction.
            Image sortImage = new Image();
            if (SortDirection.Ascending == m_SortDirection)
            {
                sortImage.ImageUrl = "~/Images/ArrowDown.png";
                sortImage.AlternateText = "Ascending Order";
            }
            else
            {
                sortImage.ImageUrl = "~/Images/ArrowUp.png";
                sortImage.AlternateText = "Descending Order";
            }

            // Add the image to the appropriate header cell.
            headerRow.Cells[iCol].Controls.Add(sortImage);
        }

        protected void ResultDisplay(int ResultRows)
        {
            if (ResultRows == 0)
            {
                lblResult.Text = "No Result Found..";
                lnkAll.Enabled = false;
                lnkNone.Enabled = false;
            }
            else
            {
                lblResult.Text = "Result Found :" + ResultRows.ToString().Trim();
                lnkAll.Enabled = true;
                lnkNone.Enabled = true;
            }
        }

        protected void GoToPage_TextChanged(object sender, EventArgs e)
        {
            TextBox txtGoToPage = (TextBox)sender;

            int pageNumber;
            if (int.TryParse(txtGoToPage.Text.Trim(), out pageNumber) && pageNumber > 0 && pageNumber <= this.grdAcMaster.PageCount)
            {
                this.grdAcMaster.PageIndex = pageNumber - 1;
            }
            else
            {
                this.grdAcMaster.PageIndex = 0;
            }

            bindGridView(); 
        }

        #region Event Handlers
        protected void OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                if (String.Empty != m_strSortExp)
                {
                    AddSortImage(e.Row);
                }
            }
        }

        protected void OnSort(object sender, GridViewSortEventArgs e)
        {
            // There seems to be a bug in GridView sorting implementation. Value of
            // SortDirection is always set to "Ascending". Now we will have to play
            // little trick here to switch the direction ourselves.
            if (String.Empty != m_strSortExp)
            {
                if (String.Compare(e.SortExpression, m_strSortExp, true) == 0)
                {
                    m_SortDirection = (m_SortDirection == SortDirection.Ascending) ? SortDirection.Descending : SortDirection.Ascending;
                }
            }

            ViewState["_Direction_"] = m_SortDirection;
            ViewState["_SortExp_"] = m_strSortExp = e.SortExpression;

            this.bindGridView();
        }
        #endregion

        protected void lnkAll_Click(object sender, EventArgs e)
        {

        }

        
        protected void dropGrdview_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList dropDown = (DropDownList)sender;
            int grdPageSize;
            grdPageSize = int.Parse(dropDown.SelectedValue);
            this.grdAcMaster.PageSize = grdPageSize;
            bindGridView();
            dropDown.SelectedValue = grdPageSize.ToString(); 
        }

        protected string EraseWord(string word)
        {
            word = word.Replace("<span class=highlight>", "");
            word = word.Replace("</span>", "");
            word = word.Trim();
            return word;
        }

    

        public string HighlightText(string InputTxt)
        {
            if (txtSearch.Text != "")
                SearchString = txtSearch.Text.Trim();

            if (SearchString == "")
            {
                return InputTxt;
            }
            else
            {
                System.Text.RegularExpressions.Regex ResultStr;
                ResultStr = new System.Text.RegularExpressions.Regex(SearchString.Replace(" ", "|"),System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return ResultStr.Replace(InputTxt,new System.Text.RegularExpressions.MatchEvaluator(this.ReplaceWords));
            }
        }

        public string ReplaceWords(System.Text.RegularExpressions.Match m)
        {
            return "<span class=highlight>" + m.ToString() + "</span>";
        }

        protected void btnGOSearch_Click(object sender, EventArgs e)
        {
            bindGridView(); 
        }

        protected void grdAcMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Pager)
            {
                Label lblTotalNumberOfPages = (Label)e.Row.FindControl("lblTotalNumberOfPages");
                lblTotalNumberOfPages.Text = grdAcMaster.PageCount.ToString();

                TextBox txtGoToPage = (TextBox)e.Row.FindControl("txtGoToPage");
                txtGoToPage.Text = (grdAcMaster.PageIndex + 1).ToString();

                DropDownList ddlPageSize = (DropDownList)e.Row.FindControl("ddlPageSize");
                ddlPageSize.SelectedValue = grdAcMaster.PageSize.ToString();
            }
            else
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    //e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';this.style.backgroundColor='#fafad2'";
                    //e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none';this.style.backgroundColor='#f5f5f5'";

                    e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                    e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";

                }
            }
        }

        protected void grdAcMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "EDITLINK":
                    //Response.Redirect("uwAcMaster.aspx?acID=" + grdAcMaster.DataKeys[Convert.ToInt16(e.CommandArgument)].Values[0].ToString().Trim() +
                    //                  "&acGroupType=B&addMode=false&editMode=true");
                    Server.Transfer("uwAcMaster.aspx?acID=" + grdAcMaster.DataKeys[Convert.ToInt16(e.CommandArgument)].Values[0].ToString().Trim() +
                                      "&acGroupType=B&addMode=false&editMode=true");

                    break;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            for (int i=0;i<=grdAcMaster.Rows.Count-1;i++) 
            {
                CheckBox chkSelect = (CheckBox)grdAcMaster.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    try
                    {
                        DeleteRec(Convert.ToInt32(grdAcMaster.DataKeys[i].Values[0]));
                        tblError.Visible = false;
                        btnGOSearch_Click(sender, e); // Refresh GridView 
                    }
                    catch (Exception Ex)
                    {
                        tblError.Visible = true;
                        lblErrorHeading.Text = "Error Found while Deleting Records.";
                        lblErrorDetails.Text = Ex.Message;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "HighlightRow(null,'" + chkSelect.ClientID + "');", true);
                        break;
                    }
                }
            }
        }

        protected void DeleteRec(Int32 acId)
        {
            try
            {
                obj_Gen_AcMast_View.Ac_Id  = acId;
                obj_Gen_AcMast_View.Delete();

                CL_Gen_Master_WriteXML obj_Master_WriteXML = new CL_Gen_Master_WriteXML();
                DataSet m_Ds = new DataSet();
                m_Ds = obj_Master_WriteXML.writeXmlDS("AC");

                string xmlPath = Convert.ToString(SessionProxy.Company.Rows[0]["dir_nm"]).Trim() +
                                 "\\xml\\AcMast.xml";

                m_Ds.WriteXml(Server.MapPath(xmlPath));
                if (m_Ds != null)
                    m_Ds.Dispose();

            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message.Trim());
            }
        }

        protected void ObjectDataSource1_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            e.InputParameters["searchtext"] = txtSearch.Text.Trim();
            string strSort = "[ac_name] asc";
            if (null != m_strSortExp &&
                String.Empty != m_strSortExp)
            {
                strSort = String.Format("{0} {1}", m_strSortExp, (m_SortDirection == SortDirection.Descending) ? "DESC" : "ASC");
            }
            e.InputParameters["sortBytext"] = strSort;

        }

        protected void lnkBtnAddNew_Click(object sender, EventArgs e)
        {
            //Response.Redirect("uwAcMaster.aspx?&acGroupType=B&addMode=true&editMode=false");
            Server.Transfer("uwAcMaster.aspx?&acGroupType=B&addMode=true&editMode=false");
        }
}
    public class GetAcMastList
    {
        private static int totalRec;

        [DataObjectMethod(DataObjectMethodType.Select)]
        public List<AcMast> GetAcMastRows(int startIndex,
                    int pageSize,
                    string sortBy,
                    string searchtext,
                    string sortBytext)
        {
            //PageCustomProperties PageCustomProps = new PageCustomProperties();
            boolFunction bitFunction = new boolFunction();
            TransactionData TransDataBLL = new TransactionData();
            List<AcMast> result;

            int totRec = 0;

            if (string.IsNullOrEmpty(sortBytext))
                sortBy = "[ac_name] asc";
            result = TransDataBLL.GetAcMastRows(startIndex, pageSize, sortBytext,
                        searchtext, ref totRec);
            totalRec = totRec;
            return result;
        }

        public static int GetTotalRecCount(string searchtext,string sortBytext)
        {
            return totalRec;
        }
    }
}
