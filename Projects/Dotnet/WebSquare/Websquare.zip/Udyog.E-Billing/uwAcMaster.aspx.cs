using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Business.Logic.Layer;  


namespace Udyog.E.Billing
{
    public partial class uwAcMaster : System.Web.UI.Page
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();    
        //DataTier DataAccess;
       
        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }
        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private int acId;
        public int AcId
        {
            get { return acId; }
            set { acId = value; }
        }

        private string acGroup;
        public string AcGroup
        {
            get { return acGroup; }
            set { acGroup = value; }
        }

        SqlDataReader dr;
        private string SqlStr = "";
        private SqlConnection connHandle;
        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet AcmastDataSet = new DataSet();
            if (IsPostBack == true)
            {
                 AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                 EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                 AcId = Convert.ToInt32(Request.QueryString["acId"]);
                 AcGroup = Convert.ToString(Request.QueryString["acGroupType"]);
                    

                 AcmastDataSet = SessionProxy.AcmastDataSet;
  
                if (AcmastDataSet.Tables["lother"].Rows.Count > 0)
                {
                    DataView xtra_vw = AcmastDataSet.Tables["lother"].DefaultView;
                    xtra_vw.Sort = "Serial";
                    vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                    try
                    {
                        vuAddInfo.genControls(xtra_vw,
                                AcmastDataSet.Tables["Acmastview"].Rows[0], tblAddInfoDetails);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                }
                return;
            }

            // Get Parameters from Previous Page
            AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
            AcId =  Convert.ToInt32(Request.QueryString["acId"]);
            AcGroup = Convert.ToString(Request.QueryString["acGroupType"]);

            AcmastDataSet = new DataSet(); 
            DataTier DataAccess = new DataTier();
            lblTrType.Text = "Account Master";

            SqlParameter[] param = {
                new SqlParameter("@acGroup",SqlDbType.VarChar),
                new SqlParameter("@addMode",SqlDbType.Bit),
                new SqlParameter("@editMode",SqlDbType.Bit),
                new SqlParameter("@acId",SqlDbType.Int)};

            param[0].Value = acGroup;
            param[1].Value = AddMode;
            param[2].Value = EditMode;
            param[3].Value = AcId;
 
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
   
            ArrayList dblist = new ArrayList();
            dblist.Add("GroupView");
            dblist.Add("TypeView");
            dblist.Add("CityView");
            dblist.Add("StateView");
            dblist.Add("CountryView");
            dblist.Add("SaleManView");
            dblist.Add("SerTaxView");
            dblist.Add("AcMastView");
            dblist.Add("lother");

            AcmastDataSet = DataAcess.ExecuteDataset(AcmastDataSet, "sp_ent_web_acMast_Init",
                                            param,
                                            dblist,connHandle);
            DataAccess.Connclose(connHandle);

            fillDropDowns(AcmastDataSet);

            if (AddMode == true)
            {
                addRec(ref AcmastDataSet);
            }
            else
            {
                if (EditMode == true)
                {
                    editRec(acId,AcmastDataSet);
                }
            }


            txtAlphaName.Attributes.Add("onfocusout", "javascript: MailNameCopy();"); 

            //SqlStr = "Select * from lother where e_code='AM' order by serial";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "lother");
            //DataAccess.Connclose();

            if (AcmastDataSet.Tables["lother"].Rows.Count > 0)
            {
                DataView xtra_vw = AcmastDataSet.Tables["lother"].DefaultView;
                xtra_vw.Sort = "Serial";
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.genControls(xtra_vw, 
                            AcmastDataSet.Tables["Acmastview"].Rows[0],tblAddInfoDetails);  
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }

            SessionProxy.AcmastDataSet = AcmastDataSet;
            AcmastDataSet.Dispose(); 
        }

        protected void addRec(ref DataSet AcmastDataSet)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            //DataAccess = new DataTier();
            //SqlStr = "select * from ac_mast where 1=2";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "AcMastView");
            DataRow acMastRow = AcmastDataSet.Tables["AcMastView"].NewRow();
            acMastRow["posting"] = "Entry by Entry";
            acMastRow["UpDown"] = 99;
            acMastRow["CrAllow"] = true;
            acMastRow["Country"] = "India";

            int countryId = 0;
            foreach (DataRow countRow in AcmastDataSet.Tables["CountryView"].Select("country ='India'"))
            {
                countryId = numFunction.toInt32(countRow["country_id"]);  
            }

            acMastRow["country_id"] = countryId;  
            DataNullUpdate.NullUpdate(acMastRow);
            dropCountry.SelectedValue = Convert.ToString(countryId);
            dropLedPost.SelectedValue = Convert.ToString(acMastRow["posting"]).Trim();
            chkCrLimitAllow.Checked = bitFunction.toBoolean(acMastRow["CrAllow"]);  
            AcmastDataSet.Tables["AcMastView"].Rows.Add(acMastRow);
            AcmastDataSet.Tables["AcMastView"].AcceptChanges();
                            
        }

        protected void editRec(Int32 acId, DataSet AcmastDataSet)
        {
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;
 
            //SqlStr = "select * from ac_mast where ac_id = " + acId;
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "AcMastView");
            bindControls(AcmastDataSet.Tables["AcMastView"].Rows[0]);
            HideRowsDepGroup();   // Set controls depending upon groups
            ConditionalBindControls(AcmastDataSet.Tables["AcMastView"].Rows[0]);
            txtAlphaName.ReadOnly = true; 
        }

        protected void fillDropDowns(DataSet AcmastDataSet)
        {
            //SqlStr = "select ac_group_name as GroupName,ac_group_id from ac_group_mast where type in ('" + acGroup + "')" +
            //         " order by ac_group_name";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet,SqlStr,"GroupView");   
            dropGroup.DataSource = AcmastDataSet.Tables["GroupView"];  
            dropGroup.DataTextField = "GroupName";
            dropGroup.DataValueField = "ac_group_id";
            dropGroup.DataBind();
            dropGroup.Items.Insert(0, "--Select Group--");   

            //SqlStr = "select ac_type_id,typ as TypeName from AC_TYPE_MAST order by typ";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet,SqlStr,"TypeView");   
            dropType.DataSource = AcmastDataSet.Tables["TypeView"];  
            dropType.DataTextField = "typename";
            dropType.DataValueField = "ac_type_id";
            dropType.DataBind();
            dropType.Items.Insert(0, "--Select Type--");

            //SqlStr = "Select distinct city,city_id from city where city is not null AND City <> '' Order By City";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "CityView");
            dropCity.DataSource = AcmastDataSet.Tables["CityView"];  
            dropCity.DataTextField = "city";
            dropCity.DataValueField = "city_id";
            dropCity.DataBind();
            dropCity.Items.Insert(0, "--Select City--");

            //SqlStr = "Select distinct state_id,state from state where state is not null and state <> '' order by state";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "StateView");
            dropState.DataSource = AcmastDataSet.Tables["StateView"];  
            dropState.DataTextField = "state";
            dropState.DataValueField = "state_id";
            dropState.DataBind();
            dropState.Items.Insert(0, "--Select State--");

            //SqlStr = "Select distinct country_id,Country from Country where Country is not null and Country <> '' order by Country";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "CountryView");
            dropCountry.DataSource = AcmastDataSet.Tables["CountryView"];  
            dropCountry.DataTextField = "country";
            dropCountry.DataValueField = "country_id";
            dropCountry.DataBind();
            dropCountry.Items.Insert(0, "--Select Country--");

            // Fill dropdownlist of CityMaster
            dropCityCountry.DataSource = AcmastDataSet.Tables["CountryView"];
            dropCityCountry.DataTextField = "country";
            dropCityCountry.DataValueField = "country_id";
            dropCityCountry.DataBind();
            dropCityCountry.Items.Insert(0, "--Select Country--");

            dropCityState.DataSource = AcmastDataSet.Tables["StateView"];
            dropCityState.DataTextField = "state";
            dropCityState.DataValueField = "state_id";
            dropCityState.DataBind();
            dropCityState.Items.Insert(0, "--Select State--");
            // End

            // Fill dropdownlist of StateMaster
            dropStateCountry.DataSource = AcmastDataSet.Tables["CountryView"];
            dropStateCountry.DataTextField = "country";
            dropStateCountry.DataValueField = "country_id";
            dropStateCountry.DataBind();
            dropStateCountry.Items.Insert(0, "--Select Country--");
            // End

            //SqlStr = "select sm_name as SalesMan from salesman order by sm_name";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "SaleManView");
            dropSalesMan.DataSource = AcmastDataSet.Tables["SaleManView"];
            dropSalesMan.DataTextField = "SalesMan";
            dropSalesMan.DataValueField = "SalesMan";
            dropSalesMan.DataBind();
            dropSalesMan.Items.Insert(0, "--Select Salesman--");

            //SqlStr = "Select Distinct code,[Name],'' As AddFld From SERTax_Mast Order By [Name]";
            //AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "SerTaxView");
            dropNatureSer.DataSource = AcmastDataSet.Tables["SerTaxView"];
            dropNatureSer.DataTextField = "name";
            dropNatureSer.DataValueField = "name";
            dropNatureSer.DataBind();
            dropNatureSer.Items.Insert(0, "--Select Service--");
             
        }

        protected void txtCityNew_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnCitySave_Click(object sender, EventArgs e)
        {
            if (IsValid == false)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddCity','SHOW');", true);
                return;
            }
            
            SqlStr = "insert into city (city,state_id) values ('" + txtNewCity.Text.ToString().Trim() + "'," +
                     dropCityState.SelectedValue + ")";

            SqlCommand cmd = new SqlCommand();
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;
 
            cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true, ref connHandle);
            try
            {
                cmd.ExecuteNonQuery();
                DataAccess.CommitTransaction(cmd.Transaction);
                lblCityError.Visible = false;
            }
            catch (Exception Ex)
            {
                lblCityError.Visible = true;
                lblCityError.Text = Ex.Message.ToString().Trim();
                DataAccess.RollBackTransaction(cmd.Transaction);
                
            }
            finally
            {
                DataAccess.Connclose(connHandle);
            }

            DataSet AcmastDataSet = SessionProxy.AcmastDataSet;  
            AcmastDataSet.Tables.Remove("CityView");
            SqlStr = "Select distinct city,city_id from city where city is not null AND City <> '' Order By City";
            AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "CityView",connHandle);
            DataAccess.Connclose(connHandle);  
            dropCity.DataSource = AcmastDataSet.Tables["CityView"];
            dropCity.DataTextField = "city";
            dropCity.DataValueField = "city_id";
            dropCity.DataBind();
            dropCity.Items.Insert(0, "--Select City--");

            SessionProxy.AcmastDataSet = AcmastDataSet;
            AcmastDataSet.Dispose();

            dropCityCountry.SelectedIndex = 0;
            dropCityState.SelectedIndex = 0;
            txtNewCity.Text = "";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddCity','HIDE');", true);
            ScriptManager1.SetFocus(dropCity);
            
        }

        protected void validateCity(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custCityValid = ((CustomValidator)(sender));
            SqlStr = "select city,city_id from city where city ='" + txtNewCity.Text + 
                     "' and state_id = " + dropCityState.SelectedValue;
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
            if (dr.HasRows == true)
            {
                custCityValid.ErrorMessage = "City already exist in City Master";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle); 
        }

        protected void btnStateSave_Click(object sender, EventArgs e)
        {
            if (IsValid == false)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddState','SHOW');", true);
                return;
            }

            SqlStr = "insert into state (state,country_id) values ('" + txtNewState.Text.ToString().Trim() + "'," +
                     dropStateCountry.SelectedValue + ")";

            SqlCommand cmd = new SqlCommand();
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
            try
            {
                cmd.ExecuteNonQuery();
                DataAccess.CommitTransaction(cmd.Transaction);
                lblStateError.Visible = false;
            }
            catch (Exception Ex)
            {
                lblStateError.Visible = true;
                lblStateError.Text = Ex.Message.ToString().Trim();
                DataAccess.RollBackTransaction(cmd.Transaction);
            }
            finally
            {
                cmd.Dispose();
                DataAccess.Connclose(connHandle);
            }

            dropStateCountry.SelectedIndex = 0;
            txtNewState.Text = "";

            DataSet AcmastDataSet = SessionProxy.AcmastDataSet;
            AcmastDataSet.Tables.Remove("StateView");
            SqlStr = "Select distinct state_id,state from state where state is not null and state <> '' order by state";
            AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "StateView",connHandle);
            DataAccess.Connclose(connHandle);
 
            dropState.DataSource = AcmastDataSet.Tables["StateView"];
            dropState.DataTextField = "state";
            dropState.DataValueField = "state_id";
            dropState.DataBind();
            dropState.Items.Insert(0, "--Select State--");

            SessionProxy.AcmastDataSet = AcmastDataSet;
            AcmastDataSet.Dispose();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddState','HIDE');", true);
            ScriptManager1.SetFocus(dropState);  
        }

        protected void validateState(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custStateValid = ((CustomValidator)(sender));
            SqlStr = "select state,country_id from state where state ='" + txtNewState.Text +
                     "' and country_id = " + dropStateCountry.SelectedValue;
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
            if (dr.HasRows == true)
            {
                custStateValid.ErrorMessage = "State already exist in State Master";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle);
        }

        protected void btnCountrySave_Click(object sender, EventArgs e)
        {
            if (IsValid == false)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddCountry','SHOW');", true);
                return;
            }

            SqlStr = "insert into Country (Country) values ('" + txtNewCountry.Text.ToString().Trim() + "')";

            SqlCommand cmd = new SqlCommand();
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
            try
            {
                cmd.ExecuteNonQuery();
                DataAccess.CommitTransaction(cmd.Transaction);
                lblCountryError.Visible = false;
            }
            catch (Exception Ex)
            {
                lblCountryError.Visible = true;
                lblCountryError.Text = Ex.Message.ToString().Trim();
                DataAccess.RollBackTransaction(cmd.Transaction);
            }
            finally
            {
                cmd.Dispose();
                DataAccess.Connclose(connHandle);
            }

            txtNewCountry.Text = "";

            DataSet AcmastDataSet = SessionProxy.AcmastDataSet;

            AcmastDataSet.Tables.Remove("CountryView");
            SqlStr = "Select distinct country_id,Country from Country where Country is not null and Country <> '' order by Country";
            AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "CountryView",connHandle);
            DataAccess.Connclose(connHandle);
 
            dropCountry.DataSource = AcmastDataSet.Tables["CountryView"];
            dropCountry.DataTextField = "country";
            dropCountry.DataValueField = "country_id";
            dropCountry.DataBind();
            dropCountry.Items.Insert(0, "--Select Country--");
            SessionProxy.AcmastDataSet = AcmastDataSet;
            AcmastDataSet.Dispose();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddCountry','HIDE');", true);
        }

        protected void validateCountry(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custCountryValid = ((CustomValidator)(sender));
            SqlStr = "select country from country where country ='" + txtNewCountry.Text + "'";
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
            if (dr.HasRows == true)
            {
                custCountryValid.ErrorMessage = "Country already exist in Country Master";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle);
        }

        protected void dropGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlStr = "select * from ac_group_mast where aC_group_name='"
                    + dropGroup.SelectedItem.Text.ToString().Trim() + "'";

            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            DataSet AcmastDataSet = SessionProxy.AcmastDataSet;
            AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "AcGroupView",connHandle);
            DataAccess.Connclose(connHandle);
 
            numericFunction numFunction = new numericFunction();
            string oldAcName = txtAlphaName.Text;
            string oldMailName = txtMailName.Text;
            int updown = numFunction.toInt32(AcmastDataSet.Tables["AcMastView"].Rows[0]["updown"]);
            DataRow acMastRow = AcmastDataSet.Tables["AcMastView"].Rows[0];
            acMastRow = DataAccess.ExactScatterGatherRow(AcmastDataSet.Tables["AcGroupView"].Rows[0],
                        acMastRow);
            acMastRow["updown"] = updown;
            acMastRow["defa_ac"] = false;
            acMastRow["ac_name"] = oldAcName;
            acMastRow["mailname"] = oldMailName;   
            acMastRow.AcceptChanges();
            HideRowsDepGroup();   // Set controls depending upon groups
            bindControls(acMastRow);
            ConditionalBindControls(acMastRow); 
            txtAlphaName.Text = oldAcName;
            txtMailName.Text = oldMailName;
            SessionProxy.AcmastDataSet = AcmastDataSet;
            AcmastDataSet.Dispose();
            ScriptManager1.SetFocus(dropGroup);  
        }

        protected void HideRowsDepGroup()
        {
            if (dropGroup.SelectedIndex == 0)
                return;

            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            // find Fixed Asset Group
            SqlParameter[] param = {
                new SqlParameter("@groupname",SqlDbType.VarChar)};
            param[0].Value = "Fixed Assets";
            SqlDataReader dr = DataAccess.ExecuteDataReader("USP_ENT_GET_ACGROUP", param,ref connHandle);
            bool isFound = false;
            while (dr.Read())
            {
                if (Convert.ToInt32(dr["ac_group_id"]) == Convert.ToInt32(dropGroup.SelectedValue))
                {
                    isFound = true;
                    break;
                }
            }

            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle); 
            if (isFound == true)
            {
                trFixedDetails.Visible = true;
                trCreditDetails.Visible = false;
            }
            else
            {
                trCreditDetails.Visible = true;
                trFixedDetails.Visible = false;
            }

            // find Sundry Creditors amd Debtors Group
            SqlParameter[] paramag = { new SqlParameter("@groupname", SqlDbType.VarChar) };
            paramag[0].Value = "Sundry Creditors,Sundry Debtors";
            dr = DataAccess.ExecuteDataReader("USP_ENT_GET_ACGROUP", paramag,ref connHandle);
            isFound = false;
            while (dr.Read())
            {
                if (Convert.ToInt32(dr["ac_group_id"]) == Convert.ToInt32(dropGroup.SelectedValue))
                {
                    isFound = true;
                    break;
                }
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle);

            if (isFound == true)
            {
                trSaleTaxDetails.Visible = true;
            }
            else
            {
                trSaleTaxDetails.Visible = false;
            }
        }

        protected void bindControls(DataRow acMastRow)
        {
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();
            boolFunction bitFunction = new boolFunction();

            txtAlphaName.Text = Convert.ToString(acMastRow["ac_name"]);
            txtMailName.Text = Convert.ToString(acMastRow["mailname"]);
            dropGroup.SelectedValue = Convert.ToString(numFunction.toInt32(acMastRow["ac_group_id"]));
            dropType.SelectedValue =  Convert.ToString(numFunction.toInt32(acMastRow["ac_type_id"])) == "0" ?
                "--Select Type--" : Convert.ToString(numFunction.toInt32(acMastRow["ac_type_id"]));
            txtContPerson.Text = Convert.ToString(acMastRow["contact"]);
            txtDesignation.Text = Convert.ToString(acMastRow["designatio"]);
            txtAddress1.Text = Convert.ToString(acMastRow["add1"]);
            txtAddress2.Text = Convert.ToString(acMastRow["add2"]);
            txtAddress3.Text = Convert.ToString(acMastRow["add3"]);
            txtArea.Text = Convert.ToString(acMastRow["area"]);
            txtZone.Text = Convert.ToString(acMastRow["zone"]);
            try
            {
                dropCity.SelectedValue = Convert.ToString(numFunction.toInt32(acMastRow["city_id"])).ToString().Trim() == "0" ?
                        "--Select City--" : Convert.ToString(numFunction.toInt32(acMastRow["city_id"]));
            }
            catch
            {
                dropCity.SelectedIndex = 0;
            }
            txtZip.Text = Convert.ToString(acMastRow["zip"]);
            try
            {
                dropState.SelectedValue = Convert.ToString(numFunction.toInt32(acMastRow["state_id"])).ToString().Trim() == "0" ?
                    "--Select State--" : Convert.ToString(numFunction.toInt32(acMastRow["state_id"]));
            }
            catch
            {
                dropState.SelectedIndex = 0;
            }

            try
            {
                dropCountry.SelectedValue = Convert.ToString(numFunction.toInt32(acMastRow["country_id"])).ToString().Trim() == "0" ?
                    "--Select Country--" : Convert.ToString(numFunction.toInt32(acMastRow["country_id"]));
            }
            catch
            {
                dropCountry.SelectedIndex = 0; 
            }
            txtOfficeTel.Text = Convert.ToString(acMastRow["phone"]);
            txtFax.Text = Convert.ToString(acMastRow["fax"]);
            txtResiTel.Text = Convert.ToString(acMastRow["phoner"]);
            txtCellNo.Text = Convert.ToString(acMastRow["mobile"]);
            txtemailID.Text = Convert.ToString(acMastRow["email"]);
            dropSalesMan.SelectedValue = Convert.ToString(acMastRow["salesman"]).ToString().Trim() == "" ?
                "--Select Salesman--" : Convert.ToString(acMastRow["salesman"]);
            txtRateLevel.Text =  Convert.ToString(numFunction.toDecimal(acMastRow["Rate_level"]));
            dropLedPost.SelectedValue = Convert.ToString(acMastRow["posting"]).ToString().Trim() == "" ?
                "Entry by Entry" : Convert.ToString(acMastRow["posting"]);
            chkDeactivate.Checked = bitFunction.toBoolean(acMastRow["ldeactive"]);
            txtDeacDate.Text =  DateFormat.dateformatBR(Convert.ToString(acMastRow["deactfrom"]));
            txtPANNo.Text = Convert.ToString(acMastRow["i_tax"]);
            txtSTnoDate.Text = Convert.ToString(acMastRow["SREGN"]);
            txtSTNotno.Text = Convert.ToString(acMastRow["SerNoti"]);
            dropNatureSer.SelectedValue = Convert.ToString(acMastRow["Serty"]).ToString().Trim() == "" ?
                "--Select Service--" : Convert.ToString(acMastRow["Serty"]);
            chkExempted.Checked = bitFunction.toBoolean(acMastRow["SerExmptd"]); 
        }

        protected void ConditionalBindControls(DataRow acMastRow)
        {
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();
            boolFunction bitFunction = new boolFunction();

            if (trCreditDetails.Visible == true)
            {
                txtCrDays.Text = Convert.ToString(numFunction.toDecimal(acMastRow["cr_days"]));
                txtCrLimit.Text = Convert.ToString(numFunction.toDecimal(acMastRow["cramount"]));
                chkCrLimitAllow.Checked = bitFunction.toBoolean(acMastRow["crallow"]);
                txtIntRate.Text = Convert.ToString(numFunction.toDecimal(acMastRow["i_rate"]));
                txtPerDays.Text = Convert.ToString(numFunction.toDecimal(acMastRow["i_days"]));
            }
            else
            {
                if (trFixedDetails.Visible == true)
                {
                    txtFixDepRate.Text = Convert.ToString(numFunction.toDecimal(acMastRow["i_rate"]));
                }
            }

            if (trBankDetails.Visible == true)
            {
                txtBnkBranch.Text = Convert.ToString(acMastRow["s_tax"]);
                txtBnkAcNo.Text = Convert.ToString(acMastRow["c_tax"]);
                txtBSRCode.Text = Convert.ToString(acMastRow["BSrcode"]);
            }
            else
            {
                if (trSaleTaxDetails.Visible == true)
                {
                    txtSaleTaxNo.Text = Convert.ToString(acMastRow["s_tax"]);
                    txtCSTno.Text = Convert.ToString(acMastRow["c_tax"]);
                    dropSaleTaxType.SelectedValue = Convert.ToString(acMastRow["st_type"]).ToString().Trim() == "" ?
                                    "-- Select Sales Tax Type --" : Convert.ToString(acMastRow["st_type"]);
                }
                else
                {
                    if (trPettyCashDetails.Visible == true)
                    {
                        txtPettyShortName.Text = Convert.ToString(acMastRow["c_tax"]);
                    }
                }
            }
        }

        protected void dropType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropType.SelectedItem.ToString().Trim().ToUpper().IndexOf("BANK") >= 0)
            {
                trBankDetails.Visible = true;
                trSaleTaxDetails.Visible = false;
                trPettyCashDetails.Visible = false;
            }
            else
            {
                if (dropType.SelectedItem.ToString().Trim().ToUpper().IndexOf("PETTY") >= 0)
                {
                    trBankDetails.Visible = false;
                    trSaleTaxDetails.Visible = false;
                    trPettyCashDetails.Visible = true;
                }
                else
                {
                    trBankDetails.Visible = false;
                    trSaleTaxDetails.Visible = true;
                    trPettyCashDetails.Visible = false;
                }
            }

        }



        protected void btnTopSave_Click(object sender, EventArgs e)
        {
            Save(); // call Save Method
        }

        private void writeXml()
        {
            CL_Gen_Master_WriteXML obj_Master_WriteXML = new CL_Gen_Master_WriteXML();
            DataSet m_Ds = new DataSet();
            m_Ds = obj_Master_WriteXML.writeXmlDS("AC");

            //string xmlPath = Convert.ToString(SessionProxy.Company.Rows[0]["dir_nm"]).Trim() +
            //                 "\\xml\\AcMast.xml";

            //string xmlPath = "\\xml\\AcMast.xml";

            string xmlPath = Convert.ToString(ConfigurationManager.AppSettings["XmlPath"]).Trim() +
                             "\\xml\\AcMast.xml";
            
            //m_Ds.WriteXml(Server.MapPath(xmlPath));

            m_Ds.WriteXml(xmlPath);
            if (m_Ds != null)
                m_Ds.Dispose();
        }

        protected void BindSave(ref DataSet AcmastDataSet)
        {
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            if (AddMode == true && EditMode == false)
            {
                SqlStr = "select ac_name from ac_mast where ac_name='" + txtAlphaName.Text + "'";
                dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                if (dr.HasRows == true)
                {
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);
                    throw new Exception("Account already exist in Account master");
                }
                dr.Close();
                DataAccess.Connclose(connHandle);
            }

            getDateFormat DateFormat = new getDateFormat();
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            DataTable lother = AcmastDataSet.Tables["Lother"];
            DataRow acMastRow = AcmastDataSet.Tables["AcmastView"].Rows[0];
            acMastRow["ac_name"] = Convert.ToString(txtAlphaName.Text).Trim();
            acMastRow["mailname"] = Convert.ToString(txtMailName.Text).Trim() == "" ?
                Convert.ToString(txtAlphaName.Text).Trim() : Convert.ToString(txtMailName.Text).Trim();
            acMastRow["ac_group_id"] = dropGroup.SelectedIndex != 0 ? numFunction.toInt32(dropGroup.SelectedValue) : 0;
            acMastRow["group"] = dropGroup.SelectedIndex != 0 ? Convert.ToString(dropGroup.SelectedItem).Trim() : "";
            //acMastRow["ac_type_id"] = dropType.SelectedIndex != 0 ? numFunction.toInt32(dropType.SelectedValue) : 0;
            if (dropType.SelectedIndex == 0)
            {
                try
                {
                    ListItem dropitem = new ListItem();
                    dropitem = dropType.Items.FindByText("");
                    acMastRow["ac_type_id"] = dropitem.Value;
                }
                catch (Exception Ex)
                {
                    throw new Exception("Error, Empty value not found in Account type  master," + 
                        Ex.Message.Trim()); 
                }
            }
            acMastRow["contact"] = Convert.ToString(txtContPerson.Text);
            acMastRow["designatio"] = Convert.ToString(txtDesignation.Text);
            acMastRow["add1"] = Convert.ToString(txtAddress1.Text);
            acMastRow["add2"] = Convert.ToString(txtAddress2.Text);
            acMastRow["add3"] = Convert.ToString(txtAddress3.Text);
            acMastRow["area"] = Convert.ToString(txtArea.Text);
            acMastRow["zone"] = Convert.ToString(txtZone.Text);
            // add city
            int cityId = 0;
            if (dropCity.SelectedIndex != 0)
                acMastRow["city_id"] = numFunction.toInt32(dropCity.SelectedValue);
            else
            {
                SqlStr = "select * from city where rtrim(ltrim(city))=''";
                dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                    {
                        cityId = numFunction.toInt32(dr["city_id"]);
                    }
                }
                else
                {
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);

                    SqlStr = "insert into city(city) values ('')";
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        DataAccess.CommitTransaction(cmd.Transaction);
                        lblCityError.Visible = false;
                    }
                    catch (Exception Ex)
                    {
                        lblCityError.Visible = true;
                        lblCityError.Text = Ex.Message.ToString().Trim();
                        DataAccess.RollBackTransaction(cmd.Transaction);
                    }
                    finally
                    {
                        DataAccess.Connclose(connHandle);
                    }
                    SqlStr = "select ident_current('Country') as cnCode";
                    dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            cityId = numFunction.toInt32(dr["cnCode"]);
                        }
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);
                }
                dr.Close();
                dr.Dispose();
                DataAccess.Connclose(connHandle);
                acMastRow["city_id"] = cityId; 
            }
            
            acMastRow["city"] = dropCity.SelectedIndex != 0 ? Convert.ToString(dropCity.SelectedItem) : "";
            acMastRow["zip"] = Convert.ToString(txtZip.Text);

            // add state
            int stateId = 0;
            if (dropState.SelectedIndex != 0)
                acMastRow["state_id"] = numFunction.toInt32(dropState.SelectedValue);
            else
            {
                SqlStr = "select * from state where rtrim(ltrim(state))=''";
                dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                    {
                        stateId = numFunction.toInt32(dr["state_id"]);
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);
                }
                else
                {
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);

                    SqlStr = "insert into state (state) values ('')";
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        DataAccess.CommitTransaction(cmd.Transaction);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        throw Ex;
                    }
                    finally
                    {
                        cmd.Dispose();
                        DataAccess.Connclose(connHandle);
                    }

                    SqlStr = "select ident_current('state') as cnCode";
                    dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            stateId = numFunction.toInt32(dr["cnCode"]);
                        }
                    
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);
                }

                dr.Close();
                dr.Dispose();
                DataAccess.Connclose(connHandle);
                acMastRow["state_id"] = stateId;
            }
            acMastRow["state"] = dropState.SelectedIndex != 0 ? Convert.ToString(dropState.SelectedItem).Trim() : "";

            // add country
            int countryId = 0;
            if (dropCountry.SelectedIndex != 0)
                acMastRow["country_id"] = numFunction.toInt32(dropCountry.SelectedValue);
            else
            {
                SqlStr = "select * from country where rtrim(ltrim(country))=''";
                dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                    {
                        countryId = numFunction.toInt32(dr["country_id"]);
                    }
                }
                else
                {
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);

                    SqlStr = "insert into country (country) values ('')";
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        DataAccess.CommitTransaction(cmd.Transaction);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        DataAccess.Connclose(connHandle);
                        throw Ex;
                    }
                    SqlStr = "select ident_current('country') as cnCode";
                    dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            countryId = numFunction.toInt32(dr["cnCode"]);
                        }
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAccess.Connclose(connHandle);
                }
                dr.Close();
                dr.Dispose();
                DataAccess.Connclose(connHandle);
                acMastRow["country_id"] = countryId;
            }
          
            acMastRow["country"] = dropCountry.SelectedIndex != 0 ? Convert.ToString(dropCountry.SelectedItem) : "";
            acMastRow["phone"] = Convert.ToString(txtOfficeTel.Text);
            acMastRow["fax"] = Convert.ToString(txtFax.Text);
            acMastRow["phoner"] = Convert.ToString(txtResiTel.Text);
            acMastRow["mobile"] = Convert.ToString(txtCellNo.Text);
            acMastRow["email"] = Convert.ToString(txtemailID.Text);
            acMastRow["salesman"] = dropSalesMan.SelectedIndex != 0 ? Convert.ToString(acMastRow["salesman"]).Trim() : "";
            acMastRow["Rate_level"] = numFunction.toDecimal(txtRateLevel.Text);
            acMastRow["posting"] = dropLedPost.SelectedIndex !=0 ? Convert.ToString(dropLedPost.SelectedValue) : "Entry by Entry";
            acMastRow["ldeactive"] = chkDeactivate.Checked == true ? 1 : 0;
            if (txtDeacDate.Text.Trim() != "__/__/____")
                acMastRow["deactfrom"] = Convert.ToDateTime(txtDeacDate.Text.ToString());
                //acMastRow["deactfrom"] = DateFormat.dateformat(txtDeacDate.Text.ToString());

            if (trCreditDetails.Visible == true)
            {
                acMastRow["cr_days"] = numFunction.toDecimal(txtCrDays.Text);
                acMastRow["cramount"] = numFunction.toDecimal(txtCrLimit.Text);
                acMastRow["crallow"] = bitFunction.toBoolean(chkCrLimitAllow.Checked);
                acMastRow["i_rate"] = numFunction.toDecimal(txtIntRate.Text);
                acMastRow["i_days"] = numFunction.toDecimal(txtPerDays.Text);
            }
            else
            {
                if (trFixedDetails.Visible == true)
                {
                    acMastRow["i_rate"] = numFunction.toDecimal(txtFixDepRate.Text);
                }
            }


            if (trBankDetails.Visible == true)
            {
                acMastRow["s_tax"] = Convert.ToString(txtBnkBranch.Text);
                acMastRow["c_tax"] = Convert.ToString(txtBnkAcNo.Text);
                acMastRow["BSrcode"] = Convert.ToString(txtBSRCode.Text);
            }
            else
            {
                if (trSaleTaxDetails.Visible == true)
                {
                    acMastRow["s_tax"] = Convert.ToString(txtSaleTaxNo.Text);
                    acMastRow["c_tax"] = Convert.ToString(txtCSTno.Text);
                    acMastRow["st_type"] = dropSaleTaxType.SelectedIndex != 0 ? Convert.ToString(dropSaleTaxType.SelectedValue).ToString().Trim() : "";
                }
                else
                {
                    if (trPettyCashDetails.Visible == true)
                    {
                        acMastRow["c_tax"] = Convert.ToString(txtPettyShortName.Text);
                    }
                }
            }

            if (lother.Rows.Count > 0)
            {
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.btnClick(tblAddInfoDetails, acMastRow, "BOXING",null);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }
            acMastRow.AcceptChanges(); 
        }

        protected void checkValidation(ref DataSet AcmastDataSet)
        {
            if (SessionProxy.VChkProd.Trim().IndexOf("vuexc") >= 0 &&
                !(SessionProxy.VChkProd.Trim().IndexOf("vuent") >= 0 ||
                  SessionProxy.VChkProd.Trim().IndexOf("vupro") >= 0 ||
                  SessionProxy.VChkProd.Trim().IndexOf("vuinv") >= 0))
            {
                DataTier DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName;

                SqlParameter[] param = {
                new SqlParameter("@groupname",SqlDbType.VarChar)};
                param[0].Value = "Sundry Creditors";
                SqlDataReader dr = DataAccess.ExecuteDataReader("USP_ENT_GET_ACGROUP", param,ref connHandle);
                bool isFound = false;
                while (dr.Read())
                {
                    if (Convert.ToInt32(dr["ac_group_id"]) == Convert.ToInt32(dropGroup.SelectedValue))
                    {
                        isFound = true;
                        break;
                    }
                }
                dr.Close();
                dr.Dispose();
                DataAccess.Connclose(connHandle);
                if (isFound == true)
                {
                    if (Convert.ToString(AcmastDataSet.Tables["AcMastView"].Rows[0]["vend_type"]).Trim() == "")
                        throw new Exception("Vendor type cannot be blank");
                }

            }

            if (Convert.ToString(AcmastDataSet.Tables["AcMastView"].Rows[0]["ac_name"]).Trim() == "")
            {
                throw new Exception("Alpha name cannot be blank");
            }

            if (Convert.ToString(AcmastDataSet.Tables["AcMastView"].Rows[0]["mailname"]).Trim() == "")
            {
                throw new Exception("Mailname name cannot be blank");
            }

            if (Convert.ToString(AcmastDataSet.Tables["AcMastView"].Rows[0]["group"]).Trim() == "")
            {
                throw new Exception("Group cannot be blank");
            }

            if (Convert.ToString(AcmastDataSet.Tables["AcMastView"].Rows[0]["type"]).Trim() != "")
            {
                if (Convert.ToString(AcmastDataSet.Tables["AcMastView"].Rows[0]["type"]).Trim() == "PETTY EXP." &&
                    Convert.ToString(AcmastDataSet.Tables["AcMastView"].Rows[0]["c_tax"]).Trim() == "")
                {
                    throw new Exception("Short name cannot be blank");
                }
            }

            if (chkDeactivate.Checked == true && txtDeacDate.Text == "__/__/____")
            {
                ScriptManager1.SetFocus(txtDeacDate);  
                throw new Exception("Deactivate date cannot be blank");
            }
        }

        protected void Save()
        {
            try
            {
                DataSet AcmastDataSet = SessionProxy.AcmastDataSet;
                BindSave(ref AcmastDataSet);
                
                checkValidation(ref AcmastDataSet);
                DataTier DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName;

                CL_Gen_Master_WriteXML obj_Master_WriteXML = new CL_Gen_Master_WriteXML(); 

                if (EditMode == true)
                {
                    SqlStr = DataAccess.GenUpdateString(AcmastDataSet.Tables["AcMastView"], "ac_mast",
                                                new string[] { "ac_id" }, null, "", new string[] { "ac_id" });
                }
                else
                {
                    if (AddMode == true)
                    {
                        SqlStr = DataAccess.GenInsertString(AcmastDataSet.Tables["AcMastView"].Rows[0], "ac_mast",
                                                    new string[] { "ac_id" }, null);
                    }
                }

                if (SqlStr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        DataAccess.CommitTransaction(cmd.Transaction);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        throw Ex;
                    }
                    finally
                    {
                        cmd.Dispose();
                        DataAccess.Connclose(connHandle);
                    }
                    tblError.Visible = false;
                    if (AcmastDataSet != null)
                        AcmastDataSet.Dispose(); 
                    //SessionProxy.AcmastDataSet = null;
                    writeXml(); 
                    Response.Redirect("uwAcMasterview.aspx?ShowStatus=true");
                }
            }
            catch (Exception Ex)
            {
                tblError.Visible = true;
                lblErrorHeading.Text  = "Please Check Error details below";
                lblErrorDetails.Text = Ex.Message; 
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message  + "');", true);
            }
        }

        protected void btnAccTypeSave_Click(object sender, EventArgs e)
        {
            if (IsValid == false)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddAccType','SHOW');", true);
                return;
            }

            SqlStr = "insert into ac_type_mast (typ) values ('" + txtNewAccType.Text.ToString().Trim() + "')";

            SqlCommand cmd = new SqlCommand();
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
            try
            {
                cmd.ExecuteNonQuery();
                DataAccess.CommitTransaction(cmd.Transaction);
                lblAccTypeError.Visible = false;
            }
            catch (Exception Ex)
            {
                lblAccTypeError.Visible = true;
                lblAccTypeError.Text = Ex.Message.ToString().Trim();
                DataAccess.RollBackTransaction(cmd.Transaction);
            }
            finally
            {
                DataAccess.Connclose(connHandle);
            }


            txtNewAccType.Text = "";
            DataSet AcmastDataSet = SessionProxy.AcmastDataSet;
            AcmastDataSet.Tables.Remove("TypeView");
            SqlStr = "select ac_type_id,typ as TypeName from AC_TYPE_MAST order by typ";
            AcmastDataSet = DataAccess.ExecuteDataset(AcmastDataSet, SqlStr, "TypeView",connHandle);
            DataAccess.Connclose(connHandle);

            dropType.DataSource = AcmastDataSet.Tables["TypeView"];
            dropType.DataTextField = "typename";
            dropType.DataValueField = "ac_type_id";
            dropType.DataBind();
            dropType.Items.Insert(0, "--Select Type--");

            SessionProxy.AcmastDataSet = AcmastDataSet;
            AcmastDataSet.Dispose();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddCountry','HIDE');", true);
        }

        protected void validateAccType(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custAccTypeValid = ((CustomValidator)(sender));
            SqlStr = "select typ from ac_type_mast where typ ='" + txtNewAccType.Text + "'";
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
            if (dr.HasRows == true)
            {
                custAccTypeValid.ErrorMessage = "Account type already exist in Account Type Master";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle);
        }

        protected void lnkBtnBack_Click(object sender, EventArgs e)
        {
            SessionProxy.AcmastDataSet = null; 
            Response.Redirect("uwAcMasterview.aspx");
            //Server.Transfer("uwAcMasterview.aspx");
        }
    }
}
