using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Business.Logic.Layer;  


namespace Udyog.E.Billing
{
    public partial class uwItemMaster : System.Web.UI.Page
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        SqlConnection connHandle;
        //DataTier DataAccess;
        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }

        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private int itemId;
        public int ItemId
        {
            get { return itemId; }
            set { itemId = value; }
        }

        private string itemGroup;
        public string ItemGroup
        {
            get { return itemGroup; }
            set { itemGroup = value; }
        }

        private string vchkprod;
        public string Vchkprod
        {
            get { return vchkprod; }
            set { vchkprod = value; }
        }

        SqlDataReader dr;
        private string SqlStr = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet ItmastDataSet = new DataSet(); 
            if (IsPostBack == true)
            {
                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                ItemId = Convert.ToInt32(Request.QueryString["ItemId"]);
                ItemGroup = Convert.ToString(Request.QueryString["ItemGroupType"]);

                ItmastDataSet = SessionProxy.ItmastDataSet;  
                if (ItmastDataSet.Tables["lother"].Rows.Count > 0)
                {
                    DataView xtra_vw = ItmastDataSet.Tables["lother"].DefaultView;
                    xtra_vw.Sort = "Serial";
                    vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                    try
                    {
                        vuAddInfo.genControls(xtra_vw,
                                ItmastDataSet.Tables["Itmastview"].Rows[0], tblAddInfoDetails);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                }
                return;
            }

            // Get Parameters from Previous Page
            AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
            ItemId =  Convert.ToInt32(Request.QueryString["ItemId"]);
            ItemGroup = Convert.ToString(Request.QueryString["ItemGroupType"]);

            hidProd.Value = SessionProxy.VChkProd ;
            ItmastDataSet = new DataSet(); 
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;
   
            lblTrType.Text = "Item Master"; 

            SqlParameter[] param = {
                new SqlParameter("@addMode",SqlDbType.Bit),
                new SqlParameter("@editMode",SqlDbType.Bit),
                new SqlParameter("@itId",SqlDbType.Int)};

            param[0].Value = AddMode;
            param[1].Value = EditMode;
            param[2].Value = ItemId;

            ArrayList dblist = new ArrayList();
            dblist.Add("TypeView");
            dblist.Add("UomView");
            dblist.Add("ItMastView");
            if (EditMode == true)
            {
                dblist.Add("ItBalView");
            }
            dblist.Add("lother");

            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, "sp_ent_web_itMast_Init",
                                            param,
                                            dblist,connHandle);

            //getCompany GetCompany = new getCompany();
            //ItmastDataSet = GetCompany.Company(ItmastDataSet, Session["ReqCode"].ToString().Trim()
            //                , Session["Finyear"].ToString().Trim());

            fillDropDowns(ItmastDataSet);
            if (AddMode == true)
            {
                addRec(ref ItmastDataSet);
            }
            else
            {
                if (EditMode == true)
                {
                    editRec(ItmastDataSet);
                }
            }

            //SqlStr = "Select * from lother where e_code='IM' order by serial";
            //ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, SqlStr, "lother");
            //DataAccess.Connclose();

            if (ItmastDataSet.Tables["lother"].Rows.Count > 0)
            {
                DataView xtra_vw = ItmastDataSet.Tables["lother"].DefaultView;
                xtra_vw.Sort = "Serial";
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.genControls(xtra_vw,
                            ItmastDataSet.Tables["Itmastview"].Rows[0], tblAddInfoDetails);  
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }

            dropStkUnit.Attributes.Add("onchange", "javascript:SelectUnit()");

            SessionProxy.ItmastDataSet = ItmastDataSet;
            ItmastDataSet.Dispose();
            ScriptManager1.SetFocus(txtItemName);  
        }

        protected void addRec(ref DataSet ItmastDataSet)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            DataRow ItMastRow = ItmastDataSet.Tables["ItMastView"].NewRow();
            ItMastRow["rateper"] = 1;
            ItMastRow["prate"] = 1;
            ItMastRow["ratio"] = 1;
            ItMastRow["rateunit"] = "PCS";
            ItMastRow["rate"] = 0;
            ItMastRow["curr_cost"] = 0;
            ItMastRow["NonStk"] = "Stockable";
            ItMastRow["in_stkval"] = true;

            DataNullUpdate.NullUpdate(ItMastRow);
            ItmastDataSet.Tables["ItMastView"].Rows.Add(ItMastRow);
            ItmastDataSet.Tables["ItMastView"].AcceptChanges();

            boolFunction bitFunction = new boolFunction();
            txtSaleRatePer.Text = Convert.ToString(ItMastRow["rateper"]);
            txtPTRatePer.Text = Convert.ToString(ItMastRow["prate"]);
            txtConvRatio.Text = Convert.ToString(ItMastRow["ratio"]);
            dropStkUnit.SelectedValue = Convert.ToString(ItMastRow["rateunit"]).Trim().ToUpper();
            txtSaleRate.Text = Convert.ToString(ItMastRow["rate"]);
            txtPTRate.Text = Convert.ToString(ItMastRow["curr_cost"]);
            dropStockType.SelectedValue = Convert.ToString(ItMastRow["nonStk"]);
            chkStkVal.Checked = bitFunction.toBoolean(ItMastRow["in_stkval"]);

            txtSaleToAcc.Text = "SALES";
            txtPTAcc.Text = "PURCHASES";

            if (bitFunction.toBoolean(SessionProxy.Company.Rows[0]["s_item"]) == true)
                txtSaleToAcc.Enabled = true;
            else
            {
                txtSaleToAcc.Text = "SALES";
                txtSaleToAcc.Enabled = false;
            }

            if (bitFunction.toBoolean(SessionProxy.Company.Rows[0]["p_item"]) == true)
                txtPTAcc.Enabled = true;
            else
            {
                txtPTAcc.Text = "PURCHASES";
                txtPTAcc.Enabled = false;
            }

            if (SessionProxy.VChkProd.Trim().IndexOf("vuexc") >= 0)
            {
                dropType.SelectedValue = "Raw Material";
            }
            else
            {
                if (SessionProxy.VChkProd.Trim().IndexOf("vuexc") >= 0)
                {
                    dropType.SelectedValue = "Trading";
                }
                else
                {
                    dropType.SelectedValue = "Raw Material";
                }
            }

            dropStkUnit.SelectedValue = "PCS";
            dropPTUnit.SelectedValue = "PCS";
            dropSaleUnit.SelectedValue = "PCS";

            ScriptManager1.SetFocus(txtItemName);  

        }

        protected void editRec(DataSet ItmastDataSet)
        {
            numericFunction numFunction = new numericFunction();
            bindControls(ItmastDataSet.Tables["ItMastView"].Rows[0],true);
            if (EditMode == true)
            {
                txtItemName.Enabled = false;
            }

            bool isStock = false;
            foreach (DataRow itMastRow in ItmastDataSet.Tables["ItBalView"].Rows)
            {
                for (int i = 4; i < ItmastDataSet.Tables["ItBalView"].Columns.Count; i++)
                {
                    if (numFunction.toDecimal(itMastRow[i]) != 0)
                    {
                        isStock = true;
                        break;
                    }
                }
            }

            //SqlStr = "select * from it_bal where it_code=" + ItemId;
            //dr = DataAccess.ExecuteDataReader(SqlStr);
            //numericFunction numFunction = new numericFunction();
            //bool isStock = false;
            //if (dr.HasRows == true)
            //{
            //    while (dr.Read())
            //    {
            //        for (int i = 4; i < dr.VisibleFieldCount; i++)
            //        {
            //            if (numFunction.toDecimal(dr[i]) != 0)
            //            {
            //                isStock = true;
            //                break;
            //            }
            //        }
            //    }
            //}
            //dr.Close();
            //dr.Dispose();

            if (isStock == true)
            {
                dropStockType.Enabled = false; 
            }
        }

        protected void fillDropDowns(DataSet ItmastDataSet)
        {
            //SqlStr = "select ittyid,type as TypeName from item_type order by type";
            //ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, SqlStr, "TypeView");
            dropType.DataSource = ItmastDataSet.Tables["TypeView"];  
            dropType.DataTextField = "typename";
            dropType.DataValueField = "ittyid";
            dropType.DataBind();
            dropType.Items.Insert(0, "--Select Type--");

            //SqlStr = "Select upper(ltrim(rtrim(u_uom))) as u_uom from UOM order by u_uom";
            //ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, SqlStr, "UomView");
            dropStkUnit.DataSource = ItmastDataSet.Tables["UomView"];
            dropStkUnit.DataTextField = "u_uom";
            dropStkUnit.DataValueField = "u_uom";
            dropStkUnit.DataBind();
            dropStkUnit.Items.Insert(0, "--Select Unit--");

            dropPTUnit.DataSource = ItmastDataSet.Tables["UomView"];
            dropPTUnit.DataTextField = "u_uom";
            dropPTUnit.DataValueField = "u_uom";
            dropPTUnit.DataBind();
            dropPTUnit.Items.Insert(0, "--Select Unit--");

            dropSaleUnit.DataSource = ItmastDataSet.Tables["UomView"];
            dropSaleUnit.DataTextField  = "u_uom";
            dropSaleUnit.DataValueField = "u_uom";
            dropSaleUnit.DataBind();
            dropSaleUnit.Items.Insert(0, "--Select Unit--");
        }

        protected void btnUnitSave_Click(object sender, EventArgs e)
        {
            if (IsValid == false)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddUnit','SHOW');", true);
                return;
            }

            DataSet ItmastDataSet = (DataSet)Session["ItMastDataSet"];
            SqlStr = "insert into Uom (u_uom,e_uom) values ('" + txtNewUnit.Text.ToString().Trim().ToUpper()  + "','" +
                     txtNewExUnit.Text.ToString().Trim().ToUpper()   + "')";

            SqlCommand cmd = new SqlCommand();
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
            try
            {
                cmd.ExecuteNonQuery();
                DataAccess.CommitTransaction(cmd.Transaction);
                lblUnitError.Visible = false;
            }
            catch (Exception Ex)
            {
                lblUnitError.Visible = true;
                lblUnitError.Text = Ex.Message.ToString().Trim();
                DataAccess.RollBackTransaction(cmd.Transaction);
                DataAccess.Connclose(connHandle);
            }
           
            ItmastDataSet.Tables.Remove("UomView");

            SqlStr = "Select upper(ltrim(rtrim(u_uom))) as u_uom from UOM order by u_uom";
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, SqlStr, "UomView",connHandle);
            DataAccess.Connclose(connHandle);  

            dropStkUnit.DataSource = ItmastDataSet.Tables["UomView"];
            dropStkUnit.DataTextField = "u_uom";
            dropStkUnit.DataValueField = "u_uom";
            dropStkUnit.DataBind();
            dropStkUnit.Items.Insert(0, "--Select Unit--");

            dropPTUnit.DataSource = ItmastDataSet.Tables["UomView"];
            dropPTUnit.DataTextField = "u_uom";
            dropPTUnit.DataValueField = "u_uom";
            dropPTUnit.DataBind();
            dropPTUnit.Items.Insert(0, "--Select Unit--");

            dropSaleUnit.DataSource = ItmastDataSet.Tables["UomView"];
            dropSaleUnit.DataTextField = "u_uom";
            dropSaleUnit.DataValueField = "u_uom";
            dropSaleUnit.DataBind();
            dropSaleUnit.Items.Insert(0, "--Select Unit--");

            txtNewExUnit.Text = "";
            txtNewUnit.Text = ""; 
            Session["ItMastDataSet"] = ItmastDataSet;
            ItmastDataSet.Dispose();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddUnit','HIDE');", true);
            ScriptManager1.SetFocus(dropStkUnit);  
        }

        protected void validateUnit(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custUnitValid = ((CustomValidator)(sender));
            SqlStr = "select u_uom from uom where u_uom ='" + txtNewUnit.Text + "'";
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
            if (dr.HasRows == true)
            {
                custUnitValid.ErrorMessage = "Unit already exist in Unit Master";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle); 
        }

        protected void btnItemTypeSave_Click(object sender, EventArgs e)
        {
            if (IsValid == false)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddItemType','SHOW');", true);
                return;
            }

            SqlStr = "insert into Item_type (type) values ('" + txtNewItemType.Text.ToString().Trim() + "')";
            
            SqlCommand cmd = new SqlCommand();
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true, ref connHandle);
            try
            {
                cmd.ExecuteNonQuery();
                DataAccess.CommitTransaction(cmd.Transaction);
                DataAccess.Connclose(connHandle);
                lblItemTypeError.Visible = false;
            }
            catch (Exception Ex)
            {
                lblItemTypeError.Visible = true;
                lblItemTypeError.Text = Ex.Message.ToString().Trim();
                DataAccess.RollBackTransaction(cmd.Transaction);
                DataAccess.Connclose(connHandle);
            }

            txtNewItemType.Text = "";
            DataSet ItmastDataSet = (DataSet)Session["ItMastDataSet"];
            ItmastDataSet.Tables.Remove("TypeView");

            SqlStr = "select ittyid,type as TypeName from item_type order by type";
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, SqlStr, "TypeView",connHandle);
            DataAccess.Connclose(connHandle);
            dropType.DataSource = ItmastDataSet.Tables["TypeView"];
            dropType.DataTextField = "typename";
            dropType.DataValueField = "ittyid";
            dropType.DataBind();
            dropType.Items.Insert(0, "--Select Type--");

            Session["ItMastDataSet"] = ItmastDataSet;
            ItmastDataSet.Dispose(); 
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ShowHidetableRow('trAddItemType','HIDE');", true);
            ScriptManager1.SetFocus(dropType);  
        }

        protected void validateItemType(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custItemTypeValid = ((CustomValidator)(sender));
            SqlStr = "select type from item_type where type ='" + txtNewItemType.Text + "'";

            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
            if (dr.HasRows == true)
            {
                custItemTypeValid.ErrorMessage = "Item type already exist in Type Master";
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle);
        }

        protected void txtGroup_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlStr = "select * from item_group where it_group_name='"
                        + txtGroup.Text.ToString().Trim() + "'";

                DataTier DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName;

                DataSet ItmastDataSet = (DataSet)Session["ItMastDataSet"];
                ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, SqlStr, "ItGroupView",connHandle);
                DataAccess.Connclose(connHandle);

                if (ItmastDataSet.Tables["ItGroupView"].Rows.Count == 0)
                {
                    ScriptManager1.SetFocus(txtGroup);
                    txtGroup.Text = "";
                    throw new Exception("Item group not found in group master");
                }

                string oldItName = txtItemName.Text;
                DataRow itMastRow = ItmastDataSet.Tables["ItMastView"].Rows[0];
                itMastRow = DataAccess.ExactScatterGatherRow(ItmastDataSet.Tables["ItGroupView"].Rows[0],
                            itMastRow);

                itMastRow.AcceptChanges();
                ItmastDataSet.Tables["ItMastView"].AcceptChanges();
                //HideRowsDepGroup();   // Set controls depending upon groups
                bindControls(itMastRow, false);
                txtItemName.Text = oldItName;
                Session["ItMastDataSet"] = ItmastDataSet;
                ItmastDataSet.Dispose();
                
                ScriptManager1.SetFocus(txtGroup);
            }
            catch (Exception Ex)
            {
                tblError.Visible = true;
                lblErrorHeading.Text = "Please Check Error details below";
                lblErrorDetails.Text = Ex.Message;
            }
        }


        protected void bindControls(DataRow ItMastRow, bool isGroup)
        {
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();
            boolFunction bitFunction = new boolFunction();

            txtItemName.Text = Convert.ToString(ItMastRow["it_name"]);
            if (isGroup == true)
                txtGroup.Text = Convert.ToString(ItMastRow["group"]) == "" ?
                    "" : Convert.ToString(ItMastRow["group"]);

            dropType.SelectedValue =  Convert.ToString(numFunction.toInt32(ItMastRow["ittyid"])) == "0" ?
                "--Select Type--" : Convert.ToString(numFunction.toInt32(ItMastRow["ittyid"]));
            txtDesc.Text = Convert.ToString(ItMastRow["it_desc"]);
            dropStkUnit.SelectedValue = Convert.ToString(ItMastRow["rateunit"]).Trim()=="" ?
                     "--Select Unit--" : Convert.ToString(ItMastRow["rateunit"]).Trim().ToUpper();
            txtConvRatio.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["ratio"]));
            txtRemark.Text = Convert.ToString(ItMastRow["remark"]);
            dropStockType.SelectedValue = Convert.ToString(ItMastRow["nonstk"]).Trim()=="" ?
            "--Select Stock Type--" : Convert.ToString(ItMastRow["nonstk"]).Trim();
            chkStkVal.Checked = bitFunction.toBoolean(ItMastRow["in_stkval"]);
            chkDeActivate.Checked = bitFunction.toBoolean(ItMastRow["ldeactive"]);
            txtDeacDate.Text = DateFormat.dateformatBR(Convert.ToString(ItMastRow["deactfrom"]));
            if (Convert.ToString(ItMastRow["sac_nm"]).Trim() != "")
            {
                string accountName = Convert.ToString(ItMastRow["sac_nm"]).Trim();
                accountName = accountName.Remove(accountName.IndexOf('"'), 1);
                accountName = accountName.Remove(accountName.LastIndexOf('"'), 1);
                txtSaleToAcc.Text = accountName.Trim();
            }
            else
            {
                txtSaleToAcc.Text = "";
            }

            dropSaleUnit.SelectedValue = Convert.ToString(ItMastRow["p_unit"]).Trim()=="" ? "--Select Unit--"
                : Convert.ToString(ItMastRow["s_unit"]).Trim().ToUpper();
            txtSaleRate.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["rate"]));
            txtSaleRatePer.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["rateper"]));

            if (Convert.ToString(ItMastRow["pac_nm"]).Trim() != "")
            {
                string accountName = Convert.ToString(ItMastRow["pac_nm"]).Trim();
                accountName = accountName.Remove(accountName.IndexOf('"'), 1);
                accountName = accountName.Remove(accountName.LastIndexOf('"'), 1);
                txtPTAcc.Text = accountName.Trim();
            }
            else
            {
                txtPTAcc.Text = "";
            }

            dropPTUnit.SelectedValue = Convert.ToString(ItMastRow["p_unit"]).Trim()=="" ? "--Select Unit--" :
                Convert.ToString(ItMastRow["p_unit"]).ToUpper();
            txtPTRate.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["curr_cost"]));
            txtSaleRatePer.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["prate"]));
            txtPTOrdLvl.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["reorder"]));   
        }

       
        protected void btnTopSave_Click(object sender, EventArgs e)
        {
            if (IsValid == true)
            {
                try
                {
                    Save(); // call Save Method
                    writeXml(); 
                    tblError.Visible = false;
                    SessionProxy.ItmastDataSet = null;
                    Response.Redirect("uwItemMasterView.aspx?ShowStatus=true");

                }
                catch (Exception Ex)
                {
                    tblError.Visible = true;
                    lblErrorHeading.Text = "Please Check Error details below";
                    lblErrorDetails.Text = Ex.Message;
                }
            }

        }

        protected void BindSave(DataRow ItMastRow,
                DataSet ItmastDataSet)
        {
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            if (AddMode == true && EditMode == false)
            {
                SqlStr = "select it_name from it_mast where it_name='" + txtItemName.Text + "'";
                dr = DataAccess.ExecuteDataReader(SqlStr, ref connHandle);
                if (dr.HasRows == true)
                {
                    dr.Close();
                    DataAccess.Connclose(connHandle);
                    throw new Exception("Item already exist in Item master");
                }
                dr.Close();
                DataAccess.Connclose(connHandle);
            }


            getDateFormat DateFormat = new getDateFormat();
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            SqlStr = "select it_group_name as GroupName,itgrid from item_group " +
                    " where it_group_name ='" + txtGroup.Text + "'";
            dr = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
            int itGrid = 0;
            if (dr.HasRows == true)
            {
                while (dr.Read())
                {
                    itGrid = numFunction.toInt32(dr["itgrid"]); 
                }
            }
            dr.Close();
            dr.Dispose();
            DataAccess.Connclose(connHandle);


            ItMastRow["it_name"] = Convert.ToString(txtItemName.Text);
            ItMastRow["itgrid"] = txtGroup.Text.Trim() != "" ? itGrid : 0;
            ItMastRow["group"] = txtGroup.Text.Trim();
            ItMastRow["ittyid"] = dropType.SelectedIndex != 0 ? numFunction.toInt32(ItMastRow["ittyid"]) : 0;
            ItMastRow["it_desc"] = Convert.ToString(txtDesc.Text);
            ItMastRow["rateunit"] = dropStkUnit.SelectedIndex != 0 ? dropStkUnit.SelectedItem.Text.Trim() : "";
            ItMastRow["ratio"] = numFunction.toDecimal(txtConvRatio.Text);
            ItMastRow["remark"] = Convert.ToString(txtRemark.Text);
            ItMastRow["nonstk"] = dropStockType.SelectedIndex != 0 ? dropStockType.SelectedValue : "";
            ItMastRow["in_stkval"] = bitFunction.toBoolean(chkStkVal.Checked);
            ItMastRow["ldeactive"] = bitFunction.toBoolean(chkDeActivate.Checked);
            if (txtDeacDate.Text.Trim() != "__/__/____")
                ItMastRow["deactfrom"] = DateFormat.TodateTime(txtDeacDate.Text);

            if (txtSaleToAcc.Text.Trim() !="")
            {
                string accountName = '"' + txtSaleToAcc.Text.ToString().Trim() + '"';
                ItMastRow["sac_nm"] = accountName.Trim(); 
            }
            ItMastRow["s_unit"] = dropSaleUnit.SelectedItem.ToString().Trim(); 
            ItMastRow["rate"] = numFunction.toDecimal(txtSaleRate.Text);
            ItMastRow["rateper"] = numFunction.toDecimal(txtSaleRatePer.Text);

            if (txtPTAcc.Text != "")
            {
                string accountName = '"' + txtPTAcc.Text.ToString().Trim() + '"';
                ItMastRow["pac_nm"] = accountName.Trim();
            }

            ItMastRow["p_unit"] = Convert.ToString(dropPTUnit.SelectedValue).Trim();
            ItMastRow["curr_cost"] = numFunction.toDecimal(txtPTRate.Text);
            ItMastRow["prate"] = numFunction.toDecimal(txtSaleRatePer.Text);
            ItMastRow["reorder"] = numFunction.toDecimal(txtPTOrdLvl.Text);   
             
            if (ItmastDataSet.Tables["lother"].Rows.Count > 0)
            {
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.btnClick(tblAddInfoDetails, ItMastRow, "BOXING",null);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }
            ItMastRow.AcceptChanges(); 
        }

        protected void checkValidation(DataSet ItmastDataSet)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            if (Convert.ToString(ItmastDataSet.Tables["ItMastView"].Rows[0]["it_name"]).Trim() == "")
            {
                throw new Exception("Item name cannot be blank");
            }

            if (Convert.ToString(ItmastDataSet.Tables["ItMastView"].Rows[0]["NonStk"]).Trim() == "")
            {
                throw new Exception("Stock type cannot be blank");
            }

            if (Convert.ToString(ItmastDataSet.Tables["ItMastView"].Rows[0]["type"]).Trim() == "")
            {
                throw new Exception("Type cannot be blank");
            }

            if (numFunction.toDecimal(ItmastDataSet.Tables["ItMastView"].Rows[0]["rate"]) == 0)
            {
                throw new Exception("Selling Rate cannot be zero");
            }

            if (numFunction.toDecimal(ItmastDataSet.Tables["ItMastView"].Rows[0]["curr_cost"]) == 0)
            {
                throw new Exception("Current cost cannot be zero");
            }

            if (numFunction.toDecimal(ItmastDataSet.Tables["ItMastView"].Rows[0]["reorder"]) == 0)
            {
                throw new Exception("Reorder level cannot be zero");
            }

            if (chkDeActivate.Checked == true && txtDeacDate.Text == "__/__/____")
            {
                ScriptManager1.SetFocus(txtDeacDate);  
                throw new Exception("Deactivate date cannot be blank");
            }

            if (bitFunction.toBoolean(SessionProxy.Company.Rows[0]["s_item"]) == true)
                if (txtSaleToAcc.Text.Trim() == "")
                {
                    ScriptManager1.SetFocus(txtSaleToAcc);  
                    throw new Exception("Select Sales A/c");
                }

            if (bitFunction.toBoolean(SessionProxy.Company.Rows[0]["p_item"]) == true)
                if (txtPTAcc.Text == "")
                {
                    ScriptManager1.SetFocus(txtPTAcc);  
                    throw new Exception("Select Purchase A/c");
                }


            if (Convert.ToString(ItmastDataSet.Tables["ItmastView"].Rows[0]["rateunit"]) == "" ||
                Convert.ToString(ItmastDataSet.Tables["ItmastView"].Rows[0]["s_unit"]) == "" ||
                Convert.ToString(ItmastDataSet.Tables["ItmastView"].Rows[0]["p_unit"]) == "")
            {
                throw new Exception("Unit cannot be blank");
            }

        }

        protected void Save()
        {
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            try
            {
                DataSet ItmastDataSet = (DataSet)Session["ItMastDataSet"];
                BindSave(ItmastDataSet.Tables["ItmastView"].Rows[0],ItmastDataSet);
                checkValidation(ItmastDataSet);
                numericFunction numFunction = new numericFunction();
                if (EditMode == true)
                {
                    SqlStr = DataAccess.GenUpdateString(ItmastDataSet.Tables["ItMastView"], "It_mast",
                                                new string[] { "it_code" }, null, "", new string[] { "it_code" });
                }
                else
                {
                    if (AddMode == true)
                    {
                        SqlStr = DataAccess.GenInsertString(ItmastDataSet.Tables["ItMastView"].Rows[0], "it_mast",
                                                    new string[] { "it_code" }, null);

                    }
                }

                if (SqlStr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true, ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        if (AddMode == true)
                        {
                            // Get Itcode
                            SqlStr = "select ident_current('it_mast') as itcode";
                            dr = DataAccess.ExecuteDataReader(SqlStr, cmd, ref connHandle);
                            Int32 itCode = 0;
                            if (dr.HasRows == true)
                            {
                                while (dr.Read())
                                {
                                    itCode = numFunction.toInt32(dr["itcode"]);
                                }
                            }
                            dr.Close();
                            dr.Dispose();
                            SqlStr = "insert into it_bal (it_name,it_code) values ('" + ItmastDataSet.Tables["ItMastView"].Rows[0]["it_name"] + "'," + itCode + ")";
                            cmd = DataAccess.ExecuteNonQuery(cmd, SqlStr, "TX", true, ref connHandle);
                            try
                            {
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception Ex)
                            {
                                throw Ex;
                            }
                        }
                        DataAccess.CommitTransaction(cmd.Transaction);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        throw Ex;
                    }
                    finally
                    {
                        cmd.Dispose();
                        DataAccess.Connclose(connHandle);
                    }
                }
            }
            catch (Exception Ex)
            {
                DataAccess.Connclose(connHandle);
                throw Ex;
            }
        }



        protected void lnkBtnBack_Click(object sender, EventArgs e)
        {
            SessionProxy.ItmastDataSet = null;
            Response.Redirect("uwItemMasterview.aspx");
        }

        protected void btnAllSave_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void writeXml()
        {
            CL_Gen_Master_WriteXML obj_Master_WriteXML = new CL_Gen_Master_WriteXML();
            DataSet m_Ds = new DataSet();
            m_Ds = obj_Master_WriteXML.writeXmlDS("IT");
            //string xmlPath = "\\xml\\ItMast.xml";
//            string xmlPath = Convert.ToString(SessionProxy.Company.Rows[0]["dir_nm"]).Trim() +
//                          "\\xml\\ItMast.xml";

            string xmlPath = Convert.ToString(ConfigurationManager.AppSettings["XmlPath"]).Trim() +
                 "\\xml\\ItMast.xml";

            //m_Ds.WriteXml(Server.MapPath(xmlPath));
            m_Ds.WriteXml(xmlPath);
            if (m_Ds != null)
                m_Ds.Dispose();
        }
    }
}
