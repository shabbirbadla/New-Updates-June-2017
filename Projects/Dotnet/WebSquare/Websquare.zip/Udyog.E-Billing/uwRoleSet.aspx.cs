using System;
using System.Data;
using System.Data.SqlClient; 
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Business.Logic.Layer;
using Data.Acess.Layer;     

namespace Udyog.E_Billing
{
    public partial class uwRoleSet : System.Web.UI.Page
    {
        private static bool AddMode;
        private static bool EditMode;
        private static int RoleID;
        SqlConnection connHandle;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                Session["RoleSet"] = null;
                Session["checknode"] = null;

                DataTier DataAcess = new DataTier();
                DataSet RoleSet = new DataSet();
                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                RoleID = Convert.ToInt32(Request.QueryString["RoleID"]);
                string sqlstr = "";
                if (AddMode == true)
                {
                    sqlstr = "select rolename from roles where 1=2";
                    RoleSet = DataAcess.ExecuteDataset(RoleSet, sqlstr, "Roles",connHandle);
                    DataAcess.Connclose(connHandle);
 
                    sqlstr = "select roleid,compid,cast(1 as bit) as IsNewAdd from rolescompany where 1=2";
                    RoleSet = DataAcess.ExecuteDataset(RoleSet, sqlstr, "Rolescompany",connHandle);
                    DataAcess.Connclose(connHandle);

                    sqlstr = "select *,cast(0 as bit) as [Check] from servicetax..rolesrights where 1=2";
                    RoleSet = DataAcess.ExecuteDataset(RoleSet, sqlstr, "RolesRights",connHandle);
                    DataAcess.Connclose(connHandle);
                }
                else
                {
                    sqlstr = "select rolename from roles where roleid =" + RoleID;
                    RoleSet = DataAcess.ExecuteDataset(RoleSet, sqlstr, "Roles",connHandle);
                    DataAcess.Connclose(connHandle);

                    sqlstr = "select roleid,compid,cast(0 as bit) as IsNewAdd from rolescompany where roleid=" + RoleID; 
                    RoleSet = DataAcess.ExecuteDataset(RoleSet, sqlstr, "Rolescompany",connHandle);
                    DataAcess.Connclose(connHandle);

                    sqlstr = "select *,cast(0 as bit) as [Check] from servicetax..rolesrights where rolesid=" + RoleID;
                    RoleSet = DataAcess.ExecuteDataset(RoleSet, sqlstr, "RolesRights",connHandle);
                    DataAcess.Connclose(connHandle);

                }

                sqlstr = "select * from co_mast";
                RoleSet = DataAcess.ExecuteDataset(RoleSet, sqlstr, "co_mast",connHandle);
                DataAcess.Connclose(connHandle);

                Session["RoleSet"] = RoleSet;
                Wizard1.ActiveStepIndex = 0;
                Session["ReqCode"] = "m22";
            }
        }

        protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
        {
            try
            {
                StepsNavigation(e.CurrentStepIndex, e.NextStepIndex);
            }
            catch (Exception Ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim() + "');", true);
            }
        }

        protected void Wizard1_SideBarButtonClick(object sender, WizardNavigationEventArgs e)
        {
            try
            {
                StepsNavigation(e.CurrentStepIndex,e.NextStepIndex);
            }
            catch (Exception Ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim() + "');", true);
            }
        }

        protected void StepsNavigation(int CurrentStepIndex,int NextStepIndex)
        {
            switch (CurrentStepIndex)
            {
                case 0:
                    switch (NextStepIndex)
                    {
                        case 1:
                            Wizard1.ActiveStepIndex = 1;
                            lstAvailComp.Items.Clear();
                            lstSeleComp.Items.Clear();  
                            fillAvailCompanyList();
                            fillSelectCompanyList(RoleID);
                            btnLstEnabled();
                            break;
                        case 2:
                            DataSet RoleSet = (DataSet)Session["RoleSet"];
                            DataTable RolesCompany = RoleSet.Tables["RolesCompany"];
                            if (RolesCompany.Rows.Count == 0)
                            {
                                RoleSet.Dispose();
                                RolesCompany.Dispose();
                                throw new Exception("Selected company not found..");
                            }
                            lstAvailComp.Items.Clear();
                            lstSeleComp.Items.Clear();
                            InsertNRemoveCompInDB(RoleID);
                            GenSelectedCompTrVw();
                            break;
                    }
                    break; 
                case 1:
                    switch (NextStepIndex)
                    {
                        case 2:
                            InsertNRemoveCompInDB(RoleID);
                            GenSelectedCompTrVw();
                            break;
                        case 0:
                            txtRoleName.Focus();
                            break;
                    }
                    break; 
                case 2 :
                    if (trCompRights.Nodes.Count > 0)
                    {
                        updateRolesRights();
                        DataSet RoleSet = (DataSet)Session["RoleSet"];
                        DataTable RolesRights = RoleSet.Tables["RolesRights"];
                        DataTable company = RoleSet.Tables["co_mast"];
                        numericFunction numFunction = new numericFunction();
                        DataRow isRow = null;

                        string lstcomp = dropSelectedComp.SelectedValue.Substring(0, dropSelectedComp.SelectedValue.Trim().IndexOf(':'));
                        string lstyear = dropSelectedComp.SelectedValue.Substring(dropSelectedComp.SelectedValue.Trim().IndexOf(':')
                                + 1, (dropSelectedComp.SelectedValue.Length - dropSelectedComp.SelectedValue.Trim().IndexOf(':')) - 1);

                        string filterExp = "";
                        DataRow compRow = null;
                        try
                        {
                            filterExp = "co_name='" + lstcomp.Trim() + "' and year='" + lstyear.Trim() + "'";
                            compRow = company.Select(filterExp)[0];
                        }
                        catch (Exception Ex)
                        {
                            throw Ex;
                        }

                        filterExp = "Range=" + ((TreeNode)Session["checknode"]).Value +
                               " and compid =" + numFunction.toInt32(compRow["compid"]);

                        isRow = RolesRights.Select(filterExp)[0];

                        if (trCompRights.SelectedNode.Checked == true)
                        {
                            isRow["rights"] = GetAccess();
                            isRow["check"] = true;
                        }
                        else
                        {
                            isRow["rights"] = "";
                            isRow["check"] = false;
                        }
                    }
  
                    switch (NextStepIndex)
                    {
                        case 1:
                            Wizard1.ActiveStepIndex = 1;
                            lstAvailComp.Items.Clear();
                            lstSeleComp.Items.Clear();
                            fillAvailCompanyList();
                            fillSelectCompanyList(RoleID);
                            btnLstEnabled();
                            break;
                        case 0:
                            txtRoleName.Focus();
                            break;
                    }
                    break; 

            }
        }

        protected void fillAvailCompanyList()
        {
            DataTier DataAcess = new DataTier();
            string sqlstr = "";
            sqlstr = "select co_name,[year] from servicetax..co_mast order by [year]";
            DataTable compYRList = DataAcess.ExecuteDataTable(sqlstr,"_ss",connHandle);
            DataAcess.Connclose(connHandle);

            foreach (DataRow compYRRow in compYRList.Rows)
            {
                ListItem lstitem = new ListItem();
                lstitem.Text = Convert.ToString(compYRRow["co_name"]).Trim() + ":" + Convert.ToString(compYRRow["year"]).Trim();
                this.lstAvailComp.Items.Add(lstitem);
            }
            compYRList.Dispose();
 
        }

        protected void fillSelectCompanyList(Int32 roleID)
        {
            DataTier DataAcess = new DataTier();
            string sqlstr = "";
            DataSet RoleSet = (DataSet)Session["RoleSet"];
            DataTable RolesCompany = RoleSet.Tables["RolesCompany"];
            numericFunction numFunction = new numericFunction();

            if (RolesCompany.Rows.Count == 0)
            {
                sqlstr = "select a.roleid,a.compid,b.co_name,b.year from servicetax..rolescompany a left " +
                         " join servicetax..co_mast b on a.compid = b.compid where a.roleid=" + roleID;

                DataTable compSelList = DataAcess.ExecuteDataTable(sqlstr, "_ss",connHandle);
                DataAcess.Connclose(connHandle);

                foreach (DataRow compSelRow in compSelList.Rows)
                {
                    ListItem lstitem = new ListItem();
                    lstitem.Text = Convert.ToString(compSelRow["co_name"]).Trim() + ":" + Convert.ToString(compSelRow["year"]).Trim();
                    this.lstSeleComp.Items.Add(lstitem);
                }
            }
            else
            {
                DataTable company = RoleSet.Tables["co_mast"];
                DataRow companyRow = null;
                foreach (DataRow RolesRow in RolesCompany.Rows)
                {
                    try
                    {
                        string filterExp = "compid=" + numFunction.toInt32(RolesRow["compid"]);
                        companyRow = company.Select(filterExp)[0];
                    }
                    catch (Exception Ex)
                    {
                        throw Ex; 
                    }

                    ListItem lstitem = new ListItem();
                    lstitem.Text = Convert.ToString(companyRow["co_name"]).Trim() + ":" + Convert.ToString(companyRow["year"]).Trim();
                    this.lstSeleComp.Items.Add(lstitem);
                }
                company.Dispose(); 
            }

            RoleSet.Dispose();
            RolesCompany.Dispose(); 
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (lstAvailComp.SelectedIndex > -1)
            {
                string lstvalue = lstAvailComp.SelectedItem.Value;
                string lsttext = lstAvailComp.SelectedItem.Text;
                ListItem lstItem = new ListItem();
                lstItem = lstSeleComp.Items.FindByText(lsttext);
                if (lstItem == null)
                {
                    lstItem = new ListItem();
                    lstItem.Value = lstvalue;  
                    lstItem.Text = lsttext;
                    lstSeleComp.Items.Add(lstItem);
                    lstAvailComp.Items.Remove(lstItem);   
                }
                btnLstEnabled();
            }
        }

        protected void btnLstEnabled()
        {
            if (lstAvailComp.Items.Count > 0)
            {
                btnAddAll.Enabled = true;
                btnAdd.Enabled = true; 
            }
            else
            {
                btnAddAll.Enabled = false;
                btnAdd.Enabled = false; 
            }

            if (lstSeleComp.Items.Count > 0)
            {
                btnRemove.Enabled = true;
                btnRemoveAll.Enabled = true;
            }
            else
            {
                btnRemove.Enabled = false;
                btnRemoveAll.Enabled = false; 
            }
        }

        protected void btnAddAll_Click(object sender, EventArgs e)
        {
            int lstcount = lstAvailComp.Items.Count;
            if (lstcount > 0)
            {
                for (int i = 0; i < lstcount ; i++)
                {
                    string lstvalue = lstAvailComp.Items[i].Value;
                    string lsttext = lstAvailComp.Items[i].Text;
                    ListItem lstItem = new ListItem();
                    lstItem = lstSeleComp.Items.FindByText(lsttext);
                    if (lstItem == null)
                    {
                        lstItem = new ListItem();
                        lstItem.Value = lstvalue;
                        lstItem.Text = lsttext;
                        lstSeleComp.Items.Add(lstItem);
                    }
                }

                lstAvailComp.Items.Clear(); 
                btnLstEnabled();
            }
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {
            if (lstSeleComp.SelectedIndex > -1)
            {
                string lstvalue = lstSeleComp.SelectedItem.Value;
                string lsttext = lstSeleComp.SelectedItem.Text;
                ListItem lstItem = new ListItem();
                lstItem = lstAvailComp.Items.FindByText(lsttext);
                if (lstItem == null)
                {
                    lstItem = new ListItem();
                    lstItem.Value = lstvalue;
                    lstItem.Text = lsttext;
                    lstAvailComp.Items.Add(lstItem);
                    lstSeleComp.Items.Remove(lstItem);
                }
                btnLstEnabled();
            }
        }

        protected void btnRemoveAll_Click(object sender, EventArgs e)
        {
            int lstcount = lstSeleComp.Items.Count;
            if (lstcount > 0)
            {
                for (int i = 0; i < lstcount; i++)
                {
                    string lstvalue = lstSeleComp.Items[i].Value;
                    string lsttext = lstSeleComp.Items[i].Text;
                    ListItem lstItem = new ListItem();
                    lstItem = lstAvailComp.Items.FindByText(lsttext);
                    if (lstItem == null)
                    {
                        lstItem = new ListItem();
                        lstItem.Value = lstvalue;
                        lstItem.Text = lsttext;
                        lstAvailComp.Items.Add(lstItem);
                    }
                }

                lstSeleComp.Items.Clear(); 
                btnLstEnabled();
            }
        }

        protected void InsertNRemoveCompInDB(int RoleID)
        {
            DataSet RoleSet = ((DataSet)Session["RoleSet"]);
            DataTable rolescompany = RoleSet.Tables["rolescompany"];
            DataTable company = RoleSet.Tables["co_mast"];
            numericFunction numFunction = new numericFunction();

            // Add Selected Company
            int lstcount = lstSeleComp.Items.Count;
            for (int i = 0; i < lstcount; i++)
            {
                string lstItem = lstSeleComp.Items[i].Text;
                string lstcomp = lstItem.Substring(0,lstItem.Trim().IndexOf(':'));
                string lstyear = lstItem.Substring(lstItem.Trim().IndexOf(':') + 1, (lstItem.Length-lstItem.Trim().IndexOf(':')) - 1);

                try
                {
                    string filterExp = "co_name='" + lstcomp + "' and year='" + lstyear + "'";
                    DataRow companyRow = company.Select(filterExp)[0];
                    DataRow roleCompRow = null;
                    try
                    {
                        filterExp = "compid = " + numFunction.toInt32(companyRow["compid"]);
                        roleCompRow = rolescompany.Select(filterExp)[0];
                    }
                    catch 
                    {
                        roleCompRow = rolescompany.NewRow();
                        roleCompRow["Roleid"] = RoleID;
                        roleCompRow["compId"] = numFunction.toInt32(companyRow["compid"]);
                        roleCompRow["IsNewAdd"] = true;
                        rolescompany.Rows.Add(roleCompRow);
                        rolescompany.AcceptChanges();  
                    }
                }
                catch (Exception Ex)
                {
                    throw Ex; 
                }
            }

            // Remove those rows which is already exist but unselected
            foreach (DataRow Rolecomp in rolescompany.Select("IsNewAdd = 0"))
            {
                Rolecomp.Delete();
                Rolecomp.AcceptChanges(); 
            }

            Session["RoleSet"] = RoleSet;
            RoleSet.Dispose();
            rolescompany.Dispose();
            company.Dispose(); 
        }

        protected void GenSelectedCompTrVw()
        {
            DataSet RoleSet = ((DataSet)Session["RoleSet"]);
            DataTable rolescompany = RoleSet.Tables["rolescompany"];
            DataTable company = RoleSet.Tables["co_mast"];
            numericFunction numFunction = new numericFunction();

            foreach (DataRow RolecompRow in rolescompany.Rows)
            {
                DataRow CompanyRow = null;
                try
                {
                    string filterExp = "compid = " + numFunction.toInt32(RolecompRow["compid"]);
                    CompanyRow = company.Select(filterExp)[0];
                }
                catch (Exception Ex)
                {
                    throw Ex;
                }

                string compname = Convert.ToString(CompanyRow["co_name"]);
                string year = Convert.ToString(CompanyRow["year"]);
                string compstr = compname.Trim() + ":" + year.Trim();
                dropSelectedComp.Items.Clear();  
                dropSelectedComp.Items.Add(compstr);
                dropSelectedComp.Items.Insert(0, "-- Select Company --");   
            }

            RoleSet.Dispose();
            rolescompany.Dispose();
            company.Dispose(); 
        }

        protected void dropSelectedComp_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTier DataAcess = new DataTier();
            DataSet RoleSet = ((DataSet)Session["RoleSet"]);
            DataTable rolescompany = RoleSet.Tables["rolescompany"];
            DataTable company = RoleSet.Tables["co_mast"];
            DataTable RolesRights = RoleSet.Tables["RolesRights"]; 
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            string lstcomp = dropSelectedComp.SelectedValue.Substring(0, dropSelectedComp.SelectedValue.Trim().IndexOf(':'));
            string lstyear = dropSelectedComp.SelectedValue.Substring(dropSelectedComp.SelectedValue.Trim().IndexOf(':')
                        + 1, (dropSelectedComp.SelectedValue.Length - dropSelectedComp.SelectedValue.Trim().IndexOf(':')) - 1);

            DataRow compRow = null;
            try
            {
                string filterExp = "co_name='" + lstcomp.Trim() + "' and year='" + lstyear.Trim() + "'";
                compRow = company.Select(filterExp)[0];
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            string dbName = Convert.ToString(compRow["dbname"]).Trim();
            string sqlstr = "select range,padname,numitem from " + 
                        dbName + "..com_menu where range not like ('%.%') order by range";
            DataTable ParentDb = DataAcess.ExecuteDataTable(sqlstr, "_p",connHandle);
            DataAcess.Connclose(connHandle);

            //sqlstr = "select * from servicetax..rolesrights where roleid =" + RoleID +
            //    " and compid = " + numFunction.toInt32(compRow["compid"]);
 
            //DataTable RightsDb = DataAcess.ExecuteDataTable(sqlstr, "_r");

            trCompRights.Nodes.Clear();
            TreeNode ParentNode;
            DataRow RightsRow;
            foreach (DataRow PadRow in ParentDb.Rows)
            {
                ParentNode = new TreeNode();
                ParentNode.Text = Convert.ToString(PadRow["padname"]).Trim();
                ParentNode.Value = Convert.ToString(PadRow["range"]).Trim();
                try
                {
                    string filterExp = "range ='" + Convert.ToString(PadRow["range"]).Trim() + "' and compid =" +
                        numFunction.toInt32(compRow["compid"]);
                    RightsRow = RolesRights.Select(filterExp)[0];
                    string test = "";
                }
                catch
                {
                    RightsRow = null;
                }

                if (RightsRow != null)
                {
                    ParentNode.Checked = bitFunction.toBoolean(RightsRow["check"]);
                //    //RightsRow = RolesRights.NewRow();
                //    //RightsRow["padname"] = Convert.ToString(PadRow["padname"]).Trim();
                //    RightsRow["rights"] = Convert.ToString(RightsRow["rights"]).Trim();
                //    //RightsRow["range"] = Convert.ToString(PadRow["range"]).Trim();
                //    //RightsRow["compid"] = numFunction.toInt32(compRow["compid"]);    
                //    RightsRow["check"] = true;
                //    //RolesRights.Rows.Add(RightsRow);
                }
                else
                {
                    ParentNode.Checked = false;
                    RightsRow = RolesRights.NewRow();
                    RightsRow["padname"] = Convert.ToString(PadRow["padname"]).Trim();
                    RightsRow["rights"] = Convert.ToString(RightsRow["rights"]).Trim();
                    RightsRow["range"] = Convert.ToString(PadRow["range"]).Trim();
                    RightsRow["compid"] = numFunction.toInt32(compRow["compid"]);    
                    RightsRow["check"] = false;
                    RolesRights.Rows.Add(RightsRow);
                }

                trCompRights.Nodes.Add(ParentNode);

                if (numFunction.toInt32(PadRow["numitem"]) > 0)
                {
                    genchildRights(ParentNode,
                                Convert.ToString(PadRow["range"]).Trim(), 
                                dbName,
                                RolesRights,
                                numFunction.toInt32(compRow["compid"])); 
                }
            }
            Session["RoleSet"] = RoleSet;
            rolescompany.Dispose();
            company.Dispose();
            Session["checknode"] = trCompRights.Nodes[0];
            CheckUncheck(Convert.ToString(RolesRights.Rows[0]["rights"]).Trim());
            RolesRights.Dispose();
        }

        protected void genchildRights(TreeNode childNode,
                    string mnuid,
                    string Dbname,
                    DataTable RolesRights,                    
                    int compid)
        {
            DataTier DataAcess = new DataTier();
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            string sqlstr = "select range,padname,numitem,urights,url from " + 
                 Dbname.Trim() + "..com_menu where range not in ('" +
                     mnuid + "') and range like ('" + mnuid + "._') or range " +
                    " like ('" + mnuid + ".__') order by padname";

            DataTable childDb = DataAcess.ExecuteDataTable(sqlstr, "_c",connHandle);
            DataAcess.Connclose(connHandle);

            TreeNode Node;
            foreach (DataRow childRow in childDb.Rows)
            {
                Node = new TreeNode();
                Node.Text = Convert.ToString(childRow["padname"]).Trim();
                Node.Value = Convert.ToString(childRow["range"]).Trim();
                childNode.ChildNodes.Add(Node);
                DataRow RightsRow;
                try
                {
                    string filterExp = "range='" + Convert.ToString(childRow["range"]) + "' and compid=" + compid;
                    RightsRow = RolesRights.Select(filterExp)[0];
                }
                catch
                {
                    RightsRow = null;
                }

                if (RightsRow != null)
                {
                    Node.Checked = bitFunction.toBoolean(RightsRow["check"]);
                    //RightsRow = RolesRights.NewRow();
                    //RightsRow["padname"] = Convert.ToString(childRow["padname"]).Trim();
                    //RightsRow["rights"] = Convert.ToString(RightsRow["rights"]).Trim();
                    //RightsRow["range"] = Convert.ToString(childRow["range"]).Trim();
                    //RightsRow["check"] = true;
                    //RightsRow["compid"] = numFunction.toInt32(compid);    
                    //RolesRights.Rows.Add(RightsRow);
                    SetParentNode(Node, bitFunction.toBoolean(RightsRow["check"]));
                }
                else
                {
                    Node.Checked = false;
                    RightsRow = RolesRights.NewRow();
                    RightsRow["padname"] = Convert.ToString(childRow["padname"]).Trim();
                    RightsRow["rights"] = Convert.ToString(RightsRow["rights"]).Trim();
                    RightsRow["range"] = Convert.ToString(childRow["range"]).Trim();
                    RightsRow["compid"] = numFunction.toInt32(compid);    
                    RightsRow["check"] = false;
                    RolesRights.Rows.Add(RightsRow);
                }

                if (numFunction.toInt32(childRow["numitem"]) > 0)
                {
                    genchildRights(Node,
                                Convert.ToString(childRow["range"]).Trim(), 
                                Dbname,
                                RolesRights,
                                compid);  
                }
            }
            
        }

        protected void SetParentNode(TreeNode ChildNode, bool isTrue)
        {
            if (ChildNode.Parent == null)
            {
                if (isTrue == false)
                {
                    for (int i = 0; i <= ChildNode.ChildNodes.Count - 1; i++)
                    {
                        if (ChildNode.ChildNodes[i].Checked == true)
                        {
                            ChildNode.Checked = ChildNode.ChildNodes[i].Checked;
                            break;
                        }
                        else
                        {
                            ChildNode.Checked = ChildNode.ChildNodes[i].Checked;
                        }
                    }
                }
                else
                {
                    ChildNode.Checked = isTrue;
                }
            }
            else
            {
                if (isTrue == false)
                {
                    for (int i = 0; i <= ChildNode.ChildNodes.Count - 1; i++)
                    {
                        if (ChildNode.ChildNodes[i].Checked == true)
                        {
                            ChildNode.Checked = ChildNode.ChildNodes[i].Checked;
                            break;
                        }
                        else
                        {
                            ChildNode.Checked = ChildNode.ChildNodes[i].Checked;
                        }
                    }
                }
                else
                {
                    ChildNode.Checked = isTrue;
                }

                SetParentNode(ChildNode.Parent, isTrue);
            }
        }

        protected void trSelectedComp_checkNode(object sender, TreeNodeEventArgs e)
        {
            this.CheckDelete.Enabled = e.Node.Checked;
            this.CheckInsert.Enabled = e.Node.Checked;
            this.CheckUpdate.Enabled = e.Node.Checked;
            this.CheckView.Enabled = e.Node.Checked;
            if (e.Node.Parent == null)
            {
                SetCheckNode(e.Node,e.Node.Checked);
            }
            else
            {
                if (e.Node.ChildNodes.Count > 0)
                {
                    SetCheckNode(e.Node, e.Node.Checked); 
                }
                SetParentNode(e.Node.Parent, e.Node.Checked); 
            }
  
        }



        protected void SetCheckNode(TreeNode Node, bool isTrue)
        {
            if (Node.ChildNodes.Count > 0)
            {
                Node.Checked = isTrue;
                for (int i = 0; i <= Node.ChildNodes.Count - 1; i++)
                {
                    SetCheckNode(Node.ChildNodes[i],isTrue);
                }
                Node.ExpandAll();
            }
            else
            {
                Node.Checked = isTrue;
            }
        }

        protected void trCompRights_SelectedNodeChanged(object sender, EventArgs e)
        {
            updateRolesRights();
        }

        protected void updateRolesRights()
        {

            DataSet RoleSet = ((DataSet)Session["RoleSet"]);
            DataTable RolesRights = RoleSet.Tables["RolesRights"];  
            CheckInsert.Enabled = true;
            CheckUpdate.Enabled = true;
            CheckDelete.Enabled = true;
            CheckView.Enabled = true;
            TreeNode CheckNode = (TreeNode)Session["checknode"];
            DataRow findRow = null;
            if (Session["checknode"] != null)
            {
                TreeNode Node = trCompRights.FindNode(CheckNode.ValuePath);
                findRow = RolesRights.Select("range='" + Node.Value.Trim() + "'")[0];
                string prePerm = "";
                if (Convert.ToString(findRow["rights"]).Trim() == "")
                    prePerm = "";
                else
                    prePerm = Convert.ToString(findRow["rights"]).Trim();

                if (Node.Checked == true)
                {
                    string parentcheck = GetAccess();
                    GetPermissionforChild(Node, true, "PARENT", parentcheck, ref RolesRights);
                }
                else
                {
                    string parentcheck = GetAccess();
                    GetPermissionforChild(Node, false, "PARENT", parentcheck, ref RolesRights);  
                }

                GetPermissionforParent(Node, ref RolesRights);

                if (Node.Parent == null)
                {
                    GetPermissionforInternalChild(Node, prePerm, ref RolesRights); 
                }
            }

            findRow = RolesRights.Select("range='" + trCompRights.SelectedNode.Value + "'")[0];
            CheckUncheck(Convert.ToString(findRow["rights"]).Trim());

            if (trCompRights.SelectedNode.Checked == false)
            {
                CheckInsert.Checked = false;
                CheckUpdate.Checked = false;
                CheckView.Checked = false;
                CheckDelete.Checked = false;
            }

            Session["RoleSet"] = RoleSet;
            Session["checknode"] = this.trCompRights.SelectedNode;
            
        }

        protected void CheckUncheck(string Access)
        {
            CheckInsert.Checked = false;
            CheckUpdate.Checked = false;
            CheckView.Checked = false;
            CheckDelete.Checked = false;

            if (Access.IndexOf("D", 0) >= 0)
            {
                this.CheckDelete.Checked = true; 
            }

            if (Access.IndexOf("I", 0) >= 0)
            {
                this.CheckInsert.Checked = true;
            }

            if (Access.IndexOf("U", 0) >= 0)
            {
                this.CheckUpdate.Checked = true;
            }

            if (Access.IndexOf("P", 0) >= 0)
            {
                this.CheckView.Checked = true;
            }
        }

        protected void GetPermissionforInternalChild(TreeNode Node,
            string Access,
            ref DataTable RolesRights)
        {

            DataRow isRow = RolesRights.Select("range='" + Node.Value.Trim() + "'")[0];
            string strRemove = "";

            if (Access != "")
            {
                for (int i = 0; i <= Access.Length - 1; i++)
                {
                    if (Convert.ToString(isRow["rights"]).Trim().IndexOf(Access[i]) < 0)
                    {
                        strRemove += Access[i];
                    }
                }
            }

            for (int i = 0; i <= Node.ChildNodes.Count - 1; i++)
            {
                isRow = RolesRights.Select("range='" + Node.ChildNodes[i].Value.Trim() + "'")[0];
                Access = Convert.ToString(isRow["rights"]).Trim();
                for (int j = 0; j <= strRemove.Length - 1; j++)
                {
                    if (Convert.ToString(isRow["rights"]).Trim().IndexOf(strRemove[j]) >= 0)
                    {
                        isRow["rights"] = Convert.ToString(isRow["rights"]).Trim().Remove(Convert.ToString(isRow["rights"]).Trim().IndexOf(strRemove[j]),1);
                    }
                }

                if (Node.ChildNodes[i].ChildNodes.Count > 0)
                {
                    GetPermissionforInternalChild(Node.ChildNodes[i], Access,ref RolesRights); 
                }
            }

        }
        protected string GetAccess()
        {
            string Access = "";
            if (this.CheckDelete.Checked == true)
            {
                Access = "D";
                this.CheckDelete.Checked = false;
            }

            if (this.CheckInsert.Checked == true)
            {
                Access += "I";
                this.CheckInsert.Checked = false;
            }

            if (this.CheckUpdate.Checked == true)
            {
                Access += "U";
                this.CheckUpdate.Checked = false;
            }

            if (this.CheckView.Checked == true)
            {
                Access += "P";
                this.CheckView.Checked = false;
            }

            return Access;
        }

        protected void GetPermissionforParent(TreeNode Node,
                ref DataTable RolesRights)
        {
            if (Node.Parent != null)
            {
                DataRow IsRow = null;
                int countInsert, countUpdate, countDelete, countPrint = 0;
                countInsert = 0 ;
                countUpdate = 0 ;
                countDelete = 0; 
                countPrint = 0;

                Node = Node.Parent;

                for (int i = 0; i <= Node.ChildNodes.Count - 1; i++)
                {
                    IsRow = RolesRights.Select("range='" + Node.ChildNodes[i].Value.Trim() + "'")[0];
                    if (Convert.ToString(IsRow["rights"]).Trim().IndexOf("I") >= 0)
                    {
                        countInsert += 1;
                    }

                    if (Convert.ToString(IsRow["rights"]).Trim().IndexOf("U") >= 0)
                    {
                        countUpdate += 1;
                    }

                    if (Convert.ToString(IsRow["rights"]).Trim().IndexOf("D") >= 0)
                    {
                        countDelete += 1;
                    }

                    if (Convert.ToString(IsRow["rights"]).Trim().IndexOf("P") >= 0)
                    {
                        countPrint += 1;
                    }
                }

                string per = "";

                if (countInsert == Node.ChildNodes.Count)
                {
                    per += "I";
                }

                if (countUpdate == Node.ChildNodes.Count)
                {
                    per += "U";
                }

                if (countDelete == Node.ChildNodes.Count)
                {
                    per += "D";
                }

                if (countPrint == Node.ChildNodes.Count)
                {
                    per += "P";
                }

                IsRow = RolesRights.Select("range='" + Node.Value.Trim() + "'")[0];
                IsRow["rights"] = per;

                GetPermissionforParent(Node, ref RolesRights); 
            }
        }

        protected void GetPermissionforChild(TreeNode Node,
                bool IsCheck,
                string root,
                string parentcheck,
                ref DataTable RolesRights)
        {
            DataRow isRow = null;
            if (Node.ChildNodes.Count > 0)
            {
                for (int i = 0; i <= Node.ChildNodes.Count - 1; i++)
                {
                    if (Node.ChildNodes[i].Checked == true)
                        GetPermissionforChild(Node.ChildNodes[i],
                                true,
                                "CHILD",
                                parentcheck,
                                ref RolesRights);
                    else
                        GetPermissionforChild(Node.ChildNodes[i],
                                false,
                                "CHILD",
                                parentcheck,
                                ref RolesRights);
                }

                if (root == "PARENT")
                {
                    isRow = RolesRights.Select("range='" + Node.Value.Trim() + "'")[0];
                    isRow["Rights"] = parentcheck.Trim();
                    isRow["Check"] = IsCheck;
                }
                else
                {
                    isRow = RolesRights.Select("range='" + Node.Value.Trim() + "'")[0];
                    string str, merge = "";
                    if (Convert.ToString(isRow["Rights"]).Trim() == "")
                    {
                        str = "";
                    }
                    else
                    {
                        str = Convert.ToString(isRow["Rights"]);
                    }

                    if (Convert.ToString(parentcheck).Trim() == "")
                    {
                        merge = "";
                    }
                    else
                    {
                        merge = parentcheck;
                    }

                    if (str.Length == 4)
                    {
                        isRow["rights"] = str;
                    }
                    else
                    {
                        if (merge.Length == 4)
                        {
                            isRow["rights"] = merge;
                        }
                        else
                        {
                            for (int j = 0; j <= str.Length - 1; j++)
                            {
                                if (merge.IndexOf(str[j]) < 0)
                                {
                                    merge = merge + str[j];
                                }
                            }
                            isRow["rights"] = merge;
                        }
                    }
                    isRow["check"] = IsCheck;
                }
            }
            else
            {
                if (root == "PARENT")
                {
                    isRow = RolesRights.Select("range='" + Node.Value.Trim() + "'")[0];
                    isRow["rights"] = parentcheck;
                    isRow["check"] = IsCheck;
                }
                else
                {
                    string str,merge = "";
                    isRow = RolesRights.Select("range='" + Node.Value.Trim() + "'")[0];
                    if (Convert.ToString(isRow["rights"]).Trim() == "")
                    {
                        str = "";
                    }
                    else
                    {
                        str = Convert.ToString(isRow["rights"]).Trim();
                    }

                    if (Convert.ToString(parentcheck).Trim() == "")
                    {
                        merge = "";
                    }
                    else
                    {
                        merge = parentcheck;
                    }

                    if (str.Length == 4)
                    {
                        isRow["rights"] = str;
                    }
                    else
                    {
                        if (merge.Length == 4)
                        {
                            isRow["rights"] = merge;
                        }
                        else
                        {
                            for (int j = 0; j <= str.Length - 1; j++)
                            {
                                if (merge.IndexOf(str[j]) < 0)
                                {
                                    merge = merge + str[j];
                                }
                            }
                            isRow["rights"] = merge;
                        }
                    }
                    isRow["check"] = IsCheck;
                }
            }
        }

        protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            if (trCompRights.Nodes.Count > 0)
            {
                DataSet RoleSet = ((DataSet)Session["RoleSet"]);
                DataTable RolesRights = RoleSet.Tables["RolesRights"];

                foreach (DataRow RolesRow in RolesRights.Rows)
                {
                    if (chkSelectAll.Checked == true)
                        RolesRow["Check"] = true;
                    else
                        if (chkSelectAll.Checked == false)
                            RolesRow["Check"] = false;
                }

                Session["RoleSet"] = RoleSet;
                RoleSet.Dispose();
                RolesRights.Dispose();
  
                for (int i = 0; i <= trCompRights.Nodes.Count - 1; i++)
                {
                    trCompRights.Nodes[i].Checked = chkSelectAll.Checked;
                    if (trCompRights.Nodes[i].ChildNodes.Count > 0)
                    {
                        SetCheckNode(trCompRights.Nodes[i], chkSelectAll.Checked); 
                    }
                }
            }
        }

        protected void imgExpandAll_Click(object sender, ImageClickEventArgs e)
        {
            for (int i = 0; i <= trCompRights.Nodes.Count - 1; i++)
            {
                trCompRights.Nodes[i].ExpandAll(); 
            }
        }

        protected void imgCollapsAll_Click(object sender, ImageClickEventArgs e)
        {
            for (int i = 0; i <= trCompRights.Nodes.Count - 1; i++)
            {
                trCompRights.Nodes[i].CollapseAll(); 
            }
        }

        protected void Wizard1_NextButtonClick(object sender, WizardNavigationEventArgs e)
        {
            switch (e.CurrentStepIndex)
            {
                case 0:
                    txtRoleName.Focus();
                    break;
                case 2:
                    dropSelectedComp.Focus();
                    break; 
            }
        }

        protected void Wizard1_PreviousButtonClick(object sender, WizardNavigationEventArgs e)
        {
            try
            {
                StepsNavigation(e.CurrentStepIndex, e.NextStepIndex);
            }
            catch (Exception Ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message.Trim() + "');", true);
            }
        }
    }
}
