using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Data.Acess.Layer;
using Business.Logic.Layer;
using Controls;  
 

namespace Udyog.E.Billing
{
    public partial class Allocation : System.Web.UI.Page
    {
        private static string pcvType = "";
        private static bool addMode = false;
        private static bool editMode = false;
        private static decimal vAmt = 0;
        private static string acName = "";
        private static numericFunction numFunction = new numericFunction();
        private static stringFunction strFunction = new stringFunction();
        private static DataTable acmast_vw = new DataTable();
        private static DataTable tmpMall_vw = new DataTable();
        private static DataTable mall_vw = new DataTable();
        private static DataTable main_vw = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {

            if (IsPostBack == false)
            {
                tmpMall_vw = (DataTable)Session["tmpMallDtSess"];
                mall_vw = (DataTable)Session["mallDtSess"];
                main_vw = (DataTable)Session["mainDtSess"];
                acmast_vw = (DataTable)Session["acMastdtSess"];

                pcvType = Request.Params["pcvType"].ToString().Trim();
                addMode = Convert.ToBoolean(Request.Params["addMode"]);
                editMode = Convert.ToBoolean(Request.Params["editMode"]);
                vAmt = Convert.ToDecimal(Request.Params["vAmt"]);
                acName = Request.Params["acName"].ToString().Trim();

                GenerateBoundColumns();
                vuAllocationInit(grdAllocation, tmpMall_vw, main_vw, chkAllocExecess, pcvType, addMode, editMode, vAmt, lblAmount, lblTotAlloc, lblBalance);
                grdAllocation.DataSource = tmpMall_vw;
                grdAllocation.DataBind();
                lblAcName.Text = acName.Trim();

                chkAllocExecess.Checked = false;

                //TextBox testBox = new TextBox();
                //testBox.Visible = true;
                //testBox.TextChanged += new EventHandler(testBox_TextChanged);
                //testBox.AutoPostBack = true;
                //Page.FindControl("Form1").Controls.Add(testBox);  


            }
            else
            {
                GenerateBoundColumns();
                vuAllocationInit(grdAllocation, tmpMall_vw, main_vw, chkAllocExecess, pcvType, addMode, editMode, vAmt, lblAmount, lblTotAlloc, lblBalance);
                grdAllocation.DataSource = tmpMall_vw;
                grdAllocation.DataBind();
                lblAcName.Text = acName.Trim();

                //TextBox testBox = new TextBox();
                //testBox.Visible = true;
                //testBox.TextChanged += new EventHandler(testBox_TextChanged);
                //testBox.AutoPostBack = true;  
                //Page.FindControl("Form1").Controls.Add(testBox);  

            }
        }

        protected void GenerateBoundColumns()
        {
            grdAllocation.Columns.Clear();
            for (int i = 0; i < 28; i++)
            {
                BoundField bndField = new BoundField();
                bndField.AccessibleHeaderText = "RemoveOnly";
                grdAllocation.Columns.Add(bndField);
            }
        }

        private decimal vchrAmt;
        public decimal VchrAmt
        {
            get { return vchrAmt; }
            set { vchrAmt = value; }
        }

        private decimal fromAcAmt;

        public decimal FromAcAmt
        {
            get { return fromAcAmt; }
            set { fromAcAmt = value; }
        }


        public void vuAllocationInit(GridView grdAllocation, DataTable tmpAll_vw, DataTable main_vw, CheckBox chkAllocExcess, string pcvType, bool addMode, bool editMode, decimal vAmt, Label lblAmount, Label lblTotAlloc, Label lblBalance)
        {

            if (addMode == true || editMode == true)
            {
                if (vAmt == 0)
                {
                    chkAllocExcess.Checked = true;
                }
                else
                {
                    chkAllocExcess.Checked = true;
                }

                decimal sumAmt1 = 0;
                decimal sumAmt2 = 0;
                decimal fromAcAmt = 0;
                //decimal vchrAmt = 0;
                bool deptFound = false;
                foreach (DataRow tmpRow in tmpAll_vw.Rows)
                {
                    if (Convert.ToString(tmpRow["dept"]).Trim() != "")
                    {
                        deptFound = true;
                    }
                }

                foreach (DataRow tmpRow in tmpAll_vw.Rows)
                {
                    if (Convert.ToString(tmpRow["entry_ty"]) != Convert.ToString(main_vw.Rows[0]["Entry_ty"]).Trim() &&
                        Convert.ToInt32(tmpRow["tran_cd"]) != Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                    {
                        sumAmt1 = sumAmt1 + (numFunction.toDecimal(tmpRow["new_all"]) + numFunction.toDecimal(tmpRow["tds"]) + numFunction.toDecimal(tmpRow["disc"]));
                    }

                    if (Convert.ToString(tmpRow["entry_ty"]) != Convert.ToString(main_vw.Rows[0]["Entry_ty"]).Trim() &&
                        Convert.ToInt32(tmpRow["tran_cd"]) != Convert.ToInt32(main_vw.Rows[0]["tran_cd"]))
                    {
                        sumAmt2 = sumAmt2 + (numFunction.toDecimal(tmpRow["new_all"]) + numFunction.toDecimal(tmpRow["tds"]) + numFunction.toDecimal(tmpRow["disc"]));
                    }
                }

                FromAcAmt = vAmt - sumAmt2;

                if (chkAllocExcess.Checked == true)
                {
                    VchrAmt = sumAmt1;

                }
                else
                {
                    VchrAmt = FromAcAmt;
                }

                lblAmount.Text = Convert.ToString(vchrAmt).Trim();
                lblTotAlloc.Text = Convert.ToString(sumAmt1).Trim();
                lblBalance.Text = Convert.ToString(vchrAmt - sumAmt2).Trim();


                if (strFunction.InList(pcvType.Trim(), new string[2] { "ST", "PT" }) == true)
                {
                    grdTemplateColumn(grdAllocation, "new_all", "Allocate", "ALLOCATING", "TEMPLATE", 0, "DECIMAL", 100); // 1
                    grdTemplateColumn(grdAllocation, "net_amt", "Inv.Amt.", "INVAMT", "BOUND", 1, "DECIMAL", 80);  // 2
                    grdTemplateColumn(grdAllocation, "re_all", "Allocated", "ALLOCATED", "BOUND", 2, "DECIMAL", 80); // 3
                    grdTemplateColumn(grdAllocation, "balance", "Balance", "BALANCE", "BOUND", 3, "DECIMAL", 80); // 4
                    grdTemplateColumn(grdAllocation, "", "Type", "INVTYPE", "BOUND", 6, "STRING", 0); //5
                    grdTemplateColumn(grdAllocation, "v_inv_no", "Bill.No.", "BILLNO", "BOUND", 4, "STRING", 80); // 6
                    if (deptFound == true)
                    {
                        grdTemplateColumn(grdAllocation, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 13, "DATE", 80); // 7
                        grdTemplateColumn(grdAllocation, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 12, "DECIMAL", 80); // 8
                        grdTemplateColumn(grdAllocation, "inv_no", "Inv.No.", "INVNO", "BOUND", 14, "STRING", 80); // 13
                        grdTemplateColumn(grdAllocation, "l_yn", "Year    ", "INVYEAR", "BOUND", 11, "STRING", 80); // 14
                    }
                    else
                    {
                        grdTemplateColumn(grdAllocation, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 12, "DATE", 80); // 7
                        grdTemplateColumn(grdAllocation, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 11, "DECIMAL", 80); // 8
                        grdTemplateColumn(grdAllocation, "inv_no", "Inv.No.", "INVNO", "BOUND", 13, "STRING", 80); // 13
                        grdTemplateColumn(grdAllocation, "l_yn", "Year    ", "INVYEAR", "BOUND", 10, "STRING", 80); // 14
                    }

                    grdTemplateColumn(grdAllocation, "tds_all", "TDS given", "TDSOLD", "BOUND", 7, "DECIMAL", 80); // 9
                    grdTemplateColumn(grdAllocation, "disc", "Discount", "DISCAMT", "BOUND", 8, "DECIMAL", 80); // 10
                    grdTemplateColumn(grdAllocation, "disc_all", "Disc.given", "DISCOLD", "TEMPLATE", 10, "DECIMAL", 80); // 11
                    grdTemplateColumn(grdAllocation, "inv_sr", "Inv.Series", "INVSERIES", "BOUND", 09, "STRING", 100); // 12
                    grdTemplateColumn(grdAllocation, "dept", "Department", "DEPT", "BOUND", 5, "STRING", 100); // 15
                }
                else
                {
                    grdTemplateColumn(grdAllocation, "new_all", "Allocate", "ALLOCATING", "TEMPLATE", 0, "DECIMAL", 200); // 1
                    grdTemplateColumn(grdAllocation, "net_amt", "Inv.Amt.", "INVAMT", "BOUND", 1, "DECIMAL", 80);  // 2
                    grdTemplateColumn(grdAllocation, "re_all", "Allocated", "ALLOCATED", "BOUND", 2, "DECIMAL", 80); // 3
                    grdTemplateColumn(grdAllocation, "balance", "Balance", "BALANCE", "BOUND", 3, "DECIMAL", 80); // 4
                    grdTemplateColumn(grdAllocation, "", "Type", "INVTYPE", "BOUND", 7, "STRING", 0); //5
                    grdTemplateColumn(grdAllocation, "v_inv_no", "Bill.No.", "BILLNO", "BOUND", 4, "STRING", 80); // 6
                    if (deptFound == true)
                    {
                        grdTemplateColumn(grdAllocation, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 09, "DATE", 80); // 7
                        grdTemplateColumn(grdAllocation, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 8, "DECIMAL", 80); // 8
                        grdTemplateColumn(grdAllocation, "tds_all", "TDS given", "TDSOLD", "BOUND", 11, "DECIMAL", 80); // 9
                        grdTemplateColumn(grdAllocation, "disc", "Discount", "DISCAMT", "TEMPLATE", 12, "DECIMAL", 80); // 10
                        grdTemplateColumn(grdAllocation, "disc_all", "Disc.given", "DISCOLD", "TEMPLATE", 14, "DECIMAL", 80); // 11
                        grdTemplateColumn(grdAllocation, "inv_sr", "Inv.Series", "INVSERIES", "BOUND", 13, "STRING", 100); // 12
                        grdTemplateColumn(grdAllocation, "inv_no", "Inv.No.", "INVNO", "BOUND", 10, "STRING", 80); // 13
                        grdTemplateColumn(grdAllocation, "l_yn", "Year    ", "INVYEAR", "BOUND", 7, "STRING", 80); // 14
                    }
                    else
                    {
                        grdTemplateColumn(grdAllocation, "v_inv_dt", "Inv.Date", "INVDATE", "BOUND", 8, "DATE", 80); // 7
                        grdTemplateColumn(grdAllocation, "tds", "TDS Amt", "TDSAMT", "TEMPLATE", 7, "DECIMAL", 80); // 8
                        grdTemplateColumn(grdAllocation, "tds_all", "TDS given", "TDSOLD", "BOUND", 10, "DECIMAL", 80); // 9
                        grdTemplateColumn(grdAllocation, "disc", "Discount", "DISCAMT", "TEMPLATE", 11, "DECIMAL", 80); // 10
                        grdTemplateColumn(grdAllocation, "disc_all", "Disc.given", "DISCOLD", "BOUND", 13, "DECIMAL", 80); // 11
                        grdTemplateColumn(grdAllocation, "inv_sr", "Inv.Series", "INVSERIES", "BOUND", 12, "STRING", 100); // 12
                        grdTemplateColumn(grdAllocation, "inv_no", "Inv.No.", "INVNO", "BOUND", 09, "STRING", 80); // 13
                        grdTemplateColumn(grdAllocation, "l_yn", "Year    ", "INVYEAR", "BOUND", 6, "STRING", 80); // 14
                    }
                    grdTemplateColumn(grdAllocation, "dept", "Department", "DEPT", "BOUND", 5, "STRING", 100); // 15
                }

                int grdIndextotCol = grdAllocation.Columns.Count - 1;
                for (int i = grdIndextotCol; 0 <= i; i--)
                {
                    if (grdAllocation.Columns[i].AccessibleHeaderText.ToString().Trim().ToUpper() == "REMOVEONLY")
                    {
                        grdAllocation.Columns.RemoveAt(i);
                    }
                }

                //CommandField cmdFld = new CommandField();
                //cmdFld.ButtonType = ButtonType.Image;
                //cmdFld.ShowSelectButton = true;
                //cmdFld.SelectImageUrl = "~/Images/allocation.gif";
                //cmdFld.HeaderText = "..";
                //cmdFld.SelectText = "Allocate";
                //cmdFld.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                //cmdFld.ItemStyle.VerticalAlign = VerticalAlign.Middle;
                //grdAllocation.Columns.Insert(0, cmdFld);

                TemplateField templateField = new TemplateField();
                DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
                Button btnforAllocate = new Button();
                btnforAllocate.ID= "btnAlloc";
                btnforAllocate.Width = 50;
                btnforAllocate.Height = 18; 
                btnforAllocate.Visible = true;
                btnforAllocate.Text = "Allocate";
                btnforAllocate.CssClass = "AllocButton"; 
                btnforAllocate.CommandName = "SELECT";
                dynamictemplateItem.AddControl(btnforAllocate, "Text", "");
                templateField.ItemTemplate = dynamictemplateItem;
                grdAllocation.Columns.Insert(0, templateField);  
 
                //for (int i = 0; i < grdAllocation.Rows[0].Cells.Count-1; i++)
                //{
                //    grdAllocation.Rows[0].Cells[i].Width = Unit.Pixel(200);
                //}


            }
        }

        //public event EventHandler TextChanged;
        public void grdTemplateColumn(GridView grdAllocation, string fldName, string headName, string tagName, string colType, int colOrder, string dataType, int colWidth)
        {
            TemplateField templateField = new TemplateField();
            DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);

            if (colType == "TEMPLATE")
            {
                NumericTextBox txtBox = new NumericTextBox();
                txtBox.ID = "txt" + fldName.Trim();
                txtBox.CssClass = "form_textAllocation";
                txtBox.Visible = true;
                txtBox.AlignStyle = "RIGHT";
                txtBox.Format = "0.00";
                txtBox.Width = 80;
                txtBox.SelectOnEntry = false;
                dynamictemplateItem.AddControl(txtBox, "Text", fldName);
                templateField.ItemTemplate = dynamictemplateItem;
                templateField.HeaderText = headName.Trim();
                templateField.AccessibleHeaderText = tagName.Trim().ToUpper();
                templateField.ItemStyle.BackColor = System.Drawing.Color.WhiteSmoke;
                grdAllocation.Columns.Insert(colOrder, templateField);

            }
            else
            {
                Label lblText = new Label();
                lblText.ID = "lbl" + fldName.Trim();
                lblText.Visible = true;
                lblText.Width = colWidth;
                dynamictemplateItem.AddControl(lblText, "Text", fldName);
                templateField.ItemTemplate = dynamictemplateItem;
                templateField.HeaderText = headName.Trim();
                templateField.AccessibleHeaderText = tagName.Trim().ToUpper();
                switch (dataType.Trim().ToUpper())
                {
                    case "STRING":
                    case "DATE":
                        templateField.ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                        break;
                    case "DECIMAL":
                        templateField.ItemStyle.HorizontalAlign = HorizontalAlign.Right;
                        break;
                }
                grdAllocation.Columns.Insert(colOrder, templateField);
            }
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            hiddModalClose.Value = Convert.ToString(VchrAmt);
            Session["tmpMallDtSess"] = tmpMall_vw;
            Session["mallDtSess"] = mall_vw;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "SetData()", "SetData();", true);
        }


        protected void grdAllocation_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row == null)
                return;

            if (e.Row.DataItem == null)
                return;
            
            if (e.Row.RowType != DataControlRowType.DataRow)
                return;

            if (e.Row.RowType != DataControlRowType.Header &&
                e.Row.RowType != DataControlRowType.Footer &&
                e.Row.RowType != DataControlRowType.Pager)
            {
                Button btn = new Button();
                btn = (Button)e.Row.FindControl("btnAlloc");
                btn.Text = "Allocate";
                btn.CssClass = "AllocButton"; 
                btn.CommandArgument = e.Row.RowIndex.ToString();
            }

            if (numFunction.toDecimal((((TextBox)e.Row.FindControl("txtnew_all")) == null ? "0" :
                ((TextBox)e.Row.FindControl("txtnew_all")).Text)) != 0 ||
                numFunction.toDecimal((((TextBox)e.Row.FindControl("txttds")) == null ? "0" :
                ((TextBox)e.Row.FindControl("txttds")).Text)) != 0 ||
                numFunction.toDecimal((((TextBox)e.Row.FindControl("txtdisc")) == null ? "0" :
                ((TextBox)e.Row.FindControl("txtdisc")).Text)) != 0)
            {
                e.Row.ForeColor = System.Drawing.Color.Red;
            }

            e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#ebebeb'");
            e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#F8F8F8' ");

            NumericTextBox txtTds = (NumericTextBox)e.Row.FindControl("txttds");
            if (txtTds != null)
            {
                if (numFunction.toDecimal(txtTds.Text) != 0)
                {
                    txtTds.ForeColor = System.Drawing.Color.Red;
                }

                txtTds.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddTds.ClientID + "','" + txtTds.ClientID + "')");
            }

            NumericTextBox txtDisc = (NumericTextBox)e.Row.FindControl("txtdisc");
            if (txtDisc != null)
            {
                if (numFunction.toDecimal(txtDisc.Text) != 0)
                {
                    txtDisc.ForeColor = System.Drawing.Color.Red;
                }
                txtDisc.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddDisc.ClientID + "','" + txtDisc.ClientID + "')");
            }

            NumericTextBox txtAllocate = (NumericTextBox)e.Row.FindControl("txtnew_all");
            if (txtAllocate != null)
            {
                if (numFunction.toDecimal(txtAllocate.Text) != 0)
                {
                    txtAllocate.ForeColor = System.Drawing.Color.Red;
                }
                txtAllocate.Attributes.Add("onfocus", "javascript:updateHiddenField('" + this.hiddAllocate.ClientID + "','" + txtAllocate.ClientID + "')");
            }

        }
        protected void grdAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('Row Command');", true);
            //Button cmdButton = new Button();
            //cmdButton = ((Button)grid);
            // GridViewRow grdRow = (GridViewRow)(((Button)e.CommandSource).NamingContainer);
            
            if (e.CommandName.ToString().ToUpper().Trim() != "SELECT")
            {
                return;
            }

            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow grdRow = grdAllocation.Rows[rowIndex];

            string key = grdAllocation.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString().Trim();
            //Dim key As String = Me.GridAccount.DataKeys(CInt(e.CommandArgument)).Value.ToString()
            //acDetRow = MainDataSet.Tables("acdet_vw").Select("acSerial = '" + key + "'")(0)

            decimal allocate = 0;
            decimal tds = 0;
            decimal disc = 0;

            allocate = numFunction.toDecimal((((TextBox)grdAllocation.Rows[grdRow.RowIndex].FindControl("txtnew_all")) == null ? "0" :
                                            ((TextBox)grdAllocation.Rows[grdRow.RowIndex].FindControl("txtnew_all")).Text));
            tds = numFunction.toDecimal(numFunction.toDecimal((((TextBox)grdAllocation.Rows[grdRow.RowIndex].FindControl("txttds")) == null ? "0" :
                                       ((TextBox)grdAllocation.Rows[grdRow.RowIndex].FindControl("txttds")).Text)));
            disc = numFunction.toDecimal((((TextBox)grdAllocation.Rows[grdRow.RowIndex].FindControl("txtdisc")) == null ? "0" :
                                        ((TextBox)grdAllocation.Rows[grdRow.RowIndex].FindControl("txtdisc")).Text));

            DataRow tmpRow = tmpMall_vw.Select("id = '" + key + "'")[0];
            tmpRow["new_all"] = allocate;
            tmpRow["tds"] = tds;
            tmpRow["disc"] = disc;
            tmpRow.AcceptChanges();

            vuAllocation getAllocation = new vuAllocation();
            if (allocate != 0)
            {
                getAllocation.allocateTxtBox_TextChanged(addMode, editMode, tmpMall_vw, main_vw, lblAmount, lblTotAlloc, lblBalance, allocate, vAmt, numFunction.toDecimal(this.hiddAllocate.Value), chkAllocExecess, tmpRow);
                VchrAmt = getAllocation.VchrAmt;

                if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                    return;
                }

            }

            if (tds != 0)
            {
                getAllocation.tdsamtTxtBox_TextChanged(addMode, editMode, tmpMall_vw, main_vw, tds, numFunction.toDecimal(this.hiddTds.Value), vAmt, tmpRow);

                if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                    return;
                }

            }

            if (disc != 0)
            {
                getAllocation.discountTxtBox_TextChanged(addMode, editMode, tmpMall_vw, main_vw, disc, numFunction.toDecimal(this.hiddDisc.Value), vAmt, tmpRow);

                if (getAllocation.ErrorMessage != "" && getAllocation.ErrorMessage != null)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert()", "alert('" + getAllocation.ErrorMessage.Trim() + "');", true);
                    return;
                }
            }
            grdAllocation.DataSource = tmpMall_vw;
            grdAllocation.DataBind();
        }
        protected void grdAllocation_RowCreated(object sender, GridViewRowEventArgs e)
        {
            // if (e.Row.RowType == DataControlRowType.DataRow &&
            //(e.Row.RowState == DataControlRowState.Normal ||
            // e.Row.RowState == DataControlRowState.Alternate))
            // {
            //     e.Row.TabIndex = -1;
            //     e.Row.Attributes["onclick"] =
            //       string.Format("javascript:SelectRow(this, {0});", e.Row.RowIndex);
            //    // e.Row.Attributes["onkeydown"] = "javascript:return SelectSibling(event);";
            //    // e.Row.Attributes["onselectstart"] = "javascript:return false;";

            // }
        }
        protected void grdAllocation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAllocation.PageIndex = e.NewPageIndex;
            grdAllocation.DataSource = tmpMall_vw;
            grdAllocation.DataBind();
        }
        protected void chkAllocExecess_CheckedChanged(object sender, EventArgs e)
        {
            decimal vchrBal1 = numFunction.toDecimal(this.lblTotAlloc.Text);
            if (chkAllocExecess.Checked == true)
            {
                VchrAmt = vchrBal1;
            }
            else
            {
                VchrAmt = FromAcAmt;
            }

        }
        protected void grdAllocation_DataBound(object sender, EventArgs e)
        {

        }
}
}
