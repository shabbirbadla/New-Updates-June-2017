using System;
using System.Data;
using System.Data.SqlClient; 
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using Business.Logic.Layer;
using Controls;

namespace Udyog.E.Billing
{
    public partial class uwETSRItemDetail : System.Web.UI.Page
    {
        //static int Tex_exe;
        //static string[,] Tex_ExAr;
        //static bool et_flag = false;

        private int tex_exe;
        public int Tex_exe
        {
            get { return tex_exe; }
            set { tex_exe = value; }
        }

        private bool et_flag;
        public bool Et_flag
        {
            get { return et_flag; }
            set { et_flag = value; }
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        private string sqlstr;
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable ToShow;
            DataTable curPurchaseDet;
            string[,] Tex_ExAr;
            if (IsPostBack == true)
            {
                Tex_ExAr = SessionProxy.Tex_ExAr;
                Tex_exe = Convert.ToInt32(Request.QueryString["Tex_exe"]);
                ToShow = SessionProxy.ToShow;
                curPurchaseDet = SessionProxy.CurPurchaseDet; 

                grdGenerate(Tex_exe,
                        Tex_ExAr);
                gridBind(ToShow,curPurchaseDet);

                ToShow.Dispose();
                curPurchaseDet.Dispose();

                return;
            }


            Tex_ExAr = SessionProxy.Tex_ExAr;

            Tex_exe = Convert.ToInt32(Request.QueryString["Tex_exe"]);
            ToShow = SessionProxy.ToShow;
            curPurchaseDet = SessionProxy.CurPurchaseDet;

            DataTable CoAdditional = SessionProxy.MainDataSet.Tables["manufact"];
            DataTable main_vw = SessionProxy.MainDataSet.Tables["main_vw"];
            Tex_ExAr = SessionProxy.Tex_ExAr;   

            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();

            Et_flag = bitFunction.toBoolean(CoAdditional.Rows[0]["et_flag"]);

            foreach (DataRow ToShowRow in ToShow.Rows)
            {
                if (DBNull.Value.Equals(ToShowRow["Supploc"]) == true) 
                    ToShowRow["Supploc"] = "";

                if (DBNull.Value.Equals(ToShowRow["Manuloc"]) == true) 
                    ToShowRow["ManuLoc"] = "";
            }

            grdGenerate(Tex_exe,
                    Tex_ExAr);

            fillDropDownList(ToShow,curPurchaseDet);

            gridBind(ToShow,curPurchaseDet);
 
            CheckInit(ToShow,
                    curPurchaseDet,
                    CoAdditional);

            SessionProxy.ToShow = ToShow;  
            SessionProxy.CurPurchaseDet = curPurchaseDet;
            ToShow.Dispose();
            curPurchaseDet.Dispose();
        }

        protected void CheckInit(DataTable ToShow,
                    DataTable curPurchaseDet,
                    DataTable CoAdditional)
        {
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();

            if (bitFunction.toBoolean(CoAdditional.Rows[0]["et_flag"]) == true)
            {
                dropConsignee.Enabled = false;
                dropManufact.Enabled = false;
                dropWareHouse.Enabled = false;
                return;
            }

            DataTable BuyerNames = curPurchaseDet.DefaultView.ToTable(true,
                    new string[] { "suppname", "suppac_id", "supploc", "suppsac_id" });

            if (BuyerNames.Rows.Count == 1)
            {
                dropConsignee.SelectedValue = Convert.ToString(BuyerNames.Rows[0]["suppname"]);
                if (Convert.ToString(BuyerNames.Rows[0]["suppLoc"]) != "")
                    dropBuyerLocation.SelectedValue = Convert.ToString(BuyerNames.Rows[0]["suppLoc"]);
                dropConsignee.Enabled = false;
                //main_vw.Rows[0]["suppac_id"] = numFunction.toInt32(BuyerNames.Rows[0]["suppac_id"]);
                //main_vw.Rows[0]["suppsac_id"] = numFunction.toInt32(BuyerNames.Rows[0]["suppsac_id"]);
                //main_vw.AcceptChanges();
            }

            DataTable ManuNames = curPurchaseDet.DefaultView.ToTable(true,
                    new string[] { "ManuName", "Manuac_id", "manuloc", "manusac_id" });

            if (ManuNames.Rows.Count == 1)
            {
                dropManufact.SelectedValue = Convert.ToString(ManuNames.Rows[0]["ManuName"]);
                if (Convert.ToString(ManuNames.Rows[0]["Manuloc"]).Trim() !="")
                    dropManuLocation.SelectedValue = Convert.ToString(ManuNames.Rows[0]["Manuloc"]);  

                dropManufact.Enabled = false;
                //main_vw.Rows[0]["manuac_id"] = numFunction.toInt32(ManuNames.Rows[0]["manuac_id"]);
                //main_vw.Rows[0]["manusac_id"] = numFunction.toInt32(ManuNames.Rows[0]["manusac_id"]);
                //main_vw.AcceptChanges();
            }

            DataTable Warehouses = ToShow.DefaultView.ToTable(true,
                    new string[] { "Ware_Nm"});

            if (Warehouses.Rows.Count == 1)
            {
                dropWareHouse.SelectedValue = Convert.ToString(Warehouses.Rows[0]["Ware_Nm"]);
                dropWareHouse.Enabled = false;
            }

            BuyerNames.Dispose();
            ManuNames.Dispose();
            Warehouses.Dispose(); 
        }

        protected void fillDropDownList(DataTable ToShow,
                DataTable curPurchaseDet)
        {
            DataTable ToShowView = new DataTable();
            ToShowView = curPurchaseDet.DefaultView.ToTable(true,
                        new string[] {"Suppname","Supploc"});
            dropConsignee.DataSource = ToShowView;
            dropConsignee.DataTextField = "suppname";
            dropConsignee.DataValueField = "suppname";
            dropConsignee.DataBind();
            dropConsignee.Items.Insert(0,"--Select Buyer--");

            foreach (DataRow ToShowRow in ToShowView.Rows)
            {
                if (Convert.ToString(ToShowRow["Supploc"]).Trim() != "")
                {
                    dropBuyerLocation.Items.Add(Convert.ToString(ToShowRow["SuppLoc"]).Trim());
                }
            }
            dropBuyerLocation.Items.Insert(0, "--Select Buyer Location--");  

            if (ToShowView.Rows.Count > 1)
            {
                dropBuyerLocation.Enabled = true;
            }
            else
            {
                if (ToShowView.Rows.Count <= 1)
                {
                    dropBuyerLocation.Enabled = false; 
                }
            }
             
            ToShowView = new DataTable();
            ToShowView = curPurchaseDet.DefaultView.ToTable(true,
                        new string[] { "ManuName", "Manuloc" });
            dropManufact.DataSource = ToShowView;
            dropManufact.DataTextField = "ManuName";
            dropManufact.DataValueField = "ManuName";
            dropManufact.DataBind();
            dropManufact.Items.Insert(0, "--Select Manufacturer--");

            foreach (DataRow ToShowRow in ToShowView.Rows)
            {
                if (Convert.ToString(ToShowRow["Manuloc"]).Trim() != "")
                {
                    dropManuLocation.Items.Add(Convert.ToString(ToShowRow["Manuloc"]).Trim());
                }
            }
            dropManuLocation.Items.Insert(0, "--Select Manufacturer Location--");

            if (ToShowView.Rows.Count > 1)
            {
                dropManuLocation.Enabled = true;
            }
            else
            {
                if (ToShowView.Rows.Count <= 1)
                {
                    dropManuLocation.Enabled = false;
                }
            }

            ToShowView = new DataTable();
            ToShowView = ToShow.DefaultView.ToTable(true,
                        new string[] { "Ware_Nm"});
            dropWareHouse.DataSource = ToShowView;
            dropWareHouse.DataTextField = "Ware_Nm";
            dropWareHouse.DataValueField = "Ware_Nm";
            dropWareHouse.DataBind();
            dropWareHouse.Items.Insert(0, "--Select Warehouse--");

            ToShowView.Dispose();
        }

        protected void grdGenerate(int Tex_exe,
            string[,] Tex_ExAr)
        {
            grdSItemDet.Columns.Clear();
  
            TemplateField templateField = new TemplateField();
            DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            BoundField bndField = null;

            CheckBox chkBox = new CheckBox();
            chkBox.ID = "ChkSelectS";

            dynamictemplateItem.AddControl(chkBox, "Checked", "ToCheck");
            templateField.ItemTemplate = dynamictemplateItem;
            grdSItemDet.Columns.Add(templateField);
            grdSItemDet.Columns[0].HeaderText = "Select";
            grdSItemDet.Columns[0].AccessibleHeaderText = "Select";
         

            // Bill No. - Column Order 2
            bndField = grdBoundField(ref bndField,
                            "inv_no",
                            "Bill No.",
                            HorizontalAlign.Left,"STRING",30);

            grdSItemDet.Columns.Add(bndField);  

            // Date - Column Order 3
            bndField = grdBoundField(ref bndField,
                            "date",
                            "Date",
                            HorizontalAlign.Left,"DATETIME",30);
            grdSItemDet.Columns.Add(bndField);  

            // Qty - Column Order 4
            grdBoundField(ref bndField,
                            "qty",
                            "Qty.",
                            HorizontalAlign.Left,"DECIMAL",30);
            grdSItemDet.Columns.Add(bndField);

            // BalQty - Column Order 5
            grdBoundField(ref bndField,
                            "balqty",
                            "Bal. Qty",
                            HorizontalAlign.Right,"DECIMAL",30);
            grdSItemDet.Columns.Add(bndField);

            // Return.Qty - Column Order 6
            dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            templateField = new TemplateField();
            NumericTextBox numBox = new NumericTextBox();
            numBox.ID = "numAlloQtyS";
            numBox.CssClass = "form_textfield3";
            numBox.Enabled = false;
            numBox.Width = Unit.Pixel(85);
            dynamictemplateItem.AddControl(numBox,"Text","AlloQty");
            templateField.ItemTemplate = dynamictemplateItem;
            grdSItemDet.Columns.Add(templateField);
            grdSItemDet.Columns[5].HeaderText = "Return Qty.";
            grdSItemDet.Columns[5].AccessibleHeaderText = "RetQty";



            // Excise - Column Order 7
            grdBoundField(ref bndField,
                            "excbal",
                            "Excise",
                            HorizontalAlign.Right,"DECIMAL",30);
            grdSItemDet.Columns.Add(bndField);

            for (int mTex_Exs = 1; mTex_Exs < Tex_exe; mTex_Exs++)
            {
                if (Tex_ExAr[mTex_Exs, 2].Trim().ToUpper().IndexOf("EXCBAL") == -1)
                {
                    grdBoundField(ref bndField,
                                    Tex_ExAr[mTex_Exs, 2].Trim(),
                                    Tex_ExAr[mTex_Exs, 0].Trim(),
                                    HorizontalAlign.Right,"DECIMAL",30);
                    grdSItemDet.Columns.Add(bndField);
                }
            }

            // Purchase Grid

            grdPItemDet.Columns.Clear();

            //TemplateField templateField = new TemplateField();
            //DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            //BoundField bndField = null;

            chkBox = new CheckBox();
            chkBox.ID = "ChkSelectP";
            dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            dynamictemplateItem.AddControl(chkBox, "Checked", "ToCheck");
            templateField = new TemplateField();
            templateField.ItemTemplate = dynamictemplateItem;
            grdPItemDet.Columns.Add(templateField);
            grdPItemDet.Columns[0].HeaderText = "Select";
            grdPItemDet.Columns[0].AccessibleHeaderText = "Select";

            // Bill No. - Column Order 2
            bndField = grdBoundField(ref bndField,
                            "inv_no",
                            "Bill No.",
                            HorizontalAlign.Left, "STRING",30);

            grdPItemDet.Columns.Add(bndField);

            // Date. - Column Order 3
            bndField = grdBoundField(ref bndField,
                            "date",
                            "Date",
                            HorizontalAlign.Left, "DATETIME",30);
            grdPItemDet.Columns.Add(bndField);

            // Supplier Name - Column Order 4
            bndField = grdBoundField(ref bndField,
                            "suppname",
                            "Supplier Name",
                            HorizontalAlign.Left, "STRING",100);
            grdPItemDet.Columns.Add(bndField);

            // Qty - Column Order 5
            grdBoundField(ref bndField,
                            "qty",
                            "Qty.",
                            HorizontalAlign.Left, "DECIMAL",30);
            grdPItemDet.Columns.Add(bndField);

            // BalQty - Column Order 6
            grdBoundField(ref bndField,
                            "balqty",
                            "Bal. Qty",
                            HorizontalAlign.Right, "DECIMAL",30);
            grdPItemDet.Columns.Add(bndField);

            // Return.Qty - Column Order 7
            dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            templateField = new TemplateField();
            numBox = new NumericTextBox();
            numBox.ID = "numAlloQtyP";
            numBox.CssClass = "form_textfield3";
            numBox.Enabled = false;
            numBox.Width = Unit.Pixel(85);
            dynamictemplateItem.AddControl(numBox, "Text", "AlloQty");
            templateField.ItemTemplate = dynamictemplateItem;
            grdPItemDet.Columns.Add(templateField);
            grdPItemDet.Columns[6].HeaderText = "Return Qty.";
            grdPItemDet.Columns[6].AccessibleHeaderText = "RetQty";

            // Excise - Column Order 8
            grdBoundField(ref bndField,
                            "excbal",
                            "Excise",
                            HorizontalAlign.Right, "DECIMAL",30);
            grdPItemDet.Columns.Add(bndField);

            // RG Page - Column Order 9
            bndField = grdBoundField(ref bndField,
                            "rgPage",
                            "RG Page",
                            HorizontalAlign.Left, "STRING",30);
            grdPItemDet.Columns.Add(bndField);

            // MT Duty
            grdBoundField(ref bndField,
                            "mtduty",
                            "MT. Duty",
                            HorizontalAlign.Right, "DECIMAL",30);
            grdPItemDet.Columns.Add(bndField);

            // MT Duty
            grdBoundField(ref bndField,
                            "entry_ty",
                            "Type",
                            HorizontalAlign.Left, "STRING",30);
            grdPItemDet.Columns.Add(bndField);

            for (int mTex_Exs = 1; mTex_Exs < Tex_exe; mTex_Exs++)
            {
                if (Tex_ExAr[mTex_Exs, 2].Trim().ToUpper().IndexOf("EXCBAL") == -1)
                {
                    grdBoundField(ref bndField,
                                    Tex_ExAr[mTex_Exs, 2].Trim(),
                                    Tex_ExAr[mTex_Exs, 0].Trim(),
                                    HorizontalAlign.Right, "DECIMAL",30);
                    grdPItemDet.Columns.Add(bndField);
                }
            }
       }

        protected void gridBind(DataTable ToShow,
            DataTable curPurchaseDet)
        {
            grdSItemDet.DataSource = ToShow;
            grdSItemDet.DataBind();

            grdPItemDet.DataSource = curPurchaseDet;
            grdPItemDet.DataBind();
        }

        protected BoundField grdBoundField(ref BoundField bndField,
                    string dataField,
                    string headerText,
                    HorizontalAlign HorzAlign,
                    string DataType,
                    int width)
        {
            bndField = new BoundField();
            bndField.DataField = dataField.ToString().Trim();
            bndField.HeaderText = headerText.ToString().Trim(); 
            bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
            bndField.ItemStyle.HorizontalAlign = HorzAlign;
            bndField.ItemStyle.Width = Unit.Pixel(width); 
            if (DataType.Trim().ToUpper() == "DECIMAL")
            {
                bndField.DataFormatString = "{0:F2}";
                bndField.HtmlEncode = false;
            }
            else
            {
                if (DataType.Trim().ToUpper() == "DATETIME")
                {
                    bndField.DataFormatString = "{0:dd/M/yyyy}";
                    bndField.HtmlEncode = false;
                }
            }

            return bndField; 
        }

        protected DataTable Filter(DataTable ToShow)
        {
            if (et_flag == true)
                return null;

            DataView ToshowView = ToShow.DefaultView;

            string filterExp = "";
            if (dropConsignee.SelectedIndex != 0)
                filterExp = " suppname ='" + dropConsignee.SelectedItem.ToString().Trim() + "'" +
                            " and supploc ='" + 
                            (dropBuyerLocation.SelectedIndex != 0 ?
                            dropBuyerLocation.SelectedItem.ToString().Trim() : "") + "'"; 
                            

            if (dropManufact.SelectedIndex !=0)
                filterExp = filterExp + (filterExp != "" ? " And " : "") + 
                    " manuname ='" + dropManufact.SelectedItem.ToString().Trim() + "'" +
                            " and manuloc ='" + 
                            ( dropManuLocation.SelectedIndex != 0 ?
                            dropManuLocation.SelectedItem.ToString().Trim() : "") + "'"; 

            if (dropWareHouse.SelectedIndex !=0)
                filterExp = filterExp + (filterExp != "" ? " And " : "") + 
                            " ware_nm ='" + dropWareHouse.SelectedItem.ToString().Trim() +"'";

            ToshowView.RowFilter = filterExp;
            ToShow = ToshowView.ToTable();

            grdSItemDet.DataSource = ToShow;
            grdSItemDet.DataBind();

            return ToShow;
        }

        protected void chkBoxP_CheckedChanged(object sender, EventArgs e)
        {
            DataTable curPurchaseDet = SessionProxy.CurPurchaseDet; 
            CheckBox chkBoxP = ((CheckBox)sender);
            GridViewRow row = ((GridViewRow)chkBoxP.NamingContainer);

            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();

            string entry_ty = Convert.ToString(grdPItemDet.DataKeys[row.RowIndex].Values[0]).Trim();
            int tran_cd = Convert.ToInt32(grdPItemDet.DataKeys[row.RowIndex].Values[1]);
            string itSerial = Convert.ToString(grdPItemDet.DataKeys[row.RowIndex].Values[2]).Trim();

            DataRow curPurchaseDetRow = curPurchaseDet.Select("entry_ty ='" + entry_ty +
                                       "' and tran_cd = " + tran_cd +
                                       " and itserial ='" + itSerial + "'")[0];

            if (chkBoxP.Checked == true)
            {
                curPurchaseDetRow["ToCheck"] = true;
                curPurchaseDetRow["alloqty"] = numFunction.toDecimal(curPurchaseDetRow["balqty"]);
            }
            else
            {
                curPurchaseDetRow["ToCheck"] = false;
                curPurchaseDetRow["alloqty"] = 0;
            }

            curPurchaseDetRow.AcceptChanges();
            curPurchaseDet.AcceptChanges();

            SessionProxy.CurPurchaseDet = curPurchaseDet; 
            curPurchaseDet.Dispose(); 
        }

        protected void chkBoxS_CheckedChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            DataTable curPurchaseDet = SessionProxy.CurPurchaseDet;
            //DataTable main_vw = SessionProxy.MainDataSet.Tables["main_vw"];
            DataTable CoAdditional = SessionProxy.MainDataSet.Tables["manufact"]; 

            CheckBox chkBoxS = ((CheckBox)sender);
            GridViewRow row = ((GridViewRow)chkBoxS.NamingContainer);

            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();

            string entry_ty = Convert.ToString(grdSItemDet.DataKeys[row.RowIndex].Values[0]).Trim();
            int tran_cd = Convert.ToInt32(grdSItemDet.DataKeys[row.RowIndex].Values[1]);
            string itSerial = Convert.ToString(grdSItemDet.DataKeys[row.RowIndex].Values[2]).Trim();

            if (chkBoxS.Checked == true)
            {
                
                DataRow ToShowSelectedRow = ToShow.Select("entry_ty ='" + entry_ty +
                                        "' and tran_cd = " + tran_cd +
                                        " and itserial ='" + itSerial + "'")[0];

                ToShowSelectedRow["alloQty"] = numFunction.toDecimal(ToShowSelectedRow["balqty"]);
                ToShowSelectedRow["ToCheck"] = true;

                decimal SumQty =  (decimal)ToShow.Compute("Sum(alloqty)", "");
                SumQty = numFunction.toDecimal(SumQty, 2); 
                lblTotqty.Text = "Total Adjust Qty : " +Convert.ToString(SumQty);

                string filterExp = "pentry_ty ='" + Convert.ToString(ToShowSelectedRow["entry_ty"]).Trim() + "'" +
                        " and ptran_cd =" + numFunction.toInt32(ToShowSelectedRow["tran_cd"]) +
                        " and pitserial ='" + Convert.ToString(ToShowSelectedRow["itserial"]).Trim() + "'";

                foreach (DataRow curPurchaseRow in curPurchaseDet.Select(filterExp))
                {
                    curPurchaseRow["AlloQty"] = numFunction.toDecimal(ToShowSelectedRow["balqty"]);
                    curPurchaseRow["tocheck"] = true;
                    curPurchaseRow.AcceptChanges();  
                }

            }
            else
            {
                if (chkBoxS.Checked == false)
                {
                    DataRow ToShowSelectedRow = ToShow.Select("entry_ty ='" + entry_ty +
                                            "' and tran_cd = " + tran_cd +
                                            " and itserial ='" + itSerial + "'")[0];

                    ToShowSelectedRow["alloQty"] = 0;
                    ToShowSelectedRow["ToCheck"] = false;

                    decimal SumQty = (decimal)ToShow.Compute("Sum(alloqty)", "");
                    SumQty = numFunction.toDecimal(SumQty, 2);
                    lblTotqty.Text = "Total Adjust Qty : " + Convert.ToString(SumQty);

                    string filterExp = "pentry_ty ='" + Convert.ToString(ToShowSelectedRow["entry_ty"]).Trim() + "'" + 
                            " and ptran_cd =" + numFunction.toInt32(ToShowSelectedRow["tran_cd"]) +
                            " and pitserial ='" + Convert.ToString(ToShowSelectedRow["itserial"]).Trim() + "'";

                    foreach (DataRow curPurchaseRow in curPurchaseDet.Select(filterExp))
                    {
                        curPurchaseRow["Alloqty"] = 0;
                        curPurchaseRow["tocheck"] = false;
                    }
                }
            }

            gridBind(ToShow,
                curPurchaseDet);

            NumericTextBox numBoxS = (NumericTextBox)grdSItemDet.Rows[row.RowIndex].FindControl("numAlloQtyS");
            if (chkBoxS.Checked == true)
            {
                numBoxS.Enabled = true;
            }
            else
            {
                numBoxS.Enabled = false;
            }

            ToShow.AcceptChanges();
            curPurchaseDet.AcceptChanges();  
            //main_vw.AcceptChanges();
            SessionProxy.ToShow = ToShow; 
            SessionProxy.CurPurchaseDet = curPurchaseDet;

            ToShow.Dispose();
            curPurchaseDet.Dispose(); 


        }

        protected void CheckSValid(DataTable ToShow,
                    DataTable curPurchaseDet)
        {
            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();

            string mess = "";
            string invNos = "";
            foreach (DataRow ToShowRow in ToShow.Select("ToCheck = 1"))
            {
                string filterExp = "pentry_ty ='" + Convert.ToString(ToShowRow["entry_ty"]).Trim() + "'" +
                    " and ptran_cd =" + numFunction.toInt32(ToShowRow["tran_cd"]) +
                    " and pitserial ='" + Convert.ToString(ToShowRow["itserial"]).Trim() + "'";

                decimal alloQty = (decimal)curPurchaseDet.Compute("Sum(alloqty)", filterExp);

                if (alloQty != numFunction.toDecimal(ToShowRow["alloqty"]))
                {
                    mess = "Allocated Qty. is not matching with \n the Qty. allocated in purchase detail";
                    invNos = invNos + ((invNos.Trim() != "" ? "," : "") + Convert.ToString(ToShowRow["inv_no"]).Trim());
                }
            }

            if (mess.Trim() != "")
            {
                mess = mess + ("\n for Transaction nos. " + invNos);
                throw new Exception(mess);
            }
        }

        protected void BalanceQtyUpdate(DataTable ToShow,
                    DataTable curPurchaseDet,
                    ref DataTable litemall_vw,
                    DataTable main_vw,
                    ref DataRow itemRow)
        {

            DataTable company = SessionProxy.Company; 

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            
            decimal updtQty = 0;
            string[,] Tex_ExAr = SessionProxy.Tex_ExAr;

            foreach (DataRow curPurchaseDetRow in curPurchaseDet.Select("ToCheck = 1"))
            {
                updtQty = numFunction.toDecimal(curPurchaseDetRow["alloqty"]);

                string fmFields = "";
                string fmFieldsa = "";
                for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                {
                    fmFieldsa = Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                    fmFields = fmFields.Trim() + (fmFields.Trim() == "" ? "" : ",") +
                            fmFieldsa.Trim();
                    fmFieldsa = Tex_ExAr[tex_exs, 5].Trim().Replace("ITEM_VW", "");
                    fmFields = fmFields.Trim() + (fmFields.Trim() == "" ? "" : ",") +
                            fmFieldsa.Trim();
                }

                sqlstr = "Select CompId,Tran_Cd,Entry_ty,Date,Itserial,Inv_no," +
                         " Ware_nm,Rgpage,Mtduty,Qty," + fmFields +
                         " From TradeItem " +
                         " Where entry_ty='" + Convert.ToString(curPurchaseDetRow["entry_ty"]).Trim() + "'" +
                         " and tran_cd= " + numFunction.toInt32(curPurchaseDetRow["tran_cd"]) +
                         " and itserial ='" + Convert.ToString(curPurchaseDetRow["itserial"]).Trim() + "'";

                DataTier DataAcess = new DataTier();
                DataTable TradeItem_Vw = DataAcess.ExecuteDataTable(sqlstr, "_tradeItemVw",connHandle);
                DataAcess.Connclose(connHandle);
 
                DataRow litemallRow = litemall_vw.NewRow();
                litemallRow["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim();
                litemallRow["tran_cd"] = numFunction.toInt32(main_vw.Rows[0]["tran_cd"]);
                litemallRow["itserial"] = Convert.ToString(itemRow["itserial"]).Trim();
                litemallRow["rgPage"] = Convert.ToString(curPurchaseDetRow["rgpage"]).Trim();
                litemallRow["pentry_ty"] = Convert.ToString(curPurchaseDetRow["entry_ty"]).Trim();
                litemallRow["ptran_cd"] = numFunction.toInt32(curPurchaseDetRow["tran_cd"]);
                litemallRow["pitserial"] = Convert.ToString(curPurchaseDetRow["itserial"]).Trim();
                litemallRow["ware_nm"] = dropWareHouse.SelectedItem.ToString().Trim();
                litemallRow["qty"] = numFunction.toDecimal(curPurchaseDetRow["alloqty"]);
                litemallRow["rentry_ty"] = Convert.ToString(curPurchaseDetRow["rentry_ty"]).Trim();
                litemallRow["rtran_cd"] = numFunction.toInt32(curPurchaseDetRow["rtran_cd"]);
                litemallRow["ritserial"] = Convert.ToString(curPurchaseDetRow["ritserial"]).Trim();

                for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                {
                    if (updtQty > 0)
                    {
                        litemallRow[Tex_ExAr[tex_exs, 1]]
                                = (updtQty * (numFunction.toDecimal(curPurchaseDetRow[Tex_ExAr[tex_exs, 2]]) /
                                             numFunction.toDecimal(curPurchaseDetRow["balqty"])));
                    }
                    else
                    {
                        litemallRow[Tex_ExAr[tex_exs, 1]] = numFunction.toDecimal(curPurchaseDetRow[Tex_ExAr[tex_exs, 2]]);    
                    }
                }

                litemall_vw.Rows.Add(litemallRow);
                litemall_vw.AcceptChanges();

                itemRow["U_basduty"] = numFunction.toDecimal(TradeItem_Vw.Rows[0]["u_basduty"]);
                itemRow["u_cessper"] = numFunction.toDecimal(TradeItem_Vw.Rows[0]["u_cessper"]);
                itemRow["u_cvdper"] = numFunction.toDecimal(TradeItem_Vw.Rows[0]["u_cvdper"]);
   
                for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                {
                    itemRow[Tex_ExAr[tex_exs, 1]] = numFunction.toDecimal(TradeItem_Vw.Rows[0][Tex_ExAr[tex_exs,1].ToString().Trim()]) +
                        numFunction.toDecimal(litemallRow[Tex_ExAr[tex_exs,1]]);
                    itemRow[Tex_ExAr[tex_exs, 5]] = numFunction.toDecimal(TradeItem_Vw.Rows[0][Tex_ExAr[tex_exs, 5].ToString().Trim()]);

                }
                //itemRow.AcceptChanges();  
                TradeItem_Vw.Dispose(); 
             }
             company.Dispose();
        }

        protected string genPageNo(DataRow TradeItemRow)
        {
            int vsentno = 0;
            string vspageno = "";
            int stoaddinlist = 1;
            int stot = 5;
            int sbrk = 130;
            DataTier DataAcess = new DataTier();
            numericFunction numFunction = new numericFunction();
            sqlstr = "Select * From LitemAll where rgpage='" + Convert.ToString(TradeItemRow["rgpage"]).Trim() + "'" +
                     " and ware_nm ='" + Convert.ToString(TradeItemRow["ware_nm"]).Trim() + "'";

            DataTable GenSpageNo = DataAcess.ExecuteDataTable(sqlstr, "_SS",connHandle);
            DataAcess.Connclose(connHandle);  
            if (GenSpageNo.Rows.Count <= 0)
            {
                vsentno = 1;
                vspageno = Convert.ToString(TradeItemRow["rgPage"]);
                return Convert.ToString(vsentno).Trim().PadLeft(10) + vspageno; 
            }

            DataRow itemRow = SessionProxy.EtItemRow; 

            DataTable pageNo = new DataTable();
            DataColumn pageNoCol = new DataColumn();
            pageNoCol.ColumnName = "spageno";
            pageNoCol.DataType = Type.GetType("System.String");
            pageNo.Columns.Add(pageNoCol);

            pageNoCol = new DataColumn();
            pageNoCol.ColumnName = "sentno";
            pageNoCol.DataType = Type.GetType("System.Int32");
            pageNo.Columns.Add(pageNoCol);
   
            int vctrzz = 0;
            int snow,snow1 = 0;
            DataRow PageNoRow = null;
            foreach (DataRow GenSpageNoRow in GenSpageNo.Rows)
            {
                vctrzz = vctrzz + 1;
                if (numFunction.toInt32(GenSpageNoRow["sentno"]) != vctrzz)
                {
                    for (int i = vctrzz; i <= numFunction.toInt32(GenSpageNoRow["sentno"]); i++)
                    {
                        PageNoRow = pageNo.NewRow();
                        if (i <= stot)
                        {
                            PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]);
                        }
                        else
                        {
                            if (i <= sbrk + stot)
                            {
                                snow = i - 1;
                                PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                                       "-" + Convert.ToString(64 + snow / stot);
                            }
                            else
                            {
                                snow = i - (stot + 1);
    				            snow1 = i - ((snow / sbrk) * sbrk);
                                PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                                       "-" + Convert.ToString(64 + snow / stot) +
                                                       Convert.ToString((snow1 % stot == 0 ? 63 : 64) +
                                                       (snow1 / stot));
                            }
                        }
                        PageNoRow["sentno"] = Convert.ToString(i).Trim();
                        pageNo.Rows.Add(PageNoRow);   
                        pageNo.AcceptChanges(); 
                    }
                    vctrzz = numFunction.toInt32(GenSpageNoRow["sentno"]);
                }

                vsentno = numFunction.toInt32(GenSpageNoRow["sentno"]);
                vspageno = Convert.ToString(GenSpageNoRow["spageno"]); 
            }

            if (pageNo.Rows.Count > 0)
            {
                vctrzz = vctrzz + 1;
                PageNoRow = pageNo.NewRow();
                if (vctrzz <= stot)
                {
                    PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]);
                }
                else
                {
                    if (vctrzz <= sbrk + stot)
                    {
                        snow = vctrzz - 1;
                        PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot);
                    }
                    else
                    {
                        snow = vctrzz - (stot + 1);
                        snow1 = vctrzz - ((snow / sbrk) * sbrk);
                        PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot) +
                                               Convert.ToString((snow1% stot == 0 ? 63 : 64) +
                                               (snow1 / stot));
                    }
                }

                PageNoRow["sentno"] = Convert.ToString(vctrzz).Trim();
                pageNo.Rows.Add(PageNoRow);
                pageNo.AcceptChanges();
                //grdPageno.DataSource = pageNo;
                //grdPageno.DataBind();
                //pnlPagePop.Visible = true;
                
            }
            else
            {
                vctrzz = vctrzz + 1;
                if (vctrzz <= stot)
                {
                    vspageno = Convert.ToString(TradeItemRow["rgpage"]);
                }
                else
                {
                    if (vctrzz <= sbrk + stot)
                    {
                        snow = vctrzz - 1;
                        vspageno = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot);
                    }
                    else
                    {
                        snow = vctrzz - (stot + 1);
                        snow1 = vctrzz - ((snow / sbrk) * sbrk);
                        vspageno = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot) +
                                               Convert.ToString((snow1 % stot == 0 ? 63 : 64) +
                                               (snow1 / stot));
                    }
                }
                vsentno = vctrzz;
                //pnlPagePop.Visible = false;
                
            }
            GenSpageNo.Dispose();
            return Convert.ToString(vsentno).Trim().PadLeft(10) + vspageno; 
        }

        protected void dropConsignee_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow; 
        }

        protected void dropBuyerLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow; 
        }

        protected void dropManufact_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow;
        }

        protected void dropManuLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow; 

        }

        protected void dropWareHouse_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow; 

        }

        protected void btnProceed_Click(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            DataTable curPurchaseDet = SessionProxy.CurPurchaseDet;  
            try
            {
                CheckSValid(ToShow, curPurchaseDet);
            }
            catch (Exception Ex)
            {
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message + "');", true);
                DisplayMessage(Ex.Message.Trim());
                return;
            }
 
            decimal totQty = (decimal)ToShow.Compute("Sum(alloqty)", "");
            numericFunction numFunction = new numericFunction();
            string retMess = "Total Allocated Quantity is : " +
                Convert.ToString(numFunction.toDecimal(totQty,2)).Trim() +
                ",Want to proceed ?";

            ToShow.Dispose();
            curPurchaseDet.Dispose();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ConfirmMessWithPostBack('" + retMess.Trim() + "','" + btnGOProceed.ClientID + "');", true);

        }

        protected void btnGOProceed_Click(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            DataRow itemRow = SessionProxy.EtItemRow;
            DataTable curPurchaseDet = SessionProxy.CurPurchaseDet;
            DataTable litemall_vw = SessionProxy.MainDataSet.Tables["litemall_vw"];
            DataTable main_vw = SessionProxy.MainDataSet.Tables["main_vw"];  

            decimal totQty = (decimal)ToShow.Compute("Sum(alloqty)", "");
            itemRow["qty"] = totQty;
            BalanceQtyUpdate(ToShow,
                            curPurchaseDet,                       
                            ref litemall_vw,
                            main_vw, ref itemRow);

            SessionProxy.MainDataSet.AcceptChanges();
            SessionProxy.EtItemRow = itemRow; 


            ScriptManager.RegisterStartupScript(this, this.GetType(), null, "doneDialog();", true);
            return; 
        }

        protected void grdSItemDet_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";

                CheckBox chkSelect = (CheckBox)e.Row.FindControl("chkSelectS");
                chkSelect.AutoPostBack = true;
                chkSelect.CheckedChanged += new EventHandler(chkBoxS_CheckedChanged);

                NumericTextBox numBox = (NumericTextBox)e.Row.FindControl("numAlloQtyS");
                numBox.AutoPostBack = true; 
                numBox.TextChanged += new EventHandler(numBoxS_TextChanged); 
            }
        }

        protected void grdPItemDet_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";

                CheckBox chkSelect = (CheckBox)e.Row.FindControl("chkSelectP");
                chkSelect.AutoPostBack = true;
                chkSelect.CheckedChanged += new EventHandler(chkBoxP_CheckedChanged);

                //NumericTextBox numBox = (NumericTextBox)e.Row.FindControl("numAlloQty");
                //numBox.AutoPostBack = true;
                //numBox.TextChanged += new EventHandler(numBoxP_TextChanged);
            }
        }

        protected void numBoxS_TextChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            DataTable CoAdditional = SessionProxy.MainDataSet.Tables["manufact"];
            DataTable main_vw = SessionProxy.MainDataSet.Tables["main_vw"];
            DataTable curPurchaseDet = SessionProxy.CurPurchaseDet;  

            numericFunction numFunction = new numericFunction();

            NumericTextBox numBox = ((NumericTextBox)sender);
            GridViewRow row = ((GridViewRow)numBox.NamingContainer);

            string entry_ty =  Convert.ToString(grdSItemDet.DataKeys[row.RowIndex].Values[0]);
            int trancd = Convert.ToInt32(grdSItemDet.DataKeys[row.RowIndex].Values[1]);
            string itSerial = Convert.ToString(grdSItemDet.DataKeys[row.RowIndex].Values[2]);

            DataRow ToShowSelectedRow = ToShow.Select("entry_ty ='" + entry_ty +
                                 "' and tran_cd = " + trancd +
                                 " and itserial ='" + itSerial + "'")[0];

            CheckBox chkBoxS = (CheckBox)grdSItemDet.Rows[row.RowIndex].FindControl("ChkSelectS");
            NumericTextBox numBoxS = (NumericTextBox)grdSItemDet.Rows[row.RowIndex].FindControl("numAlloQtyS");
            if (numFunction.toDecimal(numBoxS.Text) > 0)
            {
                chkBoxS.Checked = true;

                string filterExp = "pentry_ty ='" + Convert.ToString(ToShowSelectedRow["entry_ty"]).Trim() + "'" +
                    " and ptran_cd =" + numFunction.toInt32(ToShowSelectedRow["tran_cd"]) +
                    " and pitserial ='" + Convert.ToString(ToShowSelectedRow["itserial"]).Trim() + "'";

                ToShowSelectedRow["check"] = true;
                ToShowSelectedRow.AcceptChanges(); 
                foreach (DataRow curPurchaseRow in curPurchaseDet.Select(filterExp))
                {
                    curPurchaseRow["tocheck"] = false;
                    curPurchaseRow["Alloqty"] = 0;
                    curPurchaseDet.AcceptChanges(); 
                }
            }
            else
            {
                chkBoxS.Checked = false;
                string filterExp = "pentry_ty ='" + Convert.ToString(ToShowSelectedRow["entry_ty"]).Trim() + "'" +
                            " and ptran_cd =" + numFunction.toInt32(ToShowSelectedRow["tran_cd"]) +
                            " and pitserial ='" + Convert.ToString(ToShowSelectedRow["itserial"]).Trim() + "'";

                ToShowSelectedRow["check"] = false;
                ToShowSelectedRow.AcceptChanges();
                foreach (DataRow curPurchaseRow in curPurchaseDet.Select(filterExp))
                {
                    curPurchaseRow["tocheck"] = false;
                    curPurchaseRow["Alloqty"] = 0;
                    curPurchaseRow.AcceptChanges();
                }
            }

            chkBoxS.Enabled = true;
            ToShow.AcceptChanges();
            curPurchaseDet.AcceptChanges();

            SessionProxy.ToShow = ToShow; 
            SessionProxy.CurPurchaseDet = curPurchaseDet;

            ToShow.Dispose();
            CoAdditional.Dispose();
            main_vw.Dispose();
            curPurchaseDet.Dispose();

        }

        protected void grdSItemDet_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            grdSItemDet.PageIndex = e.NewPageIndex;
            grdSItemDet.DataSource = ToShow;
            grdSItemDet.DataBind();
            ToShow.Dispose(); 
        }

        protected void grdPItemDet_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataTable curPurchaseDe = SessionProxy.CurPurchaseDet;  
            grdPItemDet.PageIndex = e.NewPageIndex;
            grdPItemDet.DataSource = curPurchaseDe;
            curPurchaseDe.Dispose(); 
        }


        private void DisplayMessage(string strMsg)
        {
            strMsg = strMsg.Replace("\r\n", "\\n");
            strMsg = strMsg.Replace("\n", "\\n");
            strMsg = strMsg.Replace("'", "");
            string scriptString = "alert('" + strMsg + "');";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), null, scriptString, true);

        }
    }
}
