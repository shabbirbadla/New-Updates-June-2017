using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Business.Logic.Layer;
using System.Globalization;
using System.Web.Caching;
using System.Threading; 

namespace Udyog.E.Billing
{
    public partial class AppMaster : System.Web.UI.MasterPage
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private SqlConnection connHandle;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == true)
                return;

            GenNodes();
            
        }



        private void GenNodes()
        {
            numericFunction numFunction = new numericFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            //SessionProxy.ReqCode = null;

            CL_User UserKeys = new CL_User(SessionProxy.ReqCode); 

            DataSet DTMenus = (DataSet)UserKeys.Cache["MenuItems"];

            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;

            if (DTMenus == null)
            {
                SqlParameter[] spParam = new SqlParameter[1];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@userid";
                spParam[0].SqlDbType = SqlDbType.VarChar;
                spParam[0].Value = SessionProxy.UserID.Trim();

                DTMenus = new DataSet();
                ArrayList dblist = new ArrayList();
                dblist.Add("userrights");
                dblist.Add("commenu"); 

                DTMenus = DataAcess.ExecuteDataset(DTMenus,
                                    "sp_ent_web_GenMenu_Nodes",
                                    spParam,
                                    dblist,connHandle);
                DataAcess.Connclose(connHandle);

                //Cache.Insert("MenuItems",
                //        DTMenus,
                //        null,
                //        DateTime.Now.AddHours(2), Cache.NoSlidingExpiration);    
                UserKeys.Cache.Insert("MenuItems", DTMenus, null);  
                //Cache.Insert("MenuItems",
                //                DTMenus,
                //                null,
                //                Cache.NoAbsoluteExpiration,
                //                TimeSpan.FromHours(2));     

            }

            MenuItem ParentItem = null;
            string MenuName = "";
            DataRow findRange = null;
            foreach (DataRow ParentRow in DTMenus.Tables["comMenu"].Rows)
            {
                MenuName = textInfo.ToTitleCase(Convert.ToString(ParentRow["PrompName"]).Trim().Replace("\\<", "").ToLower().Trim());
                ParentItem = new MenuItem(MenuName);
                try
                {
                    findRange = DTMenus.Tables["userRights"].Select("range =" + Convert.ToInt32(ParentRow["range"]))[0];
                    if (Convert.ToString(ParentRow["Padname"]).Trim() == "_MSYSMENU")
                    {
                        if (!String.IsNullOrEmpty(Convert.ToString(ParentRow["url"])))
                        {
                            if (Convert.ToString(ParentRow["url"]).Trim().IndexOf("?") >= 0)
                            {
                                ParentItem.NavigateUrl =
                                    Convert.ToString(ParentRow["url"]).Trim() + "&rights=" +
                                    Convert.ToString(findRange["rights"]).Trim();
                                
                            }
                            else
                            {
                                ParentItem.NavigateUrl = Convert.ToString(ParentRow["url"]).Trim() + "?rights="
                                      + Convert.ToString(findRange["rights"]).Trim();
                                
                            }
                        }

                        ParentItem.Target = "_self";
                        AppMenu.Items.Add(ParentItem);
                    }

                    if (Convert.ToInt32(ParentRow["numitem"]) > 0)
                    {
                        GenChildNodes(Convert.ToString(ParentRow["barname"]).Trim(),
                                      ParentItem, DTMenus.Tables["comMenu"],
                                      DTMenus.Tables["userrights"]);
                    }
                }
                catch
                {
                    ParentItem.Enabled = false;
                }

            }

            ParentItem = new MenuItem("Log Off");
            AppMenu.Items.Add(ParentItem);

            // Generate TreeView Nodes
            string[,] parentNode = new string[10, 3];
            int count = 0;
            foreach (DataRow comMenuRow in DTMenus.Tables["comMenu"].Rows)
            {
                try
                {
                    DataRow SearchPadName = DTMenus.Tables["userRights"].Select("Range =" + numFunction.toInt32(comMenuRow["range"]))[0];
                    if (Convert.ToString(comMenuRow["Padname"]).Trim() == "_MSYSMENU")
                    {
                        parentNode[count, 0] = (Convert.ToString(comMenuRow["range"]).Trim());
                        parentNode[count, 1] = textInfo.ToTitleCase(Convert.ToString(comMenuRow["PrompName"]).Trim().Replace("\\<", "").ToLower().Trim());
                        parentNode[count, 2] = (Convert.ToString(comMenuRow["barname"]).Trim());
                        count++;
                    }
                }
                catch
                {
                }
            }

            for (int loop = 0; loop < count; loop++)
            {
                TreeNode root = new TreeNode();
                root.Text = parentNode[loop, 1];
                GenTreeViewChildNodes(root, 
                        Convert.ToString(parentNode[loop, 2]),
                        eBillTreeMenu, 
                        DTMenus.Tables["userRights"], 
                        DTMenus.Tables["comMenu"]);
                eBillTreeMenu.Nodes.Add(root);
            }

            DTMenus.Dispose();
         }

        protected void GenTreeViewChildNodes(TreeNode root, 
                string BarName, 
                TreeView _menunodes,
                DataTable userRights,
                DataTable comMenu)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            numericFunction numFunction = new numericFunction();
            DataAcess.DataBaseName = SessionProxy.DbName;
            TreeNode Child;
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;

            foreach (DataRow childMenuRow in comMenu.Select("Padname = '" + BarName.Trim() + "'"))
            {
                Child = new TreeNode();
                try
                {
                    DataRow findPadName = userRights.Select("range =" +  numFunction.toInt32(childMenuRow["Range"]))[0];
                    Child.Text = textInfo.ToTitleCase(Convert.ToString(childMenuRow["PrompName"]).Trim().Replace("\\<", "").ToLower().Trim());
                   
                    if (Convert.ToString(childMenuRow["url"]).Trim() != null ||
                        Convert.ToString(childMenuRow["url"]).Trim() != "None" ||
                        Convert.ToString(childMenuRow["url"]).Trim() != "")
                    {
                        Child.Target = "_self";
                        Child.NavigateUrl = Convert.ToString(childMenuRow["url"]).Trim();
                          
                    }
                    root.ChildNodes.Add(Child);
                }
                catch
                {

                }

                if (Convert.ToInt32(childMenuRow["numitem"]) > 0)
                {
                    GenTreeViewChildNodes(Child, Convert.ToString(childMenuRow["barname"]), _menunodes,userRights,comMenu);
                }

            }
        }


        private void GenChildNodes(string BarName,
                     MenuItem ParentItem,
                     DataTable com_Menu,
                     DataTable userrights)
        {
            MenuItem ChildItem = null;
            string MenuName = "";
            DataRow findRange = null;
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;

            foreach (DataRow ChildRow in com_Menu.Select("Padname = '" + BarName.Trim() + "'"))
            {
                MenuName = textInfo.ToTitleCase(Convert.ToString(ChildRow["PrompName"]).Trim().Replace("\\<", "").ToLower().Trim());
                if (MenuName == "Bank Receipt")
                {
                    string st;
                }

                ChildItem = new MenuItem(MenuName);
                try
                {
                    findRange = userrights.Select("range =" + Convert.ToInt32(ChildRow["range"]))[0];
                    if (!String.IsNullOrEmpty(Convert.ToString(ChildRow["url"])))
                    {
                        if (Convert.ToString(ChildRow["url"]).Trim().IndexOf("?") >= 0)
                        {
                            ChildItem.NavigateUrl =
                                Convert.ToString(ChildRow["url"]).Trim() + "&rights=" +
                                Convert.ToString(findRange["rights"]).Trim();
                        }
                        else
                        {
                            ChildItem.NavigateUrl = Convert.ToString(ChildRow["url"]).Trim() + "?rights="
                                  + Convert.ToString(findRange["rights"]).Trim();
                        }
                    }


                    ParentItem.ChildItems.Add(ChildItem);
                    if (Convert.ToInt32(ChildRow["numitem"]) > 0)
                    {
                        GenChildNodes(Convert.ToString(ChildRow["barname"]).Trim(),
                                      ChildItem, com_Menu, userrights);
                    }
                }
                catch
                {
                    ChildItem.Enabled = false;
                }
            }
        }

        protected void eBillTreeMenu_SelectedNodeChanged(object sender, EventArgs e)
        {
            if (((TreeView)sender).SelectedNode.Selected == true)
            {
                if ((((TreeView)sender).SelectedNode).ChildNodes.Count == 0)
                {

                    string strJS = "\n<script language='JavaScript'>\n" +
                                   "function HideFrames(pages)\n" +
                                   "{\n" +
                                   "    objfrm = parent.document.getElementById('LeftFrame');\n" +
                                   "    objfrm1 = parent.document.getElementById('MiddleFrameSet');\n" +
                                   "    if (objfrm != null)\n" +
                                   "    {\n" +
                                   "        if (objfrm.style.visibility == '')\n" +
                                   "        {\n" +
                                   "            objfrm1.cols = '0,*';\n" +
                                   "            objfrm.style.visibility = 'hidden';\n" +
                                   "        }\n" +
                                   "       top.TargetFrame.location.replace(pages);\n" +
                                   "    }\n" +
                                   "}\n" +
                                   "</script>";


                    //string strJS = "\n<script language='JavaScript'>\n" +
                    //               "function HideFrames(pages)\n" +
                    //               "{\n" +
                    //               "    objfrm = parent.document.getElementById('LeftFrame');\n" +
                    //               "    objfrm1 = parent.document.getElementById('MiddleFrameSet');\n" +
                    //               "    if (objfrm != null)\n" +
                    //               "    {\n" +
                    //               "        if (objfrm.style.visibility == '')\n" +
                    //               "        {\n" +
                    //               "            objfrm1.cols = '0,*';\n" +
                    //               "            objfrm.style.visibility = 'hidden';\n" +
                    //               "        }\n" +
                    //               "       top.TargetFrame.location.replace(pages);\n" +
                    //               "    }\n" +
                    //               "}\n" +
                    //               "</script>";


                    ScriptManager.RegisterStartupScript(this, this.GetType(), "HideFrames", strJS, false);
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "HideFrames('" + ((TreeView)sender).SelectedNode.Value.Trim() + "');", true);
                }
            }
        }

        protected void AppMenu_MenuItemClick(object sender, MenuEventArgs e)
        {
            if (e.Item.Value == "Log Off")
            {

                System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "logOut('" + btnHidden.ClientID + "');", true);
                //System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), null, "self.close();", true);
                //script.Append("<script language='javascript'>{self.close();}</script>")
                //Page.RegisterStartupScript("null", script.ToString())
            }
        }

        protected void btnHidden_Click(object sender, EventArgs e)
        {
            //SessionProxy.Company = null;
            //SessionProxy.CoName = null;
            //SessionProxy.DbName = null;
            //SessionProxy.DbProperties = null;
            //SessionProxy.MainDataSet = null;
            //SessionProxy.FinYear = null;
            //SessionProxy.ReportDataSet = null;
            //SessionProxy.ReqCode = null;
            //SessionProxy.UserID = null;
            //SessionProxy.VChkProd = null;
            //SessionProxy.AcmastDataSet = null;
            //SessionProxy.AcdetRowCess = null;
            //SessionProxy.AllocDataRow = null;
            //SessionProxy.DiscChrgDataSet = null;
            //SessionProxy.DiscChrgView = null;
            //SessionProxy.FolderName = null;
            //SessionProxy.RepMainDataSet = null;
            //SessionProxy.ReportPath = null;

            Response.Redirect("uwLogout.htm");
        }

    }
}
