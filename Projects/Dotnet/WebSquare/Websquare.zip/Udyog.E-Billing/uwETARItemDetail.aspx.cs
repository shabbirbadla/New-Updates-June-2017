using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Data.Acess.Layer;
using Business.Logic.Layer;
using Controls;
   

namespace Udyog.E.Billing
{
    public partial class uwETARItemDetail : System.Web.UI.Page  
    {
        private string sqlstr = "";
        private SqlDataReader dr;
        //private DataTier DataAcess;
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }
        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }
        private string pcvType;
        public string PcvType
        {
            get { return pcvType; }
            set { pcvType = value; }
        }
        private string beHave;
        public string BeHave
        {
            get { return beHave; }
            set { beHave = value; }
        }
        private string vchkprod;
        public string Vchkprod
        {
            get { return vchkprod; }
            set { vchkprod = value; }
        }
        private string entryTbl;
        public string EntryTbl
        {
            get { return entryTbl; }
            set { entryTbl = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == true)
            {
                lblError.Text = "";
                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                PcvType = Convert.ToString(Request.QueryString["pcvType"]);
                BeHave = Convert.ToString(Request.QueryString["beHave"]);
                Vchkprod = Convert.ToString(Request.QueryString["vChkProd"]);
                EntryTbl = Convert.ToString(Request.QueryString["entryTbl"]);
                return;
            }

            string itSerial = Convert.ToString(Request.QueryString["rowPos"]);
            AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
            PcvType = Convert.ToString(Request.QueryString["pcvType"]);
            BeHave = Convert.ToString(Request.QueryString["beHave"]);
            Vchkprod = Convert.ToString(Request.QueryString["vChkProd"]);
            EntryTbl = Convert.ToString(Request.QueryString["entryTbl"]);

            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;  
            DataTable main_vw = DsETItemDetail.Tables["main_vw"];
            DataTable lcode_vw = DsETItemDetail.Tables["lcode_vw"];
            DataTable item_vw = DsETItemDetail.Tables["item_vw"];
            DataTable manu_det_vw = DsETItemDetail.Tables["manu_det_vw"];
            DataTable company = DsETItemDetail.Tables["company"];

            
            DataRow itemRow = item_vw.Select("item_no ='" + itSerial.Trim() + "'")[0];
            DataRow ManuRow = null;

            boolFunction BitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();
            stringFunction strFunction = new stringFunction();

            lblTrType.Text = "Excise Itemwise Details";

            SqlParameter[] spParam = new SqlParameter[6];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@pcvtype";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = PcvType.Trim(); 

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@ettype";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().ToUpper();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@manuacId";
            spParam[2].SqlDbType = SqlDbType.Int; 
            spParam[2].Value = numFunction.toInt32(itemRow["manuac_id"]);

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@consId";
            spParam[3].SqlDbType = SqlDbType.Int; 
            spParam[3].Value = numFunction.toInt32(main_vw.Rows[0]["cons_id"]);

            spParam[4] = new SqlParameter();
            spParam[4].ParameterName = "@date";
            spParam[4].SqlDbType = SqlDbType.DateTime; 
            spParam[4].Value = DateFormat.TodateTime(main_vw.Rows[0]["date"]);

            spParam[5] = new SqlParameter();
            spParam[5].ParameterName = "@codate";
            spParam[5].SqlDbType = SqlDbType.DateTime;
            spParam[5].Value = DateFormat.TodateTime(company.Rows[0]["sta_dt"]);

            ArrayList dbList = new ArrayList();
            dbList.Add("taxvw5");
            dbList.Add("taxvw2");
            dbList.Add("taxvw3");
            dbList.Add("manufact");
            dbList.Add("col");
            dbList.Add("warehouse");

            if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().ToUpper(),
                                   new string[] { "MANUFACTURER", "IMPORTER" }) == false)
            {
                if (numFunction.toInt32(itemRow["manuac_id"]) != 0)
                {
                    dbList.Add("ManuAcId");
                }
            }
            else
            {
                 dbList.Add("ConsAcId");
            }
            dbList.Add("ExcDcMastvw");
            dbList.Add("taxvw4");
            dbList.Add("ManuDcMastvw");
            dbList.Add("manutax_vw");

            if (DateFormat.TodateTime(main_vw.Rows[0]["date"]) < DateFormat.TodateTime(company.Rows[0]["sta_dt"]))
            {
                dbList.Add("PrevDcMast_vw");
                dbList.Add("prevvw");
            }

            DataSet ARItemDataSet = new DataSet();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
 
            ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet,
                    "sp_ent_web_ETARItemDetail_Init", spParam,
                     dbList,connHandle);
            DataAcess.Connclose(connHandle);

            SessionProxy.DutyPerUnitDec = Convert.ToInt32(ARItemDataSet.Tables["col"].Rows[0]["scale"]);
            //col.Dispose();

            //CreateCursors(ref ARItemDataSet);
            //getCoAdditional GetCoAdditional = new getCoAdditional();
            //GetCoAdditional.CoAdditional(ARItemDataSet);

            //SqlParameter[] spParam = new SqlParameter[2];
            //spParam[0] = new SqlParameter();
            //spParam[0].ParameterName = "@tblnm";
            //spParam[0].SqlDbType = SqlDbType.VarChar;
            //spParam[0].Value = "Aritem";

            //spParam[1] = new SqlParameter();
            //spParam[1].ParameterName = "@tblfield";
            //spParam[1].SqlDbType = SqlDbType.VarChar;
            //spParam[1].Value = "mtduty";

            //DataTable col = DataAcess.ExecuteDataTable("sp_web_getcolsize", spParam);
            //SessionProxy.DutyPerUnitDec = Convert.ToInt32(col.Rows[0]["scale"]);
            //col.Dispose();

 
            

            bool isMEflag = true;
            if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
            {
                isMEflag = BitFunction.toBoolean(ARItemDataSet.Tables["manufact"].Rows[0]["et_flag"]);
            }
            else
            {
                if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "NON-EXCISE")
                {
                    isMEflag = BitFunction.toBoolean(ARItemDataSet.Tables["manufact"].Rows[0]["net_flag"]);
                }
            }

            string mware_nm = "";
            if (isMEflag == false)
            {
                int mmanu_id = 0;
                int mmanus_id = 0;
                int isFound = 0;
                foreach (DataRow itemvwRow in item_vw.Rows)
                {
                    isFound = isFound + 1;
                    if (isFound == 1)
                    {
                        if (mware_nm.Trim() == "")
                        {
                            mware_nm = Convert.ToString(itemvwRow["ware_nm"]).Trim();  
                        }

                        if (mmanu_id == 0)
                        {
                            mmanu_id = numFunction.toInt32(itemvwRow["manuac_id"]);
                            mmanus_id = numFunction.toInt32(itemvwRow["manusac_id"]);  
                        }
                    }

                    if (isFound > 1)
                    {
                        txtManuName.Enabled = false;
                        dropWareHouse.Enabled = false;
                        break; 
                    }
                }
                itemRow["ware_nm"] = mware_nm;
                itemRow["manuac_id"] = mmanu_id;
                itemRow["manusac_id"] = mmanus_id;
            }

            fillDropdown(itemRow,
                    lcode_vw,
                    ARItemDataSet.Tables["warehouse"]); // fill dropdownlist


            //sqlstr = " Select Ware_nm from Warehouse where validity like '%" +
            //        Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "%' and " +
            //        " ltrim(Ware_nm) != ''";
            //dr = DataAcess.ExecuteDataReader(sqlstr);
            mware_nm = "";
            if (ARItemDataSet.Tables["warehouse"].Rows.Count > 0)
            {
                int rowscount = 0;
                foreach (DataRow wareRow in ARItemDataSet.Tables["warehouse"].Rows)
                {
                    mware_nm = Convert.ToString(wareRow["ware_nm"]).Trim();
                    rowscount = rowscount + 1;
                }

                if (Convert.ToString(itemRow["ware_nm"]).Trim() == "")
                {
                    itemRow["ware_nm"] = mware_nm; 
                }

                dropWareHouse.SelectedValue = Convert.ToString(itemRow["ware_nm"]).Trim();
                if (rowscount <=1)
                    dropWareHouse.Enabled = false;
            }

            if (Convert.ToString(main_vw.Rows[0]["Rule"]).Trim().ToUpper() != "EXCISE")
                txtRGPage.Enabled = false;

            try
            {
                string filtExp = "entry_ty = '" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "' and " +
                                 " tran_cd = " + numFunction.toInt32(main_vw.Rows[0]["tran_cd"]) +
                                 " and itserial = '" + Convert.ToString(itemRow["itserial"]).Trim() + "'";

                ManuRow = manu_det_vw.Select(filtExp)[0];
            }
            catch
            {
                ManuRow = manu_det_vw.NewRow();
                ManuRow["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim();
                ManuRow["date"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
                ManuRow["doc_no"] = Convert.ToString(main_vw.Rows[0]["doc_no"]);
                ManuRow["itserial"] = Convert.ToString(itemRow["itserial"]);
                ManuRow["tran_cd"] = numFunction.toInt32(main_vw.Rows[0]["tran_cd"]);
                ManuRow["compid"] = numFunction.toInt32(main_vw.Rows[0]["compid"]);
                manu_det_vw.Rows.Add(ManuRow);
                //manu_det_vw.AcceptChanges();  
            }

            if (numFunction.toDecimal(itemRow["u_asseamt"]) == 0)
            {
                itemRow["u_asseamt"] = (numFunction.toDecimal(itemRow["qty"]) * numFunction.toDecimal(itemRow["rate"]));
            }

            if (numFunction.toDecimal(ManuRow["assevalue"]) == 0)
            {
                ManuRow["assevalue"] = numFunction.toDecimal(itemRow["u_asseamt"]);
            }

            if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().ToUpper(),
                                   new string[] { "MANUFACTURER", "IMPORTER" }) == false)
            {
                if (numFunction.toInt32(itemRow["manuac_id"]) != 0)
                {
                    //sqlstr = "Select Ac_name,ac_id From Ac_mast [nolock] Where Ac_id = " +
                    //           numFunction.toInt32(itemRow["manuac_id"]);

                    //dr = DataAcess.ExecuteDataReader(sqlstr);
                    if (ARItemDataSet.Tables["ManuAcId"].Rows.Count > 0)
                    {
                        foreach (DataRow ManuacRow in ARItemDataSet.Tables["ManuAcId"].Rows)
                        {
                            txtManuName.Text = Convert.ToString(ManuacRow["ac_name"]).Trim();
                        }
                    }
                }
            }
            else
            {
                //sqlstr = "Select Ac_name,ac_id From Ac_mast [nolock] Where Ac_id = " +
                //           numFunction.toInt32(main_vw.Rows[0]["cons_id"]);

                //dr = DataAcess.ExecuteDataReader(sqlstr);
                 if (ARItemDataSet.Tables["ConsAcId"].Rows.Count > 0)
                 {
                    foreach (DataRow ConsAcRow in ARItemDataSet.Tables["ConsAcId"].Rows)
                    {
                        txtManuName.Text = Convert.ToString(ConsAcRow["ac_name"]).Trim();
                    }
                 }

                //if (dr.HasRows == true)
                //{
                //    while (dr.Read())
                //    {
                //        txtManuName.Text = Convert.ToString(dr["ac_name"]).Trim();
                //    }
                //}
                //dr.Close();
                //dr.Dispose();
            }

            if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().ToUpper(),
                               new string[] { "MANUFACTURER", "IMPORTER" }) == false)
            {
                // no use
                //sqlstr = "Select Top 1 Mailname,Ac_id,Shipto_id From Shipto Where UPPER(VEND_TYPE) IN('MANUFACTURER','IMPORTER')";
            }
            else
            {
                txtManuName.Enabled = false;
            }

            try
            {
                fillGridExciseDuty(ref ARItemDataSet,
                                ref itemRow,
                                ref ManuRow);
            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();   
            }

            if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim().ToUpper(),
                                   new string[] { "MANUFACTURER", "IMPORTER" }) == false)
            {
                lblAssVal.Visible = false;
                txtAsseVal.Visible = false;
                fillManufactDetails(ref ManuRow,ref itemRow,ref ARItemDataSet); // Passed Row as Parameter of Manu_det table.  
            }
            else
            {
                //lblManuRate.Visible = false;
                txtManuRate.Visible = false;
                tabItemDet.Tabs[1].Enabled = false;
                //tabItemDet.Tabs[1].Visible = false; // manufacure details tab hide  
            }

            if (DateFormat.TodateTime(main_vw.Rows[0]["date"]) >= DateFormat.TodateTime(company.Rows[0]["sta_dt"]))
            {
                tabItemDet.Tabs[3].Enabled = false;
                //tabItemDet.Tabs[3].Visible = false;
            }
            else
            {
                fillPreviousBill(ref ARItemDataSet, ref itemRow); 
                tabItemDet.Tabs[3].Enabled = true;
                //tabItemDet.Tabs[3].Visible = true;
            }
            refreshvalues(ManuRow,itemRow,ARItemDataSet);
            DataAcess.Connclose(connHandle);

            txtSupRgEntNo.Text = Convert.ToString(itemRow["pentno"]).Trim();
            txtSupRgPgNo.Text = Convert.ToString(itemRow["ppageno"]).Trim();
            txtIdMarkNo.Text = Convert.ToString(itemRow["id_mark"]).Trim();

            tabItemDet.ActiveTabIndex = 0;

            SessionProxy.DsETItemDetail  = DsETItemDetail;
            SessionProxy.EtARItemDataSet = ARItemDataSet; 
            SessionProxy.EtManuRow = ManuRow;
            SessionProxy.EtItemRow = itemRow;

            main_vw.Dispose();
            lcode_vw.Dispose();
            item_vw.Dispose();
            manu_det_vw.Dispose();
            company.Dispose();
            ARItemDataSet.Dispose();
            DsETItemDetail.Dispose();
            DataAcess.Connclose(connHandle);  

            if (dropWareHouse.SelectedIndex != 0)
                callFromDropWH(dropWareHouse);

            if (txtManuName.Text != "")
                callFromDropManuName();

        }

        protected void fillManufactDetails(ref DataRow ManuRow,
                ref DataRow itemRow,
                ref DataSet ARItemDataSet)
        {
            //DataAcess = new DataTier();
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            //string entryTy = "AR";
            //sqlstr = "SELECT * FROM DCMAST WHERE ENTRY_TY='" + entryTy + "' AND CODE='E' AND ATT_FILE=0";
            //ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "ManuDcMast_vw");
            //sqlstr = "select * from dcmast where 1=0";
            //ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "manutax_vw");

            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable manu_det_vw = DsETItemDetail.Tables["manu_det_vw"];

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
  
            foreach (DataRow ManuDcRow in ARItemDataSet.Tables["ManuDcMastvw"].Rows)
            {
                ManuDcRow["def_Pert"] = Convert.ToString(ManuDcRow["pert_name"]).Trim() != "" ?
                                       numFunction.toDecimal(itemRow[Convert.ToString(ManuDcRow["pert_name"]).Trim()])
                                       : numFunction.toDecimal(ManuDcRow["def_pert"]);
                ManuDcRow["def_amt"] = numFunction.toDecimal(itemRow[Convert.ToString(ManuDcRow["fld_nm"]).Trim()]);
                ManuDcRow["excl_net"] = bitFunction.toBoolean(ManuDcRow["att_file"]) == false && Convert.ToString(ManuDcRow["code"]).Trim() == "E" ?
                                       "E" : Convert.ToString(ManuDcRow["excl_net"]).Trim();

                DataRow manuTaxRow = ARItemDataSet.Tables["manutax_vw"].NewRow();
                manuTaxRow = DataAcess.ExactScatterGatherRow(ManuDcRow, manuTaxRow);
                ARItemDataSet.Tables["manutax_vw"].Rows.Add(manuTaxRow);
                ARItemDataSet.Tables["manutax_vw"].AcceptChanges(); 
            }


            if (AddMode == true || EditMode == true)
            {
                //string defFld, defAmtExpr= "";
                //decimal defPer = 0;
                foreach (DataRow manuTaxRow in ARItemDataSet.Tables["manutax_vw"].Rows)
                {
                    if (manu_det_vw.Columns.Contains(Convert.ToString(manuTaxRow["fld_manu"]).Trim()) == true)
                    {
                        if (manu_det_vw.Columns[Convert.ToString(manuTaxRow["fld_manu"]).Trim()].DataType.ToString().Trim().ToUpper() != "SYSTEM.DECIMAL")
                        {
                            continue;
                        }
                    }
                    else
                    {
                        continue;
                    }

                    manuTaxRow["def_amt"] = Convert.ToString(manuTaxRow["fld_nm"]).Trim() != "" ?
                        numFunction.toDecimal(ManuRow[Convert.ToString(manuTaxRow["fld_manu"]).Trim()]) :
                        numFunction.toDecimal(manuTaxRow["def_amt"]);

                    DataRow taxVw2Row = ARItemDataSet.Tables["taxvw2"].NewRow();
                    taxVw2Row = DataAcess.ExactScatterGatherRow(manuTaxRow, taxVw2Row);
                    ARItemDataSet.Tables["taxvw2"].Rows.Add(taxVw2Row);
                    ARItemDataSet.Tables["taxvw2"].AcceptChanges(); 
                }
            }
            ManudetailActivate(ref ManuRow,ref itemRow,ref ARItemDataSet);
            grdManDet.DataSource = ARItemDataSet.Tables["taxvw2"];
            grdBind(grdManDet);
            DsETItemDetail.Dispose();
            manu_det_vw.Dispose();

        }
        
        protected void grdBind(GridView grd)
        {
            DataTable tmpTb = ((DataTable)grd.DataSource);
            if (tmpTb.Rows.Count == 0)
            {
                tmpTb = tmpTb.Clone();
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());
                tmpTb.Rows.Add(tmpTb.NewRow());

                grd.DataSource = tmpTb;
                grd.DataBind();
            }
            else
            {
                grd.DataSource = tmpTb; 
                grd.DataBind();
            }
            tmpTb.Dispose(); 
        }

        protected void fillGridExciseDuty(ref DataSet ARItemDataSet,
                ref DataRow itemRow,
                ref DataRow ManuRow)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable main_vw = DsETItemDetail.Tables["main_vw"];
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;


            //string entryTy = "AR";
            //sqlstr = "SELECT * FROM DCMAST WHERE ENTRY_TY='"+ entryTy + "' AND CODE='E' AND ATT_FILE=0";
            //ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "ExcDcMast_vw");
            //sqlstr = "select * from dcmast where 1=0";
            //ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "taxvw4");

            foreach (DataRow ExDcRow in ARItemDataSet.Tables["ExcDcMastvw"].Rows)
            {
                ExDcRow["def_Pert"] = Convert.ToString(ExDcRow["pert_name"]).Trim() != "" ?
                                       numFunction.toDecimal(itemRow[Convert.ToString(ExDcRow["pert_name"]).Trim()])
                                       : numFunction.toDecimal(ExDcRow["def_pert"]);
                ExDcRow["def_amt"] = numFunction.toDecimal(itemRow[Convert.ToString(ExDcRow["fld_nm"]).Trim()]);
                ExDcRow["excl_net"] =  bitFunction.toBoolean(ExDcRow["att_file"]) == false && Convert.ToString(ExDcRow["code"]).Trim() == "E" ?
                                       "E" : Convert.ToString(ExDcRow["excl_net"]).Trim();

                DataRow taxvw4Row = ARItemDataSet.Tables["taxvw4"].NewRow();
                taxvw4Row = DataAcess.ExactScatterGatherRow(ExDcRow, taxvw4Row);
                ARItemDataSet.Tables["taxvw4"].Rows.Add(taxvw4Row);
                ARItemDataSet.Tables["taxvw4"].AcceptChanges(); 
            }

            if (AddMode == true || EditMode == true)
            {
                if (numFunction.toDecimal(itemRow["examt"]) <= 0)
                {
                    string defFld, defAmtExpr= "";
                    decimal defPer = 0;
                    foreach (DataRow exRow in ARItemDataSet.Tables["taxvw4"].Rows)
                    {
                        defFld = Convert.ToString(exRow["fld_nm"]).Trim();
                        defAmtExpr = Convert.ToString(exRow["amtexpr"]).Trim();
                        defPer = numFunction.toDecimal(exRow["def_pert"]);
                        decimal exAmt = 0;

                        if (defAmtExpr != "")
                        {
                            if (defAmtExpr.Trim().IndexOf('.') >= 0)
                            {
                                string DataTableName, DataFieldName = "";
                                DataTableName = defAmtExpr.Trim().Substring(0, defAmtExpr.Trim().IndexOf("."));
                                DataFieldName = defAmtExpr.Trim().Substring(defAmtExpr.Trim().IndexOf(".") + 1, (defAmtExpr.Length - defAmtExpr.Trim().IndexOf(".")) - 1);

                                if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                                {
                                    exAmt = numFunction.toDecimal(main_vw.Rows[0][DataFieldName]);
                                }
                                else
                                {
                                    if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                    {
                                        exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                    }
                                    else
                                    {
                                        throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                    }
                                }

                                exAmt = (((exAmt) * defPer) / 100);
                            }
                            else
                            {
                                throw new Exception("Amount Expression is not proper in dcmast");
                            }
                        }
                        else
                        {
                            exAmt = (numFunction.toDecimal(itemRow["qty"]) * numFunction.toDecimal(itemRow["u_mrate"])) * defPer / 100;
                        }
                        if (bitFunction.toBoolean(exRow["round_off"]) == true)
                        {
                            exAmt = Math.Round(exAmt, 0);
                        }
                        itemRow[defFld] = numFunction.toDecimal(exAmt, 2);
                    }

                    //itemRow["mtduty"] = numFunction.toDecimal((numFunction.toDecimal(itemRow["examt"]) / numFunction.toDecimal(itemRow["qty"])));
                    //ManuRow["manumtduty"] = numFunction.toDecimal((numFunction.toDecimal(itemRow["examt"]) / numFunction.toDecimal(itemRow["qty"])));

                    //itemRow["examt"] = (numFunction.toDecimal(itemRow["qty"]) * numFunction.toDecimal(itemRow["u_mrate"])) * defPer / 100;

                    foreach (DataRow tax4Row in ARItemDataSet.Tables["taxvw4"].Rows)
                    {
                        if (Convert.ToString(tax4Row["fld_nm"]).Trim().ToUpper() == "EXAMT")
                        {
                            if (bitFunction.toBoolean(tax4Row["round_off"]) == true)
                            {
                                itemRow["examt"] = Math.Round(numFunction.toDecimal(itemRow["examt"]), 0);
                            }
                        }
                    }

                    foreach (DataRow tax4Row in ARItemDataSet.Tables["taxvw4"].Rows)
                    {
                        decimal getval = RoundInt(numFunction.toDecimal(itemRow[Convert.ToString(tax4Row["fld_nm"]).Trim()]) /
                                                  numFunction.toDecimal(itemRow["qty"]));

                        itemRow[Convert.ToString(tax4Row["fld_duty"]).Trim()] = getval;
                        ManuRow[Convert.ToString(tax4Row["fld_mduty"]).Trim()] = getval;   
                    }

                }

                foreach (DataRow tax4Row in ARItemDataSet.Tables["taxvw4"].Rows)
                {
                    if (itemRow.Table.Columns.Contains(Convert.ToString(tax4Row["fld_nm"]).Trim()) == true)
                    {
                        if (itemRow.Table.Columns[Convert.ToString(tax4Row["fld_nm"]).Trim()].DataType.ToString().Trim().ToUpper()  != "SYSTEM.DECIMAL")
                        {
                            continue;
                        }
                    }
                    else
                    {
                        continue; 
                    }

                    tax4Row["def_pert"] = Convert.ToString(tax4Row["pert_name"]).Trim() != "" ?
                        numFunction.toDecimal(itemRow[Convert.ToString(tax4Row["pert_name"]).Trim()]) :
                        numFunction.toDecimal(tax4Row["def_pert"]);
                    tax4Row["def_amt"] = Convert.ToString(tax4Row["fld_nm"]).Trim() != "" ?
                        numFunction.toDecimal(itemRow[Convert.ToString(tax4Row["fld_nm"]).Trim()]) :
                        numFunction.toDecimal(tax4Row["def_amt"]);
                    
                    DataRow taxvw5Row = ARItemDataSet.Tables["taxvw5"].NewRow();
                    taxvw5Row = DataAcess.ExactScatterGatherRow(tax4Row, taxvw5Row);
                    ARItemDataSet.Tables["taxvw5"].Rows.Add(taxvw5Row);
                    ARItemDataSet.Tables["taxvw5"].AcceptChanges(); 
                }

                //itemRow.CancelEdit(); // discard changes  
            }

            grdExciseDuty.DataSource = ARItemDataSet.Tables["taxvw5"];
            grdBind(grdExciseDuty);
            DsETItemDetail.Dispose();
            main_vw.Dispose(); 

        }

        //protected void CreateCursors(ref DataSet ARItemDataSet)
        //{
        //    DataAcess = new DataTier();
        //    sqlstr = "select * from dcmast where 1=0";
        //    ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "taxvw5");
        //    sqlstr = "select dcmast.*,getdate() as def_date,manu_det.manubill as def_Val from dcmast,manu_det where 1=0";
        //    ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "taxvw2");
        //    sqlstr = "select * from dcmast where 1=0";
        //    ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "taxvw3");
        //}

        protected void fillDropdown(DataRow itemRow,
                    DataTable lcode_vw,
                    DataTable wareVw)
        {
            //string likecond = "%" + Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() + "%";
            //sqlstr = " Select Ware_nm From Warehouse Where Validity Like '" + likecond +
            //         "' and ltrim(Ware_nm) != '' order by ware_nm";

            //DataTable wareVw = DataAcess.ExecuteDataTable(sqlstr, "_ware");
            //dropWareHouse.DataSource = wareVw;
            foreach (DataRow DRow in wareVw.Rows)
            {
                dropWareHouse.Items.Add(Convert.ToString(DRow["ware_nm"]).Trim());
            }
            //dropWareHouse.DataTextField = "ware_nm";
            //dropWareHouse.DataValueField = "ware_nm";
            //dropWareHouse.DataBind();
            dropWareHouse.Items.Insert(0, "--Select Warehouse--");
            wareVw.Dispose();

            dropWareHouse.SelectedValue = Convert.ToString(itemRow["ware_nm"]).Trim() == "" ?
                "--Select Warehouse--" : Convert.ToString(itemRow["ware_nm"]).Trim();

            wareVw.Dispose();  
      
        }

        protected void txtManuName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                callFromDropManuName();
            }
            catch (Exception Ex)
            {
                lblError.Text = Ex.Message.Trim();  
                if (Ex.Message.Trim().IndexOf("Manufacture name not found in master")>= 0)
                {
                    txtManuName.Text = "";  
                    ScriptManager1.SetFocus(txtManuName);   
                }
            }
        }

        protected void callFromDropManuName()
        {
            if (txtManuName.Text == "")
                return;

            string sqlStr = "";
            numericFunction numFunction = new numericFunction();
            int acId = 0;
            SqlParameter[] spParam = new SqlParameter[2];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@acId";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = 0;

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@AcName";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = txtManuName.Text.ToString().Trim();

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;  

            SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_Acc_validation",
                                            spParam,ref connHandle);

            if (Dr.HasRows == false)  
            {
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle);
                txtManuName.Focus();
                txtManuName.Text = "";
                throw new Exception("Manufacture name not found in master");
            }
            else
            {
                while (Dr.Read())
                {
                    acId = numFunction.toInt32(Dr["ac_id"]);
                }
            }
            Dr.Dispose();
            Dr.Close();
            DataAcess.Connclose(connHandle); 

            string sqlcond = "UPPER(A.VEND_TYPE) IN ('MANUFACTURER','IMPORTER')";
            GetLocationDetails LocationDetails = new GetLocationDetails();
            DataTable shipto_vw = new DataTable();
            shipto_vw = LocationDetails.ListLocationDetails("manusac_id", "a.location_id,a.eccno"
                                , 0, txtManuName.Text.Trim(), sqlcond, true, shipto_vw);
            if (shipto_vw.Rows.Count > 1)
            {
                dropLocation.Enabled = true; 
                dropLocation.DataSource = shipto_vw;
                dropLocation.DataTextField = "location_id";
                dropLocation.DataValueField = "shipto_id";
                dropLocation.DataBind();
                dropLocation.Items.Insert(0, "--Select Location--");
                trShiptoLocation.Visible = true;
                if (dropWareHouse.SelectedIndex == 0)
                {
                    dropWareHouse.Focus();
                }
                else
                {
                    dropLocation.Focus();
                }
            }
            else
            {
                dropLocation.Enabled = false; 
            }

            shipto_vw.Dispose();

           

            DataRow itemRow = SessionProxy.EtItemRow;  
            itemRow["manuac_id"] = acId;
            SessionProxy.EtItemRow = itemRow;
        }

        protected void txtAsseVal_TextChanged(object sender, EventArgs e)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataSet ARItemDataSet = null;
            DataTable main_vw = null;

            try
            {
                DataRow itemRow = SessionProxy.EtItemRow;
                DataRow ManuRow = SessionProxy.EtManuRow;
                ARItemDataSet = SessionProxy.EtARItemDataSet;
                DataSet DsETItemDetail = SessionProxy.DsETItemDetail;

                main_vw = DsETItemDetail.Tables["main_vw"];

                itemRow["u_asseamt"] = numFunction.toDecimal(txtAsseVal.Text);
                ManuRow["AsseValue"] = numFunction.toDecimal(txtAsseVal.Text);

                string defFld, defPerfld = "";
                foreach (DataRow taxVw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
                {
                    defFld = Convert.ToString(taxVw5Row["fld_nm"]).Trim();
                    defPerfld = Convert.ToString(taxVw5Row["pert_name"]);

                    itemRow[defFld.Trim()] = numFunction.toDecimal(taxVw5Row["def_amt"]);
                    itemRow[defPerfld.Trim()] = numFunction.toDecimal(taxVw5Row["def_pert"]);
                }

                string defAmtExpr = "";
                decimal defPer, exAmt = 0;
                foreach (DataRow taxVw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
                {
                    exAmt = 0;
                    defAmtExpr = Convert.ToString(taxVw5Row["amtexpr"]).Trim();
                    defPer = numFunction.toDecimal(taxVw5Row["def_pert"]);
                    if (defAmtExpr.Trim() != "" && defPer > 0)
                    {
                        if (defAmtExpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = defAmtExpr.Trim().Substring(0, defAmtExpr.Trim().IndexOf("."));
                            DataFieldName = defAmtExpr.Trim().Substring(defAmtExpr.Trim().IndexOf(".") + 1, (defAmtExpr.Length - defAmtExpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                            {
                                exAmt = numFunction.toDecimal(main_vw.Rows[0][DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * defPer) / 100);
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }
                    }

                    taxVw5Row["def_amt"] = numFunction.toDecimal(exAmt, 2);

                    if (bitFunction.toBoolean(taxVw5Row["round_off"]) == true)
                    {
                        taxVw5Row["def_amt"] = Math.Round(exAmt, 0);
                    }

                    taxVw5Row[Convert.ToString(taxVw5Row["fld_nm"]).Trim()] =
                        numFunction.toDecimal(taxVw5Row["def_amt"]);
                }

                ARItemDataSet.Tables["taxvw5"].AcceptChanges();

                ManudetailActivate(ref ManuRow,
                            ref itemRow,
                            ref ARItemDataSet); // call method

                itemRow["mtduty"] = RoundInt(numFunction.toDecimal(itemRow["examt"]) /
                        numFunction.toDecimal(itemRow["qty"]));
                ManuRow["manumtduty"] = numFunction.toDecimal(itemRow["mtduty"]);

                //numFunction.toDecimal(numFunction.toDecimal(itemRow["examt"]) / numFunction.toDecimal(itemRow["qty"]), 2);


                string mDefAmtexpr = "";
                decimal mdefPer, manuDefamt = 0;

                foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                {
                    exAmt = 0;
                    mDefAmtexpr = Convert.ToString(tax2Row["amtexpr"]).Trim();
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".MANUQTY");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("U_ASSEAMT", "ASSEVALUE");
                    foreach (DataRow tax2VwRow in ARItemDataSet.Tables["taxvw2"].Rows)
                    {
                        mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax2VwRow["fld_nm"]).Trim(),
                                        Convert.ToString(tax2VwRow["fld_manu"]).Trim());
                    }

                    mdefPer = numFunction.toDecimal(tax2Row["def_pert"]);
                    if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                    {
                        if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                            DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                            {
                                exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * mdefPer) / 100);
                            manuDefamt = exAmt;
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }

                        tax2Row["def_amt"] = numFunction.toDecimal(exAmt, 2);

                        if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                        {
                            tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                        }

                        ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = numFunction.toDecimal(manuDefamt, 2);
                    }
                    else
                    {
                        if (mDefAmtexpr == "")
                        {
                            mdefPer = 100;

                            exAmt = ((numFunction.toDecimal(ManuRow["assevalue"])
                                * numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_nm"]).Trim()]))
                                / numFunction.toDecimal(itemRow["u_asseamt"]));

                            tax2Row["def_amt"] = exAmt * mdefPer / 100;

                            if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                            {
                                tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                            }
                            ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = numFunction.toDecimal(tax2Row["def_amt"]);
                        }
                    }
                }
                ARItemDataSet.Tables["taxvw2"].AcceptChanges();
                grdExciseDuty.DataSource = ARItemDataSet.Tables["taxvw5"];
                grdBind(grdExciseDuty);

                SessionProxy.EtARItemDataSet = ARItemDataSet;
                SessionProxy.DsETItemDetail = DsETItemDetail;
                SessionProxy.EtManuRow = ManuRow;
                SessionProxy.EtItemRow = itemRow;

                refreshvalues(ManuRow,
                        itemRow,
                        ARItemDataSet);

                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "refreshUpadatePanel();", true);
            }
            catch (Exception Ex)
            {
                lblError.Text = Ex.Message.Trim();
                UpdatePanel6.Update();
                ScriptManager1.SetFocus(txtAsseVal);
            }
            finally
            {
                ARItemDataSet.Dispose();
                main_vw.Dispose();
            }
                        
        }

        protected void ManudetailActivate(ref DataRow ManuRow,
                        ref DataRow itemRow,
                        ref DataSet ARItemDataSet)
        {
            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();
            getDateFormat DateFormat = new getDateFormat();
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable main_vw = DsETItemDetail.Tables["main_vw"];  

            //ManuRow["manuQty"] = numFunction.toDecimal(ManuRow["Manuqty"]) == 0 ?
            //    numFunction.toDecimal(itemRow["qty"]) : numFunction.toDecimal(ManuRow["Manuqty"]);
            //ManuRow["manubill"] = Convert.ToString(ManuRow["manubill"]).Trim() == "" ?
            //    Convert.ToString(main_vw.Rows[0]["u_pinvno"]).Trim() : Convert.ToString(ManuRow["manubill"]).Trim();
            //ManuRow["manudate"] = DateFormat.TodateTime(ManuRow["Manudate"]) <= Convert.ToDateTime("01/01/1900") ?
            //    DateFormat.TodateTime(main_vw.Rows[0]["u_pinvdt"]) : DateFormat.TodateTime(ManuRow["Manudate"]);
            //ManuRow["AsseValue"] = numFunction.toDecimal(ManuRow["AsseValue"]) == 0 ?
            //    numFunction.toDecimal(itemRow["u_asseamt"]) : numFunction.toDecimal(ManuRow["Assevalue"]);
            //ManuRow["manuQty1"] = numFunction.toDecimal(ManuRow["Manuqty1"]) == 0 ?
            //    numFunction.toDecimal(itemRow["u_lqty"]) : numFunction.toDecimal(ManuRow["Manuqty1"]);
            //ManuRow["manumtduty"] = numFunction.toDecimal(ManuRow["manumtduty"]) == 0 ?
            //    numFunction.toDecimal(itemRow["mtduty"]) : numFunction.toDecimal(ManuRow["manumtduty"]);

            if (numFunction.toDecimal(ManuRow["ManuQty"]) <= 0)
            {
                ManuRow["manuQty"] = 0;
                ManuRow["AsseValue"] = 0;
                ManuRow["manuQty1"] = 0;
                ManuRow["manumtduty"] = 0;
            }

            foreach (DataRow taxVw5 in ARItemDataSet.Tables["taxvw5"].Rows)
            {
                foreach (DataRow taxVw2 in ARItemDataSet.Tables["taxvw2"].Select("head_nm ='" + Convert.ToString(taxVw5["head_nm"]).Trim() + "'"))
                {
                    taxVw2["def_pert"] = numFunction.toDecimal(taxVw5["def_pert"]);
                    taxVw2.AcceptChanges();  
                }
            }

            DsETItemDetail.Dispose(); 
            main_vw.Dispose();
        }

        protected void txtMtDuty_TextChanged(object sender, EventArgs e)
        {

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            DataSet ARItemDataSet = null;
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable main_vw = null;

            try
            {
                DataRow itemRow = SessionProxy.EtItemRow;
                DataRow ManuRow = SessionProxy.EtManuRow;
                ARItemDataSet = SessionProxy.EtARItemDataSet;
                main_vw = DsETItemDetail.Tables["main_vw"];

                itemRow["examt"] = (numFunction.toDecimal(itemRow["qty"]) *
                                numFunction.toDecimal(txtMtDuty.Text));
                ManuRow["manumtduty"] = numFunction.toDecimal(txtMtDuty.Text);
                itemRow["mtduty"] = numFunction.toDecimal(txtMtDuty.Text);

                foreach (DataRow taxvw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
                {
                    if (Convert.ToString(taxvw5Row["fld_nm"]).Trim().ToUpper() == "EXAMT")
                    {
                        taxvw5Row["def_amt"] = (numFunction.toDecimal(itemRow["qty"]) *
                                            numFunction.toDecimal(txtMtDuty.Text));

                        if (bitFunction.toBoolean(taxvw5Row["round_off"]) == true)
                        {
                            itemRow["examt"] = Math.Round(numFunction.toDecimal(taxvw5Row["examt"]), 0);
                            taxvw5Row["def_amt"] = Math.Round(numFunction.toDecimal(taxvw5Row["def_amt"]), 0);
                        }
                    }
                }
                ARItemDataSet.Tables["taxvw5"].AcceptChanges();

                string defAmtExpr = "";
                decimal defPer = 0;
                decimal exAmt = 0;

                foreach (DataRow taxVw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
                {
                    if (Convert.ToString(taxVw5Row["fld_nm"]).Trim().ToUpper() == "EXAMT")
                        continue;

                    exAmt = 0;
                    defAmtExpr = Convert.ToString(taxVw5Row["amtexpr"]).Trim();
                    defPer = numFunction.toDecimal(taxVw5Row["def_pert"]);
                    if (defAmtExpr.Trim() != "" && defPer > 0)
                    {
                        if (defAmtExpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = defAmtExpr.Trim().Substring(0, defAmtExpr.Trim().IndexOf("."));
                            DataFieldName = defAmtExpr.Trim().Substring(defAmtExpr.Trim().IndexOf(".") + 1, (defAmtExpr.Length - defAmtExpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                            {
                                exAmt = numFunction.toDecimal(main_vw.Rows[0][DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * defPer) / 100);
                            taxVw5Row["def_amt"] = numFunction.toDecimal(exAmt, 2);
                            if (bitFunction.toBoolean(taxVw5Row["round_off"]) == true)
                            {
                                taxVw5Row["def_amt"] = Math.Round(numFunction.toDecimal(taxVw5Row["def_amt"]), 0);
                            }
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }
                    }
                    taxVw5Row.AcceptChanges();
                }

                ARItemDataSet.Tables["taxvw5"].AcceptChanges();

                string deffld, defper = "";
                foreach (DataRow taxvw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
                {
                    deffld = Convert.ToString(taxvw5Row["fld_nm"]).Trim();
                    defper = Convert.ToString(taxvw5Row["pert_name"]).Trim();
                    itemRow[deffld] = numFunction.toDecimal(taxvw5Row["def_amt"], 2);
                    itemRow[defper] = numFunction.toDecimal(taxvw5Row["def_pert"], 2);
                }

                grdExciseDuty.DataSource = ARItemDataSet.Tables["taxvw5"];
                grdBind(grdExciseDuty);

                ManuRow["manumtduty"] = numFunction.toDecimal(itemRow["mtduty"]);

                SessionProxy.EtARItemDataSet = ARItemDataSet;
                SessionProxy.EtManuRow = ManuRow;
                SessionProxy.EtItemRow = itemRow;

                refreshvalues(ManuRow,
                        itemRow,
                        ARItemDataSet);

            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                UpdatePanel6.Update();
                ScriptManager1.SetFocus(txtMtDuty);
            }
            finally
            {
                main_vw.Dispose();
                ARItemDataSet.Dispose();
                DsETItemDetail.Dispose();
            }
        }

        protected void refreshvalues(DataRow ManuRow,
                DataRow itemRow,
                DataSet ARItemDataSet)
        {
            numericFunction numFunction = new numericFunction();
            getDateFormat dateFormat = new getDateFormat();
            txtAsseVal.Text = Convert.ToString(numFunction.toDecimal(ManuRow["assevalue"]));
            txtMtDuty.Text = Convert.ToString(numFunction.toDecimal(itemRow["mtduty"]));
            txtToTExcise.Text = Convert.ToString(numFunction.toDecimal(ARItemDataSet.Tables["taxvw5"].Compute("SUM(def_amt)", "")));

            if (tabItemDet.Tabs[1].Enabled == true)
            {
                txtManuQty.Text  = Convert.ToString(numFunction.toDecimal(ManuRow["manuqty"]));
                txtManuRate.Text = Convert.ToString(numFunction.toDecimal(itemRow["u_mrate"]));
                txtManuBill.Text = Convert.ToString(ManuRow["manubill"]);
                txtManAsseVal.Text = Convert.ToString(numFunction.toDecimal(ManuRow["assevalue"]));
                txtManuMtDuty.Text = Convert.ToString(numFunction.toDecimal(ManuRow["manumtduty"]));
                txtManuLoosQty.Text = Convert.ToString(numFunction.toDecimal(ManuRow["manuqty1"]));
                txtManuDate.Text = dateFormat.dateformatBR(Convert.ToString(ManuRow["manudate"]));  
            }
        }

        //private void BindingContext(DataRow ManuRow)
        //{
        //    ManuRow["manuqty"] = numFunction.toDecimal(txtManuQty.Text);
        //    ManuRow["manumtduty"] = numFunction.toDecimal(txtManuMtDuty.Text);
        //    ManuRow["manubill"] = Convert.ToString(txtManuBill.Text).Trim();
        //    ManuRow["assevalue"] = numFunction.toDecimal(txtManAsseVal.Text);

        //}
        protected void txtManuQty_TextChanged(object sender, EventArgs e)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataSet ARItemDataSet = null;

            try
            {
                DataRow itemRow = SessionProxy.EtItemRow;
                DataRow ManuRow = SessionProxy.EtManuRow;
                ARItemDataSet = SessionProxy.EtARItemDataSet;

                ManuRow["manuqty"] = numFunction.toDecimal(txtManuQty.Text);
                ManuRow["manumtduty"] = numFunction.toDecimal(txtManuMtDuty.Text);

                decimal manuMtDuty = numFunction.toDecimal(ManuRow["manuqty"]) *
                        numFunction.toDecimal(ManuRow["manumtduty"]);
                decimal defPer = 0;
                foreach (DataRow taxvw2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                {
                    if (Convert.ToString(taxvw2Row["fld_nm"]).Trim().ToUpper() == "EXAMT")
                    {
                        defPer = numFunction.toDecimal(taxvw2Row["def_pert"]);
                        break;
                    }
                }

                decimal uAsseManu = numFunction.toDecimal(itemRow["u_mrate"]) > 0 ?
                        numFunction.toDecimal(itemRow["u_mrate"]) * numFunction.toDecimal(txtManuQty.Text)
                        : ((100 * manuMtDuty) / defPer);

                txtManAsseVal.Text = Convert.ToString(uAsseManu);
                ManuRow["assevalue"] = numFunction.toDecimal(txtManAsseVal.Text);

                string mDefAmtexpr = "";
                decimal mdefPer, manuDefamt, exAmt = 0;

                foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                {
                    exAmt = 0;
                    mDefAmtexpr = Convert.ToString(tax2Row["amtexpr"]).Trim();
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".MANUQTY");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("U_ASSEAMT", "ASSEVALUE");
                    foreach (DataRow tax2VwRow in ARItemDataSet.Tables["taxvw2"].Rows)
                    {
                        mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax2VwRow["fld_nm"]).Trim(),
                                        Convert.ToString(tax2VwRow["fld_manu"]).Trim());
                    }

                    mdefPer = numFunction.toDecimal(tax2Row["def_pert"]);
                    if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                    {
                        if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                            DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                            {
                                exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * mdefPer) / 100);
                            manuDefamt = exAmt;
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }

                        tax2Row["def_amt"] = exAmt;

                        if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                        {
                            tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                        }

                        ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = manuDefamt;
                    }
                    else
                    {
                        if (mDefAmtexpr == "")
                        {
                            mdefPer = 100;

                            exAmt = ((numFunction.toDecimal(ManuRow["assevalue"])
                                * numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_nm"]).Trim()]))
                                / numFunction.toDecimal(itemRow["u_asseamt"]));

                            tax2Row["def_amt"] = exAmt * mdefPer / 100;

                            if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                            {
                                tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                            }
                            ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = numFunction.toDecimal(tax2Row["def_amt"]);
                        }
                    }
                }
                ARItemDataSet.Tables["taxvw2"].AcceptChanges();

                SessionProxy.EtARItemDataSet = ARItemDataSet;
                SessionProxy.EtItemRow = itemRow;
                SessionProxy.EtManuRow = ManuRow;

                grdManDet.DataSource = ARItemDataSet.Tables["taxvw2"];
                grdBind(grdManDet);

                refreshvalues(ManuRow,
                     itemRow,
                     ARItemDataSet);

            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                UpdatePanel6.Update();
                ARItemDataSet.Dispose();
                ScriptManager1.SetFocus(txtManuQty);
            }
            finally
            {
                ScriptManager1.SetFocus(txtManuRate);  
                ARItemDataSet.Dispose();
            }
        }

        protected void txtManAsseVal_TextChanged(object sender, EventArgs e)
        {
            DataSet ARItemDataSet = null;
            try
            {
                numericFunction numFunction = new numericFunction();
                boolFunction bitFunction = new boolFunction();
                string mDefAmtexpr = "";
                decimal mdefPer, manuDefamt, exAmt = 0;

                DataRow itemRow = SessionProxy.EtItemRow;
                DataRow ManuRow = SessionProxy.EtManuRow;
                ARItemDataSet = SessionProxy.EtARItemDataSet;


                ManuRow["assevalue"] = numFunction.toDecimal(txtManAsseVal.Text);
                ManuRow["manumtduty"] = numFunction.toDecimal(txtManuMtDuty.Text);

                foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                {
                    exAmt = 0;
                    mDefAmtexpr = Convert.ToString(tax2Row["amtexpr"]).Trim();
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".MANUQTY");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("U_ASSEAMT", "ASSEVALUE");
                    foreach (DataRow tax2VwRow in ARItemDataSet.Tables["taxvw2"].Rows)
                    {
                        mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax2VwRow["fld_nm"]).Trim(),
                                        Convert.ToString(tax2VwRow["fld_manu"]).Trim());
                    }

                    mdefPer = numFunction.toDecimal(tax2Row["def_pert"]);
                    if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                    {
                        if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                            DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                            {
                                exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * mdefPer) / 100);
                            manuDefamt = exAmt;
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }

                        tax2Row["def_amt"] = exAmt;
                        ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = manuDefamt;
                    }
                    else
                    {
                        if (mDefAmtexpr == "")
                        {
                            mdefPer = 100;

                            exAmt = ((numFunction.toDecimal(ManuRow["assevalue"])
                                * numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_nm"]).Trim()]))
                                / numFunction.toDecimal(itemRow["u_asseamt"]));

                            tax2Row["def_amt"] = exAmt * mdefPer / 100;

                            if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                            {
                                tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                            }
                            ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = numFunction.toDecimal(tax2Row["def_amt"]);
                        }
                    }
                }
                ARItemDataSet.Tables["taxvw2"].AcceptChanges();
                SessionProxy.EtARItemDataSet = ARItemDataSet;
                SessionProxy.EtManuRow = ManuRow;
                SessionProxy.EtItemRow = itemRow;

                grdManDet.DataSource = ARItemDataSet.Tables["taxvw2"];
                grdBind(grdManDet);

                refreshvalues(ManuRow,
                    itemRow,
                    ARItemDataSet);

            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                UpdatePanel6.Update();
                ScriptManager1.SetFocus(txtManAsseVal);
            }
            finally
            {
                ARItemDataSet.Dispose();
            }
        }

        protected void txtRGPage_TextChanged(object sender, EventArgs e)
        {
            if (txtRGPage.Text.Trim() == "")
                return;


            if (AddMode == true || EditMode == true)
            {
                numericFunction numFunction = new numericFunction();
                boolFunction bitFunction = new boolFunction();
                DataRow itemRow = SessionProxy.EtItemRow;
                DataSet ARItemDataSet = SessionProxy.EtARItemDataSet;
                DataSet DsETItemDetail = SessionProxy.DsETItemDetail;

                DataTable item_vw = DsETItemDetail.Tables["item_vw"];
                DataTable main_vw = DsETItemDetail.Tables["main_vw"];
                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;
 

                string vGoDown = Convert.ToString(itemRow["ware_nm"]).Trim();
                string vItSerial = Convert.ToString(itemRow["itserial"]).Trim();
                bool isFound = false;
                foreach (DataRow itemvwRow in item_vw.Rows)
                {
                    if (Convert.ToString(itemvwRow["ware_nm"]).Trim() == vGoDown.Trim())
                    {
                        if (numFunction.toInt32(itemvwRow["rgpage"]) == numFunction.toInt32(txtRGPage.Text) &&
                            numFunction.toInt32(itemvwRow["itserial"]) != numFunction.toInt32(vItSerial))   
                        {
                            isFound = true;
                        }
                    }
                }

                if (isFound == true)
                {
                    if (bitFunction.toBoolean(ARItemDataSet.Tables["manufact"].Rows[0]["rgBillg"]) == true)
                    {
                        sqlstr = "Select Entry_ty,Tran_cd,Itserial From Gen_srno " +
                                  " Where CTYPE = 'RGPAGE' And Npgno = '" + txtRGPage.Text.Trim() + "'";
                    }
                    else
                    {
                        sqlstr = "Select Entry_ty,Tran_cd,Itserial From Gen_srno " +
                                 " Where CTYPE = 'RGPAGE' AND CWARE ='" + Convert.ToString(itemRow["ware_nm"]).Trim() + "'" +
                                 " And Npgno = '" + txtRGPage.Text.Trim() + "'";
                    }

                    dr = DataAcess.ExecuteDataReader(sqlstr,ref connHandle);

                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            if (Convert.ToString(dr["entry_ty"]).Trim() == Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim() &&
                                numFunction.toInt32(dr["tran_cd"]) == numFunction.toInt32(main_vw.Rows[0]["tran_cd"]) &&
                                Convert.ToString(dr["itserial"]).Trim() == Convert.ToString(itemRow["itserial"]).Trim())
                            {
                                isFound = false;
                            }
                            else
                            {
                                isFound = true;
                            }
                        }
                    }
                    else
                    {
                        isFound = false;
                    }
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle); 
                }

                if (isFound == true)
                {
                    lblError.Text = "RG Page already exist";
                    txtRGPage.Focus(); 
                }

                itemRow["rgpage"] = txtRGPage.Text;

                SessionProxy.EtARItemDataSet = ARItemDataSet; 
                SessionProxy.EtItemRow = itemRow;
                main_vw.Dispose();
                item_vw.Dispose();
                ARItemDataSet.Dispose(); 
            }
        }

        protected void txtManuRate_TextChanged(object sender, EventArgs e)
        {
            DataSet ARItemDataSet = null;
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            try
            {
                numericFunction numFunction = new numericFunction();
                ARItemDataSet = SessionProxy.EtARItemDataSet;
                DataRow itemRow = SessionProxy.EtItemRow;
                DataRow ManuRow = SessionProxy.EtManuRow;
                ARItemDataSet = SessionProxy.EtARItemDataSet;

                decimal asseVal = numFunction.toDecimal(txtManuQty.Text) *
                    numFunction.toDecimal(txtManuRate.Text);

                txtManAsseVal.Text = Convert.ToString(asseVal);

                ManuRow["assevalue"] = asseVal;
                itemRow["u_mrate"] = numFunction.toDecimal(txtManuRate.Text);


                string mDefAmtexpr = "";
                decimal mdefPer, manuDefamt, exAmt = 0;
                boolFunction bitFunction = new boolFunction();
                foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                {
                    exAmt = 0;
                    mDefAmtexpr = Convert.ToString(tax2Row["amtexpr"]).Trim();
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".MANUQTY");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("U_ASSEAMT", "ASSEVALUE");
                    foreach (DataRow tax2VwRow in ARItemDataSet.Tables["taxvw2"].Rows)
                    {
                        mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax2VwRow["fld_nm"]).Trim(),
                                        Convert.ToString(tax2VwRow["fld_manu"]).Trim());
                    }
                    mdefPer = numFunction.toDecimal(tax2Row["def_pert"]);
                    if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                    {
                        if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                            DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                            {
                                exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * mdefPer) / 100);
                            manuDefamt = exAmt;
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }

                        tax2Row["def_amt"] = exAmt;

                        if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                        {
                            tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                        }

                        ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = manuDefamt;
                    }
                    else
                    {
                        if (mDefAmtexpr == "")
                        {
                            mdefPer = 100;

                            exAmt = ((numFunction.toDecimal(ManuRow["assevalue"])
                                * numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_nm"]).Trim()]))
                                / numFunction.toDecimal(itemRow["u_asseamt"]));

                            tax2Row["def_amt"] = exAmt * mdefPer / 100;

                            if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                            {
                                tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                            }

                            ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = numFunction.toDecimal(tax2Row["def_amt"]);
                        }
                    }
                }
                ARItemDataSet.Tables["taxvw2"].AcceptChanges();

                grdManDet.DataSource = ARItemDataSet.Tables["taxvw2"];
                grdBind(grdManDet);

                SessionProxy.EtARItemDataSet = ARItemDataSet;
                SessionProxy.EtManuRow = ManuRow;
                SessionProxy.EtItemRow = itemRow;
            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                UpdatePanel6.Update();
                ScriptManager1.SetFocus(txtManuRate);
            }
            finally
            {
                ARItemDataSet.Dispose();
            }
        }

        protected void fillPreviousBill(ref DataSet ARItemDataSet,
                    ref DataRow itemRow)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName; 

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            //string entryTy = "AR";
            //sqlstr = "SELECT * FROM DCMAST WHERE ENTRY_TY='" + entryTy + "' AND CODE='E' AND ATT_FILE=0";
            //ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "PrevDcMast_vw");
            //sqlstr = "select * from dcmast where 1=0";
            //ARItemDataSet = DataAcess.ExecuteDataset(ARItemDataSet, sqlstr, "prevvw");

            foreach (DataRow PrevDcRow in ARItemDataSet.Tables["PrevDcMast_vw"].Rows)
            {
                PrevDcRow["head_nm"] = "Bill " + Convert.ToString(PrevDcRow["head_nm"]).Trim();
                PrevDcRow["def_amt"] = numFunction.toDecimal(itemRow[Convert.ToString(PrevDcRow["fld_bill"]).Trim()]);
                PrevDcRow["excl_net"] = bitFunction.toBoolean(PrevDcRow["att_file"]) == false && Convert.ToString(PrevDcRow["code"]).Trim() == "E" ?
                                       "E" : Convert.ToString(PrevDcRow["excl_net"]).Trim();

                DataRow prevvwRow = ARItemDataSet.Tables["prevvw"].NewRow();
                prevvwRow = DataAcess.ExactScatterGatherRow(PrevDcRow, prevvwRow);
                ARItemDataSet.Tables["prevvw"].Rows.Add(PrevDcRow);
                ARItemDataSet.Tables["prevvw"].AcceptChanges();
            }

            foreach (DataRow prevvwRow in ARItemDataSet.Tables["prevvw"].Rows)
            {
                if (itemRow.Table.Columns.Contains(Convert.ToString(prevvwRow["fld_bill"]).Trim()) == true)
                {
                    if (itemRow.Table.Columns[Convert.ToString(prevvwRow["fld_bill"]).Trim()].DataType.ToString().Trim().ToUpper() != "SYSTEM.DECIMAL")
                    {
                        continue;
                    }
                }
                else
                {
                    continue;
                }

                prevvwRow["def_amt"] = Convert.ToString(prevvwRow["fld_bill"]).Trim() != "" ?
                                     numFunction.toDecimal(itemRow[Convert.ToString(prevvwRow["fld_bill"]).Trim()]) :
                                     numFunction.toDecimal(prevvwRow["def_amt"]);


                DataRow taxvw3Row = ARItemDataSet.Tables["taxvw3"].NewRow();
                taxvw3Row = DataAcess.ExactScatterGatherRow(prevvwRow, taxvw3Row);
                ARItemDataSet.Tables["taxvw3"].Rows.Add(taxvw3Row);
                ARItemDataSet.Tables["taxvw3"].AcceptChanges();
            }

            grdPrevDet.DataSource = ARItemDataSet.Tables["taxvw3"];
            grdPrevDet.DataBind();

            if (numFunction.toDecimal(itemRow["billqty"]) <= 0)
            {
                itemRow["billqty"] = numFunction.toDecimal(itemRow["qty"]);
                itemRow["billassamt"] = numFunction.toDecimal(itemRow["u_asseamt"]);

                txtPrevBillQty.Text = Convert.ToString(numFunction.toDecimal(itemRow["qty"]));
                txtPrevBillAss.Text = Convert.ToString(numFunction.toDecimal(itemRow["u_asseamt"]));

                foreach (DataRow taxRow in ARItemDataSet.Tables["taxvw3"].Rows)
                {
                    itemRow[Convert.ToString(taxRow["fld_bill"]).Trim()] =
                        numFunction.toDecimal(itemRow[Convert.ToString(taxRow["fld_nm"]).Trim()]);
                    taxRow["def_amt"] = numFunction.toDecimal(itemRow[Convert.ToString(taxRow["fld_nm"]).Trim()]);
                }
                ARItemDataSet.Tables["taxvw3"].AcceptChanges();
            }
            else
            {
                txtPrevBillQty.Text = Convert.ToString(numFunction.toDecimal(itemRow["billqty"]));
                txtPrevBillAss.Text = Convert.ToString(numFunction.toDecimal(itemRow["billassamt"]));

                foreach (DataRow taxRow in ARItemDataSet.Tables["taxvw3"].Rows)
                {
                    taxRow["def_amt"] = numFunction.toDecimal(itemRow[Convert.ToString(taxRow["fld_bill"]).Trim()]);
                }
                ARItemDataSet.Tables["taxvw3"].AcceptChanges();
            }
        }

        protected void dropLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropLocation.SelectedIndex == 0)
                return;

            numericFunction numFunction = new numericFunction();
            DataRow itemRow = SessionProxy.EtItemRow; 
            itemRow["Manusac_id"] = numFunction.toInt32(dropLocation.SelectedValue);
            SessionProxy.EtItemRow = itemRow;
            txtRGPage.Focus(); 
        }

        protected void dropWareHouse_SelectedIndexChanged(object sender, EventArgs e)
        {
            callFromDropWH(dropWareHouse);
            ScriptManager1.SetFocus(txtManuName);   
        }

        protected void callFromDropWH(DropDownList dropWH)
        {
            if (dropWH.SelectedIndex == 0)
                return;

            DataRow itemRow = SessionProxy.EtItemRow;
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable item_vw = DsETItemDetail.Tables["item_vw"]; 

            itemRow["ware_nm"] = Convert.ToString(dropWH.SelectedValue).Trim();
            itemRow["rgpage"] = "";
            txtRGPage.Text = "";
           
            GenerateRGPage RgPage = new GenerateRGPage();
            txtRGPage.Text = RgPage.GenRGPageNo(item_vw, itemRow, null,ref connHandle);
            itemRow["rgpage"] = txtRGPage.Text.Trim();
            
            item_vw.Dispose();
            DsETItemDetail.Dispose(); 
            SessionProxy.EtItemRow = itemRow;
        }



        protected void btnDone_Click(object sender, EventArgs e)
        {
            try
            {
                if (AddMode == true || EditMode == true)
                {
                    DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
                    DataRow itemRow = SessionProxy.EtItemRow;
                    DataRow ManuRow = SessionProxy.EtManuRow;
                    DataSet ARItemDataSet = SessionProxy.EtARItemDataSet;
                    DataTable main_vw = DsETItemDetail.Tables["main_vw"];
                    DataTable item_vw = DsETItemDetail.Tables["item_vw"];
                    DataTable manu_det_vw = DsETItemDetail.Tables["manu_det_vw"];
                    DataTable company = DsETItemDetail.Tables["company"];  

                    stringFunction strFunction = new stringFunction();
                    numericFunction numFunction = new numericFunction();
                    getDateFormat DateFormat = new getDateFormat();

                    itemRow["ppageno"] = Convert.ToString(txtSupRgPgNo.Text).Trim();
                    itemRow["pentno"] = Convert.ToString(txtSupRgEntNo.Text).Trim();
                    itemRow["id_mark"] = Convert.ToString(txtIdMarkNo.Text).Trim();
                    ManuRow["manubill"] = Convert.ToString(txtManuBill.Text).Trim();
                    if (txtManuDate.Text.Trim() != "__/__/____")
                    {
                        ManuRow["manudate"] = DateFormat.TodateTime(txtManuDate.Text);
                    }
                   

                    if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim(),
                                new string[] { "MANUFACTURER", "IMPORTER" }) == false)
                    {
                        if (numFunction.toInt32(itemRow["manuac_id"]) == 0)
                        {
                            throw new Exception("Manufacturer name cannot be blank..");
                        }
                    }

                    if (Convert.ToString(itemRow["ware_nm"]).Trim() == "")
                    {
                        throw new Exception("Warehouse name cannot be blank..");
                    }

                    if (Convert.ToString(itemRow["rgpage"]).Trim() == "" &&
                        Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE")
                    {
                        throw new Exception("Rule cannot be blank..");
                    }

                    Validation(ref itemRow,
                                ref ManuRow,
                                ref ARItemDataSet,
                                ref main_vw,
                                ref company);

                    itemRow["balqty"] = numFunction.toDecimal(itemRow["qty"]);

                    foreach (DataRow taxvw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
                    {
                        itemRow[Convert.ToString(taxvw5Row["fld_excbal"]).Trim()] =
                            numFunction.toDecimal(taxvw5Row["def_amt"]);
                    }

                    //itemRow["sr_sr"] = Convert.ToString(itemRow["sr_sr"]).Trim().Substring(1, 3) +
                    //    "TT" + Convert.ToString(itemRow["sr_sr"]).Trim().Substring(6);


                    if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim(),
                              new string[] { "MANUFACTURER", "IMPORTER" }) == true)
                    {
                        ManuRow["manubill"] = Convert.ToString(main_vw.Rows[0]["u_pinvno"]);
                        ManuRow["manudate"] = DateFormat.TodateTime(main_vw.Rows[0]["u_pinvdt"]);
                        ManuRow["manuqty"] = numFunction.toDecimal(itemRow["qty"]);
                        itemRow["u_asseamt"] = numFunction.toDecimal(ManuRow["assevalue"]);
                        ManuRow["manuexamt"] = numFunction.toDecimal(itemRow["examt"]);
                        ManuRow["manucesamt"] = numFunction.toDecimal(itemRow["u_cessamt"]);
                        ManuRow["manuhcsamt"] = numFunction.toDecimal(itemRow["u_hcesamt"]);
                    }

                    if (DateFormat.TodateTime(main_vw.Rows[0]["date"]) <
                        DateFormat.TodateTime(company.Rows[0]["sta_dt"]) &&
                        strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim(),
                              new string[] { "MANUFACTURER", "IMPORTER" }) == true)
                    {
                        ManuRow["ManuQty"] = Convert.ToString(itemRow["BillQty"]);
                        ManuRow["ManuExamt"] = numFunction.toDecimal(itemRow["Billexamt"]); 
                        ManuRow["ManuCesamt"] = numFunction.toDecimal(itemRow["Billcesamt"]); 
                        ManuRow["ManuCvdamt"] = numFunction.toDecimal(itemRow["Billcvdamt"]);
                        ManuRow["ManuHcsamt"] = numFunction.toDecimal(itemRow["Billhcsamt"]);
                    }

                    foreach (DataRow tax5Row in ARItemDataSet.Tables["taxvw5"].Rows)
                    {
                        if (Convert.ToString(tax5Row["fld_nm"]).Trim().ToUpper() != "EXAMT")
                        {

                            decimal getval = RoundInt(numFunction.toDecimal(itemRow[Convert.ToString(tax5Row["fld_nm"]).Trim()]) /
                                                   numFunction.toDecimal(itemRow["qty"]));

                            itemRow[Convert.ToString(tax5Row["fld_duty"]).Trim()] = getval;
                            //itemRow[Convert.ToString(tax5Row["fld_mduty"]).Trim()] = getval;

                            // ManuDet

                            getval = RoundInt(numFunction.toDecimal(ManuRow[Convert.ToString(tax5Row["fld_manu"]).Trim()]) /
                                                   numFunction.toDecimal(ManuRow["manuqty"]));

                            ManuRow[Convert.ToString(tax5Row["fld_mduty"]).Trim()] = getval;
                        }
                    }

                    item_vw.AcceptChanges();
                    ManuRow.AcceptChanges();
                    manu_det_vw.AcceptChanges();
                    main_vw.AcceptChanges();

                    SessionProxy.EtARItemDataSet = null;
                    SessionProxy.EtManuRow = null;
                    SessionProxy.DutyPerUnitDec = 0;

                    SessionProxy.DsETItemDetail = DsETItemDetail; 
                    SessionProxy.EtItemRow = itemRow; 

                    ARItemDataSet.Dispose();
                    DsETItemDetail.Dispose(); 
                    main_vw.Dispose();
                    item_vw.Dispose();
                    manu_det_vw.Dispose();
                    company.Dispose();

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "doneDialog();", true);
                    return; 
                }
            }
            catch (Exception Ex)
            {
                lblError.Text = Ex.Message;
            }
        }

        protected void Validation(ref DataRow itemRow,
                ref DataRow ManuRow,
                ref DataSet ARItemDataSet,
                ref DataTable main_vw,
                ref DataTable company)
        {
            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();
            getDateFormat DateFormat = new getDateFormat();

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            SqlParameter[] spParam = new SqlParameter[2];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@manuacId";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = numFunction.toInt32(itemRow["manuac_id"]);

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@manusacId";
            spParam[1].SqlDbType = SqlDbType.Int;
            spParam[1].Value = numFunction.toInt32(itemRow["manusac_id"]);

            SqlDataReader dr = DataAcess.ExecuteDataReader("sp_ent_web_ETARItemDetail_validation",
                                            spParam, ref connHandle);

            if (numFunction.toInt32(itemRow["manuac_id"]) != 0)
            {
                //sqlstr = "select ac_id from ac_mast where ac_id = " +
                //    numFunction.toInt32(itemRow["manuac_id"]);

                //dr = DataAcess.ExecuteDataReader(sqlstr);

                bool isfound = false;
                bool isfounds = false;
                while (dr.Read())
                {
                    isfound = Convert.ToBoolean(dr["ManuAcId"]);
                    isfounds = Convert.ToBoolean(dr["ManusAcId"]);
                }

                if (isfound == false)
                {
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle); 
                    throw new Exception("Manufacturer name cannot be blank..");
                }
            
                //if (numFunction.toInt32(itemRow["manusac_id"]) == 0)
                //{
                //    sqlstr = "select Vend_Type,Eccno From Ac_mast Where Ac_id = "
                //            + numFunction.toInt32(itemRow["manuac_id"]);
                //}
                //else
                //{
                //    sqlstr = "select Vend_Type,Eccno From shipto Where Ac_id = "
                //            + numFunction.toInt32(itemRow["manuac_id"])
                //            + " and shipto_id = " + numFunction.toInt32(itemRow["manusac_id"]);
                //}

                //DataAcess = new DataTier();
                //dr = DataAcess.ExecuteDataReader(sqlstr);
                //bool isfind = false;
                //if (dr.HasRows == true)
                //{
                //    isfind = true;
                //}
                //dr.Close();
                //dr.Dispose();

                //isfound = false;
                //while (dr.Read())
                //{
                //    isfound = Convert.ToBoolean(dr["ManusAcId"]);
                //}

                if (isfounds == false)
                {
                    dr.Close();
                    dr.Dispose();
                    DataAcess.Connclose(connHandle); 
                    throw new Exception("Manufacture's Location details not found in master");
                }
                dr.Close();
                dr.Dispose();
                DataAcess.Connclose(connHandle); 

                if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim() == "EXCISE")
                {
                    if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]),
                            new string[] {"MANUFACTURER","IMPORTER"}) == false)
                    {
                        if (Convert.ToString(ManuRow["manubill"]).Trim() == "")
                        {
                            txtManuBill.Focus(); 
                            throw new Exception("Manufacture's Bill no. cannot be empty..");
                        }

                        if (DateFormat.TodateTime(ManuRow["manudate"]) == DateTime.MinValue ||
                            DateFormat.TodateTime(ManuRow["manudate"]) == DateTime.MaxValue)
                        {
                            throw new Exception("Manufacture's Bill Date cannot be empty..");
                        }

                        if (DateFormat.TodateTime(main_vw.Rows[0]["date"]) <
                            DateFormat.TodateTime(ManuRow["manudate"]))
                        {
                            throw new Exception("Manufacture's excise date cannot be greater than Goods Receipt Transaction date");
                        }

                        if (Convert.ToString(itemRow["ppageno"]).Trim() == "")
                        {
                            txtSupRgPgNo.Focus();
                            throw new Exception("Supplier RG Page No. cannot be empty..");
                        }

                        if (Convert.ToString(itemRow["pentno"]).Trim() == "")
                        {
                            txtSupRgEntNo.Focus();
                            throw new Exception("Supplier RG Entry No. cannot be empty..");
                        }
                    }
                
                
                    if (numFunction.toDecimal(itemRow["mtduty"]) >  
                            numFunction.toDecimal(itemRow["examt"]))
                    {
                        throw new Exception("Duty per unit cannot be greater than Excise Amt.");
                    }

                    //if (numFunction.toDecimal(itemRow["u_cessamt"]) >
                    //        numFunction.toDecimal(itemRow["examt"]))
                    //{
                    //    throw new Exception("Cess surcharge cannot be greater than Excise Amt.");
                    //}

                    if (DateFormat.TodateTime(main_vw.Rows[0]["date"]) <
                            DateFormat.TodateTime(company.Rows[0]["sta_dt"]))
                    {
                        if (numFunction.toDecimal(itemRow["billassamt"]) <
                                numFunction.toDecimal(itemRow["u_asseamt"]))
                        {
                            throw new Exception("Bill Ass. Value can't be less than Ass. Value");
                        }

                        if (numFunction.toDecimal(itemRow["billqty"]) <
                                numFunction.toDecimal(itemRow["qty"]))
                        {
                            throw new Exception("Bill Qty. cannot be less than Goods Reciept Qty.");
                        }
                        //else
                        //{
                        //    if (numFunction.toDecimal(itemRow["billexamt"]) <
                        //            numFunction.toDecimal(itemRow["examt"]))
                        //    {
                        //        throw new Exception("Bill Excise Amt. cannot be less than Supplier/Manufacturer/Importer Excise Amt.");
                        //    }
                        //}

                        foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                        {
                            if (numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_bill"]).Trim()]) <
                                    numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_nm"]).Trim()]))
                            {
                                throw new Exception("Bill " + Convert.ToString(tax2Row["head_nm"]).Trim()+
                                    " can't be less than " + Convert.ToString(tax2Row["head_nm"]));   
                            }
                        }
                    }

                    //

                    if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]),
                            new string[] {"MANUFACTURER","IMPORTER"}) == false)
                    {
                        if (numFunction.toDecimal(ManuRow["manuqty"]) < 
                                numFunction.toDecimal(itemRow["qty"]))
                        {
                            throw new Exception("Manufacturer Qty cannot be less than Qty.");
                        }

                        foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                        {
                            if (numFunction.toDecimal(ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()]) <
                                    numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_nm"]).Trim()]))
                            {
                                throw new Exception("Manufactured " + Convert.ToString(tax2Row["head_nm"]).Trim()+
                                    " can't be less than " + Convert.ToString(tax2Row["head_nm"]));   
                            }
                        }

                        if (DateFormat.TodateTime(main_vw.Rows[0]["date"]) <
                            DateFormat.TodateTime(company.Rows[0]["sta_dt"]))
                        {
                            if (numFunction.toDecimal(ManuRow["Assevalue"]) <
                                numFunction.toDecimal(itemRow["BillAssAmt"]))
                            {
                                throw new Exception("Manufactured Ass. Value cannot be less than Bill Ass. Value");
                            }

                            if (numFunction.toDecimal(ManuRow["manuqty"]) <
                                numFunction.toDecimal(itemRow["billqty"]))
                            {
                                throw new Exception("Manufactured Qty. cannot be less than Bill Qty.");
                            }

                            foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
                            {
                                if (numFunction.toDecimal(ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()]) <
                                        numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_bill"]).Trim()]))
                                {
                                    throw new Exception("Manufactured " + Convert.ToString(tax2Row["head_nm"]).Trim()+
                                        " can't be less than Bill" + Convert.ToString(tax2Row["head_nm"]));   
                                }
                            }
                        }
                    }
                }
            }

            if (strFunction.InList(Convert.ToString(main_vw.Rows[0]["ettype"]).Trim(),
                        new string[] { "MANUFACTURER", "IMPORTER" }) == false)
            {
                    ManuRow["manuac_id"] = numFunction.toInt32(itemRow["manuac_id"]);
                    ManuRow["manusac_id"] = numFunction.toInt32(itemRow["manusac_id"]);
            }
            else
            {
                    ManuRow["manuac_id"] = numFunction.toInt32(main_vw.Rows[0]["cons_id"]);
                    ManuRow["manusac_id"] = numFunction.toInt32(main_vw.Rows[0]["scons_id"]);
            }
           
        }

            

        protected void txtdefPer_TextChanged(object sender, EventArgs e)
        {
            NumericTextBox numBox = ((NumericTextBox)sender);
            GridViewRow row = ((GridViewRow)numBox.NamingContainer);
            callFromGrdExDuty(row.RowIndex);
            numBox.Dispose();
        }

        protected void txtdefAmt_TextChanged(object sender, EventArgs e)
        {
            NumericTextBox numBox = ((NumericTextBox)sender);
            GridViewRow row = ((GridViewRow)numBox.NamingContainer);
            callFromGrdExDuty(row.RowIndex);
            numBox.Dispose();
        }

        protected void callFromGrdExDuty(int RowIndex)
        {

            DataRow itemRow = SessionProxy.EtItemRow;
            DataRow ManuRow = SessionProxy.EtManuRow;
            DataSet ARItemDataSet = SessionProxy.EtARItemDataSet;
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable main_vw = DsETItemDetail.Tables["main_vw"];

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            decimal defPert, defamt, exAmt = 0;
            defPert = numFunction.toDecimal(((NumericTextBox)grdExciseDuty.Rows[RowIndex].FindControl("txtdefPer")).Text);
            defamt = numFunction.toDecimal(((NumericTextBox)grdExciseDuty.Rows[RowIndex].FindControl("txtdefAmt")).Text);

            string deffld, perfld = "";
            deffld = grdExciseDuty.DataKeys[RowIndex].Values[0].ToString().Trim();
            perfld = grdExciseDuty.DataKeys[RowIndex].Values[1].ToString().Trim();

            itemRow[perfld.Trim()] = defPert;
            itemRow[deffld.Trim()] = defamt;

            foreach (DataRow taxvw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
            {
                exAmt = 0;
                if (Convert.ToString(taxvw5Row["fld_nm"]).Trim() == deffld)
                {
                    if (defPert != numFunction.toDecimal(taxvw5Row["def_pert"]))
                    {
                        string amtExpr = Convert.ToString(taxvw5Row["amtexpr"]).Trim();
                        if (amtExpr.Trim() != "")
                        {
                            if (amtExpr.Trim().IndexOf('.') >= 0)
                            {
                                string DataTableName, DataFieldName = "";
                                DataTableName = amtExpr.Trim().Substring(0, amtExpr.Trim().IndexOf("."));
                                DataFieldName = amtExpr.Trim().Substring(amtExpr.Trim().IndexOf(".") + 1, (amtExpr.Length - amtExpr.Trim().IndexOf(".")) - 1);

                                if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                                {
                                    exAmt = numFunction.toDecimal(main_vw.Rows[0][DataFieldName]);
                                }
                                else
                                {
                                    if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                    {
                                        exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                    }
                                    else
                                    {
                                        throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                    }
                                }

                                exAmt = (((exAmt) * defPert) / 100);
                            }
                            else
                            {
                                throw new Exception("Amount Expression is not proper in dcmast");
                            }
                        }
                    }
                    else
                    {
                        exAmt = defamt;
                    }

                    taxvw5Row["def_pert"] = defPert;
                    
                    
                    if (bitFunction.toBoolean(taxvw5Row["round_off"]) == true)
                    {
                        exAmt = Math.Round(exAmt, 0);
                    }
                    taxvw5Row["def_amt"] = exAmt;
                    taxvw5Row.AcceptChanges();
                }

                itemRow[Convert.ToString(taxvw5Row["fld_nm"]).Trim()] = numFunction.toDecimal(taxvw5Row["def_amt"], 2);
                itemRow[Convert.ToString(taxvw5Row["pert_name"]).Trim()] = numFunction.toDecimal(taxvw5Row["def_pert"]);
            }

            string defAmtExpr = "";
            decimal defPer = 0;
            exAmt = 0;

            foreach (DataRow taxVw5Row in ARItemDataSet.Tables["taxvw5"].Rows)
            {
                if (Convert.ToString(taxVw5Row["fld_nm"]).Trim() == deffld.Trim())
                    continue;

                exAmt = 0;
                defAmtExpr = Convert.ToString(taxVw5Row["amtexpr"]).Trim();
                defPer = numFunction.toDecimal(taxVw5Row["def_pert"]);
                if (defAmtExpr.Trim() != "" && defPer > 0)
                {
                    if (defAmtExpr.Trim().IndexOf('.') >= 0)
                    {
                        string DataTableName, DataFieldName = "";
                        DataTableName = defAmtExpr.Trim().Substring(0, defAmtExpr.Trim().IndexOf("."));
                        DataFieldName = defAmtExpr.Trim().Substring(defAmtExpr.Trim().IndexOf(".") + 1, (defAmtExpr.Length - defAmtExpr.Trim().IndexOf(".")) - 1);

                        if (DataTableName.ToString().Trim().ToUpper() == "MAIN_VW")
                        {
                            exAmt = numFunction.toDecimal(main_vw.Rows[0][DataFieldName]);
                        }
                        else
                        {
                            if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                            {
                                exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                            }
                            else
                            {
                                throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                            }
                        }

                        exAmt = (((exAmt) * defPer) / 100);
                        taxVw5Row["def_amt"] = numFunction.toDecimal(exAmt, 2);
                        if (bitFunction.toBoolean(taxVw5Row["round_off"]) == true)
                        {
                            taxVw5Row["def_amt"] = Math.Round(numFunction.toDecimal(taxVw5Row["def_amt"]), 0);   
                        }

                        itemRow[Convert.ToString(taxVw5Row["fld_nm"]).Trim()] = numFunction.toDecimal(taxVw5Row["def_amt"]);
                    }
                    else
                    {
                        throw new Exception("Amount Expression is not proper in dcmast");
                    }
                }
                taxVw5Row.AcceptChanges();
            }

            ARItemDataSet.Tables["taxvw5"].AcceptChanges();

            ManudetailActivate(ref ManuRow,
                    ref itemRow,
                    ref ARItemDataSet);

            itemRow["mtduty"] = numFunction.toDecimal((numFunction.toDecimal(itemRow["examt"]) / numFunction.toDecimal(itemRow["qty"])));
            ManuRow["manumtduty"] = numFunction.toDecimal((numFunction.toDecimal(itemRow["examt"]) / numFunction.toDecimal(itemRow["qty"])));

            grdExciseDuty.EditIndex = -1;
            grdExciseDuty.DataSource = ARItemDataSet.Tables["taxvw5"];
            grdBind(grdExciseDuty);

            refreshvalues(ManuRow,
                itemRow,
                ARItemDataSet);

            tabItemDet.ActiveTabIndex = 0;

            SessionProxy.EtItemRow = itemRow;
            SessionProxy.EtManuRow = ManuRow;
            SessionProxy.EtARItemDataSet = ARItemDataSet;
            SessionProxy.DsETItemDetail = DsETItemDetail; 

            ARItemDataSet.Dispose();
            DsETItemDetail.Dispose(); 
            main_vw.Dispose();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "refreshUpadatePanel();", true);
        }

        protected void txtdefManuAmt_TextChanged(object sender, EventArgs e)
        {
            NumericTextBox numBox = ((NumericTextBox)sender);
            GridViewRow row = ((GridViewRow)numBox.NamingContainer);
            callFromGrdManuDuty(row.RowIndex);
        }

        /// <summary>
        /// This below method is used for Manufacture details grid
        /// </summary>
        /// <param name="RowIndex"></param>
        protected void callFromGrdManuDuty(int RowIndex)
        {
            DataRow itemRow = SessionProxy.EtItemRow;
            DataRow ManuRow = SessionProxy.EtManuRow;
            DataSet ARItemDataSet = SessionProxy.EtARItemDataSet;  

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            decimal defamt = 0;
            defamt = numFunction.toDecimal(((NumericTextBox)grdManDet.Rows[RowIndex].FindControl("txtdefManuAmt")).Text);

            string deffld, perfld = "";
            deffld = grdManDet.DataKeys[RowIndex].Values[0].ToString().Trim();

            ManuRow[deffld.Trim()] = defamt;

            foreach (DataRow taxvw2Row in ARItemDataSet.Tables["taxvw2"].Rows)
            {
                if (Convert.ToString(taxvw2Row["fld_manu"]).Trim() == deffld)
                {
                    taxvw2Row["def_amt"] = defamt;
                    taxvw2Row.AcceptChanges();
                }
            }

            string mDefAmtexpr = "";
            decimal mdefPer, manuDefamt, exAmt = 0;

            foreach (DataRow tax2Row in ARItemDataSet.Tables["taxvw2"].Rows)
            {
                if (Convert.ToString(tax2Row["fld_manu"]).Trim() == deffld)
                    continue;

                exAmt = 0;
                mDefAmtexpr = Convert.ToString(tax2Row["amtexpr"]).Trim();
                mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".MANUQTY");
                mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("U_ASSEAMT", "ASSEVALUE");
                foreach (DataRow tax2VwRow in ARItemDataSet.Tables["taxvw2"].Rows)
                {
                    mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax2VwRow["fld_nm"]).Trim(),
                                    Convert.ToString(tax2VwRow["fld_manu"]).Trim());
                }

                mdefPer = numFunction.toDecimal(tax2Row["def_pert"]);

                if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                {
                    if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                    {
                        string DataTableName, DataFieldName = "";
                        DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                        DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                        if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                        {
                            exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                        }
                        else
                        {
                            if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                            {
                                exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                            }
                            else
                            {
                                throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                            }
                        }

                        exAmt = (((exAmt) * mdefPer) / 100);
                        manuDefamt = numFunction.toDecimal(exAmt);
                    }
                    else
                    {
                        throw new Exception("Amount Expression is not proper in dcmast");
                    }

                    tax2Row["def_amt"] = numFunction.toDecimal(exAmt);
                    ManuRow[Convert.ToString(tax2Row["fld_manu"]).Trim()] = manuDefamt;
                }
                else
                {

                    if (mDefAmtexpr == "")
                    {
                        mdefPer = 100;

                        exAmt = ((numFunction.toDecimal(ManuRow["assevalue"])
                            * numFunction.toDecimal(itemRow[Convert.ToString(tax2Row["fld_nm"]).Trim()]))
                            / numFunction.toDecimal(itemRow["u_asseamt"]));

                        tax2Row["def_amt"] = exAmt * mdefPer / 100;

                        if (bitFunction.toBoolean(tax2Row["round_off"]) == true)
                        {
                            tax2Row["def_amt"] = Math.Round(numFunction.toDecimal(tax2Row["def_amt"]), 0);
                        }
                        tax2Row["fld_manu"] = numFunction.toDecimal(tax2Row["def_amt"]);
                    }
                }
            }
            ARItemDataSet.Tables["taxvw2"].AcceptChanges();

            grdManDet.EditIndex = -1;
            grdManDet.DataSource = ARItemDataSet.Tables["taxvw2"];
            grdBind(grdManDet);

            SessionProxy.EtARItemDataSet = ARItemDataSet;
            SessionProxy.EtManuRow = ManuRow;
            SessionProxy.EtItemRow = itemRow;


            refreshvalues(ManuRow,
                           itemRow,
                           ARItemDataSet);

            ARItemDataSet.Dispose();
            tabItemDet.ActiveTabIndex = 1;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "refreshUpadatePanel();", true);
        }

        /// <summary>
        /// This below method is used for Previous year grid
        /// </summary>
        /// <param name="RowIndex"></param>
        
        protected void callFromGrdPrevDuty(int RowIndex)
        {
            DataRow itemRow = SessionProxy.EtItemRow;
            DataRow ManuRow = SessionProxy.EtManuRow;
            DataSet ARItemDataSet = SessionProxy.EtARItemDataSet;  

            numericFunction numFunction = new numericFunction();
            decimal defamt = 0;
            defamt = numFunction.toDecimal(((NumericTextBox)grdPrevDet.Rows[RowIndex].FindControl("txtdefPrevAmt")).Text);

            string deffld, perfld = "";
            deffld = grdPrevDet.DataKeys[RowIndex].Values[0].ToString().Trim();

            itemRow[deffld.Trim()] = defamt;

            foreach (DataRow taxvw3Row in ARItemDataSet.Tables["taxvw3"].Rows)
            {
                if (Convert.ToString(taxvw3Row["fld_bill"]).Trim() == deffld)
                {
                    taxvw3Row["def_amt"] = defamt;
                    taxvw3Row.AcceptChanges();
                }
            }

            string mDefAmtexpr = "";
            decimal mdefPer, prevDefamt, exAmt, manuDefamt = 0;

            foreach (DataRow tax3Row in ARItemDataSet.Tables["taxvw3"].Rows)
            {
                if (Convert.ToString(tax3Row["fld_bill"]).Trim() == deffld)
                    continue;

                exAmt = 0;
                mDefAmtexpr = Convert.ToString(tax3Row["amtexpr"]).Trim();
                mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".BILLQTY");
                foreach (DataRow tax3VwRow in ARItemDataSet.Tables["taxvw3"].Rows)
                {
                    mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax3VwRow["fld_nm"]).Trim(),
                                    Convert.ToString(tax3VwRow["fld_bill"]).Trim());
                }

                mdefPer = numFunction.toDecimal(tax3Row["def_pert"]);
                boolFunction bitFunction = new boolFunction();

                if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                {
                    if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                    {
                        string DataTableName, DataFieldName = "";
                        DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                        DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                        if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                        {
                            exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                        }
                        else
                        {
                            if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                            {
                                exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                            }
                            else
                            {
                                throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                            }
                        }

                        exAmt = (((exAmt) * mdefPer) / 100);
                        manuDefamt = numFunction.toDecimal(exAmt);
                    }
                    else
                    {
                        throw new Exception("Amount Expression is not proper in dcmast");
                    }

                    tax3Row["def_amt"] = numFunction.toDecimal(exAmt);
                    if (bitFunction.toBoolean(tax3Row["round_off"]) == true)
                    {
                        tax3Row["def_amt"] = Math.Round(exAmt,0);
                    }

                    ManuRow[Convert.ToString(tax3Row["fld_manu"]).Trim()] = manuDefamt;
                }
            }
            ARItemDataSet.Tables["taxvw3"].AcceptChanges();

            grdPrevDet.EditIndex = -1;
            grdPrevDet.DataSource = ARItemDataSet.Tables["taxvw3"];
            grdBind(grdPrevDet);

            SessionProxy.EtARItemDataSet = ARItemDataSet;
            SessionProxy.EtManuRow = ManuRow;
            SessionProxy.EtItemRow = itemRow;


            refreshvalues(ManuRow,
                           itemRow,
                           ARItemDataSet);

            ARItemDataSet.Dispose();
            tabItemDet.ActiveTabIndex = 1;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "refreshUpadatePanel();", true);
        }

        protected void btnUpDtRefresh_Click(object sender, EventArgs e)
        {
            DataSet ARItemDataSet = SessionProxy.EtARItemDataSet;
            DataRow ManuRow = SessionProxy.EtManuRow;
            DataRow itemRow = SessionProxy.EtItemRow;  

            refreshvalues(ManuRow,
                           itemRow,
                           ARItemDataSet);

            ARItemDataSet.Dispose(); 
        }

        private decimal RoundInt(decimal amt)
        {
            string ActPadval = "";
            Int32 IntAmt = (Int32)amt;
            decimal ActAmt = amt - IntAmt;
            ActPadval = Convert.ToString(ActAmt).PadRight(12,'0');
            decimal MidAmt = 0;
            if (ActPadval.IndexOf('.') >=0)
                MidAmt = Convert.ToDecimal(ActPadval.Substring(ActPadval.IndexOf('.'), SessionProxy.DutyPerUnitDec+ 1));
            return IntAmt + MidAmt;
        }

        protected void txtdefPrevAmt_TextChanged(object sender, EventArgs e)
        {
            NumericTextBox numBox = ((NumericTextBox)sender);
            GridViewRow row = ((GridViewRow)numBox.NamingContainer);
            callFromGrdPrevDuty(row.RowIndex);
        }

        protected void txtPrevBillQty_TextChanged(object sender, EventArgs e)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataSet ARItemDataSet = null;

            try
            {
                DataRow itemRow = SessionProxy.EtItemRow;
                DataRow ManuRow = SessionProxy.EtManuRow;
                ARItemDataSet = SessionProxy.EtARItemDataSet;

                itemRow["BillAssAmt"] = ((numFunction.toDecimal(itemRow["billqty"]) *
                                        numFunction.toDecimal(itemRow["u_asseamt"]))
                                        / numFunction.toDecimal(itemRow["qty"]));

                txtManAsseVal.Text = Convert.ToString(itemRow["BillAssAmt"]);

                string mDefAmtexpr = "";
                decimal mdefPer, manuDefamt, exAmt = 0;

                foreach (DataRow tax3Row in ARItemDataSet.Tables["taxvw3"].Rows)
                {
                    exAmt = 0;
                    mDefAmtexpr = Convert.ToString(tax3Row["amtexpr"]).Trim();
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".BILLQTY");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("U_ASSEAMT", "BILLASSAMT");
                    foreach (DataRow tax3VwRow in ARItemDataSet.Tables["taxvw3"].Rows)
                    {
                        mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax3VwRow["fld_nm"]).Trim(),
                                        Convert.ToString(tax3VwRow["fld_bill"]).Trim());
                    }

                    mdefPer = numFunction.toDecimal(tax3Row["def_pert"]);
                    if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                    {
                        if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                            DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                            {
                                exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * mdefPer) / 100);
                            manuDefamt = exAmt;
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }

                        tax3Row["def_amt"] = exAmt;

                        if (bitFunction.toBoolean(tax3Row["round_off"]) == true)
                        {
                            tax3Row["def_amt"] = Math.Round(numFunction.toDecimal(tax3Row["def_amt"]), 0);
                        }

                        ManuRow[Convert.ToString(tax3Row["fld_manu"]).Trim()] = manuDefamt;
                    }
                }
                ARItemDataSet.Tables["taxvw3"].AcceptChanges();

                SessionProxy.EtARItemDataSet = ARItemDataSet;
                SessionProxy.EtManuRow = ManuRow;
                SessionProxy.EtItemRow = itemRow;

                grdPrevDet.DataSource = ARItemDataSet.Tables["taxvw3"];
                grdBind(grdPrevDet);

                refreshvalues(ManuRow,
                     itemRow,
                     ARItemDataSet);

            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                ScriptManager1.SetFocus(txtManuQty);
            }
            finally
            {
                ARItemDataSet.Dispose();
            }
        }


        protected void txtPrevBillAss_TextChanged(object sender, EventArgs e)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataSet ARItemDataSet = null;

            try
            {
                DataRow itemRow = SessionProxy.EtItemRow;
                DataRow ManuRow = SessionProxy.EtManuRow;
                ARItemDataSet = SessionProxy.EtARItemDataSet;

                string mDefAmtexpr = "";
                decimal mdefPer, manuDefamt, exAmt = 0;

                foreach (DataRow tax3Row in ARItemDataSet.Tables["taxvw3"].Rows)
                {
                    exAmt = 0;
                    mDefAmtexpr = Convert.ToString(tax3Row["amtexpr"]).Trim();
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("ITEM_VW.", "MANU_DET_VW.");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace(".QTY", ".BILLQTY");
                    mDefAmtexpr = mDefAmtexpr.ToUpper().Replace("U_ASSEAMT", "BILLASSAMT");
                    foreach (DataRow tax3VwRow in ARItemDataSet.Tables["taxvw3"].Rows)
                    {
                        mDefAmtexpr = mDefAmtexpr.Replace(Convert.ToString(tax3VwRow["fld_nm"]).Trim(),
                                        Convert.ToString(tax3VwRow["fld_bill"]).Trim());
                    }

                    mdefPer = numFunction.toDecimal(tax3Row["def_pert"]);
                    if (mDefAmtexpr.Trim() != "" && mdefPer > 0)
                    {
                        if (mDefAmtexpr.Trim().IndexOf('.') >= 0)
                        {
                            string DataTableName, DataFieldName = "";
                            DataTableName = mDefAmtexpr.Trim().Substring(0, mDefAmtexpr.Trim().IndexOf("."));
                            DataFieldName = mDefAmtexpr.Trim().Substring(mDefAmtexpr.Trim().IndexOf(".") + 1, (mDefAmtexpr.Length - mDefAmtexpr.Trim().IndexOf(".")) - 1);

                            if (DataTableName.ToString().Trim().ToUpper() == "MANU_DET_VW")
                            {
                                exAmt = numFunction.toDecimal(ManuRow[DataFieldName]);
                            }
                            else
                            {
                                if (DataTableName.ToString().Trim().ToUpper() == "ITEM_VW")
                                {
                                    exAmt = numFunction.toDecimal(itemRow[DataFieldName]);
                                }
                                else
                                {
                                    throw new Exception("Other than Main_vw or Item_vw table name found in Amount Expression.");
                                }
                            }

                            exAmt = (((exAmt) * mdefPer) / 100);
                            manuDefamt = exAmt;
                        }
                        else
                        {
                            throw new Exception("Amount Expression is not proper in dcmast");
                        }

                        tax3Row["def_amt"] = exAmt;

                        if (bitFunction.toBoolean(tax3Row["round_off"]) == true)
                        {
                            tax3Row["def_amt"] = Math.Round(numFunction.toDecimal(tax3Row["def_amt"]), 0);
                        }

                        ManuRow[Convert.ToString(tax3Row["fld_bill"]).Trim()] = manuDefamt;
                    }
                }
                ARItemDataSet.Tables["taxvw3"].AcceptChanges();

                SessionProxy.EtARItemDataSet = ARItemDataSet;
                SessionProxy.EtManuRow = ManuRow;
                SessionProxy.EtItemRow = itemRow;

                grdPrevDet.DataSource = ARItemDataSet.Tables["taxvw3"];
                grdBind(grdPrevDet);

                refreshvalues(ManuRow,
                     itemRow,
                     ARItemDataSet);

            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                ARItemDataSet.Dispose();
                ScriptManager1.SetFocus(txtManuQty);
            }
            finally
            {
                ARItemDataSet.Dispose();
            }

        }

    }
}
