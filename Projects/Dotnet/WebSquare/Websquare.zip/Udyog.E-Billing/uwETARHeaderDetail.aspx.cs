using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Business.Logic.Layer;
using Data.Acess.Layer;    

namespace Udyog.E.Billing
{
    public partial class uwETARHeaderDetail : BasePage 
    {
        private string SqlStr;
       
        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }
        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }
        private string pcvType;
        public string PcvType
        {
            get { return pcvType; }
            set { pcvType = value; }
        }
        private string beHave;
        public string BeHave
        {
            get { return beHave; }
            set { beHave = value; }
        }
        private string vchkprod;
        public string Vchkprod
        {
            get { return vchkprod; }
            set { vchkprod = value; }
        }
        private string entryTbl;
        public string EntryTbl
        {
            get { return entryTbl; }
            set { entryTbl = value; }
        }

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private SqlConnection connHandle;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == true)
            {
                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                PcvType = Convert.ToString(Request.QueryString["pcvType"]);
                BeHave = Convert.ToString(Request.QueryString["beHave"]);
                Vchkprod = Convert.ToString(Request.QueryString["vChkProd"]);
                EntryTbl = Convert.ToString(Request.QueryString["entryTbl"]);
                return;
            }

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
            PcvType = Convert.ToString(Request.QueryString["pcvType"]);
            BeHave = Convert.ToString(Request.QueryString["beHave"]);
            Vchkprod = Convert.ToString(Request.QueryString["vChkProd"]);
            EntryTbl = Convert.ToString(Request.QueryString["entryTbl"]);

            DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;
            DataTable main_vw = DsETHeaderDetail.Tables["main_vw"];
            DataTable lcode_vw = DsETHeaderDetail.Tables["lcode_vw"];
            DataTable item_vw = DsETHeaderDetail.Tables["item_vw"];
            DataTable manu_det_vw = DsETHeaderDetail.Tables["manu_det_vw"]; 

                 
            //fillDropdownList();

            numericFunction numFunction = new numericFunction();
            if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) == 0)
            {
                main_vw.Rows[0]["cons_id"] = numFunction.toInt32(main_vw.Rows[0]["ac_id"]);
                main_vw.Rows[0]["scons_id"] = numFunction.toInt32(main_vw.Rows[0]["sac_id"]);
                main_vw.AcceptChanges();  
            }
            getDateFormat GetDateFormat = new getDateFormat();
            txtBillDate.Text = GetDateFormat.dateformatBR(Convert.ToString(main_vw.Rows[0]["u_pinvdt"]));
            txtBillNo.Text = Convert.ToString(main_vw.Rows[0]["u_pinvno"]);

            SqlParameter[] spParam = new SqlParameter[2];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@acId";
            spParam[0].SqlDbType = SqlDbType.Int;
            spParam[0].Value = numFunction.toInt32(main_vw.Rows[0]["cons_id"]);

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@AcName";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = "";

            SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_Acc_validation",
                                            spParam,ref connHandle);
            if (Dr.HasRows == true)
            {
                while (Dr.Read())
                {
                    txtConsigner.Text = Convert.ToString(Dr["ac_name"]);   
                }
            }
            Dr.Close();
            Dr.Dispose();
            DataAcess.Connclose(connHandle); 

            SessionProxy.DsETHeaderDetail = DsETHeaderDetail;
            DsETHeaderDetail.Dispose(); 
            //Session["main_vw"] = main_vw;
            //Session["lcode_vw"] = lcode_vw;
            //Session["item_vw"] = item_vw;
            //Session["manu_det_vw"] = manu_det_vw;


            if (txtConsigner.Text != "")
                txtConsigner_TextChanged(sender, e);

            main_vw.Dispose();
            lcode_vw.Dispose();
            item_vw.Dispose();
            manu_det_vw.Dispose();

             

        }

        //protected void fillDropdownList()
        //{
        //    DataTable lcode_vw = (DataTable)Session["lcode_vw"];
        //    vouFillDropdownList fillDrops = new vouFillDropdownList();
        //    fillDrops.fillDropDownList(dropConsigner, "--Select Consigner--", "ac_id", "ac_name",
        //                    "PARTY", PcvType, BeHave, lcode_vw, "ac_name,ac_id", 0, Vchkprod);
        //}

        protected void txtConsigner_TextChanged(object sender, EventArgs e)
        {
            DataTable main_vw = null;
            DataTable item_vw = null;
            DataTable shipto_vw = null;
            DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;  
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            try
            {

                main_vw = DsETHeaderDetail.Tables["main_vw"];
                item_vw = DsETHeaderDetail.Tables["item_vw"];

                numericFunction numFunction = new numericFunction();
                if (txtConsigner.Text.Trim() == "")
                {
                    main_vw.Rows[0]["cons_id"] = 0;
                    main_vw.Rows[0]["scons_id"] = 0;
                    main_vw.AcceptChanges();
                    return;
                }
                else
                {
                    string sqlStr = "";
                    SqlDataReader Dr;
                    int acId = 0;
                    sqlStr = " select Top 1 Ac_id from ac_mast where ac_name ='" + txtConsigner.Text.ToString().Trim() + "'";
                    Dr = DataAcess.ExecuteDataReader(sqlStr,ref connHandle);
                    if (Dr.HasRows == false)
                    {
                        Dr.Close();
                        Dr.Dispose();
                        DataAcess.Connclose(connHandle); 
                        throw new Exception("Consigner name not found in master");
                    }
                    else
                    {
                        while (Dr.Read())
                        {
                            acId = numFunction.toInt32(Dr["ac_id"]);
                        }
                    }
                    Dr.Close();
                    Dr.Dispose();
                    DataAcess.Connclose(connHandle); 
                    main_vw.Rows[0]["cons_id"] = acId;
                }

                string sqlcond = "";
                if (Convert.ToString(main_vw.Rows[0]["ettype"]).Trim() != "" &&
                    item_vw.Rows.Count > 0)
                    sqlcond = " upper(a.vend_type) in('" + Convert.ToString(main_vw.Rows[0]["ettype"]).Trim() + "') ";
                else
                    sqlcond = " upper(a.vend_type) in('MANUFACTURER','IMPORTER','DEPOT','SUPPLIER') ";

                GetLocationDetails LocationDetails = new GetLocationDetails();
                shipto_vw = new DataTable();
                shipto_vw = LocationDetails.ListLocationDetails("scons_id", "a.location_id,a.eccno"
                                    , 0, txtConsigner.Text.Trim(), sqlcond, true, shipto_vw);

                if (shipto_vw.Rows.Count > 1)
                {
                    dropLocation.DataSource = shipto_vw;
                    dropLocation.DataTextField = "location_id";
                    dropLocation.DataValueField = "shipto_id";
                    dropLocation.DataBind();
                    dropLocation.Items.Insert(0, "--Select Location--");
                    dropLocation.Enabled = true;
                    //trShiptoLocation.Visible = true;
                    dropLocation.Focus();
                }
                else
                {
                    if (shipto_vw.Rows.Count == 1)
                    {
                        main_vw.Rows[0]["scons_id"] = numFunction.toInt32(shipto_vw.Rows[0]["shipto_id"]);
                        main_vw.AcceptChanges();
                    }
                    else
                    {
                        if (shipto_vw.Rows.Count == 0)
                        {
                            if (dropLocation.SelectedIndex != -1)
                                dropLocation.SelectedIndex = 0;

                            dropLocation.Enabled = false;
                            //trShiptoLocation.Visible = false;
                            main_vw.Rows[0]["scons_id"] = 0;
                            main_vw.AcceptChanges();
                        }

                    }
                }
                SessionProxy.DsETHeaderDetail = DsETHeaderDetail;
            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                ScriptManager1.SetFocus(txtConsigner);
            }
            finally
            {
                DsETHeaderDetail.Dispose();
            }

            main_vw.Dispose();
            item_vw.Dispose();
            if (shipto_vw != null)
                shipto_vw.Dispose();
            DataAcess.Connclose(connHandle);

        }

        protected void dropLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropLocation.SelectedIndex == 0)
                return;

            numericFunction numFunction = new numericFunction();
            DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;  
            DataTable main_vw = DsETHeaderDetail.Tables["main_vw"]; 

            main_vw.Rows[0]["scons_id"] = numFunction.toInt32(dropLocation.SelectedValue);
            main_vw.AcceptChanges();
            SessionProxy.DsETHeaderDetail = DsETHeaderDetail;
            DsETHeaderDetail.Dispose();
            main_vw.Dispose(); 
            txtBillNo.Focus(); 
        }

        protected void btnDone_Click(object sender, EventArgs e)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            try
            {
                numericFunction numFunction = new numericFunction();
                DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;  
                DataTable main_vw = DsETHeaderDetail.Tables["main_vw"]; 
                if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) != 0)
                    Validation();

                DsETHeaderDetail.Dispose(); 
                main_vw.Dispose();
                DataAcess.Connclose(connHandle);  
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "doneDialog();", true);
                return; 

            }
            catch (Exception Ex)
            {
                lblError.Visible = true;
                lblError.Text = Ex.Message.Trim();   
            }
            
            DataAcess.Connclose(connHandle);  
        }

        protected void Validation()
        {
            numericFunction numFunction = new numericFunction();
            getDateFormat DateFormat = new getDateFormat();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;  
            DataTable main_vw = DsETHeaderDetail.Tables["main_vw"];
            DataTable item_vw = DsETHeaderDetail.Tables["item_vw"];
            DataTable manu_det_vw = DsETHeaderDetail.Tables["manu_det_vw"];
            DataSet Dsvalid = new DataSet();

            try
            {
                if (txtBillNo.Text.Trim() == "")
                    throw new Exception("Bill no. cannot be blank");

                if (txtBillDate.Text.Trim() == "")
                    throw new Exception("Bill Data cannot be blank");
                else
                {
                    if (DateFormat.TodateTime(txtBillDate.Text) > DateFormat.TodateTime(main_vw.Rows[0]["date"]))
                        throw new Exception("Bill date should not be more than Transaction date");
                }

                SqlParameter[] spParam = new SqlParameter[7];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@pcvtype";
                spParam[0].SqlDbType = SqlDbType.VarChar;
                spParam[0].Value = Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim();

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@entryTbl";
                spParam[1].SqlDbType = SqlDbType.VarChar;
                spParam[1].Value = entryTbl.Trim();

                spParam[2] = new SqlParameter();
                spParam[2].ParameterName = "@billno";
                spParam[2].SqlDbType = SqlDbType.VarChar;
                spParam[2].Value = txtBillNo.Text.Trim();

                spParam[3] = new SqlParameter();
                spParam[3].ParameterName = "@lyn";
                spParam[3].SqlDbType = SqlDbType.VarChar;
                spParam[3].Value = Convert.ToString(main_vw.Rows[0]["l_yn"]).Trim();

                spParam[4] = new SqlParameter();
                spParam[4].ParameterName = "@acid";
                spParam[4].SqlDbType = SqlDbType.Int;
                spParam[4].Value = numFunction.toInt32(main_vw.Rows[0]["ac_id"]);

                spParam[5] = new SqlParameter();
                spParam[5].ParameterName = "@consId";
                spParam[5].SqlDbType = SqlDbType.Int;
                spParam[5].Value = numFunction.toInt32(main_vw.Rows[0]["cons_id"]);

                spParam[6] = new SqlParameter();
                spParam[6].ParameterName = "@sconsId";
                spParam[6].SqlDbType = SqlDbType.Int;
                spParam[6].Value = numFunction.toInt32(main_vw.Rows[0]["scons_id"]);

                ArrayList dblist = new ArrayList();
                dblist.Add("Isbill");
                if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) != 0)
                {
                    dblist.Add("acMast");
                    dblist.Add("VendType");
                }

                Dsvalid = DataAcess.ExecuteDataset(Dsvalid,
                                   "sp_ent_web_ETARHeaderDetail_validation",
                                               spParam, dblist,connHandle);

                if (Dsvalid.Tables["Isbill"].Rows.Count != 0)
                {
                    throw new Exception("Bill no. already exist. please re-enter");
                }

                if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) != 0)
                {
                    if (Dsvalid.Tables["acMast"].Rows.Count == 0)
                    {
                        throw new Exception("Consigner not found in master");
                    }


                    //string sqlcond = "";
                    //if (Convert.ToString(main_vw.Rows[0]["ettype"]).Trim() != "" &&
                    //    item_vw.Rows.Count > 0)
                    //    sqlcond = " upper(a.vend_type) in('" + Convert.ToString(main_vw.Rows[0]["ettype"]).Trim() + "') "; 
                    //else
                    //    sqlcond = " upper(a.vend_type) in('MANUFACTURER','IMPORTER','DEPOT','SUPPLIER') ";

                    //GetLocationDetails LocationDetails = new GetLocationDetails();
                    //DataTable shipto_vw = new DataTable();
                    //shipto_vw = LocationDetails.ListLocationDetails("scons_id", "a.location_id,a.eccno"
                    //                    , 0, dropConsigner.SelectedItem.Text.Trim(), sqlcond, true, shipto_vw);

                    //if (shipto_vw.Rows.Count == 0)
                    //{
                    //    shipto_vw.Dispose();
                    //    throw new Exception("Consigner location details not found in master"); 
                    //}

                    string eccNo = "";
                    string ettype = "";
                    if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) != 0)
                    {
                        if (Dsvalid.Tables["VendType"].Rows.Count > 0)
                        {
                            foreach (DataRow sConsRow in Dsvalid.Tables["VendType"].Rows)
                            {
                                eccNo = Convert.ToString(sConsRow["eccno"]).Trim();
                                ettype = Convert.ToString(sConsRow["Vend_Type"]).Trim();
                            }
                        }
                        else
                        {
                            throw new Exception("Consigner location details not found in master");
                        }
                    }

                    //if (numFunction.toInt32(main_vw.Rows[0]["scons_id"]) == 0)
                    //    SqlStr = "Select Vend_Type,Eccno From Ac_mast Where Ac_id = " +
                    //              numFunction.toInt32(main_vw.Rows[0]["cons_id"]);
                    //else
                    //    SqlStr = "Select Vend_Type,Eccno From Shipto Where Ac_id = " +
                    //              numFunction.toInt32(main_vw.Rows[0]["cons_id"]) +
                    //              " And Shipto_id = " + numFunction.toInt32(main_vw.Rows[0]["scons_id"]);

                    //dr = DataAcess.ExecuteDataReader(SqlStr);
                    //isFoundRows = false;

                    //if (dr.HasRows == true)
                    //{
                    //    isFoundRows = true;
                    //    while (dr.Read())
                    //    {
                    //        eccNo = Convert.ToString(dr["eccno"]).Trim();
                    //        ettype = Convert.ToString(dr["Vend_Type"]).Trim();
                    //    }
                    //}

                    ////dr.Close();
                    ////dr.Dispose();

                    //if (isFoundRows == false)
                    //    throw new Exception("Consigner location details not found in master");


                    if (Convert.ToString(main_vw.Rows[0]["rule"]).Trim().ToUpper() == "EXCISE"
                        && eccNo.Trim() == "")
                        throw new Exception("ECC no. cannot be empty");

                        main_vw.Rows[0]["ettype"] = ettype;

                    if (ettype.Trim().ToUpper() == "MANUFACTURER" ||
                        ettype.Trim().ToUpper() == "IMPORTER")
                    {
                        foreach (DataRow manuDetRow in manu_det_vw.Rows)
                        {
                            manuDetRow["manuAc_id"] = numFunction.toInt32(main_vw.Rows[0]["cons_id"]);
                            manuDetRow["ManuSAc_id"] = numFunction.toInt32(main_vw.Rows[0]["SCons_id"]);
                            manuDetRow["manubill"] = Convert.ToString(main_vw.Rows[0]["u_pinvno"]);
                            manuDetRow["manudate"] = DateFormat.TodateTime(main_vw.Rows[0]["u_pinvdt"]);
                            manuDetRow.AcceptChanges();
                        }
                    }
                }
                main_vw.AcceptChanges();
                manu_det_vw.AcceptChanges();
                SessionProxy.DsETHeaderDetail = DsETHeaderDetail;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                DsETHeaderDetail.Dispose();
                main_vw.Dispose();
                item_vw.Dispose();
                manu_det_vw.Dispose();
                Dsvalid.Dispose(); 
                
            }


        }

       
    }
}
