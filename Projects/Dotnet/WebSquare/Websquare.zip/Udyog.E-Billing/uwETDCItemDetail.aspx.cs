using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Business.Logic.Layer;
using Controls;

namespace Udyog.E.Billing
{
    public partial class uwETDCItemDetail : System.Web.UI.Page
    {
        private int tex_exe;
        public int Tex_exe
        {
            get { return tex_exe; }
            set { tex_exe = value; }
        }

        private bool et_flag;
        public bool Et_flag
        {
            get { return et_flag; }
            set { et_flag = value; }
        }

        //private string[,] tex_ExAr;
        //public string[,] Tex_ExAr
        //{
        //    get { return tex_ExAr; }
        //    set { tex_ExAr = value; }
        //}

        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();
        SqlConnection connHandle;

        private string sqlstr;
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable ToShow;
            boolFunction bitFunction;
            if (IsPostBack == true)
            {
                bitFunction = new boolFunction();
                Et_flag = bitFunction.toBoolean(SessionProxy.DsETItemDetail.Tables["manufact"].Rows[0]["et_flag"]);
                ToShow = SessionProxy.ToShow; 
                Tex_exe = Convert.ToInt32(Request.QueryString["Tex_exe"]);
                grdGenerate(Tex_exe,
                        SessionProxy.Tex_ExAr);
                gridBind(ToShow);
                ToShow.Dispose();
                return;
            }


            Tex_exe = Convert.ToInt32(Request.QueryString["Tex_exe"]);

            ToShow = SessionProxy.ToShow;
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable CoAdditional = DsETItemDetail.Tables["manufact"];
            DataTable main_vw = DsETItemDetail.Tables["main_vw"];


            bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();

            Et_flag = bitFunction.toBoolean(CoAdditional.Rows[0]["et_flag"]);

            foreach (DataRow ToShowRow in ToShow.Rows)
            {
                if (DBNull.Value.Equals(ToShowRow["Supploc"]) == true) 
                    ToShowRow["Supploc"] = "";

                if (DBNull.Value.Equals(ToShowRow["Manuloc"]) == true) 
                    ToShowRow["ManuLoc"] = "";
            }

            grdGenerate(Tex_exe,
                    SessionProxy.Tex_ExAr);

            fillDropDownList(ToShow);

            gridBind(ToShow);
 
            CheckInit(ref ToShow,
                    ref main_vw,
                    CoAdditional);

            SessionProxy.ToShow = ToShow;
            DsETItemDetail.Dispose(); 
            CoAdditional.Dispose();
            main_vw.Dispose();
            ToShow.Dispose(); 
        }

        protected void CheckInit(ref DataTable ToShow,
                    ref DataTable main_vw,
                    DataTable CoAdditional)
        {
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();

            if (bitFunction.toBoolean(CoAdditional.Rows[0]["et_flag"]) == true)
            {
                txtConsignee.Enabled = false;
                txtManufact.Enabled = false;
                dropWareHouse.Enabled = false;
                return;
            }

            DataTable BuyerNames = ToShow.DefaultView.ToTable(true,
                    new string[] { "suppname", "suppac_id", "supploc", "suppsac_id" });

            if (BuyerNames.Rows.Count == 1)
            {
                txtConsignee.Text = Convert.ToString(BuyerNames.Rows[0]["suppname"]);
                if (Convert.ToString(BuyerNames.Rows[0]["suppLoc"]) != "")
                    dropBuyerLocation.SelectedValue = Convert.ToString(BuyerNames.Rows[0]["suppLoc"]);
                txtConsignee.Enabled = false;
                main_vw.Rows[0]["suppac_id"] = numFunction.toInt32(BuyerNames.Rows[0]["suppac_id"]);
                main_vw.Rows[0]["suppsac_id"] = numFunction.toInt32(BuyerNames.Rows[0]["suppsac_id"]);
                main_vw.AcceptChanges();
            }

            DataTable ManuNames = ToShow.DefaultView.ToTable(true,
                    new string[] { "ManuName", "Manuac_id", "manuloc", "manusac_id" });

            if (ManuNames.Rows.Count == 1)
            {
                txtManufact.Text = Convert.ToString(ManuNames.Rows[0]["ManuName"]);
                if (Convert.ToString(ManuNames.Rows[0]["Manuloc"]).Trim() !="")
                    dropManuLocation.SelectedValue = Convert.ToString(ManuNames.Rows[0]["Manuloc"]);  

                //hiddManuLoc.Value = Convert.ToString(BuyerNames.Rows[0]["Manuloc"]); 
                txtManufact.Enabled = false;
                main_vw.Rows[0]["manuac_id"] = numFunction.toInt32(ManuNames.Rows[0]["manuac_id"]);
                main_vw.Rows[0]["manusac_id"] = numFunction.toInt32(ManuNames.Rows[0]["manusac_id"]);
                main_vw.AcceptChanges();
            }

            DataTable Warehouses = ToShow.DefaultView.ToTable(true,
                    new string[] { "Ware_Nm"});

            if (Warehouses.Rows.Count == 1)
            {
                dropWareHouse.SelectedValue = Convert.ToString(Warehouses.Rows[0]["Ware_Nm"]);
                dropWareHouse.Enabled = false;
            }

            if (!String.IsNullOrEmpty(DBPropsSession.VarETGoDown))
            {
                dropWareHouse.SelectedValue = Convert.ToString(DBPropsSession.VarETGoDown);
            }

            ToShow = Filter(ToShow);  
            BuyerNames.Dispose();
            ManuNames.Dispose();
            Warehouses.Dispose(); 
        }

        protected void fillDropDownList(DataTable ToShow)
        {
            DataTable ToShowView = new DataTable();
            ToShowView = ToShow.DefaultView.ToTable(true,
                        new string[] {"Suppname","Supploc"});
            //dropConsignee.DataSource = ToShowView;
            //dropConsignee.DataTextField = "suppname";
            //dropConsignee.DataValueField = "suppname";
            //dropConsignee.DataBind();
            //dropConsignee.Items.Insert(0,"--Select Buyer--");

            foreach (DataRow ToShowRow in ToShowView.Rows)
            {
                if (Convert.ToString(ToShowRow["Supploc"]).Trim() != "")
                {
                    dropBuyerLocation.Items.Add(Convert.ToString(ToShowRow["SuppLoc"]).Trim());
                }
            }
            dropBuyerLocation.Items.Insert(0, "--Select Buyer Location--");  

            if (ToShowView.Rows.Count > 1)
            {
                dropBuyerLocation.Enabled = true;
            }
            else
            {
                if (ToShowView.Rows.Count <= 1)
                {
                    dropBuyerLocation.Enabled = false; 
                }
            }
             
            ToShowView = new DataTable();
            ToShowView = ToShow.DefaultView.ToTable(true,
                        new string[] { "ManuName", "Manuloc" });
            //dropManufact.DataSource = ToShowView;
            //dropManufact.DataTextField = "ManuName";
            //dropManufact.DataValueField = "ManuName";
            //dropManufact.DataBind();
            //dropManufact.Items.Insert(0, "--Select Manufacturer--");

            foreach (DataRow ToShowRow in ToShowView.Rows)
            {
                if (Convert.ToString(ToShowRow["Manuloc"]).Trim() != "")
                {
                    dropManuLocation.Items.Add(Convert.ToString(ToShowRow["Manuloc"]).Trim());
                }
            }
            dropManuLocation.Items.Insert(0, "--Select Manufacturer Location--");

            if (ToShowView.Rows.Count > 1)
            {
                dropManuLocation.Enabled = true;
            }
            else
            {
                if (ToShowView.Rows.Count <= 1)
                {
                    dropManuLocation.Enabled = false;
                }
            }

            ToShowView = new DataTable();
            ToShowView = ToShow.DefaultView.ToTable(true,
                        new string[] { "Ware_Nm"});
            dropWareHouse.DataSource = ToShowView;
            dropWareHouse.DataTextField = "Ware_Nm";
            dropWareHouse.DataValueField = "Ware_Nm";
            dropWareHouse.DataBind();
            dropWareHouse.Items.Insert(0, "--Select Warehouse--");

            ToShowView.Dispose();
        }

        protected void grdGenerate(int Tex_exe,
            string[,] Tex_ExAr)
        {
            grdItemDet.Columns.Clear();
  
            TemplateField templateField = new TemplateField();
            DynamicTemplate dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            BoundField bndField = null;

            CheckBox chkBox = new CheckBox();
            chkBox.ID = "ChkSelect";

            dynamictemplateItem.AddControl(chkBox, "Checked", "ToCheck");
            templateField.ItemTemplate = dynamictemplateItem;
            grdItemDet.Columns.Add(templateField);
            grdItemDet.Columns[0].HeaderText = "Select";
            grdItemDet.Columns[0].AccessibleHeaderText = "Select";

            // RG Page - Column Order 2
            bndField = grdBoundField(ref bndField,
                            "rgPage",
                            "RG Page",
                            HorizontalAlign.Left,"STRING");
            
            grdItemDet.Columns.Add(bndField);  

            // Bill No. - Column Order 3
            bndField = grdBoundField(ref bndField,
                            "u_pinvno",
                            "Bill No.",
                            HorizontalAlign.Left,"STRING");
            grdItemDet.Columns.Add(bndField);  

            // Date - Column Order 4
            grdBoundField(ref bndField,
                            "u_pinvdt",
                            "Date",
                            HorizontalAlign.Left,"DATETIME");
            grdItemDet.Columns.Add(bndField);

            // BalQty - Column Order 5
            grdBoundField(ref bndField,
                            "balqty",
                            "Bal. Qty",
                            HorizontalAlign.Right,"DECIMAL");
            grdItemDet.Columns.Add(bndField);

            // Adj.Qty - Column Order 6
            dynamictemplateItem = new DynamicTemplate(ListItemType.Item);
            templateField = new TemplateField();
            NumericTextBox numBox = new NumericTextBox();
            numBox.ID = "numAlloQty";
            numBox.CssClass = "form_textfield3";
            numBox.Enabled = false;
            numBox.Width = Unit.Pixel(85);
            numBox.AutoPostBack = true; 
            


            dynamictemplateItem.AddControl(numBox,"Text", "AlloQty");
            templateField.ItemTemplate = dynamictemplateItem;
            grdItemDet.Columns.Add(templateField);
            grdItemDet.Columns[5].HeaderText = "Adjust Qty.";
            grdItemDet.Columns[5].AccessibleHeaderText = "AdjQty";

            // Excise - Column Order 7
            grdBoundField(ref bndField,
                            "excbal",
                            "Excise",
                            HorizontalAlign.Right,"DECIMAL");
            grdItemDet.Columns.Add(bndField);

            for (int mTex_Exs = 1; mTex_Exs < Tex_exe; mTex_Exs++)
            {
                if (Tex_ExAr[mTex_Exs, 2].Trim().ToUpper().IndexOf("EXCBAL") == -1)
                {
                    grdBoundField(ref bndField,
                                    Tex_ExAr[mTex_Exs, 2].Trim(),
                                    Tex_ExAr[mTex_Exs, 0].Trim(),
                                    HorizontalAlign.Right,"DECIMAL");
                    grdItemDet.Columns.Add(bndField);
                }
            }

            // MT Duty
            grdBoundField(ref bndField,
                            "mtduty",
                            "MT. Duty",
                            HorizontalAlign.Right,"DECIMAL");
            grdItemDet.Columns.Add(bndField);

            // MT Duty
            grdBoundField(ref bndField,
                            "entry_ty",
                            "Type",
                            HorizontalAlign.Left,"STRING");
            grdItemDet.Columns.Add(bndField);

            

        }

        protected void gridBind(DataTable ToShow)
        {
            grdItemDet.DataSource = ToShow;
            grdItemDet.DataBind();
        }

        protected BoundField grdBoundField(ref BoundField bndField,
                    string dataField,
                    string headerText,
                    HorizontalAlign HorzAlign,
                    string DataType)
        {
            bndField = new BoundField();
            bndField.DataField = dataField.ToString().Trim();
            bndField.HeaderText = headerText.ToString().Trim(); 
            bndField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
            bndField.ItemStyle.HorizontalAlign = HorzAlign;
            if (DataType.Trim().ToUpper() == "DECIMAL")
            {
                bndField.DataFormatString = "{0:F2}";
                bndField.HtmlEncode = false;
            }
            else
            {
                if (DataType.Trim().ToUpper() == "DATETIME")
                {
                    bndField.DataFormatString = "{0:dd/M/yyyy}";
                    bndField.HtmlEncode = false;
                }
            }

            return bndField; 
        }

        protected DataTable Filter(DataTable ToShow)
        {
            if (Et_flag == true)
                return null;

            DataView ToshowView = ToShow.DefaultView;

            string filterExp = "";
            if (txtConsignee.Text.Trim() != "")
                filterExp = " suppname ='" + txtConsignee.Text.ToString().Trim() + "'" +
                            " and supploc ='" + 
                            (dropBuyerLocation.SelectedIndex != 0 ?
                            dropBuyerLocation.SelectedItem.ToString().Trim() : "") + "'"; 
                            

            if (txtManufact.Text.Trim() !="")
                filterExp = filterExp + (filterExp != "" ? " And " : "") + 
                    " manuname ='" + txtManufact.Text.ToString().Trim() + "'" +
                            " and manuloc ='" + 
                            ( dropManuLocation.SelectedIndex != 0 ?
                            dropManuLocation.SelectedItem.ToString().Trim() : "") + "'"; 

            if (dropWareHouse.SelectedIndex !=0)
                filterExp = filterExp + (filterExp != "" ? " And " : "") + 
                            " ware_nm ='" + dropWareHouse.SelectedItem.ToString().Trim() +"'";

            ToshowView.RowFilter = filterExp;
            ToShow = ToshowView.ToTable();

            grdItemDet.DataSource = ToShow;
            grdItemDet.DataBind();

            ToshowView.Dispose();
            ToShow.Dispose();
            UpdatePanel1.Update();  
            return ToShow;
        }
        
        protected void chkBox_CheckedChanged(object sender, EventArgs e)
        {
            bool isAllTrue = false;
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable ToShow = SessionProxy.ToShow;
            DataTable main_vw = DsETItemDetail.Tables["main_vw"];
            DataTable litemall_vw = DsETItemDetail.Tables["litemall_vw"]; 
            DataTable CoAdditional = DsETItemDetail.Tables["CoAdditional"];

            CheckBox chkBox = ((CheckBox)sender);
            GridViewRow row = ((GridViewRow)chkBox.NamingContainer);

            if (chkBox.Checked == true)
            {
                try
                {
                    CheckValid(Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[0]),
                        Convert.ToInt32(grdItemDet.DataKeys[row.RowIndex].Values[1]),
                        Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[2]), true,
                        ref ToShow,
                        ref main_vw,
                        ref CoAdditional,
                        ref litemall_vw);


                }
                catch (Exception Ex)
                {
                    chkBox.Checked = false;
                    throw Ex;
                }

            }
            else
            {
                if (chkBox.Checked == false)
                {
                    CheckValid(Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[0]),
                        Convert.ToInt32(grdItemDet.DataKeys[row.RowIndex].Values[1]),
                        Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[2]), false,
                        ref ToShow,
                        ref main_vw,
                        ref CoAdditional,
                        ref litemall_vw);

                }
            }

            gridBind(ToShow);
            NumericTextBox numBox = (NumericTextBox)grdItemDet.Rows[row.RowIndex].FindControl("numAlloQty");
            if (chkBox.Checked == true)
            {
                numBox.Enabled = true;
            }
            else
            {
                numBox.Enabled = false;
            }
            ToShow.AcceptChanges();
            main_vw.AcceptChanges();

            SessionProxy.ToShow = ToShow;
            SessionProxy.DsETItemDetail = DsETItemDetail;


            DsETItemDetail.Dispose(); 
            ToShow.Dispose();
            main_vw.Dispose();
            //CoAdditional.Dispose();

        }

        protected void CheckValid(string entry_ty,
                    int tran_cd,
                    string itSerial,
                    bool isTrue,
                    ref DataTable ToShow,
                    ref DataTable main_vw,
                    ref DataTable CoAdditional,
                    ref DataTable litemall_vw)
        {
            numericFunction numFunction = new numericFunction();
            stringFunction strFunction = new stringFunction();

            DataRow ToShowSelectedRow = ToShow.Select("entry_ty ='" + entry_ty +
                                    "' and tran_cd = " + tran_cd +
                                    " and itserial ='" + itSerial + "'")[0];
            if (isTrue == true)
            {
                ToShowSelectedRow["alloQty"] = numFunction.toDecimal(ToShowSelectedRow["balqty"]);
                ToShowSelectedRow["ToCheck"] = true;
            }
            else
            {
                ToShowSelectedRow["alloQty"] = 0;
                ToShowSelectedRow["ToCheck"] = false;
            }

            decimal SumQty =  (decimal)ToShow.Compute("Sum(alloqty)", "");
            SumQty = numFunction.toDecimal(SumQty, 2); 
            lblTotqty.Text = "Total Adjust Qty : " +Convert.ToString(SumQty);

            if (SumQty > 0)
            {
                if (txtConsignee.Text == "")
                {
                    txtConsignee.Text = Convert.ToString(ToShowSelectedRow["suppname"]).Trim();
                    if (Convert.ToString(ToShowSelectedRow["supploc"]).Trim() != "")
                        dropBuyerLocation.SelectedValue = Convert.ToString(ToShowSelectedRow["supploc"]).Trim();
                    else
                        dropBuyerLocation.SelectedIndex = 0;
                        

                    //hiddSuppLoc.Value = Convert.ToString(ToShowSelectedRow["supploc"]).Trim();

                    main_vw.Rows[0]["suppac_id"] = numFunction.toInt32(ToShowSelectedRow["suppac_id"]);
                    main_vw.Rows[0]["suppsac_id"] = numFunction.toInt32(ToShowSelectedRow["suppsac_id"]);

                    ToShow = Filter(ToShow);
                }

                if (txtManufact.Text == "")
                {
                    txtManufact.Text = Convert.ToString(ToShowSelectedRow["manuname"]).Trim();
                    if (Convert.ToString(ToShowSelectedRow["manuloc"]).Trim() != "")
                        dropManuLocation.SelectedValue = Convert.ToString(ToShowSelectedRow["manuloc"]).Trim();
                    else
                        dropBuyerLocation.SelectedIndex = 0;
                     

                    //hiddManuLoc.Value = Convert.ToString(ToShowSelectedRow["manuloc"]).Trim();

                    main_vw.Rows[0]["manuac_id"] = numFunction.toInt32(ToShowSelectedRow["manuac_id"]);
                    main_vw.Rows[0]["manusac_id"] = numFunction.toInt32(ToShowSelectedRow["manusac_id"]);

                    ToShow = Filter(ToShow);
                }

                if (dropWareHouse.SelectedIndex == 0)
                {
                    dropWareHouse.SelectedValue = Convert.ToString(ToShowSelectedRow["ware_nm"]).Trim();
                    ToShow = Filter(ToShow);
                }

                txtConsignee.Enabled = false;
                txtManufact.Enabled = false;
                dropWareHouse.Enabled = false;
            }
            else
            {
                txtConsignee.Enabled = true;
                txtManufact.Enabled = true;
                dropWareHouse.Enabled = true;
                txtConsignee.Text = "";
                txtManufact.Text = "";
                dropWareHouse.SelectedIndex = 0;
                main_vw.Rows[0]["suppac_id"] = 0;
                main_vw.Rows[0]["suppsac_id"] = 0;
                main_vw.Rows[0]["manuac_id"] = 0;
                main_vw.Rows[0]["manusac_id"] = 0;
                CheckInit(ref ToShow, ref main_vw, CoAdditional); 
            }

            main_vw.AcceptChanges();
            string[,] Tex_ExAr = SessionProxy.Tex_ExAr;
            string fmFields = "";
            string fmFieldsa = "";
            for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
            {
                fmFieldsa = Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                fmFields = fmFields.Trim() + (fmFields.Trim() == "" ? "" : ",") +
                        fmFieldsa.Trim();
                fmFieldsa = Tex_ExAr[tex_exs, 5].Trim().Replace("ITEM_VW", "");
                fmFields = fmFields.Trim() + (fmFields.Trim() == "" ? "" : ",") +
                        fmFieldsa.Trim();
            }

            SqlParameter[] spParam = new SqlParameter[4];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@fmFields";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = fmFields; 

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@entryTy";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(ToShowSelectedRow["entry_ty"]).Trim();

            spParam[2] = new SqlParameter();
            spParam[2].ParameterName = "@tranCd";
            spParam[2].SqlDbType = SqlDbType.Int;
            spParam[2].Value = numFunction.toInt32(ToShowSelectedRow["tran_cd"]);

            spParam[3] = new SqlParameter();
            spParam[3].ParameterName = "@itSerial";
            spParam[3].SqlDbType = SqlDbType.VarChar;
            spParam[3].Value = Convert.ToString(ToShowSelectedRow["itserial"]).Trim();

            //sqlstr = "Select CompId,Tran_Cd,Entry_ty,Date,Itserial,It_code," +
            //         " Tariff,Ware_nm,Rgpage,Mtduty,Qty," + fmFields +
            //         " From TradeItem " +
            //         " Where entry_ty='" + Convert.ToString(ToShowSelectedRow["entry_ty"]).Trim() +"'" +
            //         " and tran_cd= " + numFunction.toInt32(ToShowSelectedRow["tran_cd"]) +
            //         " and itserial ='" + Convert.ToString(ToShowSelectedRow["itserial"]).Trim() +"'";

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            ArrayList dblist = new ArrayList();
            dblist.Add("TradeItem");
            DataSet ChkDs = new DataSet();
            ChkDs = DataAcess.ExecuteDataset(ChkDs,
                   "sp_ent_web_ETDCItemDetail_BalanceQtyUpdate",
                               spParam, dblist,connHandle);
            DataAcess.Connclose(connHandle);
            //DataTable TradeItem_Vw = DataAcess.ExecuteDataTable(sqlstr, "_tradeItemVw");
            DataTable TradeItem_Vw = ChkDs.Tables["TradeItem"]; 

            if (isTrue == true)
            {
                string pageNo = genPageNo(TradeItem_Vw.Rows[0],litemall_vw);
                ToShowSelectedRow["sentno"] = numFunction.toInt32(strFunction.Left(pageNo, 10));
                ToShowSelectedRow["spageno"] = pageNo.Substring(9, pageNo.Length - 11);
            }
            else
            {
                ToShowSelectedRow["sentno"] = 0;
                ToShowSelectedRow["spageno"] = "";
            }

            main_vw.AcceptChanges(); 
            ToShowSelectedRow.AcceptChanges();
            
            ChkDs.Dispose();
            TradeItem_Vw.Dispose(); 
        }

        protected void BalanceQtyUpdate(DataTable ToShow,
                    ref DataTable litemall_vw,
                    DataTable main_vw,
                    ref DataRow itemRow)
        {

            DataSet DsETItemDetail  = SessionProxy.DsETItemDetail;
            DataTable company = DsETItemDetail.Tables["company"];

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            string[,] Tex_ExAr = SessionProxy.Tex_ExAr;

            decimal updtQty = 0;

            foreach (DataRow ToShowRow in ToShow.Select("ToCheck = 1"))
            {
                updtQty = numFunction.toDecimal(ToShowRow["alloqty"]) > numFunction.toDecimal(ToShowRow["balqty"])
                    ? 0 : numFunction.toDecimal(ToShowRow["alloqty"]);
                    

                string fmFields = "";   
                string fmFieldsa = "";
                for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                {
                    fmFieldsa = Tex_ExAr[tex_exs, 1].Trim().Replace("ITEM_VW", "");
                    fmFields = fmFields.Trim() + (fmFields.Trim() == "" ? "" : ",") +
                            fmFieldsa.Trim();
                    fmFieldsa = Tex_ExAr[tex_exs, 5].Trim().Replace("ITEM_VW", "");
                    fmFields = fmFields.Trim() + (fmFields.Trim() == "" ? "" : ",") +
                            fmFieldsa.Trim();
                    fmFieldsa = Tex_ExAr[tex_exs, 6].Trim().Replace("ITEM_VW", "");
                    fmFields = fmFields.Trim() + (fmFields.Trim() == "" ? "" : ",") +
                            fmFieldsa.Trim();

                }

                SqlParameter[] spParam = new SqlParameter[4];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@fmFields";
                spParam[0].SqlDbType = SqlDbType.VarChar;
                spParam[0].Value = fmFields;

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@entryTy";
                spParam[1].SqlDbType = SqlDbType.VarChar;
                spParam[1].Value = Convert.ToString(ToShowRow["entry_ty"]).Trim();

                spParam[2] = new SqlParameter();
                spParam[2].ParameterName = "@tranCd";
                spParam[2].SqlDbType = SqlDbType.Int;
                spParam[2].Value = numFunction.toInt32(ToShowRow["tran_cd"]);

                spParam[3] = new SqlParameter();
                spParam[3].ParameterName = "@itSerial";
                spParam[3].SqlDbType = SqlDbType.VarChar;
                spParam[3].Value = Convert.ToString(ToShowRow["itserial"]).Trim();

                //sqlstr = "Select CompId,Tran_Cd,Entry_ty,Date,Itserial,It_code," +
                //         " Tariff,Ware_nm,Rgpage,Mtduty,Qty," + fmFields +
                //         " From TradeItem " +
                //         " Where entry_ty='" + Convert.ToString(ToShowRow["entry_ty"]).Trim() +"'" +
                //         " and tran_cd= " + numFunction.toInt32(ToShowRow["tran_cd"]) +
                //         " and itserial ='" + Convert.ToString(ToShowRow["itserial"]).Trim() +"'";

                DataTier DataAcess = new DataTier();
                DataAcess.DataBaseName = SessionProxy.DbName;

                ArrayList dblist = new ArrayList();
                dblist.Add("TradeItem");
                DataSet BalDS = new DataSet();
                BalDS = DataAcess.ExecuteDataset(BalDS,
                       "sp_ent_web_ETDCItemDetail_BalanceQtyUpdate",
                                   spParam, dblist,connHandle);
                DataAcess.Connclose(connHandle);
                DataTable TradeItem_Vw = BalDS.Tables["TradeItem"]; 
                //DataTier DataAcess = new DataTier();
                //DataTable TradeItem_Vw = DataAcess.ExecuteDataTable(sqlstr, "_tradeItemVw");

                DataRow litemallRow = litemall_vw.NewRow();
                litemallRow["entry_ty"] = Convert.ToString(main_vw.Rows[0]["entry_ty"]).Trim();
                litemallRow["tran_cd"] = numFunction.toInt32(main_vw.Rows[0]["tran_cd"]);
                litemallRow["itserial"] = Convert.ToString(itemRow["itserial"]).Trim();
                litemallRow["rgPage"] = Convert.ToString(TradeItem_Vw.Rows[0]["rgpage"]).Trim();
                litemallRow["sentno"] = numFunction.toInt32(ToShowRow["sentno"]);
                litemallRow["spageno"] = Convert.ToString(ToShowRow["spageno"]).Trim();
                litemallRow["pentry_ty"] = Convert.ToString(TradeItem_Vw.Rows[0]["entry_ty"]).Trim();
                litemallRow["ptran_cd"] = numFunction.toInt32(TradeItem_Vw.Rows[0]["tran_cd"]);
                litemallRow["pitserial"] = Convert.ToString(TradeItem_Vw.Rows[0]["itserial"]).Trim();
                litemallRow["ware_nm"] = dropWareHouse.SelectedItem.ToString().Trim();
                litemallRow["qty"] = numFunction.toDecimal(ToShowRow["alloqty"]);

                for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                {
                    if (updtQty > 0)
                    {
                        //litemallRow[Tex_ExAr[tex_exs, 1]]
                        //        = (updtQty * (numFunction.toDecimal(TradeItem_Vw.Rows[0][Tex_ExAr[tex_exs, 6]]) /
                        //                     numFunction.toDecimal(TradeItem_Vw.Rows[0]["qty"])));

                        litemallRow[Tex_ExAr[tex_exs, 1]]
                                    = (updtQty * (numFunction.toDecimal(TradeItem_Vw.Rows[0][Tex_ExAr[tex_exs, 6]])));
                    }
                    else
                    {
                        litemallRow[Tex_ExAr[tex_exs, 1]] = numFunction.toDecimal(ToShowRow[Tex_ExAr[tex_exs,2]]);    
                    }
                }

                litemallRow["compid"] = numFunction.toInt32(company.Rows[0]["compid"]);
                litemall_vw.Rows.Add(litemallRow);
                litemall_vw.AcceptChanges();
  
                for (int tex_exs = 0; tex_exs < Tex_exe; tex_exs++)
                {
                    itemRow[Tex_ExAr[tex_exs, 5]] = numFunction.toDecimal(TradeItem_Vw.Rows[0][Tex_ExAr[tex_exs, 5].ToString().Trim()]);
                    itemRow[Tex_ExAr[tex_exs, 1]] = numFunction.toDecimal(itemRow[Tex_ExAr[tex_exs, 1].ToString().Trim()]) +
                                                    numFunction.toDecimal(litemallRow[Tex_ExAr[tex_exs, 1].ToString().Trim()]);
                }
                BalDS.Dispose();
                TradeItem_Vw.Dispose(); 
             }
             DsETItemDetail.Dispose();
             company.Dispose();
        }

        protected string genPageNo(DataRow TradeItemRow,DataTable litemall_vw)
        {
            int vsentno = 0;
            string vspageno = "";
            int stoaddinlist = 1;
            int stot = 5;
            int sbrk = 130;
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            numericFunction numFunction = new numericFunction();
            //sqlstr = "Select sentno,spageno From LitemAll where rgpage='" + Convert.ToString(TradeItemRow["rgpage"]).Trim() + "'" +
            //         " and ware_nm ='" + Convert.ToString(TradeItemRow["ware_nm"]).Trim() + "'";

            SqlParameter[] spParam = new SqlParameter[2];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@rgpage";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = Convert.ToString(TradeItemRow["rgpage"]).Trim();

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@wareNm";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(TradeItemRow["ware_nm"]).Trim();

            ArrayList dblist = new ArrayList();
            dblist.Add("GenSPageNo");

            DataSet PgDs = new DataSet();
            PgDs = DataAcess.ExecuteDataset(PgDs,
                   "sp_ent_web_ETDCItemDetail_genPageNo",
                               spParam, dblist,connHandle);
            DataAcess.Connclose(connHandle);  

            DataTable GenSpageNo = PgDs.Tables["GenSPageNo"];
            string filtExp = "rgPage = '" + Convert.ToString(TradeItemRow["rgPage"]).Trim() + "' " +
                             " and ware_nm ='" + Convert.ToString(TradeItemRow["ware_nm"]).Trim() + "' ";
                   
            foreach(DataRow litemallRow in litemall_vw.Select(filtExp))
            {
                DataRow NewSPageNoRow = GenSpageNo.NewRow();
                NewSPageNoRow["sentno"] = numFunction.toInt32(litemallRow["sentno"]);
                NewSPageNoRow["spageno"] = Convert.ToString(litemallRow["spageno"]);
            }

            if (GenSpageNo.Rows.Count <= 0)
            {
                vsentno = 1;
                vspageno = Convert.ToString(TradeItemRow["rgPage"]);
                return Convert.ToString(vsentno).Trim().PadLeft(10) + vspageno; 
            }

            DataRow itemRow = SessionProxy.EtItemRow;

            DataTable pageNo = new DataTable();
            DataColumn pageNoCol = new DataColumn();
            pageNoCol.ColumnName = "spageno";
            pageNoCol.DataType = Type.GetType("System.String");
            pageNo.Columns.Add(pageNoCol);

            pageNoCol = new DataColumn();
            pageNoCol.ColumnName = "sentno";
            pageNoCol.DataType = Type.GetType("System.Int32");
            pageNo.Columns.Add(pageNoCol);
   
            int vctrzz = 0;
            int snow,snow1 = 0;
            DataRow PageNoRow = null;
            foreach (DataRow GenSpageNoRow in GenSpageNo.Rows)
            {
                vctrzz = vctrzz + 1;
                if (numFunction.toInt32(GenSpageNoRow["sentno"]) != vctrzz)
                {
                    for (int i = vctrzz; i <= numFunction.toInt32(GenSpageNoRow["sentno"]); i++)
                    {
                        PageNoRow = pageNo.NewRow();
                        if (i <= stot)
                        {
                            PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]);
                        }
                        else
                        {
                            if (i <= sbrk + stot)
                            {
                                snow = i - 1;
                                PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                                       "-" + Convert.ToString(64 + snow / stot);
                            }
                            else
                            {
                                snow = i - (stot + 1);
    				            snow1 = i - ((snow / sbrk) * sbrk);
                                PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                                       "-" + Convert.ToString(64 + snow / stot) +
                                                       Convert.ToString((snow1 % stot == 0 ? 63 : 64) +
                                                       (snow1 / stot));
                            }
                        }
                        PageNoRow["sentno"] = Convert.ToString(i).Trim();
                        pageNo.Rows.Add(PageNoRow);   
                        pageNo.AcceptChanges(); 
                    }
                    vctrzz = numFunction.toInt32(GenSpageNoRow["sentno"]);
                }

                vsentno = numFunction.toInt32(GenSpageNoRow["sentno"]);
                vspageno = Convert.ToString(GenSpageNoRow["spageno"]); 
            }

            if (pageNo.Rows.Count > 0)
            {
                vctrzz = vctrzz + 1;
                PageNoRow = pageNo.NewRow();
                if (vctrzz <= stot)
                {
                    PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]);
                }
                else
                {
                    if (vctrzz <= sbrk + stot)
                    {
                        snow = vctrzz - 1;
                        PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot);
                    }
                    else
                    {
                        snow = vctrzz - (stot + 1);
                        snow1 = vctrzz - ((snow / sbrk) * sbrk);
                        PageNoRow["spageno"] = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot) +
                                               Convert.ToString((snow1% stot == 0 ? 63 : 64) +
                                               (snow1 / stot));
                    }
                }

                PageNoRow["sentno"] = Convert.ToString(vctrzz).Trim();
                pageNo.Rows.Add(PageNoRow);
                pageNo.AcceptChanges();
                grdPageno.DataSource = pageNo;
                grdPageno.DataBind();
                pnlPagePop.Visible = true;
                
            }
            else
            {
                vctrzz = vctrzz + 1;
                if (vctrzz <= stot)
                {
                    vspageno = Convert.ToString(TradeItemRow["rgpage"]);
                }
                else
                {
                    if (vctrzz <= sbrk + stot)
                    {
                        snow = vctrzz - 1;
                        vspageno = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot);
                    }
                    else
                    {
                        snow = vctrzz - (stot + 1);
                        snow1 = vctrzz - ((snow / sbrk) * sbrk);
                        vspageno = Convert.ToString(TradeItemRow["rgpage"]) +
                                               "-" + Convert.ToString(64 + snow / stot) +
                                               Convert.ToString((snow1 % stot == 0 ? 63 : 64) +
                                               (snow1 / stot));
                    }
                }
                vsentno = vctrzz;
                pnlPagePop.Visible = false;
                
            }
            pageNo.Dispose();
            GenSpageNo.Dispose(); 
            PgDs.Dispose(); 
            return Convert.ToString(vsentno).Trim().PadLeft(10) + vspageno; 
        }

        protected void txtConsignee_TextChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            try
            {
                SqlParameter[] spParam = new SqlParameter[2];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@acId";
                spParam[0].SqlDbType = SqlDbType.Int;
                spParam[0].Value = 0;

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@AcName";
                spParam[1].SqlDbType = SqlDbType.VarChar;
                spParam[1].Value = txtConsignee.Text.ToString().Trim();

                SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_Acc_validation",
                                                spParam,ref connHandle);

                if (Dr.HasRows == false)
                {
                    Dr.Close();
                    Dr.Dispose();
                    DataAcess.Connclose(connHandle);
                    throw new Exception("Consignee name not found in master");
                }
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle);

                //sqlstr = " select Top 1 Ac_id from ac_mast where ac_name ='" + txtConsignee.Text.ToString().Trim() + "'";
                //DataTable dtAc = DataAcess.ExecuteDataTable(sqlstr, "_ss");

                //if (dtAc.Rows.Count == 0)
                //{
                //    dtAc.Dispose();
                //    DataAcess.Connclose();
                //    throw new Exception("Consignee name not found in master");
                //}
                //dtAc.Dispose();
                ToShow = Filter(ToShow);
                SessionProxy.ToShow = ToShow;
            }
            catch (Exception Ex)
            {
                lblError.Text = Ex.Message.Trim();
            }
            finally
            {
               ToShow.Dispose();
            }
        }

        protected void dropBuyerLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow;
            ToShow.Dispose();
        }

        protected void txtManufact_TextChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            try
            {
                SqlParameter[] spParam = new SqlParameter[2];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@acId";
                spParam[0].SqlDbType = SqlDbType.Int;
                spParam[0].Value = 0;

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@AcName";
                spParam[1].SqlDbType = SqlDbType.VarChar;
                spParam[1].Value = txtManufact.Text.ToString().Trim();

                SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_Acc_validation",
                                                spParam,ref connHandle);

                if (Dr.HasRows == false)
                {
                    Dr.Close();
                    Dr.Dispose();
                    DataAcess.Connclose(connHandle);
                    throw new Exception("Manufacture name not found in master");
                }
                Dr.Close();
                Dr.Dispose();
                DataAcess.Connclose(connHandle);

                //sqlstr = " select Top 1 Ac_id from ac_mast where ac_name ='" + txtManufact.Text.ToString().Trim() + "'";
                //DataTable dtAc = DataAcess.ExecuteDataTable(sqlstr, "_ss");
                //if (dtAc.Rows.Count == 0)
                //{
                //    dtAc.Dispose();
                //    DataAcess.Connclose();
                //    throw new Exception("Consignee name not found in master");
                //}
                //dtAc.Dispose();
                ToShow = Filter(ToShow);
                SessionProxy.ToShow = ToShow;
            }
            catch (Exception Ex)
            {
                lblError.Text = Ex.Message.Trim();
            }
            finally
            {
                DataAcess.Connclose(connHandle);
                ToShow.Dispose();   
            }
        }

        protected void dropManuLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow; 
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow;
            ToShow.Dispose();
        }

        protected void dropWareHouse_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            ToShow = Filter(ToShow);
            SessionProxy.ToShow = ToShow;
            ToShow.Dispose();
        }

        protected void btnProceed_Click(object sender, EventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            decimal totQty = (decimal)ToShow.Compute("Sum(alloqty)", "");
            ToShow.Dispose();
            numericFunction numFunction = new numericFunction();
            string retMess = "Total Allocated Quantity is : " +
                Convert.ToString(numFunction.toDecimal(totQty,2)).Trim() +
                ",Want to proceed ?";

            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ConfirmMessWithPostBack('" + retMess.Trim() + "','" + btnGOProceed.ClientID + "');", true);

        }

        protected void btnGOProceed_Click(object sender, EventArgs e)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            DataTable ToShow = SessionProxy.ToShow;
            DataRow itemRow = SessionProxy.EtItemRow;
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable litemall_vw = DsETItemDetail.Tables["litemall_vw"];
            DataTable main_vw = DsETItemDetail.Tables["main_vw"];

            decimal totQty = (decimal)ToShow.Compute("Sum(alloqty)", "");
            itemRow["qty"] = totQty;
            BalanceQtyUpdate(ToShow,
                            ref litemall_vw,
                            main_vw, ref itemRow);

            SessionProxy.DsETItemDetail = DsETItemDetail; 
            ToShow.Dispose(); 
            litemall_vw.Dispose();
            main_vw.Dispose();
            DsETItemDetail.Dispose(); 

            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "doneDialog();", true);
            return; 
        }

        protected void grdItemDet_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";

                CheckBox chkSelect = (CheckBox)e.Row.FindControl("chkSelect");
                chkSelect.AutoPostBack = true;
                chkSelect.CheckedChanged += new EventHandler(chkBox_CheckedChanged);

                NumericTextBox numBox = (NumericTextBox)e.Row.FindControl("numAlloQty");
                numBox.AutoPostBack = true; 
                numBox.TextChanged += new EventHandler(numBox_TextChanged); 
            }
        }

        protected void numBox_TextChanged(object sender, EventArgs e)
        {
            DataSet DsETItemDetail = SessionProxy.DsETItemDetail;
            DataTable ToShow = SessionProxy.ToShow;
            DataTable CoAdditional = DsETItemDetail.Tables["manufact"];
            DataTable main_vw = DsETItemDetail.Tables["main_vw"]; 

            numericFunction numFunction = new numericFunction();

            NumericTextBox numBox = ((NumericTextBox)sender);
            GridViewRow row = ((GridViewRow)numBox.NamingContainer);

            string entry_ty =  Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[0]);
            int trancd = Convert.ToInt32(grdItemDet.DataKeys[row.RowIndex].Values[1]);
            string itSerial = Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[2]);

            DataRow ToShowSelectedRow = ToShow.Select("entry_ty ='" + entry_ty +
                                 "' and tran_cd = " + trancd +
                                 " and itserial ='" + itSerial + "'")[0];

            if (numFunction.toDecimal(numBox.Text) > numFunction.toDecimal(ToShowSelectedRow["balqty"]))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('cannot allocate more than available Qty.');", true);
                return;
            }

            CheckBox chkBox = (CheckBox)grdItemDet.Rows[row.RowIndex].FindControl("ChkSelect");
            if (numFunction.toDecimal(numBox.Text) > 0)
            {
                chkBox.Checked = true;
            }
            else
                chkBox.Checked = false;

            ToShowSelectedRow["alloqty"] = numFunction.toDecimal(numBox.Text);
 
            decimal totQty = (decimal)ToShow.Compute("Sum(alloqty)", "");
            totQty = numFunction.toDecimal(totQty, 2); 
            lblTotqty.Text = "Total Adjusted Qty.:" + Convert.ToString(totQty);

            if (totQty > 0)
            {
                if (txtConsignee.Text.Trim() == "")
                {
                    txtConsignee.Text = Convert.ToString(ToShowSelectedRow["suppname"]).Trim();
                    if (Convert.ToString(ToShowSelectedRow["supploc"]).Trim() != "")
                        dropBuyerLocation.SelectedValue = Convert.ToString(ToShowSelectedRow["supploc"]).Trim();

                    main_vw.Rows[0]["suppac_id"] = numFunction.toInt32(ToShowSelectedRow["suppac_id"]);
                    main_vw.Rows[0]["suppsac_id"] = numFunction.toInt32(ToShowSelectedRow["suppsac_id"]);

                    ToShow = Filter(ToShow);
                }

                if (txtManufact.Text.Trim()  == "")
                {
                    txtManufact.Text = Convert.ToString(ToShowSelectedRow["manuname"]).Trim();
                    if (Convert.ToString(ToShowSelectedRow["manuloc"]).Trim() != "")
                        dropManuLocation.SelectedValue = Convert.ToString(ToShowSelectedRow["manuloc"]).Trim();

                    main_vw.Rows[0]["manuac_id"] = numFunction.toInt32(ToShowSelectedRow["manuac_id"]);
                    main_vw.Rows[0]["manusac_id"] = numFunction.toInt32(ToShowSelectedRow["manusac_id"]);

                    ToShow = Filter(ToShow);
                }

                if (dropWareHouse.SelectedIndex == 0)
                {
                    dropWareHouse.SelectedValue = Convert.ToString(ToShowSelectedRow["ware_nm"]).Trim();
                    ToShow = Filter(ToShow);
                }

                txtConsignee.Enabled = false;
                txtManufact.Enabled = false;
                dropWareHouse.Enabled = false;
            }
            else
            {
                txtConsignee.Enabled = true;
                txtManufact.Enabled = true;
                dropWareHouse.Enabled = true;
                CheckInit(ref ToShow, ref main_vw, CoAdditional);
            }

            main_vw.AcceptChanges();
            ToShow.AcceptChanges();

            numBox.Enabled = true;

            SessionProxy.ToShow = ToShow;
            SessionProxy.DsETItemDetail = DsETItemDetail;

            DsETItemDetail.Dispose();
            ToShow.Dispose();
            CoAdditional.Dispose();
            main_vw.Dispose();
        }

        protected void grdItemDet_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataTable ToShow = SessionProxy.ToShow;
            grdItemDet.PageIndex = e.NewPageIndex;
            gridBind(ToShow);
            ToShow.Dispose();
        }

        //protected void numBox_TextChanged(object sender, EventArgs e)
        //{
        //    string test = "";

        //    NumericTextBox numBox = ((NumericTextBox)sender);
        //    GridViewRow row = ((GridViewRow)numBox.NamingContainer);

        //    DataTable ToShow = SessionProxy.ToShow;
        //    DataRow ToShowSelectedRow = ToShow.Select("entry_ty ='" + Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[0]) +
        //                            "' and tran_cd = " + Convert.ToInt32(grdItemDet.DataKeys[row.RowIndex].Values[1]) +
        //                            " and itserial ='" + Convert.ToString(grdItemDet.DataKeys[row.RowIndex].Values[2]) + "'")[0];

        //    ToShowSelectedRow["alloQty"] = numFunction.toDecimal(numBox.Text);
        //    ToShow.AcceptChanges();
        //    SessionProxy.ToShow = ToShow;
        //}


    }
}
