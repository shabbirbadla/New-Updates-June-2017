using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Data.Acess.Layer;
using Business.Logic.Layer;


namespace Udyog.E.Billing
{
    public partial class UwControlCentre : System.Web.UI.Page
    {
        DataTier DataAccess;
        SqlConnection connHandle;

        private string SqlStr;
        protected void Page_Load(object sender, EventArgs e)
        {
            DataAccess = new DataTier();
             
            DataSet CntrlDataSet = new DataSet();
            if (IsPostBack == true)
            {
                CntrlDataSet = (DataSet)Session["CntrlDataSet"];
                return;
            }
            CntrlDataSet = new DataSet();
            lblTrType.Text = " Control Centre(General)";
            GetControls(ref CntrlDataSet);            
            EnableDisableControls(Page, false);            
            Session["CntrlDataSet"] = CntrlDataSet;
            CntrlDataSet.Dispose();
        }

        protected void GetControls(ref DataSet CntrlDataSet)
        {
            SqlStr = "select * from servicetax..co_mast";
            CntrlDataSet = DataAccess.ExecuteDataset(CntrlDataSet, SqlStr, "coMastView",connHandle);
            DataAccess.Connclose(connHandle);
            BindControls(CntrlDataSet.Tables["coMastView"].Rows[0]);

        }

        protected void BindControls(DataRow CCRow)
        {
            //General Info            
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            chkItemTotSales.Checked = bitFunction.toBoolean(CCRow["snet_op"]);
            chkItemTotPur.Checked = bitFunction.toBoolean(CCRow["pnet_op"]);
            chkRndItemGrsAmtSales.Checked = bitFunction.toBoolean(CCRow["sinet_op"]);
            chkRndItemGrsAmtPur.Checked = bitFunction.toBoolean(CCRow["pinet_op"]);
            chkRndGrsAmountSales.Checked = bitFunction.toBoolean(CCRow["sgro_op"]);
            chkRndGrsAmountPur.Checked = bitFunction.toBoolean(CCRow["pgro_op"]);
            chkRateOfItemSales.Checked = bitFunction.toBoolean(CCRow["srate_op"]);
            chkRateOfItemPur.Checked = bitFunction.toBoolean(CCRow["srate_op"]);
            txtGrplevNo.Text = Convert.ToString(CCRow["grp_lv"]);
            txtSalesRndOffAc.Text = Convert.ToString(CCRow["sac_round"]);
            txtPurRndOffAc.Text = Convert.ToString(CCRow["pac_round"]);
            
            string[] HDArr = Convert.ToString(CCRow["holi_day"]).Split(',');
            if (HDArr[0].ToString().Trim() == "Mn")
            {
                chkMndy.Checked = true;
            }
            if (HDArr[0].ToString().Trim() == "Tu")
            {
                chkTusdy.Checked = true;
            }
            if (HDArr[0].ToString().Trim() == "Wd")
            {
                chkWeddy.Checked = true;
            }
            if (HDArr[0].ToString().Trim() == "Th")
            {
                chkThsdy.Checked = true;
            }
            if (HDArr[0].ToString().Trim() == "Fr")
            {
                chkFrdy.Checked = true;
            }
            if (HDArr[0].ToString().Trim() == "Sat")
            {
                chksatdy.Checked = true;
            }
            if (HDArr[0].ToString().Trim() == "Su")
            {
                chkSndy.Checked = true;
            }

             
            //Accounts

            chkManPyAdjust.Checked = bitFunction.toBoolean(CCRow["allo_op"]);
            chkOnLnBalChk.Checked = bitFunction.toBoolean(CCRow["ac_bchk"]);
            chkAccWise.Checked = bitFunction.toBoolean(CCRow["acc_adj"]);

            //Inventory
            chkForItem.Checked = bitFunction.toBoolean(CCRow["it_bchk"]);
            chkAllowItem.Checked = bitFunction.toBoolean(CCRow["neg_itbal"]);
            txtdecPtQty.Text = Convert.ToString(CCRow["deci"]);
            txtDcPtRt.Text = Convert.ToString(CCRow["ratedeci"]);
            chkPartyPrclst.Checked = bitFunction.toBoolean(CCRow["it_rate"]);
            chkStkItems.Checked = bitFunction.toBoolean(CCRow["it_stock"]);
           
        }
        protected void txtSalesRndOffAc_TextChanged(object sender, EventArgs e)
        {
            SqlStr = "select * from ac_mast where ac_name like'%"
                   + txtSalesRndOffAc.Text.ToString().Trim() + "%'";
            //DataAccess = new DataTier();
            //DataAccess.DataBaseName = "NXIO";

            DataSet CntrlDataSet = (DataSet)Session["CntrlDataSet"];
            CntrlDataSet = DataAccess.ExecuteDataset(CntrlDataSet, SqlStr, "acmastView",connHandle);
            DataAccess.Connclose(connHandle);
 
            string oldacName = txtSalesRndOffAc.Text;
            DataRow CCRow = CntrlDataSet.Tables["acmastView"].Rows[0];
            CCRow = DataAccess.ExactScatterGatherRow(CntrlDataSet.Tables["acmastView"].Rows[0],
                       CCRow);

            CCRow.AcceptChanges();
            CntrlDataSet.Tables["acmastView"].AcceptChanges();
            txtSalesRndOffAc.Text = oldacName;
            Session["CntrlDataSet"] = CntrlDataSet;
            CntrlDataSet.Dispose();
        }

        protected void txtPurRndOffAc_TextChanged(object sender, EventArgs e)
        {
            SqlStr = "select * from ac_mast where ac_name like '%"
                    + txtPurRndOffAc.Text.ToString().Trim() + "%'";
            DataAccess = new DataTier();
            DataSet CntrlDataSet = (DataSet)Session["CntrlDataSet"];
            CntrlDataSet = DataAccess.ExecuteDataset(CntrlDataSet, SqlStr, "acmastView",connHandle);
            DataAccess.Connclose(connHandle);

            string oldacName = txtPurRndOffAc.Text;
            DataRow CCRow = CntrlDataSet.Tables["acmastView"].Rows[0];
            CCRow = DataAccess.ExactScatterGatherRow(CntrlDataSet.Tables["acmastView"].Rows[0],
                       CCRow);

            CCRow.AcceptChanges();
            CntrlDataSet.Tables["acmastView"].AcceptChanges();
            txtPurRndOffAc.Text = oldacName;
            Session["CntrlDataSet"] = CntrlDataSet;
            CntrlDataSet.Dispose();
        }
        
        protected void lnkBtnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("UwControlCentre.aspx");
            
        }
        protected void BindSave(DataRow CCRow,ref DataSet CntrlDataSet)
        {
            string HStr = "";
            DataAccess = new DataTier();
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            CCRow["deci"] = numFunction.toDecimal(txtdecPtQty.Text);
            CCRow["ac_bchk"] = bitFunction.toBoolean(chkOnLnBalChk.Checked);
            CCRow["it_bchk"] = bitFunction.toBoolean(chkForItem.Checked);
            CCRow["grp_lv"] = Convert.ToString(txtGrplevNo.Text);
            if (chkMndy.Checked == true)
            {
                HStr += (HStr.Trim() != "" ? ",Mn" : "Mn");
                CCRow["holi_day"] = Convert.ToString(HStr);

            }
            if (chkTusdy.Checked == true)
            {
                HStr += (HStr.Trim() != "" ? ",Tu" : "Tu");
                CCRow["holi_day"] = Convert.ToString(HStr);

            }
            if (chkWeddy.Checked == true)
            {
                HStr += (HStr.Trim() != "" ? ",Wd" : "Wd");
                CCRow["holi_day"] = Convert.ToString(HStr);
            }
            if (chkThsdy.Checked == true)
            {
                HStr += (HStr.Trim() != "" ? ",Th" : "Th");
                CCRow["holi_day"] = Convert.ToString(HStr);

            }
            if (chkFrdy.Checked == true)
            {
                HStr += (HStr.Trim() != "" ? ",Fr" : "Fr");
                CCRow["holi_day"] = Convert.ToString(HStr);

            }
            if (chksatdy.Checked == true)
            {
                HStr += (HStr.Trim() != "" ? ",Sat" : "Sat");
                CCRow["holi_day"] = Convert.ToString(HStr);

            }
            if (chkSndy.Checked == true)
            {
                HStr += (HStr.Trim() != "" ? ",Su" : "Su");
                CCRow["holi_day"] = Convert.ToString(HStr);

            }
            CCRow["allo_op"] = bitFunction.toBoolean(chkManPyAdjust.Checked);
            CCRow["acc_adj"] = bitFunction.toBoolean(chkAccWise.Checked);
            CCRow["sgro_op"] = bitFunction.toBoolean(chkRndGrsAmountSales.Checked);
            CCRow["pgro_op"] = bitFunction.toBoolean(chkRndGrsAmountPur.Checked);
            CCRow["snet_op"] = bitFunction.toBoolean(chkItemTotSales.Checked);
            CCRow["pnet_op"] = bitFunction.toBoolean(chkItemTotPur.Checked);
            CCRow["srate_op"] = bitFunction.toBoolean(chkRateOfItemSales.Checked);
            CCRow["prate_op"] = bitFunction.toBoolean(chkRateOfItemPur.Checked);
            //extender
            CCRow["sac_round"] = txtSalesRndOffAc.Text.Trim();
            CCRow["pac_round"] = txtPurRndOffAc.Text.Trim();

            CCRow["neg_itbal"] = bitFunction.toBoolean(chkAllowItem.Checked);
            CCRow["it_stock"] = bitFunction.toBoolean(chkStkItems.Checked);
            CCRow["it_rate"] = bitFunction.toBoolean(chkPartyPrclst.Checked);
            CCRow["sinet_op"] = bitFunction.toBoolean(chkRndItemGrsAmtSales.Checked);
            CCRow["pinet_op"] = bitFunction.toBoolean(chkRndItemGrsAmtPur.Checked);
            CCRow["ratedeci"] = numFunction.toDecimal(txtDcPtRt.Text);
            CCRow.AcceptChanges();

        }
        protected void Save()
        {
            try
            {
                DataSet CntrlDataSet = (DataSet)Session["CntrlDataSet"];
                BindSave(CntrlDataSet.Tables["coMastView"].Rows[0], ref CntrlDataSet);
                DataAccess = new DataTier();
                
                SqlStr = DataAccess.GenUpdateString(CntrlDataSet.Tables["coMastView"], "servicetax..co_mast",
                                               new string[] { "compid" }, null, "", new string[] { "compid" });

                if (SqlStr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {

                        cmd.ExecuteNonQuery();

                        DataAccess.CommitTransaction(cmd.Transaction);
                        DataAccess.Connclose(connHandle);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        DataAccess.Connclose(connHandle);
                        throw Ex;
                    }
                }
                CntrlDataSet.Dispose();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
        private void EnableDisableControls(Control root, bool isflag)
        {
            miscFunctions miscFunc = new miscFunctions();
            miscFunc.EnableDisableControlsRecursive(root, isflag);
            miscFunc.Dispose();
            btnEdit.Enabled = true;                    
                       
        }
        

        protected void btnTopSave_Click(object sender, EventArgs e)
        {

            if (IsValid == true)
            {
                try
                {
                    Save(); // call Save Method
                    tblError.Visible = false;
                    EnableDisableControls(Page, false);
                    lnkBtnBack.Enabled = true;
                    btnBottomCancel.Enabled = true;
                    Response.Redirect("UwControlCentre.aspx?ShowStatus=false");
                }
                catch (Exception Ex)
                {
                    tblError.Visible = true;
                    lblErrorHeading.Text = "Please Check Error details below";
                    lblErrorDetails.Text = Ex.Message;
                }
            }
            

        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            EnableDisableControls(Page, true);
            btnEdit.Enabled = false;
        }
    }
}
