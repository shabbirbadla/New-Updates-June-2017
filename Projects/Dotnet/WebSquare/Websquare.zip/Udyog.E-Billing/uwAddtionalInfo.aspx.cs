using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Data.Acess.Layer;
using Business.Logic.Layer;

namespace Udyog.E.Billing
{
    public partial class uwAddtionalInfo : System.Web.UI.Page
    {
        //DataTier DataAccess;        
        //private static string infoGroup;

        private string SqlStr="";
        private SqlDataReader da;
        private SqlConnection connHandle;

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }

        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private string infoid;
        public string Infoid
        {
            get { return infoid; }
            set { infoid = value; }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet AddInfoDataSet;
            AddInfoDataSet = (DataSet)Session["AddInfoDataSet"];
            txtFieldName.Attributes.Add("onfocus", "javascript:return TextFieldDetail();");
            //ChkValidationfield.Attributes.Add("onclick", "javascript:return Checkdefault();");
            //ChkValidationfield.Attributes.Add("onfocus", "javascript:return Checkdefault();");        
            if (IsPostBack == true)
            {
                AddInfoDataSet = (DataSet)Session["AddInfoDataSet"];
                AddMode = Convert.ToBoolean(Request.QueryString["addmode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editmode"]);
                Infoid = Convert.ToString(Request.QueryString["infoId"]);

                return;
            }
                         
            AddMode = Convert.ToBoolean(Request.QueryString["addmode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editmode"]);
            Infoid = Convert.ToString(Request.QueryString["infoId"]);

            AddInfoDataSet = new DataSet();
            
            lblTrType.Text = "Addtional Information Master";
                       
            fillDropDown(ref AddInfoDataSet);

            FillList(ref AddInfoDataSet);
            if (AddMode == true)
            {
                addRec(ref AddInfoDataSet);
            }
            else
            {
                if (EditMode == true)
                {
                    editRec(Infoid, ref AddInfoDataSet);
                }
            }
           Session["AddInfoDataSet"] = AddInfoDataSet;
           AddInfoDataSet.Dispose();
}

        protected void addRec(ref DataSet AddInfoDataSet)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            boolFunction bitFunction = new boolFunction();
            SqlStr = "select * from lother where 1=2";
            DataTier DataAccess = new DataTier();
            DataAccess = new DataTier();
            AddInfoDataSet = DataAccess.ExecuteDataset(AddInfoDataSet, SqlStr, "AddinfoView",connHandle);
            DataAccess.Connclose(connHandle);
 
            DataRow AddInfoRow = AddInfoDataSet.Tables["AddinfoView"].NewRow();
            AddInfoRow["fld_wid"] = 0;
            AddInfoRow["fld_dec"] = 0;
            
            DataNullUpdate.NullUpdate(AddInfoRow);
            AddInfoDataSet.Tables["AddinfoView"].Rows.Add(AddInfoRow);
            AddInfoDataSet.Tables["AddinfoView"].AcceptChanges();

            if (RdBtnMain.SelectedValue == "M")
            {
                DropTransType.SelectedItem.Text = Convert.ToString(AddInfoRow["e_code"]).Trim();
            }
            else
            {
                if (RdBtnMain.SelectedValue == "T")
                {
                    DropTransType.SelectedValue = Convert.ToString(AddInfoRow["e_code"]).Trim();
                }
            }
            txtheadname.Text = Convert.ToString(AddInfoRow["head_nm"]);
            txtserialOrd.Text = Convert.ToString(AddInfoRow["serial"]);
            
            //field Details
            txtFieldName.Text = Convert.ToString(AddInfoRow["fld_nm"]).Trim();
            DropType.SelectedValue = Convert.ToString(AddInfoRow["data_ty"]).Trim();
            txtWidth.Text = Convert.ToString(AddInfoRow["fld_wid"]);
            txtdecimal.Text = Convert.ToString(AddInfoRow["fld_dec"]);

            //check box
            ChkDP.Checked = bitFunction.toBoolean(AddInfoRow["Inpickup"]);
            ChkDG.Checked = bitFunction.toBoolean(AddInfoRow["ingrid"]);


            //General details
            txtPopUp.Text  = Convert.ToString(AddInfoRow["filtcond"]).Trim();
            ChkInterUse.Checked = bitFunction.toBoolean(AddInfoRow["inter_use"]);
            ChkMadatory.Checked = bitFunction.toBoolean(AddInfoRow["mandatory"]);

            listValidation.SelectedValue = Convert.ToString(AddInfoRow["validity"]).Trim();
            TxtRemarks.Text = Convert.ToString(AddInfoRow["remarks"]);
            if (ChkDefault.Checked == true)
            {
                txtDefault.Enabled = true;
                txtDefault.Focus();
            }
            else
            {
                if (ChkInterUse.Checked == true)
                {
                    txtDefault.Enabled = false;
                }
                else
                {
                    if (ChkMadatory.Checked == true)
                    {
                        txtDefault.Enabled = false;
                    }
                }
            }
            ScriptManager1.SetFocus(RdBtnMain);
            //RdBtnMain.Focus();
        }
        
        protected void editRec(string infoId, ref DataSet AddInfoDataSet)
        {
            DataTier DataAccess = new DataTier();
            SqlStr = "select * from lother where e_code like '%"+ infoId + "%'";
            AddInfoDataSet = DataAccess.ExecuteDataset(AddInfoDataSet, SqlStr, "AddinfoView",connHandle);
            DataAccess.Connclose(connHandle);
            
            BindControls(AddInfoDataSet.Tables["AddinfoView"].Rows[0], true);
            if (EditMode == true)
            {
                txtheadname.Enabled = false;
            }
            
        }

        protected void BindControls(DataRow AddInfoRow, bool istrue)
        {
            numericFunction numfunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            
            ChkDefault.Checked = bitFunction.toBoolean(AddInfoRow["defa_fld"]);
            ChkInterUse.Checked = bitFunction.toBoolean(AddInfoRow["inter_use"]);
            ChkMadatory.Checked = bitFunction.toBoolean(AddInfoRow["mandatory"]);

            ChkDG.Checked = bitFunction.toBoolean(AddInfoRow["ingrid"]);
            ChkDP.Checked = bitFunction.toBoolean(AddInfoRow["Inpickup"]);

            if(RdBtnMain.SelectedValue == "M")
            {
                DropTransType.SelectedValue = Convert.ToString(AddInfoRow["code"]).ToString().Trim() ==""?
                    "--Select Trans Type--" : Convert.ToString(AddInfoRow["code"]).ToString().Trim();
            }
            else
            {
                if (RdBtnMain.SelectedValue == "T")
                {
                    DropTransType.SelectedValue = Convert.ToString(AddInfoRow["cd"]).ToString().Trim() == "" ?
                    "--Select Trans Type--" : Convert.ToString(AddInfoRow["cd"]).ToString().Trim();
                }
            }
            txtheadname.Text = Convert.ToString(AddInfoRow["head_nm"]).Trim();
            txtserialOrd.Text = Convert.ToString(numfunction.toInt32(AddInfoRow["serial"]));
            txtFieldName.Text = Convert.ToString(AddInfoRow["fld_nm"]).Trim();
            DropType.SelectedValue = Convert.ToString(AddInfoRow["data_ty"]).Trim() == "" ?
             "--Select Type--" : Convert.ToString(AddInfoRow["data_ty"]).Trim();
            txtWidth.Text = Convert.ToString(numfunction.toInt32(AddInfoRow["fld_wid"]));
            txtdecimal.Text = Convert.ToString(numfunction.toInt32(AddInfoRow["fld_dec"]));
            txtPopUp.Text = Convert.ToString(AddInfoRow["filtcond"]).Trim();
            if (RdBtnMain.SelectedValue == "M")
            {
                listValidation.Items[0].Value = Convert.ToString(AddInfoRow["validity"]).Trim();
            }
            else
            {
                if (RdBtnMain.SelectedValue == "T")
                {
                    listValidation.Items[0].Value = Convert.ToString(AddInfoRow["validity"]).Trim();
                }
            }
            TxtRemarks.Text = Convert.ToString(AddInfoRow["remarks"]).Trim();    

        }
        protected void FillList(ref DataSet AddInfoDataSet)
        {
            //DataAccess = new DataTier();
            //DataAccess.DataBaseName = "Nxio";
            DataTier DataAccess = new DataTier();
            if (RdBtnMain.SelectedValue == "M")
            {
                SqlStr = "select searchflds from mastcode where searchflds != ''";
                AddInfoDataSet = DataAccess.ExecuteDataset(AddInfoDataSet, SqlStr, "mastcodeView",connHandle);
                DataAccess.Connclose(connHandle);
                listValidation.DataSource = AddInfoDataSet.Tables["mastcodeView"];
                listValidation.DataTextField = "searchflds";
                listValidation.DataValueField = "searchflds";
                listValidation.DataBind();
            }
            else
            {
                if (RdBtnMain.SelectedValue == "T")
                {
                    SqlStr = "select it_fields from lcode where it_fields !=''";
                    AddInfoDataSet = DataAccess.ExecuteDataset(AddInfoDataSet, SqlStr, "lcodeView",connHandle);
                    DataAccess.Connclose(connHandle);

                    listValidation.DataSource = AddInfoDataSet.Tables["lcodeView"];
                    listValidation.DataTextField = "it_fields";
                    listValidation.DataValueField = "it_fields";
                    listValidation.DataBind();
                }
            }

            
        }
        protected void fillDropDown(ref DataSet AddInfoDataSet)
        {
            DataTier DataAccess = new DataTier();
            if (RdBtnMain.SelectedValue == "M")
            {
                SqlStr = "Select Name,code from Mastcode ";
                AddInfoDataSet = DataAccess.ExecuteDataset(AddInfoDataSet, SqlStr, "MastcodeView",connHandle);
                DataAccess.Connclose(connHandle);

                DropTransType.DataSource = AddInfoDataSet.Tables["MastcodeView"];
                DropTransType.DataTextField = "name";
                DropTransType.DataValueField = "code";
                DropTransType.DataBind();
                DropTransType.Items.Insert(0, "--Select TranType--");

            }
            else
            {
                if (RdBtnMain.SelectedValue == "T")
                {
                    RdBtnTranType.Enabled = true;
                    if (RdBtnTranType.SelectedValue == "TW")
                    {
                        ChkDP.Enabled = true;
                        ChkDG.Enabled = false;
                        SqlStr = "select code_nm,cd from lcode";
                        AddInfoDataSet = DataAccess.ExecuteDataset(AddInfoDataSet, SqlStr, "lcodeView",connHandle);
                        DataAccess.Connclose(connHandle);

                        DropTransType.DataSource = AddInfoDataSet.Tables["lcodeView"];
                        DropTransType.DataTextField = "code_nm";
                        DropTransType.DataValueField = "cd";
                        DropTransType.DataBind();
                        DropTransType.Items.Insert(0, "--Select TranType--");
                    }

                    else
                    {
                        if (RdBtnTranType.SelectedValue == "I")
                        {
                            ChkDP.Enabled = true;
                            ChkDG.Enabled = true;
                            SqlStr = "select code_nm,cd from lcode";
                            AddInfoDataSet = DataAccess.ExecuteDataset(AddInfoDataSet, SqlStr, "lcodeView",connHandle);
                            DataAccess.Connclose(connHandle);

                            DropTransType.DataSource = AddInfoDataSet.Tables["lcodeView"];
                            DropTransType.DataTextField = "code_nm";
                            DropTransType.DataValueField = "cd";
                            DropTransType.DataBind();
                            DropTransType.Items.Insert(0, "--Select TranType--");
                        }
                    }
                }
            }
        }


        protected void Save()
        {
            try
            {
                DataTier DataAccess = new DataTier();
                DataSet AddInfoDataSet = (DataSet)Session["AddInfoDataSet"];
                BindSave(AddInfoDataSet.Tables["AddinfoView"].Rows[0], AddInfoDataSet);
                numericFunction numFunction = new numericFunction();
                if (EditMode == true)
                {
                    SqlStr = DataAccess.GenUpdateString(AddInfoDataSet.Tables["AddinfoView"], "lother",
                        new string[] { "e_code" }, null, "", new string[] { "e_code" });
                }
                else
                {
                    if(AddMode== true)
                    {
                        SqlStr = DataAccess.GenInsertString(AddInfoDataSet.Tables["AddinfoView"].Rows[0], 
                            "lother", new string[] { "e_code" }, null);
                    }
                }
                if (SqlStr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {

                        cmd.ExecuteNonQuery();
                        DataAccess.CommitTransaction(cmd.Transaction);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        throw Ex;
                    }
                    finally
                    {
                        cmd.Dispose();
                        DataAccess.Connclose(connHandle);
                    }
                }
                AddInfoDataSet.Dispose();
            }
            catch (Exception EX)
            {
                throw EX;
            }
        }

        protected void BindSave(DataRow AddInfoRow, DataSet AddInfoDataSet)
        {
            //DataAccess = new DataTier();
            //DataAccess.DataBaseName = "nxio";
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataTier DataAccess = new DataTier();
            if (AddMode == true && EditMode == false)
            {
                if (RdBtnMain.SelectedValue == "M")
                {
                    SqlStr = "select * from mastcode where code='" + DropTransType.SelectedValue + "'";
                    DataAccess = new DataTier();
                    da = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                    if (da.HasRows == true)
                    {
                        da.Close();
                        DataAccess.Connclose(connHandle);
                        throw new Exception("Account already exist in Account master");
                    }
                    da.Close();
                  //  AddInfoRow["code"] = DropTransType.SelectedIndex != 0 ? DropTransType.SelectedValue.Trim() : "";
                }
                else
                {
                    if (RdBtnTranType.SelectedValue == "TW" || RdBtnTranType.SelectedValue == "I")
                    {
                        SqlStr = "select * from lcode where cd='" + DropTransType.SelectedValue + "'";
                        DataAccess = new DataTier();
                        da = DataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                        if (da.HasRows == true)
                        {
                            da.Close();
                            DataAccess.Connclose(connHandle);
                            throw new Exception("Account already exist in Account master");
                        }
                        da.Close();
                        AddInfoRow["cd"] = DropTransType.SelectedIndex != 0 ? DropTransType.SelectedValue.Trim() : "";
                    }
                }
            }
               
                AddInfoRow["e_code"] = DropTransType.SelectedIndex != 0 ? DropTransType.SelectedValue.Trim() : "";
                AddInfoRow["head_nm"] = Convert.ToString(txtheadname.Text);
                AddInfoRow["fld_nm"] = Convert.ToString(txtFieldName.Text);
                AddInfoRow["data_ty"] = DropType.SelectedIndex != 0 ? DropType.SelectedItem.Text.Trim() : "";
                AddInfoRow["fld_wid"] = Convert.ToString(txtWidth.Text);
                AddInfoRow["fld_dec"] = Convert.ToString(txtdecimal.Text);
                if (RdBtnTranType.SelectedValue == "TW")
                {
                    AddInfoRow["att_file"] = Convert.ToBoolean(RdBtnTranType.Items[0].Selected);
                }
                else
                {
                    if (RdBtnTranType.SelectedValue == "I")
                    {
                        AddInfoRow["att_file"] = Convert.ToBoolean(RdBtnTranType.Items[1].Selected);
                    }
                }
                
                AddInfoRow["filtcond"] = Convert.ToString(txtPopUp.Text);
                AddInfoRow["serial"] = Convert.ToString(txtserialOrd.Text);
                AddInfoRow["inter_use"] = bitFunction.toBoolean(ChkInterUse.Checked);
                AddInfoRow["mandatory"] = bitFunction.toBoolean(ChkMadatory.Checked);
                AddInfoRow["inpickup"] = bitFunction.toBoolean(ChkDP.Checked);
                AddInfoRow["ingrid"] = bitFunction.toBoolean(ChkDG.Checked);
                if (RdBtnMain.SelectedValue == "M")
                {
                    AddInfoRow["type"] = Convert.ToString(RdBtnMain.Items[0].Value);
                }
                else
                {
                    if (RdBtnMain.SelectedValue == "T")
                    {
                        AddInfoRow["type"] = Convert.ToString(RdBtnMain.Items[1].Value);
                    }
                }
                AddInfoRow["remarks"] = Convert.ToString(TxtRemarks.Text);
                AddInfoRow["defa_fld"] = bitFunction.toBoolean(ChkDefault.Checked);
                if (RdBtnMain.SelectedValue == "M")
                {
                    for (int i = 0; i <= listValidation.Items.Count -1; i++)
                    {
                        AddInfoRow["validity"] = listValidation.Items[i].Selected.ToString();
                    }
                }
                else
                {
                    if (RdBtnMain.SelectedValue == "T")
                    {
                        for (int i = 0; i <= listValidation.Items.Count - 1; i++)
                        {
                            AddInfoRow["validity"] = Convert.ToString(listValidation.Items[i].Selected.ToString());
                        }
                    }
                }
                
                AddInfoRow.AcceptChanges();
            }
                
        
    
        protected void btnTopSave_Click(object sender, EventArgs e)
        {
            Save();

        }

        protected void lnkBtnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwAddtionalInfoView.aspx");
        }
    }
}

