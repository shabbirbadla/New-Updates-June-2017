using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Data.Acess.Layer;
using Business.Logic.Layer;  

namespace Udyog.E.Billing
{
    public partial class Item_Group_Master : System.Web.UI.Page
    {
        DataTier DataAccess;       
        
        SqlDataReader dr;
        SqlConnection connHandle;

        private string sqlstr="";
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }
        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private Int32 itemid;
        public Int32 Itemid
        {
            get { return itemid; }
            set { itemid = value; }
        }

        private string itemGroup;
        public string ItemGroup
        {
            get { return itemGroup; }
            set { itemGroup = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            DataAccess = new DataTier();
            DataSet ItmastDataSet = new DataSet();
            if (IsPostBack == true)
            {
                ItmastDataSet = (DataSet)Session["ItmastDataSet"];
                if (ItmastDataSet.Tables["lother"].Rows.Count > 0)
                {
                    DataView xtra_vw = ItmastDataSet.Tables["lother"].DefaultView;
                    xtra_vw.Sort = "";
                    vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                    try
                    {
                        vuAddInfo.genControls(xtra_vw,
                                ItmastDataSet.Tables["Itmastview"].Rows[0],tblAddInforDetails);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                    tdAddInfo.Visible = true;
                }

                AddMode = Convert.ToBoolean(Request.QueryString["addmode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editmode"]);
                Itemid = Convert.ToInt32(Request.QueryString["itemid"]);
                ItemGroup = Convert.ToString(Request.QueryString["ItemGroupType"]);

                return;
            }

            Session["ItmastDataSet"] = null;

            getCompany CompObj = new getCompany();
            ItmastDataSet = CompObj.Company(ItmastDataSet, SessionProxy.ReqCode.Trim(), SessionProxy.FinYear.Trim());

            AddMode = Convert.ToBoolean(Request.QueryString["addmode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editmode"]); 
            Itemid = Convert.ToInt32(Request.QueryString["itemid"]);
            ItemGroup = Convert.ToString(Request.QueryString["ItemGroupType"]);

            hidnProd.Value = SessionProxy.VChkProd;
            lblItrType.Text = "Item Group Master";
            fillDropDowns(ref ItmastDataSet);
            if (AddMode == true)
            {
                AddRecord(ref ItmastDataSet);
            }
            else
            {
                if (EditMode == true)
                {
                    editRec(Itemid,ref ItmastDataSet);
                }
            }
            
            sqlstr = "Select * from lother where e_code='IG' order by serial";
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, sqlstr, "lother",connHandle);
            DataAccess.Connclose(connHandle);


            if (ItmastDataSet.Tables["lother"].Rows.Count > 0)
            {
                DataView xtra_vw = ItmastDataSet.Tables["lother"].DefaultView;
                xtra_vw.Sort = "Serial";
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.genControls(xtra_vw,
                            ItmastDataSet.Tables["Itmastview"].Rows[0], tblAddInforDetails);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
                
                tdAddInfo.Visible = true;
            }
            else
            {
                tdAddInfo.Visible = false;
            }           

            Session["ItmastDataSet"] = ItmastDataSet;
            ItmastDataSet.Dispose();
              
        }

        public void AddRecord(ref DataSet ItmastDataSet)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            DataAccess = new DataTier();
            sqlstr = "select * from item_group where 1=2";
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, sqlstr, "Itmastview",connHandle);
            DataAccess.Connclose(connHandle);
 
            DataRow ItMastRow = ItmastDataSet.Tables["Itmastview"].NewRow();
            ItMastRow["rateper"] = 1;
            ItMastRow["prate"] = 1;
            ItMastRow["ratio"] = 1;
            ItMastRow["rateunit"] = "PCS";
            ItMastRow["rate"] = 0;
            ItMastRow["curr_cost"] = 0;
            ItMastRow["in_stkval"] = true;

            DataNullUpdate.NullUpdate(ItMastRow);
            ItmastDataSet.Tables["Itmastview"].Rows.Add(ItMastRow);
            ItmastDataSet.Tables["Itmastview"].AcceptChanges();

            boolFunction bitFunction = new boolFunction();
            txtRatepercentSale.Text = Convert.ToString(ItMastRow["rateper"]);
            txtRatePercentPur.Text = Convert.ToString(ItMastRow["prate"]);
            txtConversionRatio.Text = Convert.ToString(ItMastRow["ratio"]);
            ddlStockUnit.SelectedValue = Convert.ToString(ItMastRow["rateunit"]).Trim().ToUpper();
            txtRateSales.Text = Convert.ToString(ItMastRow["rate"]);
            txtRatePurchase.Text = Convert.ToString(ItMastRow["curr_cost"]);
            ddlItemType.SelectedValue = Convert.ToString(ItMastRow["type"]).Trim();
            chkStkVal.Checked = bitFunction.toBoolean(ItMastRow["in_stkval"]);

            txtSaleToAcc.Text = "SALES";
            txtPTAcc.Text = "PURCHASE";
            
            if (bitFunction.toBoolean(ItmastDataSet.Tables["company"].Rows[0]["s_item"]) == true)
                txtSaleToAcc.Enabled = true;
            else
            {
                txtSaleToAcc.Text = "SALES";
                txtSaleToAcc.Enabled = false;
            }

            if (bitFunction.toBoolean(ItmastDataSet.Tables["company"].Rows[0]["p_item"]) == true)
                txtPTAcc.Enabled = true;
            else
            {
                txtPTAcc.Text = "PURCHASES";
                txtPTAcc.Enabled = false;
            }
            ScriptManager1.SetFocus(textGrpName);
    
        }

        protected void editRec(Int32 Itemid, ref DataSet ItmastDataSet)
        {
            sqlstr = "select * from item_group where Itgrid=" + Itemid;
            DataAccess = new DataTier();
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, sqlstr, "Itmastview",connHandle);
            DataAccess.Connclose(connHandle);
            BindControls(ItmastDataSet.Tables["ItMastView"].Rows[0],true);
            if (EditMode == true)
            {
                textGrpName.Enabled = false;
            }
        }

        protected void fillDropDowns(ref DataSet ItmastDataSet)
        {
            //For type
            sqlstr = "select ittyid,type from item_type where LTRIM(RTRIM(type)) <> ''order by type";
            DataAccess = new DataTier();
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, sqlstr, "TypeView",connHandle);

            ddlItemType.DataSource = ItmastDataSet.Tables["TypeView"];
            ddlItemType.DataTextField = "type";
            ddlItemType.DataValueField = "ittyid";
            ddlItemType.DataBind();
            ddlItemType.Items.Insert(0, "--Select Type--");

            //For Stock Unit
            sqlstr = "Select upper(ltrim(rtrim(u_uom))) as u_uom from UOM order by u_uom";
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, sqlstr, "UomView",connHandle);
            DataAccess.Connclose(connHandle); 
            ddlStockUnit.DataSource = ItmastDataSet.Tables["UomView"];
            ddlStockUnit.DataTextField = "u_uom";
            ddlStockUnit.DataValueField = "u_uom";
            ddlStockUnit.DataBind();
            ddlStockUnit.Items.Insert(0, "--Select Unit--");

            //For salesUnit
            ddlUnit.DataSource = ItmastDataSet.Tables["UomView"];
            ddlUnit.DataTextField = "u_uom";
            ddlUnit.DataValueField = "u_uom";
            ddlUnit.DataBind();
            ddlUnit.Items.Insert(0, "--Select Unit--");

            //For Purchase unit
            ddlPurUnit.DataSource = ItmastDataSet.Tables["UomView"];
            ddlPurUnit.DataTextField = "u_uom";
            ddlPurUnit.DataValueField = "u_uom";
            ddlPurUnit.DataBind();
            ddlPurUnit.Items.Insert(0, "--Select Unit--");
                  
        }

        protected void txtGroup_TextChanged(object sender, EventArgs e)
        { 
            sqlstr = "select * from item_group where it_group_name='"
                    + txtGroup.Text.ToString().Trim() + "'";
            
            DataAccess = new DataTier();
            DataSet ItmastDataSet = (DataSet)Session["ItmastDataSet"];
            ItmastDataSet = DataAccess.ExecuteDataset(ItmastDataSet, sqlstr, "ItGroupView",connHandle);
            DataAccess.Connclose(connHandle); 
            string oldItName = textGrpName.Text;
            DataRow ItMastRow = ItmastDataSet.Tables["ItMastView"].Rows[0];
            ItMastRow = DataAccess.ExactScatterGatherRow(ItmastDataSet.Tables["ItGroupView"].Rows[0],
                       ItMastRow);

            ItMastRow.AcceptChanges();
            ItmastDataSet.Tables["ItMastView"].AcceptChanges();
            BindControls(ItMastRow, false);
            
            textGrpName.Text =  oldItName;
            Session["ItmastDataSet"] = ItmastDataSet;
            ItmastDataSet.Dispose();
            DataAccess.Connclose(connHandle);
           
        }
        protected void btnTopSave_Click(object sender, EventArgs e)
        {
            if (IsValid == true)
            {
                try
                {
                    Save(); 
                    tblError.Visible = false;
                    Response.Redirect("ItemGroupMasterView.aspx?ShowStatus=true");

                }
                catch (Exception Ex)
                {
                    
                    tblError.Visible = true;
                    lblErrorItHeading.Text = "Please Check Error details below";
                    lblItErrorDetails.Text = Ex.Message;
                }
            }

        }



        protected void BindControls(DataRow ItMastRow, bool isGroup)
        {
            
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

           textGrpName.Text = Convert.ToString(ItMastRow["it_group_name"]);
            
            if (isGroup == true)
            {
                txtGroup.Text = Convert.ToString(ItMastRow["it_group_name"]).Trim() == "" ?
                    "" : Convert.ToString(ItMastRow["it_group_name"]);
            }
            txtDescription.Text = Convert.ToString(ItMastRow["it_alias"]);

            ddlStockUnit.SelectedValue = Convert.ToString(ItMastRow["rateunit"]).Trim() == ""?
                "--Select Unit--": Convert.ToString(ItMastRow["rateunit"]).Trim().ToUpper();

            txtConversionRatio.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["ratio"]));

            ddlItemType.SelectedValue = Convert.ToString(numFunction.toInt32(ItMastRow["ittyid"])) == "0" ?
                "--Select Type--" : Convert.ToString(numFunction.toInt32(ItMastRow["ittyid"]));

            txtRemark.Text = Convert.ToString(ItMastRow["remark"]);
            chkStkVal.Checked = bitFunction.toBoolean(ItMastRow["in_stkval"]);

            //sales Fields
            if (Convert.ToString(ItMastRow["sac_nm"]).Trim() != "")
            {
                string accountName = Convert.ToString(ItMastRow["sac_nm"]).Trim();
                accountName = accountName.Remove(accountName.IndexOf('"'), 1);
                accountName = accountName.Remove(accountName.LastIndexOf('"'), 1);
                txtSaleToAcc.Text = accountName.Trim();
            }
            else
            {
                txtSaleToAcc.Text = "";
            }

            ddlUnit.SelectedValue = Convert.ToString(ItMastRow["s_unit"]).Trim() ==""?
                "--Select Unit--":Convert.ToString(ItMastRow["s_unit"]).Trim().ToUpper();

            txtRateSales.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["rate"]));

            txtRatepercentSale.Text = Convert.ToString(ItMastRow["rateper"]);
            //purchase fields
            if (Convert.ToString(ItMastRow["pac_nm"]).Trim() != "")
            {
                string accountName = Convert.ToString(ItMastRow["pac_nm"]).Trim();
                accountName = accountName.Remove(accountName.IndexOf('"'), 1);
                accountName = accountName.Remove(accountName.LastIndexOf('"'), 1);
                txtPTAcc.Text = accountName.Trim();
            }
            else
            {
                txtPTAcc.Text = "";
            }

            ddlPurUnit.SelectedValue = Convert.ToString(ItMastRow["p_unit"]).Trim() == ""? 
                "--Select Unit--": Convert.ToString(ItMastRow["p_unit"]).ToUpper();

            txtRatePurchase.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["curr_cost"]));

            txtRatePercentPur.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["prate"]));
            
            txtReOrderPur.Text = Convert.ToString(numFunction.toDecimal(ItMastRow["reorder"])); 
        }

        protected void BindSave(ref DataSet ItmastDataSet)
        {
                if (AddMode == true && EditMode == false)
                {
                sqlstr = "select it_group_name from item_group where it_group_name='" +textGrpName.Text + "'";

                DataAccess = new DataTier();
                dr = DataAccess.ExecuteDataReader(sqlstr,ref connHandle);
                if (dr.HasRows == true)
                {
                    dr.Close();
                    DataAccess.Connclose(connHandle);
                    throw new Exception("Item already exist in Item Group Master");
                }
                dr.Close();
                DataAccess.Connclose(connHandle);
            }
           
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataTable lother = ItmastDataSet.Tables["Lother"];
            DataRow ItMastRow = ItmastDataSet.Tables["Itmastview"].Rows[0];
            ItMastRow["it_group_name"] = Convert.ToString(textGrpName.Text);
            ItMastRow["group"] = txtGroup.Text.Trim();
            ItMastRow["ittyid"] = ddlItemType.SelectedIndex != 0 ? numFunction.toInt32(ddlItemType.SelectedValue) : 0;
            ItMastRow["it_alias"] = Convert.ToString(txtDescription.Text);
            ItMastRow["rateunit"] = ddlStockUnit.SelectedIndex != 0 ? ddlStockUnit.SelectedItem.Text.Trim() : "";
            ItMastRow["ratio"] = numFunction.toDecimal(txtConversionRatio.Text);
            ItMastRow["remark"] = Convert.ToString(txtRemark.Text);
            ItMastRow["in_stkval"] = bitFunction.toBoolean(chkStkVal.Checked);
            if (txtSaleToAcc.Text.Trim() != "")
            {
                string accountName = '"' + txtSaleToAcc.Text.ToString().Trim() + '"';
                ItMastRow["sac_nm"] = accountName.Trim();
            }
            
            ItMastRow["s_unit"] = ddlUnit.SelectedItem.ToString().Trim();
            ItMastRow["rate"] = numFunction.toDecimal(txtRateSales.Text);
            ItMastRow["rateper"] = numFunction.toDecimal(txtRatepercentSale.Text);

            if (txtPTAcc.Text != "")
            {
                string accountName = '"' + txtPTAcc.Text.ToString().Trim() + '"';
                ItMastRow["pac_nm"] = accountName.Trim();
            }


            ItMastRow["p_unit"] = Convert.ToString(ddlPurUnit.SelectedValue).Trim();
            ItMastRow["curr_cost"] = numFunction.toDecimal(txtRatePurchase.Text);
            ItMastRow["prate"] = numFunction.toDecimal(txtRatePercentPur.Text);
            ItMastRow["reorder"] = numFunction.toDecimal(txtReOrderPur.Text);

            if (lother.Rows.Count > 0)
            {
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.btnClick(tblAddInforDetails, ItMastRow, "BOXING", null);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }

            ItMastRow.AcceptChanges();
        }

        protected void checkValidation(DataSet ItMastDataset)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            DataSet ItmastDataSet = (DataSet)Session["ItmastDataSet"];
            if (Convert.ToString( ItmastDataSet.Tables["ItMastView"].Rows[0]["it_group_name"]).Trim() == "")
            {
                throw new Exception("Group name cannot be blank");
            }

            if (Convert.ToString(ItmastDataSet.Tables["ItMastView"].Rows[0]["type"]).Trim() == "")
            {
                throw new Exception("Type cannot be blank");
            }

            if (numFunction.toDecimal(ItmastDataSet.Tables["ItMastView"].Rows[0]["rate"]) == 0)
            {
                throw new Exception("Selling Rate cannot be zero");
            }

            if (numFunction.toDecimal(ItmastDataSet.Tables["ItMastView"].Rows[0]["curr_cost"]) == 0)
            {
                throw new Exception("Current cost cannot be zero");
            }

            if (numFunction.toDecimal(ItmastDataSet.Tables["ItMastView"].Rows[0]["reorder"]) == 0)
            {
                throw new Exception("Reorder level cannot be zero");
            }

            if (bitFunction.toBoolean(ItmastDataSet.Tables["company"].Rows[0]["s_item"]) == true)
                if (txtSaleToAcc.Text == "")
                {
                    txtSaleToAcc.Focus();
                    throw new Exception("Select Sales A/c");
                }

            if (bitFunction.toBoolean(ItmastDataSet.Tables["company"].Rows[0]["p_item"]) == true)
                if (txtPTAcc.Text == "")
                {
                    txtPTAcc.Focus();
                    throw new Exception("Select Purchase A/c");
                }


            if (Convert.ToString(ItmastDataSet.Tables["ItMastView"].Rows[0]["rateunit"]) == "" ||
                Convert.ToString(ItmastDataSet.Tables["ItMastView"].Rows[0]["s_unit"]) == "" ||
                Convert.ToString(ItmastDataSet.Tables["ItMastView"].Rows[0]["p_unit"]) == "")
            {
                throw new Exception("Unit cannot be blank");
            }
            ItmastDataSet.Dispose();
            
        }
        protected void Save()
        {
            try
            {
                DataAccess = new DataTier();
                DataSet ItmastDataSet = (DataSet)Session["ItmastDataSet"];
                BindSave(ref ItmastDataSet);
                checkValidation(ItmastDataSet);
                numericFunction numFunction = new numericFunction();
                if (EditMode == true)
                {
                    sqlstr = DataAccess.GenUpdateString(ItmastDataSet.Tables["ItMastView"], "item_group",
                                                new string[] { "Itgrid" }, null, "", new string[] { "Itgrid" });
                }
                else
                {
                    if (AddMode == true)
                    {
                        sqlstr = DataAccess.GenInsertString(ItmastDataSet.Tables["ItMastView"].Rows[0], "item_group",
                                                    new string[] { "Itgrid" }, null);

                    }
                }

                if (sqlstr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(sqlstr, "TX", true,ref connHandle);
                    try
                    {
                        
                        cmd.ExecuteNonQuery();
                       
                        DataAccess.CommitTransaction(cmd.Transaction);
                        DataAccess.Connclose(connHandle);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        DataAccess.Connclose(connHandle);
                        throw Ex;
                    }
                }
                ItmastDataSet.Dispose();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }


        protected void ItlnkBtnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("ItemGroupMasterview.aspx");

        }
        protected void btnAllSaveItem_Click(object sender, EventArgs e)
        {
            Save();
        }
    }
}
