using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using Business.Logic.Layer;


namespace Udyog.E.Billing
{
    public partial class uwAcgroupMaster : System.Web.UI.Page
    {
        DataTier dataAccess;
        SqlDataReader dr;
        private string SqlStr = "";

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }

        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private Int32 acid;
        public Int32 Acid
        {
            get { return acid; }
            set { acid = value; }
        }

        private SqlConnection connHandle;

        protected void Page_Load(object sender,EventArgs e)
        {
            DataSet AcgroupDataSet = new DataSet();
            if (IsPostBack == true)
            {
                AcgroupDataSet = (DataSet)Session["AcgroupDataSet"];
                if (AcgroupDataSet.Tables["lother"].Rows.Count > 0)
                {
                    DataView xtra_vw = AcgroupDataSet.Tables["lother"].DefaultView;
                    xtra_vw.Sort = "";
                    vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                    try
                    {
                        vuAddInfo.genControls(xtra_vw,
                                AcgroupDataSet.Tables["AcMastView"].Rows[0], tblAddInforDetails);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                    tdAddInfo.Visible = true;
                }

                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                Acid = Convert.ToInt32(Request.QueryString["acId"]);

                return;
            }
            // Get Parameters from Previous Page
            AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
            Acid = Convert.ToInt32(Request.QueryString["acId"]);
            
            //AcgroupDataSet = new DataSet();
            //dataAccess = new DataTier();
           // dataAccess.DataBaseName = "nxio";
            lblTrType.Text = "Account Group Master";

           
            //Session["ReqCode"] = "m22";
            //Session["Finyear"] = "2008-2009";
            //getCompany GetCompany = new getCompany();
            //AcgroupDataSet = GetCompany.Company(AcgroupDataSet, Session["ReqCode"].ToString().Trim()
              //              , Session["Finyear"].ToString().Trim());
            if (AddMode == true)
            {
                addRecord(ref AcgroupDataSet);
            }
            else
            {
                if (EditMode == true)
                {
                    editRecord(Acid, ref AcgroupDataSet);
                }
            }
            SqlStr = "Select * from lother where e_code='AG' order by serial";
            AcgroupDataSet = dataAccess.ExecuteDataset(AcgroupDataSet, SqlStr, "lother",connHandle);
            dataAccess.Connclose(connHandle);

            if (AcgroupDataSet.Tables["lother"].Rows.Count > 0)
            {
                DataView xtra_vw = AcgroupDataSet.Tables["lother"].DefaultView;
                xtra_vw.Sort = "Serial";
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.genControls(xtra_vw,
                            AcgroupDataSet.Tables["AcMastView"].Rows[0], tblAddInforDetails);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
                tdAddInfo.Visible = true;

            }
            else
            {
                tdAddInfo.Visible = false;
            }
           
            Session["AcgroupDataSet"] = AcgroupDataSet;
            AcgroupDataSet.Dispose();
            
        }
        protected void addRecord(ref DataSet AcgroupDataSet)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            boolFunction bitFunction = new boolFunction();
            dataAccess = new DataTier();
            SqlStr = "select * from AC_GROUP_MAST where 1=2";
            AcgroupDataSet = dataAccess.ExecuteDataset(AcgroupDataSet, SqlStr, "AcMastView",connHandle);
            dataAccess.Connclose(connHandle); 
            DataRow acMastRow = AcgroupDataSet.Tables["AcMastView"].NewRow();
            acMastRow["posting"] = "Entry by Entry";
            acMastRow["cr_days"] = 0;
            acMastRow["cramount"] = 0;
            acMastRow["i_rate"] = 0;
            acMastRow["i_days"] = 0;
            acMastRow["t_rate"] = 0;
            acMastRow["CrAllow"] = true;
            acMastRow["st_type"] = "";
            acMastRow["lTds"] = false;            
            DataNullUpdate.NullUpdate(acMastRow);
            DropLedgerPosting.SelectedValue = Convert.ToString(acMastRow["posting"]).Trim().ToUpper();
            txtCreditDays.Text = Convert.ToString(acMastRow["cr_days"]);
            txtCreditLimit.Text = Convert.ToString(acMastRow["cramount"]);
            textRateInterest.Text = Convert.ToString(acMastRow["i_rate"]);
            textPerDays.Text = Convert.ToString(acMastRow["i_days"]);
            DropSalestaxType.SelectedValue = Convert.ToString(acMastRow["st_type"]).Trim().ToUpper();
            chkTDS.Checked = bitFunction.toBoolean(acMastRow["lTds"]);
            AcgroupDataSet.Tables["AcMastView"].Rows.Add(acMastRow);
            AcgroupDataSet.Tables["AcMastView"].AcceptChanges();
            ScriptManager1.SetFocus(txtSubGroup);
            
        }

        protected void editRecord(Int32 acId, ref DataSet AcgroupDataSet)
        {
            dataAccess = new DataTier();
            SqlStr = "select * from AC_GROUP_MAST where ac_group_id = " + acId;
            AcgroupDataSet = dataAccess.ExecuteDataset(AcgroupDataSet, SqlStr, "AcMastView",connHandle);
            dataAccess.Connclose(connHandle);
            bindControl(AcgroupDataSet.Tables["AcMastView"].Rows[0],true);
            if (EditMode == true)
            {
                txtSubGroup.Enabled = false;
            }          
            
        }

        protected void txtGroup_TextChanged(object sender, EventArgs e)
        {
            
            SqlStr = "select * from AC_GROUP_MAST where ac_group_name ='" 
                    + txtGroup.Text.ToString().Trim() + "'";
            dataAccess = new DataTier();
            DataSet AcgroupDataSet = (DataSet)Session["AcgroupDataSet"];
            AcgroupDataSet = dataAccess.ExecuteDataset(AcgroupDataSet, SqlStr, "AcGroupView",connHandle);
            dataAccess.Connclose(connHandle); 
            string oldAcName = txtSubGroup.Text;
            DataRow acMastRow = AcgroupDataSet.Tables["AcMastView"].Rows[0];
            acMastRow = dataAccess.ExactScatterGatherRow(AcgroupDataSet.Tables["AcGroupView"].Rows[0], acMastRow);
            acMastRow.AcceptChanges();
            AcgroupDataSet.Tables["AcMastView"].AcceptChanges();
            bindControl(acMastRow,false);
            txtSubGroup.Text = oldAcName;
            Session["AcgroupDataSet"] = AcgroupDataSet;
            AcgroupDataSet.Dispose();
        }
          

        protected void bindControl(DataRow acMastRow, bool isGroup)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            txtSubGroup.Text = Convert.ToString(acMastRow["ac_group_name"]);
            if (isGroup == true)
            {
                txtGroup.Text = Convert.ToString(acMastRow["ac_group_name"]).Trim() == "" ?
                "" : Convert.ToString(acMastRow["ac_group_name"]);

            }
            DropLedgerPosting.SelectedValue = Convert.ToString(acMastRow["posting"]).ToString().Trim() == "" ?
                "Entry by Entry" : Convert.ToString(acMastRow["posting"]);

            txtCreditDays.Text = Convert.ToString(numFunction.toDecimal(acMastRow["cr_days"]));
            txtCreditLimit.Text = Convert.ToString(numFunction.toDecimal(acMastRow["cramount"]));
            textRateInterest.Text = Convert.ToString(numFunction.toDecimal(acMastRow["i_rate"]));
            textPerDays.Text = Convert.ToString(numFunction.toDecimal(acMastRow["i_days"]));
            DropSalestaxType.SelectedValue = Convert.ToString(acMastRow["st_type"]).ToString().Trim() == "" ?
                "--Select Sales Tax Type--" : Convert.ToString(acMastRow["st_type"]);
            txtTDSRate.Text = Convert.ToString(numFunction.toDecimal(acMastRow["t_rate"]));
            chkTDS.Checked = bitFunction.toBoolean(acMastRow["lTds"]);
            GraphCredLmt.Checked = bitFunction.toBoolean(acMastRow["crallow"]);
        }
        
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValid == true)
            {
                try
                {
                    Save(); // call Save Method
                    tblError.Visible = false;
                    Response.Redirect("uwAcGroupMasterView.aspx?ShowStatus=true");

                }
                catch (Exception Ex)
                {
                    tblError.Visible = true;
                    lblErrorHeading.Text = "Please Check Error details below";
                    lblErrorDetails.Text = Ex.Message;
                }
            }
        }

        protected void BindSave(ref DataSet AcgroupDataSet)
        {
            
            if (AddMode == true && EditMode == false)
            {
                SqlStr = "select ac_group_name from AC_GROUP_MAST where ac_group_name='" + txtSubGroup.Text + "'";
                dataAccess = new DataTier();
                dr = dataAccess.ExecuteDataReader(SqlStr,ref connHandle);
                if (dr.HasRows == true)
                {
                    dr.Close();
                    dataAccess.Connclose(connHandle);
                    throw new Exception("Account already exist in Account Group master");
                }
                dr.Close();
                dataAccess.Connclose(connHandle);
            }

            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            DataRow acMastRow = AcgroupDataSet.Tables["AcMastView"].Rows[0];
            acMastRow["ac_group_name"] = Convert.ToString(txtSubGroup.Text);
            acMastRow["group"] = Convert.ToString(txtGroup.Text).Trim();
            acMastRow["posting"] = DropLedgerPosting.SelectedIndex != 0 ? DropLedgerPosting.SelectedItem.Text.Trim() : "";
            acMastRow["cr_days"] = numFunction.toDecimal(txtCreditDays.Text);
            acMastRow["cramount"] = numFunction.toDecimal(txtCreditLimit.Text);
            acMastRow["crallow"] = bitFunction.toBoolean(GraphCredLmt.Checked);
            acMastRow["i_rate"] = numFunction.toDecimal(textRateInterest.Text);
            acMastRow["i_days"] = numFunction.toDecimal(textPerDays.Text);
            acMastRow["st_type"] = DropSalestaxType.SelectedIndex != 0 ? DropSalestaxType.SelectedItem.Text.Trim() : "";
            acMastRow["lTds"] = bitFunction.toBoolean(chkTDS.Checked);
            acMastRow["t_rate"] = numFunction.toDecimal(txtTDSRate.Text);
            acMastRow.AcceptChanges();
        }


        protected void chkValidation(ref DataSet AcgroupDataSet)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            if (Convert.ToString(AcgroupDataSet.Tables["AcMastView"].Rows[0]["ac_group_name"]).Trim() == "")
            {
                throw new Exception("Sub Group cannot be blank.");
            }
            if (Convert.ToString(AcgroupDataSet.Tables["AcMastView"].Rows[0]["group"]).Trim() == "")
            {
                throw new Exception("Group cannot be blank");
            }
            if (numFunction.toDecimal(AcgroupDataSet.Tables["AcMastView"].Rows[0]["cr_days"]) < 0)
            {
                throw new Exception("Credit Days cannot Be Negative");
            }
            if (numFunction.toDecimal(AcgroupDataSet.Tables["AcMastView"].Rows[0]["cramount"]) < 0)
            {
                throw new Exception(" Credit limit cannot Be Negative");
            }
            if (numFunction.toDecimal(AcgroupDataSet.Tables["AcMastView"].Rows[0]["i_rate"]) < 0)
            {
                throw new Exception(" Rate Of Interest cannot Be Negative");
            }
            if (numFunction.toDecimal(AcgroupDataSet.Tables["AcMastView"].Rows[0]["t_rate"]) < 0)
            {
                throw new Exception(" Tds Rate cannot Be Negative");
            }
        }

        protected void Save()
        {
            try
            {
                DataSet AcgroupDataSet = (DataSet)Session["AcgroupDataSet"];
                BindSave(ref AcgroupDataSet);
                chkValidation(ref AcgroupDataSet);
                numericFunction numFunction = new numericFunction();
                dataAccess = new DataTier();
                if (EditMode == true)
                {
                    SqlStr = dataAccess.GenUpdateString(AcgroupDataSet.Tables["AcMastView"], "AC_GROUP_MAST",
                                                new string[] { "ac_group_id" }, null, "", new string[] { "ac_group_id" });
                }
                else
                {
                    if (AddMode == true)
                    {
                        SqlStr = dataAccess.GenInsertString(AcgroupDataSet.Tables["AcMastView"], "AC_GROUP_MAST",
                                                    new string[] { "ac_group_id" }, null);
                    }
                }
                if (SqlStr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = dataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        dataAccess.CommitTransaction(cmd.Transaction);
                        dataAccess.Connclose(connHandle);
                    }
                    catch (Exception Ex)
                    {
                        dataAccess.RollBackTransaction(cmd.Transaction);
                        dataAccess.Connclose(connHandle);
                        throw Ex;
                    }                    
                }
                AcgroupDataSet.Dispose();
            }
            catch (Exception Ex)
            {
                throw Ex;
                tblError.Visible = true;
                lblErrorHeading.Text = "Please Check Error details below";
                lblErrorDetails.Text = Ex.Message;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message + "');", true);
            }
            
        }

       
        protected void lnkBtnBack1_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwAcGroupMasterView.aspx");
        }

      }
}
