using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Collections.Generic; 
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using Business.Logic.Layer;
using AjaxControlToolkit;
using System.ComponentModel; 



namespace Udyog.E.Billing
{
    public partial class uwAcGroupMasterView : BasePage 
    {

        #region Define Variable 
        private  String m_strSortExp;
        private SortDirection m_SortDirection = SortDirection.Ascending;
        CL_Gen_Man_AcGroup_view obj_Gen_AcGroup_View = new CL_Gen_Man_AcGroup_view();       

        string SearchString = "";
        #endregion

        #region Page Events
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable AcMastView = new DataTable();
            DataTier DataAccess = new DataTier();
            if (IsPostBack == false)
            {
                m_strSortExp = "[ac_group_name]";

                ViewState["_Direction_"] = m_SortDirection;
                ViewState["_SortExp_"] = m_strSortExp;

                lblTrType.Text = "Account Group Master";
                txtSearch.Attributes.Add("onkeypress", "return OnKeyEnter();");
                txtSearch.Attributes.Add("onfocus", "select();");
                bool ShowStatus = Convert.ToBoolean(Request.QueryString["ShowStatus"]);

                if (ShowStatus == true)
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Sucessfully Saved.');", true);

                txtSearch.Focus();
            }
            else
            {
                if (null != ViewState["_SortExp_"])
                {
                    m_strSortExp = ViewState["_SortExp_"] as String;
                }

                if (null != ViewState["_Direction_"])
                {
                    m_SortDirection = (SortDirection)ViewState["_Direction_"];
                }
            }
            //AcMastView.Dispose();

        }

       

        protected void GoToPage_TextChanged(object sender, EventArgs e)
        {
            TextBox txtGoToPage = (TextBox)sender;

            int pageNumber;
            if (int.TryParse(txtGoToPage.Text.Trim(), out pageNumber) && pageNumber > 0 && pageNumber <= this.grdAcMaster.PageCount)
            {
                this.grdAcMaster.PageIndex = pageNumber - 1;
            }
            else
            {
                this.grdAcMaster.PageIndex = 0;
            }

            bindGridView();
        }

        protected void OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                if (String.Empty != m_strSortExp)
                {
                    AddSortImage(e.Row);
                }
            }
        }

        protected void OnSort(object sender, GridViewSortEventArgs e)
        {
            // There seems to be a bug in GridView sorting implementation. Value of
            // SortDirection is always set to "Ascending". Now we will have to play
            // little trick here to switch the direction ourselves.
            if (String.Empty != m_strSortExp)
            {
                if (String.Compare(e.SortExpression.Trim(), m_strSortExp, true) == 0)
                {
                    m_SortDirection = (m_SortDirection == SortDirection.Ascending) ? SortDirection.Descending : SortDirection.Ascending;
                }
            }

            ViewState["_Direction_"] = m_SortDirection;
            ViewState["_SortExp_"] = m_strSortExp = e.SortExpression.Trim();

            this.bindGridView();
        }
        protected void dropGrdview_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList dropDown = (DropDownList)sender;
            int grdPageSize;
            grdPageSize = int.Parse(dropDown.SelectedValue);
            this.grdAcMaster.PageSize = grdPageSize;
            bindGridView();
            dropDown.SelectedValue = grdPageSize.ToString();
        }

        protected void btnGOSearch_Click(object sender, EventArgs e)
        {
            bindGridView();
        }

        protected void grdAcMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Pager)
            {
                Label lblTotalNumberOfPages = (Label)e.Row.FindControl("lblTotalNumberOfPages");
                lblTotalNumberOfPages.Text = grdAcMaster.PageCount.ToString();

                TextBox txtGoToPage = (TextBox)e.Row.FindControl("txtGoToPage");
                txtGoToPage.Text = (grdAcMaster.PageIndex + 1).ToString();

                DropDownList ddlPageSize = (DropDownList)e.Row.FindControl("ddlPageSize");
                ddlPageSize.SelectedValue = grdAcMaster.PageSize.ToString();
            }
            else
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                    e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";

                }
            }
        }

        protected void grdAcMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "EDITLINK":
                    Response.Redirect("uwAcGroupMaster.aspx?acId=" + grdAcMaster.DataKeys[Convert.ToInt16(e.CommandArgument)].Values[0].ToString().Trim() +
                                      "&addMode=false&editMode=true");
                    break;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= grdAcMaster.Rows.Count - 1; i++)
            {
                CheckBox chkSelect = (CheckBox)grdAcMaster.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    try
                    {
                        DeleteRec(Convert.ToInt32(grdAcMaster.DataKeys[i].Values[0]));
                        tblError.Visible = false;
                        btnGOSearch_Click(sender, e); // Refresh GridView 
                    }
                    catch (Exception Ex)
                    {
                        tblError.Visible = true;
                        lblErrorHeading.Text = "Error Found while Deleting Records.";
                        lblErrorDetails.Text = Ex.Message;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "HighlightRow(null,'" + chkSelect.ClientID + "');", true);
                        break;
                    }
                }
            }
        }

        protected void lnkBtnAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwAcGroupMaster.aspx?&addMode=true&editMode=false");
        }

        protected void ObjectDataSource1_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            e.InputParameters["searchtext"] = txtSearch.Text.Trim();
            string strSort = "[ac_group_name] asc";
            if (null != m_strSortExp &&
                String.Empty != m_strSortExp)
            {
                strSort = String.Format("{0} {1}", m_strSortExp, (m_SortDirection == SortDirection.Descending) ? "DESC" : "ASC");
            }
            e.InputParameters["sortBytext"] = strSort;
        }

        #endregion

        #region Private Methods
        private void DeleteRec(Int32 Groupcd)
        {
            try
            {
                obj_Gen_AcGroup_View.Ac_group_id = Groupcd;
                obj_Gen_AcGroup_View.Delete();
            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message.Trim());
            }
        }

        private void bindGridView()
        {
            grdAcMaster.DataBind();
        }

        private int GetSortColumnIndex(String strCol)
        {
            foreach (DataControlField field in grdAcMaster.Columns)
            {
                if (field.SortExpression == strCol)
                {
                    return grdAcMaster.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        private void AddSortImage(GridViewRow headerRow)
        {
            Int32 iCol = !string.IsNullOrEmpty(m_strSortExp) ? GetSortColumnIndex(m_strSortExp.Trim().ToUpper()) : -1;
            if (-1 == iCol)
            {
                return;
            }
            // Create the sorting image based on the sort direction.
            Image sortImage = new Image();
            if (SortDirection.Ascending == m_SortDirection)
            {
                sortImage.ImageUrl = "~/Images/ArrowDown.png";
                sortImage.AlternateText = "Ascending Order";
            }
            else
            {
                sortImage.ImageUrl = "~/Images/ArrowUp.png";
                sortImage.AlternateText = "Descending Order";
            }

            // Add the image to the appropriate header cell.
            headerRow.Cells[iCol].Controls.Add(sortImage);
        }
        protected string EraseWord(string word)
        {
            word = word.Replace("<span class=highlight>", "");
            word = word.Replace("</span>", "");
            word = word.Trim();
            return word;
        }
        #endregion

        #region Public Methods
        public string HighlightText(string InputTxt)
        {
            if (txtSearch.Text != "")
                SearchString = txtSearch.Text.Trim();

            if (SearchString == "")
            {
                return InputTxt;
            }
            else
            {
                System.Text.RegularExpressions.Regex ResultStr;
                ResultStr = new System.Text.RegularExpressions.Regex(SearchString.Replace(" ", "|"), System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return ResultStr.Replace(InputTxt, new System.Text.RegularExpressions.MatchEvaluator(this.ReplaceWords));
            }
        }

        public string ReplaceWords(System.Text.RegularExpressions.Match m)
        {
            return "<span class=highlight>" + m.ToString() + "</span>";
        }
        #endregion



    }

    public class GetAcGroup_View
    {
        CL_Gen_Man_AcGroup_view obj_Gen_AcGroup = new CL_Gen_Man_AcGroup_view();
        private static int totalRec;

        [DataObjectMethod(DataObjectMethodType.Select)]
        public List<CL_Gen_Ent_AcGroup_Grid_Columns> GetAcGroup_Rows(int startIndex,
                    int pageSize,
                    string sortBy,
                    string searchtext,
                    string sortBytext)
        {

            List<CL_Gen_Ent_AcGroup_Grid_Columns> result;

            int totRec = 0;

            obj_Gen_AcGroup.StartIndex = startIndex;
            obj_Gen_AcGroup.PageSize = pageSize;
            obj_Gen_AcGroup.SortBy = sortBytext;
            obj_Gen_AcGroup.Searchtext = searchtext;

            result = obj_Gen_AcGroup.GetAllRows();
            totalRec = obj_Gen_AcGroup.TotalRec; 
            return result;
        }

        public static int GetTotalRecCount(string searchtext, string sortBytext)
        {
            return totalRec;
        }
    }

}
