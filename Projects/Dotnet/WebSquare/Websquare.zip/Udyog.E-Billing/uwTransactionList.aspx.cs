using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic ;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using AjaxControlToolkit;
using System.ComponentModel; 
using Business.Logic.Layer;
using System.IO;
using System.Data.SqlClient;


namespace Udyog.E.Billing
{
    public partial class uwTransactionList : BasePage
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();

        private String m_strSortExp;
        private SortDirection m_SortDirection = SortDirection.Ascending;
        private SqlConnection connHandle;
        string SearchString = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                m_strSortExp = "[date]";

                ViewState["_Direction_"] = m_SortDirection;
                ViewState["_SortExp_"] = m_strSortExp;

                CL_DBPageProperties DBProps = new CL_DBPageProperties();
                SessionProxy.DbProperties = DBProps.DbProperties();
                DataRow DbRow = SessionProxy.DbProperties.NewRow();
                SessionProxy.DbProperties.Rows.Add(DbRow);

                //PageCustomProperties PageCustomProps = new PageCustomProperties();
                DBPropsSession = new CL_DbProperties_SessionProxy();
                DBPropsSession.PcvType = Request.QueryString["PcvType"];
                DBPropsSession.Vchkprod = Convert.ToString(SessionProxy.VChkProd).Trim();
                //DBPropsSession = PageCustomProps;

                this.Title = lblTrType.Text.Trim() + " View ";
                txtSearch.Attributes.Add("onkeypress", "return OnKeyEnter();");
                txtSearch.Attributes.Add("onfocus", "select();");
                txtSearch.Focus();
            }
            else
            {
                if (null != ViewState["_SortExp_"])
                {
                    m_strSortExp = ViewState["_SortExp_"] as String;
                }

                if (null != ViewState["_Direction_"])
                {
                    m_SortDirection = (SortDirection)ViewState["_Direction_"];
                }
            }
        }

        int GetSortColumnIndex(String strCol)
        {
            foreach (DataControlField field in grdview.Columns)
            {
                if (field.SortExpression == strCol)
                {
                    return grdview.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        void AddSortImage(GridViewRow headerRow)
        {
            Int32 iCol = !string.IsNullOrEmpty(m_strSortExp) ? GetSortColumnIndex(m_strSortExp.Trim().ToUpper()) : -1;
            if (-1 == iCol)
            {
                return;
            }
            // Create the sorting image based on the sort direction.
            Image sortImage = new Image();
            if (SortDirection.Ascending == m_SortDirection)
            {
                sortImage.ImageUrl = "~/Images/ArrowDown.png";
                sortImage.AlternateText = "Ascending Order";
            }
            else
            {
                sortImage.ImageUrl = "~/Images/ArrowUp.png";
                sortImage.AlternateText = "Descending Order";
            }

            // Add the image to the appropriate header cell.
            headerRow.Cells[iCol].Controls.Add(sortImage);
        }

        protected void ResultDisplay(int ResultRows)
        {
            if (ResultRows == 0)
            {
                lblResult.Text = "No Result Found..";
                lnkAll.Enabled = false;
                lnkNone.Enabled = false;
                btnPrint.Enabled = false;
            }
            else
            {
                lblResult.Text = "Result Found :" + ResultRows.ToString().Trim();
                lnkAll.Enabled = true;
                lnkNone.Enabled = true;
                btnPrint.Enabled = true;

            }
        }

        #region Event Handlers
        protected void OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                if (String.Empty != m_strSortExp)
                {
                    AddSortImage(e.Row);
                }
            }
        }

        protected void OnSort(object sender, GridViewSortEventArgs e)
        {
            // There seems to be a bug in GridView sorting implementation. Value of
            // SortDirection is always set to "Ascending". Now we will have to play
            // little trick here to switch the direction ourselves.
            if (String.Empty != m_strSortExp)
            {
                if (String.Compare(e.SortExpression, m_strSortExp, true) == 0)
                {
                    m_SortDirection = (m_SortDirection == SortDirection.Ascending) ? SortDirection.Descending : SortDirection.Ascending;
                }
            }

            ViewState["_Direction_"] = m_SortDirection;
            ViewState["_SortExp_"] = m_strSortExp = e.SortExpression;

            //this.bindGridView();
        }

        protected void GoToPage_TextChanged(object sender, EventArgs e)
        {
            TextBox txtGoToPage = (TextBox)sender;

            int pageNumber;
            if (int.TryParse(txtGoToPage.Text.Trim(), out pageNumber) && pageNumber > 0 && pageNumber <= this.grdview.PageCount)
            {
                this.grdview.PageIndex = pageNumber - 1;
            }
            else
            {
                this.grdview.PageIndex = 0;
            }

            bindGridView();
        }

        protected void dropGrdview_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList dropDown = (DropDownList)sender;
            this.grdview.PageSize = int.Parse(dropDown.SelectedValue);
            bindGridView();
        }

        protected void grdview_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Pager)
            {
                Label lblTotalNumberOfPages = (Label)e.Row.FindControl("lblTotalNumberOfPages");
                lblTotalNumberOfPages.Text = grdview.PageCount.ToString();

                TextBox txtGoToPage = (TextBox)e.Row.FindControl("txtGoToPage");
                txtGoToPage.Text = (grdview.PageIndex + 1).ToString();

                DropDownList ddlPageSize = (DropDownList)e.Row.FindControl("ddlPageSize");
                ddlPageSize.SelectedValue = grdview.PageSize.ToString();

            }
            else
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                    e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";
                }
            }
            HideGridCol(e);
            if (SessionProxy.LcodeView != null)
                lblTrType.Text = Convert.ToString(SessionProxy.LcodeView.Rows[0]["code_nm"]).Trim();

        }

        private void HideGridCol(GridViewRowEventArgs e)
        {
            if ((e.Row.RowState == DataControlRowState.Normal ||
                 e.Row.RowState == DataControlRowState.Alternate) &&
                 (e.Row.RowType == DataControlRowType.DataRow ||
                  e.Row.RowType == DataControlRowType.Header))
            {
                // Department
                if (DBPropsSession.ColDept == true)
                    e.Row.Cells[4].Visible = true;
                else
                    e.Row.Cells[4].Visible = false;

                // Category
                if (DBPropsSession.ColCate == true)
                    e.Row.Cells[5].Visible = true;
                else
                    e.Row.Cells[5].Visible = false;

                // Series
                if (DBPropsSession.ColSeries == true)
                    e.Row.Cells[6].Visible = true;
                else
                    e.Row.Cells[6].Visible = false;

                // Rule
                if (DBPropsSession.ColRule == true)
                    e.Row.Cells[7].Visible = true;
                else
                    e.Row.Cells[7].Visible = false;

                // Bank Name
                if (DBPropsSession.ColBankNm == true)
                    e.Row.Cells[8].Visible = true;
                else
                    e.Row.Cells[8].Visible = false;

                // U_pinvno and U_pinvdt
                if (DBPropsSession.ColRule == true)
                {
                    e.Row.Cells[10].Visible = true;
                    e.Row.Cells[11].Visible = true;
                }
                else
                {
                    e.Row.Cells[10].Visible = false;
                    e.Row.Cells[11].Visible = false;
                }
            }
        }
        protected void grdview_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            switch (e.CommandName.Trim().ToUpper())
            {
                case "EDITLINK":
                    string strLink = "vuTransactionEntry.aspx?pcvtype=" + DBPropsSession.PcvType.Trim() +
                                      "&behave=" + DBPropsSession.PcvType.Trim() +
                                      "&tranCd=" + grdview.DataKeys[Convert.ToInt16(e.CommandArgument)].Values[1].ToString().Trim() +
                                      "&addMode=false&editMode=true";

                    SessionProxy.MainQueryString = null;
                    SessionProxy.LikeInitQuery = null;
                    SessionProxy.ViewTranView = null;
                    SessionProxy.LcodeView = null;
                    SessionProxy.TranItDetView = null;
                    SessionProxy.TranAcDetView = null;
                    SessionProxy.RStatusView = null;
                    SessionProxy.DbProperties.Dispose();

                    Server.Transfer(strLink);

                    //Response.Redirect("vuTransactionEntry.aspx?pcvtype=" + DBPropsSession.PcvType.Trim() +
                    //                  "&tranCd=" + grdview.DataKeys[Convert.ToInt16(e.CommandArgument)].Values[1].ToString().Trim() +
                    //                  "&addMode=false&editMode=true");
                    break;
                case "PLUS":
                    GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                    grdViewCallNestGrid(row.RowIndex);
                    break;
                case "PRINT":
                    GridViewRow PrintRow = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                    grdViewCallNestPrintGrid(PrintRow.RowIndex);
                    break;
            }
        }


        protected void grdPrintDialog_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "PrintLink")
            {
                string strPrintCond = " tran_cd in(";
                string tranValue = "";
                bool isSelect = false;
                for (int i = 0; i < grdview.Rows.Count; i++)
                {
                    CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                    if (chkSelect.Checked == true)
                    {
                        if (tranValue != "")
                            tranValue += "," + grdview.DataKeys[i].Values[1].ToString().Trim();
                        else
                            tranValue += grdview.DataKeys[i].Values[1].ToString().Trim();

                        isSelect = true;
                    }
                }

                if (isSelect == false)
                {
                    DisplayMessage("Please Select atleast one transaction.. ");
                    return;
                }

                strPrintCond += tranValue.Trim() + ")";

                GridViewRow PrintRow = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                GridView grdPrintDialog = ((GridView)((Control)e.CommandSource).Parent.Parent.Parent.Parent);
                //GridView grdPrintDialog = ((GridView)((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).FindControl("TabPanel1")).FindControl("grdPrintDialog"));
                string desc = grdPrintDialog.DataKeys[PrintRow.RowIndex].Values[0].ToString().Trim();
                string repName = grdPrintDialog.DataKeys[PrintRow.RowIndex].Values[1].ToString().Trim();

                string filterExp = "desc ='" + desc.Trim() + "' and rep_nm='" + repName.Trim() + "'";
                try
                {
                    DataTable RStatus_vw = SessionProxy.RStatusView;
                    DataRow rStatusRow = RStatus_vw.Select(filterExp)[0];
                    if (Convert.ToString(rStatusRow["SqlQuery"]).Trim() == "")
                        throw new Exception("Cannot run Report,Query is blank in Report Wizard Master");
                    else
                        if (Convert.ToString(rStatusRow["retTable"]).Trim() == "")
                            throw new Exception("Cannot run Report,Temp Tablename is blank in Report Wizard Master");
                        else
                            if (Convert.ToString(rStatusRow["QTable"]).Trim() == "")
                                throw new Exception("Cannot run Report,Main Tablename is blank in Report Wizard Master");

                    string repSqlStr = "";
                    if (Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("EXECUTE") >= 0)
                    {
                        string pCond1 = "";
                        string pCond2 = "";
                        repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).ToUpper().Trim().Substring(0, Convert.ToString(rStatusRow["SqlQuery"]).Trim().LastIndexOf(';') - 1);
                        pCond1 = Convert.ToString(rStatusRow["QTable"]).Trim() + ".entry_ty ='" + DBPropsSession.PcvType.Trim() + "'";
                        pCond2 = Convert.ToString(rStatusRow["QTable"]).Trim() + "." + strPrintCond.Trim();
                        repSqlStr = repSqlStr.Trim() + '"' + pCond1 + " and " + pCond2 + '"';
                    }
                    else
                    {
                        string pCond = Convert.ToString(rStatusRow["QTable"]).Trim() +
                                       ".entry_ty = '" + DBPropsSession.PcvType.Trim() + "'" +
                                       " and " + Convert.ToString(rStatusRow["QTable"]).Trim() + "." + strPrintCond.Trim();

                        repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).Trim();
                        int whPos = Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("WHERE");

                        if (whPos >= 0)
                        {
                            repSqlStr = repSqlStr.Trim().Substring(0, whPos + 5) + " " +
                                        pCond.Trim() + " and " + repSqlStr.Trim().Substring(whPos + 6);
                        }
                        else
                            repSqlStr = repSqlStr + " WHERE " + pCond.Trim();

                    }

                    if (repSqlStr.Trim() != "")
                    {
                        DataTable Company = SessionProxy.Company;
                        string cFileName = Server.MapPath(".") + "\\" + Convert.ToString(Company.Rows[0]["dir_nm"]).Trim() + "\\Reports\\" + Convert.ToString(rStatusRow["rep_nm"]).Trim() + ".rpt";
                        if (File.Exists(cFileName) == false)
                        {
                            cFileName = Server.MapPath(".") + "\\Reports\\" + Convert.ToString(rStatusRow["rep_nm"]).Trim() + ".rpt";
                        }

                        Company.Dispose();
                        Company = null;
                        if (!File.Exists(cFileName))
                        {
                            throw new Exception(cFileName.Trim() + " Report file not found ...!!");
                        }

                        repSqlStr.Replace("REPORT HEADER", Convert.ToString(rStatusRow["desc"]).Trim());
                        SessionProxy.MainQueryString = repSqlStr.Trim();
                        SessionProxy.ReportPath = cFileName.Trim();
                        SessionProxy.ReportDataSet = null;
                    }

                    RStatus_vw.Dispose();
                    string strOpenWin = "";
                    //strOpenWin = "open_window_max('uwCRViewer.aspx','Report');";
                    strOpenWin = "open_window_max('ueCrystalHomePage.aspx','Report');";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "openWindowMax()", strOpenWin, true);
                }
                catch (Exception EX)
                {
                    DisplayMessage(EX.Message.Trim());
                }

            }
        }
        protected void grdViewCallNestPrintGrid(int rowIndex)
        {
            ImageButton ImgBtn = ((ImageButton)grdview.Rows[rowIndex].Cells[0].FindControl("imgPrint"));
            DataTable lcode_vw = SessionProxy.LcodeView;

            if (ImgBtn.AlternateText.Trim().IndexOf('+') >= 0)
            {
                SqlParameter[] spParam = new SqlParameter[2];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@code_nm";
                spParam[0].SqlDbType = SqlDbType.VarChar;
                spParam[0].Value = Convert.ToString(lcode_vw.Rows[0]["Code_nm"]).Trim();

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@repo_nm";
                spParam[1].SqlDbType = SqlDbType.Int;
                spParam[1].Value = Convert.ToString(lcode_vw.Rows[0]["repo_nm"]).Trim();

                DataTier dataAcess = new DataTier();
                dataAcess.DataBaseName = SessionProxy.DbName;
   
                DataTable RStatus_vw = new DataTable();
                RStatus_vw = dataAcess.ExecuteDataTable("sp_ent_web_tranview_print_nested", spParam,connHandle);

                foreach (DataRow RStat_Row in RStatus_vw.Select("desc = '' and rep_nm = ''"))
                {
                    RStat_Row.Delete();
                }
                RStatus_vw.AcceptChanges();

                if (RStatus_vw.Rows.Count > 0)
                {
                    ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).ActiveTabIndex = 0;
                    ((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).FindControl("TabPanel1")).Enabled = true;
                    ((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).FindControl("TabPanel1")).HeaderText = Convert.ToString(lcode_vw.Rows[0]["Code_nm"]).Trim() +
                        " Printing Dialog ";
                    GridView findPrintGrid = ((GridView)((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).FindControl("TabPanel1")).FindControl("grdPrintDialog"));
                    findPrintGrid.DataSource = RStatus_vw;
                    findPrintGrid.DataBind();
                    ImgBtn.AlternateText = "Print -";
                    ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).Visible = true;
                }
                else
                {
                    ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).Visible = false;
                }
                dataAcess.Connclose(connHandle);
                SessionProxy.RStatusView = RStatus_vw;
                RStatus_vw.Dispose();
            }
            else
            {
                if (ImgBtn.AlternateText.Trim().IndexOf('-') >= 0)
                {
                    ImgBtn.AlternateText = "Print +";
                    ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer2")).Visible = false;
                }
            }
            lcode_vw.Dispose();
        }

        protected void grdViewCallNestGrid(int rowIndex)
        {
            ImageButton findBtn = ((ImageButton)grdview.Rows[rowIndex].Cells[0].FindControl("imgNode"));
            DataTable lcode_vw = SessionProxy.LcodeView;
            DataTable tranitdet_vw = SessionProxy.TranItDetView;
            DataTable tranacdet_vw = SessionProxy.TranAcDetView;
            DataTier dataAcess = new DataTier();
            dataAcess.DataBaseName = SessionProxy.DbName;

            if (findBtn.AlternateText.Trim() == "+")
            {
                ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = true;

                string entry_ty = "";
                int tran_cd = 0;
                entry_ty = grdview.DataKeys[rowIndex].Values[0].ToString().Trim();
                tran_cd = Convert.ToInt32(grdview.DataKeys[rowIndex].Values[1]);
                if (Convert.ToBoolean(lcode_vw.Rows[0]["v_item"]) == true)
                {

                    SqlParameter[] spParam = new SqlParameter[3];
                    spParam[0] = new SqlParameter();
                    spParam[0].ParameterName = "@entry_ty";
                    spParam[0].SqlDbType = SqlDbType.VarChar;
                    spParam[0].Value = entry_ty.Trim();

                    spParam[1] = new SqlParameter();
                    spParam[1].ParameterName = "@tran_cd";
                    spParam[1].SqlDbType = SqlDbType.Int;
                    spParam[1].Value = tran_cd;

                    spParam[2] = new SqlParameter();
                    spParam[2].ParameterName = "@isWhat";
                    spParam[2].SqlDbType = SqlDbType.VarChar;
                    spParam[2].Value = "IT";

                    tranitdet_vw = dataAcess.ExecuteDataTable("sp_ent_web_tranview_nested_query", spParam,connHandle);

                    if (tranitdet_vw.Rows.Count != 0)
                    {
                        ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                        ((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).Enabled = true;
                        GridView findItGrid = ((GridView)((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).FindControl("grdItDetails"));
                        findItGrid.DataSource = tranitdet_vw;
                        findItGrid.DataBind();

                    }
                    else
                    {
                        ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 1;
                        ((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).Enabled = false;

                    }
                    SessionProxy.TranItDetView = tranitdet_vw;
                    tranitdet_vw.Dispose();

                }
                else
                {
                    ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 1;
                    ((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).Enabled = false;
                }

                if (Convert.ToBoolean(lcode_vw.Rows[0]["v_account"]) == true)
                {
                    SqlParameter[] spParam = new SqlParameter[3];
                    spParam[0] = new SqlParameter();
                    spParam[0].ParameterName = "@entry_ty";
                    spParam[0].SqlDbType = SqlDbType.VarChar;
                    spParam[0].Value = entry_ty.Trim();

                    spParam[1] = new SqlParameter();
                    spParam[1].ParameterName = "@tran_cd";
                    spParam[1].SqlDbType = SqlDbType.Int;
                    spParam[1].Value = tran_cd;

                    spParam[2] = new SqlParameter();
                    spParam[2].ParameterName = "@isWhat";
                    spParam[2].SqlDbType = SqlDbType.VarChar;
                    spParam[2].Value = "AC";

                    tranacdet_vw = dataAcess.ExecuteDataTable("sp_ent_web_tranview_nested_query", spParam,connHandle);

                    ((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel2")).Enabled = true;
                    GridView findAcGrid = ((GridView)((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel2")).FindControl("grdAcDetails"));
                    findAcGrid.DataSource = tranacdet_vw;
                    findAcGrid.DataBind();
                    SessionProxy.TranAcDetView = tranacdet_vw;
                    tranacdet_vw.Dispose();
                }
                else
                {
                    ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                    ((TabPanel)((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel2")).Enabled = false;
                }
                findBtn.ImageUrl = "~/Images/minus.gif";
                findBtn.AlternateText = "-";
                dataAcess.Connclose(connHandle);
            }
            else
            {
                ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                ((TabContainer)grdview.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = false;
                findBtn.ImageUrl = "~/Images/plus.gif";
                findBtn.AlternateText = "+";
            }

            lcode_vw.Dispose();
        }

        protected void lnkBtnAddNew_Click(object sender, EventArgs e)
        {
            string strLink = "vuTransactionEntry.aspx?pcvtype=" + DBPropsSession.PcvType.Trim() + 
                    "&behave=" + DBPropsSession.Behave.Trim() + "&addMode=true&editMode=false";

            SessionProxy.DbProperties.Dispose();
            SessionProxy.MainQueryString = null;
            SessionProxy.LikeInitQuery = null;
            SessionProxy.ViewTranView = null;
            SessionProxy.LcodeView = null;
            SessionProxy.TranItDetView = null;
            SessionProxy.TranAcDetView = null;
            SessionProxy.RStatusView = null;

            Server.Transfer(strLink);

        }

        protected void lnkAll_Click(object sender, EventArgs e)
        {
            System.Drawing.ColorConverter colConvert = new System.Drawing.ColorConverter();
            for (int i = 0; i < grdview.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                chkSelect.Checked = true;
                grdview.Rows[i].BackColor = (System.Drawing.Color)colConvert.ConvertFromString("#fafad2");
                grdview.Rows[i].ForeColor = (System.Drawing.Color)colConvert.ConvertFromString("Red");
            }
        }

        protected void lnkNone_Click(object sender, EventArgs e)
        {
            System.Drawing.ColorConverter colConvert = new System.Drawing.ColorConverter();
            for (int i = 0; i < grdview.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                chkSelect.Checked = false;
                grdview.Rows[i].BackColor = (System.Drawing.Color)colConvert.ConvertFromString("#f5f5f5");
                grdview.Rows[i].ForeColor = (System.Drawing.Color)colConvert.ConvertFromString("black");

            }
        }

        public string HighlightText(string InputTxt)
        {
            if (txtSearch.Text != "")
                SearchString = txtSearch.Text.Trim();

            if (SearchString == "")
            {
                return InputTxt;
            }
            else
            {
                System.Text.RegularExpressions.Regex ResultStr;
                ResultStr = new System.Text.RegularExpressions.Regex(SearchString.Replace(" ", "|"), System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return ResultStr.Replace(InputTxt, new System.Text.RegularExpressions.MatchEvaluator(this.ReplaceWords));
            }
        }

        public string ReplaceWords(System.Text.RegularExpressions.Match m)
        {
            return "<span class=highlight>" + m.ToString() + "</span>";
        }

        private void bindGridView()
        {
            grdview.DataBind();  
        }
        #endregion

        protected void btnGOSearch_Click(object sender, EventArgs e)
        {
            bindGridView(); 
        }

        protected void btnPrint_Click(object sender, EventArgs e)
        {
            string strPrintCond = " tran_cd in(";
            string tranValue = "";
            bool isSelect = false;
            DataTable lcode_vw = SessionProxy.LcodeView;
            DataTable RStatus_vw = SessionProxy.RStatusView;

            for (int i = 0; i < grdview.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    if (tranValue != "")
                        tranValue += "," + grdview.DataKeys[i].Values[1].ToString().Trim();
                    else
                        tranValue += grdview.DataKeys[i].Values[1].ToString().Trim();

                    isSelect = true;
                }
            }

            if (isSelect == false)
            {
                DisplayMessage(" Please Select atleast one transaction.. ");
                return;
            }


            SqlParameter[] spParam = new SqlParameter[2];
            spParam[0] = new SqlParameter();
            spParam[0].ParameterName = "@group";
            spParam[0].SqlDbType = SqlDbType.VarChar;
            spParam[0].Value = Convert.ToString(lcode_vw.Rows[0]["Code_nm"]).Trim();

            spParam[1] = new SqlParameter();
            spParam[1].ParameterName = "@repnm";
            spParam[1].SqlDbType = SqlDbType.VarChar;
            spParam[1].Value = Convert.ToString(lcode_vw.Rows[0]["repo_nm"]).Trim();

            DataTier dataAcess = new DataTier();
            dataAcess.DataBaseName = SessionProxy.DbName;

            RStatus_vw = dataAcess.ExecuteDataTable("sp_ent_web_tranview_print", spParam,connHandle);
            dataAcess.Connclose(connHandle);
            foreach (DataRow RStat_Row in RStatus_vw.Select("desc = '' and rep_nm = ''"))
            {
                RStat_Row.Delete();
            }
            RStatus_vw.AcceptChanges();

            if (RStatus_vw.Rows.Count > 1)
            {
                pnlPrint.Visible = true;
                grdPrintDialog.DataSource = RStatus_vw;
                grdPrintDialog.DataBind();

                System.Drawing.ColorConverter colConvert = new System.Drawing.ColorConverter();
                for (int i = 0; i < grdview.Rows.Count; i++)
                {
                    CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                    if (chkSelect.Checked == true)
                    {
                        grdview.Rows[i].BackColor = (System.Drawing.Color)colConvert.ConvertFromString("#fafad2");
                        grdview.Rows[i].ForeColor = (System.Drawing.Color)colConvert.ConvertFromString("Red");
                    }
                }

            }
            else
            {
                if (RStatus_vw.Rows.Count == 0)
                {
                    DisplayMessage("No Report found...!!!!");
                }
                else
                {
                    strPrintCond += tranValue.Trim() + ")";

                    pnlPrint.Visible = false;
                    try
                    {
                        DataRow rStatusRow = RStatus_vw.Rows[0];
                        if (Convert.ToString(rStatusRow["SqlQuery"]).Trim() == "")
                            throw new Exception("Cannot run Report,Query is blank in Report Wizard Master");
                        else
                            if (Convert.ToString(rStatusRow["retTable"]).Trim() == "")
                                throw new Exception("Cannot run Report,Temp Tablename is blank in Report Wizard Master");
                            else
                                if (Convert.ToString(rStatusRow["QTable"]).Trim() == "")
                                    throw new Exception("Cannot run Report,Main Tablename is blank in Report Wizard Master");

                        string repSqlStr = "";
                        if (Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("EXECUTE") >= 0)
                        {
                            string pCond1 = "";
                            string pCond2 = "";
                            repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).ToUpper().Trim().Substring(0, Convert.ToString(rStatusRow["SqlQuery"]).Trim().LastIndexOf(';'));
                            pCond1 = Convert.ToString(rStatusRow["QTable"]).Trim() + ".entry_ty ='" +
                                     DBPropsSession.PcvType.Trim() + "'";

                            pCond2 = Convert.ToString(rStatusRow["QTable"]).Trim() + "." + strPrintCond.Trim();
                            repSqlStr = repSqlStr.Trim() + ' ' + '"' + pCond1 + " and " + pCond2 + '"';
                        }
                        else
                        {
                            string pCond = Convert.ToString(rStatusRow["QTable"]).Trim() +
                                           ".entry_ty = '" + DBPropsSession.PcvType.Trim() + "'" +
                                           " and " + Convert.ToString(rStatusRow["QTable"]).Trim() + "." + strPrintCond.Trim();

                            repSqlStr = Convert.ToString(rStatusRow["SqlQuery"]).Trim();
                            int whPos = Convert.ToString(rStatusRow["SqlQuery"]).Trim().ToUpper().IndexOf("WHERE");

                            if (whPos >= 0)
                            {
                                repSqlStr = repSqlStr.Trim().Substring(0, whPos + 5) + " " +
                                            pCond.Trim() + " and " + repSqlStr.Trim().Substring(whPos + 6);
                            }
                            else
                                repSqlStr = repSqlStr + " WHERE " + pCond.Trim();

                        }

                        if (repSqlStr.Trim() != "")
                        {
                            getCompany GetCompany = new getCompany();
                            DataTable Company = SessionProxy.Company; 
                            string cFileName = Server.MapPath(".") + "\\" + Convert.ToString(Company.Rows[0]["dir_nm"]).Trim() + "\\Reports\\" + Convert.ToString(rStatusRow["rep_nm"]).Trim() + ".rpt";
                            if (File.Exists(cFileName) == false)
                            {
                                cFileName = Server.MapPath(".") + "\\Reports\\" + Convert.ToString(rStatusRow["rep_nm"]).Trim() + ".rpt";
                            }
                            Company.Dispose();
                            Company = null;
                            if (!System.IO.File.Exists(cFileName))
                            {
                                System.Drawing.ColorConverter colConvert = new System.Drawing.ColorConverter();
                                for (int i = 0; i < grdview.Rows.Count; i++)
                                {
                                    CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                                    if (chkSelect.Checked == true)
                                    {
                                        grdview.Rows[i].BackColor = (System.Drawing.Color)colConvert.ConvertFromString("#fafad2");
                                        grdview.Rows[i].ForeColor = (System.Drawing.Color)colConvert.ConvertFromString("Red");
                                    }
                                }

                                throw new Exception(cFileName.Trim() + " Report file not found ...!!");
                            }

                            repSqlStr.Replace("REPORT HEADER", Convert.ToString(rStatusRow["desc"]).Trim());
                            SessionProxy.MainQueryString = repSqlStr.Trim();
                            SessionProxy.ReportPath = cFileName.Trim();
                            //Session["RepName"] = Convert.ToString(rStatusRow["rep_nm"]).Trim();
                            SessionProxy.ReportDataSet = null;
                            //Session["ReportDataSet"] = null;
                        }

                        string strOpenWin = "";
                        //strOpenWin = "open_window_max('uwCRViewer.aspx','Report');";
                        strOpenWin = "open_window_max('ueCrystalHomePage.aspx','Report');";
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "openWindow()", strOpenWin, true);

                        System.Drawing.ColorConverter colConvert1 = new System.Drawing.ColorConverter();
                        for (int i = 0; i < grdview.Rows.Count; i++)
                        {
                            CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                            if (chkSelect.Checked == true)
                            {
                                grdview.Rows[i].BackColor = (System.Drawing.Color)colConvert1.ConvertFromString("#fafad2");
                                grdview.Rows[i].ForeColor = (System.Drawing.Color)colConvert1.ConvertFromString("Red");
                            }
                        }

                    }
                    catch (Exception EX)
                    {
                        DisplayMessage(EX.Message);
                    }
                }
            }
            SessionProxy.RStatusView = RStatus_vw;  
            RStatus_vw.Dispose();
            lcode_vw.Dispose();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string strDeleteCond = " tran_cd in(";
            string tranValue = "";
            bool isSelect = false;
            numericFunction numFunction = new numericFunction();
            DataTier dataAcess = new DataTier();
            dataAcess.DataBaseName = SessionProxy.DbName;
   
            for (int i = 0; i < grdview.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)grdview.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    if (tranValue != "")
                        tranValue += "," + grdview.DataKeys[i].Values[1].ToString().Trim();
                    else
                        tranValue += grdview.DataKeys[i].Values[1].ToString().Trim();

                    isSelect = true;
                }
            }

            if (isSelect == false)
            {
                DisplayMessage(" Please Select atleast one transaction.. ");
                return;
            }

            strDeleteCond += tranValue.Trim() + ")";

            if (isSelect == true)
            {
                string sqlStr = "";
                if (DBPropsSession.Vchkprod.IndexOf("vutex") >= 0 ||
                    DBPropsSession.Vchkprod.IndexOf("vuexc") >= 0)
                {
                    sqlStr = "select entry_ty,tran_cd,date,inv_no,u_sinfo, " +
                        "l_yn,inv_sr,u_sinfo,[rule] from " + DBPropsSession.Entry_Tbl.Trim() +
                        "main where " + strDeleteCond.Trim();
                }
                else
                {
                    sqlStr = "select entry_ty,tran_cd,date,inv_no," +
                        "l_yn,inv_sr,[rule] from " + DBPropsSession.Entry_Tbl.Trim() +
                        "main where " + strDeleteCond.Trim();
                }

                DataTable main_vw = dataAcess.ExecuteDataTable(sqlStr, "_main",connHandle);
                getCompany GetCompany = new getCompany();
                DataTable Company = GetCompany.Company(SessionProxy.ReqCode.Trim()
                    , SessionProxy.FinYear.Trim());
                DataTable lcode_vw = SessionProxy.LcodeView;
                DataTable acdet_vw = null;

                foreach (DataRow mainRow in main_vw.Rows)
                {
                    string retMess = "";
                    try
                    {
                        if (DBPropsSession.AccountPage == true || DBPropsSession.AllocationPage == true)
                        {
                            sqlStr = "select * from " + DBPropsSession.Entry_Tbl.Trim() +
                                     "acdet where tran_cd = " + numFunction.toInt32(mainRow["tran_cd"]);

                            acdet_vw = dataAcess.ExecuteDataTable(sqlStr, "acdet",connHandle);
                        }

                        vuTransactionevent TransactionEvent = new vuTransactionevent();
                        //TransactionEvent.PageCustProps = DBPropsSession;
                        retMess = TransactionEvent.DeletePreValidation(mainRow,
                            acdet_vw);

                        if (retMess.Trim() != "")
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "ConfirmMessWithPostBack('" + retMess.Trim() + "','" + btnDelete.ClientID + "');", true);
                            return;
                        }
                        else
                        {
                            TransactionEvent.DoDelete(mainRow,
                                lcode_vw,
                                Company,
                                acdet_vw);
                        }
                    }
                    catch (Exception EX)
                    {
                        DisplayMessage(EX.Message);
                    }
                }

                lcode_vw.Dispose();
                if (acdet_vw != null)
                    acdet_vw.Dispose();

                main_vw.Dispose();

                sqlStr = Convert.ToString(SessionProxy.ViewInitQuery.Trim());
                //sqlStr += " from " + SessionProxy.PageCustomProps.Entry_Tbl.Trim() + "main";
                //DataTable tran_vw = dataAcess.ExecuteDataTable(sqlStr, "tran_vw");
                dataAcess.Connclose(connHandle);
                //SessionProxy.ViewTranView = tran_vw;

                bindGridView();

            }

            if (isSelect == false)
            {
                DisplayMessage(" Please Select atleast one transaction.. ");
                return;
            }

        }

        protected void ObjectDataSource1_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            e.InputParameters["trantype"] = DBPropsSession.PcvType;
            e.InputParameters["searchtext"] = txtSearch.Text.Trim();
            string strSort = "[date] asc";
            if (null != m_strSortExp &&
                String.Empty != m_strSortExp)
            {
                strSort = String.Format("{0} {1}", m_strSortExp, (m_SortDirection == SortDirection.Descending) ? "DESC" : "ASC");
            }
            e.InputParameters["sortBytext"] = strSort;
        }
    }

    public class GetTransactionData : BasePage
    {
        private static int totalRec;
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();

        [DataObjectMethod(DataObjectMethodType.Select)]
        public List<TransactionList> GetAllRows(int startIndex,
                    int pageSize,
                    string sortBy,
                    string trantype,
                    string searchtext,
                    string sortBytext)
        {
            List<TransactionList> result = null;
            try
            {
                //PageCustomProperties PageCustomProps = new PageCustomProperties();
                boolFunction bitFunction = new boolFunction();
                TransactionData TransDataBLL = new TransactionData();
                


                totalRec = 0;
                DataTable lcode_vw = new DataTable();
                DataTable colParam = new DataTable();

                if (string.IsNullOrEmpty(sortBy))
                    sortBytext = "date desc";
                result = TransDataBLL.GetAllRows(startIndex, pageSize, sortBytext,
                            trantype, searchtext, ref totalRec, ref lcode_vw, ref colParam);
                SessionProxy.LcodeView = lcode_vw;

                // Set Page Global Properties
                if (lcode_vw.Rows[0]["bcode_nm"].ToString().Trim() == "")
                {
                    DBPropsSession.Behave = lcode_vw.Rows[0]["entry_ty"].ToString().Trim();
                }
                else
                {
                    DBPropsSession.Behave = lcode_vw.Rows[0]["bcode_nm"].ToString().Trim();
                }

                DBPropsSession.Entry_Tbl = DBPropsSession.PcvType.Trim();
                DBPropsSession.AccountPage = bitFunction.toBoolean(lcode_vw.Rows[0]["v_account"]);
                DBPropsSession.ChargesPage = bitFunction.toBoolean(lcode_vw.Rows[0]["v_disc"]);
                DBPropsSession.IchargesPage = bitFunction.toBoolean(lcode_vw.Rows[0]["i_disc"]);

                if (DBPropsSession.AccountPage == true)
                {
                    DBPropsSession.AllocationPage = true;
                }

                DBPropsSession.AinfoPage = bitFunction.toBoolean(lcode_vw.Rows[0]["v_extra"]);
                DBPropsSession.TdsPage = false;

                if (DBPropsSession.PcvType == "EP" || DBPropsSession.PcvType == "BP" || DBPropsSession.PcvType == "CP")
                    DBPropsSession.TdsPage = true;

                DBPropsSession.ServiceTaxPage = false;

                if (DBPropsSession.PcvType == "IS" || DBPropsSession.PcvType == "SB")
                {
                    DBPropsSession.ServiceTaxPage = true;
                }

                if (bitFunction.toBoolean(lcode_vw.Rows[0]["v_item"]) == true)
                {
                    if (bitFunction.toBoolean(SessionProxy.Company.Rows[0]["inv_op"]) == false && bitFunction.toBoolean(SessionProxy.Company.Rows[0]["bill_inven"]) == false)
                    {
                        DBPropsSession.ItemPage = false;
                    }
                    else
                    {
                        DBPropsSession.ItemPage = true;
                    }
                }

                if (bitFunction.toBoolean(colParam.Rows[0]["dept"]))
                    DBPropsSession.ColDept = true;
                else
                    DBPropsSession.ColDept = false;

                if (bitFunction.toBoolean(colParam.Rows[0]["cate"]))
                    DBPropsSession.ColCate = true;
                else
                    DBPropsSession.ColCate = false;

                if (bitFunction.toBoolean(colParam.Rows[0]["series"]))
                    DBPropsSession.ColSeries = true;
                else
                    DBPropsSession.ColSeries = false;

                if (bitFunction.toBoolean(colParam.Rows[0]["rule"]))
                    DBPropsSession.ColRule = true;
                else
                    DBPropsSession.ColRule = false;

                if (bitFunction.toBoolean(colParam.Rows[0]["banknm"]))
                    DBPropsSession.ColBankNm = true;
                else
                    DBPropsSession.ColBankNm = false;

                if (bitFunction.toBoolean(colParam.Rows[0]["uinvnodt"]))
                    DBPropsSession.ColUInvnodt = true;
                else
                    DBPropsSession.ColUInvnodt = false;

                // End
            }
            catch (Exception EX)
            {
                DisplayMessage(EX.Message.Trim());
            }
            
            return result;
        }

        public static int GetTotalRecCount(string trantype, string searchtext,string sortBytext)
        {
            return totalRec;
        }
    }
}
