 function pageLoad() 
 { 
    $find('AutoCompleteEx').add_populated(shownev); //if no result, this event will not be triggered and loading can't be hidden. But if result is exist, hiding event will be triggered when the user selects value to hide popup list.So we need populated event to hide loading when the result is not empty.
    $find('AutoCompleteEx').add_populating(populatingev);
    $find('AutoCompleteEx').add_hiding(onhiding); // no matter the result is empty or not, hiding event will be triggered. If the result is empty, it will trigger hiding event after response returned. If the result is exist, hiding event will be triggered after user selected value to hide popuplist.    
    try
    {
        $find('autocompxtenderitem').add_populated(shownevitem); //if no result, this event will not be triggered and loading can't be hidden. But if result is exist, hiding event will be triggered when the user selects value to hide popup list.So we need populated event to hide loading when the result is not empty.
        $find('autocompxtenderitem').add_populating(populatingevitem);
        $find('autocompxtenderitem').add_hiding(onhiding); // no matter the result is empty or not, hiding event will be triggered. If the result is empty, it will trigger hiding event after response returned. If the result is exist, hiding event will be triggered after user selected value to hide popuplist.    
    }
    catch (err) { }
 }
     
 function shownevitem() 
{
    var progress = $get('divItemProgress');
    progress.style.display= 'none';

}

function populatingevitem() 
{
    var progress = $get('divItemProgress');
    progress.style.display= 'block';
}

    function onhiding() 
{
  var progress = $get('DivPartyProgress');
  progress.style.display= 'none';
}

function onhidingitem() 
{
  var progress = $get('divItemProgress');
  progress.style.display= 'none';
}

function shownevitem() 
{
    var progress = $get('divItemProgress');
    progress.style.display= 'none';

}

function populatingevitem() 
{
    var progress = $get('divItemProgress');
    progress.style.display= 'block';
}
