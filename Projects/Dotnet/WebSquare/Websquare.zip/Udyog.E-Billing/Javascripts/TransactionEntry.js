    function Objvalidation(ObjTxt,ObjValue,ObjAlertMess)
    {
       
        var txtValue=document.getElementById(ObjTxt).value;
        if (txtValue == ObjValue)
        {            
           alert(ObjAlertMess);
           return false;
        }
    }
    
    
    
    
    function calAssValue()
    {
        alert(parseFloat(document.getElementById("<%=txtitqty.clientId%>").value)*parseFloat(document.getElementById("<%=txtitrate.clientId%>").value));
        var txtValue=parseFloat(document.getElementById("<%=txtitqty.clientId%>").value)*parseFloat(document.getElementById("<%=txtitrate.clientId%>").value);
        document.getElementById("<%=txtitrate.clientId%>").value=parseFloat(document.getElementById("<%=txtitrate.clientId%>").value).toFixed(2);
        document.getElementById("<%=txtitamt.clientId%>").value=txtValue.toFixed(2);
    }
    
         
    function CalQuantityP()
    {
       if(document.getElementById("<%=txtCarton.clientId%>").value=="")
       {
            document.getElementById("<%=txtCarton.clientId%>").value=0;
       }
       
       if (document.getElementById("<%=txtCarton.clientId%>").value > 0)
       {
           var txtValue= parseFloat(document.getElementById("<%=txtCarton.clientId%>").value)*parseFloat(document.getElementById("<%=txtQtyCar.clientId%>").value);
           document.getElementById("<%=txtitqty.clientId%>").value=txtValue.toFixed(2);
       
           var ItQty  = parseFloat(document.getElementById("<%=txtitqty.clientId%>").value);
       
            if (ItQty == 0 | ItQty == null)
            {
                alert(" 0 Qty not allowed");
                return false;
            }
           
       }
    }
    
    function CalQuantityS()
    {
        alert(document.getElementById("<%=txtCarton.clientId%>").value);
       if(document.getElementById("<%=txtCarton.clientId%>").value=="")
       {
            document.getElementById("<%=txtCarton.clientId%>").value=0;
       }
       
       if (document.getElementById("<%=txtCarton.clientId%>").value > 0)
       {
           var txtValue= parseFloat(document.getElementById("<%=txtCarton.clientId%>").value)*parseFloat(document.getElementById("<%=txtQtyCar.clientId%>").value);
           document.getElementById("<%=txtitqty.clientId%>").value=txtValue.toFixed(2);
       
           var BalQty = parseFloat(document.getElementById("<%=hidbalqty.clientId%>").value);
           var ItQty  = parseFloat(document.getElementById("<%=txtitqty.clientId%>").value);
       
           if (ItQty > BalQty)
           {
                alert( BalQty + " Stock is avaliable for this Item");
                document.getElementById("<%=txtitqty.clientId%>").value=0.00;
                return false;
           }
           else
           {
                if (ItQty == 0 | ItQty == null)
                {
                    alert(" 0 Qty not allowed");
                    return false;
                }
           }
           
       }
    }

    function StockValidation()    
    {
       
       var BalQty = parseFloat(document.getElementById("<%=hidbalqty.clientId%>").value);
       var ItQty  = parseFloat(document.getElementById("<%=txtitqty.clientId%>").value);
       if (ItQty > BalQty)
       {
            alert( BalQty + " Stock is avaliable for this Item");
            document.getElementById("<%=txtitqty.clientId%>").value=0.00;
            return false;
       }
       else
       {
            if (ItQty == 0 | ItQty == null)
            {
                alert(" 0 Qty not allowed");
                return false;
            }
       }
    }
    
    function disCharges_PerRemove(perTxt,amtTxt)
    {
       
       var ChargesAmt  = parseFloat(document.getElementById(amtTxt).value);
       if (ChargesAmt > 0)
       {
            document.getElementById(perTxt).value=0.00;
            return false;
       }
    }
                
    function chargeGridAmt(currtxt,nexttxt,abntAmt)
    {
        if(parseFloat(document.getElementById(currtxt).value)==0)
        {
            document.getElementById(nexttxt).disabled=false;
        }
        else
        {
            document.getElementById(nexttxt).disabled=true;
        }
        var netAmt=parseFloat(document.getElementById("<%=hidDateValid.clientID%>").value);
        document.getElementById(nexttxt).value= (((netAmt - parseFloat(abntAmt)) * parseFloat(document.getElementById(currtxt).value))/100).toFixed(2);
        document.getElementById(currtxt).value=parseFloat(document.getElementById(currtxt).value).toFixed(2);  
    }
    
    function tabPanelDisabled(tabClientId,tabWhat)
    {
        var clientId=tabClientId;
        ctlId='__tab_'+ctlId;
        if (tabWhat = 'T')
        {
            $get(ctlId).disabled=true;
        }
        else
        {
            $get(ctlId).disabled=false;
        }
    }
    
   function OpenDialog(wName,winSettings,objHiddClose,objbtnClick)
   {
        // get the control values
        alert(wName);
	    var str1 = wName;
	    // create an array with the values
	    var winArgs = new Array(str1);
	    //var winSettings = 'center:yes;resizable:no;help:no;'
	    //	+ 'status:no;dialogWidth:700px;dialogHeight:500px';
	
        if (winSettings == '')
        {	    
	        var winSettings = 'resizable:no;help:no;scrollbar:yes;'
		        + 'status:no;dialogWidth:800px;dialogHeight:345px;dialogLeft=10;dialogTop=225;';
	    }
        
	    //winArgs = window.showModalDialog(wName, winArgs, winSettings);
	    winArgs = window.showModalDialog(wName,winArgs,winSettings);
				
	    // see if the array is null
	    if(winArgs == null)
	    {
		    window.alert('no data returned!');
	    }
		else
	    {
		    // set the values from what's returned
		    alert("uday reached in test.js");
		    alert(winArgs[0]);
		    document.getElementById(objHiddClose).value = winArgs[0];
		    alert(document.getElementById(objHiddClose).value);
		    var btn = document.getElementById(objbtnClick);
            if (btn != null)
            { //If we find the button click it
                    btn.click();
                    //event.keyCode = 0
            }
		}
	}	
	
	function narrMess(alertMess)
	{
	    if(confirm(alertMess))
        {
           document.getElementById("<%=hidDateValid.clientID%>").value="1";
        }
        else
        {
            document.getElementById("<%=hidDateValid.clientID%>").value="0";
            return false;
        }
    }
    
    function updateHiddenField(objHidden,objValue,objBtn)
    {
        
        if (document.getElementById(objHidden).value !=  document.getElementById(objValue).value)
        {
            document.getElementById(objHidden).value =  document.getElementById(objValue).value
        }
        alert(document.getElementById(objHidden).value);
        //document.getElementById(objHidden).select();
        //if (objBtn != null)
        //{
         //   var Btn = document.getElementById(objBtn);
          //  Btn.click(); 
        //}
    }
    
    function DoPostBack()
    {        
        __doPostBack("numTxtBox", "TextChanged");
    }  
    

    
            
    function HideProgress(divId)
    {
        var progress = $get('progress');
        progress.style.visibility = 'hidden';
        var isGridRun = $get(divId);  
        var isGridExpand = $get('gridExpand');  
        isGridExpand.title = isGridRun.id;
    }
    
    
   