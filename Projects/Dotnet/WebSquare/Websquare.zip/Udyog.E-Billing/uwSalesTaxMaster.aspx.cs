using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using Business.Logic.Layer;
namespace Udyog.E_Billing
{
    public partial class uwSalesTaxMaster : System.Web.UI.Page
    {
        DataTier DataAccess;
        //private static bool AddMode;
        //private static bool EditMode;
        //private static string Staxid;

        SqlDataReader dr;
        private string SqlStr = "";
        private SqlConnection connHandle;

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }

        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private string staxid;
        public string Staxid
        {
            get { return staxid; }
            set { staxid = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            DataAccess = new DataTier();
            DataSet STaxDataset = new DataSet();
            if (IsPostBack == true)
            {

                STaxDataset = (DataSet)Session["STaxDataset"];
                if (STaxDataset.Tables["lother"].Rows.Count > 0)
                {
                    DataView xtra_vw = STaxDataset.Tables["lother"].DefaultView;
                    xtra_vw.Sort = "";
                    vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                    try
                    {
                        vuAddInfo.genControls(xtra_vw,
                                STaxDataset.Tables["SalesView"].Rows[0], tblAddInforDetails);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                    tdAddInfo.Visible = true;
                }
                if (STaxDataset.Tables["lcode"].Rows.Count > 0)
                {
                    DataView xtra_vw = STaxDataset.Tables["lcode"].DefaultView;
                    xtra_vw.Sort = "";
                    VuchkTransaction vuchkTrans = new VuchkTransaction();
                    try
                    {
                        vuchkTrans.genChkControls(xtra_vw,
                        STaxDataset.Tables["SalesView"].Rows[0], tblodeDetails);

                        if (txtValidIn.Text != "")
                        {
                            vuchkTrans.btnClick(tblodeDetails, null, "UNBOXING", Convert.ToString(txtValidIn.Text));
                        }
                    }

                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                    

                }
                else
                {
                    tdLcode.Visible = false;
                }

                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                Staxid = Convert.ToString(Request.QueryString["Staxid"]);

                return;
            }


            AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
            EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
            Staxid = Convert.ToString(Request.QueryString["Staxid"]);

            lbltrType.Text = "SalesTax Master";
            if (AddMode == true)
            {
                addRecord(ref STaxDataset);
            }
            else
            {
                if (EditMode == true)
                {
                    editRecord(Staxid, ref STaxDataset);
                }
            }
            SqlStr = "Select * from lother where e_code='WM' order by serial";
            STaxDataset = DataAccess.ExecuteDataset(STaxDataset, SqlStr, "lother",connHandle);
            DataAccess.Connclose(connHandle);

            if (STaxDataset.Tables["lother"].Rows.Count > 0)
            {
                DataView xtra_vw = STaxDataset.Tables["lother"].DefaultView;
                xtra_vw.Sort = "Serial";
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.genControls(xtra_vw,
                            STaxDataset.Tables["SalesView"].Rows[0], tblAddInforDetails);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
                tdAddInfo.Visible = true;

            }
            SqlStr = "Select * from lcode";
            STaxDataset = DataAccess.ExecuteDataset(STaxDataset, SqlStr, "lcode",connHandle);
            DataAccess.Connclose(connHandle);
            if (STaxDataset.Tables["lcode"].Rows.Count > 0)
            {
                DataView xtra_vw = STaxDataset.Tables["lcode"].DefaultView;
                xtra_vw.Sort = "cd";
                VuchkTransaction vuchkTrans = new VuchkTransaction();
                try
                {
                    vuchkTrans.genChkControls(xtra_vw,
                       STaxDataset.Tables["SalesView"].Rows[0], tblodeDetails);

                    if (txtValidIn.Text != "")
                    {
                        vuchkTrans.btnClick(tblodeDetails, null, "UNBOXING", Convert.ToString(txtValidIn.Text));
                    }
                }

                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
                tdLcode.Visible = true;
            }
            else
            {
                tdLcode.Visible = false;
            }

            Session["STaxDataset"] = STaxDataset;
            STaxDataset.Dispose();

        }
        protected void addRecord(ref DataSet STaxDataset)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            DataAccess = new DataTier();
            boolFunction bitFunction = new boolFunction();
            getDateFormat dateformate = new getDateFormat();
            numericFunction numFunction = new numericFunction();
            getCompany company = new getCompany();
            DataTable comp = company.Company(Session["ReqCode"].ToString().Trim(),Session["Finyear"].ToString().Trim());
            //SalesMastRow["level1"] = 0;
            SqlStr = "select * from stax_mas where 1=2";
            STaxDataset = DataAccess.ExecuteDataset(STaxDataset, SqlStr, "SalesView",connHandle);
            DataAccess.Connclose(connHandle);  
            DataRow SalesMastRow = STaxDataset.Tables["SalesView"].NewRow();
            DataNullUpdate.NullUpdate(SalesMastRow);
            STaxDataset.Tables["SalesView"].Rows.Add(SalesMastRow);
            STaxDataset.Tables["SalesView"].AcceptChanges();
            
            txtSTNm.Text = Convert.ToString(SalesMastRow["tax_name"]).Trim();
            txtTobIssue.Text = Convert.ToString(SalesMastRow["form_nm"]);
            txtToBReceivd.Text = Convert.ToString(SalesMastRow["rform_nm"]);
            chkIncldval.Checked = bitFunction.toBoolean(SalesMastRow["stkval"]);                       
            chkDeActv.Checked = bitFunction.toBoolean(SalesMastRow["ldeactive"]);
            txtToDeAct.Text = DateTime.Now.Date.ToString();
            txtValidIn.Text = Convert.ToString(SalesMastRow["validity"]);
            txtFromdt.Text = dateformate.dateformatBR(Convert.ToString(comp.Rows[0]["sta_dt"]));
            txtTodt.Text = dateformate.dateformatBR(Convert.ToString(comp.Rows[0]["end_dt"]));
            
            ScriptManager1.SetFocus(txtTranType);

        }
        protected void Validation(ref DataSet STaxDataset)
        {
            getDateFormat DateFormat = new getDateFormat();
            STaxDataset = (DataSet)Session["STaxDataset"];
            if (Convert.ToDateTime(STaxDataset.Tables["SalesView"].Rows[0]["wefstkfrom"]) > Convert.ToDateTime(STaxDataset.Tables["SalesView"].Rows[0]["wefstkto"]))
            {
                throw new Exception("FromDate Cannot Be Greater than ToDate");
            }
            else
            {
                if (Convert.ToDateTime(STaxDataset.Tables["SalesView"].Rows[0]["wefstkfrom"]) == Convert.ToDateTime(STaxDataset.Tables["SalesView"].Rows[0]["wefstkto"]))
                {
                    throw new Exception("FromDate And ToDate Cannot Be Same");
                }
            }
        }

        protected void editRecord(string Staxid, ref DataSet STaxDataset)
        {
            DataAccess = new DataTier();
            SqlStr = "select * from stax_mas where tax_name ='" + Staxid + "'";
            STaxDataset = DataAccess.ExecuteDataset(STaxDataset, SqlStr, "SalesView",connHandle);
            DataAccess.Connclose(connHandle);
            bindControl(STaxDataset.Tables["SalesView"].Rows[0], true);

            if (EditMode == true)
            {
                txtTranType.Enabled = false;

            }

        }
        protected void bindControl(DataRow SalesMastRow, bool istrue)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();
            SqlStr = "select code_nm from lcode where cd='" + SalesMastRow["entry_ty"] + "'";
            dr = DataAccess.ExecuteDataReader(SqlStr, ref connHandle);
            //string str = "";
            if (dr.HasRows == true)
            {
                while (dr.Read())
                {
                    txtTranType.Text = Convert.ToString(dr["code_nm"]);
                }
            }
            dr.Close();
            DataAccess.Connclose(connHandle);
            
            txtSTNm.Text = Convert.ToString(SalesMastRow["tax_name"]).Trim();
            txtPerc.Text = Convert.ToString(SalesMastRow["level1"]);
            if (Convert.ToString(SalesMastRow["ac_name1"]).Trim() != "")
            {
                string accountName = Convert.ToString(SalesMastRow["ac_name1"]).Trim();
                accountName = accountName.Remove(accountName.IndexOf('"'), 1);
                accountName = accountName.Remove(accountName.LastIndexOf('"'), 1);
                txtACNm.Text = accountName.Trim();
            }
            else
            {
                txtACNm.Text = "";
            }            
            txtTobIssue.Text = Convert.ToString(SalesMastRow["form_nm"]).Trim();
            txtToBReceivd.Text = Convert.ToString(SalesMastRow["rform_nm"]).Trim();
            chkIncldval.Checked = bitFunction.toBoolean(SalesMastRow["stkval"]);
            txtFromdt.Text = Convert.ToString(SalesMastRow["wefstkfrom"]);
            txtTodt.Text = Convert.ToString(SalesMastRow["wefstkto"]);
            chkDeActv.Checked = Convert.ToBoolean(SalesMastRow["ldeactive"]);
            txtToDeAct.Text = Convert.ToString(SalesMastRow["deactfrom"]).Trim();
            txtValidIn.Text = Convert.ToString(SalesMastRow["validity"]);         

        }

        protected void btnTopSave_Click(object sender, EventArgs e)
        {
            if (IsValid == true)
            {
                try
                {
                    Save(); // call Save Method
                    tblError.Visible = false;
                    Response.Redirect("uwSalesTaxMasterView.aspx?ShowStatus=true");

                }
                catch (Exception Ex)
                {
                    tblError.Visible = true;
                    lblErrorItHeading.Text = "Please Check Error details below";
                    lblErrorItHeading.Text = Ex.Message;
                }
            }
        }
        protected void Save()
        {
            try
            {
                DataSet STaxDataset = (DataSet)Session["STaxDataset"];
                BindSave(ref STaxDataset);
                Validation(ref STaxDataset);
                numericFunction numFunction = new numericFunction();
                if (EditMode == true)
                {
                    SqlStr = DataAccess.GenUpdateString(STaxDataset.Tables["SalesView"], "stax_mas",
                                                new string[] { "tax_name" }, null, "", new string[] { "tax_name" });
                }
                else
                {
                    if (AddMode == true)
                    {
                        SqlStr = DataAccess.GenInsertString(STaxDataset.Tables["SalesView"].Rows[0], "stax_mas",
                                                    new string[] { " " }, null);
                    }
                }
                if (SqlStr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(SqlStr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        DataAccess.CommitTransaction(cmd.Transaction);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        throw Ex;
                    }
                    finally
                    {
                        DataAccess.Connclose(connHandle);
                    }
                }
                STaxDataset.Dispose();
            }
            catch (Exception Ex)
            {
                throw Ex; 
                tblError.Visible = true;
                lblErrorItHeading.Text = "Please Check Error details below";
                lblErrorItHeading.Text = Ex.Message;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('" + Ex.Message + "');", true);
            }

        }
        protected void BindSave(ref DataSet STaxDataset)
        {
            if (AddMode == true && EditMode == false)
            {
                SqlStr = "select tax_name from stax_mas where tax_name='" + txtSTNm.Text + "'";
                DataTier DataAccess = new DataTier();
                dr = DataAccess.ExecuteDataReader(SqlStr, ref connHandle);
                if (dr.HasRows == true)
                {
                    dr.Close();
                    DataAccess.Connclose(connHandle);
                    throw new Exception("Name already exist in SalesTax Master");
                }
                dr.Close();
                DataAccess.Connclose(connHandle);
            }
            numericFunction numFunction = new numericFunction();
            boolFunction bitfunction = new boolFunction();
            DataTable lother = STaxDataset.Tables["Lother"];
            DataRow SalesMastRow = STaxDataset.Tables["SalesView"].Rows[0];

            if (txtTranType.Text != "")
            {
                DataAccess = new DataTier();
                SqlStr = "select cd  from lcode where code_nm ='" + txtTranType.Text + "'";
                dr = DataAccess.ExecuteDataReader(SqlStr, ref connHandle);
                string str1 = "";
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                    {
                        str1 = Convert.ToString(dr["cd"]);   
                    }
                }
                dr.Close();
                DataAccess.Connclose(connHandle);
                SalesMastRow["entry_ty"] = txtTranType.Text.Trim() != "" ? str1 : "";
            }

                
            
            SalesMastRow["tax_name"] = Convert.ToString(txtSTNm.Text);
            SalesMastRow["st_type"] = dropTaxTp.SelectedItem.ToString().Trim();
            SalesMastRow["level1"] = numFunction.toDecimal(txtPerc.Text);

            if (txtACNm.Text != "")
            {
                string accountName = '"' + txtACNm.Text.Trim() + '"';
                SalesMastRow["ac_name1"] = accountName.Trim();
            }
            SalesMastRow["form_nm"] = Convert.ToString(txtTobIssue.Text);
            SalesMastRow["rform_nm"] = Convert.ToString(txtToBReceivd.Text);
            SalesMastRow["stkval"] = bitfunction.toBoolean(chkIncldval.Checked);
            SalesMastRow["wefstkfrom"]  = Convert.ToDateTime(txtFromdt.Text);
            SalesMastRow["wefstkto"]  = Convert.ToDateTime(txtTodt.Text);
            if (chkDeActv.Checked == true)
            {
                SalesMastRow["deactfrom"] = Convert.ToDateTime(txtToDeAct.Text);
            }
            
            SalesMastRow["ldeactive"] = Convert.ToBoolean(chkDeActv.Checked);
            SalesMastRow["validity"] = Convert.ToString(txtValidIn.Text);
            if (lother.Rows.Count > 0)
            {
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.btnClick(tblAddInforDetails, SalesMastRow, "BOXING", null);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }

            SalesMastRow.AcceptChanges();
        }
        protected void lnkBtnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwSalesTaxMasterView.aspx");
        }

        protected void saveLcode()
        {
            DataSet STaxDataset = (DataSet)Session["STaxDataset"];
            DataTable lcode = STaxDataset.Tables["lcode"];
            if (lcode.Rows.Count > 0)
            {
                VuchkTransaction vulcode = new VuchkTransaction();
                try
                {
                    txtValidIn.Text = vulcode.btnClick(tblodeDetails, null, "", "");

                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }

        }


        protected void btnOk_Click(object sender, EventArgs e)
        {
            saveLcode();
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            CancelLcode();
        }
        protected void CancelLcode()
        {
            DataSet STaxDataset = (DataSet)Session["STaxDataset"];
            DataTable lcode = STaxDataset.Tables["lcode"];
            if (lcode.Rows.Count > 0)
            {
                VuchkTransaction vulcode = new VuchkTransaction();
                try
                {
                    if (txtValidIn.Text != "")
                    {
                        vulcode.btnClick(tblodeDetails, null, "Cancel", Convert.ToString(txtValidIn.Text));
                        txtValidIn.Text = "";
                    }
                    else
                    {
                        txtValidIn.Text = vulcode.btnClick(tblodeDetails, null, "Cancel", "");
                        txtValidIn.Text = "";
                    }
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }

        }
    }
}