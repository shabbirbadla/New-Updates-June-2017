using System;
using System.Data;
using System.Data.SqlClient; 
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using Business.Logic.Layer;
using AjaxControlToolkit;

namespace Udyog.E.Billing
{
    public partial class uwPriceMasterView : System.Web.UI.Page
    {
        private string sqlStr = "";
        private String m_strSortExp;
        private SortDirection m_SortDirection = SortDirection.Ascending;
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();    

        string SearchString = "";
        SqlConnection connHandle;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                m_strSortExp = "prcode";

                DataTable prlistview = new DataTable();
                sqlStr = "select cast(0 as bit) as [select], prlistcd,prcode," +
                         "(case prlistty when 'S' then 'Sales' when 'P' then 'Purchase' end) as prlistty from it_rate";

                DataTier DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName;
                prlistview = DataAccess.ExecuteDataTable(sqlStr, "_tmp",connHandle);
                DataAccess.Connclose(connHandle);
 
                Session["PriceListView"] = prlistview;
                prlistview.Dispose(); 
                bindGridView();

                lblTrType.Text = "Pricelist Master";
                txtSearch.Attributes.Add("onkeypress", "return OnKeyEnter();");
                txtSearch.Attributes.Add("onfocus", "select();");
                txtSearch.Focus();

                bool ShowStatus = Convert.ToBoolean(Request.QueryString["ShowStatus"]);

                if (ShowStatus == true)
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Sucessfully Saved.');", true);
            }
            else
            {
                if (null != ViewState["_SortExp_"])
                {
                    m_strSortExp = ViewState["_SortExp_"] as String;
                }

                if (null != ViewState["_Direction_"])
                {
                    m_SortDirection = (SortDirection)ViewState["_Direction_"];
                }
            }

        }

        private void bindGridView()
        {
            DataTable prlistview = (DataTable)Session["PriceListView"];
            String strSort = "prcode DESC, prlistty DESC";
            if (null != m_strSortExp &&
                String.Empty != m_strSortExp)
            {
                strSort = String.Format("{0} {1}", m_strSortExp, (m_SortDirection == SortDirection.Descending) ? "DESC" : "ASC");
            }
            DataView dv = new DataView(prlistview, String.Empty, strSort, DataViewRowState.CurrentRows);
            grdPrListMaster.DataSource = dv;
            grdPrListMaster.DataBind();
            prlistview.Dispose();
            dv.Dispose();
            ResultDisplay(dv.Count);
        }

        int GetSortColumnIndex(String strCol)
        {
            foreach (DataControlField field in grdPrListMaster.Columns)
            {
                if (field.SortExpression == strCol)
                {
                    return grdPrListMaster.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        void AddSortImage(GridViewRow headerRow)
        {
            Int32 iCol = GetSortColumnIndex(m_strSortExp);
            if (-1 == iCol)
            {
                return;
            }
            // Create the sorting image based on the sort direction.
            Image sortImage = new Image();
            if (SortDirection.Ascending == m_SortDirection)
            {
                sortImage.ImageUrl = "~/Images/ArrowDown.png";
                sortImage.AlternateText = "Ascending Order";
            }
            else
            {
                sortImage.ImageUrl = "~/Images/ArrowUp.png";
                sortImage.AlternateText = "Descending Order";
            }

            // Add the image to the appropriate header cell.
            headerRow.Cells[iCol].Controls.Add(sortImage);
        }

        protected void ResultDisplay(int ResultRows)
        {
            if (ResultRows == 0)
            {
                lblResult.Text = "No Result Found..";
                lnkAll.Enabled = false;
                lnkNone.Enabled = false;
            }
            else
            {
                lblResult.Text = "Result Found :" + ResultRows.ToString().Trim();
                lnkAll.Enabled = true;
                lnkNone.Enabled = true;
            }
        }

        protected void GoToPage_TextChanged(object sender, EventArgs e)
        {
            TextBox txtGoToPage = (TextBox)sender;

            int pageNumber;
            if (int.TryParse(txtGoToPage.Text.Trim(), out pageNumber) && pageNumber > 0 && pageNumber <= this.grdPrListMaster.PageCount)
            {
                this.grdPrListMaster.PageIndex = pageNumber - 1;
            }
            else
            {
                this.grdPrListMaster.PageIndex = 0;
            }

            bindGridView(); 
        }

        #region Event Handlers
        protected void OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                if (String.Empty != m_strSortExp)
                {
                    AddSortImage(e.Row);
                }
            }
        }

        protected void OnSort(object sender, GridViewSortEventArgs e)
        {
            // There seems to be a bug in GridView sorting implementation. Value of
            // SortDirection is always set to "Ascending". Now we will have to play
            // little trick here to switch the direction ourselves.
            if (String.Empty != m_strSortExp)
            {
                if (String.Compare(e.SortExpression, m_strSortExp, true) == 0)
                {
                    m_SortDirection = (m_SortDirection == SortDirection.Ascending) ? SortDirection.Descending : SortDirection.Ascending;
                }
            }

            ViewState["_Direction_"] = m_SortDirection;
            ViewState["_SortExp_"] = m_strSortExp = e.SortExpression;

            this.bindGridView();
        }
        #endregion

        protected void lnkAll_Click(object sender, EventArgs e)
        {

        }

        protected void grdPrListMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex == grdPrListMaster.PageCount)
            {
                grdPrListMaster.PageIndex = 0;
                bindGridView();
                return;
            }

            if (e.NewPageIndex != -1)
            {
                grdPrListMaster.PageIndex = e.NewPageIndex;
            }
            else
            {
                grdPrListMaster.PageIndex = grdPrListMaster.PageCount;
            }
            bindGridView();
        }

        protected void dropGrdview_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList dropDown = (DropDownList)sender;
            int grdPageSize;
            grdPageSize = int.Parse(dropDown.SelectedValue);
            this.grdPrListMaster.PageSize = grdPageSize;
            bindGridView();
            dropDown.SelectedValue = grdPageSize.ToString(); 
        }

        protected string EraseWord(string word)
        {
            word = word.Replace("<span class=highlight>", "");
            word = word.Replace("</span>", "");
            word = word.Trim();
            return word;
        }

    

        public string HighlightText(string InputTxt)
        {
            if (txtSearch.Text != "")
                SearchString = txtSearch.Text.Trim();

            if (SearchString == "")
            {
                return InputTxt;
            }
            else
            {
                System.Text.RegularExpressions.Regex ResultStr;
                ResultStr = new System.Text.RegularExpressions.Regex(SearchString.Replace(" ", "|"),System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return ResultStr.Replace(InputTxt,new System.Text.RegularExpressions.MatchEvaluator(this.ReplaceWords));
            }
        }

        public string ReplaceWords(System.Text.RegularExpressions.Match m)
        {
            return "<span class=highlight>" + m.ToString() + "</span>";
        }

        protected void btnGOSearch_Click(object sender, EventArgs e)
        {
            DataTable prlistview = new DataTable();
            SearchString = "";
            grdPrListMaster.DataBind();
            SearchString = txtSearch.Text;
            sqlStr = "select cast(0 as bit) as [select], prlistcd,prcode," +
                     "(case prlistty when 'S' then 'Sales' when 'P' then 'Purchase' end) as prlistty " +
                     " from it_rate" +
                     " where prcode like '%" + txtSearch.Text + "%' or prlistty like '%" + txtSearch.Text + "%'";

            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName; 
            prlistview = DataAccess.ExecuteDataTable(sqlStr, "_tmp",connHandle);
            DataAccess.Connclose(connHandle); 
            Session["PriceListView"] = prlistview;
            bindGridView(); 
        }

        protected void grdPrListMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Pager)
            {
                Label lblTotalNumberOfPages = (Label)e.Row.FindControl("lblTotalNumberOfPages");
                lblTotalNumberOfPages.Text = grdPrListMaster.PageCount.ToString();

                TextBox txtGoToPage = (TextBox)e.Row.FindControl("txtGoToPage");
                txtGoToPage.Text = (grdPrListMaster.PageIndex + 1).ToString();

                DropDownList ddlPageSize = (DropDownList)e.Row.FindControl("ddlPageSize");
                ddlPageSize.SelectedValue = grdPrListMaster.PageSize.ToString();
            }
            else
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    //e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';this.style.backgroundColor='#fafad2'";
                    //e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none';this.style.backgroundColor='#f5f5f5'";

                    e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                    e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";

                }
            }
        }

        protected void grdPrListMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "EDITLINK":
                    Response.Redirect("uwPriceListMaster.aspx?prlistcd=" + grdPrListMaster.DataKeys[Convert.ToInt16(e.CommandArgument)].Values[0].ToString().Trim() +
                                      "&addMode=false&editMode=true");
                    break;
                case "PLUS":
                    GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                    grdViewCallNestGrid(row.RowIndex);
                    break;
            }
        }

        protected void grdViewCallNestGrid(int rowIndex)
        {
            ImageButton findBtn = ((ImageButton)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("imgNode"));
            if (findBtn.AlternateText.Trim() == "+")
            {
                ((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = true;

                int prLstcd = 0;
                prLstcd = Convert.ToInt32(grdPrListMaster.DataKeys[rowIndex].Values[0]);

                string SqlStr = "select b.it_name,a.flatrate,a.discount,a.cmputrate from it_rate_det a" +
                                " inner join it_mast b on a.it_code = b.it_code " +
                                " where a.prlistcd = " + prLstcd;

                DataTable tranitdet_vw = new DataTable();
                DataTier DataAccess = new DataTier();
                DataAccess.DataBaseName = SessionProxy.DbName; 
                tranitdet_vw = DataAccess.ExecuteDataTable(SqlStr, "itDet",connHandle);
                DataAccess.Connclose(connHandle);
                if (tranitdet_vw.Rows.Count != 0)
                {
                    ((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                    ((TabPanel)((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).Enabled = true;
                    GridView findItGrid = ((GridView)((TabPanel)((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).FindControl("grdPrlstItDetails"));
                    findItGrid.DataSource = tranitdet_vw;
                    findItGrid.DataBind();
                    findBtn.ImageUrl = "~/Images/minus.gif";
                    findBtn.AlternateText = "-";
                }
                else
                {
                    ((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                    ((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = false;
                    findBtn.ImageUrl = "~/Images/Noplus.gif";
                    findBtn.AlternateText = "";
                }

             
                
            }
            else
            {
                ((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                ((TabContainer)grdPrListMaster.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = false;
                findBtn.ImageUrl = "~/Images/plus.gif";
                findBtn.AlternateText = "+";
            }
        }
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= grdPrListMaster.Rows.Count - 1; i++) 
            {
                CheckBox chkSelect = (CheckBox)grdPrListMaster.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    try
                    {
                        DeleteRec(Convert.ToInt32(grdPrListMaster.DataKeys[i].Values[0]));
                        tblError.Visible = false;
                        btnGOSearch_Click(sender, e); // Refresh GridView 
                    }
                    catch (Exception Ex)
                    {
                        tblError.Visible = true;
                        lblErrorHeading.Text = "Error Found while Deleting Records.";
                        lblErrorDetails.Text = Ex.Message;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "HighlightRow(null,'" + chkSelect.ClientID + "');", true);
                        break;
                    }
                }
            }
        }

        protected void DeleteRec(Int32 prListcd)
        {
            DataTier DataAccess = new DataTier();
            DataAccess.DataBaseName = SessionProxy.DbName;

            DataTable prlistview = (DataTable)Session["PriceListView"];
            boolFunction bitFunction = new boolFunction();

            DataRow prListRow = prlistview.Select("prlistcd = " + prListcd)[0];
            string PrlistCode = Convert.ToString(prListRow["prcode"]).Trim();
  
            SqlCommand cmd = new SqlCommand();
            sqlStr = DataAccess.GenDeleteString("it_rate", "prlistcd = " + prListcd);
            if (sqlStr != "")
            {
                cmd = DataAccess.ExecuteNonQuery(cmd, sqlStr, "TX", true,ref connHandle);
                try
                {
                    cmd.ExecuteNonQuery();
                    sqlStr = DataAccess.GenDeleteString("it_rate_det", "prlistcd = " + prListcd);
                    if (sqlStr != "")
                    {
                        cmd = DataAccess.ExecuteNonQuery(cmd, sqlStr, "TX", true,ref connHandle);
                        try
                        {
                            cmd.ExecuteNonQuery();
                            DataAccess.CommitTransaction(cmd.Transaction);
                            DataAccess.Connclose(connHandle);
                        }
                        catch (SqlException Ex)
                        {
                            throw DataAccess.SqlExceptionErrorsTraping(Ex);
                        }
                        catch (Exception Ex)
                        {
                            DataAccess.RollBackTransaction(cmd.Transaction);
                            DataAccess.Connclose(connHandle);
                            throw Ex;
                        }
                    }
                }
                catch (SqlException Ex)
                {
                    throw DataAccess.SqlExceptionErrorsTraping(Ex);
                }
                catch (Exception Ex)
                {
                    throw Ex;
                }
                finally
                {
                    cmd.Dispose();
                    DataAccess.Connclose(connHandle);
                }
            }
        }

        protected void lnkBtnAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwPriceListMaster.aspx?&addMode=true&editMode=false");
        }

        protected void grdPrlstItDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView findItGrid = ((GridView)sender);
            DataTable dataSource = ((DataTable)(findItGrid.DataSource));
            findItGrid.PageIndex = e.NewPageIndex;
            bindGridView(); 
            //findItGrid.DataSource = tranitdet_vw;
            //findItGrid.DataBind(); 
        }









}
}
