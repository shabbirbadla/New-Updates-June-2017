using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;  
using System.Data.SqlClient; 
using Data.Acess.Layer;
using Business.Logic.Layer; 

namespace Udyog.E.Billing
{
    public partial class viewReport : System.Web.UI.Page
    {
        //private static DataTable rStatusVw;

        

        boolFunction BitFunction = new boolFunction();
        numericFunction numFunction = new numericFunction();
        SqlConnection connHandle;
        string SqlStr = "";
        //static DataTable _tmpVar;
        private getDateFormat DateFormat = new getDateFormat();
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == true)
                return;

            SessionProxy.RStatusView = null; 
            DateFormat = new getDateFormat();
            BitFunction = new boolFunction();
            numFunction = new numericFunction();
            DataTable rStatusVw = new DataTable();
            string RepName = Convert.ToString(Request.QueryString["ReportName"]);

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            rStatusVw = DataAcess.ExecuteDataTable("Select * from r_status where upper([Group])='" + RepName.Trim() + "' and dontshow =0", "_re",connHandle);
            DataAcess.Connclose(connHandle);

            foreach (DataRow rStatusRow in rStatusVw.Rows)
            {
                dropGroup.Items.Add(Convert.ToString(rStatusRow["desc"]).Trim());    
            }
            //dropGroup.Items.Insert(0,"--Select Report Group--");

            GenRepTable(); // Generate Temp Table 
            dropGroup.SelectedValue = RepName.Trim();

            lblTrType.Text = RepName.Trim();
            SessionProxy.RStatusView = rStatusVw;
            getCompany GetCompany = new getCompany();
            DataTable company = SessionProxy.Company;  
            getDateFormat GetDateFormat = new getDateFormat();
            txtfromDate.Text = GetDateFormat.dateformatBR(Convert.ToString(company.Rows[0]["sta_dt"]));
            txtToDate.Text = GetDateFormat.dateformatBR(Convert.ToString(company.Rows[0]["end_dt"])); 
            dropGroup_SelectedIndexChanged(sender, e);
        }

        protected void dropGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (dropGroup.SelectedIndex == 0)
            //    return;

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            stringFunction strFunction = new stringFunction();
            DataTable rStatusVw = SessionProxy.RStatusView;
            DataRow rStatusRow = rStatusVw.Select("desc = '" + dropGroup.SelectedValue.Trim() + "'")[0];
            txtfromDate.Visible = BitFunction.toBoolean(rStatusRow["isfr_date"]);
            txtToDate.Visible = BitFunction.toBoolean(rStatusRow["isto_date"]);
            if (txtfromDate.Visible == false)
                ImgBntCalc.Visible = false;
            else
                ImgBntCalc.Visible = true;

            if (txtToDate.Visible == false)
                imgBtnToCalc.Visible = false;
            else
                imgBtnToCalc.Visible = true;

            if (txtfromDate.Visible == false &&
                txtToDate.Visible == false)
                trDates.Visible = false;
            else
                trDates.Visible = true;

            if (txtfromDate.Visible == true && txtToDate.Visible == false)
            {
                lblDate.Text = " As on Date";
            }

            // Accounts
            cboFromAcc.Visible = BitFunction.toBoolean(rStatusRow["isfr_ac"]);
            cboToAcc.Visible = BitFunction.toBoolean(rStatusRow["isto_ac"]);
            if (cboFromAcc.Visible == true && cboToAcc.Visible == false)
            {
                tdToAcc.Visible = false;
            }
            else
            {
                if (cboFromAcc.Visible == false && cboToAcc.Visible == false)
                    trAccounts.Visible = false;
                else
                    trAccounts.Visible = true; 
            }

            if (Convert.ToString(rStatusRow["ac_group"]).Trim() == "")
            {
                //lblMess.Visible = true;
                //lblMess.Text = "No Default GROUP defined..";
                DataTable acName = null;
                if (cboFromAcc.Visible == true)
                {
                    SqlStr = " select ac_name,ac_id from ac_mast order by ac_name ";

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    acName = DataAcess.ExecuteDataTable(SqlStr, "_acname",connHandle);
                    DataAcess.Connclose(connHandle); 
                    cboFromAcc.DataSource = acName;
                    cboFromAcc.DataTextField = "ac_name";
                    cboFromAcc.DataValueField = "ac_id";
                    cboFromAcc.DataBind();
                    cboFromAcc.Items.Insert(0, "--Select A/c Name--");
                    if (acName.Rows.Count > 0)
                        cboFromAcc.SelectedIndex = 1;
                    else
                        cboFromAcc.SelectedIndex = 0;

                }

                if (cboToAcc.Visible == true)
                {
                    SqlStr = " select ac_name,ac_id from ac_mast order by ac_name desc";
                    DataAcess.DataBaseName = SessionProxy.DbName;
                    acName = DataAcess.ExecuteDataTable(SqlStr, "_acName",connHandle);
                    DataAcess.Connclose(connHandle); 

                    cboToAcc.DataSource = acName;
                    cboToAcc.DataTextField = "ac_name";
                    cboToAcc.DataValueField = "ac_id";
                    cboToAcc.DataBind();
                    cboToAcc.Items.Insert(0, "--Select A/c Name");
                    cboToAcc.SelectedIndex = 1;
                    if (acName.Rows.Count > 0)
                        cboToAcc.SelectedIndex = 1;
                    else
                        cboToAcc.SelectedIndex = 0;

                }
                //acName.Dispose(); // Dispose datatable 
            }
            else
            {
                lblMess.Text = "Group :" + Convert.ToString(rStatusRow["ac_group"]).Trim();
                DataView acName = null;

                if (cboFromAcc.Visible == true)
                {
                    SqlParameter[] param = {
                        new SqlParameter("@groupname",SqlDbType.NVarChar,4000)};

                    param[0].Value = Convert.ToString(rStatusRow["ac_group"]).Trim();
                    //DataTable acName1 = DataAcess.ExecuteDataTable("usp_acc_subgroups", ParamCollection);

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    acName = DataAcess.ExecuteDataTable("usp_acc_subgroups", param,connHandle).DefaultView;
                    DataAcess.Connclose(connHandle);
 
                    acName.Sort = "ac_name ASC";
                    cboFromAcc.DataSource = acName;
                    cboFromAcc.DataTextField = "ac_name";
                    cboFromAcc.DataValueField = "ac_id";
                    cboFromAcc.DataBind();
                    cboFromAcc.Items.Insert(0, "--Select A/c Name");
                    cboFromAcc.SelectedIndex = 1;
                    if (acName.Count > 0)
                        cboFromAcc.SelectedIndex = 1;
                    else
                        cboFromAcc.SelectedIndex = 0;

                }

                if (cboToAcc.Visible == true)
                {
                    if (acName == null)
                    {
                        SqlParameter[] sParam = {new SqlParameter("@groupname",
                                SqlDbType.VarChar, 4000)};
                        sParam[0].Value = Convert.ToString(rStatusRow["ac_group"]).Trim();

                        DataAcess.DataBaseName = SessionProxy.DbName;
                        acName = DataAcess.ExecuteDataTable("usp_acc_subgroups", sParam,connHandle).DefaultView;
                        DataAcess.Connclose(connHandle); 
                    }

                    acName.Sort = "ac_name DESC";
                    cboToAcc.DataSource = acName; 
                    cboToAcc.DataTextField = "ac_name";
                    cboToAcc.DataValueField = "ac_id";
                    cboToAcc.DataBind();
                    cboToAcc.Items.Insert(0, "--Select A/c Name--");
                    cboToAcc.SelectedIndex = 1;
                    if (acName.Count > 0)
                        cboToAcc.SelectedIndex = 1;
                    else
                        cboToAcc.SelectedIndex = 0;

                }
                //acName.Dispose(); 
            }


            // Items
            cboFromItem.Visible = BitFunction.toBoolean(rStatusRow["isfr_item"]);
            cboToItems.Visible = BitFunction.toBoolean(rStatusRow["isto_item"]);
            if (cboFromItem.Visible == true && cboToItems.Visible == false)
                tdToItem.Visible = false;
            else
                if (cboFromItem.Visible == false && cboToItems.Visible == false)
                    trItems.Visible = false;
                else
                    trItems.Visible = true;

            if (Convert.ToString(rStatusRow["it_group"]).Trim() == "")
            {
                //lblMess.Visible = true;
                //lblMess.Text = "No Default GROUP defined..";
                DataTable itName = null;
                if (cboFromItem.Visible == true)
                {
                    SqlStr = " select it_name,it_code from it_mast order by it_name ";

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    itName = DataAcess.ExecuteDataTable(SqlStr, "_itname",connHandle);
                    DataAcess.Connclose(connHandle);
 
                    cboFromItem.DataSource = itName;
                    cboFromItem.DataTextField = "it_name";
                    cboFromItem.DataValueField = "it_code";
                    cboFromItem.DataBind();
                    cboFromItem.Items.Insert(0, "--Select Item--");
                    cboFromItem.SelectedIndex = 1;
                    if (itName.Rows.Count > 0)
                        cboFromItem.SelectedIndex = 1;
                    else
                        cboFromItem.SelectedIndex = 0;

                }

                if (cboToItems.Visible == true)
                {
                    SqlStr = " select it_name,it_code from it_mast order by it_name desc";

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    itName = DataAcess.ExecuteDataTable(SqlStr, "_itName",connHandle);
                    DataAcess.Connclose(connHandle);

                    cboToItems.DataSource = itName;
                    cboToItems.DataTextField = "it_name";
                    cboToItems.DataValueField = "it_code";
                    cboToItems.DataBind();
                    cboToItems.Items.Insert(0, "--Select Item--");
                    cboToItems.SelectedIndex = 1;
                    if (itName.Rows.Count > 0)
                        cboToItems.SelectedIndex = 1;
                    else
                        cboToItems.SelectedIndex = 0;

                }
                if (itName != null) 
                    itName.Dispose(); // Dispose datatable 
            }
            else
            {
                lblMess.Text = "Group :" + Convert.ToString(rStatusRow["it_group"]).Trim();
                DataView itName = null;

                if (cboFromItem.Visible == true)
                {
                    SqlParameter[] param = {
                        new SqlParameter("@itemname",SqlDbType.NVarChar,4000)};
                    param[0].Value = Convert.ToString(rStatusRow["it_group"]).Trim();

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    itName = DataAcess.ExecuteDataTable("usp_item_subgroups", param,connHandle).DefaultView;
                    DataAcess.Connclose(connHandle);

                    itName.Sort = "it_name ASC";
                    cboFromItem.DataSource = itName;
                    cboFromItem.DataTextField = "it_name";
                    cboFromItem.DataValueField = "it_code";
                    cboFromItem.DataBind();
                    cboFromItem.Items.Insert(0, "--Select Item--");
                    cboFromItem.SelectedIndex = 1;
                    if (itName.Count > 0)
                        cboFromItem.SelectedIndex = 1;
                    else
                        cboFromItem.SelectedIndex = 0;

                }

                if (cboToAcc.Visible == true)
                {
                    if (itName == null)
                    {
                        SqlParameter[] param = {
                        new SqlParameter("@itemname",SqlDbType.VarChar,4000)};
                        param[0].Value = Convert.ToString(rStatusRow["it_group"]).Trim();

                        DataAcess.DataBaseName = SessionProxy.DbName;
                        itName = DataAcess.ExecuteDataTable("usp_item_subgroups", param,connHandle).DefaultView;
                        DataAcess.Connclose(connHandle);
                    }

                    itName.Sort = "it_name DESC";
                    cboToItems.DataSource = itName;
                    cboToItems.DataTextField = "it_name";
                    cboToItems.DataValueField = "it_code";
                    cboToItems.DataBind();
                    cboToItems.Items.Insert(0, "--Select Item--");
                    cboToItems.SelectedIndex = 1;
                    if (itName.Count > 0)
                        cboToItems.SelectedIndex = 1;
                    else
                        cboToItems.SelectedIndex = 0;
                }
                if (itName != null) 
                    itName.Dispose();
            }


            // Amounts
            txtFromAmt.Visible = BitFunction.toBoolean(rStatusRow["isfr_amt"]);
            txtToAmt.Visible = BitFunction.toBoolean(rStatusRow["isto_amt"]);
            if (txtFromAmt.Visible == true && txtToAmt.Visible == false)
                tdToAmt.Visible = false; 
            else
                if (txtFromAmt.Visible == false && txtToAmt.Visible == false)
                    trAmounts.Visible = false; 
                else
                    trAmounts.Visible = true;

            // Departments
            cboFromDept.Visible = BitFunction.toBoolean(rStatusRow["isdept"]);
            cboToDept.Visible = BitFunction.toBoolean(rStatusRow["isdept"]);
            if (cboFromDept.Visible == true && cboToDept.Visible == false)
                tdToDept.Visible = false;
            else
                if (cboFromDept.Visible == false && cboToDept.Visible == false)
                    trDepartments.Visible = false;
                else
                    trDepartments.Visible = true;

            if (trDepartments.Visible == true)
            {
                DataView dePartMent = null;
                if (cboFromDept.Visible == true)
                {
                    SqlStr = " select dept from department order by dept ";

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    dePartMent = DataAcess.ExecuteDataTable(SqlStr, "_dept",connHandle).DefaultView;
                    DataAcess.Connclose(connHandle);
                    dePartMent.Sort = "dept ASC";
                    cboFromDept.DataSource = dePartMent;
                    cboFromDept.DataTextField = "dept";
                    cboFromDept.DataValueField = "dept";
                    cboFromDept.DataBind();
                    cboFromDept.Items.Insert(0, "--Select Department--");
                    if (dePartMent.Count > 0)
                        cboFromDept.SelectedIndex = 1;
                    else
                        cboFromDept.SelectedIndex = 0;
                }

                if (cboToDept.Visible == true)
                {
                    if (dePartMent == null)
                    {
                        SqlStr = " select dept from department order by dept ";

                        DataAcess.DataBaseName = SessionProxy.DbName;
                        dePartMent = DataAcess.ExecuteDataTable(SqlStr, "_dept",connHandle).DefaultView;
                        DataAcess.Connclose(connHandle);
                    }
                    dePartMent.Sort = "dept DESC"; 
                    cboToDept.DataSource = dePartMent;
                    cboToDept.DataTextField = "dept";
                    cboToDept.DataValueField = "dept";
                    cboToDept.DataBind();
                    cboToDept.Items.Insert(0, "--Select Department--");
                    
                    if (dePartMent.Count > 0)
                        cboToDept.SelectedIndex = 1;
                    else
                        cboToDept.SelectedIndex = 0;
                }

                if (dePartMent != null)
                    dePartMent.Dispose(); 


            }

            // Categories
            cboFromCate.Visible = BitFunction.toBoolean(rStatusRow["iscategory"]);
            cboToCate.Visible = BitFunction.toBoolean(rStatusRow["iscategory"]);
            if (cboFromCate.Visible == true && cboToCate.Visible == false)
                tdToCate.Visible = false;
            else
                if (cboFromCate.Visible == false && cboToCate.Visible == false)
                    trCategories.Visible = false;
                else
                    trCategories.Visible = true;

            if (trCategories.Visible == true)
            {
                DataView cateGory = null;
                if (cboFromCate.Visible == true)
                {
                    SqlStr = " select cate from Category order by cate ";

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    cateGory = DataAcess.ExecuteDataTable(SqlStr, "_cate",connHandle).DefaultView;
                    DataAcess.Connclose(connHandle);

                    cateGory.Sort = "cate ASC";
                    cboFromCate.DataSource = cateGory;
                    cboFromCate.DataTextField = "cate";
                    cboFromCate.DataValueField = "cate";
                    cboFromCate.DataBind();
                    cboFromCate.Items.Insert(0, "--Select Category--");
                    if (cateGory.Count > 0)
                        cboFromCate.SelectedIndex = 1;
                    else
                        cboFromCate.SelectedIndex = 0;

                }

                if (cboToCate.Visible == true)
                {
                    if (cateGory == null)
                    {
                        SqlStr = " select cate from category order by cate ";

                        DataAcess.DataBaseName = SessionProxy.DbName;
                        cateGory = DataAcess.ExecuteDataTable(SqlStr, "_cate",connHandle).DefaultView;
                        DataAcess.Connclose(connHandle);
                    }
                    cateGory.Sort = "cate DESC";
                    cboToCate.DataSource = cateGory;
                    cboToCate.DataTextField = "cate";
                    cboToCate.DataValueField = "cate";
                    cboToCate.DataBind();
                    cboToCate.Items.Insert(0, "--Select Category--");

                    if (cateGory.Count > 0) 
                        cboToCate.SelectedIndex = 1;
                    else
                        cboToCate.SelectedIndex = 0;
                }

                if (cateGory  != null)
                    cateGory.Dispose(); 

            }

            // WareHouses
            cboFromWH.Visible = BitFunction.toBoolean(rStatusRow["iswarehous"]);
            cboToWH.Visible = BitFunction.toBoolean(rStatusRow["iswarehous"]);
            if (cboFromWH.Visible == true && cboToWH.Visible == false)
                tdToWH.Visible = false;
            else
                if (cboFromWH.Visible == false && cboToWH.Visible == false)
                    trWareHouses.Visible = false; 
                else
                    trWareHouses.Visible = true;

            if (trWareHouses.Visible == true)
            {
                DataView wareHouse = null;
                if (cboFromWH.Visible == true)
                {
                    SqlStr = " select ware_nm from warehouse order by ware_nm ";

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    wareHouse = DataAcess.ExecuteDataTable(SqlStr, "_wh",connHandle).DefaultView;
                    DataAcess.Connclose(connHandle);
                    wareHouse.Sort = "ware_nm ASC";
                    cboFromWH.DataSource = wareHouse;
                    cboFromWH.DataTextField = "ware_nm";
                    cboFromWH.DataValueField = "ware_nm";
                    cboFromWH.DataBind();
                    cboFromWH.Items.Insert(0, "--Select WareHouse--");
                    if (wareHouse.Count > 0)
                        cboFromWH.SelectedIndex = 1;
                    else
                        cboFromWH.SelectedIndex = 0;
                }

                if (cboToWH.Visible == true)
                {
                    if (wareHouse == null)
                    {
                        SqlStr = " select ware_nm from warehouse order by ware_nm ";

                        DataAcess.DataBaseName = SessionProxy.DbName;
                        wareHouse = DataAcess.ExecuteDataTable(SqlStr, "_wh",connHandle).DefaultView;
                        DataAcess.Connclose(connHandle);
                    }
                    wareHouse.Sort = "ware_nm DESC";
                    cboToWH.DataSource = wareHouse;
                    cboToWH.DataTextField = "ware_nm";
                    cboToWH.DataValueField = "ware_nm";
                    cboToWH.DataBind();
                    cboToWH.Items.Insert(0, "--Select Warehouse--");
                    if (wareHouse.Count > 0)
                        cboToWH.SelectedIndex = 1;
                    else
                        cboToWH.SelectedIndex = 0;
                }

                if (wareHouse != null)
                    wareHouse.Dispose(); 


            }

            // Series

            cboFromSeries.Visible = BitFunction.toBoolean(rStatusRow["isinvseri"]);
            cboToSeries.Visible = BitFunction.toBoolean(rStatusRow["isinvseri"]);
            if (cboFromSeries.Visible == true && cboToSeries.Visible == false)
                tdToWH.Visible = false;
            else
                if (cboFromSeries.Visible == false && cboToSeries.Visible == false)
                    trSeries.Visible = false;
                else
                    trSeries.Visible = true;

            if (trSeries.Visible == true)
            {
                DataView InvSeries = null;
                if (cboFromSeries.Visible == true)
                {
                    SqlStr = " select inv_sr from series order by inv_sr ";

                    DataAcess.DataBaseName = SessionProxy.DbName;
                    InvSeries = DataAcess.ExecuteDataTable(SqlStr, "_sr",connHandle).DefaultView;
                    DataAcess.Connclose(connHandle);

                    InvSeries.Sort = "inv_sr ASC";
                    cboFromSeries.DataSource = InvSeries;
                    cboFromSeries.DataTextField = "inv_sr";
                    cboFromSeries.DataValueField = "inv_sr";
                    cboFromSeries.DataBind();
                    cboFromSeries.Items.Insert(0, "--Select Series--");
                    if (InvSeries.Count > 0)
                        cboFromSeries.SelectedIndex = 1;
                    else
                        cboFromSeries.SelectedIndex = 0;
                }

                if (cboToSeries.Visible == true)
                {
                    if (InvSeries == null)
                    {
                        SqlStr = " select inv_sr from Series order by inv_sr ";

                        DataAcess.DataBaseName = SessionProxy.DbName;
                        InvSeries = DataAcess.ExecuteDataTable(SqlStr, "_sr",connHandle).DefaultView;
                        DataAcess.Connclose(connHandle);
                    }
                    InvSeries.Sort = "inv_sr DESC";
                    cboToSeries.DataSource = InvSeries;
                    cboToSeries.DataTextField = "inv_sr";
                    cboToSeries.DataValueField = "inv_sr";
                    cboToSeries.DataBind();
                    cboToSeries.Items.Insert(0, "--Select Series--");
                    if (InvSeries.Count > 0)
                        cboToSeries.SelectedIndex = 1;
                    else
                        cboToSeries.SelectedIndex = 0;
                }
                if (InvSeries != null)
                    InvSeries.Dispose(); 

            }

            
            if (strFunction.InList(Convert.ToString(rStatusRow["rep_nm"]).Trim().ToUpper(),
                    new string[] {"OUTDR","OUTDRAGE","OUTCR","OUTCRAGE"}) == true)
            {
                trwithAdv.Visible = true;     
            }
            else
            {
                trwithAdv.Visible = false;
            }

            DataAcess.Connclose(connHandle);  

        }

        protected void GenRepTable()
        {
            SqlStr = "Select ac_group_mast.ac_group_name as advAcGroup,"
                   + "ac_group_mast.ac_group_name as _group,"
                   + "ac_group_mast.ac_group_id as GroupId,"
                   + "item_group.It_group_name as advItGroup,"
                   + "item_group.it_group_name as _itGroup,"
                   + "it_mast.Type as advItType,ac_mast.ac_Name as sName,ac_mast.ac_Name as eName,"
                   + "ac_mast.ac_id as frmAcId, ac_mast.ac_id as ToAcId,"
                   + "It_mast.it_code as frmItCd, it_mast.It_code as ToItCd,"
                   + "it_mast.It_name as sItem,it_mast.It_name as eItem,"
                   + "main.Entry_ty as voutypes,"
                   + "main.gro_amt as sAmt,"
                   + "main.gro_amt as eAmt,"
                   + "space(254) as lcstr_one, space(254) as lcstr_two, space(254) as lcstr_thrd,"
                   + "main.inv_sr as sInvSr,main.inv_sr as eInvSr,"
                   + "item.ware_Nm as sware,item.Ware_Nm as eWare,"
                   + "main.Cate as sCat,main.Cate as eCat,"
                   + "main.Dept as sDept,main.Dept as eDept,"
                   + "main.Date as sDate,main.Date as eDate,0 as ChkVal2 "
                   + "from ac_mast,ac_group_mast,item_group,it_mast,main,item where 1=2";

            DataSet MainDataSet = SessionProxy.ReportDataSet;
            if (MainDataSet == null)
                MainDataSet = new DataSet();

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
            MainDataSet = DataAcess.ExecuteDataset(MainDataSet,SqlStr, "_tmpVar",connHandle);
            DataAcess.Connclose(connHandle);

            DataRow dRow;
            dRow = MainDataSet.Tables["_tmpVar"].NewRow();
            MainDataSet.Tables["_tmpVar"].Rows.Add(dRow);
            MainDataSet.Tables["_tmpVar"].AcceptChanges();
            SessionProxy.ReportDataSet = MainDataSet;  
            MainDataSet.Dispose(); 
        }

        protected void btnPrint_Click(object sender, EventArgs e)
        {
            if ((txtfromDate.Text != "__/__/____" && txtToDate.Text == "__/__/____") ||
                (txtfromDate.Text != "" && txtToDate.Text == ""))
            {
                if (DateFormat.TodateTime(txtfromDate.Text) > DateFormat.TodateTime(txtToDate.Text))
                {
                    lblMess.Text = " FROM date cannot be greater than TO date..";
                    return;
                }

                if (DateFormat.TodateTime(txtToDate.Text) < DateFormat.TodateTime(txtfromDate.Text))
                {
                    lblMess.Text = " FROM date cannot be less than TO date..";
                    return;
                }
            }

            DataTable rStatusVw = SessionProxy.RStatusView;
            DataRow rStatusRow = rStatusVw.Select("desc ='" + dropGroup.SelectedValue.Trim() + "'")[0];

            if (Convert.ToString(rStatusRow["Qtable"]).Trim() == "" &&
                !(Convert.ToString(rStatusRow["SqlQuery"]).Trim().IndexOf("EXECUTE ") >= 0))
            {
                lblMess.Text = " QTABLE field cannot not be blank in Report Wizard ";
            }


            if (Convert.ToString(rStatusRow["sqlquery"]).Trim() == "")
            {
                lblMess.Text = " Query or Procedure not found..";
            }

            bool isStoreProcedure = false;
            bool isSqlQuery = false;

            if (Convert.ToString(rStatusRow["sqlquery"]).Trim().IndexOf("EXECUTE") >= 0)
                isStoreProcedure = true;
            else
                if (Convert.ToString(rStatusRow["sqlquery"]).Trim().IndexOf("SELECT") >= 0)
                    isSqlQuery = true;

            string SqlScript = "";
            if (isStoreProcedure == true)
                SqlScript = SetSPparameters(rStatusRow);
            else
                if (isSqlQuery == true)
                    SqlScript = SetQueryparameters(rStatusRow);

            DataSet MainDataSet = SessionProxy.ReportDataSet;  
            if (MainDataSet != null)
            {
                getCoAdditional GetCoAdditional = new getCoAdditional();
                if (MainDataSet.Tables.Contains("Company") == false)
                    MainDataSet.Tables.Add(SessionProxy.Company.Copy()); 

                MainDataSet = GetCoAdditional.CoAdditional(MainDataSet);
            }

            saveTmpFile(MainDataSet.Tables["_tmpVar"]);

            callPrint(SqlScript,rStatusRow);

            SessionProxy.ReportDataSet = MainDataSet;
        }

        protected void saveTmpFile(DataTable _tmpVar)
        {
            _tmpVar.Rows[0]["sdate"] = DateFormat.TodateTime(txtfromDate.Text);
            _tmpVar.Rows[0]["edate"] = DateFormat.TodateTime(txtToDate.Text);
            if (cboFromItem.Visible == true) 
                _tmpVar.Rows[0]["sitem"] = cboFromItem.SelectedIndex != 0 ?
                    cboFromItem.SelectedItem.Text.ToString() : "''";
            if (cboToItems.Visible == true) 
                _tmpVar.Rows[0]["eitem"] = cboToItems.SelectedIndex != 0 ?
                    cboToItems.SelectedItem.Text.ToString() : "''";
            if (cboFromAcc.Visible == true) 
                _tmpVar.Rows[0]["sname"] = cboFromAcc.SelectedIndex != 0 ?
                    cboFromAcc.SelectedItem.Text.ToString() : "''";
            if (cboToAcc.Visible == true) 
                _tmpVar.Rows[0]["ename"] = cboToAcc.SelectedIndex != 0 ?
                    cboToAcc.SelectedItem.Text.ToString() : "''";
            if (cboFromSeries.Visible == true) 
                _tmpVar.Rows[0]["sinvsr"] = cboFromSeries.SelectedIndex != 0 ?
                    cboFromSeries.SelectedItem.Text.ToString() : "''";
            if (cboToSeries.Visible == true) 
                _tmpVar.Rows[0]["einvsr"] = cboToSeries.SelectedIndex != 0 ?
                    cboToSeries.SelectedItem.Text.ToString() : "''";
            if (cboFromWH.Visible == true) 
                _tmpVar.Rows[0]["sware"] = cboFromWH.SelectedIndex != 0 ?
                    cboFromWH.SelectedItem.Text.ToString() : "''";
            if (cboToWH.Visible == true) 
                _tmpVar.Rows[0]["eware"] = cboToWH.SelectedIndex != 0 ?
                    cboToWH.SelectedItem.Text.ToString() : "''";
            if (cboFromCate.Visible == true) 
                _tmpVar.Rows[0]["scat"] = cboFromCate.SelectedIndex != 0 ?
                    cboFromCate.SelectedItem.Text.ToString() : "''";
            if (cboToCate.Visible == true)
                _tmpVar.Rows[0]["ecat"] = cboToCate.SelectedIndex != 0 ?
                    cboToCate.SelectedItem.Text.ToString() : "''";
            if (cboFromDept.Visible == true)
                _tmpVar.Rows[0]["sdept"] = cboFromDept.SelectedIndex != 0 ?
                    cboFromDept.SelectedItem.Text.ToString() : "''";
            if (cboToDept.Visible == true)
                _tmpVar.Rows[0]["edept"] = cboToDept.SelectedIndex != 0 ?
                    cboToDept.SelectedItem.Text.ToString() : "''";
            if (txtFromAmt.Visible == true) 
                _tmpVar.Rows[0]["samt"] = txtFromAmt.Text != "" ?
                      numFunction.toDecimal(txtFromAmt.Text) : numFunction.toDecimal("0.00");
            if (txtToAmt.Visible == true) 
                _tmpVar.Rows[0]["eamt"] = txtToAmt.Text!= "" ?
                    numFunction.toDecimal(txtToAmt.Text) : numFunction.toDecimal("0.00");
            if (trwithAdv.Visible == true)
                _tmpVar.Rows[0]["chkval2"] = chkAdvPayment.Checked == true ?
                    1 : 0;
             _tmpVar.AcceptChanges();      
        }

        protected void callPrint(string SqlScript, DataRow rStatusRow)
        {
            if (SqlScript.Trim() != "")
            {
                DataSet MainDataSet = SessionProxy.ReportDataSet;  
                string cFileName = Server.MapPath(".") + "\\" + Convert.ToString(MainDataSet.Tables["Company"].Rows[0]["dir_nm"]).Trim() + "\\Reports\\" + Convert.ToString(rStatusRow["rep_nm"]).Trim() + ".rpt";
                if (File.Exists(cFileName) == false)
                {
                    cFileName = Server.MapPath(".") + "\\Reports\\" + Convert.ToString(rStatusRow["rep_nm"]).Trim() + ".rpt";
                }

                if (!System.IO.File.Exists(cFileName))
                {
                    throw new Exception(cFileName.Trim() + " Report file not found ...!!");
                }

                SqlScript.Replace("REPORT HEADER", Convert.ToString(rStatusRow["desc"]).Trim());
                SessionProxy.MainQueryString = SqlScript.Trim();
                SessionProxy.ReportPath = cFileName.Trim();
                SessionProxy.ReportDataSet = MainDataSet;
                //Session["RepName"] = Convert.ToString(rStatusRow["rep_nm"]).Trim();
                //Session["ReportDataSet"] = MainDataSet;
                MainDataSet.Dispose(); 
            }

            string strOpenWin = "";
            //strOpenWin = "open_window_max('uwCRViewer.aspx','Report');";
            strOpenWin = "open_window_max('ueCrystalHomePage.aspx','Report');";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "openWindow()", strOpenWin, true);

        }
        protected string SetSPparameters(DataRow rStatusRow)
        {
            string spParam = "";
            string sqlQuery = Convert.ToString(rStatusRow["SqlQuery"]).Trim();

            //sqlQuery = sqlQuery.Trim().Substring(sqlQuery.Trim().IndexOf("EXECUTE ") + 8,
            //           (sqlQuery.Trim().IndexOf(";") >= 0 ? sqlQuery.Trim().IndexOf(";")
            //           : sqlQuery.Trim().IndexOf(" ")) - 8);
            // Set TmpAc
            spParam = "''";
            // Set TmpIt
            spParam += ",''";
            // Set Special Conditiomn
            spParam += Convert.ToString(rStatusRow["spl_condn"]).Trim() != "" ?
                "," + Convert.ToString(rStatusRow["spl_condn"]).Trim() : ",''";

            // Set Date ( FROM - TO range)
            if (txtfromDate.Visible == true && txtToDate.Visible == true)
                spParam += ",'" + DateFormat.dateformat(DateFormat.TodateTime(txtfromDate.Text).ToString()) + "','" +
                                DateFormat.dateformat(DateFormat.TodateTime(txtToDate.Text).ToString()) + "'";
                
            else
                // AS ON Date
                if (txtfromDate.Visible == true && txtToDate.Visible == false)
                    spParam += ",'" + DateFormat.dateformat(DateFormat.TodateTime(txtfromDate.Text).ToString()) + "',''";
                else
                    if (txtfromDate.Visible == false && txtToDate.Visible == false)
                        spParam += ",'',''";


            // Set Account ( FROM - TO range )
            if (cboFromAcc.Visible == true && cboToAcc.Visible == true)
                spParam += "," + (cboFromAcc.SelectedIndex != 0 ?
                    "'" + cboFromAcc.SelectedItem.Text.Trim() + "'" : "''") +
                            (cboToAcc.SelectedIndex != 0 ? ",'" + cboToAcc.SelectedItem.Text.Trim() + "'" : ",''");

            else
                if (cboFromAcc.Visible == true && cboToAcc.Visible == false)
                    spParam += "," + (cboFromAcc.SelectedIndex != 0 ?
                        "'" + cboFromAcc.SelectedItem.Text.Trim() + "',''" : "'',''");
                else
                    if (cboFromAcc.Visible == false && cboToAcc.Visible == false)
                        spParam += ",'',''";

            // Set Items ( FROM - TO range )

            if (cboFromItem.Visible == true && cboToItems.Visible == true)
                spParam += "," + (cboFromItem.SelectedIndex != 0 ?
                    "'" + cboFromItem.SelectedItem.Text.Trim() + "'" : "''") +
                            (cboToItems.SelectedIndex != 0 ? ",'" + cboToItems.SelectedItem.Text.Trim() + "'" : ",''");

            else
                if (cboFromItem.Visible == true && cboToItems.Visible == false)
                    spParam += "," + (cboFromItem.SelectedIndex != 0 ?
                        "'" + cboFromItem.SelectedItem.Text.Trim() + "',''" : "'',''");
                else
                    if (cboFromItem.Visible == false && cboToItems.Visible == false)
                        spParam += ",'',''";

            // Set Amount ( FROM - TO range )

            if (txtFromAmt.Visible == true && txtToAmt.Visible == true)
                spParam += "," + (txtFromAmt.Text != "" ?
                    txtFromAmt.Text + "," : "0.00") +
                            (txtToAmt.Text != "" ? txtToAmt.Text : ",0.00");
                            
            else
                if (txtFromAmt.Visible == true && txtToAmt.Visible == false)
                    spParam += "," + (txtFromAmt.Text != "" ?
                        txtFromAmt.Text  + ",0.00" : "0.00,0.00");
                else
                    if (txtFromAmt.Visible == false && txtToAmt.Visible == false)
                        spParam += ",0.00,0.00";

            // Set Department ( FROM - TO range )
            if (cboFromDept.Visible == true && cboToDept.Visible == true)
                spParam += "," + (cboFromDept.SelectedIndex != 0 ?
                    "'" + cboFromDept.SelectedItem.Text.Trim() + "'" : "''") + 
                            (cboToDept.SelectedIndex != 0 ? ",'" + cboToDept.SelectedItem.Text.Trim() + "'" : ",''");
                            
            else
                if (cboFromDept.Visible == false && cboToDept.Visible == false)
                        spParam += ",'',''";

            // Set Category ( FROM - TO range )
                if (cboFromCate.Visible == true && cboToCate.Visible == true)
                    spParam += "," + (cboFromCate.SelectedIndex != 0 ?
                        "'" + cboFromCate.SelectedItem.Text.Trim() + "'" : "''") +
                        (cboToCate.SelectedIndex != 0 ? ",'" + cboToCate.SelectedItem.Text.Trim() + "'" : ",''");

                else
                    if (cboFromCate.Visible == false && cboToCate.Visible == false)
                        spParam += ",'',''";

            // Set Warehouse ( FROM - TO range )
                if (cboFromWH.Visible == true && cboToWH.Visible == true)
                    spParam += "," + (cboFromWH.SelectedIndex != 0 ? "'" + cboFromWH.SelectedItem.Text.Trim() + "'" : "''") +
                                (cboToWH.SelectedIndex != 0 ? ",'" + cboToWH.SelectedItem.Text.Trim() + "'" : ",''");

                else
                    if (cboFromWH.Visible == false && cboToWH.Visible == false)
                        spParam += ",'',''";

            // Set Series ( FROM - TO range )
                if (cboFromSeries.Visible == true && cboToSeries.Visible == true)
                    spParam += "," + (cboFromSeries.SelectedIndex != 0 ?
                        "'" + cboFromSeries.SelectedItem.Text.Trim() + "'" : "''") + 
                                (cboToSeries.SelectedIndex != 0 ? ",'" + cboToSeries.SelectedItem.Text.Trim() + "'" : ",''");

                else
                    if (cboFromSeries.Visible == false && cboToSeries.Visible == false)
                        spParam += ",'',''";

            // Set Company fin. Year
            spParam += ",'" + SessionProxy.FinYear + "'";

            // Set ExPara
            spParam += ",''";
            
            sqlQuery = sqlQuery.Trim().Substring(0, sqlQuery.Trim().IndexOf(";"));

            sqlQuery += spParam; 
            //           (sqlQuery.Trim().IndexOf(";") >= 0 ? sqlQuery.Trim().IndexOf(";")
            //           : sqlQuery.Trim().IndexOf(" ")) - 8);
            
            //sp_sproc_columns USP_REP_ANNECR7A
            return sqlQuery;
        }

        protected string SetQueryparameters(DataRow rStatusRow)
        {
            string sqlstr = "";
            return sqlstr;
        }

        protected void lnkBack_Click(object sender, EventArgs e)
        {

        }

    }
}
