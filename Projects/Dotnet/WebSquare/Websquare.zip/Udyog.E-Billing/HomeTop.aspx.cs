using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Udyog.E.Billing
{
    public partial class HomeTop : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            imgTreeview.Attributes.Add("onclick", "return HideFrame()");
            //if (!DBNull.Value.Equals(Session["CoName"]))   
            //{
            //    lblConame.Text = Session["CoName"].ToString().Trim();
            //    lblfinYear.Text = Session["Finyear"].ToString().Trim();
            //    lblUserId.Text = Session["UserID"].ToString().Trim(); 
            //}
        }
    }
}
