using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data.Acess.Layer;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using CrystalDecisions.Shared;
using System.IO;
using Business.Logic.Layer;

namespace Udyog.E.Billing
{
    public partial class uwCRViewer : BasePage
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle = null;
        
        ReportDocument RepHandle = new ReportDocument();

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //    //DataSet MainDataSet = new DataSet();
            //    //DataTier DataAcess = new DataTier();
            //    ////bitFunction = new boolFunction();
            //    ////numFunction = new numericFunction();
            //    ////dateFormat = new getDateFormat();

            //    ////MainSqlStr = SessionProxy.MainQueryString;
            //    ////SubSqlStr = SessionProxy.SubQueryString;

            //    ////isSubReport = SessionProxy.IsSubReport;
            //    //MainDataSet = SessionProxy.ReportDataSet;
            //    ////reportPath = SessionProxy.ReportPath.Trim();  
 
            //    ////Session.Remove("MainQueryString");
            //    ////Session.Remove("SubQueryString");
            //    ////Session.Remove("IsSubReport");
            //    ////Session.Remove("ReportDataSet");
            //    ////Session.Remove("ReportPath");
            //    //SessionProxy.RepMainDataSet = MainDataSet;
            //    //MainDataSet.Dispose();
            //}
            this.CallReport();
        }

        public void CallReport() 
        {
            //string cFileName = Server.MapPath(".") + "\\Reports\\Mumbai\\St_Billc.Rpt";
            //string cFileName = Server.MapPath(".") + reportPath.Trim();
            string reportPath = SessionProxy.ReportPath.Trim(); 
            if (!File.Exists(reportPath.Trim()))
            {
                DisplayMessage("Report file not found...");
                return;
            }

            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
  
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();
            getDateFormat dateFormat = new getDateFormat();
            DataSet MainReportCommandSet = new DataSet();
            DataSet SubReportCommandSet = new DataSet();
            DataSet MainDataSet = SessionProxy.ReportDataSet; 
            if (MainDataSet == null)
                MainDataSet = new DataSet();

            
            RepHandle.Load(reportPath);

            string[] subSqlStr = null;
            string[] mainSqlStr = SessionProxy.MainQueryString.Trim().Split(':');
             
            if (SessionProxy.IsSubReport == true && RepHandle.Subreports.Count > 0) // Is Subreport is True
            {
                if (SessionProxy.SubQueryString.Trim() != null && SessionProxy.SubQueryString.Trim()  != "") 
                {
                    subSqlStr = SessionProxy.SubQueryString.Trim().Split(':');  
                    SubReportCommandSet = DataAcess.ExecuteDataset(subSqlStr,connHandle);
                    DataAcess.Connclose(connHandle);
                }
            }

            if (SessionProxy.ReportDataSet == null)
            {
                getCoAdditional GetCoAdditional = new getCoAdditional();
                //MainDataSet = GetCompany.Company(MainDataSet, SessionProxy.ReqCode.Trim(), SessionProxy.FinYear.Trim());
                MainDataSet.Tables.Add(SessionProxy.Company.Copy()); 
                MainDataSet = GetCoAdditional.CoAdditional(MainDataSet);
            }
            else
            {
                if (MainDataSet.Tables.Contains("Company") == false)
                {
                    //getCompany GetCompany = new getCompany();
                    //MainDataSet = GetCompany.Company(MainDataSet, SessionProxy.ReqCode.Trim(), SessionProxy.FinYear.Trim());
                    MainDataSet.Tables.Add(SessionProxy.Company.Copy()); 
                }

                if (MainDataSet.Tables.Contains("Manufact") == false)
                {
                    getCoAdditional GetCoAdditional = new getCoAdditional();
                    MainDataSet = GetCoAdditional.CoAdditional(MainDataSet);
                }

            }

            DataTable command = new DataTable();
            int strCnt = 0;
            foreach (string sqlStr in mainSqlStr)
            {   
                if (!string.IsNullOrEmpty(sqlStr))
                {
                    strCnt += 1;
                    try
                    {
                        MainReportCommandSet = DataAcess.ExecuteDataset(MainReportCommandSet, sqlStr, "Command" + strCnt.ToString().Trim(),500,connHandle);
                        DataAcess.Connclose(connHandle); 
                    }
                    catch (Exception Ex)
                    {
                        DisplayMessage(Ex.Message.Trim());
                        return;
                    }
                }
            }
             
            //RepHandle.DataSourceConnections[0].SetConnection("Uday", 
            //    Session["DbName"].ToString().Trim() , 
            //    "sa", 
            //    "sa1985");
                          
            if (SessionProxy.IsSubReport == true && RepHandle.IsSubreport == true)
            {
                if (subSqlStr == null)
                {
                    RepHandle.SetDataSource(MainReportCommandSet.Tables[0]);
                }
                else
                {
                    RepHandle.SetDataSource(MainReportCommandSet);
                }
            }
            else
            {
                for (int i = 0; i < RepHandle.Database.Tables.Count; i++)
                {
                    RepHandle.Database.Tables[i].SetDataSource(MainReportCommandSet.Tables[i]);   
                }
            }
            
            ParameterValues ParamValue;
            ParameterFieldDefinitions parameterFieldDefinitions = RepHandle.DataDefinition.ParameterFields;
            ParameterDiscreteValue disCreteValue = new ParameterDiscreteValue();

            string param = "";
            string dataTableName = "";
            string colName = "";
            for (int i = 0; i < parameterFieldDefinitions.Count; i++)
            {
                if (parameterFieldDefinitions[i].ParameterFieldUsage.ToString().ToUpper() == "NOTINUSE")
                    continue;

                param = parameterFieldDefinitions[i].ParameterFieldName;
                if (param.Trim().IndexOf('+') >= 0)
                {
                    string[] paramArr = param.Split('+');
                    string discValue = "";
                    string paramS = "";
                    foreach (string paramA in paramArr)
                    {
                        if (paramA.Trim().IndexOf('.') < 0)
                            continue;

                        paramS = "";

                        if (paramA.Trim().ToUpper().IndexOf("ALLT(") >= 0)
                            paramS = paramA.Trim().Substring(5, (paramA.Trim().Length - 5) - 1);

                        if (paramA.Trim().ToUpper().IndexOf("ALLTRIM(") >= 0)
                            paramS = paramA.Trim().Substring(8, (paramA.Trim().Length - 8) - 1);
                        
                        if (paramS.Trim() != "")
                            dataTableName = paramS.Trim().Substring(0, paramS.Trim().IndexOf('.'));
                        else
                        {
                            int paramAL = (paramA.Trim().IndexOf('.') == -1 || paramA.Trim().Length < paramA.Trim().IndexOf('.') 
                                           ? paramA.Trim().Length :
                                             paramA.Trim().IndexOf('.'));

                            dataTableName = paramA.Trim().Substring(0, paramAL);
                        }

                        if (dataTableName.Trim().ToUpper() == "COADDITIONAL")
                            dataTableName = "MANUFACT";

                        try
                        {
                            if (paramA.Trim().ToUpper().IndexOf("ALLTRIM(") >= 0 ||
                                paramA.Trim().ToUpper().IndexOf("ALLT(") >= 0)
                                colName = paramA.Trim().Substring(paramA.Trim().IndexOf('.') + 1, (paramA.Length - paramA.Trim().IndexOf('.')) - 2);
                            else
                                colName = paramA.Trim().Substring(paramA.Trim().IndexOf('.') + 1, (paramA.Length - paramA.Trim().IndexOf('.')) - 1);

                            discValue += "'" + MainDataSet.Tables[dataTableName].Rows[0][colName] + "'";
                        }
                        catch
                        {

                        }
                    }
                    ParamValue = parameterFieldDefinitions[i].CurrentValues;
                    disCreteValue.Value = discValue.Trim(); 
                    ParamValue.Add(disCreteValue);
                    parameterFieldDefinitions[i].ApplyCurrentValues(ParamValue);
                }
                else
                {
                    if (param.Trim().IndexOf('.') >= 0)
                    {
                        dataTableName = param.Trim().Substring(0, param.Trim().IndexOf('.'));

                        if (dataTableName.Trim().ToUpper() == "COADDITIONAL")
                            dataTableName = "MANUFACT";

                        try
                        {
                            colName = param.Trim().Substring(param.Trim().IndexOf('.') + 1, (param.Length - param.Trim().IndexOf('.')) - 1);
                            ParamValue = parameterFieldDefinitions[i].CurrentValues;
                            switch (MainDataSet.Tables[dataTableName].Rows[0][colName].GetType().ToString().Trim().ToUpper())
                            {
                                case "SYSTEM.STRING":
                                    //disCreteValue.Value = "'" + MainDataSet.Tables[dataTableName].Rows[0][colName] + "'";
                                    disCreteValue.Value = Convert.ToString(MainDataSet.Tables[dataTableName].Rows[0][colName]).Trim();
                                    break;
                                case "SYSTEM.DATETIME":
                                    disCreteValue.Value = dateFormat.TodateTime(MainDataSet.Tables[dataTableName].Rows[0][colName]);
                                    break;
                                case "SYSTEM.BOOLEAN":
                                    disCreteValue.Value = bitFunction.toBoolean(MainDataSet.Tables[dataTableName].Rows[0][colName]);
                                    break;
                                case "SYSTEM.DECIMAL":
                                case "SYSTEM.NUMERIC":
                                case "SYSTEM.INT32":
                                case "SYSTEM.INT16":
                                case "SYSTEM.INT64":
                                    disCreteValue.Value = numFunction.toDecimal(MainDataSet.Tables[dataTableName].Rows[0][colName]);
                                    break;
                                case "SYSTEM.DBNULL":
                                    disCreteValue.Value = "";
                                    break;
                            }
                            
                            ParamValue.Add(disCreteValue);
                            parameterFieldDefinitions[i].ApplyCurrentValues(ParamValue);
                        }
                        catch
                        {

                        }
                    }
                    else
                    {
                        if (param.Trim().ToUpper() == "MUSERNAME")
                        {
                            ParamValue = parameterFieldDefinitions[i].CurrentValues;
                            disCreteValue.Value = SessionProxy.UserID.Trim();
                            ParamValue.Add(disCreteValue);
                            parameterFieldDefinitions[i].ApplyCurrentValues(ParamValue);
                        }
                            
                    }
                }
            }

            if (RepHandle.Subreports.Count > 0 && SessionProxy.IsSubReport == true)
            {
                string subParam = "";
                ParameterValues subParamValue;
                ParameterDiscreteValue subDisCreteValue = new ParameterDiscreteValue();
                ParameterFieldDefinitions subParameterFieldDefinitions;

                for (int i=0;i<RepHandle.Subreports.Count;i++)
                {
                    if (SessionProxy.IsSubReport == true && RepHandle.Subreports.Count > 0)
                    {
                        if (subSqlStr == null)
                        {
                            RepHandle.Subreports[i].SetDataSource(MainReportCommandSet.Tables[1]);
                        }
                        else
                        {
                            RepHandle.Subreports[i].SetDataSource(SubReportCommandSet.Tables[i]);
                        }
                    }
                    else
                    {
                        RepHandle.SetDataSource(SubReportCommandSet.Tables[i]);
                    }

                    subParameterFieldDefinitions = RepHandle.Subreports[i].DataDefinition.ParameterFields;
                    for (int sParamCnt = 0; sParamCnt < subParameterFieldDefinitions.Count-1; sParamCnt++)
                    {
                        subParam = subParameterFieldDefinitions[sParamCnt].ParameterFieldName;
                         if (subParam.Trim().IndexOf('.') >= 0)
                         {
                            dataTableName = subParam.Trim().Substring(0, subParam.Trim().IndexOf('.'));
                            
                            if (dataTableName.Trim().ToUpper() == "COADDITIONAL")
                                dataTableName = "MANUFACT";

                            colName = subParam.Trim().Substring(subParam.Trim().IndexOf('.')+1,(subParam.Length - subParam.Trim().IndexOf('.'))-1);
                            subParamValue = subParameterFieldDefinitions[sParamCnt].CurrentValues;
                            subDisCreteValue.Value = "'" + MainDataSet.Tables[dataTableName].Rows[0][colName] + "'";
                            subParamValue.Add(subDisCreteValue);
                            subParameterFieldDefinitions[sParamCnt].ApplyCurrentValues(subParamValue);
                         }
                    }
                }
            }

            
            CRViewer.HasCrystalLogo = false;
            CRViewer.ReportSource = RepHandle;
            

            //RepHandle.ExportToDisk(ExportFormatType.PortableDocFormat,"c:\\zv\\Invoice.pdf");  
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "init", "init();", true);
        }

        protected void CRViewer_Unload(object sender, EventArgs e)
        {
            RepHandle.Close();
            RepHandle.Dispose(); 
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //MemoryStream oStream; // using System.IO
            //oStream = (MemoryStream)
            //RepHandle.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            //Response.Clear();
            //Response.Buffer = true;
            //Response.ContentType = "application/pdf";
            //Response.BinaryWrite(oStream.ToArray());
            //Response.End();

            string filename, ExcelFile, strtype = "PDF";
            filename = "FameMixSal" + DateTime.Now.Day + DateTime.Now.Month + DateTime.Now.Year + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second;
            ExcelFile = Server.MapPath("~") + "\\Reports.pdf";

            DiskFileDestinationOptions diskFileDestinationOptions = new DiskFileDestinationOptions();

            CrystalDecisions.CrystalReports.Engine.ReportDocument dd = new ReportDocument();

            ExportOptions exportOptions = RepHandle.ExportOptions; 
            exportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
            exportOptions.FormatOptions = null;

            exportOptions.ExportFormatType = ExportFormatType.PortableDocFormat; // .ExcelRecord;
            diskFileDestinationOptions.DiskFileName = ExcelFile;
            exportOptions.DestinationOptions = diskFileDestinationOptions;

            try
            {
                switch (strtype)
                {
                    case "Excel":
                        RepHandle.ExportToHttpResponse(ExportFormatType.Excel, Response, false, filename);
                        //rptdoc.ExportToHttpResponse(ExportFormatType.Excel, Response, false, filename);

                        //rptdoc.ExportToHttpResponse(objExcelFormatOptions, Response, false, filename);
                        break;
                    case "PDF":
                        RepHandle.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, false, filename);
                        //rptdoc.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, false, filename);
                        break;
                    case "Word":
                        RepHandle.ExportToHttpResponse(ExportFormatType.WordForWindows, Response, false, filename); 
                        //rptdoc.ExportToHttpResponse(ExportFormatType.WordForWindows, Response, false, filename);
                        break;
                    case "ExcelRecord":
                        //rptdoc.Export();
                        RepHandle.Export(); 
                        Response.Redirect("~/Reports.xls");
                        break;
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }

        
    }
}
