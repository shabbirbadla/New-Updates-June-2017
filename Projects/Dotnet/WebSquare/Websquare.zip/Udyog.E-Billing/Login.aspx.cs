using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Business.Logic.Layer;  


namespace Udyog.E.Billing
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lnkUdXprs.Attributes.Add("onmouseover", "javascript:ImagePlace(0);");
                lnkExmfg.Attributes.Add("onmouseover", "javascript:ImagePlace(1);");
                lnkExTd.Attributes.Add("onmouseover", "javascript:ImagePlace(2);");
                lnkEntAcc.Attributes.Add("onmouseover", "javascript:ImagePlace(3);");
                lnkProfAcc.Attributes.Add("onmouseover", "javascript:ImagePlace(4);");
                lnkTankhwa.Attributes.Add("onmouseover", "javascript:ImagePlace(5);");
                lnkNiryat.Attributes.Add("onmouseover", "javascript:ImagePlace(6);");
                lnkInventory.Attributes.Add("onmouseover", "javascript:ImagePlace(7);");
                lnkOrdProc.Attributes.Add("onmouseover", "javascript:ImagePlace(8);");
                lnkEtds.Attributes.Add("onmouseover", "javascript:ImagePlace(9);");
                lnkVastra.Attributes.Add("onmouseover", "javascript:ImagePlace(10);");
                lnkServicetax.Attributes.Add("onmouseover", "javascript:ImagePlace(11);");
                lnkISD.Attributes.Add("onmouseover", "javascript:ImagePlace(12);");
                //txtReqCode.Attributes.Add("onfocus", "javascript:RemoveAll();");   
                //txtReqCode.Focus();
                //btnClear.Attributes.Add("onclick", "javascript:RemoveAll();");   
                ScriptManager1.SetFocus(txtReqCode);
                txtReqCode.Focus(); 
            }
        }

        protected void txtReqCode_TextChanged(object sender, EventArgs e)
        {
            try
            {
                lblErrorMess.Visible = false;
                vuLogin getLogin = new vuLogin();
                getLogin.txtReqCode_TextChanged(txtReqCode, dropFinYear);
                txtUserId.Focus();
            }
            catch (Exception Ex)
            {
                //lblErrorMess.Visible = true;
                //lblErrorMess.Text = Ex.Message.Trim();
                DisplayMessage(Ex.Message.Trim());
                txtReqCode.Focus();
            }
        }

        protected void btnSign_Click(object sender, EventArgs e)
        {
            try
            {
                lblErrorMess.Visible = false; 
                vuLogin getLogin = new vuLogin();
                getLogin.btnSign_Click(txtReqCode, 
                                       txtPass, 
                                       txtUserId, 
                                       dropFinYear, 
                                       this.Page);

                string strOpenWin = "";
                //strOpenWin = "open_window_max('eBillHomePage.aspx','E-Billing');";
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "openWindowMax()", strOpenWin, true);
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "popup","popupwindow();", true);
                //Response.Redirect("AppDefault.aspx");
                System.Text.StringBuilder script = new System.Text.StringBuilder();
                Response.Cookies["CookUserName"].Value = txtUserId.Text;
                Response.Cookies["CookUserName"].Expires = DateTime.Now.AddDays(1);
                FormsAuthentication.GetAuthCookie(txtUserId.Text.ToLower(), false);
                FormsAuthentication.RedirectFromLoginPage(txtUserId.Text, false);

                if (Cache["MenuItems"] != null)
                    Cache.Remove("MenuItems");
            }
            catch (Exception Ex)
            {
                DisplayMessage(Ex.Message.Trim());
            }

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtReqCode.Text = "";
            txtUserId.Text = "";
            txtPass.Text = "";
            dropFinYear.Items.Clear(); 
            ScriptManager1.SetFocus(txtReqCode); 
        }


        private void DisplayMessage(string strMsg)
        {
            strMsg = strMsg.Replace("\r\n", "\\n");
            strMsg = strMsg.Replace("\n", "\\n");
            strMsg = strMsg.Replace("'", "");
            string scriptString = "alert('" + strMsg + "');";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), null, scriptString, true);

        }

    }
}
