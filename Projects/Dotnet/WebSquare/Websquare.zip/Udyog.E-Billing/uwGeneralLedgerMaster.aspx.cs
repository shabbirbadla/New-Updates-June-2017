using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Data.Acess.Layer;
using Business.Logic.Layer;

namespace Udyog.E.Billing
{
    public partial class uwGeneralLedgerMaster : System.Web.UI.Page
    {
        DataTier DataAccess = new DataTier();
       // private static string vchkProd;
        SqlDataReader da;
        private string sqlstr = "";
        private SqlConnection connHandle;

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }
        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }

        private Int32 ledgerId;

        public Int32 LedgerId
        {
            get { return ledgerId; }
            set { ledgerId = value; }
        }

        private string acGroup;
        public string AcGroup
        {
            get { return acGroup; }
            set { acGroup = value; }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet GnDataSet ;

            if (IsPostBack == true)
            {
                GnDataSet = (DataSet)Session["GnDataSet"];
                if (GnDataSet.Tables["lother"].Rows.Count > 0)
                {
                    DataView xtra_vw = GnDataSet.Tables["lother"].DefaultView;
                    xtra_vw.Sort = "Serial";
                    vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                    try
                    {
                        vuAddInfo.genControls(xtra_vw,
                                GnDataSet.Tables["GLMastView"].Rows[0], tblAddInfoDetails);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                }

                AddMode = Convert.ToBoolean(Request.QueryString["addmode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editmode"]);
                LedgerId = Convert.ToInt32(Request.QueryString["LedgerId"]);
                AcGroup = Convert.ToString(Request.QueryString["ledgergrp"]);

                return;
              }
            

              AddMode = Convert.ToBoolean(Request.QueryString["addmode"]);
              EditMode = Convert.ToBoolean(Request.QueryString["editmode"]);
              LedgerId = Convert.ToInt32(Request.QueryString["LedgerId"]);
              AcGroup = Convert.ToString(Request.QueryString["ledgergrp"]);
              lblTrType.Text = "General Ledger Master";

               // acGroup = "B";
                GnDataSet = new DataSet();
                //DataAccess = new DataTier();
                //DataAccess.DataBaseName = "nxio";
                //Session["ReqCode"] = "m22";
                //Session["Finyear"] = "2008-2009";
                //getCompany GetCompany = new getCompany();
                //GnDataSet = GetCompany.Company(GnDataSet, Session["ReqCode"].ToString().Trim()
                //                , Session["Finyear"].ToString().Trim());
            
                txtName.Attributes.Add("onfocusout", "javascript: NameCopy();");
                fillDropDowns(AcGroup, ref GnDataSet);
                
                if (AddMode == true)
                {
                    AddRecord(ref GnDataSet);
                }
                else
                {
                    if (EditMode == true)
                    {
                        editRec(LedgerId, ref GnDataSet);
                    }
                }

                txtName.Attributes.Add("onfocusout", "javascript: MailNameCopy();");
                sqlstr = "Select * from lother where e_code='AM' order by serial";
                GnDataSet = DataAccess.ExecuteDataset(GnDataSet, sqlstr, "lother",connHandle);
                DataAccess.Connclose(connHandle);

                if (GnDataSet.Tables["lother"].Rows.Count > 0)
                {
                    //AddMode = true;
                    DataView xtra_vw = GnDataSet.Tables["lother"].DefaultView;
                    xtra_vw.Sort = "Serial";
                    vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                    try
                    {
                        vuAddInfo.genControls(xtra_vw, GnDataSet.Tables["GLMastView"].Rows[0], tblAddInfoDetails);
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message);
                    }
                }
                //vchkProd = "vuent";
                
            
            Session["GnDataSet"] = GnDataSet;
            GnDataSet.Dispose();
        }

        protected void AddRecord(ref DataSet GnDataSet)
        {
            getNullUpdate DataNullUpdate = new getNullUpdate();
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();
            //DataAccess = new DataTier();
            //DataAccess.DataBaseName = "nxio";

            sqlstr = "select * from ac_mast where 1=2";
            GnDataSet = DataAccess.ExecuteDataset(GnDataSet, sqlstr, "GLMastView",connHandle);
            DataAccess.Connclose(connHandle);  
            DataRow acMastRow = GnDataSet.Tables["GLMastView"].NewRow();
            acMastRow["Country"] = "India";
            //acMastRow["group"] = "Expense";

            sqlstr = "select country,country_id from country where country = 'India'";
            da = DataAccess.ExecuteDataReader(sqlstr,ref connHandle);
            int countryId = 0;
            if (da.HasRows == true)
            {
                while (da.Read())
                {
                    countryId = numFunction.toInt32(da["country_id"]);
                }
            }
            da.Close();
            da.Dispose();
            DataAccess.Connclose(connHandle);
 
            acMastRow["country_id"] = countryId;

            sqlstr = "select city,city_id from city";
            da = DataAccess.ExecuteDataReader(sqlstr, ref connHandle);
            int cityId = 0;
            if (da.HasRows == true)
            {
                while (da.Read())
                {
                    cityId = numFunction.toInt32(da["city_id"]);
                }
            }
            da.Close();
            da.Dispose();
            DataAccess.Connclose(connHandle);

            acMastRow["country_id"] = countryId;

            sqlstr = "select state,state_id from state ";
            da = DataAccess.ExecuteDataReader(sqlstr, ref connHandle);
            int stateId = 0;
            if (da.HasRows == true)
            {
                while (da.Read())
                {
                    stateId = numFunction.toInt32(da["state_id"]);
                }
            }
            da.Close();
            da.Dispose();
            DataAccess.Connclose(connHandle);

            acMastRow["country_id"] = countryId;


            DataNullUpdate.NullUpdate(acMastRow);
            //ddlCountry.SelectedValue = Convert.ToString(countryId);
            GnDataSet.Tables["GLMastView"].Rows.Add(acMastRow);
            GnDataSet.Tables["GLMastView"].AcceptChanges();

            txtName.Text = Convert.ToString(acMastRow["ac_name"]);
            //txtGroup.Text electedValue = Convert.ToString(acMastRow["group"]).Trim().ToUpper();
           txtContPerson.Text = Convert.ToString(acMastRow["contact"]);
           txtdesignation.Text = Convert.ToString(acMastRow["designatio"]);
           txtAdd.Text= Convert.ToString(acMastRow["add1"]);
           txtAdd1.Text = Convert.ToString(acMastRow["add2"]);
           txtAdd2.Text = Convert.ToString(acMastRow["add3"]);

           ddlCity.SelectedValue = Convert.ToString(acMastRow["city"]).Trim();
           txtZip.Text = Convert.ToString(acMastRow["zip"]);
           ddlstate.SelectedValue = Convert.ToString(acMastRow["state"]).Trim().ToUpper();
           ddlCountry.SelectedValue = Convert.ToString(acMastRow["country"]).Trim().ToUpper();
           txtofficeno.Text =Convert.ToString(acMastRow["phone"]);
           txtresident.Text = Convert.ToString(acMastRow["phoner"]);
           txtfax.Text = Convert.ToString(acMastRow["fax"]);
           txtcellno.Text = Convert.ToString(acMastRow["mobile"]);
           txtEmail.Text = Convert.ToString(acMastRow["email"]);

            DataNullUpdate.NullUpdate(acMastRow);
            ScriptManager1.SetFocus(txtName);
            
            
        }

        protected void editRec(Int32 LedgerId, ref DataSet GnDataSet)
        {
            //DataAccess = new DataTier();
            //DataAccess.DataBaseName = "nxio";
            sqlstr = "select * from ac_mast where ac_id = " + LedgerId;
            GnDataSet = DataAccess.ExecuteDataset(GnDataSet, sqlstr, "GLMastView",connHandle);
            DataAccess.Connclose(connHandle);
            bindControls(GnDataSet.Tables["GLMastView"].Rows[0],true);
            
            if (EditMode == true)
            {
                txtName.Enabled = false;
            }
        }

        protected void bindControls(DataRow acMastRow, bool isGroup)
        {
            numericFunction numFunction = new numericFunction();
            boolFunction bitFunction = new boolFunction();

            txtName.Text = Convert.ToString(acMastRow["ac_name"]);
            if (isGroup == true)
            {
                txtGroup.Text = Convert.ToString(acMastRow["group"]).Trim() == "" ? "" :
                    Convert.ToString(acMastRow["group"]).Trim();

            }
            txtContPerson.Text = Convert.ToString(acMastRow["contact"]);
            txtdesignation.Text = Convert.ToString(acMastRow["designatio"]);
            txtAdd.Text = Convert.ToString(acMastRow["add1"]);
            txtAdd1.Text = Convert.ToString(acMastRow["add2"]);
            txtAdd2.Text = Convert.ToString(acMastRow["add3"]);

            try
            {
                ddlCity.SelectedValue = Convert.ToString(numFunction.toInt32(acMastRow["city_id"])).ToString().Trim() == "0" ?
                        "--Select City--" : Convert.ToString(numFunction.toInt32(acMastRow["city_id"]));
            }
            catch
            {
                ddlCity.SelectedIndex = 0;
            }
            
            txtZip.Text = Convert.ToString(acMastRow["zip"]);

            try
            {
                ddlstate.SelectedValue = Convert.ToString(numFunction.toInt32(acMastRow["state_id"])).ToString().Trim() == "0" ?
                                        "--Select state--" : Convert.ToString(numFunction.toInt32(acMastRow["state_id"]));
            }
            catch
            {
                ddlstate.SelectedIndex = 0;
            }
            try
            {
                ddlCountry.SelectedValue = Convert.ToString(numFunction.toInt32(acMastRow["country_id"])).ToString().Trim() == "0" ?
                    "--Select Country--" : Convert.ToString(numFunction.toInt32(acMastRow["country_id"]));
            }
            catch
            {
                ddlCountry.SelectedIndex = 0;
            }
                      
            txtofficeno.Text = Convert.ToString(acMastRow["phone"]);
            txtfax.Text = Convert.ToString(acMastRow["fax"]);
            txtresident.Text = Convert.ToString(acMastRow["phoner"]);
            txtcellno.Text = Convert.ToString(acMastRow["mobile"]);
            txtEmail.Text = Convert.ToString(acMastRow["email"]);
            
       
        }


        protected void fillDropDowns(string acGroup, ref DataSet GnDataSet)
        {
            DataAccess = new DataTier();
            
            sqlstr = "Select distinct city,city_id from city where city is not null AND City <> '' Order By City";
            GnDataSet = DataAccess.ExecuteDataset(GnDataSet, sqlstr, "CityView",connHandle);
            DataAccess.Connclose(connHandle); 
            ddlCity.DataSource = GnDataSet.Tables["CityView"];
            ddlCity.DataTextField = "city";
            ddlCity.DataValueField = "city_id";
            ddlCity.DataBind();
            ddlCity.Items.Insert(0, "--Select City--");

           
            sqlstr = "Select distinct state_id,state from state where state is not null and state <> '' order by state";
            GnDataSet = DataAccess.ExecuteDataset(GnDataSet, sqlstr, "StateView",connHandle);
            DataAccess.Connclose(connHandle);

            ddlstate.DataSource = GnDataSet.Tables["StateView"];
            ddlstate.DataTextField = "state";
            ddlstate.DataValueField = "state_id";
            ddlstate.DataBind();
            ddlstate.Items.Insert(0, "--Select State--");

           
            sqlstr = "Select distinct country_id,Country from Country where Country is not null and Country <> '' order by Country";
            GnDataSet = DataAccess.ExecuteDataset(GnDataSet, sqlstr, "CountryView",connHandle);
            DataAccess.Connclose(connHandle);

            ddlCountry.DataSource = GnDataSet.Tables["CountryView"];
            ddlCountry.DataTextField = "country";
            ddlCountry.DataValueField = "country_id";
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, "--Select Country--");
        }

        protected void txtGroup_TextChanged(object sender, EventArgs e)
        {
            sqlstr = "select * from ac_mast where ac_name='"
                      + txtGroup.Text.ToString().Trim() + "'";
            //DataAccess = new DataTier();
            //DataAccess.DataBaseName = "NXIO";

  
            DataSet GnDataSet = (DataSet)Session["GnDataSet"];
            GnDataSet = DataAccess.ExecuteDataset(GnDataSet, sqlstr, "GLGroupView",connHandle);
            DataAccess.Connclose(connHandle);


            string oldName = txtName.Text;
            DataRow acMastRow = GnDataSet.Tables["GLMastView"].Rows[0];
            acMastRow = DataAccess.ExactScatterGatherRow(GnDataSet.Tables["GLGroupView"].Rows[0],
                        acMastRow);

            acMastRow.AcceptChanges();
            GnDataSet.Tables["GLMastView"].AcceptChanges();
            
            bindControls(acMastRow, false);
            txtName.Text = oldName;
            Session["GnDataSet"] = GnDataSet;
            GnDataSet.Dispose();
        }


       

        protected void lnkLedgerBtnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("GeneralLedgerView.aspx");
        }

        protected void btnBottomSave_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void btnAllSaveItem_Click(object sender, EventArgs e)
        {
            Save();
        }
        protected void BindSave(DataRow acMastRow,DataSet GnDataSet)
        {
            //DataAccess = new DataTier();
            //DataAccess.DataBaseName = "nxio";
            if (AddMode == true && EditMode == false)
            {
                sqlstr = "select ac_name from ac_mast where ac_name='" + txtName.Text + "'";
                DataAccess = new DataTier();
                da = DataAccess.ExecuteDataReader(sqlstr,ref connHandle);
                if (da.HasRows == true)
                {
                    da.Close();
                    DataAccess.Connclose(connHandle);
                    throw new Exception("Account already exist ");
                }
                da.Close();
                DataAccess.Connclose(connHandle);
            }

           
            numericFunction numFunction = new numericFunction();
            DataTable lother = GnDataSet.Tables["Lother"];
            
            acMastRow["ac_name"] = Convert.ToString(txtName.Text).Trim();
            acMastRow["group"] = txtGroup.Text.Trim();                     
            acMastRow["contact"] = Convert.ToString(txtContPerson.Text);
            acMastRow["designatio"] = Convert.ToString(txtdesignation.Text);
            acMastRow["add1"] = Convert.ToString(txtAdd.Text);
            acMastRow["add2"] = Convert.ToString(txtAdd1.Text);
            acMastRow["add3"] = Convert.ToString(txtAdd2.Text);

            // add city 
            int cityId = 0;
            if (ddlCity.SelectedIndex != 0)
                acMastRow["city_id"] = numFunction.toInt32(ddlCity.SelectedValue);
            else
            {
                sqlstr = "select * from city where rtrim(ltrim(city))=''";
                da = DataAccess.ExecuteDataReader(sqlstr,ref connHandle);
                if (da.HasRows == true)
                {
                    while (da.Read())
                    {
                        cityId = numFunction.toInt32(da["city_id"]);
                    }
                }
                else
                {
                    da.Close();
                    da.Dispose();
                    DataAccess.Connclose(connHandle);

                    sqlstr = "insert into city(city) values ('')";
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(sqlstr, "TX", true,ref connHandle);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        DataAccess.CommitTransaction(cmd.Transaction);

                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        throw Ex;
                    }
                    finally
                    {
                        cmd.Dispose();
                        DataAccess.Connclose(connHandle);
                    }
                }
            
                    
                da.Close();
                da.Dispose();
                acMastRow["city_id"] = cityId;
            }
            acMastRow["city"] = ddlCity.SelectedIndex != 0 ? Convert.ToString(ddlCity.SelectedItem) : "";
            acMastRow["zip"] = Convert.ToString(txtZip.Text);
            acMastRow["state"] = ddlstate.SelectedIndex != 0 ? numFunction.toInt32(acMastRow["state_id"]) : 0;
            acMastRow["country"] = ddlCountry.SelectedIndex != 0 ? numFunction.toInt32(acMastRow["country_id"]) : 0;
            acMastRow["phone"] = Convert.ToString(txtofficeno.Text);
            acMastRow["fax"] = Convert.ToString(txtfax.Text);
            acMastRow["phoner"] = Convert.ToString(txtresident.Text);
            acMastRow["mobile"] = Convert.ToString(txtcellno.Text);
            acMastRow["email"] = Convert.ToString(txtEmail.Text);



            if (lother.Rows.Count > 0)
            {
                vuAdditionalInfo vuAddInfo = new vuAdditionalInfo();
                try
                {
                    vuAddInfo.btnClick(tblAddInfoDetails, acMastRow, "BOXING", null);
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }
         
            acMastRow.AcceptChanges();
        }
        protected void btnTopLedgerSave_Click(object sender, EventArgs e)
        {
            if (IsValid == true)
            {
                try
                {
                    Save(); // call Save Method
                   
                    tblError.Visible = false;
                    Response.Redirect("GeneralLedgerView.aspx?ShowStatus=true");

                }
                catch (Exception Ex)
                {
                    tblError.Visible = true;
                    lblErrorHeading.Text = "Please Check Error Details Below";
                    lblErrorDetails.Text = Ex.Message;
                }
            }

        }
        
        protected void Save()
        { 
            try
            {
                DataSet GnDataSet = (DataSet)Session["GnDataSet"];
                BindSave(GnDataSet.Tables["GLMastView"].Rows[0], GnDataSet);
                //checkValidation(GnDataSet);
                //DataAccess = new DataTier();
                //DataAccess.DataBaseName = "nxio";

                numericFunction numFunction = new numericFunction();
                if (EditMode == true)
                {
                    sqlstr = DataAccess.GenUpdateString(GnDataSet.Tables["GLMastView"], "ac_mast",
                                                new string[] { "ac_id" }, null, "", new string[] { "ac_id" });
                }
                else
                {
                    if (AddMode == true)
                    {
                        sqlstr = DataAccess.GenInsertString(GnDataSet.Tables["GLMastView"].Rows[0], "ac_mast",
                                                    new string[] { "ac_id" }, null);

                    }
                }

                if (sqlstr != "")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = DataAccess.ExecuteNonQuery(sqlstr, "TX", true,ref connHandle);
                    try
                    {

                        cmd.ExecuteNonQuery();

                        DataAccess.CommitTransaction(cmd.Transaction);
                    }
                    catch (Exception Ex)
                    {
                        DataAccess.RollBackTransaction(cmd.Transaction);
                        throw Ex;
                    }
                    finally
                    {
                        cmd.Dispose();
                        DataAccess.Connclose(connHandle);
                    }
                }
                GnDataSet.Dispose();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            }
        protected void btnTopLedgerCancel_Click(object sender, EventArgs e)
        {
        }
        
    }
}

