using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Business.Logic.Layer;
using Data.Acess.Layer;
using System.Data.SqlClient;
  

namespace Udyog.E.Billing
{
    public partial class uwETDCHeaderDetail : System.Web.UI.Page
    {
        //private DataTier DataAcess;
        //private stringFunction stringFunction;
        private numericFunction numFunction;
        private getDateFormat DateFormat;
        //private string sqlstr = "";
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        SqlConnection connHandle;

        private bool addMode;
        public bool AddMode
        {
            get { return addMode; }
            set { addMode = value; }
        }
        private bool editMode;
        public bool EditMode
        {
            get { return editMode; }
            set { editMode = value; }
        }
        private string pcvType;
        public string PcvType
        {
            get { return pcvType; }
            set { pcvType = value; }
        }
        private string beHave;
        public string BeHave
        {
            get { return beHave; }
            set { beHave = value; }
        }
        private string vchkprod;
        public string Vchkprod
        {
            get { return vchkprod; }
            set { vchkprod = value; }
        }
        private string entryTbl;
        public string EntryTbl
        {
            get { return entryTbl; }
            set { entryTbl = value; }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == true)
            {
                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                PcvType = Convert.ToString(Request.QueryString["pcvType"]);
                BeHave = Convert.ToString(Request.QueryString["beHave"]);
                Vchkprod = Convert.ToString(Request.QueryString["vChkProd"]);
                EntryTbl = Convert.ToString(Request.QueryString["entryTbl"]);
                return;
            }
            else
            {
                numFunction = new numericFunction();
                DateFormat = new getDateFormat();
                DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;  
                DataTable main_vw = DsETHeaderDetail.Tables["main_vw"];
                DataTable lcode_vw = DsETHeaderDetail.Tables["lcode_vw"];  

                AddMode = Convert.ToBoolean(Request.QueryString["addMode"]);
                EditMode = Convert.ToBoolean(Request.QueryString["editMode"]);
                PcvType = Convert.ToString(Request.QueryString["pcvType"]);
                BeHave = Convert.ToString(Request.QueryString["beHave"]);
                Vchkprod = Convert.ToString(Request.QueryString["vChkProd"]);
                EntryTbl = Convert.ToString(Request.QueryString["entryTbl"]);


              if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) == 0)
              {
                  main_vw.Rows[0]["cons_id"] = numFunction.toInt32(main_vw.Rows[0]["ac_id"]);
                  main_vw.Rows[0]["scons_id"] = numFunction.toInt32(main_vw.Rows[0]["sac_id"]);
              }

              SqlParameter[] spParam = new SqlParameter[2];
              spParam[0] = new SqlParameter();
              spParam[0].ParameterName = "@entryTbl";
              spParam[0].SqlDbType = SqlDbType.VarChar;
              spParam[0].Value = EntryTbl.Trim();

              spParam[1] = new SqlParameter();
              spParam[1].ParameterName = "@consId";
              spParam[1].SqlDbType = SqlDbType.VarChar;
              spParam[1].Value = numFunction.toInt32(main_vw.Rows[0]["cons_id"]);

              ArrayList dbList = new ArrayList();
              dbList.Add("Mode");
              dbList.Add("Broker");
              if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) != 0)
              {
                  dbList.Add("ConsId");
              }
              DataTier DataAcess = new DataTier();
              DataAcess.DataBaseName = SessionProxy.DbName;

              DataSet InitDS = new DataSet();
              InitDS = DataAcess.ExecuteDataset(InitDS,
                      "sp_ent_web_ETDCHeaderDetail_Init", spParam,
                       dbList,connHandle);
              DataAcess.Connclose(connHandle);

              FillDropDownList(InitDS.Tables["Mode"],InitDS.Tables["Broker"]);




              

              if (numFunction.toInt32(main_vw.Rows[0]["cons_id"]) != 0)
              {
                  if (InitDS.Tables["ConsId"].Rows.Count > 0)
                  {
                      foreach (DataRow ConsRow in InitDS.Tables["ConsId"].Rows)
                      {
                          txtConsignee.Text = Convert.ToString(ConsRow["ac_name"]).Trim();
                      }
                  }
              }

              if (DateFormat.TodateTime(main_vw.Rows[0]["u_cominvdt"]) <= Convert.ToDateTime("01/01/1900") ||
                  DateFormat.TodateTime(main_vw.Rows[0]["u_cominvdt"]) < DateFormat.TodateTime(main_vw.Rows[0]["date"]))
                  main_vw.Rows[0]["u_cominvdt"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);

              if (Convert.ToString(main_vw.Rows[0]["u_mode"]) == "")
              {
                  main_vw.Rows[0]["u_mode"] = "By Road";
                  dropUMode.SelectedValue = Convert.ToString(main_vw.Rows[0]["u_mode"]);
              }

              if (DateFormat.TodateTime(main_vw.Rows[0]["u_tinvdate"]) <= Convert.ToDateTime("01/01/1900") ||
                  DateFormat.TodateTime(main_vw.Rows[0]["u_tinvdate"]) < DateFormat.TodateTime(main_vw.Rows[0]["date"]))
              {
                  main_vw.Rows[0]["u_tinvdate"] = DateFormat.TodateTime(main_vw.Rows[0]["date"]);
              }

              if (Convert.ToString(main_vw.Rows[0]["u_tinvtime"]).Trim() == "")
              {
                  main_vw.Rows[0]["u_tinvtime"] = DateTime.Today.TimeOfDay;
              }
              main_vw.AcceptChanges();

              txtUcominv.Text = Convert.ToString(main_vw.Rows[0]["u_cominv"]).Trim();
              txtUtpono.Text = Convert.ToString(main_vw.Rows[0]["u_tpono"]).Trim();
              txtUtInvTime.Text = Convert.ToString(main_vw.Rows[0]["u_tinvtime"]).Trim();
              txtUgtime.Text = Convert.ToString(main_vw.Rows[0]["u_gtime"]).Trim();
              txtUcominvdt.Text = DateFormat.dateformatBR(Convert.ToString(main_vw.Rows[0]["u_cominvdt"]).Trim());
              txtUtpodate.Text = DateFormat.dateformatBR(Convert.ToString(main_vw.Rows[0]["u_tpodate"]).Trim());
              txtUtinvdate.Text = DateFormat.dateformatBR(Convert.ToString(main_vw.Rows[0]["u_tinvdate"]).Trim());
              txtUtginvdat.Text = DateFormat.dateformatBR(Convert.ToString(main_vw.Rows[0]["u_tginvdat"]).Trim());
              txtUtlrno.Text = Convert.ToString(main_vw.Rows[0]["u_tlrno"]).Trim();
                
              SessionProxy.DsETHeaderDetail = DsETHeaderDetail;
              DsETHeaderDetail.Dispose();
              InitDS.Dispose(); 
              main_vw.Dispose();
              lcode_vw.Dispose();

              if (txtConsignee.Text != "") 
                txtConsigner_TextChanged(sender, e);
              else
                txtUcominv.Focus();

            }
        }

        protected void FillDropDownList(DataTable Mode,DataTable Broker)
        {

            dropUMode.DataSource = Mode;
            dropUMode.DataTextField = "Mode";
            dropUMode.DataValueField = "Mode";
            dropUMode.DataBind();

            dropUMode.Items.Insert(0, "--Select Mode--");

            Mode.Dispose();


            //sqlstr = " select broker from " + EntryTbl.Trim() + "main" +
            //         " group by broker order by broker";

            //tblMode = DataAcess.ExecuteDataTable(sqlstr, "_ss");
            dropBroker.DataSource = Broker;
            dropBroker.DataTextField = "broker";
            dropBroker.DataValueField = "broker";
            dropBroker.DataBind();
            dropBroker.Items.Insert(0, "--Select Broker--");

            Broker.Dispose();

        }

        protected void txtConsigner_TextChanged(object sender, EventArgs e)
        {
            DataTable main_vw = null;
            DataTable shipto_vw = null;
            DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;

            numericFunction numFunction = new numericFunction();
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            try
            {
                main_vw = DsETHeaderDetail.Tables["main_vw"];
                if (txtConsignee.Text.Trim() == "")
                {
                    main_vw.Rows[0]["cons_id"] = 0;
                    main_vw.Rows[0]["scons_id"] = 0;
                    main_vw.AcceptChanges();
                    dropLocation.Enabled = false;
                    return;
                }
                else
                {
                    int acId = 0;

                    SqlParameter[] spParam = new SqlParameter[2];
                    spParam[0] = new SqlParameter();
                    spParam[0].ParameterName = "@acId";
                    spParam[0].SqlDbType = SqlDbType.Int;
                    spParam[0].Value = 0;

                    spParam[1] = new SqlParameter();
                    spParam[1].ParameterName = "@AcName";
                    spParam[1].SqlDbType = SqlDbType.VarChar;
                    spParam[1].Value = txtConsignee.Text.ToString().Trim();

                    SqlDataReader Dr = DataAcess.ExecuteDataReader("sp_ent_web_Acc_validation",
                                                    spParam,ref connHandle);
                    //sqlStr = " select Top 1 Ac_id from ac_mast where ac_name ='" +
                    //    txtConsignee.Text.ToString().Trim() + "'";
                    //Dr = DataAcess.ExecuteDataReader(sqlStr);
                    if (Dr.HasRows == false)
                    {
                        Dr.Close();
                        Dr.Dispose();
                        DataAcess.Connclose(connHandle);
                        throw new Exception("Consigner name not found in master");
                    }
                    else
                    {
                        while (Dr.Read())
                        {
                            acId = numFunction.toInt32(Dr["ac_id"]);
                        }
                    }
                    Dr.Close();
                    Dr.Dispose();
                    DataAcess.Connclose(connHandle);

                    main_vw.Rows[0]["cons_id"] = acId;
                }

                string sqlcond = "";
                GetLocationDetails LocationDetails = new GetLocationDetails();

                shipto_vw = new DataTable();
                shipto_vw = LocationDetails.ListLocationDetails("scons_id", "a.location_id,a.eccno"
                                    , 0, txtConsignee.Text.Trim(), sqlcond, true, shipto_vw);

                if (shipto_vw.Rows.Count > 1)
                {
                    dropLocation.DataSource = shipto_vw;
                    dropLocation.DataTextField = "location_id";
                    dropLocation.DataValueField = "shipto_id";
                    dropLocation.DataBind();
                    dropLocation.Items.Insert(0, "--Select Location--");
                    dropLocation.Enabled = true;
                    //trShiptoLocation.Visible = true;
                    dropLocation.Focus();
                }
                else
                {
                    if (shipto_vw.Rows.Count == 1)
                    {
                        main_vw.Rows[0]["scons_id"] = numFunction.toInt32(shipto_vw.Rows[0]["shipto_id"]);
                        main_vw.AcceptChanges();
                    }
                    else
                    {
                        if (shipto_vw.Rows.Count == 0)
                        {
                            if (dropLocation.SelectedIndex != -1)
                                dropLocation.SelectedIndex = 0;

                            dropLocation.Enabled = false;
                            //trShiptoLocation.Visible = false;
                            main_vw.Rows[0]["scons_id"] = 0;
                            main_vw.AcceptChanges();
                        }

                    }
                }
                SessionProxy.DsETHeaderDetail = DsETHeaderDetail; 
            }
            catch (Exception EX)
            {
                lblError.Text = EX.Message.Trim();
                txtConsignee.Text = "";
                ScriptManager1.SetFocus(txtConsignee);
            }
            finally
            {
                DataAcess.Connclose(connHandle);
                DsETHeaderDetail.Dispose();
                main_vw.Dispose();
                if (shipto_vw != null)
                    shipto_vw.Dispose();
            }

            
        }

        protected void btnDone_Click(object sender, EventArgs e)
        {
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;

            //DataAcess.DataBaseName = SessionProxy.DbName;  
            DataSet DsETHeaderDetail = SessionProxy.DsETHeaderDetail;  
            DataTable main_vw = DsETHeaderDetail.Tables["main_vw"];
            try
            {
                numFunction = new numericFunction();
                DateFormat = new getDateFormat();

                main_vw.Rows[0]["u_cominv"] = Convert.ToString(txtUcominv.Text).Trim();
                main_vw.Rows[0]["u_tpono"] = Convert.ToString(txtUtpono.Text).Trim();
                main_vw.Rows[0]["u_mode"]   = Convert.ToString(dropUMode.SelectedItem).Trim();
                main_vw.Rows[0]["broker"]   = Convert.ToString(dropBroker.SelectedItem).Trim();

                if (txtUcominvdt.Text != "__/__/____")
                    main_vw.Rows[0]["u_cominvdt"] = DateFormat.TodateTime(txtUcominvdt.Text);

                if (txtUtpodate.Text != "__/__/____")
                    main_vw.Rows[0]["u_tpodate"] = DateFormat.TodateTime(txtUtpodate.Text);

                if (txtUtinvdate.Text != "__/__/____")
                    main_vw.Rows[0]["u_tinvdate"] = DateFormat.TodateTime(txtUtinvdate.Text);

                if (txtUtginvdat.Text != "__/__/____")
                    main_vw.Rows[0]["u_tginvdat"] = DateFormat.TodateTime(txtUtginvdat.Text);

                if (txtUgtime.Text.Trim() != "__:__" && txtUgtime.Text.Trim() !="__:__ AM")
                    main_vw.Rows[0]["u_gtime"] = Convert.ToString(txtUgtime.Text).Trim();

                main_vw.Rows[0]["u_tlrno"] = Convert.ToString(txtUtlrno.Text);

                SqlParameter[] spParam = new SqlParameter[2];
                spParam[0] = new SqlParameter();
                spParam[0].ParameterName = "@consId";
                spParam[0].SqlDbType = SqlDbType.Int;
                spParam[0].Value = numFunction.toInt32(main_vw.Rows[0]["Cons_id"]);

                spParam[1] = new SqlParameter();
                spParam[1].ParameterName = "@sconsId";
                spParam[1].SqlDbType = SqlDbType.Int;
                spParam[1].Value = numFunction.toInt32(main_vw.Rows[0]["sCons_id"]);

                SqlDataReader dr = DataAcess.ExecuteDataReader("sp_ent_web_ETDCHeaderDetail_validation",
                                                spParam,ref connHandle);

                //if (numFunction.toInt32(main_vw.Rows[0]["scons_id"]) == 0)
                //    sqlstr = "select top 1 vend_type,eccno from ac_mast " +
                //             " where ac_id =" + numFunction.toInt32(main_vw.Rows[0]["Cons_id"]);
                //else
                //    sqlstr = "select top 1 vend_type,eccno from ac_mast " +
                //             " where ac_id =" + numFunction.toInt32(main_vw.Rows[0]["Cons_id"]) +
                //             " and shipto_id =" + numFunction.toInt32(main_vw.Rows[0]["sCons_id"]);

                //SqlDataReader dr = DataAcess.ExecuteDataReader(sqlstr);
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                    {
                        if (Convert.ToString(main_vw.Rows[0]["Rule"]).Trim().ToUpper() == "EXCISE")
                        {
                            if (Convert.ToString(dr["eccno"]).Trim() == "")
                            {
                                dr.Close();
                                dr.Dispose();
                                DataAcess.Connclose(connHandle);
                                throw new Exception("ECC no. cannot be blank");
                            }
                        }

                        main_vw.Rows[0]["ettype"] = Convert.ToString(dr["vend_type"]);
                    }
                }
                dr.Close();
                dr.Dispose();
                DataAcess.Connclose(connHandle);

                if (Convert.ToString(main_vw.Rows[0]["u_cominv"]) == "")
                    main_vw.Rows[0]["u_cominvdt"] = DateFormat.TodateTime(DateTime.MinValue);

                if (Convert.ToString(main_vw.Rows[0]["u_cominv"]) != "" &&
                    DateFormat.TodateTime(main_vw.Rows[0]["u_cominvdt"]) <= Convert.ToDateTime("01/01/1900"))
                    throw new Exception("Commercial Invoice date cannot be blank");

                if (DateFormat.TodateTime(main_vw.Rows[0]["date"])
                        < DateFormat.TodateTime(main_vw.Rows[0]["U_cominvdt"]))
                    throw new Exception("Commercial Invoice date cannot be greater than Transaction date");

                if (DateFormat.TodateTime(main_vw.Rows[0]["u_tginvdat"])
                        < DateFormat.TodateTime(main_vw.Rows[0]["u_tinvdate"]))
                    throw new Exception("Goods issued Date can't be less than Invoice issued Date");

                if (txtUgtime.Text.Trim() == "__:__" || txtUgtime.Text.Trim() == "__:__ AM")
                    throw new Exception("Goods issued Time cannot be Blank..");
                

                main_vw.AcceptChanges();
                lblError.Text = "";
                SessionProxy.DsETHeaderDetail = DsETHeaderDetail;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "doneDialog();", true);
            }
            catch (Exception Ex)
            {
                lblError.Text = Ex.Message;
            }
            finally
            {
                DsETHeaderDetail.Dispose(); 
                main_vw.Dispose();
                DataAcess.Connclose(connHandle);
            }
        }

    }
}
