using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Web.Script.Serialization;
using System.ComponentModel;
using System.Xml;
using Data.Acess.Layer;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Configuration; 
using System.Web.Caching;
using AjaxControlToolkit;
using Business.Logic.Layer;  

namespace Udyog.E.Billing
{
    /// <summary>
    /// Summary description for ListHelp
    /// </summary>
    
    

    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService]
    
    public class ListHelp : System.Web.Services.WebService
    {
        private UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();
        private SqlConnection connHandle;
        //[WebMethod (CacheDuration=50)]

        
        [WebMethod (EnableSession=true)]
        public string[] getList(String prefixText, string contextKey)
        {
             
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;
               
            string sqlstr = "";
            bool isInternalData = false;
            List<String> suggArList = new List<string>();
            JavaScriptSerializer serializer = new JavaScriptSerializer();
             
            switch (contextKey.ToString().Trim().ToUpper())
            {
                case "ITEM":
                    sqlstr = "select it_name from it_mast [no lock] where it_name like '%" + prefixText.Trim() + "%'" +
                             " order by it_name";
                    break;
                case "BANK":
                    sqlstr = "select ac_name from ac_mast where ac_name like '%" + prefixText.Trim() + "%' and typ='Bank'" +
                             " order by ac_name";
                    break;
                case "ITEMGROUP":
                    sqlstr = "select it_group_name as GroupName,itgrid from item_group " +
                             " where it_group_name like '%" + prefixText.Trim() + "%' order by " +
                             " it_group_name";
                    break;
                case "ACCOUNTGROUP":
                    sqlstr = "select [group] from ac_group_mast where [group] like '%" + prefixText.Trim() + "%'" +
                             " order by [group]";
                    break;
                case "ADDITIONAL INFO":
                    sqlstr = "select validity from lother where validity like '%" + prefixText.Trim() + "%'order by validity";
                    break;
                case "SALESTAX":
                    sqlstr = "select distinct code_nm from lcode where code_nm like '%" + prefixText.Trim() + "%'order by code_nm";
                    break;
                case "SALESACCOUNT":
                    sqlstr = "select ac_name from ac_mast where ac_name like '%" + prefixText.Trim() + "%' and [group]='SUNDRY DEBTORS' order by ac_name";
                    break;
                case "PURACCOUNT":
                    sqlstr = "select ac_name from ac_mast where ac_name like '%" + prefixText.Trim() + "%' and [group]='SUNDRY CREDITORS' ORDER by ac_name";
                    break;
                case "DCMAST":
                    sqlstr = "select head_nm from dcmast where head_nm like '%" + prefixText.Trim() + "%'";
                    break;
                case "BCODE":
                    sqlstr = "select bcode_nm from lcode where bcode_nm  like '%" + prefixText.Trim() + "%'";
                    break;
                case "LCODE_NM":
                    sqlstr = "select code_nm from lcode where code_nm like '%" + prefixText.Trim() + "%'";
                    break;
                case "ET_DC_SUPP_ACC_FROM_SESSION":  
                    if (SessionProxy.ToShow != null)
                    {
                        isInternalData = true;
                        DataTable ToShowView = ((DataTable)Session["ToShow"]).DefaultView.ToTable(true,
                                    new string[] { "Suppname", "Supploc" });;
                        suggArList = new List<string>();
                        foreach (DataRow listRow in ToShowView.Rows)
                        {
                            string list = AutoCompleteExtender.CreateAutoCompleteItem(Convert.ToString(listRow[0]), serializer.Serialize(listRow[0]));
                            //suggArList.Add(Convert.ToString(listRow[0]));
                            suggArList.Add(list);
                        }
                    }
                    break;
                case "ET_DC_MANU_ACC_FROM_SESSION":
                    if (SessionProxy.ToShow != null)
                    {
                        isInternalData = true;
                        DataTable ToShowView = ((DataTable)Session["ToShow"]).DefaultView.ToTable(true,
                                    new string[] { "ManuName", "Manuloc" }); ;

                        suggArList = new List<string>();
                        foreach (DataRow listRow in ToShowView.Rows)
                        {
                            string list = AutoCompleteExtender.CreateAutoCompleteItem(Convert.ToString(listRow[0]), serializer.Serialize(listRow[0]));
                            //suggArList.Add(Convert.ToString(listRow[0]));
                            suggArList.Add(list);
                        }
                    }
                    break;


            }

            if (isInternalData == false)
            {
                //Cache cache = HttpRuntime.Cache;
                CL_User UserKeys = new CL_User(SessionProxy.ReqCode); 
                
                DataSet xmlDS;
                string filterExp = "";
                switch (contextKey.ToString().Trim().ToUpper())
                {
                    case "ACCOUNT":
                    case "BANK":
                        //xmlDS = (DataSet)cache["AcMastView"];
                        xmlDS = (DataSet)UserKeys.Cache["AcMastView"];  
                        if (xmlDS == null)
                        {
                            xmlDS = new DataSet();

                            //string xmlPath = "\\xml\\AcMast.xml";

                            string xmlPath = Convert.ToString(ConfigurationManager.AppSettings["XmlPath"]).Trim() +
                                             "\\xml\\AcMast.xml";

                            //string xmlPath = Convert.ToString(SessionProxy.Company.Rows[0]["dir_nm"]).Trim() +
                            //                 "\\xml\\AcMast.xml";

                            //xmlDS.ReadXml(Server.MapPath(xmlPath));

                            xmlDS.ReadXml(xmlPath);

                            //UserKeys.Cache.Insert("AcMastView", xmlDS, new CacheDependency(Server.MapPath(xmlPath)));
                            UserKeys.Cache.Insert("AcMastView", xmlDS, new CacheDependency(xmlPath));
                            //cache.Insert("AcMastView", xmlDS, new CacheDependency(Server.MapPath(xmlPath)) , Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(20));
                        }

                        suggArList = new List<string>();
                        filterExp = "ac_name like '" + prefixText.Trim() + "%'";
                        foreach (DataRow listRow in xmlDS.Tables["AcXml"].Select(filterExp))
                        {
                            string list = AutoCompleteExtender.CreateAutoCompleteItem(Convert.ToString(listRow["ac_name"]), serializer.Serialize(listRow[0]));
                            suggArList.Add(list);
                        }
                        xmlDS.Dispose();
                        break; 
                    case "ITEM":
                         xmlDS = (DataSet)UserKeys.Cache["ItMastView"];
                         if (xmlDS == null)
                         {
                             if (DBPropsSession.ItRate == false)
                             {
                                 xmlDS = new DataSet();

                                 //string xmlPath = "\\xml\\ItMast.xml";

                                 //string xmlPath = Convert.ToString(SessionProxy.Company.Rows[0]["dir_nm"]).Trim() +
                                 //                 "\\xml\\ItMast.xml";

                                 string xmlPath = Convert.ToString(ConfigurationManager.AppSettings["XmlPath"]).Trim() +
                                             "\\xml\\ItMast.xml";

                                 //xmlDS.ReadXml(Server.MapPath(xmlPath));
                                 xmlDS.ReadXml(xmlPath);
                                 UserKeys.Cache.Insert("ItMastView", xmlDS, new CacheDependency(xmlPath));
                                 //UserKeys.Cache.Insert("ItMastView", xmlDS, new CacheDependency(Server.MapPath(xmlPath)));
                                 //cache.Insert("ItMastView", xmlDS, new CacheDependency(Server.MapPath(xmlPath)), Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(20));
                             }
                             else
                             {
                                 SqlParameter[] spParam = new SqlParameter[1];
                                 spParam[0] = new SqlParameter();
                                 spParam[0].ParameterName = "@prlstcode";
                                 spParam[0].SqlDbType = SqlDbType.VarChar;
                                 spParam[0].Value = SessionProxy.PrlistCode.Trim();
                                 spParam[0].Direction = ParameterDirection.Input;

                                 xmlDS = new DataSet();
                                 ArrayList dblist = new ArrayList();
                                 dblist.Add("ItXml");
                                 xmlDS = DataAcess.ExecuteDataset(xmlDS, "sp_ent_web_pricelist_Item",
                                          spParam, dblist,connHandle);
                                 DataAcess.Connclose(connHandle);

                                 UserKeys.Cache.Insert("ItMastView", xmlDS, null);
                                 //cache.Insert("ItMastView", xmlDS, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(20));
                             }
                         }

                         suggArList = new List<string>();
                         filterExp = "it_name like '" + prefixText.Trim() + "%'";
                         foreach (DataRow listRow in xmlDS.Tables["ItXml"].Select(filterExp))
                         {
                             string list = AutoCompleteExtender.CreateAutoCompleteItem(Convert.ToString(listRow["it_name"]), serializer.Serialize(listRow[0]));
                             suggArList.Add(list);
                         }
                         xmlDS.Dispose();
                        break; 
                    default :
                        DataTable testdb = DataAcess.ExecuteDataTable(sqlstr, "_ss",connHandle);
                        DataAcess.Connclose(connHandle);
                        suggArList = new List<string>();
                        foreach (DataRow listRow in testdb.Rows)
                        {
                            string list = AutoCompleteExtender.CreateAutoCompleteItem(Convert.ToString(listRow[0]), serializer.Serialize(listRow[0]));
                            suggArList.Add(list);
                        }
                        testdb.Dispose();
                        break; 
                }
            }
            return suggArList.ToArray();
        }


        [WebMethod]
        public string[] GetCompletionList5(string prefixText, int count)
        {

            if (count == 0)
            {
                count = 10;
            }

            if (prefixText.Equals("xyz"))
            {
                return new string[0];
            }

            Random random = new Random();
            List<string> items = new List<string>(count);

            for (int i = 0; i < count; i++)
            {

                char c1 = (char)random.Next(65, 90);
                char c2 = (char)random.Next(97, 122);
                char c3 = (char)random.Next(97, 122);
                int id = i;
                int age = random.Next(18, 70);
                items.Add(id.ToString() + "|" + age.ToString() + "|" + prefixText + c1 + c2 + c3);
            }

            return items.ToArray();
        }
    }
}
