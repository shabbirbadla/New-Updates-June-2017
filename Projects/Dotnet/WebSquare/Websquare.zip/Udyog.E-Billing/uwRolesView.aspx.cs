using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;  
using Data.Acess.Layer;
using Business.Logic.Layer;
using AjaxControlToolkit;

namespace Udyog.E_Billing
{
    public partial class uwRolesView : System.Web.UI.Page
    {
        DataTier DataAccess;
        private static string sqlStr = "";
        private String m_strSortExp;
        private SortDirection m_SortDirection = SortDirection.Ascending;
        string SearchString = "";
        private SqlConnection connHandle;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                m_strSortExp = "roleName";

                DataAccess = new DataTier();
                sqlStr = "select cast(0 as bit) as [select], RoleName,RoleId " +
                         " from Roles";
                DataTable rolesview = DataAccess.ExecuteDataTable(sqlStr, "_tmp",connHandle);
                DataAccess.Connclose(connHandle);
 
                Session["RolesView"] = rolesview;
                bindGridView();

                lblTrType.Text = "Roles ";
                txtSearch.Attributes.Add("onkeypress", "return OnKeyEnter();");
                txtSearch.Attributes.Add("onfocus", "select();");
                txtSearch.Focus();

                bool ShowStatus = Convert.ToBoolean(Request.QueryString["ShowStatus"]);

                if (ShowStatus == true)
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "alert('Sucessfully Saved.');", true);
            }
            else
            {
                if (null != ViewState["_SortExp_"])
                {
                    m_strSortExp = ViewState["_SortExp_"] as String;
                }

                if (null != ViewState["_Direction_"])
                {
                    m_SortDirection = (SortDirection)ViewState["_Direction_"];
                }
            }
        }

        private void bindGridView()
        {
            DataTable rolesview = ((DataTable)Session["RolesView"]);
            String strSort = "RoleName DESC ";
            if (null != m_strSortExp &&
                String.Empty != m_strSortExp)
            {
                strSort = String.Format("{0} {1}", m_strSortExp, (m_SortDirection == SortDirection.Descending) ? "DESC" : "ASC");
            }
            DataView dv = new DataView(rolesview, String.Empty, strSort, DataViewRowState.CurrentRows);
            grdRoles.DataSource = dv;
            grdRoles.DataBind();
            ResultDisplay(dv.Count);
        }

        int GetSortColumnIndex(String strCol)
        {
            foreach (DataControlField field in grdRoles.Columns)
            {
                if (field.SortExpression == strCol)
                {
                    return grdRoles.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        void AddSortImage(GridViewRow headerRow)
        {
            Int32 iCol = GetSortColumnIndex(m_strSortExp);
            if (-1 == iCol)
            {
                return;
            }
            // Create the sorting image based on the sort direction.
            Image sortImage = new Image();
            if (SortDirection.Ascending == m_SortDirection)
            {
                sortImage.ImageUrl = "~/Images/ArrowDown.png";
                sortImage.AlternateText = "Ascending Order";
            }
            else
            {
                sortImage.ImageUrl = "~/Images/ArrowUp.png";
                sortImage.AlternateText = "Descending Order";
            }

            // Add the image to the appropriate header cell.
            headerRow.Cells[iCol].Controls.Add(sortImage);
        }

        protected void ResultDisplay(int ResultRows)
        {
            if (ResultRows == 0)
            {
                lblResult.Text = "No Result Found..";
                lnkAll.Enabled = false;
                lnkNone.Enabled = false;
            }
            else
            {
                lblResult.Text = "Result Found :" + ResultRows.ToString().Trim();
                lnkAll.Enabled = true;
                lnkNone.Enabled = true;
            }
        }

        protected void GoToPage_TextChanged(object sender, EventArgs e)
        {
            TextBox txtGoToPage = (TextBox)sender;

            int pageNumber;
            if (int.TryParse(txtGoToPage.Text.Trim(), out pageNumber) && pageNumber > 0 && pageNumber <= this.grdRoles.PageCount)
            {
                this.grdRoles.PageIndex = pageNumber - 1;
            }
            else
            {
                this.grdRoles.PageIndex = 0;
            }

            bindGridView();
        }

        protected void OnRowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                if (String.Empty != m_strSortExp)
                {
                    AddSortImage(e.Row);
                }
            }
        }

        protected void OnSort(object sender, GridViewSortEventArgs e)
        {
            // There seems to be a bug in GridView sorting implementation. Value of
            // SortDirection is always set to "Ascending". Now we will have to play
            // little trick here to switch the direction ourselves.
            if (String.Empty != m_strSortExp)
            {
                if (String.Compare(e.SortExpression, m_strSortExp, true) == 0)
                {
                    m_SortDirection = (m_SortDirection == SortDirection.Ascending) ? SortDirection.Descending : SortDirection.Ascending;
                }
            }

            ViewState["_Direction_"] = m_SortDirection;
            ViewState["_SortExp_"] = m_strSortExp = e.SortExpression;

            this.bindGridView();
        }
        


        protected void grdRoles_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex == grdRoles.PageCount)
            {
                grdRoles.PageIndex = 0;
                bindGridView();
                return;
            }

            if (e.NewPageIndex != -1)
            {
                grdRoles.PageIndex = e.NewPageIndex;
            }
            else
            {
                grdRoles.PageIndex = grdRoles.PageCount;
            }
            bindGridView();
        }

        protected void dropGrdview_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList dropDown = (DropDownList)sender;
            int grdPageSize;
            grdPageSize = int.Parse(dropDown.SelectedValue);
            this.grdRoles.PageSize = grdPageSize;
            bindGridView();
            dropDown.SelectedValue = grdPageSize.ToString();
        }

        protected string EraseWord(string word)
        {
            word = word.Replace("<span class=highlight>", "");
            word = word.Replace("</span>", "");
            word = word.Trim();
            return word;
        }



        public string HighlightText(string InputTxt)
        {
            if (txtSearch.Text != "")
                SearchString = txtSearch.Text.Trim();

            if (SearchString == "")
            {
                return InputTxt;
            }
            else
            {
                System.Text.RegularExpressions.Regex ResultStr;
                ResultStr = new System.Text.RegularExpressions.Regex(SearchString.Replace(" ", "|"), System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return ResultStr.Replace(InputTxt, new System.Text.RegularExpressions.MatchEvaluator(this.ReplaceWords));
            }
        }

        public string ReplaceWords(System.Text.RegularExpressions.Match m)
        {
            return "<span class=highlight>" + m.ToString() + "</span>";
        }

        protected void btnGOSearch_Click(object sender, EventArgs e)
        {
            DataTable rolesview;
            SearchString = "";
            grdRoles.DataBind();
            SearchString = txtSearch.Text;
            sqlStr = "select cast(0 as bit) as [select], rolename,RoleId " +
                     " from Roles" +
                     " where rolename like '%" + txtSearch.Text + "%'";
            rolesview = DataAccess.ExecuteDataTable(sqlStr, "_tmp",connHandle);
            DataAccess.Connclose(connHandle);
            Session["RolesView"] = rolesview; 
            bindGridView();
        }

        protected void grdRoles_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Pager)
            {
                Label lblTotalNumberOfPages = (Label)e.Row.FindControl("lblTotalNumberOfPages");
                lblTotalNumberOfPages.Text = grdRoles.PageCount.ToString();

                TextBox txtGoToPage = (TextBox)e.Row.FindControl("txtGoToPage");
                txtGoToPage.Text = (grdRoles.PageIndex + 1).ToString();

                DropDownList ddlPageSize = (DropDownList)e.Row.FindControl("ddlPageSize");
                ddlPageSize.SelectedValue = grdRoles.PageSize.ToString();
            }
            else
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    //e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';this.style.backgroundColor='#fafad2'";
                    //e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none';this.style.backgroundColor='#f5f5f5'";

                    e.Row.Attributes["onmouseover"] = "this.style.cursor='hand';";
                    e.Row.Attributes["onmouseout"] = "this.style.textDecoration='none'";

                }
            }
        }

        protected void grdRoles_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.Trim().ToUpper())
            {
                case "EDITLINK":
                    Response.Redirect("uwRoleSet.aspx?RoleID=" + grdRoles.DataKeys[Convert.ToInt16(e.CommandArgument)].Values[0].ToString().Trim() +
                                      "&addMode=false&editMode=true");
                    break;
                case "PLUS":
                    GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                    grdViewCallNestGrid(row.RowIndex);
                    break;
            }
        }

        protected void grdViewCallNestGrid(int rowIndex)
        {
            ImageButton findBtn = ((ImageButton)grdRoles.Rows[rowIndex].Cells[0].FindControl("imgNode"));
            if (findBtn.AlternateText.Trim() == "+")
            {
                ((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = true;

                int roleID = 0;
                roleID = Convert.ToInt32(grdRoles.DataKeys[rowIndex].Values[0]);

                string SqlStr = "select [user],state from [user] where roleid =" + roleID;

                DataTable userview = new DataTable();
                userview = DataAccess.ExecuteDataTable(SqlStr, "userVw",connHandle);
                DataAccess.Connclose(connHandle);

                Session["UserView"] = userview;
                if (userview.Rows.Count != 0)
                {
                    ((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                    ((TabPanel)((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).Enabled = true;
                    GridView findItGrid = ((GridView)((TabPanel)((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).FindControl("TabPanel1")).FindControl("grdUsers"));
                    findItGrid.DataSource = userview;
                    findItGrid.DataBind();
                    findBtn.ImageUrl = "~/Images/minus.gif";
                    findBtn.AlternateText = "-";
                }
                else
                {
                    ((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                    ((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = false;
                    findBtn.ImageUrl = "~/Images/Noplus.gif";
                    findBtn.AlternateText = "";
                }
            }
            else
            {
                ((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).ActiveTabIndex = 0;
                ((TabContainer)grdRoles.Rows[rowIndex].Cells[0].FindControl("TabContainer1")).Visible = false;
                findBtn.ImageUrl = "~/Images/plus.gif";
                findBtn.AlternateText = "+";
            }
        }
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= grdRoles.Rows.Count - 1; i++)
            {
                CheckBox chkSelect = (CheckBox)grdRoles.Rows[i].FindControl("chkSelect");
                if (chkSelect.Checked == true)
                {
                    try
                    {
                        DeleteRec(Convert.ToInt32(grdRoles.DataKeys[i].Values[0]));
                        tblError.Visible = false;
                        btnGOSearch_Click(sender, e); // Refresh GridView 
                    }
                    catch (Exception Ex)
                    {
                        tblError.Visible = true;
                        lblErrorHeading.Text = "Error Found while Deleting Records.";
                        lblErrorDetails.Text = Ex.Message;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "null", "HighlightRow(null,'" + chkSelect.ClientID + "');", true);
                        break;
                    }
                }
            }
        }

        protected void DeleteRec(Int32 roleID)
        {
            boolFunction bitFunction = new boolFunction();
            numericFunction numFunction = new numericFunction();

            //DataTable rolesview = ((DataTable)Session["RolesView"]); 
            //DataRow roleRow = rolesview.Select("roleId = " + roleID)[0];
            //int roleID = numFunction.toInt32(roleRow["roleId"]);

            SqlCommand cmd = new SqlCommand();
            sqlStr = DataAccess.GenDeleteString("Roles", "roleId = " + roleID);
            if (sqlStr != "")
            {
                cmd = DataAccess.ExecuteNonQuery(cmd, sqlStr, "TX", true,ref connHandle);
                try
                {
                    cmd.ExecuteNonQuery();
                    sqlStr = DataAccess.GenDeleteString("RolesCompany", "roleId = " + roleID );
                    if (sqlStr != "")
                    {
                        cmd = DataAccess.ExecuteNonQuery(cmd, sqlStr, "TX", true,ref connHandle);
                        try
                        {
                            cmd.ExecuteNonQuery();
                            DataAccess.CommitTransaction(cmd.Transaction);
                        }
                        catch (SqlException Ex)
                        {
                            DataAccess.RollBackTransaction(cmd.Transaction); 
                            throw DataAccess.SqlExceptionErrorsTraping(Ex);
                        }
                        catch (Exception Ex)
                        {
                            DataAccess.RollBackTransaction(cmd.Transaction); 
                            throw Ex;
                        }
                        finally
                        {
                            cmd.Dispose();
                            DataAccess.Connclose(connHandle);
                        }
                    }
                }
                catch (SqlException Ex)
                {
                    throw DataAccess.SqlExceptionErrorsTraping(Ex);
                }
                catch (Exception Ex)
                {
                    throw Ex;
                }
            }
        }

        protected void lnkBtnAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("uwRoleSet.aspx?&addMode=true&editMode=false");
        }

        protected void grdUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView findUserGrid = ((GridView)sender);
            DataTable dataSource = ((DataTable)(findUserGrid.DataSource));
            findUserGrid.PageIndex = e.NewPageIndex;
            findUserGrid.DataSource = ((DataTable)Session["UserView"]);
            findUserGrid.DataBind();
        }


    }
}
