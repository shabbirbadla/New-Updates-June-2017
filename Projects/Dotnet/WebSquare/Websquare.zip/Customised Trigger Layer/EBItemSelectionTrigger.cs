using System;
using System.Collections.Generic;
using System.Text;
using System.Data; 

namespace Customised.Trigger.Layer
{
    public class EBItemSelectionTrigger
    {
        private DataSet eBMainDataSet;

        public DataSet EBMainDataSet
        {
            get { return eBMainDataSet; }
            set { eBMainDataSet = value; }
        }

        public EBItemSelectionTrigger(DataSet MainDataSet)
        {
            EBMainDataSet = MainDataSet;
        }

        public void ItemSelectedIndexChanged()
        {

        }


    }
}
