using System;
using System.Collections.Generic;
using System.Text;

namespace Customised_Trigger_Layer
{
    public class Class1
    {
    }
}
