using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections; 
using System.Data.SqlClient;
using System.Web.UI;  
using System.Web.Caching; 
using Data.Acess.Layer;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Business.Logic.Layer;  
using Controls;


namespace Customised.Trigger.Layer
{
    public class uwTRTrigItemTextChanged
    {
        private static UdyogSessionProxy SessionProxy = new UdyogSessionProxy();
        private static CL_DbProperties_SessionProxy DBPropsSession = new CL_DbProperties_SessionProxy();
        private SqlConnection connHandle;

        public uwTRTrigItemTextChanged()
        {
        }

        public void item_Update(object sender, EventArgs e)
        {
            GraphicalCheckBox chkBox = ((GraphicalCheckBox)((Control)sender).Parent.Parent.FindControl("chku_sample"));
            if (chkBox.Checked == true)
            {
                NumericTextBox txtQRate = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numrate"));
                txtQRate.Text = "0";
            }
        }

        public void Item_TextChanged(DataSet MainDataSet,
            string itcode,
            string xmlPath,
            Cache cache,
            object sender,
            EventArgs e)
        {

            //SqlDataReader Dr;
            DataTier DataAcess = new DataTier();
            DataAcess.DataBaseName = SessionProxy.DbName;  

            //DataSet xmlDS = (DataSet)cache["ItMastView"];
            //if (xmlDS == null)
            //{
            if (DBPropsSession.ItRate == true)
                {
                    SqlParameter[] spParam = new SqlParameter[2];
                    spParam[0] = new SqlParameter();
                    spParam[0].ParameterName = "@prlstcode";
                    spParam[0].SqlDbType = SqlDbType.VarChar;
                    spParam[0].Value = SessionProxy.PrlistCode.Trim();
                    spParam[0].Direction = ParameterDirection.Input;

                    spParam[1] = new SqlParameter();
                    spParam[1].ParameterName = "@itemcode";
                    spParam[1].SqlDbType = SqlDbType.VarChar;
                    spParam[1].Value = itcode;
                    spParam[1].Direction = ParameterDirection.Input;

                    SqlDataReader dr;
                    dr = DataAcess.ExecuteDataReader("sp_ent_web_pricelist_Item",
                             spParam,ref connHandle);
                    if (dr.HasRows == false)
                    {
                        dr.Close();
                        DataAcess.Connclose(connHandle);
                        throw new Exception("Item not found in master");
                    }

                    NumericTextBox txtQCarton = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numu_qcarton"));
                    NumericTextBox txtQRate = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numrate"));

                    while (dr.Read())
                    {
                        txtQCarton.Text = Convert.ToString(dr["u_qty"]).Trim();
                        txtQRate.Text = Convert.ToString(dr["rate"]).Trim();
                        if (Convert.ToDecimal(dr["rate"]) == 0)
                        {
                            txtQRate.Text = "1";
                        }
                    }
                    DataAcess.Connclose(connHandle);
                }
                else
                {
                    DataSet xmlDS = new DataSet();
                    xmlDS = new DataSet();
                    xmlDS.ReadXml(xmlPath);
                    cache.Insert("ItMastView", xmlDS, new CacheDependency(xmlPath), Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(20));

                    string filterExp = "it_name = '" + itcode.Trim() + "'";
                    try
                    {
                        DataRow itRow = xmlDS.Tables["ItXml"].Select(filterExp)[0];
                        NumericTextBox txtQCarton = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numu_qcarton"));
                        NumericTextBox txtQRate = ((NumericTextBox)((Control)sender).Parent.Parent.FindControl("numrate"));
                        txtQCarton.Text = Convert.ToString(itRow["u_qty"]).Trim();
                        txtQRate.Text = Convert.ToString(itRow["rate"]).Trim();
                        if (Convert.ToDecimal(itRow["rate"]) == 0)
                        {
                            txtQRate.Text = "1";
                        }
                    }
                    catch (Exception Ex)
                    {
                        throw new Exception(Ex.Message.Trim() + "Item not found in master");
                    }
                    finally
                    {
                        xmlDS.Dispose();
                    }

                }

               
        }
    }
}
