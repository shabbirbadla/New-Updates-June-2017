using System;
using System.Collections.Generic;
using System.Text;

namespace Customised.Trigger.Layer
{
    //delegate void DropDelegate(object sender, DropEventArgs e);
    //class DropEventArgs : System.EventArgs
    //{
    //    public string astring;
    //    public DropEventArgs(string a)
    //    {
    //        astring = a;
    //    }
    //} 

    //public class DropDelegatesAndEvents
    //{
    //    private DropDelegate youDoIt;
    //    private string param;

    //    void DropDelegatesAndEvents(DropDelegate d, string p)
    //    {
    //        youDoIt = d;
    //        param = p;
    //    }

    //    public void SelectedIndexChanged(object sender, EventArgs e)
    //    {

    //    }
    //}
}
