using System;
using System.Collections.Specialized;
using System.Data;
using System.Configuration;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Compilation;

namespace Controls
{
    public static class Utility
    {
        public static string GetHandlerPath(Type type)
        {
            HttpHandlersSection httpHandlersSection = (HttpHandlersSection)WebConfigurationManager.GetSection("system.web/httpHandlers");

            foreach (HttpHandlerAction httpHandlerAction in httpHandlersSection.Handlers)
            {
                Type httpHandlerActionType = BuildManager.GetType(httpHandlerAction.Type, true);

                if (type.IsAssignableFrom(httpHandlerActionType))
                {
                    return httpHandlerAction.Path;
                }
            }

            string message = string.Format("No HTTP handler defined for '{0}'.", type);
            throw new ArgumentOutOfRangeException(message);
        }

        public static string GetUrl(string baseUrl, NameValueCollection parameters)
        {
            return baseUrl + "?" + UrlEncode(parameters);
        }

        public static string GetUrl(string baseUrl, string param1Name, object param1Value)
        {
            NameValueCollection nvc = new NameValueCollection(1);
            nvc.Add(param1Name, param1Value == null ? null : param1Value.ToString());

            return GetUrl(baseUrl, nvc);
        }

        public static string UrlEncode(NameValueCollection parameters)
        {
            StringBuilder stringBuilder = new StringBuilder();
            bool first = true;
            foreach (string parameter in parameters)
            {
                if (first)
                {
                    first = false;
                }
                else
                {
                    stringBuilder.Append("&");
                }
                stringBuilder.Append(parameter);
                stringBuilder.Append("=");

                string value = parameters[parameter];
                if (value != null)
                {
                    string encodedValue = HttpUtility.UrlEncode(value);
                    encodedValue = encodedValue.Replace("+", "%20");
                    stringBuilder.Append(encodedValue);
                }
            }
            return stringBuilder.ToString();
        }
    }
}
