using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.ComponentModel;
using AjaxControlToolkit;

namespace Controls
{
    public class CollapsiblePanelEx : CollapsiblePanelExtender
    {
        [DefaultValue("")]
        //[SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", Justification = "Following ASP.NET AJAX pattern")]
        [ExtenderControlEvent]
        [ClientPropertyName("expanding")]
        public string OnExpand
        {
            get { return (string)(ViewState["OnExpand"] ?? string.Empty); }
            set { ViewState["OnExpand"] = value; }
        }

        [DefaultValue("")]
        //[SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", Justification = "Following ASP.NET AJAX pattern")]
        [ExtenderControlEvent]
        [ClientPropertyName("expanded")]
        public string OnExpanded
        {
            get { return (string)ViewState["OnExpanded"] ?? string.Empty; }
            set { ViewState["OnExpanded"] = value; }
        }

        [DefaultValue("")]
        //[SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", Justification = "Following ASP.NET AJAX pattern")]
        [ExtenderControlEvent]
        [ClientPropertyName("expandComplete")]
        public string OnExpandComplete
        {
            get { return (string)ViewState["OnExpandComplete"] ?? string.Empty; }
            set { ViewState["OnExpandComplete"] = value; }
        }

        [DefaultValue("")]
        //[SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", Justification = "Following ASP.NET AJAX pattern")]
        [ExtenderControlEvent]
        [ClientPropertyName("collapsing")]
        public string OnCollapse
        {
            get { return (string)ViewState["OnCollapse"] ?? string.Empty; }
            set { ViewState["OnCollapse"] = value; }
        }

        [DefaultValue("")]
        //[SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", Justification = "Following ASP.NET AJAX pattern")]
        [ExtenderControlEvent]
        [ClientPropertyName("collapsed")]
        public string OnCollapsed
        {
            get { return (string)ViewState["OnCollapsed"] ?? string.Empty; }
            set { ViewState["OnCollapsed"] = value; }
        }

        [DefaultValue("")]
        //[SuppressMessage("Microsoft.Naming", "CA1706:ShortAcronymsShouldBeUppercase", Justification = "Following ASP.NET AJAX pattern")]
        [ExtenderControlEvent]
        [ClientPropertyName("collapseComplete")]
        public string OnCollapseComplete
        {
            get { return (string)ViewState["OnCollapseComplete"] ?? string.Empty; }
            set { ViewState["OnCollapseComplete"] = value; }
        }
    }
}
