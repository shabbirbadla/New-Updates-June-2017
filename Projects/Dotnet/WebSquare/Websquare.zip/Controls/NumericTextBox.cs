using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;


namespace Controls
{
    /// Summary description for NumericTextBox.
    /// </summary>
    [DefaultProperty("Format"),
    ToolboxData("<{0}:NumericTextBox runat=server></{0}:NumericTextBox>")]
    public class NumericTextBox : System.Web.UI.WebControls.TextBox
    {
       
        private string format = "0.00";
        private bool allowminusvalue = false;
        private bool allowblank = false;
        private string alignStyle = "RIGHT";
        private bool selectonentry = true;

        [Bindable(true),
        Category("Appearance"),
        Description("Specify the format of number like (0, 0.00, 0000000)."),
        DefaultValue("0.00")]
        public string Format
        {
            get
            {
                return format;
            }

            set
            {
                format = value;
            }
        }


        [Category("Appearance"),
         Description(""),
         DefaultValue("LEFT")]
        public string AlignStyle
        {
            get { return alignStyle; }
            set { alignStyle = value; }
        }

        [Category("Appearance"),
         DefaultValue(false)]
        public bool SelectOnEntry
        {
            get
            {
                return selectonentry;
            }

            set
            {
                selectonentry = value;
            }
        }

        [Category("Appearance"),
        DefaultValue(false)]
        public bool AllowMinusValue
        {
            get
            {
                return allowminusvalue;
            }

            set
            {
                allowminusvalue = value;
            }
        }

        [Bindable(true),
        Category("AllowBlank"),
        Description(""),
        DefaultValue(false)]
        public bool AllowBlank
        {
            get
            {
                return allowblank;
            }

            set
            {
                allowblank = value;
            }
        }

        /// <summary> 
        /// Render this control to the output parameter specified.
        /// </summary>
        /// <param name="output"> The HTML writer to write out to </param>
        protected override void Render(HtmlTextWriter output)
        {

            string strJS = "\n<script language='JavaScript'>\n" +
                "function YouWebFormatNumber(num, format, allowminus, allowblank)\n" +
                "{\n" +
                "	num=num.replace(' ','');\n" +
                "	num=num.replace(',','');\n" +
                "	if(num=='' && allowblank)\n" +
                "		return '';\n" +
                "	if(isNaN(num))\n" +
                "		return format;\n" +
                "	num=Number(num);\n" +
                "	var bknum = num;\n" +
                "	if(num<0 && allowminus==false)\n" +
                "		return format;\n" +
                "	else if(num<0 && allowminus==true)\n" +
                "		num=num*-1;\n" +
                "	var formats, bformat, fformat, btext, ftext='';\n" +
                "	formats = format.split('.');\n" +
                "	bformat = formats[0];\n" +
                "	fformat = formats[1];\n" +
                "	if(!fformat)\n" +
                "		fformat='';\n" +

                "	if(Math.pow(10, bformat.length)>num)\n" +
                "		btext = (parseInt(num,10) + Math.pow(10, bformat.length)+'').substr(1);\n" +
                "	else\n" +
                "		btext = parseInt(num,10);\n" +
                "	if(fformat.length>0)\n" +
                "	{\n" +
                "		ftext = num.toFixed(fformat.length).split('.')[1];\n" +
                "		if(!ftext)\n" +
                "			ftext=fformat;\n" +
                "	}\n" +
                "	if(bknum>=0){\n" +
                "	if(ftext.length>0)\n" +
                "		return btext+'.'+ftext;\n" +
                "	else\n" +
                "		return btext;}\n" +
                "	else if(bknum<0){\n" +
                "	if(ftext.length>0)\n" +
                "		return '-'+btext+'.'+ftext;\n" +
                "	else\n" +
                "		return '-'+btext;}\n" +
                "}\n" +
                "function PreventChar()\n" +
                "{\n" +
                "var e=event;\n" +
                "if (e.keyCode==46 || e.keyCode==45 || (e.keyCode>=48 && e.keyCode<=57))\n" +
                "{\n" +
                "return true;\n" +
                "}\n" +
                "else\n" +
                "{\n" +
                "window.event.keyCode=0;\n" +
                "}\n" +
                "}\n" +
                "</script>";


            //string strJS = "\n<script language='JavaScript'>\n" +
            //    "function YouWebFormatNumber()\n" +
            //    "{\n" +
            //    " alert('uday');\n" +
            //    "}\n" +
            //    "</script>";

            if (!this.Page.IsClientScriptBlockRegistered("YouWebFormatNumber"))
                System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "YouWebFormatNumber", strJS, false);

            //System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "YouWebFormatNumber", strJS, false);

            this.Attributes.Remove("onblur");
            this.Attributes.Remove("onkeypress");
            //this.Attributes.Add("onblur", "this.value=YouWebFormatNumber();");
            this.Attributes.Add("onblur", "this.value=YouWebFormatNumber(this.value,'" + format + "', " + allowminusvalue.ToString().ToLower() + ", " + allowblank.ToString().ToLower() + ");");
            this.Attributes.Add("onkeypress", "PreventChar()");
            
            // Text Align

            if (AlignStyle != null && AlignStyle != "")
            {
                if (AlignStyle.ToString().ToUpper().Trim() == "LEFT")
                {
                    this.Style.Add("text-align", "LEFT");
                }
                else
                {
                    if (AlignStyle.ToString().ToUpper().Trim() == "RIGHT")
                    {
                        this.Style.Add("text-align", "RIGHT");
                    }
                }
            }

            if (SelectOnEntry == true)
            {
                this.Attributes.Remove("onfocus");
                this.Attributes.Add("onfocus", "select();");
            }

         
            base.Render(output);
        }

        public override string Text
        {
            get
            {
                return base.Text;
            }
            set
            {
                    if (value.Trim().Length == 0)
                    {
                        if (allowblank)
                            base.Text = "";
                        else
                            base.Text = format;
                            

                    }
                    else
                    {
                        try
                        {
                            decimal v = decimal.Parse(value);
                            if (!allowminusvalue && v < 0)
                                base.Text = format;
                            else
                            {
                                base.Text = decimal.Parse(value).ToString(this.format);
                            }
                        }
                        catch
                        {
                            base.Text = format;
                        }
                    }

                


                }
            }

            //protected override void OnInit(EventArgs e) 
            //{ 
            //    this.TextChanged += new EventHandler(TextBox1_TextChanged); 
            //    base.OnInit(e); 
            //}    
            
            //void TextBox1_TextChanged(object sender, EventArgs e) 
            //{ 
            //    OnBubbleTextChanged(e); 
            //}    
            
            //public event EventHandler BubbleTextChanged;
            //protected void OnBubbleTextChanged(EventArgs e)
            //{
            //    if (BubbleTextChanged != null)
            //    {
            //        BubbleTextChanged(this, e);
            //    }
            //}
        }


    }


