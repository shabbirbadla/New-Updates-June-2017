using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace Controls
{
    [DefaultProperty("Format"),
   ToolboxData("<{0}:CustDropDownList runat=server></{0}:CustDropDownList>")]

    public class CustDropDownList : System.Web.UI.WebControls.DropDownList    
    {
        private string tag = "";
        private string dbdatavaluefield = "";

        [Category("Accessibility"),
         Description("Specify the Tag value"),
         DefaultValue("")]
        public string Tag
        {
            get { return tag; }
            set { tag = value; }
        }

        [Category("Data"),
         Description("Specify the Datavaluefield of Table"),
         DefaultValue("")]
        public string DbDataValueField
        {
            get { return dbdatavaluefield; }
            set { dbdatavaluefield = value; }
        }

    }
}
