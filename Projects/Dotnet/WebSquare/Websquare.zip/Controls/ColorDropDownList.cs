using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Drawing;

namespace Controls
{
    [ToolboxData("<{0}:ColorDropDownList runat=server></{0}:ColorDropDownList>")]
	public class ColorDropDownList : System.Web.UI.WebControls.DropDownList
	{
		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(false),
		Description("Hide ToolTip")
		]
		public bool ToolTipHide 
		{
			get 
			{
				object o = ViewState["ToolTipHide"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["ToolTipHide"] = value;
				base.Attributes["ToolTipHide"] = value.ToString().ToLower(); 
			}
		}

		[
		Bindable(true), 
		Category("ToolTip"),
		DefaultValue(typeof(Color), "#FFFFE1"),
		Description("ToolTip background color"),
		TypeConverter(typeof(WebColorConverter))
		]
		public Color ToolTipBackColor 
		{
			get 
			{
				object o = ViewState["ToolTipBackColor"];
				return (o == null) ? Color.FromArgb(255,255,225) : (Color)o;
			}
			set 
			{
				ViewState["ToolTipBackColor"] = value;
				base.Attributes["ToolTipBackColor"] = (value != Color.Empty) ? ColorTranslator.ToHtml(value) :  ColorTranslator.ToHtml(Color.FromArgb(255,255,225));
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Color), "Black"),
		Description("ToolTip border color"),
		TypeConverter(typeof(WebColorConverter))
		]
		public Color ToolTipBorderColor 
		{
			get 
			{
				object o = ViewState["ToolTipBorderColor"];
				return ((o == null) ? Color.Black : (Color)o);
			}
			set 
			{
				ViewState["ToolTipBorderColor"] = value;
				base.Attributes["ToolTipBorderColor"] = ColorTranslator.ToHtml(value);
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(BorderStyle.Solid),
		Description("ToolTip border style")
		]
		public BorderStyle ToolTipBorderStyle 
		{
			get 
			{
				object o = ViewState["ToolTipBorderStyle"];
				return (o == null) ? BorderStyle.Solid : (BorderStyle)o;
			}
			set 
			{
				ViewState["ToolTipBorderStyle"] = value;
				base.Attributes["ToolTipBorderStyle"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Unit), "1px"),
		Description("ToolTip border width")
		]
		public Unit ToolTipBorderWidth 
		{
			get 
			{
				object o = ViewState["ToolTipBorderWidth"];
				return (o == null) ? Unit.Parse("1px") : (Unit)o;
			}
			set 
			{
				if (value.Value < 0) throw new ArgumentOutOfRangeException("value");
				ViewState["ToolTipBorderWidth"] = value;
				base.Attributes["ToolTipBorderWidth"] = value.ToString();
			}
		}


		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue("Verdana, Arial, Tahoma"),
		Description("ToolTip font family")
		]
		public string ToolTipFontFamily 
		{
			get 
			{
				string s = (string)ViewState["ToolTipFontFamily"];
				return (s == null) ? "Verdana, Arial, Tahoma" : s;
			}
			set 
			{
				ViewState["ToolTipFontFamily"] = value;
				base.Attributes["ToolTipFontFamily"] = value;
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(FontUnit), "10px"),
		Description("Size of the ToolTip font")
		]
		public FontUnit ToolTipFontSize 
		{
			get 
			{
				object o = ViewState["ToolTipFontSize"];
				return (o == null) ? FontUnit.Parse("10px") : (FontUnit)o;
			}
			set 
			{
				ViewState["ToolTipFontSize"] = value;
				base.Attributes["ToolTipFontSize"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(false),
		Description("Whether the ToolTip font is bold")
		]
		public bool ToolTipFontBold 
		{
			get 
			{
				object o = ViewState["ToolTipFontBold"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["ToolTipFontBold"] = value;
				base.Attributes["ToolTipFontBold"] = (value) ? "Bold" : "Normal";
			}
		}

		[
		Bindable(true), 
		Category("ToolTip"),
		DefaultValue(typeof(Color), "Black"),
		Description("Color of the ToolTip text"),
		TypeConverter(typeof(WebColorConverter))
		]
		public Color ToolTipForeColor 
		{
			get 
			{
				object o = ViewState["ToolTipForeColor"];
				return (o == null) ? Color.Black : (Color)o;
			}
			set 
			{
				ViewState["ToolTipForeColor"] = value;
				base.Attributes["ToolTipForeColor"] = ColorTranslator.ToHtml(value);
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Unit), "1px"),
		Description("ToolTip padding")
		]
		public Unit ToolTipPadding 
		{
			get 
			{
				object o = ViewState["ToolTipPadding"];
				return (o == null) ? Unit.Parse("1px") : (Unit)o;
			}
			set 
			{
				if (value.Value < 0) throw new ArgumentOutOfRangeException("value");
				ViewState["ToolTipPadding"] = value;
				base.Attributes["ToolTipPadding"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(25),
		Description("ToolTip vertical offset")
		]
		public int ToolTipOffsetTop 
		{
			get 
			{
				object o = ViewState["ToolTipOffsetTop"];
				return (o == null) ? 25 : (int)o;
			}
			set 
			{
				ViewState["ToolTipOffsetTop"] = value;
				base.Attributes["ToolTipOffsetTop"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(5),
		Description("ToolTip horizontal offset")
		]
		public int ToolTipOffsetLeft 
		{
			get 
			{
				object o = ViewState["ToolTipOffsetLeft"];
				return (o == null) ? 5 : (int)o;
			}
			set 
			{
				ViewState["ToolTipOffsetLeft"] = value;
				base.Attributes["ToolTipOffsetLeft"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Unit), "10px"),
		Description("ToolTip initial width")
		]
		public Unit ToolTipInitialWidth 
		{
			get 
			{
				object o = ViewState["ToolTipInitialWidth"];
				return (o == null) ? Unit.Parse("10px") : (Unit)o;
			}
			set 
			{
				if (value.Value < 0) throw new ArgumentOutOfRangeException("value");
				ViewState["ToolTipInitialWidth"] = value;
				base.Attributes["ToolTipInitialWidth"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(100),
		Description("ToolTip Z-Index")
		]
		public int ToolTipZIndex 
		{
			get 
			{
				object o = ViewState["ToolTipZIndex"];
				return (o == null) ? 100 : (int)o;
			}
			set 
			{
				ViewState["ToolTipZIndex"] = value;
				base.Attributes["ToolTipZIndex"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(true),
		Description("Save the ToolTip text")
		]
		public bool ToolTipSaveText 
		{
			get 
			{
				object o = ViewState["ToolTipSaveText"];
				return (o == null) ? true : (bool)o;
			}
			set 
			{
				ViewState["ToolTipSaveText"] = value;
				base.Attributes["ToolTipSaveText"] = value.ToString().ToLower();
			}
		}

		protected override void OnInit(EventArgs e)
		{
			string sCode = @"
<script language=javascript>
function xOnKeyUp(key_event)
{
	var lb = key_event.srcElement;

	var el = document.getElementById('div_' + lb.id);
	if (el)
	{
		if (key_event.keyCode == 8)
		{
			key_event.returnValue = false;
			if (el.ToolTipText.length > 0) el.ToolTipText = el.ToolTipText.substr(0, el.ToolTipText.length - 1);

			el.innerText = el.ToolTipText + ' ';
			xFindItem(el.ToolTipText, lb);
		}

		if (key_event.keyCode == 27)
		{
			key_event.returnValue = false;

			el.ToolTipText = '';
			el.innerText = '';
			xFindItem(el.ToolTipText, lb);
		}

		if (key_event.keyCode == 13)
		{
			key_event.returnValue = true;
			if (lb.AutoPostBack == 'true') lb.onchange();
		}
	}
}
	
function xOnKeyPress(key_event)
{
	var lb = key_event.srcElement;

	var el = document.getElementById('div_' + lb.id);
	if (el)
	{
		if (key_event.keyCode != 13)
		{		
			el.ToolTipText = el.ToolTipText + String.fromCharCode(key_event.keyCode); 
			el.innerText = el.ToolTipText +' ';
			xFindItem(el.ToolTipText, lb);
		}
		key_event.returnValue = false;
	}
}

function xFindItem(s, lb)
{
	s = s.toUpperCase();
	
	var slen = s.length;
	var lblen = lb.length;
	var lbo = lb.options;
		
	if (slen == 0 && lblen > 0)
	{ 
		lb.selectedIndex = 0;
		return;
	}

	for (i = 0; i < lblen; i++)
	{	
		if (lbo[i].text.toUpperCase().substr(0, slen) == s)
		{
			lb.selectedIndex = i;
			break;
		}
	}
}

function xOnFocus(elm)
{
	var el = document.getElementById('div_' + elm.id);
	if (!el)
	{
		var xdiv = document.createElement('DIV');
		xdiv.id = 'div_' + elm.id;
		xdiv.noWrap = true;
		xdiv.style.position = 'absolute';
		
		xdiv.ToolTipText = '';
		xdiv.style.color = elm.ToolTipForeColor;
		xdiv.style.width = elm.ToolTipInitialWidth;
		xdiv.style.padding = elm.ToolTipPadding;
		xdiv.style.display  = (elm.ToolTipHide == 'false') ? 'inline' : 'none';
		xdiv.style.backgroundColor = elm.ToolTipBackColor; 
		xdiv.style.borderColor = elm.ToolTipBorderColor; 
		xdiv.style.borderStyle = elm.ToolTipBorderStyle; 
		xdiv.style.borderWidth = elm.ToolTipBorderWidth; 
		xdiv.style.fontFamily = elm.ToolTipFontFamily; 
		xdiv.style.fontSize = elm.ToolTipFontSize; 
		xdiv.style.fontWeight = elm.ToolTipFontBold;
		xdiv.style.zIndex = elm.ToolTipZIndex;

		if (document.documentElement && document.documentElement.scrollTop) xdiv.style.top = document.documentElement.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
			else xdiv.style.top = document.body.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
		if (document.documentElement && document.documentElement.scrollLeft) xdiv.style.left = document.documentElement.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);
			else xdiv.style.left = document.body.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);

		elm.insertAdjacentElement('afterEnd', xdiv);
	}
	else 
	{
		if (document.documentElement && document.documentElement.scrollTop) el.style.top = document.documentElement.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
			else el.style.top = document.body.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
		if (document.documentElement && document.documentElement.scrollLeft) el.style.left = document.documentElement.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);
			else el.style.left = document.body.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);

		if (elm.ToolTipSaveText == 'false') 
		{
			el.innerText = '';
			el.ToolTipText = '';
		}
		el.style.display  = (elm.ToolTipHide == 'false') ? 'inline': 'none';
	}
}

function xOnBlur(elm)
{
	var el = document.getElementById('div_' + elm.id);
	if (el) el.style.display = 'none';
}
</script>";

			if (!Page.IsClientScriptBlockRegistered("xNet")) Page.RegisterClientScriptBlock ("xNet", sCode);

			base.Attributes["onfocus"] = "javascript:xOnFocus(this);";
			base.Attributes["onblur"] = "javascript:xOnBlur(this);";
			base.Attributes["onkeypress"] = "javascript:xOnKeyPress(event);";
			base.Attributes["onkeydown"] = "javascript:xOnKeyUp(event);";
			base.Attributes["ToolTipText"] = ""; 
			base.Attributes["ToolTipHide"] = ToolTipHide.ToString().ToLower(); 
			base.Attributes["ToolTipBackColor"] = (ToolTipBackColor != Color.Empty) ? ColorTranslator.ToHtml(ToolTipBackColor) :  ColorTranslator.ToHtml(Color.FromArgb(255,255,225));
			base.Attributes["ToolTipBorderColor"] = ColorTranslator.ToHtml(ToolTipBorderColor);
			base.Attributes["ToolTipBorderStyle"] = ToolTipBorderStyle.ToString();
			base.Attributes["ToolTipBorderWidth"] = ToolTipBorderWidth.ToString();
			base.Attributes["ToolTipFontFamily"] = ToolTipFontFamily;
			base.Attributes["ToolTipFontSize"] = ToolTipFontSize.ToString();
			base.Attributes["ToolTipFontBold"] = (ToolTipFontBold) ? "Bold" : "Normal";
			base.Attributes["ToolTipForeColor"] = ColorTranslator.ToHtml(ToolTipForeColor);
			base.Attributes["ToolTipOffsetLeft"] = ToolTipOffsetLeft.ToString();
			base.Attributes["ToolTipOffsetTop"] = ToolTipOffsetTop.ToString();
			base.Attributes["ToolTipPadding"] = ToolTipPadding.ToString();
			base.Attributes["ToolTipInitialWidth"] = ToolTipInitialWidth.ToString();
			base.Attributes["ToolTipZIndex"] = ToolTipZIndex.ToString();
			base.Attributes["ToolTipSaveText"] = ToolTipSaveText.ToString().ToLower();
			base.Attributes["AutoPostBack"] = base.AutoPostBack.ToString().ToLower();
		}

		protected override void Render(HtmlTextWriter output)
		{
			base.Render(output);
		}
	}


	[ToolboxData("<{0}:xNetListBox runat=server></{0}:xNetListBox>")]
	public class xNetListBox : System.Web.UI.WebControls.ListBox
	{
		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(false),
		Description("Hide ToolTip")
		]
		public bool ToolTipHide 
		{
			get 
			{
				object o = ViewState["ToolTipHide"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["ToolTipHide"] = value;
				base.Attributes["ToolTipHide"] = value.ToString().ToLower(); 
			}
		}

		[
		Bindable(true), 
		Category("ToolTip"),
		DefaultValue(typeof(Color), "#FFFFE1"),
		Description("ToolTip background color"),
		TypeConverter(typeof(WebColorConverter))
		]
		public Color ToolTipBackColor 
		{
			get 
			{
				object o = ViewState["ToolTipBackColor"];
				return (o == null) ? Color.FromArgb(255,255,225) : (Color)o;
			}
			set 
			{
				ViewState["ToolTipBackColor"] = value;
				base.Attributes["ToolTipBackColor"] = (value != Color.Empty) ? ColorTranslator.ToHtml(value) :  ColorTranslator.ToHtml(Color.FromArgb(255,255,225));
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Color), "Black"),
		Description("ToolTip border color"),
		TypeConverter(typeof(WebColorConverter))
		]
		public Color ToolTipBorderColor 
		{
			get 
			{
				object o = ViewState["ToolTipBorderColor"];
				return ((o == null) ? Color.Black : (Color)o);
			}
			set 
			{
				ViewState["ToolTipBorderColor"] = value;
				base.Attributes["ToolTipBorderColor"] = ColorTranslator.ToHtml(value);
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(BorderStyle.Solid),
		Description("ToolTip border style")
		]
		public BorderStyle ToolTipBorderStyle 
		{
			get 
			{
				object o = ViewState["ToolTipBorderStyle"];
				return (o == null) ? BorderStyle.Solid : (BorderStyle)o;
			}
			set 
			{
				ViewState["ToolTipBorderStyle"] = value;
				base.Attributes["ToolTipBorderStyle"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Unit), "1px"),
		Description("ToolTip border width")
		]
		public Unit ToolTipBorderWidth 
		{
			get 
			{
				object o = ViewState["ToolTipBorderWidth"];
				return (o == null) ? Unit.Parse("1px") : (Unit)o;
			}
			set 
			{
				if (value.Value < 0) throw new ArgumentOutOfRangeException("value");
				ViewState["ToolTipBorderWidth"] = value;
				base.Attributes["ToolTipBorderWidth"] = value.ToString();
			}
		}


		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue("Verdana, Arial, Tahoma"),
		Description("ToolTip font family")
		]
		public string ToolTipFontFamily 
		{
			get 
			{
				string s = (string)ViewState["ToolTipFontFamily"];
				return (s == null) ? "Verdana, Arial, Tahoma" : s;
			}
			set 
			{
				ViewState["ToolTipFontFamily"] = value;
				base.Attributes["ToolTipFontFamily"] = value;
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(FontUnit), "10px"),
		Description("Size of the ToolTip font")
		]
		public FontUnit ToolTipFontSize 
		{
			get 
			{
				object o = ViewState["ToolTipFontSize"];
				return (o == null) ? FontUnit.Parse("10px") : (FontUnit)o;
			}
			set 
			{
				ViewState["ToolTipFontSize"] = value;
				base.Attributes["ToolTipFontSize"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(false),
		Description("Whether the ToolTip font is bold")
		]
		public bool ToolTipFontBold 
		{
			get 
			{
				object o = ViewState["ToolTipFontBold"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["ToolTipFontBold"] = value;
				base.Attributes["ToolTipFontBold"] = (value) ? "Bold" : "Normal";
			}
		}

		[
		Bindable(true), 
		Category("ToolTip"),
		DefaultValue(typeof(Color), "Black"),
		Description("Color of the ToolTip text"),
		TypeConverter(typeof(WebColorConverter))
		]
		public Color ToolTipForeColor 
		{
			get 
			{
				object o = ViewState["ToolTipForeColor"];
				return (o == null) ? Color.Black : (Color)o;
			}
			set 
			{
				ViewState["ToolTipForeColor"] = value;
				base.Attributes["ToolTipForeColor"] = ColorTranslator.ToHtml(value);
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Unit), "1px"),
		Description("ToolTip padding")
		]
		public Unit ToolTipPadding 
		{
			get 
			{
				object o = ViewState["ToolTipPadding"];
				return (o == null) ? Unit.Parse("1px") : (Unit)o;
			}
			set 
			{
				if (value.Value < 0) throw new ArgumentOutOfRangeException("value");
				ViewState["ToolTipPadding"] = value;
				base.Attributes["ToolTipPadding"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(25),
		Description("ToolTip vertical offset")
		]
		public int ToolTipOffsetTop 
		{
			get 
			{
				object o = ViewState["ToolTipOffsetTop"];
				return (o == null) ? 25 : (int)o;
			}
			set 
			{
				ViewState["ToolTipOffsetTop"] = value;
				base.Attributes["ToolTipOffsetTop"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(5),
		Description("ToolTip horizontal offset")
		]
		public int ToolTipOffsetLeft 
		{
			get 
			{
				object o = ViewState["ToolTipOffsetLeft"];
				return (o == null) ? 5 : (int)o;
			}
			set 
			{
				ViewState["ToolTipOffsetLeft"] = value;
				base.Attributes["ToolTipOffsetLeft"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(typeof(Unit), "10px"),
		Description("ToolTip initial width")
		]
		public Unit ToolTipInitialWidth 
		{
			get 
			{
				object o = ViewState["ToolTipInitialWidth"];
				return (o == null) ? Unit.Parse("10px") : (Unit)o;
			}
			set 
			{
				if (value.Value < 0) throw new ArgumentOutOfRangeException("value");
				ViewState["ToolTipInitialWidth"] = value;
				base.Attributes["ToolTipInitialWidth"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(100),
		Description("ToolTip Z-Index")
		]
		public int ToolTipZIndex 
		{
			get 
			{
				object o = ViewState["ToolTipZIndex"];
				return (o == null) ? 100 : (int)o;
			}
			set 
			{
				ViewState["ToolTipZIndex"] = value;
				base.Attributes["ToolTipZIndex"] = value.ToString();
			}
		}

		[
		Bindable(true),
		Category("ToolTip"),
		DefaultValue(true),
		Description("Save ToolTip text")
		]
		public bool ToolTipSaveText 
		{
			get 
			{
				object o = ViewState["ToolTipSaveText"];
				return (o == null) ? true : (bool)o;
			}
			set 
			{
				ViewState["ToolTipSaveText"] = value;
				base.Attributes["ToolTipSaveText"] = value.ToString().ToLower();
			}
		}

		protected override void OnInit(EventArgs e)
		{
			string sCode = @"
<script language=javascript>
function xOnKeyUp(key_event)
{
	var lb = key_event.srcElement;

	var el = document.getElementById('div_' + lb.id);
	if (el)
	{
		if (key_event.keyCode == 8)
		{
			key_event.returnValue = false;
			if (el.ToolTipText.length > 0) el.ToolTipText = el.ToolTipText.substr(0, el.ToolTipText.length - 1);

			el.innerText = el.ToolTipText + ' ';
			xFindItem(el.ToolTipText, lb);
		}

		if (key_event.keyCode == 27)
		{
			key_event.returnValue = false;

			el.ToolTipText = '';
			el.innerText = '';
			xFindItem(el.ToolTipText, lb);
		}

		if (key_event.keyCode == 13)
		{
			key_event.returnValue = true;
			if (lb.AutoPostBack == 'true') lb.onchange();
		}
	}
}
	
function xOnKeyPress(key_event)
{
	var lb = key_event.srcElement;

	var el = document.getElementById('div_' + lb.id);
	if (el)
	{
		if (key_event.keyCode != 13)
		{		
			el.ToolTipText = el.ToolTipText + String.fromCharCode(key_event.keyCode); 
			el.innerText = el.ToolTipText +' ';
			xFindItem(el.ToolTipText, lb);
		}
		key_event.returnValue = false;
	}
}

function xFindItem(s, lb)
{
	s = s.toUpperCase();
	
	var slen = s.length;
	var lblen = lb.length;
	var lbo = lb.options;
		
	if (slen == 0 && lblen > 0)
	{ 
		lb.selectedIndex = 0;
		return;
	}

	for (i = 0; i < lblen; i++)
	{	
		if (lbo[i].text.toUpperCase().substr(0, slen) == s)
		{
			lb.selectedIndex = i;
			break;
		}
	}
}

function xOnFocus(elm)
{
	var el = document.getElementById('div_' + elm.id);
	if (!el)
	{
		var xdiv = document.createElement('DIV');
		xdiv.id = 'div_' + elm.id;
		xdiv.noWrap = true;
		xdiv.style.position = 'absolute';
		
		xdiv.ToolTipText = '';
		xdiv.style.color = elm.ToolTipForeColor;
		xdiv.style.width = elm.ToolTipInitialWidth;
		xdiv.style.padding = elm.ToolTipPadding;
		xdiv.style.display  = (elm.ToolTipHide == 'false') ? 'inline' : 'none';
		xdiv.style.backgroundColor = elm.ToolTipBackColor; 
		xdiv.style.borderColor = elm.ToolTipBorderColor; 
		xdiv.style.borderStyle = elm.ToolTipBorderStyle; 
		xdiv.style.borderWidth = elm.ToolTipBorderWidth; 
		xdiv.style.fontFamily = elm.ToolTipFontFamily; 
		xdiv.style.fontSize = elm.ToolTipFontSize; 
		xdiv.style.fontWeight = elm.ToolTipFontBold;
		xdiv.style.zIndex = elm.ToolTipZIndex;

		if (document.documentElement && document.documentElement.scrollTop) xdiv.style.top = document.documentElement.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
			else xdiv.style.top = document.body.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
		if (document.documentElement && document.documentElement.scrollLeft) xdiv.style.left = document.documentElement.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);
			else xdiv.style.left = document.body.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);
	
		elm.insertAdjacentElement('afterEnd', xdiv);
	}
	else 
	{
		if (document.documentElement && document.documentElement.scrollTop) el.style.top = document.documentElement.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
			else el.style.top = document.body.scrollTop + elm.getBoundingClientRect().top - parseInt(elm.ToolTipOffsetTop);
		if (document.documentElement && document.documentElement.scrollLeft) el.style.left = document.documentElement.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);
			else el.style.left = document.body.scrollLeft + elm.getBoundingClientRect().left + parseInt(elm.ToolTipOffsetLeft);

		if (elm.ToolTipSaveText == 'false') 
		{
			el.innerText = '';
			el.ToolTipText = '';
		}
		el.style.display  = (elm.ToolTipHide == 'false') ? 'inline': 'none';
	}
}

function xOnBlur(elm)
{
	var el = document.getElementById('div_' + elm.id);
	if (el) el.style.display = 'none';
}
</script>";

			if (!Page.IsClientScriptBlockRegistered("xNet")) Page.RegisterClientScriptBlock ("xNet", sCode);

			base.Attributes["onfocus"] = "javascript:xOnFocus(this);";
			base.Attributes["onblur"] = "javascript:xOnBlur(this);";
			base.Attributes["onkeypress"] = "javascript:xOnKeyPress(event);";
			base.Attributes["onkeydown"] = "javascript:xOnKeyUp(event);";
			base.Attributes["ToolTipText"] = ""; 
			base.Attributes["ToolTipHide"] = ToolTipHide.ToString().ToLower(); 
			base.Attributes["ToolTipBackColor"] = (ToolTipBackColor != Color.Empty) ? ColorTranslator.ToHtml(ToolTipBackColor) :  ColorTranslator.ToHtml(Color.FromArgb(255,255,225));
			base.Attributes["ToolTipBorderColor"] = ColorTranslator.ToHtml(ToolTipBorderColor);
			base.Attributes["ToolTipBorderStyle"] = ToolTipBorderStyle.ToString();
			base.Attributes["ToolTipBorderWidth"] = ToolTipBorderWidth.ToString();
			base.Attributes["ToolTipFontFamily"] = ToolTipFontFamily;
			base.Attributes["ToolTipFontSize"] = ToolTipFontSize.ToString();
			base.Attributes["ToolTipFontBold"] = (ToolTipFontBold) ? "Bold" : "Normal";
			base.Attributes["ToolTipForeColor"] = ColorTranslator.ToHtml(ToolTipForeColor);
			base.Attributes["ToolTipOffsetLeft"] = ToolTipOffsetLeft.ToString();
			base.Attributes["ToolTipOffsetTop"] = ToolTipOffsetTop.ToString();
			base.Attributes["ToolTipPadding"] = ToolTipPadding.ToString();
			base.Attributes["ToolTipInitialWidth"] = ToolTipInitialWidth.ToString();
			base.Attributes["ToolTipZIndex"] = ToolTipZIndex.ToString();
			base.Attributes["ToolTipSaveText"] = ToolTipSaveText.ToString().ToLower(); 
			base.Attributes["AutoPostBack"] = base.AutoPostBack.ToString().ToLower();
		}

		protected override void Render(HtmlTextWriter output)
		{
			base.Render(output);
		}
	}
	}
